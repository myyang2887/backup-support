"""v3.31：案件フォルダ単位の要約（1 フォルダ = 1 案件 = 1 要約）。"""
from __future__ import annotations

import json
import time
from pathlib import Path

import openpyxl
import pytest

from app import case_detect as CD
from app import case_flow as CF
from app.reference_index import build_index

SUFS = {".pdf", ".pptx", ".xlsx", ".md"}


def _ledger(path: Path, rows=None) -> Path:
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["依頼番号", "依頼日", "件名", "依頼者", "完了日"])
    for r in rows or [
        ["2023-045", "2023/04/03", "アルミ外材コート層硬さ試験", "製造技術部", "2023/05/01"],
        ["2023-046", "2023/05/10", "樹脂筐体の熱流体解析", "設計部", "2023/06/20"],
        ["2023-047", "2023/06/01", "光学フィルム透過率評価", "開発部", "2023/07/15"],
    ]:
        ws.append(r)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return path


@pytest.fixture()
def index(tmp_path):
    return build_index([str(_ledger(tmp_path / "refs" / "台帳.xlsx"))], use_cache=False)


# ----------------------------------------------------------------------
# フォルダ名での照合
# ----------------------------------------------------------------------

def test_match_folder_stages(index):
    r = index.match_folder("アルミ外材コート層硬さ試験")
    assert r.ok and r.confirmed and r.method == "exact_filename"
    assert "フォルダ名" in r.reason
    r = index.match_folder("2023-046_熱解析")
    assert r.ok and r.method == "request_number"
    r = index.match_folder("光学フィルム透過率評価（追加測定）")
    assert r.ok and r.method == "partial" and not r.confirmed
    assert not index.match_folder("速報").ok            # 一般語では当たらない
    assert not index.match_folder("").ok


def test_match_folder_does_not_use_parent_names(index):
    """親の名前で当たると、子フォルダが親の案件として二重に数えられる。"""
    r = index.match_folder("速報", "アルミ外材コート層硬さ試験/速報")
    assert not r.ok


def test_match_folder_keeps_dots_in_name(tmp_path):
    idx = build_index([str(_ledger(tmp_path / "r" / "t.xlsx",
                                   [["2023-050", "2023/1/1", "冷却ファン Ver.2 評価", "設計部", ""]]))],
                      use_cache=False)
    assert idx.match_folder("冷却ファン Ver.2 評価").ok


# ----------------------------------------------------------------------
# 案件の切り出し
# ----------------------------------------------------------------------

RELS = [
    "2023年度/アルミ外材コート層硬さ試験/報告書.pdf",
    "2023年度/アルミ外材コート層硬さ試験/速報/速報2.xlsx",
    "2023年度/アルミ外材コート層硬さ試験/補足/条件.pptx",
    "2023年度/2023-046_熱解析/結果.pptx",
    "2023年度/2023-046_熱解析/~$結果.pptx",
    "2023年度/光学フィルム透過率評価/写真.png",
    "2023年度/光学フィルム透過率評価/測定.xlsx",
    "2023年度/一覧メモ.pdf",
    "2023年度/その他/memo.pdf",
]


def test_detect_nearest_matched_folder_is_the_case(index):
    r = CD.detect_cases(RELS, index, SUFS)
    names = {c["name"]: c for c in r["cases"]}
    assert set(names) == {"アルミ外材コート層硬さ試験", "2023-046_熱解析", "光学フィルム透過率評価"}
    alu = names["アルミ外材コート層硬さ試験"]
    # サブフォルダの資料も同じ案件に入る（何階層でも）
    assert [f["rel_in_case"] for f in alu["files"]] == ["報告書.pdf", "補足/条件.pptx", "速報/速報2.xlsx"]
    assert alu["match"]["confirmed"] and not alu["needs_review"]
    assert alu["match"]["row"]["cells"][0]["value"] == "2023-045"
    assert r["unassigned"] == ["2023年度/その他/memo.pdf", "2023年度/一覧メモ.pdf"]
    assert r["excluded"] == [{"rel": "2023年度/光学フィルム透過率評価/写真.png",
                              "reason": "未対応の形式 .png"}]
    assert not r["fallback"]


def test_detect_outermost_folder_can_be_the_case(index):
    r = CD.detect_cases(["アルミ外材コート層硬さ試験/a.pdf",
                         "アルミ外材コート層硬さ試験/x/y/z/b.xlsx"], index, SUFS)
    assert len(r["cases"]) == 1 and r["cases"][0]["file_count"] == 2


def test_detect_same_row_from_two_folders_is_one_case(index):
    r = CD.detect_cases(["A/アルミ外材コート層硬さ試験/a.pdf",
                         "B/2023-045 追加分/b.pdf"], index, SUFS)
    assert len(r["cases"]) == 1
    c = r["cases"][0]
    assert c["folders"] == ["A/アルミ外材コート層硬さ試験", "B/2023-045 追加分"]
    # 複数フォルダの案件では、資料名にフォルダ名を付けて区別する
    assert [f["rel_in_case"] for f in c["files"]] == ["アルミ外材コート層硬さ試験/a.pdf",
                                                       "2023-045 追加分/b.pdf"]
    assert c["notes"]


def test_detect_prefers_confirmed_outer_over_weak_inner(index):
    """近い方の当たりが「要確認」で、外側に別の行への「確定」があれば外側を採る。"""
    rels = ["アルミ外材コート層硬さ試験/光学フィルム透過率評価（参考）/c.pdf",
            "アルミ外材コート層硬さ試験/a.pdf"]
    r = CD.detect_cases(rels, index, SUFS)
    assert len(r["cases"]) == 1 and r["cases"][0]["name"] == "アルミ外材コート層硬さ試験"
    assert r["cases"][0]["file_count"] == 2


def test_detect_keys_are_stable_for_subsets(index):
    full = {c["name"]: c["key"] for c in CD.detect_cases(RELS, index, SUFS)["cases"]}
    sub = CD.detect_cases([r for r in RELS if "アルミ" in r], index, SUFS)["cases"]
    assert sub[0]["key"] == full["アルミ外材コート層硬さ試験"]


def test_detect_fallback_without_ledger():
    r = CD.detect_cases(["案件X/a.pdf", "案件X/s/b.pdf", "直下.pdf"], None, SUFS)
    assert r["fallback"] and "台帳が登録されていない" in r["message"]
    assert [(c["name"], c["file_count"]) for c in r["cases"]] == [("案件X", 2)]
    assert r["cases"][0]["needs_review"] and r["unassigned"] == ["直下.pdf"]


def test_detect_fallback_when_nothing_matches(index):
    r = CD.detect_cases(["無関係なフォルダ/a.pdf"], index, SUFS)
    assert r["fallback"] and "台帳未照合" in r["message"]


# ----------------------------------------------------------------------
# 資料の読み取り（read_only）と統合
# ----------------------------------------------------------------------

@pytest.fixture()
def cfg(tmp_path):
    from app.config import load_config
    c = load_config()
    c.llm.mock = True
    c.paths.out_dir = str(tmp_path / "out")
    c.workflow.reference_library_dir = str(tmp_path / "refs")
    _ledger(tmp_path / "refs" / "台帳.xlsx")
    return c


def _case_folder(root: Path) -> Path:
    d = root / "src" / "アルミ外材コート層硬さ試験"
    (d / "速報").mkdir(parents=True)
    (d / "報告書.md").write_text("# 報告書\n\n結果：ビッカース硬さ 512 HV。前回比 8% 向上。",
                                encoding="utf-8")
    (d / "速報" / "速報2.md").write_text("# 速報\n\n速報値：ビッカース硬さ 509 HV。",
                                        encoding="utf-8")
    return d


def _case_for(cfg, folder: Path):
    rels = {p.relative_to(folder.parent).as_posix(): str(p)
            for p in folder.rglob("*") if p.is_file()}
    det = CD.detect_cases(list(rels), CD.load_index(cfg), SUFS)
    c = det["cases"][0]
    members = [{"rel": f["rel"], "rel_in_case": f["rel_in_case"], "name": f["name"],
                "path": rels[f["rel"]]} for f in c["files"]]
    return {"key": c["key"], "name": c["name"], "folders": c["folders"],
            "match": c["match"], "members": members}


def test_read_only_member_stops_before_summary(cfg, tmp_path):
    from app.graph import run_workflow
    f = tmp_path / "m.md"
    f.write_text("# 見出し\n\n本文。", encoding="utf-8")
    root = tmp_path / "members"
    final = run_workflow(str(f), cfg, runs_root=str(root), read_only=True, case_member=True)
    rd = Path(final["run_dir"])
    assert rd.parent == root                                  # 単発の runs/ には置かない
    assert (rd / "evidence_aggregated.json").exists()
    assert not (rd / "case_summary.md").exists()              # 要約は書かない
    st = json.loads((rd / "status.json").read_text(encoding="utf-8"))
    nodes = {h["node"] for h in st["history"]}
    assert {"gap_fill", "analyze_visual"} <= nodes and "write_summary" not in nodes
    lr = [h for h in st["history"] if h["node"] == "lookup_reference" and h["phase"] == "done"]
    assert lr and lr[-1]["detail"] == "案件単位で照合"           # 台帳は案件単位で 1 回


def test_member_aggregation_is_not_capped(cfg, tmp_path, monkeypatch):
    """案件の資料は類別上限・文字数上限で証拠を削らない（0 = 上限なし）。"""
    import app.nodes as N
    seen = {}
    real = N.aggregate_evidence

    def spy(items, **kw):
        seen.update(kw)
        return real(items, **kw)

    monkeypatch.setattr(N, "aggregate_evidence", spy)
    from app.graph import run_workflow
    f = tmp_path / "m.md"
    f.write_text("# 見出し\n\n本文。", encoding="utf-8")
    run_workflow(str(f), cfg, runs_root=str(tmp_path / "mem"), read_only=True, case_member=True)
    assert seen["max_per_category"] >= 10 ** 9 and seen["max_total_chars"] >= 10 ** 12


class _Spy:
    """モック LLM の呼び出しを記録する。"""

    def __init__(self, cfg):
        from app.llm_client import LocalLLMClient
        self.inner = LocalLLMClient(**cfg.llm.model_dump(exclude={"vision"}))
        self.metrics_hook = None
        self.calls = []

    def chat_json(self, **kw):
        self.calls.append(kw)
        return self.inner.chat_json(**kw)

    def __getattr__(self, name):
        return getattr(self.inner, name)


def test_run_case_end_to_end(cfg, tmp_path):
    folder = _case_folder(tmp_path)
    case = _case_for(cfg, folder)
    cid = CF.case_id_for(case["name"], [m["path"] for m in case["members"]])
    cdir = Path(cfg.paths.out_dir) / "runs" / cid
    CF.prepare_case_dir(cdir, case, "case", "依頼対応事例")
    spy = _Spy(cfg)
    CF.run_case(cdir, case, cfg, template_id="case", llm=spy)

    assert (cdir / "case_summary.md").exists() and (cdir / "case_summary.json").exists()
    prog = CF.read_progress(cdir)
    assert prog["phase"] == "done" and all(m["state"] == "done" for m in prog["members"])
    # 資料の読み取り結果は case_members/ に置かれる
    assert all("case_members" in m["run_dir"] for m in prog["members"])

    # 統合：出典付き・ID は資料ごとに接頭辞・台帳は案件で 1 回
    ev = json.loads((cdir / "evidence_aggregated.json").read_text(encoding="utf-8"))["evidence"]
    ref = [e for e in ev if str(e["evidence_id"]).startswith("ref_")]
    body = [e for e in ev if not str(e["evidence_id"]).startswith("ref_")]
    assert ref and any("2023-045" in e["content"] for e in ref)
    assert body and all(e["evidence_id"][:4] in ("f01_", "f02_") for e in body)
    assert {e["file"] for e in body} <= {"報告書.md", "速報/速報2.md"}
    ids = [e["evidence_id"] for e in ev]
    assert len(ids) == len(set(ids))

    # 要約の指示：案件の規則・資料一覧・両資料の証拠が入り、出力上限は案件用
    main = [c for c in spy.calls if c.get("tag") == "summary:main"][0]
    user = main["user"]
    assert "案件としての要約" in user and "黙って選ばない" in user
    assert '"documents"' in user and "報告書.md" in user and "速報/速報2.md" in user
    assert main["max_tokens"] == cfg.case.summary_max_tokens
    rep = json.loads((cdir / "case_merge_report.json").read_text(encoding="utf-8"))
    assert rep["documents"] == 2 and rep["ledger_evidence"] >= 1


def test_run_case_reports_failed_member_and_continues(cfg, tmp_path, monkeypatch):
    folder = _case_folder(tmp_path)
    case = _case_for(cfg, folder)
    import app.graph as G
    real = G.run_workflow

    def flaky(path, *a, **kw):
        if "速報2" in str(path):
            raise RuntimeError("壊れたファイル")
        return real(path, *a, **kw)

    monkeypatch.setattr(G, "run_workflow", flaky)
    cdir = Path(cfg.paths.out_dir) / "runs" / "c1"
    CF.prepare_case_dir(cdir, case, "case")
    state = CF.run_case(cdir, case, cfg, template_id="case")
    prog = CF.read_progress(cdir)
    assert [m["state"] for m in prog["members"]] == ["done", "failed"]
    msgs = [e.get("message", "") for e in state.get("errors", [])]
    assert any("速報/速報2.md" in m and "含まれていません" in m for m in msgs)
    assert (cdir / "case_summary.md").exists()


def test_run_case_all_members_failed_raises(cfg, tmp_path, monkeypatch):
    folder = _case_folder(tmp_path)
    case = _case_for(cfg, folder)
    import app.graph as G
    monkeypatch.setattr(G, "run_workflow", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("x")))
    cdir = Path(cfg.paths.out_dir) / "runs" / "c2"
    CF.prepare_case_dir(cdir, case, "case")
    with pytest.raises(RuntimeError, match="すべての資料"):
        CF.run_case(cdir, case, cfg, template_id="case")


def test_run_case_cancel_between_members(cfg, tmp_path):
    from app.observability import RunCancelled, RunStore
    folder = _case_folder(tmp_path)
    case = _case_for(cfg, folder)
    cdir = Path(cfg.paths.out_dir) / "runs" / "c3"
    CF.prepare_case_dir(cdir, case, "case")
    RunStore(cdir).request_cancel()
    with pytest.raises(RunCancelled):
        CF.run_case(cdir, case, cfg, template_id="case")


def test_cross_file_duplicates_are_merged_but_traced(cfg, tmp_path):
    """資料をまたいだ完全な重複は 1 件にするが、どの資料にもあったかは残す。"""
    from app.observability import RunStore
    m1, m2 = tmp_path / "m1", tmp_path / "m2"
    for d, items in ((m1, ["硬さ 512 HV", "固有A"]), (m2, ["硬さ 512 HV", "固有B"])):
        RunStore(d).save_json("evidence_aggregated.json", {"evidence": [
            {"evidence_id": f"e{i}", "category": "result", "content": t, "confidence": 0.9}
            for i, t in enumerate(items)]})
        RunStore(d).save_json("evidence_visual.json", {"evidence": []})
    case = {"name": "X", "folders": [], "members": [
        {"rel_in_case": "a.pdf", "name": "a.pdf", "state": "done", "run_dir": str(m1)},
        {"rel_in_case": "b.pdf", "name": "b.pdf", "state": "done", "run_dir": str(m2)}]}
    node = CF.make_merge_node(cfg)
    run_dir = tmp_path / "case"
    run_dir.mkdir()
    out = node({"run_dir": str(run_dir), "case": case, "errors": []})
    contents = [e["content"] for e in out["aggregated_evidence"] if not e["evidence_id"].startswith("ref_")]
    assert contents == ["硬さ 512 HV", "固有A", "固有B"]
    dup = [e for e in out["aggregated_evidence"] if e["content"] == "硬さ 512 HV"][0]
    assert dup["file"] == "a.pdf" and dup["also_in"] == ["b.pdf"]
    assert out["case_meta"]["document_count"] == 2


def test_single_run_prompt_is_unchanged(cfg, tmp_path):
    """単発の要約には案件の規則を入れない（従来どおり）。"""
    from app.graph import run_workflow
    f = tmp_path / "s.md"
    f.write_text("# 見出し\n\n本文。", encoding="utf-8")
    spy = _Spy(cfg)
    from app.graph import build_graph
    app_ = build_graph(cfg, spy)
    app_.invoke({"input_path": str(f)}, config={"recursion_limit": 60})
    main = [c for c in spy.calls if c.get("tag") == "summary:main"][0]
    assert "案件としての要約" not in main["user"] and main["max_tokens"] == 8192


# ----------------------------------------------------------------------
# API と画面
# ----------------------------------------------------------------------

@pytest.fixture()
def client(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient

    import app.webapp as W
    monkeypatch.setattr(W.config.paths, "out_dir", str(tmp_path / "out"))
    monkeypatch.setattr(W.config.paths, "inbox_dir", str(tmp_path / "inbox"))
    monkeypatch.setattr(W.config.ledger, "db_path", str(tmp_path / "out" / "ledger.sqlite3"))
    from app.ledger import Ledger
    (tmp_path / "out").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(W, "_ledger", Ledger(tmp_path / "out" / "case_ledger.sqlite3"))
    monkeypatch.setattr(W.config.llm, "mock", True)
    monkeypatch.setattr(W.config.workflow, "reference_library_dir", str(tmp_path / "refs"))
    _ledger(tmp_path / "refs" / "台帳.xlsx")
    c = TestClient(W.app)
    c.W, c.tmp = W, tmp_path
    yield c
    with W._runs_lock:
        for k in [k for k, v in W._runs.items() if v.get("case")]:
            W._runs.pop(k, None)


def _send(client, uid, files):
    multipart = [("files", (Path(rel).name, data, "application/octet-stream")) for rel, data in files]
    return client.post(f"/api/uploads/{uid}/files", files=multipart,
                       data={"relative_paths": [rel for rel, _ in files]})


def _wait(client, rid, timeout=60):
    t = time.time()
    while time.time() - t < timeout:
        st = client.get(f"/api/runs/{rid}").json()
        if st["state"] in ("done", "failed", "cancelled"):
            return st
        time.sleep(0.3)
    raise AssertionError("timeout")


def test_api_detect_by_paths(client):
    r = client.post("/api/cases/detect", json={"paths": RELS}).json()
    assert {c["name"] for c in r["cases"]} == {"アルミ外材コート層硬さ試験", "2023-046_熱解析",
                                                "光学フィルム透過率評価"}
    assert client.get("/api/ui").json()["case_enabled"] is True


def test_api_detect_server_folder_is_server_side_only(client, tmp_path, monkeypatch):
    d = _case_folder(tmp_path)
    r = client.post("/api/cases/detect", json={"folder": str(d)}).json()
    assert r["cases"][0]["name"] == "アルミ外材コート層硬さ試験" and r["cases"][0]["file_count"] == 2
    monkeypatch.setattr(client.W, "_is_server_side", lambda request: False)
    assert client.post("/api/cases/detect", json={"folder": str(d)}).status_code == 403
    assert client.post("/api/cases", json={"folder": str(d)}).status_code == 403


def test_api_case_disabled(client, monkeypatch):
    monkeypatch.setattr(client.W.config.case, "enabled", False)
    assert client.post("/api/cases/detect", json={"paths": RELS}).status_code == 403
    assert client.get("/api/ui").json()["case_enabled"] is False


def test_api_upload_start_cases_end_to_end(client):
    uid = client.post("/api/uploads").json()["upload_id"]
    _send(client, uid, [
        ("2023年度/アルミ外材コート層硬さ試験/報告書.md", "# 報告\n\n硬さ 512 HV。".encode()),
        ("2023年度/アルミ外材コート層硬さ試験/速報/速報2.md", "# 速報\n\n硬さ 509 HV。".encode()),
        ("2023年度/2023-046_熱解析/結果.md", "# 結果\n\n最高温度 68.3 degC。".encode()),
        ("2023年度/一覧メモ.md", "# メモ".encode()),
    ])
    det = client.post("/api/cases/detect", json={"paths": [
        "2023年度/アルミ外材コート層硬さ試験/報告書.md", "2023年度/2023-046_熱解析/結果.md"]}).json()
    key = {c["name"]: c["key"] for c in det["cases"]}["アルミ外材コート層硬さ試験"]
    body = client.post(f"/api/uploads/{uid}/start_cases", json={"case_keys": [key]}).json()
    assert body["source"] == "cases" and body["total"] == 1            # 選んだ案件だけ
    batch = client.get(f"/api/batches/{body['batch_id']}").json()
    item = batch["items"][0]
    assert item["case"] and item["file_count"] == 2 and item["rel"] == "アルミ外材コート層硬さ試験"

    st = _wait(client, item["run_id"])
    assert st["state"] == "done", st.get("error")
    assert st["case"] and st["case_progress"]["phase"] == "done"
    assert [m["rel_in_case"] for m in st["case_progress"]["members"]] == ["報告書.md", "速報/速報2.md"]
    md = client.get(f"/api/runs/{item['run_id']}/markdown")
    assert md.status_code == 200
    # 案件は単発の履歴に混ざらない（一括処理の中に出る）
    assert item["run_id"] not in [r["run_id"] for r in client.get("/api/runs?scope=single").json()]
    # 台帳（案件台帳）にも 1 行
    rows = client.get("/api/ledger").json()
    rows = rows.get("rows", rows) if isinstance(rows, dict) else rows
    assert any(r.get("run_id") == item["run_id"] for r in rows)

    # 確認・編集画面と、一括処理としての書面出力（案件ごとの ZIP を含む）
    assert client.get(f"/api/runs/{item['run_id']}/review").status_code == 200
    assert client.get(f"/api/batches/{body['batch_id']}/export.pdf").status_code == 200
    z = client.get(f"/api/batches/{body['batch_id']}/export.docx", params={"mode": "separate"})
    assert z.status_code == 200 and z.content[:2] == b"PK"

    # 削除すると、他の案件が使っていない資料の読み取り結果も消える
    mroot = client.tmp / "out" / "case_members"
    assert len(list(mroot.iterdir())) == 2
    r = client.delete(f"/api/runs/{item['run_id']}").json()
    assert r["removed"]["case_members"] == 2 and not list(mroot.iterdir())


def test_status_shows_member_progress_while_reading(client):
    """資料を読んでいる間は、その資料の進捗（status.json）をそのまま返す。"""
    from app.observability import RunStore
    W = client.W
    cdir = client.tmp / "out" / "runs" / "case_x"
    mdir = client.tmp / "out" / "case_members" / "m_1"
    RunStore(mdir).event("extract_text_evidence", "running", "3/9")
    RunStore(cdir).save_json(CF.PROGRESS_FILE, {"phase": "reading", "current": 0, "members": [
        {"rel_in_case": "a.pdf", "name": "a.pdf", "state": "running", "run_dir": str(mdir)}]})
    with W._runs_lock:
        W._runs["case_x"] = {"run_id": "case_x", "input_name": "X", "state": "running",
                             "case": True, "run_dir": str(cdir), "created": time.time()}
    st = client.get("/api/runs/case_x").json()
    assert st["case"] and st["case_progress"]["phase"] == "reading"
    assert st["progress"]["current_node"] == "extract_text_evidence"


def test_frontend_case_button():
    html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
    for needle in ('id="pick-case"', 'id="case-dir"', "/api/cases/detect", "start_cases",
                   "renderCaseProgress", "merge_case", "案件フォルダとして要約"):
        assert needle in html
