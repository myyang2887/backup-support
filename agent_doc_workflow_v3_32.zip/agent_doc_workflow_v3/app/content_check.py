"""
要約の中身の検査（v3.32）— 形式が正しいことと、中身が正しいことを分けて見る。

v3.31 の品質レポートは JSON の形式チェックが通れば「ok」で、項目が埋まって
いれば充足率 100% と出ていた。根拠情報の欄に存在しない証拠 ID が 110 件中
25 件あっても、画像の読み違いがそのまま本文に入っていても、ok のままだった。

ここでは規則で確かめられる事だけを見る（LLM は使わない）。

1. 根拠情報の証拠 ID が実在するか
   - 案件では資料の接頭辞（f01_ など）が抜けた ID がよく出る。接頭辞を付けると
     ちょうど 1 件に当たる場合だけ直し、それ以外は根拠情報から外して記録する
2. 画像の読み違いと判断して外した表記が、本文に入っていないか
   - 案件では、別の資料の原文にその表記があれば正しい記述とみなす
3. 案件では、すべての資料が「資料ごとの分析」に出ているか

結果は validation["content_status"]（問題なし / 要確認）と
validation["content_issues"] に入れる。形式の ok とは別に表示する。
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

from .deep_read import normalize_text

STATUS_OK = "問題なし"
STATUS_REVIEW = "要確認"

_PREFIX_RE = re.compile(r"^f\d{2}_")


def _squeeze(text: str) -> str:
    return re.sub(r"\s+", "", normalize_text(text))


def _read(p: str) -> str:
    try:
        return Path(p).read_text(encoding="utf-8", errors="ignore") if p else ""
    except OSError:
        return ""


def _load(p: Path) -> Any:
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def fix_evidence_ids(cited: List[str], valid: List[str]) -> Tuple[List[str], List[Dict[str, str]], List[str]]:
    """根拠情報の証拠 ID を確かめる。

    戻り値: (直した後の一覧, 直した物 [{from, to}], 外した物)
    """
    valid_set = set(valid)
    by_suffix: Dict[str, List[str]] = {}
    for v in valid:
        if _PREFIX_RE.match(v):
            by_suffix.setdefault(v[4:], []).append(v)
    out: List[str] = []
    fixed: List[Dict[str, str]] = []
    removed: List[str] = []
    for raw in cited or []:
        cid = str(raw).strip().strip("[]()「」『』\"'")
        if not cid:
            continue
        if cid in valid_set:
            if cid not in out:
                out.append(cid)
            continue
        cands = by_suffix.get(_PREFIX_RE.sub("", cid), [])
        if len(cands) == 1:
            if cands[0] not in out:
                out.append(cands[0])
            fixed.append({"from": cid, "to": cands[0]})
        else:
            removed.append(cid)
    return out, fixed, removed


def _flagged_by_source(state: Dict[str, Any]) -> List[Tuple[str, str, str]]:
    """(表記, 資料名, その資料以外の原文) の一覧。単発 run は資料名・他の原文が空。"""
    out: List[Tuple[str, str, str]] = []
    if state.get("case_mode"):
        members = [m for m in (state.get("case") or {}).get("members", []) if m.get("state") == "done"]
        sources = {m["rel_in_case"]: _read(m.get("markdown_path", "")) for m in members}
        for m in members:
            rep = _load(Path(m["run_dir"]) / "page_report.json") or {}
            others = "\n".join(t for f, t in sources.items() if f != m["rel_in_case"])
            for r in rep.get("removed") or []:
                for x in r.get("flagged") or []:
                    out.append((x, m["rel_in_case"], others))
    else:
        for r in (state.get("page_report") or {}).get("removed") or []:
            for x in r.get("flagged") or []:
                out.append((x, "", ""))
    return out


def run_content_checks(state: Dict[str, Any], summary: Dict[str, Any]) -> Dict[str, Any]:
    """中身の検査。summary["evidence"] はその場で直す（直した内容は戻り値に残す）。"""
    issues: List[str] = []
    result: Dict[str, Any] = {}

    # ---- 1. 証拠 ID ----
    valid = [str(e.get("evidence_id", "")) for e in state.get("aggregated_evidence", []) or []]
    valid += [str(v.get("evidence_id", "")) for v in state.get("visual_evidence", []) or []]
    if not state.get("case_mode"):
        # 単発では断片の ID（text_chunk_0003 など）を挙げるモデルもある。実在する断片なので有効とする
        valid += [str(e.get("chunk_id", "")) for e in state.get("aggregated_evidence", []) or []]
    valid = [v for v in valid if v]
    if isinstance(summary.get("evidence"), list):
        cited = [str(x) for x in summary["evidence"]]
        ids, fixed, removed = fix_evidence_ids(cited, valid)
        summary["evidence"] = ids
        result["evidence_ids"] = {"cited": len(cited), "valid": len(ids),
                                  "fixed": fixed[:50], "removed": removed[:50]}
        if removed:
            issues.append(f"根拠情報に、実在しない証拠 ID が {len(removed)} 件ありました（{len(cited)} 件中）。"
                          f"根拠情報から外しています")
        if fixed:
            result["evidence_ids"]["note"] = f"資料の接頭辞が抜けた ID を {len(fixed)} 件直しました"

    # ---- 2. 外した読み取りが本文に入っていないか ----
    body = dict(summary)
    body.pop("evidence", None)
    text = _squeeze(json.dumps(body, ensure_ascii=False))
    leaked: List[str] = []
    for x, fname, others in _flagged_by_source(state):
        key = _squeeze(x)
        if len(key) < 2 or key not in text:
            continue
        if others and key in _squeeze(others):
            continue          # 別の資料の原文にある表記なので、読み違いとは限らない
        label = f"{x}（{fname}）" if fname else x
        if label not in leaked:
            leaked.append(label)
    if leaked:
        result["flagged_in_body"] = leaked[:30]
        issues.append("画像の読み違いと判断した表記が本文に入っています（"
                      + "、".join(leaked[:5]) + "）。原文で確認してください")

    # ---- 3. 案件：すべての資料が「資料ごとの分析」にあるか ----
    if state.get("case_mode"):
        from .case_analysis import files_in_findings, findings_path, get_path, match_file

        files = [m["rel_in_case"] for m in (state.get("case") or {}).get("members", [])
                 if m.get("state") == "done"]
        path = findings_path(summary)
        findings = [str(x) for x in (get_path(summary, path) if path else []) or []]
        named = files_in_findings(findings)
        if named or any(f.startswith(("【資料間】", "【結論】")) for f in findings):
            covered = {match_file(n, files) for n in named}
            missing = [f for f in files if f not in covered]
            result["files_missing_in_findings"] = missing
            if missing:
                issues.append("「資料ごとの分析」に出てこない資料があります（"
                              + "、".join(f"『{f}』" for f in missing[:5]) + "）")
        elif len(files) > 0 and path:
            issues.append("「判明した事実」を資料ごと・資料間・結論に書き分けられませんでした")

    result["content_status"] = STATUS_REVIEW if issues else STATUS_OK
    result["content_issues"] = issues
    return result
