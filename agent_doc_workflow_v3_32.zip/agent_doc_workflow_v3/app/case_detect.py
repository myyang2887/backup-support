"""
案件フォルダの切り出し（v3.31）。

「案件フォルダとして要約」では、1 つのフォルダを 1 案件として、配下の資料を
まとめて 1 つの要約にする。どのフォルダが 1 案件かは **参照台帳との照合で決める**：
フォルダ名が台帳のどこかの行に当たれば、そのフォルダが案件。何階層目でも
（いちばん外側でも）よい。

規則（すべてコードで決める。LLM は使わない）：

  1. 各ファイルは、照合に成功した祖先フォルダのうち **いちばん近い物** に属する。
     ただしその照合が「要確認」で、もっと外側に「確定」の照合があり、しかも
     別の行を指している場合は、確定の方を採る（弱い当たりで案件を割らない）。
  2. 同じ台帳行に当たったフォルダは 1 つの案件にまとめる
     （「速報」と「報告書」が別フォルダでも、同じ依頼なら 1 案件）。
  3. どの祖先フォルダも当たらないファイルは「どの案件にも属さない」として
     一覧に出し、勝手には処理しない。
  4. 台帳が未登録、または 1 件も当たらない場合に限り、選んだフォルダ
     （最上位）を 1 案件とみなす案を出す（「台帳未照合」と明示する）。

ここは入力として **相対パスの一覧だけ** を受け取る。ファイルの中身は要らないので、
ブラウザからのアップロードでは送信前に結果を見せられる。
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .reference_index import MatchResult, ReferenceIndex

# 一覧に出す台帳行の列数（全列はレビュー画面で見る）
_ROW_PREVIEW_CELLS = 6


# ----------------------------------------------------------------------
# 台帳の索引
# ----------------------------------------------------------------------

def reference_paths(config: Any, extra: Optional[Iterable[str]] = None) -> List[str]:
    """照合に使う台帳の置き場所（lookup_reference と同じ規則）。"""
    from .config import PROJECT_ROOT

    paths = [p for p in (extra or []) if p]
    wf = config.workflow
    lib = getattr(wf, "reference_library_dir", "")
    if lib:
        lib_path = Path(lib)
        if not lib_path.is_absolute():
            lib_path = PROJECT_ROOT / lib_path
        if lib_path.is_dir():
            paths.append(str(lib_path))
    return paths


def load_index(config: Any, extra: Optional[Iterable[str]] = None) -> Optional[ReferenceIndex]:
    """台帳の索引。台帳照合が無効、または 1 冊も無ければ None。"""
    if not getattr(config.workflow, "reference_enabled", False):
        return None
    paths = reference_paths(config, extra)
    if not paths:
        return None
    from .reference_index import build_index, load_reference_specs

    spec = load_reference_specs().get(getattr(config.workflow, "reference_spec_id", "default"))
    idx = build_index(paths, spec=spec)
    return idx if idx.rows else None


# ----------------------------------------------------------------------
# パスの整理
# ----------------------------------------------------------------------

def _parts(rel: str) -> List[str]:
    return [p for p in str(rel or "").replace("\\", "/").split("/") if p not in ("", ".")]


def _ignored(parts: List[str]) -> bool:
    """scan_folder / アップロードと同じく、隠し・Office の一時ファイルは数えない。"""
    name = parts[-1]
    return (any(p.startswith(".") for p in parts[:-1])
            or name.startswith(".") or name.startswith("~$"))


def row_key(match: MatchResult) -> str:
    """台帳行の同一性（どの台帳の・どのシートの・何行目か）。案件の鍵になる。"""
    r = match.row
    raw = f"{r.source_file}#{r.sheet_name}#{r.row_number}" if r else ""
    return "row:" + hashlib.sha1(raw.encode("utf-8")).hexdigest()[:12]


def _row_preview(match: MatchResult) -> Dict[str, Any]:
    r = match.row
    if r is None:
        return {}
    cells = [{"head": h, "value": v} for h, v in r.nonempty()][:_ROW_PREVIEW_CELLS]
    return {"source": Path(r.source_file).name, "sheet": r.sheet_name,
            "row_number": r.row_number, "cells": cells}


def _match_info(match: Optional[MatchResult], folder: str = "") -> Dict[str, Any]:
    if match is None:
        return {"ok": False, "reason": "台帳と照合していません", "folder": folder}
    return {"ok": match.ok, "method": match.method,
            "confidence": round(float(match.confidence or 0.0), 3),
            "confirmed": bool(match.confirmed), "reason": match.reason,
            "folder": folder, "row": _row_preview(match)}


def safe_case_name(name: str, limit: int = 40) -> str:
    """run ディレクトリ名に使える形（Windows で使えない文字を除く）。"""
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(name or "")).strip().rstrip(". ")
    return (s or "case")[:limit]


# ----------------------------------------------------------------------
# 切り出し
# ----------------------------------------------------------------------

def detect_cases(rel_paths: Iterable[str], index: Optional[ReferenceIndex],
                 suffixes: Iterable[str], *, allow_partial: bool = True) -> Dict[str, Any]:
    """相対パスの一覧から案件を切り出す。

    戻り値：
      cases      … [{key, name, folders, files:[{rel, rel_in_case, name}], match, needs_review, notes}]
      unassigned … どの案件にも属さないファイル（相対パス）
      excluded   … 対象外の形式など [{rel, reason}]
      fallback   … 台帳で 1 件も決まらず、最上位フォルダを案件とみなした場合 True
    """
    sufs = {s.lower() for s in suffixes}
    files: List[Tuple[str, List[str]]] = []
    excluded: List[Dict[str, str]] = []
    seen: set = set()
    for raw in rel_paths:
        parts = _parts(raw)
        if not parts:
            continue
        rel = "/".join(parts)
        if rel in seen:
            continue
        seen.add(rel)
        if _ignored(parts):
            continue
        suf = Path(parts[-1]).suffix.lower()
        if suf not in sufs:
            excluded.append({"rel": rel, "reason": f"未対応の形式 {suf or '(拡張子なし)'}"})
            continue
        files.append((rel, parts))
    files.sort(key=lambda x: x[0])

    ledger = {"enabled": index is not None, "rows": len(index.rows) if index else 0}

    # ---- 1. 各フォルダを照合（同じフォルダは 1 回だけ）----
    matches: Dict[str, MatchResult] = {}

    def folder_match(path: str) -> MatchResult:
        if path not in matches:
            name = path.rsplit("/", 1)[-1]
            matches[path] = (index.match_folder(name, path, allow_partial=allow_partial)
                             if index is not None else MatchResult(ok=False))
        return matches[path]

    # ---- 2. 各ファイルを案件へ ----
    groups: Dict[str, Dict[str, Any]] = {}
    unassigned: List[str] = []
    for rel, parts in files:
        ancestors = ["/".join(parts[:k]) for k in range(len(parts) - 1, 0, -1)]  # 近い順
        hits = [(a, folder_match(a)) for a in ancestors] if index is not None else []
        hits = [(a, m) for a, m in hits if m.ok and m.row is not None]
        if not hits:
            unassigned.append(rel)
            continue
        folder, m = hits[0]
        if not m.confirmed:
            firm = next(((a, x) for a, x in hits[1:] if x.confirmed), None)
            if firm and row_key(firm[1]) != row_key(m):
                folder, m = firm
        key = row_key(m)
        g = groups.setdefault(key, {"key": key, "folders": set(), "files": [], "matches": {}})
        g["folders"].add(folder)
        g["matches"][folder] = m
        g["files"].append((rel, folder))

    cases: List[Dict[str, Any]] = []
    for key, g in groups.items():
        cases.append(_build_case(key, g["folders"], g["files"], g["matches"]))

    fallback = False
    message = ""
    if not cases:
        # ---- 4. 台帳で 1 件も決まらない：最上位フォルダを案件とみなす案 ----
        fallback = True
        if index is None:
            message = ("参照台帳が登録されていない（または照合が無効な）ため、"
                       "選んだフォルダ 1 つを 1 案件とみなします")
        else:
            message = ("台帳と照合できたフォルダが 1 つもありませんでした。"
                       "選んだフォルダ 1 つを 1 案件とみなします（台帳未照合）")
        tops: Dict[str, List[Tuple[str, str]]] = {}
        unassigned = []
        for rel, parts in files:
            if len(parts) < 2:
                unassigned.append(rel)       # 最上位に直接置かれたファイル
                continue
            tops.setdefault(parts[0], []).append((rel, parts[0]))
        for top, fl in sorted(tops.items()):
            c = _build_case("folder:" + top, {top}, fl, {})
            c["needs_review"] = True
            c["notes"].append("台帳未照合（台帳の情報は要約に入りません）")
            cases.append(c)

    cases.sort(key=lambda c: (c["folders"][0] if c["folders"] else c["name"]))
    return {"cases": cases, "unassigned": unassigned, "excluded": excluded,
            "fallback": fallback, "message": message, "ledger": ledger,
            "file_count": len(files)}


def _build_case(key: str, folders: set, files: List[Tuple[str, str]],
                matches: Dict[str, MatchResult]) -> Dict[str, Any]:
    # 入れ子のフォルダは外側だけを表示する（同じ行に当たった内側は含まれている）
    shown = sorted(f for f in folders
                   if not any(f != o and f.startswith(o + "/") for o in folders))
    multi = len(shown) > 1
    members = []
    for rel, folder in sorted(files):
        top = next((o for o in shown if rel == o or rel.startswith(o + "/")), folder)
        inner = rel[len(top) + 1:] if rel.startswith(top + "/") else rel
        base = top.rsplit("/", 1)[-1]
        members.append({"rel": rel, "name": rel.rsplit("/", 1)[-1],
                        "rel_in_case": f"{base}/{inner}" if multi else inner})
    # 代表の照合：確度が最も高い物（同点なら外側）
    best_folder, best = None, None
    for f in sorted(matches, key=lambda x: (x.count("/"), x)):
        m = matches[f]
        if best is None or float(m.confidence or 0) > float(best.confidence or 0):
            best_folder, best = f, m
    name = shown[0].rsplit("/", 1)[-1] if shown else key
    notes: List[str] = []
    if multi:
        notes.append(f"{len(shown)} つのフォルダが同じ台帳行に当たったため 1 案件にまとめました")
    needs_review = bool(best is not None and not best.confirmed)
    return {"key": key, "name": name, "folders": shown,
            "files": members, "file_count": len(members),
            "match": _match_info(best, best_folder or ""),
            "needs_review": needs_review, "notes": notes}
