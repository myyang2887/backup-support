"""
案件の三段構え（v3.32）— 資料ごとの分析 → 資料間の比較 → 「判明した事実」の欄。

## なぜ必要か

v3.31 の案件要約は、全資料の「抜き出した証拠」を 1 つの山にして要約モデルへ
渡していた。そのため

- 資料 1 件ずつの中身（何の資料で、どんな条件で何を測り、何と結論したか）を
  誰も整理しないまま、いきなり全体の要約を書かせていた
- 資料どうしの関係（版違いか、補い合うのか、同じ測定の別条件か）を比べる
  段が無かった
- 証拠の抽出で表が「測定データあり」のように丸められると、その先で
  数値を取り戻す手段が無かった

ここでは人が複数の資料を読むときと同じ順に分ける。

1. analyze_files  … 資料 1 件ごとに、**原文そのもの**（PDF・PowerPoint・Word は
   取り出した本文、Excel はセルの値）と、原文と照合済みの画像の読み取りを
   渡して整理させる。資料の種類は問わない。結果は資料の置き場にキャッシュする。
2. compare_files  … 1 で作った整理結果を並べて、関係・共通点・違いを出す。
   資料が 1 件なら飛ばす。
3. case_findings  … 1 と 2 から「調査・対応により判明した事実」の欄を書く。
   3 つの部分（資料ごとの分析／資料間の比較／案件としての結論）に分け、
   プログラムが目印を付けて 1 つの欄に入れる。テンプレートが目印で見出しを付ける。

数値は最後にコードで確かめる。どの資料の原文・画像の読み取りにも無い数値を含む
項目は、欄に入れない（理由は報告ファイルに残す）。
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field, ValidationError

from .config import AppConfig
from .contract import VisualEvidence, schema_skeleton
from .deep_read import report_prompt_block, unsupported_numbers
from .evidence import visual_to_pack

CASE_ANALYSIS_VERSION = "3.32"

#: 「判明した事実」の各項目の頭に付ける目印。テンプレートがこれで見出しを分ける。
TAG_FILE = "【資料別】"
TAG_COMPARE = "【資料間】"
TAG_CONCLUSION = "【結論】"
CONCLUSION_KINDS = ("資料の結論", "データから読み取れること", "未解決の点")

ANALYSIS_FILE = "file_analysis.json"
COMPARISON_FILE = "case_comparison.json"
FINDINGS_REPORT_FILE = "case_findings_report.json"


# ----------------------------------------------------------------------
# 出力の形（LLM との境界）
# ----------------------------------------------------------------------

class FileAnalysis(BaseModel):
    document_type: str = ""
    date_or_version: str = ""
    purpose: str = ""
    contents: List[str] = Field(default_factory=list)
    measurements: List[str] = Field(default_factory=list)
    conclusions: List[str] = Field(default_factory=list)
    limitations: List[str] = Field(default_factory=list)
    open_points: List[str] = Field(default_factory=list)


class CaseComparison(BaseModel):
    relations: List[str] = Field(default_factory=list)
    common: List[str] = Field(default_factory=list)
    added: List[str] = Field(default_factory=list)
    differences: List[str] = Field(default_factory=list)
    not_comparable: List[str] = Field(default_factory=list)
    case_conclusions: List[str] = Field(default_factory=list)
    unresolved: List[str] = Field(default_factory=list)


class FileFindings(BaseModel):
    file: str = ""
    points: List[str] = Field(default_factory=list)


class ConclusionItem(BaseModel):
    kind: str = ""
    text: str = ""


class CaseFindings(BaseModel):
    by_file: List[FileFindings] = Field(default_factory=list)
    comparison: List[str] = Field(default_factory=list)
    conclusions: List[ConclusionItem] = Field(default_factory=list)


# ----------------------------------------------------------------------
# プロンプト
# ----------------------------------------------------------------------

FILE_ANALYSIS_SYSTEM = """あなたは技術資料を読み、内容を正確に整理する担当です。
渡すのは、1 つの案件フォルダに入っている資料のうちの 1 件です。
この資料だけを読んで、何が書かれているかを整理してください。

JSON のみを出力してください。

各項目の書き方：
- document_type：資料の種類（測定結果の表、解析報告書、打ち合わせ資料、依頼書 など）。
- date_or_version：資料に書かれている日付・版。書かれていなければ空文字。
- purpose：この資料が何のために作られたか。資料から分からなければ空文字。
- contents：資料に書かれている内容を、まとまりごとに 1 項目ずつ。
- measurements：測定・解析の条件と結果。試料名（番号）・条件・測定項目・値・単位を、
  原文の表記のまま書く。1 項目には 1 つの試料、または 1 つの条件の結果をまとめる。
  表の行が多くても省略しない。値を丸めたり、別の単位に換算したりしない。
- conclusions：資料自身が述べている結論・判断。資料に書かれていない解釈は入れない。
- limitations：前提・条件の制約・注意書き。
- open_points：資料からは分からない点、検討中・未完了と書かれている点。

守ること：
- 資料に無いことを書かない。分からない項目は空にする（空文字・空配列）。
- 数値は原文にある物だけを使う。
- 「原文との照合」の注意書きがある場合は、それに従う。"""


COMPARE_SYSTEM = """あなたは複数の資料を突き合わせる担当です。
同じ案件フォルダに入っている資料を、1 件ずつ整理した結果を渡します。
資料どうしを比べて、関係・共通点・違いを整理してください。

JSON のみを出力してください。

各項目の書き方（資料名は『』で囲む）：
- relations：資料どうしの関係。「同じ測定の別条件」「速報と最終報告（版違い）」
  「測定データとその報告書」などを、内容から判断して書く。
- common：複数の資料に共通して書かれている事実と、それがどの資料にあるか。
- added：ある資料にだけ書かれている事実と、その資料名。
- differences：同じ事柄について値や結論が違う点。両方の値を資料名付きで書く。
  どちらが正しいかは決めない。
- not_comparable：試料・条件・単位が違うため、そのままでは比べられない点。
- case_conclusions：資料全体から言えること。資料に結論として書かれていることと、
  数値から直接読み取れることに限る。
- unresolved：資料をすべて読んでも分からない点、資料間で決着していない点。

守ること：
- 渡された整理結果に無いことを書かない。
- 数値は整理結果にある表記のまま使う。計算し直さない。"""


FINDINGS_SYSTEM = """あなたは案件の要約のうち「調査・対応により判明した事実」の欄を書く担当です。
この欄は次の 3 つの部分から成ります。

1. by_file（資料ごとの分析）
   資料 1 件ごとに、その資料から分かる事実を points に書く。file には資料名をそのまま書く。
   測定・解析の結果は、試料・条件・値・単位を省かずに書く。
   渡した資料はすべて取り上げる。
2. comparison（資料間の比較）
   資料どうしで共通する点・違う点・一方にしか無い点。値が違う場合は、両方の値を
   資料名付きで書く。資料が 1 件だけなら空配列にする。
3. conclusions（案件としての結論）
   kind は次の 3 つのどれかにする。
   - 資料の結論：資料に結論として書かれていること
   - データから読み取れること：数値から直接言えること（比較・傾向など）。資料に無い推測は書かない
   - 未解決の点：資料からは分からないこと、決着していないこと

JSON のみを出力してください。

守ること：
- 渡した材料に無い事実・数値を書かない。数値を計算し直さない。
- 1 項目は 1〜3 文。長くなってもよいので、必要なことは省略しない。
- 項目の頭に記号・番号・見出しを付けない（見出しはプログラムが付けます）。
- 「原文との照合」で本文に書かないよう指示された表記は使わない。"""


# ----------------------------------------------------------------------
# 材料づくり
# ----------------------------------------------------------------------

def _load(p: Path) -> Any:
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def _read(p: str) -> str:
    try:
        return Path(p).read_text(encoding="utf-8", errors="ignore") if p else ""
    except OSError:
        return ""


def member_visuals(mdir: Path) -> List[dict]:
    doc = _load(mdir / "evidence_visual_checked.json") or _load(mdir / "evidence_visual.json") or {}
    return doc.get("evidence", []) or []


def _visual_pack(vis: List[dict], readable_text_limit: int = 0) -> List[dict]:
    items = []
    for d in vis:
        try:
            items.append(VisualEvidence.model_validate(d))
        except ValidationError:
            continue
    return visual_to_pack(items, max_total_chars=0, readable_text_limit=readable_text_limit)


def _sheet_names(source: str) -> List[str]:
    return re.findall(r"^#{1,3}\s*シート\s*[:：]\s*(.+?)\s*$", source, re.M)


def member_material(member: Dict[str, Any], *, source_limit: int = 0,
                    readable_text_limit: int = 0) -> Dict[str, Any]:
    """資料 1 件分の分析材料。原文が長すぎる場合だけ、抜き出した証拠で代える。"""
    mdir = Path(member["run_dir"])
    source = _read(member.get("markdown_path", ""))
    report = _load(mdir / "page_report.json") or {}
    vis = _visual_pack(member_visuals(mdir), readable_text_limit)
    note = ""
    text_evidence: List[dict] = []
    if source_limit and len(source) > source_limit:
        text_evidence = [{"content": e.get("content", ""), "category": e.get("category", ""),
                          **({"page": e["page"]} if e.get("page") else {}),
                          **({"sheet_name": e["sheet_name"]} if e.get("sheet_name") else {})}
                         for e in ((_load(mdir / "evidence_aggregated.json") or {}).get("evidence") or [])
                         if (e.get("origin") or "text") != "reference"]
        note = (f"原文が長い（約 {len(source):,} 字）ため、原文の代わりに本文から抜き出した"
                f"証拠 {len(text_evidence)} 件を渡しています。")
        source = ""
    return {"file": member["rel_in_case"], "source": source, "visual": vis,
            "check_block": report_prompt_block(report) if report.get("version") == 2 else "",
            "text_evidence": text_evidence, "note": note,
            "sheets": _sheet_names(source) if source else []}


def material_key(mat: Dict[str, Any], model: str) -> str:
    h = hashlib.sha1()
    for part in (CASE_ANALYSIS_VERSION, model, mat["source"], mat["check_block"], mat["note"],
                 json.dumps(mat["visual"], ensure_ascii=False, sort_keys=True),
                 json.dumps(mat["text_evidence"], ensure_ascii=False, sort_keys=True),
                 json.dumps(FileAnalysis.model_json_schema(), sort_keys=True), FILE_ANALYSIS_SYSTEM):
        h.update(str(part).encode("utf-8"))
        h.update(b"\x00")
    return h.hexdigest()[:16]


def file_analysis_user(mat: Dict[str, Any], title: str = "") -> str:
    parts = [f"資料名：{mat['file']}"]
    if title:
        parts.append(f"資料の見出し：{title}")
    if mat["sheets"]:
        parts.append("シート：" + "、".join(mat["sheets"]))
    if mat["note"]:
        parts.append(mat["note"])
    if mat["source"]:
        parts += ["", "【原文】（文字として取り出せた本文。Excel はセルの値をシートごとの表にした物）",
                  mat["source"]]
    if mat["text_evidence"]:
        parts += ["", "【本文から抜き出した証拠】",
                  json.dumps(mat["text_evidence"], ensure_ascii=False, separators=(",", ":"))]
    if mat["visual"]:
        parts += ["", "【画像からの読み取り】（ページ・シートを画像にして読み取った物。"
                      "原文と照らし合わせ、合わない行は外してあります）",
                  json.dumps(mat["visual"], ensure_ascii=False, separators=(",", ":"))]
    if mat["check_block"]:
        parts += ["", mat["check_block"]]
    parts += ["", "次の形式の JSON で出力してください：",
              json.dumps(schema_skeleton(FileAnalysis.model_json_schema()), ensure_ascii=False)]
    return "\n".join(parts)


# ----------------------------------------------------------------------
# 目印付きの文字列 ⇔ 構造
# ----------------------------------------------------------------------

_LEAD_MARK = re.compile(r"^\s*(?:[-・*●■□◆◇▼▶︎>]+|\(?\d{1,2}[.)）]|[①-⑳])\s*")


def _clean(text: str) -> str:
    t = re.sub(r"\s+", " ", str(text or "")).strip()
    t = _LEAD_MARK.sub("", t)
    for tag in (TAG_FILE, TAG_COMPARE, TAG_CONCLUSION):
        if t.startswith(tag):
            t = t[len(tag):].strip()
    return t


def _norm_name(name: str) -> str:
    return re.sub(r"[\s『』「」\"'（）()]+", "", str(name or "")).lower()


def match_file(name: str, files: List[str]) -> str:
    """モデルが書いた資料名を、実際の資料名に当てる（拡張子なし・パス違いも許す）。"""
    key = _norm_name(name)
    if not key:
        return ""
    for f in files:
        if _norm_name(f) == key:
            return f
    for f in files:
        nf = _norm_name(f)
        stem = _norm_name(Path(f).stem)
        base = _norm_name(Path(f).name)
        if key in (stem, base) or (len(key) >= 4 and (key in nf or nf.endswith(key))):
            return f
    return ""


def findings_to_strings(by_file: List[Tuple[str, List[str]]], comparison: List[str],
                        conclusions: List[Tuple[str, str]]) -> List[str]:
    out: List[str] = []
    for f, points in by_file:
        for p in points:
            out.append(f"{TAG_FILE}『{f}』{p}")
    for c in comparison:
        out.append(f"{TAG_COMPARE}{c}")
    for kind, text in conclusions:
        out.append(f"{TAG_CONCLUSION}{kind}：{text}" if kind else f"{TAG_CONCLUSION}{text}")
    return out


def files_in_findings(findings: List[str]) -> List[str]:
    """「資料ごとの分析」に出てくる資料名（出てきた順）。"""
    seen: List[str] = []
    for item in findings or []:
        s = str(item)
        if s.startswith(TAG_FILE):
            m = re.match(r"『(.+?)』", s[len(TAG_FILE):])
            if m and m.group(1) not in seen:
                seen.append(m.group(1))
    return seen


# ----------------------------------------------------------------------
# 「判明した事実」の欄をどこに書くか
# ----------------------------------------------------------------------

_FINDINGS_CANDIDATES = (("action_results", "findings"), ("findings",), ("key_results",),
                        ("main_content",), ("key_points",))


def findings_path(summary: Dict[str, Any]) -> Optional[Tuple[str, ...]]:
    for path in _FINDINGS_CANDIDATES:
        node: Any = summary
        ok = True
        for k in path:
            if isinstance(node, dict) and k in node:
                node = node[k]
            else:
                ok = False
                break
        if ok and isinstance(node, list):
            return path
    return None


def get_path(summary: Dict[str, Any], path: Tuple[str, ...]) -> Any:
    node: Any = summary
    for k in path:
        node = node[k]
    return node


def set_path(summary: Dict[str, Any], path: Tuple[str, ...], value: Any) -> None:
    node: Any = summary
    for k in path[:-1]:
        node = node[k]
    node[path[-1]] = value


# ----------------------------------------------------------------------
# ノード
# ----------------------------------------------------------------------

def make_case_analysis_nodes(config: AppConfig, llm):
    from .nodes import _push_error, _save_json, _store, _update_status

    wf = config.workflow
    cc = config.case

    def _members(state) -> List[Dict[str, Any]]:
        return [m for m in (state.get("case") or {}).get("members", []) if m.get("state") == "done"]

    def _titles(state) -> Dict[str, str]:
        docs = ((state.get("case_meta") or {}).get("documents")) or []
        return {d.get("file", ""): d.get("document_title", "") for d in docs}

    # ------------------------------------------------------------------
    def analyze_files(state) -> Dict[str, Any]:
        members = _members(state)
        titles = _titles(state)
        _update_status(state, "analyze_files", peek=f"{len(members)} 件の資料を 1 件ずつ読んでいます…")
        store = _store(state)
        out: List[Dict[str, Any]] = []
        reused = 0
        for i, m in enumerate(members, 1):
            store.raise_if_cancelled()
            rel = m["rel_in_case"]
            mat = member_material(m, source_limit=int(cc.analysis_source_chars or 0),
                                  readable_text_limit=wf.visual_readable_text_limit)
            key = material_key(mat, config.llm.model)
            cache_p = Path(m["run_dir"]) / ANALYSIS_FILE
            cached = _load(cache_p) or {}
            if wf.resume and cached.get("key") == key and isinstance(cached.get("analysis"), dict):
                out.append({"file": rel, "analysis": cached["analysis"], "cached": True})
                reused += 1
                continue
            _update_status(state, "analyze_files", "running", f"{i}/{len(members)}",
                           peek=f"『{rel}』を読んでいます…")
            if not (mat["source"] or mat["visual"] or mat["text_evidence"]):
                out.append({"file": rel, "analysis": FileAnalysis().model_dump(), "empty": True})
                continue
            try:
                raw = llm.chat_json(system=FILE_ANALYSIS_SYSTEM,
                                    user=file_analysis_user(mat, titles.get(rel, "")),
                                    max_tokens=int(cc.analysis_max_tokens),
                                    json_schema=FileAnalysis.model_json_schema(),
                                    tag=f"case:analyze:{i:02d}", temperature=0.0)
                fa = FileAnalysis.model_validate(raw).model_dump()
            except Exception as e:  # noqa: BLE001 1 件の失敗で案件を止めない
                _push_error(state, "analyze_files",
                            f"資料『{rel}』の分析に失敗しました（この資料は抜き出した証拠だけで書きます）",
                            repr(e))
                out.append({"file": rel, "analysis": None, "failed": True})
                continue
            _save_json({"key": key, "version": CASE_ANALYSIS_VERSION, "file": rel,
                        "material": {"source_chars": len(mat["source"]), "visual": len(mat["visual"]),
                                     "text_evidence": len(mat["text_evidence"]), "note": mat["note"]},
                        "analysis": fa}, cache_p)
            out.append({"file": rel, "analysis": fa})
        _save_json({"files": out}, Path(state["run_dir"]) / "case_file_analyses.json")
        done = sum(1 for x in out if x.get("analysis"))
        _update_status(state, "analyze_files", "done",
                       f"{done}/{len(members)} 件" + (f"（前回の結果を使用 {reused} 件）" if reused else ""),
                       peek=f"{done} 件の資料を整理しました")
        return {"file_analyses": out, "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    def compare_files(state) -> Dict[str, Any]:
        analyses = [a for a in state.get("file_analyses") or [] if a.get("analysis")]
        run_dir = Path(state["run_dir"])
        if len(analyses) < 2:
            _update_status(state, "compare_files", "done", "資料が 1 件のため省略",
                           peek="比べる相手の資料が無いので、比較は省きました")
            return {"case_comparison": {}}
        _update_status(state, "compare_files", peek=f"{len(analyses)} 件の資料を突き合わせています…")
        titles = _titles(state)
        material = [{"file": a["file"], "title": titles.get(a["file"], ""), **a["analysis"]}
                    for a in analyses]
        user = ("同じ案件フォルダに入っている資料の整理結果です。\n\n"
                + json.dumps(material, ensure_ascii=False, separators=(",", ":"))
                + "\n\n次の形式の JSON で出力してください：\n"
                + json.dumps(schema_skeleton(CaseComparison.model_json_schema()), ensure_ascii=False))
        try:
            raw = llm.chat_json(system=COMPARE_SYSTEM, user=user,
                                max_tokens=int(cc.compare_max_tokens),
                                json_schema=CaseComparison.model_json_schema(),
                                tag="case:compare", temperature=0.0)
            comp = CaseComparison.model_validate(raw).model_dump()
        except Exception as e:  # noqa: BLE001
            _push_error(state, "compare_files", "資料間の比較に失敗しました（比較なしで続けます）", repr(e))
            comp = {}
        _save_json(comp, run_dir / COMPARISON_FILE)
        n = sum(len(v) for v in comp.values() if isinstance(v, list))
        _update_status(state, "compare_files", "done", f"{n} 項目",
                       peek=("資料どうしの関係と違いを整理しました" if n else "比較できる点が見つかりませんでした"))
        return {"case_comparison": comp, "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    def _source_blob(state) -> str:
        parts = [json.dumps(state.get("aggregated_evidence", []), ensure_ascii=False),
                 json.dumps(state.get("visual_evidence", []), ensure_ascii=False)]
        for m in _members(state):
            parts.append(_read(m.get("markdown_path", "")))
        return "\n".join(parts)

    def case_findings(state) -> Dict[str, Any]:
        summary = state.get("summary") or {}
        path = findings_path(summary)
        analyses = [a for a in state.get("file_analyses") or [] if a.get("analysis")]
        files = [m["rel_in_case"] for m in _members(state)]
        run_dir = Path(state["run_dir"])
        if path is None or not files:
            _update_status(state, "case_findings", "done", "対象の欄なし")
            return {}
        _update_status(state, "case_findings", peek="「判明した事実」の欄を資料ごと・資料間・結論に分けて書いています…")
        titles = _titles(state)
        draft = [str(x) for x in get_path(summary, path) or []]
        material = {
            "資料の一覧": [{"file": f, "title": titles.get(f, "")} for f in files],
            "資料ごとの分析": [{"file": a["file"], **a["analysis"]} for a in analyses],
            "資料間の比較": state.get("case_comparison") or {},
            "要約の下書きにある記述（参考）": draft,
        }
        check_block = state.get("case_page_block") or ""
        user = ("材料：\n" + json.dumps(material, ensure_ascii=False, separators=(",", ":"))
                + (("\n\n" + check_block) if check_block else "")
                + "\n\n次の形式の JSON で出力してください：\n"
                + json.dumps(schema_skeleton(CaseFindings.model_json_schema()), ensure_ascii=False))
        report: Dict[str, Any] = {"files": files, "removed": [], "filled_from_analysis": [], "llm_failed": False}
        try:
            raw = llm.chat_json(system=FINDINGS_SYSTEM, user=user,
                                max_tokens=int(cc.findings_max_tokens),
                                json_schema=CaseFindings.model_json_schema(),
                                tag="case:findings", temperature=0.0)
            cf = CaseFindings.model_validate(raw)
        except Exception as e:  # noqa: BLE001
            _push_error(state, "case_findings", "「判明した事実」の専用パスに失敗しました（分析結果から組み立てます）",
                        repr(e))
            cf = CaseFindings()
            report["llm_failed"] = True

        blob = _source_blob(state)

        def verified(items: List[str], where: str) -> List[str]:
            kept = []
            for it in items:
                t = _clean(it)
                if not t:
                    continue
                bad = unsupported_numbers(t, blob)
                if bad:
                    report["removed"].append({"where": where, "text": t,
                                              "numbers": [b["text"] for b in bad[:5]]})
                    continue
                kept.append(t)
            return kept

        by_file: Dict[str, List[str]] = {f: [] for f in files}
        for ff in cf.by_file:
            f = match_file(ff.file, files)
            if not f:
                report.setdefault("unknown_files", []).append(ff.file)
                continue
            by_file[f] += verified(ff.points, f)
        # モデルが取り上げなかった資料は、その資料の分析結果から補う
        amap = {a["file"]: a["analysis"] for a in analyses}
        for f in files:
            if by_file[f] or f not in amap:
                continue
            a = amap[f]
            pts = ([a["purpose"]] if a.get("purpose") else []) + list(a.get("measurements") or []) \
                + list(a.get("conclusions") or [])
            got = verified(pts, f)
            if got:
                by_file[f] = got
                report["filled_from_analysis"].append(f)

        comparison = verified(cf.comparison, "資料間の比較") if len(files) > 1 else []
        conclusions: List[Tuple[str, str]] = []
        for c in cf.conclusions:
            kind = c.kind.strip() if c.kind.strip() in CONCLUSION_KINDS else ""
            for t in verified([c.text], "案件としての結論"):
                conclusions.append((kind, t))
        order = {k: i for i, k in enumerate(CONCLUSION_KINDS)}
        conclusions.sort(key=lambda kc: order.get(kc[0], len(order)))

        items = findings_to_strings([(f, by_file[f]) for f in files if by_file[f]], comparison, conclusions)
        report["counts"] = {"by_file": sum(len(v) for v in by_file.values()),
                            "comparison": len(comparison), "conclusions": len(conclusions)}
        report["missing_files"] = [f for f in files if not by_file[f]]
        if items:
            set_path(summary, path, items)
            state["summary"] = summary
        else:
            report["kept_draft"] = True
        _save_json(report, run_dir / FINDINGS_REPORT_FILE)
        if report["removed"]:
            _push_error(state, "case_findings",
                        f"原文に無い数値を含む {len(report['removed'])} 項目を「判明した事実」に入れませんでした",
                        json.dumps(report["removed"][:5], ensure_ascii=False))
        c = report["counts"]
        _update_status(state, "case_findings", "done",
                       f"資料別 {c['by_file']}・資料間 {c['comparison']}・結論 {c['conclusions']}",
                       peek=("「判明した事実」を書き分けました" if items
                             else "書き分けられなかったため、要約の下書きのままにしました"))
        return {"summary": summary, "errors": state.get("errors", [])}

    return {"analyze_files": analyze_files, "compare_files": compare_files,
            "case_findings": case_findings}


def external_file_labels(summary: Dict[str, Any], files: List[str]) -> Dict[str, Any]:
    """社外版用：「判明した事実」の資料名（社内のファイル名）を「資料1」「資料2」…に置き換えた写し。"""
    import copy

    path = findings_path(summary)
    if path is None or not files:
        return summary
    out = copy.deepcopy(summary)
    label = {f: f"資料{i}" for i, f in enumerate(files, 1)}
    items = []
    for item in get_path(out, path) or []:
        s = str(item)
        for f, lab in label.items():
            s = s.replace(f"『{f}』", f"『{lab}』")
        items.append(s)
    set_path(out, path, items)
    return out


def analyses_prompt_block(state: Dict[str, Any]) -> str:
    """write_summary に渡す「資料ごとの分析」「資料間の比較」。"""
    analyses = [{"file": a["file"], **a["analysis"]}
                for a in state.get("file_analyses") or [] if a.get("analysis")]
    if not analyses:
        return ""
    out = ["資料ごとの分析（各資料の原文を 1 件ずつ読んで整理した物。証拠より詳しい場合はこちらを優先）：",
           json.dumps(analyses, ensure_ascii=False, separators=(",", ":"))]
    comp = state.get("case_comparison") or {}
    if any(comp.get(k) for k in comp):
        out += ["資料間の比較：", json.dumps(comp, ensure_ascii=False, separators=(",", ":"))]
    return "\n".join(out)
