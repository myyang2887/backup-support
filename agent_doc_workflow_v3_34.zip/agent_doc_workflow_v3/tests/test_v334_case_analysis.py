"""v3.34：数値を「どの行の、どの見出しの値か」まで確かめる／範囲ごとの分析／書き直しを減らす。

資料の形を決め打ちしないこと（複数段の見出し、自由に配置されたシート、図が主役のシート、
PDF のページ）と、弱いモデルが間違えたときに規則で止められることを確かめる。
"""
from __future__ import annotations

import json
from pathlib import Path

import openpyxl
import pytest

from app import case_analysis as CA
from app import case_detect as CD
from app import case_flow as CF
from app import table_index as T
from app.cell_format import cell_to_text

from tests.test_v332_source_check_and_case_layers import SUFS, _run, cfg  # noqa: F401（fixture）

# ----------------------------------------------------------------------
# 原文の索引
# ----------------------------------------------------------------------

TABLE = """## シート: 一覧

| 面 | 旧番号 | 試料 | 弾性率A(MPa) |  | 弾性率B(MPa) |
|---|---|---|---|---|---|
|  |  |  | 条件=0.3 | 条件=0.4 |  |
| 9 | - | 樹脂X | 3301.129875 | 3100.5 | 338.7872 |
| 12 | No.5 | 樹脂Y | 308.39 | 284.67 | 336.9086875 |

## シート: 条件

|  | 試験条件 |  |  |
|---|---|---|---|
|  | 最大荷重 | 1 | μN |
|  | 試験深度は 50〜1000 nm とした |  |  |
"""


def _cell(idx, raw):
    return [c for c in idx.cells if c.raw == raw][0]


def test_index_gives_each_value_its_row_and_headers():
    idx = T.build_index(TABLE)
    c = _cell(idx, "284.67")
    assert c.unit_name == "一覧" and c.labels() == ["No.5", "樹脂Y"]
    assert c.headers == ["条件=0.4", "弾性率A(MPa)"] and c.unit == "MPa"     # 結合された見出しを引き継ぐ
    assert _cell(idx, "336.9086875").headers == ["弾性率B(MPa)"]              # 下段が空の列は隣から引き継がない
    free = [c for c in idx.cells if c.unit_name == "条件" and c.kind == "table"][0]
    assert free.labels() == ["最大荷重", "μN"]                                # 表でない配置でも周りの文字を拾う
    assert idx.order[:2] == ["一覧", "条件"]


def test_units_for_pages_and_plain_text():
    assert [n for n, _ in T.source_units("## p.1\n本文\n## p.2\n本文\n")] == ["p.1", "p.2"]
    assert [n for n, _ in T.source_units("# ページ 3\n本文\n")] == ["p.3"]
    assert [n for n, _ in T.source_units("見出しの無い本文です。")] == [""]
    idx = T.build_index("## p.2\n\n| 試料 | 厚さ(mm) |\n|---|---|\n| A | 1.25 |\n\n荷重は 500 N とした。\n")
    assert _cell(idx, "1.25").unit == "mm" and _cell(idx, "500 N").kind == "text"


@pytest.mark.parametrize("rec,status,line", [
    (dict(sample="樹脂Y", item="弾性率A", condition="条件=0.3", value="308.39", unit="MPa"),
     "ok", "樹脂Y（条件=0.3）：弾性率A 308.39 MPa"),
    # 番号の取り違え：その行に No.5 は無い → 原文の行の表記に直す
    (dict(sample="樹脂X（No.5）", item="弾性率A", value=3301.129875, unit="MPa"),
     "corrected", "樹脂X：弾性率A 3301.129875 MPa"),
    # 項目の取り違え：値は弾性率A の列にある → 原文の見出しに直す
    (dict(sample="樹脂Y", item="弾性率B", value="308.39", unit="MPa"),
     "corrected", "樹脂Y：弾性率A(MPa) 条件=0.3 308.39 MPa"),
    # 条件の取り違え：その列は 条件=0.4
    (dict(sample="樹脂Y", item="弾性率A", condition="条件=0.3", value="284.67", unit="MPa"),
     "corrected", "樹脂Y（条件=0.4）：弾性率A 284.67 MPa"),
    # 表示の丸め
    (dict(sample="樹脂Y", item="弾性率A", value="308.4", unit="MPa"), "ok", "樹脂Y：弾性率A 308.4 MPa"),
    # 文の中の値で項目名が違う → 原文の文をそのまま使う
    (dict(sample="", item="膜厚", value="1000 nm"), "corrected", "試験深度は 50〜1000 nm とした"),
    (dict(sample="樹脂Y", item="弾性率A", value="999.9", unit="MPa"), "missing", None),
    (dict(sample="樹脂Y", item="外観", value="良好"), "text", None),
])
def test_verify_record(rec, status, line):
    out = T.verify_record(rec, T.build_index(TABLE))
    assert out["status"] == status
    if line:
        assert T.record_line(out) == line


def test_value_only_in_figure_reading_is_marked_as_figure():
    out = T.verify_record(dict(sample="", item="先端角", value="65.27°"), T.build_index(TABLE),
                          figure_text="圧子形状 先端角 65.27°")
    assert out["status"] == "figure" and T.record_line(out).endswith("（図から読み取り）")


@pytest.mark.parametrize("text,bad", [
    ("樹脂Yの弾性率Bは 308.39 MPa であった。", True),                       # 項目が違う
    ("樹脂Xは、弾性率Aが 308.39 MPa。", True),                             # 試料が違う
    ("樹脂Yの弾性率Aは 条件=0.3 で 284.67 MPa。", True),                    # 条件が違う
    ("弾性率Bは 条件=0.3 で 308.39 MPa。", True),
    ("樹脂X（No.5）の弾性率Aは約 3301 MPa。", True),                        # 番号が違う
    ("樹脂Yは弾性率Aが 条件=0.3 で 308.39 MPa、条件=0.4 で 284.67 MPa、弾性率Bは約 336.9 MPa。", False),
    ("樹脂Yは 樹脂Xより低く、弾性率Aは 308.39 MPa であった。", False),       # 比べる相手の名前は許す
    ("弾性率Aは弾性率Bより大きく、樹脂Xで約 3301 MPa。", False),
    ("面 12 の弾性率Aは 条件=0.3 のとき約 308.39 MPa。", False),
    ("図から読み取った先端角は 65.27° である。", False),                     # 表に無い値は判断しない
])
def test_check_statement(text, bad):
    assert bool(T.check_statement(text, T.build_index(TABLE))) is bad


def test_column_stats_cover_all_rows_without_a_model():
    rows = "".join(f"| S-{i} | {100 + i} | {2.0 + i / 1000:.3f} |\n" for i in range(500))
    idx = T.build_index("## シート: 走査\n\n| 試料 | 深さ(nm) | 硬さ(GPa) |\n|---|---|---|\n" + rows)
    st = {s["item"]: s for s in T.column_stats(idx, "走査")}
    assert st["硬さ(GPa)"]["count"] == 500 and st["硬さ(GPa)"]["min"] == {"value": "2.000", "row": "S-0"}
    assert st["硬さ(GPa)"]["max"]["row"] == "S-499" and st["深さ(nm)"]["unit"] == "nm"


def test_float_noise_is_removed_at_the_source():
    assert cell_to_text(338.78720000000004) == "338.7872"
    assert cell_to_text(0.1 + 0.2) == "0.3" and cell_to_text(2.0) == "2" and cell_to_text(3301.129875) == "3301.129875"


def test_cross_file_base_and_only_claims():
    other = TABLE.replace("樹脂Y", "樹脂Z").replace("3100.5", "3100.9")
    idx = {"a.xlsx": T.build_index(TABLE), "b.xlsx": T.build_index(other)}
    base = T.cross_file_base(idx, {"a.xlsx": TABLE, "b.xlsx": other})
    assert {"label": "樹脂X", "files": ["a.xlsx", "b.xlsx"]} in base["labels_in_several_files"]
    assert base["labels_in_one_file"]["a.xlsx"] == ["樹脂Y"]
    assert base["same_values"][0]["count"] == 2 and base["different_values"][0]["count"] == 1
    p = base["_presence"]
    assert T.only_claim_problem("樹脂Xのデータは『a.xlsx』にのみある", ["a.xlsx"], p) == "樹脂x"
    assert T.only_claim_problem("樹脂Yのデータは『a.xlsx』にのみある", ["a.xlsx"], p) == ""
    assert T.only_claim_problem("樹脂Xは『a.xlsx』と『b.xlsx』にある", ["a.xlsx", "b.xlsx"], p) == ""


# ----------------------------------------------------------------------
# 範囲の分け方
# ----------------------------------------------------------------------

def test_build_units_keeps_big_ranges_apart_and_attaches_visuals():
    big = "## シート: 走査\n\n| 深さ | 硬さ |\n|---|---|\n" + "".join(f"| {i} | {i / 7:.3f} |\n" for i in range(900))
    src = big + "\n## シート: 一覧\n\n| 試料 | 値 |\n|---|---|\n| A | 1.5 |\n\n## シート: 図\n\n| 解析結果の図 |\n|---|\n"
    vis = [{"evidence_id": "v1", "sheet_name": "図", "readable_text": ["応力分布"]},
           {"evidence_id": "v2", "sheet_name": "一覧", "readable_text": ["A 1.5"]},
           {"evidence_id": "v3", "readable_text": ["どのシートか分からない画像"]}]
    units = CA.build_units(src, vis, merge_chars=2000)
    assert [u["names"] for u in units] == [["走査"], ["一覧", "図"], [CA.FIGURE_UNIT]]
    assert [v["evidence_id"] for v in units[1]["visual"]] == ["v2", "v1"]
    shown, info = CA.shown_text(units[0]["text"], 60, 30000)
    assert info["tables_cut"] == 1 and "全 900 行" in shown and shown.count("\n") < 80


def test_build_units_for_pages_and_image_only_documents():
    src = "## p.1\n" + "本文" * 30 + "\n## p.2\n" + "本文" * 30 + "\n"
    units = CA.build_units(src, [{"evidence_id": "p2", "page": 2, "readable_text": ["図"]}], merge_chars=10)
    assert [u["names"] for u in units] == [["p.1"], ["p.2"]] and units[1]["visual"]
    only_img = CA.build_units("", [{"evidence_id": "s", "readable_text": ["スキャン"]}])
    assert [u["names"] for u in only_img] == [[CA.FIGURE_UNIT]]
    assert CA.unit_label("p.2") == "2ページ" and CA.unit_label("一覧") == "シート「一覧」" and CA.unit_label("") == "資料全体"


def test_coerce_unit_accepts_other_shapes():
    ua, rep = CA.coerce_unit({"summary": ["表"], "records": [
        {"試料": "A", "項目": "硬さ", "値": 2.31, "単位": "GPa"},
        {"試料": "B", "硬さ": 2.4, "弾性率": 45},
        "C の硬さは 2.5 GPa"], "notes": "前提1\n前提2"})
    assert [(r.sample, r.item, r.value) for r in ua.highlights] == [
        ("A", "硬さ", "2.31"), ("B", "硬さ", "2.4"), ("B", "弾性率", "45")]
    assert ua.notes == ["前提1", "前提2", "C の硬さは 2.5 GPa"] and ua.summary == "表"
    cx, _ = CA.coerce_conclusions({"資料の結論": ["a"], "未解決の点": "b"})
    assert [(c.kind, c.text) for c in cx.conclusions] == [("資料の結論", "a"), ("未解決の点", "b")]
    cx, _ = CA.coerce_conclusions(["c"])
    assert cx.conclusions[0].text == "c"


# ----------------------------------------------------------------------
# 案件を通して
# ----------------------------------------------------------------------

def _book(path: Path, *, long: bool, extra=None):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "走査"
    ws.append(["深さ(nm)", "硬さ(GPa)"])
    for i in range(300 if long else 3):
        ws.append([50 + i * 5, round(2.0 + i * 0.001, 4)])
    ws2 = wb.create_sheet("一覧")
    ws2.append(["面", "旧番号", "試料", "弾性率A(MPa)", None, "弾性率B(MPa)"])
    ws2.append([None, None, None, "条件=0.3", "条件=0.4", None])
    ws2.append([9, "-", "樹脂X", 3301.129875, 3100.5, 338.78720000000004])
    ws2.append([12, "No.5", "樹脂Y", 308.39, 284.67, 336.90868750000004])
    if extra:
        ws2.append(extra)
    ws3 = wb.create_sheet("条件")
    ws3["B2"] = "試験条件"
    ws3["B4"] = "最大荷重"
    ws3["C4"] = 1
    ws3["D4"] = "μN"
    ws3["B6"] = "試料は接着剤で固定した。値は固定方法の影響を受ける。"
    wb.save(path)


def _case(cfg, root: Path, build) -> dict:
    d = root / "src" / "アルミ外材コート層硬さ試験"
    d.mkdir(parents=True)
    build(d)
    rels = {p.relative_to(d.parent).as_posix(): str(p) for p in d.rglob("*") if p.is_file()}
    det = CD.detect_cases(list(rels), CD.load_index(cfg), SUFS)
    c = det["cases"][0]
    return {"key": c["key"], "name": c["name"], "folders": c["folders"], "match": c["match"],
            "members": [{"rel": f["rel"], "rel_in_case": f["rel_in_case"], "name": f["name"],
                         "path": rels[f["rel"]]} for f in c["files"]]}


def _two_books(d: Path):
    _book(d / "速報.xlsx", long=True)
    _book(d / "報告.xlsx", long=False, extra=[13, "-", "樹脂W", 1200.5, 1100.25, 400.125])


class Mock:
    """案件の 4 種類の呼び出しにだけ答え、他は既定のモックに任せる。"""

    STAGES = (("unit", "1 件の資料の一部"), ("file", "読み手が判断に使える形"),
              ("compare", "突き合わせる担当"), ("conclusion", "「案件としての結論」を書く担当"))

    def __init__(self, cfg, **answers):
        from app.llm_client import LocalLLMClient
        self.inner = LocalLLMClient(**cfg.llm.model_dump(exclude={"vision"}))
        self.metrics_hook = None
        self.calls = []
        self.answers = answers

    def chat_json(self, **kw):
        for stage, mark in self.STAGES:
            if mark in kw["system"]:
                self.calls.append({"stage": stage, **kw})
                ans = self.answers.get(stage)
                if ans is None:
                    return {}
                out = ans(kw) if callable(ans) else ans
                if isinstance(out, Exception):
                    raise out
                return out
        return self.inner.chat_json(**kw)

    def of(self, stage):
        return [c for c in self.calls if c["stage"] == stage]

    def __getattr__(self, name):
        return getattr(self.inner, name)


GOOD_UNIT = {"summary": "試料ごとの弾性率の表。",
             "highlights": [{"sample": "樹脂X（No.5）", "condition": "条件=0.3", "item": "弾性率A",
                             "value": 3301.129875, "unit": "MPa"},
                            {"sample": "樹脂Y", "item": "弾性率A", "value": 999.9, "unit": "MPa"}],
             "notes": ["試料は接着剤で固定した。値は固定方法の影響を受ける。"], "figures": []}
GOOD_FILE = {"document_type": "測定結果の表",
             "points": ["樹脂Yの弾性率Aは 条件=0.3 で約 308.4 MPa、条件=0.4 で約 284.7 MPa で、条件の仮定で値が変わる。",
                        "樹脂Xの弾性率Aは 条件=0.3 で約 3301 MPa と、樹脂Yより一桁大きい。"],
             "conclusions": [], "limitations": ["試料は接着剤で固定した。値は固定方法の影響を受ける。"],
             "open_points": []}


def _section(cdir: Path) -> str:
    md = (cdir / "case_summary.md").read_text(encoding="utf-8")
    return md[md.index("## 調査"):md.index("## 対応効果")]


def test_case_end_to_end(cfg, tmp_path):
    case = _case(cfg, tmp_path, _two_books)

    def file_answer(kw):
        if "前回の出力について" in kw["user"]:
            return GOOD_FILE
        bad = dict(GOOD_FILE)
        bad["points"] = ["樹脂Yの弾性率Bは 308.39 MPa であった。",              # 項目の取り違え
                         GOOD_FILE["points"][1],
                         "复合弹性率は 336.9 MPa。"]                             # 資料に無い文字
        return bad

    llm = Mock(cfg, unit=GOOD_UNIT, file=file_answer,
               compare={"relations": ["『速報.xlsx』は速報、『報告.xlsx』はその後の報告で、樹脂Wの測定が加わっている。"],
                        "common": ["樹脂X・樹脂Yの弾性率は、両方の資料に同じ値で載っている。"],
                        "added": ["樹脂Xのデータは『速報.xlsx』にのみある。", "樹脂Wは『報告.xlsx』にだけある。"],
                        "differences": ["弾性率Bは『速報.xlsx』338.7872 MPa、『報告.xlsx』338.7872 MPa。"]},
               conclusion={"conclusions": [
                   {"kind": "データから読み取れること",
                    "text": "樹脂Yの弾性率Aは 条件=0.3 で約 308.4 MPa、条件=0.4 で約 284.7 MPa で、判断は条件の仮定で変わる。"},
                   {"kind": "データから読み取れること", "text": "樹脂Yの弾性率Bは 条件=0.3 で 308.39 MPa。"}]})
    cdir = _run(cfg, case, llm)

    # 長い表は先頭だけを見せ、全行の集計をプログラムが渡す（入力が表の行数に比例しない）
    big = [c for c in llm.of("unit") if "速報.xlsx" in c["user"] and "シート「走査」" in c["user"].split("【原文】")[0]][0]
    assert "全 300 行" in big["user"] and "硬さ(GPa)：300 件、最小 2、最大 2.299" in big["user"]
    assert len(big["user"]) < 12000
    # 端数は原文の段階で落ちている
    assert "338.78720000000004" not in "".join(c["user"] for c in llm.calls)

    fa = {f["file"]: f for f in json.loads((cdir / "case_file_analyses.json").read_text(encoding="utf-8"))["files"]}
    sokuho = fa["速報.xlsx"]
    assert sokuho["status"] == "ok" and sokuho["corrected"] >= 1          # No.5 の取り違えを直した
    assert {r["reason"] for r in sokuho["removed"]} == set()              # 書き直しで直った
    saved = json.loads((Path(cfg.paths.out_dir) / "case_members").glob("速報_*/file_analysis.json").__next__()
                       .read_text(encoding="utf-8"))
    hl = [h for u in saved["units"] for h in u.get("highlights", [])]
    assert all(h["sample"] != "樹脂X（No.5）" for h in hl) and all(h.get("number") != 999.9 for h in hl)
    assert any(d.get("record", "").startswith("樹脂Y：弾性率A 999.9") for u in saved["units"] for d in u["dropped"])
    # 分析に出てこなかった表（長い走査の表）は、集計から 1 項目を足す
    assert "シート「走査」" in sokuho["coverage"]["auto_added"]

    sec = _section(cdir)
    assert "シート「走査」：深さは 50〜1545 nm（300 件）、硬さは 2〜2.299 GPa（300 件）。" in sec
    assert "复" not in sec and "弾性率Bは 308.39" not in sec
    # 資料ごとの分析は、その資料の分析をそのまま使う（結論の段で書き直さない）
    for p in GOOD_FILE["points"]:
        assert sec.count(p) == 2
    assert "by_file" not in llm.of("conclusion")[0]["user"]
    # 比較：他の資料にもある物を「〜にのみ」と書いた記述、同じ値どうしの「違い」は外す
    assert "樹脂Xのデータは『速報.xlsx』にのみある" not in sec and "一方にだけある内容：樹脂Wは『報告.xlsx』にだけある。" in sec
    assert "338.7872 MPa、『報告.xlsx』338.7872" not in sec
    assert "【原文から機械的に拾った対応】" in llm.of("compare")[0]["user"]
    # 結論：対応の合わない項目は外し、資料に書かれた前提はプログラムが必ず足す
    assert "弾性率Bは 条件=0.3 で 308.39" not in sec
    assert sec.index("データから読み取れること：樹脂Yの弾性率Aは") < sec.index("前提・制約：『")
    assert "値は固定方法の影響を受ける" in sec[sec.index("■ 案件としての結論"):]

    q = json.loads((cdir / "quality_report.json").read_text(encoding="utf-8"))
    assert q["content_status"] == "要確認"
    assert any("「この資料にだけある」とした記述が 1 件" in w for w in q["warnings"])
    assert any("結論のうち、数値と項目・試料の対応が原文と合わない記述を 1 件" in w for w in q["warnings"])
    assert q["case_layers"]["analysis"]["ok"] == 2 and q["case_layers"]["comparison"]["ran"] is True

    # 2 回目：範囲ごとの整理も資料の分析も使い回す
    llm2 = Mock(cfg, unit=GOOD_UNIT, file=GOOD_FILE, compare=llm.answers["compare"],
                conclusion=llm.answers["conclusion"])
    _run(cfg, case, llm2)
    assert not llm2.of("unit") and not llm2.of("file") and llm2.of("compare")


def test_points_that_copy_values_are_cut_down(cfg, tmp_path):
    case = _case(cfg, tmp_path, lambda d: _book(d / "測定.xlsx", long=True))
    dump = "走査の値は " + "、".join(f"{2.0 + i * 0.001:.3f} GPa" for i in range(40)) + " であった。"
    llm = Mock(cfg, unit={"summary": "深さごとの硬さの表。", "highlights": [], "notes": [], "figures": []},
               file={"document_type": "表",
                     "points": ["深さ 50〜1545 nm の範囲で硬さを測定した。" + dump, dump]},
               conclusion={"conclusions": [{"kind": "未解決の点", "text": "長期の変化は資料からは分からない。"}]})
    cdir = _run(cfg, case, llm)
    assert len(llm.of("file")) == 2 and "値の書き写しになっている" in llm.of("file")[1]["user"]
    sec = _section(cdir)
    assert "深さ 50〜1545 nm の範囲で硬さを測定した。" in sec          # 文の切れ目で制限内に収めた
    assert "2.039 GPa" not in sec
    assert not llm.of("compare")                                       # 資料が 1 件
    assert "■ 資料間の比較" in sec and "未解決の点：長期の変化は資料からは分からない。" in sec


def test_failures_are_reported_and_replaced_by_that_files_evidence(cfg, tmp_path):
    case = _case(cfg, tmp_path, _two_books)
    llm = Mock(cfg, unit=lambda kw: ValueError("JSON が読めません") if "速報.xlsx" in kw["user"] else GOOD_UNIT,
               file=GOOD_FILE, compare={"common": ["樹脂Xは両方の資料にある。"]}, conclusion=["配列だけ"])
    cdir = _run(cfg, case, llm)
    fa = {f["file"]: f for f in json.loads((cdir / "case_file_analyses.json").read_text(encoding="utf-8"))["files"]}
    # 範囲の整理に失敗しても、集計から機械的に組み立てる（数値は原文の値）
    assert fa["速報.xlsx"]["status"] == "auto" and fa["報告.xlsx"]["status"] == "ok"
    retry = [c for c in llm.of("unit") if c.get("tag", "").endswith(":retry")][0]
    assert "JSON として読めませんでした" in retry["user"]
    sec = _section(cdir)
    assert "シート「走査」：深さは 50〜1545 nm（300 件）" in sec
    # 結論は文字列の配列でも受け取る
    assert "配列だけ" in sec
    q = json.loads((cdir / "quality_report.json").read_text(encoding="utf-8"))
    assert any(w.startswith("分析の文章を作れず") and "『速報.xlsx』" in w for w in q["warnings"][:3])
    assert any(w.startswith("読み取れなかった範囲があります") for w in q["warnings"][:3])


def test_nothing_usable_is_said_plainly(cfg, tmp_path):
    def build(d):
        (d / "a.md").write_text("# メモ\n\n確認中。", encoding="utf-8")
        (d / "b.md").write_text("# メモ2\n\n確認中です。", encoding="utf-8")

    case = _case(cfg, tmp_path, build)
    real = CA.make_case_analysis_nodes

    def no_evidence(config, l):
        nodes = real(config, l)
        inner = nodes["analyze_files"]

        def wrapped(state):
            state["aggregated_evidence"] = []          # 証拠も無い状態を再現する
            out = inner(state)
            out["aggregated_evidence"] = []
            return out
        nodes["analyze_files"] = wrapped
        return nodes

    CA.make_case_analysis_nodes = no_evidence
    try:
        cdir = _run(cfg, case, Mock(cfg, unit=ValueError("x"), conclusion=ValueError("x")))
    finally:
        CA.make_case_analysis_nodes = real
    sec = _section(cdir)
    assert sec.count("この資料は分析できませんでした") == 2
    assert "資料間の比較は行っていません（内容を取り出せた資料が 0 件しかないため（資料ごとの分析 0/2 件））" in sec
    q = json.loads((cdir / "quality_report.json").read_text(encoding="utf-8"))
    assert q["warnings"][0].startswith("資料ごとの分析ができたのは 0/2 件です")
    assert any(w.startswith("案件としての結論を書けなかった") for w in q["warnings"])


def test_image_heavy_sheet_is_analysed_from_figure_readings(cfg, tmp_path):
    """図が主役のシート：セルには題名だけ。画像の読み取りが材料になり、値は「図から」と扱う。"""
    source = "## シート: 解析結果\n\n| 応力分布の解析結果 |\n|---|\n"
    vis = [{"evidence_id": "v1", "asset_kind": "sheet_render", "sheet_name": "解析結果",
            "visual_type": "chart", "visual_summary": "応力分布の図", "key_facts": ["最大応力は 120 MPa"],
            "readable_text": ["最大応力 120 MPa", "最小応力 3 MPa"], "source_check": "一部未確認",
            "unverified": ["120 MPa", "3 MPa"]}]
    units = CA.build_units(source, vis)
    assert len(units) == 1 and units[0]["visual"]
    idx = T.build_index(source)
    rec = T.verify_record(dict(sample="", item="最大応力", value="120 MPa"), idx,
                          figure_text=json.dumps(vis, ensure_ascii=False))
    assert rec["status"] == "figure"
    assert T.column_stats(idx) == [] and T.check_statement("最大応力は 120 MPa。", idx) == []
    blob = source + json.dumps(vis, ensure_ascii=False)
    assert CA.screen("図から読み取った最大応力は 120 MPa。", blob=blob, index=idx, vocab=None, source=source) is None
    assert CA.screen("最大応力は 150 MPa。", blob=blob, index=idx, vocab=None, source=source)["reason"] == "number"


def test_frontend_and_prompts_are_generic():
    """特定の案件の語（試料名・項目名）を、プログラムや指示に埋め込んでいない。"""
    root = Path(__file__).resolve().parents[1]
    code = "".join((root / "app" / n).read_text(encoding="utf-8")
                   for n in ("case_analysis.py", "table_index.py", "content_check.py"))
    prompts = CA.UNIT_SYSTEM + CA.FILE_SYSTEM + CA.COMPARE_SYSTEM + CA.CONCLUSION_SYSTEM
    for word in ("PET", "LDPE", "ポアソン", "圧子", "Oliver"):
        assert word not in prompts
    for word in ("PET", "LDPE", "Oliver"):
        assert word not in code


def test_unit_shown_only_by_cell_format_is_unverifiable_not_wrong():
    """単位がセルの表示形式や図にしか無い場合（原文に単位の記載が無い）は、読み違いと決めつけない。
    原文に同じ量の別の単位がある場合（μN と pN）だけ、食い違いとして外す。"""
    from app import deep_read as D
    src = "## シート: 測定\n| 試料 | 厚さ | 荷重(μN) |\n|---|---|---|\n| S-1 | 12.5 | 1 |\n| S-2 | 13.5 | 2 |\n" + "説明" * 20
    vis = [{"evidence_id": "v", "asset_kind": "sheet_render", "sheet_name": "測定",
            "readable_text": ["S-1 12.5 mm 1 μN", "S-2 13.5 mm 2 pN"]}]
    chk = D.build_source_check(src, vis)
    it = chk["items"][0]
    cleaned, _ = D.apply_source_check(vis, chk)
    assert it["unit_mismatch"] == [{"read": "2 pN", "source": "原文の単位：μN"}]
    assert it["unverified"] == ["12.5 mm", "13.5 mm"] and cleaned[0]["readable_text"] == ["S-1 12.5 mm 1 μN"]


# ----------------------------------------------------------------------
# 表・図・説明文を自由に配置したシート／図が何十枚も並ぶシート
# ----------------------------------------------------------------------

FREE_LAYOUT = """## シート: まとめ

| 熱流体解析 結果まとめ |  |  |  |  |  |  |  |  |
|---|---|---|---|---|---|---|---|---|
| 解析条件：入口流速 2.5 m/s、周囲温度 25 ℃ |  |  |  |  |  |  |  |  |
|  |  | ケース | 最高温度(℃) | 圧力損失(Pa) |  |  | ケース | 風量(m3/min) |
|  |  | Case1 | 68.3 | 120.5 |  |  | Case1 | 0.82 |
|  |  | Case2 | 72.1 | 98.25 |  |  | Case2 | 0.75 |
| ※ Case2 はフィン枚数を 12 枚に増やした条件。 |  |  |  |  |  |  |  |  |
"""


def test_title_and_notes_do_not_become_headers_of_a_distant_table():
    idx = T.build_index(FREE_LAYOUT)
    cell = [c for c in idx.cells if c.raw == "68.3"][0]
    assert cell.headers == ["最高温度(℃)"] and cell.labels() == ["Case1"]      # 題名を引き継がない・重複なし
    stats = {s["item"]: s for s in T.column_stats(idx)}
    assert set(stats) == {"最高温度(℃)", "圧力損失(Pa)", "風量(m3/min)"}
    assert stats["最高温度(℃)"]["unit"] == "℃" and stats["最高温度(℃)"]["min"]["row"] == "Case1"
    # 正しい文は通し、取り違えだけを拾う（横に並んだ別の表の値でも同じ）
    assert T.check_statement("Case2 の最高温度は 72.1 ℃で、Case1 の 68.3 ℃より高い。", idx) == []
    assert T.check_statement("入口流速 2.5 m/s、周囲温度 25 ℃で解析した。", idx) == []
    assert T.check_statement("Case1 の圧力損失は 68.3 Pa。", idx)[0]["said"] == "圧力損失"
    assert T.check_statement("Case2 の風量は 0.82 m3/min。", idx)


def test_many_figure_readings_are_split_into_parts():
    """解析結果の図が何十枚も並ぶシート：1 回の入力に収まるよう、同じ範囲の続きとして分ける。"""
    source = "## シート: 結果図\n\n| 流速分布・温度分布 |\n|---|\n"
    vis = [{"evidence_id": f"v{i}", "asset_kind": "sheet_render", "sheet_name": "結果図",
            "visual_summary": "流速分布の図" * 20, "readable_text": [f"最大流速 {i}.5 m/s"]} for i in range(30)]
    one = CA.build_units(source, vis)
    assert len(one) == 1 and len(one[0]["visual"]) == 30
    parts = CA.build_units(source, vis, max_visual_chars=2000)
    assert len(parts) > 3 and sum(len(u["visual"]) for u in parts) == 30
    assert all(u["names"] == ["結果図"] for u in parts)
    assert parts[0]["text"].strip() and not parts[1]["text"]          # 原文は 1 つ目にだけ付ける
    assert parts[1]["part"] == (2, len(parts))
    assert all(sum(len(json.dumps(v, ensure_ascii=False)) for v in u["visual"]) <= 2000 or len(u["visual"]) == 1
               for u in parts)


def test_sheet_image_cap_is_reported_not_silent(tmp_path):
    """図の多いブックでシート画像が上限に達したら、画像にしなかったシートを記録する。"""
    from reportlab.pdfgen import canvas
    from app.nodes import _render_sheet_pdfs
    meta = []
    for i, name in enumerate(["結果1", "結果2", "結果3"]):
        p = tmp_path / f"s{i}.pdf"
        cv = canvas.Canvas(str(p))
        cv.drawString(72, 700, f"sheet {i}")
        cv.showPage()
        cv.save()
        meta.append({"index": i + 1, "name": name, "pdf_path": str(p)})
    rep = {}
    pages = _render_sheet_pdfs(meta, tmp_path / "out", scale=0.5, max_pages=2, report=rep)
    assert len(pages) == 2 and rep == {"not_rendered": ["結果3"], "capped": 2}
    rep2 = {}
    assert len(_render_sheet_pdfs(meta, tmp_path / "out2", scale=0.5, max_pages=10, report=rep2)) == 3
    assert rep2 == {}
