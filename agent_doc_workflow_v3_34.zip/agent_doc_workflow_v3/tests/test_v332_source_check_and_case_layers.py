"""v3.32：画像の読み取りと原文の照合／抽出の緩和／キャッシュの版／案件の三段構え／中身の検査。

資料の種類（PDF・PowerPoint・Word・Excel）が混ざった案件でも同じ考え方で
動くことを確かめる。特定の案件の数値や語に依存した検査はしない。
"""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import openpyxl
import pytest

from app import case_detect as CD
from app import case_flow as CF
from app import deep_read as D
from app.case_analysis import (TAG_COMPARE, TAG_CONCLUSION, TAG_FILE, files_in_findings,
                               findings_to_strings, match_file)
from app.content_check import STATUS_OK, STATUS_REVIEW, fix_evidence_ids, run_content_checks
from app.parsing import structural_chunks_traced

from tests.test_v331_case_folder import _ledger

SUFS = {".pdf", ".pptx", ".xlsx", ".md"}


# ----------------------------------------------------------------------
# 数値と単位の取り出し
# ----------------------------------------------------------------------

def test_numbers_next_to_japanese_are_extracted():
    vals = [(v, u) for v, u, _ in D._extract_numbers("結果は12.5 GPaであった。温度は23℃。")]
    assert (12.5, "GPa") in vals and (23.0, "degC") in vals


def test_model_numbers_are_not_values():
    vals = [v for v, _, _ in D._extract_numbers("型番AB300、試料X12")]
    assert 300.0 not in vals and 12.0 not in vals


@pytest.mark.parametrize("text,unit", [
    ("150 nm/s", "nm/s"), ("150 mm/s", "mm/s"), ("50 um", "μm"), ("50 µm", "μm"),
    ("0.8 m3/min", "m3/min"), ("500 μN", "μN"), ("3 kPa", "kPa"), ("12 MHz", "MHz"),
])
def test_composed_units(text, unit):
    got = D._extract_numbers(text)
    assert got and got[0][1] == unit


# ----------------------------------------------------------------------
# 原文との照合
# ----------------------------------------------------------------------

EXCEL_SRC = """## シート: 測定
| 試料 | 速度 | 弾性率 |
|---|---|---|
| S-1 | 150 nm/s | 12.5 GPa |
| S-2 | 300 nm/s | 13.1 GPa |
## シート: 集計
| 項目 | 値 |
|---|---|
| 平均 | 12.8 |
## グラフ（定義から復元した数値）
- 系列 弾性率: 12.5, 13.1
"""


def _sheet(eid, sheet, lines):
    return {"evidence_id": eid, "asset_kind": "sheet_render", "sheet_name": sheet,
            "readable_text": lines, "key_facts": [], "visual_summary": ""}


def test_excel_sheet_misreads_are_removed_and_unverifiable_lines_are_kept():
    vis = [_sheet("v1", "測定", ["試料 速度 弾性率", "S-1 150 mm/s 12.5 GPa", "密度 2.3 g/cm3",
                                "S-2 300 nm/s 13.9 GPa", "S-2 300 nm/s 13.1 GPa"]),
           _sheet("v2", "集計", ["平均 12.8", "弾性率 12.5 13.1"])]
    chk = D.build_source_check(EXCEL_SRC, vis)
    a, b = chk["items"]
    assert a["status"] == D.CHECK_DIFF and a["scope"] == "シート「測定」"
    assert a["unit_mismatch"] == [{"read": "150 mm/s", "source": "150 nm/s"}]
    # 原文の同じ行（S-2 の行）に対応しているのに値が違う → 読み違い
    assert "13.9 GPa" in a["contradicted"]
    # 原文のどの行にも対応しない行（図の注記など）→ 外さずに「確かめられない」とする
    assert "2.3 g/cm3" in a["unverified"] and "2.3 g/cm3" not in a["contradicted"]
    # 別シートの値を引いた集計・グラフは、資料全体の原文にあれば一致とみなす
    assert b["status"] == D.CHECK_OK
    cleaned, removed = D.apply_source_check(vis, chk)
    assert cleaned[0]["readable_text"] == ["試料 速度 弾性率", "密度 2.3 g/cm3", "S-2 300 nm/s 13.1 GPa"]
    assert sorted(removed[0]["lines"]) == ["S-1 150 mm/s 12.5 GPa", "S-2 300 nm/s 13.9 GPa"]
    assert cleaned[0]["unverified"] == ["2.3 g/cm3"]
    assert cleaned[1]["readable_text"] == vis[1]["readable_text"]
    assert chk["checked"] == 2 and chk["ok"] == 1 and chk["diff"] == 1


def test_reading_that_matches_nothing_is_dropped_but_figure_notes_survive():
    src = EXCEL_SRC
    hallucinated = _sheet("v1", "測定", ["1月 320 kWh 100 V 3.2 A", "2月 410 kWh 100 V 4.1 A",
                                        "3月 395 kWh 100 V 3.9 A", "電力量 電圧 電流"])
    hallucinated["visual_summary"] = "毎月の電力使用量の表"
    note = _sheet("v2", "測定", ["S-1 150 nm/s 12.5 GPa", "圧子の角度 65.27° 77.03°"])
    chk = D.build_source_check(src, [hallucinated, note])
    cleaned, _ = D.apply_source_check([hallucinated, note], chk)
    assert chk["items"][0].get("unreliable") and cleaned[0]["readable_text"] == []
    assert cleaned[0]["visual_summary"] == ""
    assert cleaned[1]["readable_text"] == note["readable_text"]
    assert cleaned[1]["unverified"] == ["65.27°", "77.03°"] and cleaned[1]["source_check"] == D.CHECK_PART
    # 図だけが写ったページ（表の形でない）は、原文と合わなくても捨てない
    fig = _sheet("v3", "測定", ["圧子形状", "先端角 65.27°", "稜間角 77.03°", "接触深さ hc", "投影面積 A", "応力分布図",
                               "最大 120 MPa", "最小 3 MPa", "凡例", "変位", "荷重", "除荷曲線"])
    chk = D.build_source_check(src, [fig])
    cleaned, _ = D.apply_source_check([fig], chk)
    assert not chk["items"][0].get("unreliable") and cleaned[0]["readable_text"] == fig["readable_text"]


def test_lines_with_characters_foreign_to_the_document_are_removed():
    vis = [_sheet("v1", "測定", ["S-1 150 nm/s 12.5 GPa", "复合弹性率 13.1 GPa"])]
    chk = D.build_source_check(EXCEL_SRC, vis)
    cleaned, _ = D.apply_source_check(vis, chk)
    assert cleaned[0]["readable_text"] == ["S-1 150 nm/s 12.5 GPa"]
    assert D.foreign_chars("押込弾性率 ν=0.3 μN ① ㎛") == []


def test_pdf_and_slide_pages_are_checked_leniently():
    """ページに貼られた図の中の文字は文字層に無いことが多い。外さずに「一部未確認」とする。"""
    for src in ("## p.1\n本報告では試料の弾性率を測定した。結果は 12.5 GPa であった。\n## p.2\n図2 に荷重と変位の関係を示す。測定は室温。\n",
                "## スライド 1：概要\n本報告では試料の弾性率を測定した。結果は 12.5 GPa であった。\n"
                "## スライド 2：結果\n図2 に荷重と変位の関係を示す。測定は室温。\n"):
        vis = [{"evidence_id": "p2", "asset_kind": "page_render", "page": 2,
                "readable_text": ["図2 荷重と変位", "最大荷重 500 μN"]},
               {"evidence_id": "p1", "asset_kind": "page_render", "page": 1,
                "readable_text": ["弾性率 12.5 MPa"]}]
        chk = D.build_source_check(src, vis)
        p2, p1 = chk["items"]
        assert p2["status"] == D.CHECK_PART
        assert "500 μN" in p2["numbers_missing"]
        assert p1["status"] == D.CHECK_DIFF and p1["unit_mismatch"]
        cleaned, removed = D.apply_source_check(vis, chk)
        assert cleaned[0]["readable_text"] == vis[0]["readable_text"]       # 外さない
        assert "500 μN" in cleaned[0]["unverified"]
        assert cleaned[1]["readable_text"] == []                            # 単位違いは外す
        block = D.source_check_prompt_block(chk, removed)
        assert "図から読み取った値" in block and "12.5 MPa" in block


def test_no_source_text_is_not_reported_as_match():
    vis = [{"evidence_id": "p1", "asset_kind": "page_render", "page": 1, "readable_text": ["温度 23 ℃"]}]
    chk = D.build_source_check("", vis)
    assert chk["has_source"] is False and chk["ok"] == 0 and chk["na"] == 1
    lines = D.source_check_lines(chk)
    assert any("確かめられていません" in ln for ln in lines)


def test_embedded_images_are_outside_the_check():
    vis = [{"evidence_id": "e1", "asset_kind": "embedded", "page": 1, "readable_text": ["999 kg"]}]
    chk = D.build_source_check("## p.1\n" + "本文" * 30, vis)
    assert chk["items"][0]["status"] == D.CHECK_NA and chk["checked"] == 0


def test_text_evidence_numbers_are_checked_against_source():
    src = "## シート: 測定\n| 試料 | 硬さ |\n|---|---|\n| S-1 | 2.31 GPa |\n" + "x" * 40
    rep = D.check_text_evidence(src, [
        {"evidence_id": "a", "content": "S-1 の硬さは 2.31 GPa", "origin": "text"},
        {"evidence_id": "b", "content": "S-1 の硬さは 2.13 GPa", "origin": "text"},
        {"evidence_id": "r", "content": "金額 120 万円", "origin": "reference"}])
    assert [i["evidence_id"] for i in rep["items"]] == ["b"]


def test_deep_read_node_saves_checked_visuals(tmp_path):
    from app.config import load_config
    from app.nodes import make_nodes
    cfg = load_config()
    cfg.llm.mock = True
    md = tmp_path / "doc.md"
    md.write_text(EXCEL_SRC, encoding="utf-8")
    nodes = make_nodes(cfg)
    vis = [_sheet("v1", "測定", ["S-1 150 mm/s 12.5 GPa", "S-2 300 nm/s 13.1 GPa"])]
    out = nodes["deep_read"]({"run_dir": str(tmp_path), "markdown_path": str(md),
                              "visual_evidence": vis, "aggregated_evidence": []})
    assert out["visual_evidence"][0]["readable_text"] == ["S-2 300 nm/s 13.1 GPa"]
    assert out["visual_evidence"][0]["source_check"] == D.CHECK_DIFF
    assert (tmp_path / "evidence_visual_checked.json").exists()
    rep = json.loads((tmp_path / "page_report.json").read_text(encoding="utf-8"))
    assert rep["version"] == 2 and "本文に書かないでください" in rep["prompt_block"]
    assert "150 mm/s" in rep["prompt_block"]


# ----------------------------------------------------------------------
# 断片の作り方
# ----------------------------------------------------------------------

def test_chunks_keep_sheet_names_and_do_not_merge_sheets():
    md = ("## シート: 測定\n\n| a | b |\n|---|---|\n"
          + "".join(f"| {i} | {i * 1.5} |\n" for i in range(400))
          + "\n## シート: 条件\n\n| x | y |\n|---|---|\n| 温度 | 23 |\n\n## 主な数式\n\n- 測定!C3: `=A1`\n")
    recs, _ = structural_chunks_traced(md, chunk_chars=2000, overlap=100)
    sheets = [r["sheet_name"] for r in recs]
    assert sheets[0] == "測定" and "条件" in sheets and sheets[-1] == ""
    for r in recs:
        if r["sheet_name"] == "測定" and r["slice_index"] > 0:
            assert r["text"].startswith("## シート: 測定（続き）")
        # 表の行が 2 つの断片に割れていない
        body = [ln for ln in r["text"].split("\n") if ln.startswith("| ") and ln[2:3].isdigit()]
        assert all(ln.endswith("|") for ln in body)


def test_page_headings_of_native_text_are_recognised():
    recs, _ = structural_chunks_traced("## p.3\n本文3\n", chunk_chars=100)
    assert recs[0]["page"] == 3


# ----------------------------------------------------------------------
# キャッシュの版
# ----------------------------------------------------------------------

def test_text_evidence_cache_is_rebuilt_when_settings_change(tmp_path):
    from app.config import load_config
    from app.graph import run_workflow
    cfg = load_config()
    cfg.llm.mock = True
    cfg.paths.out_dir = str(tmp_path / "out")
    f = tmp_path / "s.md"
    f.write_text("# 見出し\n\n本文。", encoding="utf-8")

    def details():
        rd = Path(final["run_dir"])
        st = json.loads((rd / "status.json").read_text(encoding="utf-8"))
        return [h.get("detail", "") for h in st["history"]
                if h["node"] == "extract_text_evidence" and h["phase"] == "done"]

    final = run_workflow(str(f), cfg, runs_root=str(tmp_path / "m"), read_only=True, case_member=True)
    final = run_workflow(str(f), cfg, runs_root=str(tmp_path / "m"), read_only=True, case_member=True)
    assert details()[-1] == "キャッシュ再利用"
    cfg.workflow.extract_max_tokens = 1234
    final = run_workflow(str(f), cfg, runs_root=str(tmp_path / "m"), read_only=True, case_member=True)
    assert details()[-1] != "キャッシュ再利用"
    keys = json.loads((Path(final["run_dir"]) / "cache_keys.json").read_text(encoding="utf-8"))
    assert keys["text"]["extract_max_tokens"] == 1234


def test_old_run_without_cache_keys_is_not_reused(tmp_path):
    from app.config import load_config
    from app.graph import run_workflow
    cfg = load_config()
    cfg.llm.mock = True
    f = tmp_path / "s.md"
    f.write_text("# 見出し\n\n本文。", encoding="utf-8")
    final = run_workflow(str(f), cfg, runs_root=str(tmp_path / "m"), read_only=True, case_member=True)
    rd = Path(final["run_dir"])
    (rd / "cache_keys.json").unlink()                     # v3.31 以前の置き場を再現
    final = run_workflow(str(f), cfg, runs_root=str(tmp_path / "m"), read_only=True, case_member=True)
    st = json.loads((rd / "status.json").read_text(encoding="utf-8"))
    done = [h["detail"] for h in st["history"] if h["node"] == "extract_text_evidence" and h["phase"] == "done"]
    assert done[-1] != "キャッシュ再利用"


# ----------------------------------------------------------------------
# 中身の検査
# ----------------------------------------------------------------------

def test_fix_evidence_ids_repairs_missing_prefix_only_when_unique():
    valid = ["f01_c1_ev_001", "f02_c1_ev_002", "f01_c2_ev_001", "f02_c2_ev_001", "ref_001"]
    ids, fixed, removed = fix_evidence_ids(
        ["c1_ev_001", "f03_c1_ev_002", "c2_ev_001", "ref_001", "nothing"], valid)
    assert ids == ["f01_c1_ev_001", "f02_c1_ev_002", "ref_001"]
    assert {f["from"] for f in fixed} == {"c1_ev_001", "f03_c1_ev_002"}
    assert removed == ["c2_ev_001", "nothing"]          # 2 件に当たる物は直さない


def test_content_checks_single_run(tmp_path):
    state = {"aggregated_evidence": [{"evidence_id": "e1"}], "visual_evidence": [],
             "page_report": {"removed": [{"flagged": ["150 mm/s"]}]}}
    summary = {"findings": ["速度は 150 mm/s"], "evidence": ["e1", "x9"]}
    res = run_content_checks(state, summary)
    assert summary["evidence"] == ["e1"]
    assert res["content_status"] == STATUS_REVIEW and len(res["content_issues"]) == 2
    summary = {"findings": ["速度は 150 nm/s"], "evidence": ["e1"]}
    assert run_content_checks(state, summary)["content_status"] == STATUS_OK


def test_findings_tags_round_trip():
    items = findings_to_strings([("a/測定.xlsx", ["p1", "p2"]), ("報告.pdf", ["q"])], ["c"],
                                [("資料の結論", "z")])
    assert items[0] == f"{TAG_FILE}『a/測定.xlsx』p1"
    assert f"{TAG_COMPARE}c" in items and f"{TAG_CONCLUSION}資料の結論：z" in items
    assert files_in_findings(items) == ["a/測定.xlsx", "報告.pdf"]
    files = ["a/測定.xlsx", "報告.pdf", "スライド.pptx"]
    assert match_file("測定", files) == "a/測定.xlsx"
    assert match_file("『報告.pdf』", files) == "報告.pdf"
    assert match_file("スライド", files) == "スライド.pptx"
    assert match_file("無関係", files) == ""


def test_template_groups_findings_and_keeps_plain_lists():
    from app.contract import CaseSummary
    from app.render import render_markdown
    tpl = Path(__file__).resolve().parents[1] / "templates" / "case_summary_v2.md.j2"
    out = Path(tempfile.mkdtemp()) / "s.md"
    s = CaseSummary()
    s.action_results.findings = findings_to_strings(
        [("x.xlsx", ["値 1"]), ("y.pdf", ["値 2"])], ["共通点"], [("未解決の点", "残り")])
    render_markdown(s, str(tpl), str(out))
    md = out.read_text(encoding="utf-8")
    sec = md[md.index("## 調査"):md.index("## 対応効果")]
    assert sec.index("■ 資料ごとの分析") < sec.index("『x.xlsx』") < sec.index("『y.pdf』") \
        < sec.index("■ 資料間の比較") < sec.index("■ 案件としての結論")
    assert "【" not in sec and "- 未解決の点：残り" in sec
    s.action_results.findings = ["ふつうの事実"]
    render_markdown(s, str(tpl), str(out))
    sec = out.read_text(encoding="utf-8")
    assert "- ふつうの事実" in sec and "■" not in sec


# ----------------------------------------------------------------------
# 案件：PDF・Excel・Markdown が混ざったフォルダ
# ----------------------------------------------------------------------

@pytest.fixture()
def cfg(tmp_path):
    from app.config import load_config
    c = load_config()
    c.llm.mock = True
    c.paths.out_dir = str(tmp_path / "out")
    c.workflow.reference_library_dir = str(tmp_path / "refs")
    _ledger(tmp_path / "refs" / "台帳.xlsx")
    return c


def _mixed_case(cfg, root: Path, *, only_excel: bool = False):
    d = root / "src" / "アルミ外材コート層硬さ試験"
    d.mkdir(parents=True)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "測定"
    ws.append(["試料", "荷重(μN)", "硬さ(GPa)"])
    ws.append(["S-1", 500, 2.31])
    ws.append(["S-2", 500, 2.47])
    wb.save(d / "測定結果.xlsx")
    if not only_excel:
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.cidfonts import UnicodeCIDFont
        from reportlab.pdfgen import canvas
        pdfmetrics.registerFont(UnicodeCIDFont("HeiseiMin-W3"))
        cv = canvas.Canvas(str(d / "報告書.pdf"))
        cv.setFont("HeiseiMin-W3", 12)
        cv.drawString(72, 750, "報告書 コート層の硬さ")
        cv.drawString(72, 730, "結論：硬さは 2.31 GPa から 2.47 GPa で、基準を満たす。")
        cv.showPage()
        cv.save()
        (d / "メモ.md").write_text("# 打ち合わせメモ\n\n次回は長期の変化を確認する。", encoding="utf-8")
    rels = {p.relative_to(d.parent).as_posix(): str(p) for p in d.rglob("*") if p.is_file()}
    det = CD.detect_cases(list(rels), CD.load_index(cfg), SUFS)
    c = det["cases"][0]
    return {"key": c["key"], "name": c["name"], "folders": c["folders"], "match": c["match"],
            "members": [{"rel": f["rel"], "rel_in_case": f["rel_in_case"], "name": f["name"],
                         "path": rels[f["rel"]]} for f in c["files"]]}


def _run(cfg, case, llm):
    cid = CF.case_id_for(case["name"], [m["path"] for m in case["members"]])
    cdir = Path(cfg.paths.out_dir) / "runs" / cid
    CF.prepare_case_dir(cdir, case, "case", "依頼対応事例")
    CF.run_case(cdir, case, cfg, template_id="case", llm=llm)
    return cdir


def test_frontend_shows_case_layers_and_check():
    html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
    for s in ("analyze_files", "compare_files", "case_findings", "原文との照合：画像",
              "前回の結果を使用", "内容の確認"):
        assert s in html


def test_external_version_hides_internal_file_names():
    from app.case_analysis import external_file_labels
    s = {"action_results": {"findings": findings_to_strings(
        [("顧客A_測定.xlsx", ["値 1"]), ("報告.pdf", ["値 2"])], [], [])}}
    out = external_file_labels(s, ["顧客A_測定.xlsx", "報告.pdf"])
    joined = "".join(out["action_results"]["findings"])
    assert "顧客A" not in joined and "『資料1』" in joined and "『資料2』" in joined
    assert "顧客A" in "".join(s["action_results"]["findings"])        # 社内版はそのまま
