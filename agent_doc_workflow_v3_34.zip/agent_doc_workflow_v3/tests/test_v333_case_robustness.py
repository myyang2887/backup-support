"""v3.33：案件の三段構えを、弱いモデルの出力でも動かす。

- 形の違う出力（オブジェクト・数値・入れ子・辞書）を受け取って使う
- 何も使えないときだけ、理由を添えて 1 回やり直す
- 分析できなかった資料は、その資料自身の証拠で書くか「分析できなかった」と書く
- 比較を飛ばした理由を正しく出す
- 「資料ごとの分析」の数値は、その資料自身の原文で確かめる
- 画像の照合：表示の丸め・接頭辞（p・f）・換算
"""
from __future__ import annotations

import json

import pytest

from app import deep_read as D
from app.case_analysis import FileAnalysis
from app.llm_coerce import coerce_flat, to_list, to_text



# ----------------------------------------------------------------------
# 出力の形を寄せる
# ----------------------------------------------------------------------

def test_measurement_objects_become_sentences():
    row = {"試料": "PET", "条件": "ポアソン比 0.3", "測定項目": "複合弾性率",
           "値": 3301.129875, "単位": "MPa"}
    assert to_text(row) == "PET（ポアソン比 0.3）：複合弾性率 3301.129875 MPa"
    assert to_text({"sample": "S-1", "value": 2.31, "unit": "GPa"}) == "S-1：2.31 GPa"
    assert to_text({"試料": "A", "最大値": 12, "単位": "nm"}) == "A：最大値 12 nm"
    # 役割の分からないキーは「キー：値」で残す（情報を落とさない）
    assert to_text({"試料": "A", "硬さ": 2.3, "弾性率": 45}) == "試料：A、硬さ：2.3、弾性率：45"


def test_to_list_flattens_any_shape():
    assert to_list([{"sample": "A", "value": 1.5, "unit": "GPa"}, ["x", ["y"]], 5]) == ["A：1.5 GPa", "x", "y", "5"]
    assert to_list("- a\n- b\n") == ["a", "b"]
    assert to_list({"S-1": 2.31, "S-2": 2.47}) == ["S-1：2.31", "S-2：2.47"]


def test_coerce_flat_keeps_usable_fields():
    raw = {"document_type": ["測定結果", "表"], "purpose": None,
           "points": [{"試料": "A", "値": 1.5, "単位": "GPa"}, "B：2.0 GPa"],
           "conclusions": "結論A\n結論B", "unknown": 1}
    fa, rep = coerce_flat(raw, FileAnalysis)
    assert fa.points == ["A：1.5 GPa", "B：2.0 GPa"]
    assert fa.conclusions == ["結論A", "結論B"] and fa.document_type == "測定結果、表"
    assert any(x.startswith("points") for x in rep["fixed"])
    # 1 段包まれていても読む
    fa, _ = coerce_flat({"analysis": {"purpose": "p"}}, FileAnalysis)
    assert fa.purpose == "p"


# ----------------------------------------------------------------------
# 画像の照合：表示の丸め・接頭辞・換算
# ----------------------------------------------------------------------

SRC = ("## シート: 測定\n| 試料 | 荷重(μN) | 深さ(nm) | 弾性率(MPa) | 比 |\n|---|---|---|---|---|\n"
       "| S-1 | 1 | 316.5335 | 3301.129875 | 0.125 |\n| S-2 | 1000 | 150 | 2.5 | x |\n" + "説明" * 20)


def _check(lines):
    vis = [{"evidence_id": "v", "asset_kind": "sheet_render", "sheet_name": "測定", "readable_text": lines}]
    return D.build_source_check(SRC, vis)["items"][0]


def test_excel_display_rounding_is_not_a_misread():
    it = _check(["S-1 1 317 3301.13 12.5%", "3.30E+03"])
    assert it["status"] == D.CHECK_OK and "317" in it["rounded"]


def test_wrong_prefix_is_caught_even_without_unit_next_to_value():
    it = _check(["S-1 荷重 1 pN"])
    assert it["status"] == D.CHECK_DIFF
    assert it["unit_mismatch"] == [{"read": "1 pN", "source": "原文の単位：μN"}]


def test_real_digit_misread_is_still_caught():
    it = _check(["S-1 318 3301.13"])
    assert "318" in it["numbers_missing"] and it["status"] == D.CHECK_DIFF


def test_prefix_conversion_counts_as_match():
    src = "## p.1\n荷重は 1 μN、速度は 150 nm/s とした。" + "説明" * 20
    vis = [{"evidence_id": "p", "asset_kind": "page_render", "page": 1,
            "readable_text": ["荷重 0.001 mN", "速度 0.15 μm/s"]}]
    it = D.build_source_check(src, vis)["items"][0]
    assert it["status"] == D.CHECK_OK and len(it["converted"]) == 2


def test_new_prefixes_in_unit_table():
    assert [u for _, u, _ in D._extract_numbers("1 pN、2 fF、3 ps")] == ["pN", "fF", "ps"]


def test_unsupported_numbers_accepts_display_rounding_and_conversion():
    assert D.unsupported_numbers("深さは 317 nm、荷重は 0.001 mN", "深さ 316.5335 nm、荷重 1 μN") == []
    assert D.unsupported_numbers("深さは 320 nm", "深さ 316.5335 nm")
