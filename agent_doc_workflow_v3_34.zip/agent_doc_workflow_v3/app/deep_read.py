"""
精読モード（deep read）— ページ単位で本文と図を突き合わせる層。

v3.32 で中心を「原文との照合」（このファイルの後半）に移した。画像の読み取りを
抜き出した証拠ではなく原文そのものと照らし合わせ、Excel はシート、PDF・PPT は
ページで組にする。下の build_page_report（証拠どうしの突き合わせ）は互換のために
残しているが、ワークフローからは呼んでいない。以下は v3.9 当時の説明。

## 何をする物か

人が資料を読むとき、1 ページの中で「本文」「図表」「ページ全体の見た目」を
同時に見て辻褄を確認してから次へ進む。v3.8 までのこのシステムは本文チェーンと
視覚チェーンが最後まで一度も出会わず、`write_summary` で初めて並べられていた。
本文が「3.2 秒」、図が「3.5 秒」と言っていても誰も気付けない。

精読モードはその隙間を埋める。ただし**逐次 refine にはしない**：

- refine（1 ページ目の要約に 2 ページ目を溶かし込む…）は前段の誤りが最後まで
  伝播し、位置バイアスが出て、直列なので O(n) で遅い。弱いモデルでは特に悪い。
- ここでは **ページ単位の突き合わせは並列**に行い、集約は従来どおり
  map-reduce のまま残す。「ページ内は精読、全体は map-reduce」の折衷。

## 判定はモデルに任せない

食い違いの裁定を弱いモデルの自由記述に任せると、もっともらしい嘘が増えるだけ。
ここでの突き合わせは**確定的な規則**で行う：

1. 数値の一致検査 — 同じページの本文と図から数値（単位付き）を拾い、
   同じ量を指していそうなのに値が違う組を「要確認」として挙げる
2. 被覆の対帳 — そのページに図が N 枚あるのに視覚証拠が M 件しか無い、等
3. 片側しか無いページの検出 — 本文だけ／図だけのページを可視化

LLM は「食い違いが実際に問題か」の判断には使わない。人と後段のプロンプトに
**事実として渡す**だけ。
"""
from __future__ import annotations

import re
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

# 単位の並び順は**長い物から**でなければならない。正規表現の選択肢は
# 左から順に試されるので、`m` を先に置くと "0.8 m3/min" が "0.8 m" として
# 拾われ、単位違いで突き合わせが成立しなくなる（実際にそのバグを踏んだ）。
#
# v3.32：単位表を組み立て式にした。以前は列挙に無い単位（nm・μm・μN、
# mm/s のような速度）が「単位なし」や別の単位として拾われ、
# 「150 nm/s」と「150 mm/s」の違いを検出できなかった。
# v3.33：p・f を足した（「1 pN」が単位なしの小さな整数として素通りしていた）
_PREFIXES = ["f", "p", "n", "μ", "m", "c", "k", "M", "G"]
_PREFIX_FACTOR = {"f": 1e-15, "p": 1e-12, "n": 1e-9, "μ": 1e-6, "m": 1e-3, "c": 1e-2,
                  "": 1.0, "k": 1e3, "M": 1e6, "G": 1e9}
_BASES = ["Pa", "Hz", "m", "g", "N", "s", "V", "A", "W", "L", "J", "Ω", "F", "T"]
_SPECIAL = [
    "万円", "億円", "千円", "ヶ月", "か月", "時間", "kWh", "degC", "°C", "wt%", "vol%",
    "ppm", "ppb", "rpm", "kgf", "bar", "sec", "min", "deg", "mol", "dB", "HV", "pH",
    "m3", "m2", "mm2", "mm3", "cm2", "cm3", "mL", "t", "h", "K", "%", "°",
    "秒", "分", "時", "日", "週", "年", "件", "個", "人", "台", "回", "円", "枚", "本", "点",
]
_DENOMS = ["min", "sec", "mm2", "cm2", "cm3", "mm3", "m2", "m3", "mm", "cm", "kg", "mL",
           "s", "h", "m", "g", "L", "K"]


def _build_units() -> List[str]:
    units = set(_SPECIAL) | set(_BASES)
    for pre in _PREFIXES:
        for base in _BASES:
            units.add(pre + base)
    for u in list(units):
        if re.fullmatch(r"[A-Za-zμΩ°%0-9]+", u):
            for d in _DENOMS:
                units.add(f"{u}/{d}")
    return sorted(units, key=lambda u: (-len(u), u))


_UNITS = _build_units()


def normalize_text(text: str) -> str:
    """照合用の表記ゆれ吸収：全角/半角、μ と µ、℃ など（NFKC）。
    「um」「uN」のように u で代用されたマイクロも μ に寄せる。"""
    import unicodedata

    t = unicodedata.normalize("NFKC", str(text or ""))
    t = t.replace("µ", "μ")
    t = re.sub(r"(?<![A-Za-z])u(?=(?:m|N|g|L|s|A|V|W|F)(?![A-Za-z]))", "μ", t)
    return t


#: 数値＋単位。日本語資料で実際に出る書き方に寄せてある
#: （カンマ区切り・指数表記・単位なしの裸の数も拾う）。
#: 単位の直後に英字が続く場合は単位とみなさない（"3 mold" の m など）。
#: 数字の直前が英数字なら型番・試料番号の一部とみなす。日本語の直後
#: （「結果は12.5 GPa」）は数値として拾う。\w を使うと漢字・かなも語の一部と
#: みなされ、日本語の文中の数値が一つも拾えなくなる。
_NUM_RE = re.compile(
    r"(?<![A-Za-z0-9_.])"
    r"([+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?|[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)"
    r"\s*"
    r"((?:" + "|".join(re.escape(u) for u in _UNITS) + r")(?![A-Za-z]))?"
)

#: 相対差がこれ以下なら「同じ値」とみなす。
#: 丸め表記の揺れ（68.30 と 68.3）だけを吸収したいので厳しめに取る。
#: 0.5% にすると 68.3 と 68.5 のような**実在する食い違い**を見逃す。
_REL_TOL = 0.001


def _extract_numbers(text: str) -> List[Tuple[float, str, str]]:
    """(値, 単位, 原文表記) の一覧。単位なしは "" で返す。"""
    out: List[Tuple[float, str, str]] = []
    if not text:
        return out
    text = normalize_text(text)
    for m in _NUM_RE.finditer(text):
        raw = m.group(1)
        try:
            val = float(raw.replace(",", ""))
        except ValueError:
            continue
        unit = (m.group(2) or "").strip()
        unit = {"℃": "degC", "°C": "degC", "％": "%", "sec": "s"}.get(unit, unit)
        out.append((val, unit, m.group(0).strip()))
    return out


def _close(a: float, b: float) -> bool:
    if a == b:
        return True
    scale = max(abs(a), abs(b))
    return scale > 0 and abs(a - b) / scale <= _REL_TOL


# ---- v3.33：表示の丸め・単位の換算 ----
# Excel のセルは 316.5335 でも、画像（表示）では 317 と出る。画像の読み取りは
# 表示どおりなので、原文の値を同じ桁で丸めて一致すれば正しい読み取りとみなす。
# 書式が % のセル（値 0.125・表示 12.5%）も同じ考え方で扱う。

def _decimals(raw: str) -> Optional[int]:
    """表記の小数点以下の桁数。指数表記は対象外（None）。"""
    m = re.match(r"\s*[+-]?[\d,]+(?:\.(\d+))?([eE])?", raw or "")
    if not m or m.group(2):
        return None
    return len(m.group(1) or "")


def display_match(val: float, raw: str, src: float, unit: str = "") -> bool:
    """読み取り値 val（表記 raw）が、原文の値 src を表示用に丸めた物と言えるか。"""
    d = _decimals(raw)
    if d is None:
        # 指数表記（3.30E+03）：仮数の桁数で原文の値を丸めて比べる
        m = re.match(r"\s*[+-]?(\d+)(?:\.(\d+))?[eE]", raw or "")
        if not m or src == 0:
            return False
        sig = len((m.group(1) + (m.group(2) or "")).lstrip("0")) or 1
        return _close(float(f"{src:.{sig - 1}e}"), val)
    cands = [(val, d)]
    if unit == "%":
        cands.append((val / 100.0, d + 2))     # 書式 % のセル：0.125 → 12.5%
    for v, dd in cands:
        if abs(src) < 10 ** (-dd):              # 0.004 を「0」と表示した類は判断しない
            continue
        if abs(round(src, dd) - v) <= 10 ** (-dd) * 1e-6 + 1e-12:
            return True
        if unit == "%" and dd == d + 2 and _close(v, src):
            return True
    return False


def split_unit(unit: str) -> Optional[Tuple[float, str]]:
    """接頭辞付きの単位を（倍率, 基本単位）に分ける。mm/s → (1e-3, "m/s")。"""
    if not unit:
        return None
    num, sep, den = unit.partition("/")
    for base in sorted(_BASES, key=len, reverse=True):
        if num.endswith(base):
            pre = num[: -len(base)]
            if pre in _PREFIX_FACTOR:
                return _PREFIX_FACTOR[pre], base + (sep + den if sep else "")
    return None


def converted_match(val: float, unit: str, pairs: List[Tuple[float, str, str]]) -> str:
    """接頭辞を換算すれば原文の値と一致するか（0.001 mN と 1 μN）。一致した原文の表記を返す。"""
    su = split_unit(unit)
    if not su:
        return ""
    f, base = su
    for v, u, raw in pairs:
        if not u or u == unit:
            continue
        so = split_unit(u)
        if so and so[1] == base and _close(val * f, v * so[0]):
            return raw
    return ""


def cross_check_page(page: Optional[int],
                     text_items: List[Dict[str, Any]],
                     visual_items: List[Dict[str, Any]]) -> Dict[str, Any]:
    """1 ページ分の突き合わせ。全て確定的な規則で判定する。"""
    text_blob = " ".join(str(d.get("content", "")) for d in text_items)
    vis_blob_parts: List[str] = []
    for v in visual_items:
        vis_blob_parts.append(str(v.get("visual_summary", "")))
        vis_blob_parts.extend(str(x) for x in (v.get("key_facts") or []))
        vis_blob_parts.extend(str(x) for x in (v.get("readable_text") or []))
    vis_blob = " ".join(vis_blob_parts)

    t_nums = _extract_numbers(text_blob)
    v_nums = _extract_numbers(vis_blob)

    # 同じ単位で近い値が両方にあれば「裏が取れた」、
    # 同じ単位なのに一致する相手が居ない値は「片側だけ」として挙げる。
    corroborated: List[str] = []
    text_only: List[str] = []
    visual_only: List[str] = []

    v_by_unit: Dict[str, List[float]] = defaultdict(list)
    for val, unit, _ in v_nums:
        v_by_unit[unit].append(val)
    t_by_unit: Dict[str, List[float]] = defaultdict(list)
    for val, unit, _ in t_nums:
        t_by_unit[unit].append(val)

    seen_t = set()
    for val, unit, raw in t_nums:
        if raw in seen_t:
            continue
        seen_t.add(raw)
        if not unit:
            continue                      # 単位なしの裸の数は誤検出が多いので対象外
        if any(_close(val, o) for o in v_by_unit.get(unit, [])):
            corroborated.append(raw)
        elif v_by_unit.get(unit):
            # 同じ単位の値が図側にもあるのに一致しない ＝ 食い違いの疑い
            text_only.append(raw)

    seen_v = set()
    for val, unit, raw in v_nums:
        if raw in seen_v:
            continue
        seen_v.add(raw)
        if not unit:
            continue
        if not any(_close(val, o) for o in t_by_unit.get(unit, [])) and t_by_unit.get(unit):
            visual_only.append(raw)

    conflicts: List[Dict[str, Any]] = []
    for unit in set(t_by_unit) & set(v_by_unit):
        if not unit:
            continue
        tv, vv = sorted(set(t_by_unit[unit])), sorted(set(v_by_unit[unit]))
        if tv and vv and not any(_close(a, b) for a in tv for b in vv):
            conflicts.append({"unit": unit,
                              "text_values": tv[:6], "visual_values": vv[:6]})

    if text_items and visual_items:
        coverage = "both"
    elif text_items:
        coverage = "text_only"
    elif visual_items:
        coverage = "visual_only"
    else:
        coverage = "empty"

    return {
        "page": page,
        "coverage": coverage,
        "text_evidence_count": len(text_items),
        "visual_evidence_count": len(visual_items),
        "numbers_corroborated": corroborated[:12],
        "numbers_text_only": text_only[:12],
        "numbers_visual_only": visual_only[:12],
        "conflicts": conflicts[:6],
        "needs_review": bool(conflicts),
    }


def build_page_report(text_evidence: List[Dict[str, Any]],
                      visual_evidence: List[Dict[str, Any]]) -> Dict[str, Any]:
    """全ページ分の突き合わせ結果を作る。

    ページ番号を持たない証拠は `unpaged` にまとめる（捨てない）。
    """
    by_page_t: Dict[Any, List[Dict[str, Any]]] = defaultdict(list)
    by_page_v: Dict[Any, List[Dict[str, Any]]] = defaultdict(list)
    for d in text_evidence or []:
        by_page_t[d.get("page")].append(d)
    for d in visual_evidence or []:
        by_page_v[d.get("page")].append(d)

    pages = sorted({p for p in list(by_page_t) + list(by_page_v) if p is not None})
    results = [cross_check_page(p, by_page_t.get(p, []), by_page_v.get(p, []))
               for p in pages]

    unpaged_t, unpaged_v = by_page_t.get(None, []), by_page_v.get(None, [])
    unpaged = None
    if unpaged_t or unpaged_v:
        unpaged = cross_check_page(None, unpaged_t, unpaged_v)

    conflicts = [r for r in results if r["needs_review"]]
    return {
        "pages": results,
        "unpaged": unpaged,
        "page_count": len(results),
        "pages_with_both": sum(1 for r in results if r["coverage"] == "both"),
        "pages_text_only": sum(1 for r in results if r["coverage"] == "text_only"),
        "pages_visual_only": sum(1 for r in results if r["coverage"] == "visual_only"),
        "conflict_pages": [r["page"] for r in conflicts],
        "conflict_count": len(conflicts),
    }


def report_to_prompt_block(report: Dict[str, Any], max_pages: int = 40) -> str:
    """突き合わせ結果を Agent 3 のプロンプトに載る短い日本語ブロックへ。

    長くすると証拠パックを圧迫するので、**要確認の頁と片側しか無い頁**に絞る。
    問題の無い頁はわざわざ書かない。
    """
    if not report or not report.get("pages"):
        return ""
    lines: List[str] = []
    for r in report["pages"][:max_pages]:
        if r["conflicts"]:
            for c in r["conflicts"]:
                lines.append(
                    f"- {r['page']}ページ：本文と図で {c['unit']} の値が食い違っています"
                    f"（本文 {c['text_values']} / 図 {c['visual_values']}）。"
                    f"どちらか一方だけを断定せず、資料で確認できる方を採用すること。")
        elif r["coverage"] == "visual_only":
            lines.append(f"- {r['page']}ページ：本文側の証拠が無く、図の読み取りのみです。")
    if not lines:
        return ""
    head = (f"ページ突き合わせ（精読モード・{report['page_count']} ページ中 "
            f"{report['conflict_count']} ページで要確認）：")
    return head + "\n" + "\n".join(lines[:20])


def summary_lines(report: Dict[str, Any]) -> List[str]:
    """UI / ログ用の日本語 1 行要約。"""
    if not report or not report.get("pages"):
        return []
    out = [f"精読：{report['page_count']} ページを突き合わせ"
           f"（本文と図の両方があるページ {report['pages_with_both']}）"]
    if report["pages_text_only"]:
        out.append(f"　本文のみのページ {report['pages_text_only']}")
    if report["pages_visual_only"]:
        out.append(f"　図のみのページ {report['pages_visual_only']}")
    if report["conflict_count"]:
        out.append(f"　⚠ 数値が食い違うページ {report['conflict_count']}："
                   f"{report['conflict_pages'][:10]}")
    return out


# ---------------------------------------------------------------------------
# 数値の裏取り — 作話に対する確定的な歯止め
# ---------------------------------------------------------------------------
#
# 「詳しく書け」と指示された弱いモデルの典型的な失敗は、字数を満たすために
# **もっともらしい数値を作ること**。プロンプトで禁じても完全には止まらない。
#
# そこで規則で潰す：出力に現れた数値が証拠のどこにも無ければ、それは
# モデルが作った物と断定してよい。要約は抽出であって創造ではないので、
# 「証拠に無い数値が出てくる」こと自体が異常である。
#
# 判定はモデルを介さないので、モデルの巧拙に左右されない。


def unsupported_numbers(produced_text: str, evidence_text: str,
                        allow_ordinals: bool = True) -> List[Dict[str, Any]]:
    """出力にあって証拠に無い数値を挙げる。

    - 単位付きの値は「値＋単位」で照合する（68.3 degC と 68.3 % は別物）
    - 単位なしの裸の数は誤検出が多いので、既定では見逃す
      （箇条書きの番号や「3 件」の語形違いを拾ってしまうため）
    - 丸め表記の揺れ（68.30 と 68.3）は一致とみなす
    """
    ev = _extract_numbers(evidence_text)
    ev_by_unit: Dict[str, List[float]] = defaultdict(list)
    for val, unit, _ in ev:
        ev_by_unit[unit].append(val)
    # 単位が落ちた書き方（証拠「68.3 degC」→ 出力「68.3」）も裏取り済みとみなす
    ev_any = [val for val, _, _ in ev]

    bad: List[Dict[str, Any]] = []
    seen = set()
    for val, unit, raw in _extract_numbers(produced_text):
        if raw in seen:
            continue
        seen.add(raw)
        if not unit:
            if allow_ordinals:
                continue
            if any(_close(val, o) for o in ev_any):
                continue
            bad.append({"value": val, "unit": "", "text": raw})
            continue
        if any(_close(val, o) for o in ev_by_unit.get(unit, [])):
            continue
        # 単位付きで一致が無い。単位を無視しても一致しないなら作話とみなす
        if any(_close(val, o) for o in ev_any):
            continue
        # v3.33：表示の丸め（原文 316.5335 を 317 と書いた）・接頭辞の換算は裏付けありとみなす
        if any(display_match(val, raw, o, unit) for o in ev_any):
            continue
        if converted_match(val, unit, ev):
            continue
        bad.append({"value": val, "unit": unit, "text": raw})
    return bad


def verify_items(items: List[str], evidence_text: str) -> Dict[str, Any]:
    """加筆結果を証拠と突き合わせて採否を決める。

    1 つでも裏の取れない数値があれば **その回の加筆を丸ごと捨てる**。
    部分採用にすると、捨てた文と残した文の整合が崩れて余計に危ない。
    """
    joined = "\n".join(items or [])
    bad = unsupported_numbers(joined, evidence_text)
    return {"ok": not bad, "unsupported": bad,
            "reason": ("" if not bad else
                       "証拠に無い数値が含まれています: "
                       + ", ".join(b["text"] for b in bad[:5]))}


# ---------------------------------------------------------------------------
# 原文との照合（v3.32）— 図・ページ画像の読み取りを、資料の原文で確かめる
# ---------------------------------------------------------------------------
#
# v3.31 までの突き合わせ（上の build_page_report）には穴が 3 つあった。
#
#   1. 本文側に「モデルが抽出した証拠の文」を使っていた。表は抽出の段階で
#      「〜の測定データ」のように要約されるので、照合する数値が残っていない。
#   2. 本文と図を「ページ番号」で組にしていた。Excel の本文はシート単位で
#      ページ番号を持たないため、1 組も成立しなかった。
#   3. 組が成立しない・片側しか無い場合も「食い違いなし」と表示していた。
#
# ここでは次のように改める。資料の種類を問わず同じ考え方で動く。
#
#   - 本文側は **原文**（Excel はセルから作った表、PDF・PowerPoint・Word は
#     文字として取り出した本文）をそのまま使う。モデルを通さない。
#   - 組にする単位は、原文と画像の両方が持っている位置情報で決める：
#     Excel はシート名、PDF・PowerPoint はページ（スライド）番号。
#     どちらも決められなければ資料全体の原文と照合し、その旨を残す。
#   - 画像から読み取った数値・単位・語が原文にあるかを 1 つずつ確かめる。
#   - 結果は「一致」「相違あり」「一部未確認」「照合不可」の 4 つに分ける。
#     原文が無い（スキャン PDF など）場合は照合不可であり、一致ではない。
#   - v3.34：「原文と食い違う」と「原文では確かめられない」を行ごとに分ける。
#     外すのは、単位の食い違い・原文の 1 行に対応しているのに数値が違う行・
#     読み取り全体が原文とほとんど合わないときの表状の行・文字の誤認識。
#     原文のどの行にも対応しない行（図の注記、貼られた画像の文字）は外さず
#     「一部未確認」とし、後段に「図から読み取った値」として伝える。
#     Excel のシートにも図・図形・テキストボックスがあり、その文字はセルに無い。
#
# 判定はすべて規則で行い、LLM は使わない。

CHECK_OK = "一致"
CHECK_DIFF = "相違あり"
CHECK_PART = "一部未確認"
CHECK_NA = "照合不可"

# 厳密に照合できるのは「画像と原文が同じ物を写している」と言える場合だけ。
#   - Excel のシート画像と、そのシートのセル値 … 原文が完全なので、原文に無い
#     数値・語は読み違いとみなして外す（厳密）
#   - PDF / PPT のページ画像と、そのページの文字 … ページに貼られた図の中の文字は
#     文字層に無いことが多い。原文に無いだけでは誤りと言えないので外さず、
#     「原文で確認できなかった」として後段に伝える（緩め）
#   - 単位の食い違い（原文に同じ値が別の単位で書かれている）は、どちらでも外す
MODE_STRICT = "strict"
MODE_LENIENT = "lenient"

_SHEET_HEAD_RE = re.compile(r"^#{1,3}\s*シート\s*[:：]\s*(.+?)\s*$", re.M)
_PAGE_HEAD_RE = re.compile(
    r"^#{1,3}\s*(?:ページ|page|スライド|slide|p\.)\s*[:：]?\s*(\d+)", re.M | re.I)
#: 語の照合に使う「漢字・カタカナの連なり」（2 文字以上）。ひらがなを含む
#: 言い回しはモデルの書き方で変わるので見ない。
_TERM_RE = re.compile(r"[一-龥々ァ-ヶー]{2,}")
#: 原文がこれより短い単位は、照合の根拠にしない（見出しだけ等）
_MIN_SOURCE_CHARS = 30


def split_source_units(source_text: str) -> Dict[str, Any]:
    """原文を、照合の単位（シート／ページ）ごとに分ける。

    戻り値: {"sheets": {シート名: 本文}, "sheet_order": [名前...],
             "pages": {番号: 本文}, "all": 全文}
    見出しが無い資料は sheets / pages が空になり、資料全体で照合する。
    """
    text = source_text or ""
    out: Dict[str, Any] = {"sheets": {}, "sheet_order": [], "pages": {}, "all": text}

    def cut(regex, cast):
        marks = list(regex.finditer(text))
        res = []
        for i, m in enumerate(marks):
            end = marks[i + 1].start() if i + 1 < len(marks) else len(text)
            res.append((cast(m.group(1)), text[m.start():end]))
        return res

    for name, body in cut(_SHEET_HEAD_RE, lambda x: x.strip()):
        # シートの次に来る別種の見出し（「## 主な数式」など）は含めない
        nxt = re.search(r"^## (?!シート)", body[3:], re.M)
        body = body[: nxt.start() + 3] if nxt else body
        out["sheets"][name] = out["sheets"].get(name, "") + body
        if name not in out["sheet_order"]:
            out["sheet_order"].append(name)
    for no, body in cut(_PAGE_HEAD_RE, int):
        out["pages"][no] = out["pages"].get(no, "") + body
    return out


def _name_key(name: str) -> str:
    return re.sub(r"[\W_]+", "", normalize_text(name)).lower()


def source_for(units: Dict[str, Any], *, sheet_name: str = "",
               page: Optional[int] = None) -> Tuple[str, str]:
    """この画像と照合する原文と、その範囲の呼び名を返す。"""
    if sheet_name and units["sheets"]:
        key = _name_key(sheet_name)
        for name, body in units["sheets"].items():
            if _name_key(name) == key:
                return body, f"シート「{name}」"
        # 画像のファイル名ではシート名が 40 文字で切られる。前方一致で 1 つに決まれば採る
        hits = [n for n in units["sheets"] if key and _name_key(n).startswith(key)]
        if len(hits) == 1:
            return units["sheets"][hits[0]], f"シート「{hits[0]}」"
    if page is not None and page in units["pages"] and not units["sheets"]:
        return units["pages"][page], f"{page}ページ"
    return units["all"], "資料全体"


def _unit_in_text(unit: str, norm_text: str) -> bool:
    """単位が原文に（単位として）書かれているか。mm が mm/s の一部として
    現れるだけの場合は数えない。"""
    return bool(re.search(r"(?<![A-Za-zμ/])" + re.escape(unit) + r"(?![A-Za-z0-9/])", norm_text))


def _term_in_source(term: str, squeezed: str) -> bool:
    if term in squeezed:
        return True
    # 画像側で 2 つの見出しが繋がって読まれた場合（「複合弾性率測定」など）
    for i in range(2, len(term) - 1):
        if term[:i] in squeezed and term[i:] in squeezed:
            return True
    return False


def _num_index(text: str) -> Tuple[List[float], Dict[float, set], List[Tuple[float, str, str]]]:
    nums = _extract_numbers(text)
    units_of: Dict[float, set] = defaultdict(set)
    for v, u, _ in nums:
        if u:
            units_of[v].add(u)
    return [v for v, _, _ in nums], units_of, nums


def check_item_against_source(item: Dict[str, Any], source_text: str,
                              mode: str = MODE_STRICT,
                              fallback_text: str = "") -> Dict[str, Any]:
    """画像 1 枚の読み取りを原文で確かめる。

    source_text   … この画像と同じ範囲の原文（そのシート・そのページ）
    fallback_text … 資料全体の原文。別シートの値を引いたグラフ・集計表のように、
                    範囲の外にある値は「原文にある」と数える（単位はその値の単位で見る）
    mode          … strict なら原文に無い数値・語は「相違あり」、lenient なら
                    「一部未確認」。単位の食い違いはどちらでも「相違あり」。

    戻り値:
      status         … 一致 / 相違あり / 一部未確認 / 照合不可
      numbers_ok     … 原文にもあった数値の個数
      numbers_missing… 原文に見当たらない数値（表記のまま）
      unit_mismatch  … 値は原文にあるが単位が違う物 [{read, source}]
      terms_missing  … 書き起こしにあって原文に無い語
    """
    res: Dict[str, Any] = {"status": CHECK_NA, "numbers_ok": 0, "numbers_missing": [],
                           "unit_mismatch": [], "terms_missing": []}
    src = normalize_text(source_text)
    whole = normalize_text(fallback_text) if fallback_text else src
    # 原文の有無は資料全体で見る。ページ・シート単位では、文字の少ないページ
    # （図が主役のページ・セルが数個のシート）も正しい照合の相手になる
    if len(whole.strip()) < _MIN_SOURCE_CHARS or not src.strip():
        res["reason"] = "原文がありません"
        return res
    squeezed = re.sub(r"[\s|｜\-:：]+", "", src)
    squeezed_all = re.sub(r"[\s|｜\-:：]+", "", whole) if fallback_text else squeezed

    src_vals, units_of, src_pairs = _num_index(src)
    all_vals, all_units_of, all_pairs = _num_index(whole) if fallback_text else (src_vals, units_of, src_pairs)

    lines: List[str] = [str(x) for x in (item.get("readable_text") or [])]
    prose: List[str] = [str(item.get("visual_summary", ""))] + [str(x) for x in (item.get("key_facts") or [])]

    seen: set = set()
    checked = 0
    for line in lines + prose:
        for val, unit, raw in _extract_numbers(line):
            if raw in seen:
                continue
            seen.add(raw)
            if not unit and float(val).is_integer() and abs(val) < 10:
                continue                      # 番号・枚数などの小さな整数は対象外
            checked += 1
            hits = [o for o in src_vals if _close(val, o)]
            if not hits:
                # 表示の丸め（316.5335 → 317、0.125 → 12.5%）
                hits = [o for o in src_vals if display_match(val, raw, o, unit)]
                if hits:
                    res.setdefault("rounded", []).append(raw)
            in_scope = bool(hits)
            if not hits:
                hits = [o for o in all_vals if _close(val, o)] or \
                       [o for o in all_vals if display_match(val, raw, o, unit)]
            if not hits and unit:
                # 接頭辞の換算で一致する（0.001 mN と 1 μN）なら正しい読み取り
                conv = converted_match(val, unit, src_pairs) or converted_match(val, unit, all_pairs)
                if conv:
                    res["numbers_ok"] += 1
                    res.setdefault("converted", []).append({"read": raw, "source": conv})
                    continue
            if not hits:
                res["numbers_missing"].append(raw)
                continue
            res["numbers_ok"] += 1
            if not unit:
                continue
            table = units_of if in_scope else all_units_of
            src_units = set().union(*(table.get(o, set()) for o in hits))
            if unit in src_units:
                continue
            # 値の隣に単位が無い表（見出しに単位がある列など）は、範囲内に
            # その単位が書かれていれば良しとする
            if in_scope and _unit_in_text(unit, src):
                continue
            # 書式 % のセル（値 0.125・表示 12.5%）：同じ数字が別の列に別の単位で
            # あっても、% 表示として説明できるなら読み違いではない
            if unit == "%" and any(display_match(val, raw, o, "%") and not units_of.get(o)
                                   for o in src_vals):
                continue
            if not src_units and not in_scope:
                continue                      # 範囲外で単位の記載も無い：判断しない
            if src_units:
                src_label = "、".join(f"{val:g} {u}" for u in sorted(src_units))
            else:
                # 値の隣に単位が無い（見出しにある）表。同じ量の単位が原文にあれば示す（μN ⇔ pN など）
                su = split_unit(unit)
                near = sorted({p + su[1] for p in _PREFIX_FACTOR
                               if su and p + su[1] != unit and _unit_in_text(p + su[1], src)}) if su else []
                if not near:
                    # 原文に、この値の単位が書かれていない（単位がセルの表示形式や図の中にある場合）。
                    # 食い違いとは言えないので外さず、「原文では確かめられない」に入れる
                    res.setdefault("unit_unverified", []).append(raw)
                    continue
                src_label = "原文の単位：" + "・".join(near)
            res["unit_mismatch"].append({"read": raw, "source": src_label})

    # 語は書き起こし（readable_text）だけで見る。説明文は言い回しが変わるため
    terms: List[str] = []
    for line in lines:
        for t in _TERM_RE.findall(normalize_text(line)):
            if t not in terms:
                terms.append(t)
    for t in terms:
        if not (_term_in_source(t, squeezed) or _term_in_source(t, squeezed_all)):
            res["terms_missing"].append(t)
    res["terms_checked"] = len(terms)

    if not checked and not terms:
        res["reason"] = "照合できる数値・語がありません"
        return res
    res["mode"] = mode

    # ---- v3.34：行ごとに「原文と食い違う」のか「原文では確かめられない」のかを分ける ----
    verdict = _classify_lines(lines, src, whole, res, source_chars=src)
    res["remove_lines"] = verdict["remove"]
    res["contradicted"] = verdict["contradicted"]      # 読み違いと判断した表記（本文に使わせない）
    res["unverified"] = verdict["unverified"]          # 原文で確かめられない表記（残す）
    if verdict.get("unreliable"):
        res["unreliable"] = True
    if verdict["remove"] or res["unit_mismatch"]:
        res["status"] = CHECK_DIFF
    elif res["numbers_missing"] or res["terms_missing"] or res.get("unit_unverified"):
        res["status"] = CHECK_PART
    else:
        res["status"] = CHECK_OK
    return res


_ID_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9.\-]*[A-Za-z0-9]|[A-Za-z]")


def _line_tokens(line: str) -> Tuple[List[Tuple[float, str, str]], List[str]]:
    """行の中の数値（小さな整数は除く）と語（漢字・カタカナの連なり、英字の識別子）。"""
    n = normalize_text(line)
    nums = [(v, u, raw) for v, u, raw in _extract_numbers(n)
            if u or not (float(v).is_integer() and abs(v) < 10)]
    words = list(dict.fromkeys(_TERM_RE.findall(n) + [w for w in _ID_TOKEN_RE.findall(n) if len(w) >= 2]))
    return nums, words


def _classify_lines(lines: List[str], src: str, whole: str, res: Dict[str, Any],
                    *, source_chars: str) -> Dict[str, Any]:
    """読み取りの各行を分類する。

    - 単位の食い違いがある行 … 読み違い（外す）
    - 原文のある行に対応している（その行の語・数値の半分以上が、原文の同じ 1 行にある）のに、
      その行に無い数値を含む … 読み違い（外す）。表の 1 行を写し間違えた形
    - 原文のどの行にも対応しない … 原文では確かめられない（残す）。図の中の注記・
      貼られた画像の文字は、セルや文字層に無いのが普通
    - 原文に表があり、読み取りも表の形なのに、ほとんど原文と合わない（2 割未満）…
      表を取り違えて読んでいる。原文と合わない行は外す
    - 資料に無い種類の文字（簡体字・ハングルなど）を含む行 … 文字の誤認識（外す）
    """
    missing = set(res.get("numbers_missing") or [])
    mism = {m["read"] for m in res.get("unit_mismatch") or []}
    rows = []
    for ln in (src or "").split("\n"):
        if ln.strip() and not ln.lstrip().startswith("#") and not re.match(r"^\s*\|?\s*:?-{2,}", ln):
            rows.append(([v for v, _, _ in _extract_numbers(ln)],
                         re.sub(r"[\s|｜]+", "", ln)))

    info = []
    total = matched = 0
    for line in lines:
        nums, words = _line_tokens(line)
        miss_n = [raw for _, _, raw in nums if raw in missing]
        mis_u = [raw for _, _, raw in nums if raw in mism]
        sq_whole = re.sub(r"[\s|｜\-:：]+", "", whole)
        ok_words = [w for w in words if _term_in_source(w, sq_whole)]
        total += len(nums) + len(words)
        matched += (len(nums) - len(miss_n)) + len(ok_words)
        best = 0
        if miss_n and rows:
            for row_nums, row_sq in rows:
                cnt = sum(1 for v, u, raw in nums
                          if any(_close(v, o) or display_match(v, raw, o, u) for o in row_nums))
                cnt += sum(1 for w in words if w in row_sq)
                if cnt > best:
                    best = cnt
        n_tok = len(nums) + len(words)
        anchored = bool(miss_n) and best >= 2 and best / max(1, n_tok) >= 0.5
        info.append({"line": line, "nums": nums, "miss": miss_n, "mis_u": mis_u, "anchored": anchored,
                     "hits": (len(nums) - len(miss_n)) + len(ok_words)})

    # 読み取り全体が信用できないと言えるのは、次がすべて成り立つときだけ：
    #   - この範囲の原文に、数値の並ぶ表がある（2 行以上）
    #   - 読み取りも表の形をしている（数値が 2 個以上並ぶ行が 3 行以上）
    #   - それなのに、語・数値の 2 割未満しか原文と合わない
    # 図だけが写っているページ（注記・凡例が散らばる）は表の形にならないので、ここには入らない。
    # シートに表と図の両方がある場合、図のページの読み取りを捨てないための条件
    src_table_rows = sum(1 for nums, _ in rows if len(nums) >= 2)
    read_table_lines = sum(1 for line in lines if len(_line_tokens(line)[0]) >= 2)
    unreliable = (src_table_rows >= 2 and read_table_lines >= 3 and total >= 10
                  and matched / max(1, total) < 0.2)
    remove: List[str] = []
    contradicted: List[str] = list(mism)
    unverified: List[str] = []
    for it in info:
        foreign = foreign_chars(it["line"], source_chars)
        if it["mis_u"] or it["anchored"] or foreign or (
                unreliable and (len(it["nums"]) >= 2 or it["hits"] == 0)):
            remove.append(it["line"])
            for raw in it["miss"]:
                if raw not in contradicted:
                    contradicted.append(raw)
        else:
            for raw in it["miss"]:
                if raw not in unverified:
                    unverified.append(raw)
    # 説明文（key_facts・visual_summary）にだけ出てくる、原文に無い数値
    for raw in missing:
        if raw not in contradicted and raw not in unverified:
            (contradicted if unreliable else unverified).append(raw)
    for raw in res.get("unit_unverified") or []:
        if raw not in contradicted and raw not in unverified:
            unverified.append(raw)
    return {"remove": remove, "contradicted": contradicted, "unverified": unverified,
            "unreliable": unreliable}


_ALLOWED_EXTRA = set("²³⁰¹⁴⁵⁶⁷⁸⁹⁻⁺₀₁₂₃₄₅₆₇₈₉µ·•‐‑–—―…≒≈≦≧≤≥±×÷√∞∝∴∵°′″‰Ω㎛㎜㎝㎞㎎㎏㏄"
                     "①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳〜～﹣−－‘’“”«»‹›™®©")


def foreign_chars(text: str, source_text: str = "") -> List[str]:
    """日本語の技術文書に普通は出てこない文字（Shift_JIS の範囲に無い文字）のうち、
    原文にも無い物。画像の誤認識で混ざる簡体字・ハングル・アラビア文字などを拾う。"""
    src = set(source_text or "")
    out: List[str] = []
    for ch in str(text or ""):
        if ch.isascii() or ch in _ALLOWED_EXTRA or ch in src or ch.isspace():
            continue
        try:
            ch.encode("cp932")
        except UnicodeEncodeError:
            if ch not in out:
                out.append(ch)
    return out


def flagged_strings(check: Optional[Dict[str, Any]]) -> List[str]:
    """読み違いと判断した表記（単位の食い違い・原文の行と食い違う数値）。本文に使わせない。"""
    if not check:
        return []
    out = [m["read"] for m in check.get("unit_mismatch") or []]
    for x in check.get("contradicted") or []:
        if x not in out:
            out.append(x)
    return out


def unverified_strings(check: Optional[Dict[str, Any]]) -> List[str]:
    """原文では確かめられなかった表記（外さずに残す。図の中の注記など）。"""
    if not check:
        return []
    return list(check.get("unverified") or [])


def build_source_check(source_text: str, visual_evidence: List[Dict[str, Any]],
                       *, page_kinds: Tuple[str, ...] = ("page_render", "sheet_render")
                       ) -> Dict[str, Any]:
    """資料 1 つ分の照合結果。

    照合の対象は「ページやシートを丸ごと写した画像」の読み取り。資料に貼られた
    写真・グラフなどの埋込画像は、原文に同じ内容があるとは限らないので対象外
    （照合不可として数える）。
    """
    units = split_source_units(source_text)
    items: List[Dict[str, Any]] = []
    for v in visual_evidence or []:
        kind = v.get("asset_kind") or "embedded"
        entry = {"evidence_id": v.get("evidence_id", ""), "asset_kind": kind,
                 "page": v.get("page"), "sheet_name": v.get("sheet_name", "")}
        if kind not in page_kinds:
            entry.update({"status": CHECK_NA, "scope": "", "reason": "埋込画像（原文との照合対象外）"})
            items.append(entry)
            continue
        src, scope = source_for(units, sheet_name=v.get("sheet_name", ""), page=v.get("page"))
        # v3.34：判定の規則は資料の種類によらず同じ（行ごとに食い違い／確認不可を分ける）。
        # mode は記録のために残す
        mode = MODE_STRICT if (kind == "sheet_render" and scope.startswith("シート")) else MODE_LENIENT
        entry.update(check_item_against_source(
            v, src, mode=mode, fallback_text=units["all"] if scope != "資料全体" else ""))
        entry["scope"] = scope
        items.append(entry)

    pages = [i for i in items if i["asset_kind"] in page_kinds]
    return {
        "has_source": len((source_text or "").strip()) >= _MIN_SOURCE_CHARS,
        "unit_kind": "sheet" if units["sheets"] else ("page" if units["pages"] else "whole"),
        "items": items,
        "checked": len(pages),
        "ok": sum(1 for i in pages if i["status"] == CHECK_OK),
        "diff": sum(1 for i in pages if i["status"] == CHECK_DIFF),
        "part": sum(1 for i in pages if i["status"] == CHECK_PART),
        "na": sum(1 for i in pages if i["status"] == CHECK_NA),
    }


def apply_source_check(visual_evidence: List[Dict[str, Any]],
                       check: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """照合で原文に無いと分かった行を、読み取り結果から外す。

    原文がある範囲では原文が正しい（セルの値・文字として取り出した本文）。
    画像からの読み取りは、原文に無い内容（図の中の文字・注記など）を補うために使う。
    外した行は捨てずに返す（確認画面・品質報告で見せるため）。

    戻り値: (外した後の読み取り結果, 外した内容の一覧)
    """
    by_id = {i["evidence_id"]: i for i in check.get("items") or []}
    cleaned: List[Dict[str, Any]] = []
    removed: List[Dict[str, Any]] = []
    for v in visual_evidence or []:
        c = by_id.get(v.get("evidence_id", ""))
        d = dict(v)
        if c:
            d["source_check"] = c["status"]
        if c and unverified_strings(c):
            d["unverified"] = unverified_strings(c)
        bad = [normalize_text(x) for x in flagged_strings(c)] if c and c.get("status") == CHECK_DIFF else []
        rm_lines = set(c.get("remove_lines") or []) if c else set()
        if bad or rm_lines:
            def hit(line: str) -> bool:
                n = normalize_text(str(line))
                return any(b and b in n for b in bad)

            kept_lines, dropped = [], []
            for field in ("readable_text", "key_facts"):
                keep = []
                for line in d.get(field) or []:
                    gone = (str(line) in rm_lines) if field == "readable_text" else hit(line)
                    (dropped if gone else keep).append(line)
                d[field] = keep
                kept_lines += keep
            if hit(d.get("visual_summary", "")) or (c and c.get("unreliable")):
                dropped.append(d.get("visual_summary", ""))
                d["visual_summary"] = ""
            if dropped:
                removed.append({"evidence_id": v.get("evidence_id", ""), "scope": c.get("scope", ""),
                                "page": v.get("page"), "sheet_name": v.get("sheet_name", ""),
                                "lines": dropped, "flagged": flagged_strings(c)})
        cleaned.append(d)
    return cleaned, removed


def source_check_lines(check: Dict[str, Any], removed: Optional[List[Dict[str, Any]]] = None) -> List[str]:
    """画面・ログ用の 1 行要約。"""
    if not check:
        return []
    if not check.get("checked"):
        return ["原文との照合：対象のページ画像がありません"]
    parts = [f"一致 {check['ok']}", f"相違あり {check['diff']}"]
    if check.get("part"):
        parts.append(f"一部未確認 {check['part']}")
    parts.append(f"照合不可 {check['na']}")
    out = [f"原文との照合：画像 {check['checked']} 件（{'・'.join(parts)}）"]
    if removed:
        out.append(f"　原文と合わない読み取り {sum(len(r['lines']) for r in removed)} 行を外しました")
    if not check.get("has_source"):
        out.append("　原文（文字として取り出せた本文）が無いため、画像の読み取りは確かめられていません")
    return out


def source_check_prompt_block(check: Dict[str, Any],
                              removed: Optional[List[Dict[str, Any]]] = None,
                              *, label: str = "") -> str:
    """要約を書くモデルに渡す注意書き。外した表記・確認できなかった表記を並べる。"""
    if not check or not check.get("checked"):
        return ""
    head = f"【原文との照合{('：' + label) if label else ''}】"
    lines = [head + source_check_lines(check, removed)[0].split("：", 1)[-1]]
    flagged: List[str] = []
    for r in removed or []:
        for x in r.get("flagged") or []:
            if x not in flagged:
                flagged.append(x)
    if flagged:
        lines.append("次の表記は画像の読み違いと判断しました。本文に書かないでください："
                     + "、".join(flagged[:80]))
    unv: List[str] = []
    for i in check.get("items") or []:
        for x in unverified_strings(i):
            if x not in unv:
                unv.append(x)
    if unv:
        lines.append("次の表記は画像にだけあり、原文の文字では確認できませんでした。"
                     "使う場合は「図から読み取った値」と分かる書き方にしてください："
                     + "、".join(unv[:80]))
    if not check.get("has_source"):
        lines.append("この資料は原文の文字が取り出せていません。画像の読み取りだけが根拠です。")
    return "\n".join(lines)


def check_text_evidence(source_text: str, evidence: List[Dict[str, Any]],
                        *, origins: Tuple[str, ...] = ("text", "excel", "gap_fill")
                        ) -> Dict[str, Any]:
    """本文から抜き出した証拠の数値が、原文に実際にあるかを確かめる（精読モード）。

    証拠の抽出はモデルが行うので、転記の誤り・丸め・作った数値が混ざり得る。
    原文に無い数値は外さずに挙げるだけにする（言い換えや単位換算の可能性があるため）。
    台帳など資料の外から来た証拠は対象外。
    """
    src = normalize_text(source_text)
    if len(src.strip()) < _MIN_SOURCE_CHARS:
        return {"has_source": False, "checked": 0, "items": []}
    src_vals, _, src_pairs = _num_index(src)
    items: List[Dict[str, Any]] = []
    checked = 0
    for e in evidence or []:
        if (e.get("origin") or "text") not in origins:
            continue
        missing: List[str] = []
        for val, unit, raw in _extract_numbers(str(e.get("content", ""))):
            if not unit and float(val).is_integer() and abs(val) < 10:
                continue
            if any(_close(val, o) or display_match(val, raw, o, unit) for o in src_vals):
                continue
            if unit and converted_match(val, unit, src_pairs):
                continue
            if raw not in missing:
                missing.append(raw)
        checked += 1
        if missing:
            items.append({"evidence_id": e.get("evidence_id", ""), "numbers_missing": missing[:10]})
    return {"has_source": True, "checked": checked, "items": items}


def report_prompt_block(report: Dict[str, Any], *, id_prefix: str = "") -> str:
    """deep_read が残した page_report.json（version 2）から、要約を書くモデルへの
    注意書きを作る。案件では証拠 ID に資料の接頭辞（f01_ など）を付ける。"""
    if not report:
        return ""
    parts: List[str] = []
    sc = report.get("source_check") or {}
    if sc:
        b = source_check_prompt_block(sc, report.get("removed") or [])
        if b:
            parts.append(b)
    tc = report.get("text_check") or {}
    if tc.get("items"):
        parts.append("次の証拠の数値は原文に見当たりません（転記の誤り・換算の可能性）。"
                     "そのまま断定せず、原文にある値を優先してください："
                     + "；".join(f"{id_prefix}{i['evidence_id']}（{'、'.join(i['numbers_missing'][:4])}）"
                                for i in tc["items"][:30]))
    return "\n".join(parts)
