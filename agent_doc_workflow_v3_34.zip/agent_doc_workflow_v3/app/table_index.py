"""
原文の「どの数値が、何の値か」を引けるようにする索引（v3.34）。

## なぜ必要か

v3.33 までは、要約に出てくる数値を「原文のどこかに同じ数字があるか」だけで
確かめていた。実案件では数字は合っているのに対応が違う誤りが残った。

- 旧サンプル番号が「-」の 3 試料が、すべて「No.5」と書かれた
- 押込弾性率の値が「複合弾性率」として書かれた
- 浮動小数の端数（338.7872 と 338.78720000000004）が「値の違い」として比較された

数字だけでは「その値がどの試料の、どの項目の値か」が分からない。ここでは
原文の表を読み直し、数値 1 つごとに**同じ行の文字**と**同じ列の見出し**を
持たせる。試料名や項目名は決め打ちしない。表の形だけを使うので、Excel でも
PDF・PowerPoint・Word の表でも同じように働く。

- 表の中の数値 … 行（同じ行のセル全部）と見出し（同じ列の上にある文字）
  - 見出しが結合セルで空の場合は、見出し行の左隣の文字を引き継ぐ
- 文の中の数値 … その文（セル・段落）全体
- 自由に配置されたシート（表・図・説明文が混ざる）でも、数値の周りにある
  文字を拾うだけなので壊れない。対応が読み取れない数値は「値だけ確認」になる

この索引を使う場面：
1. モデルが出した測定記録（試料・条件・項目・値・単位）の確認と、原文に合わせた補正
2. 書き上がった文の「数値と項目・試料の対応」の確認
3. 資料間の比較の下ごしらえ（同じ値・同じ試料がどの資料にあるか）
4. 画像の読み取りが「原文と食い違う」のか「原文では確かめられない」のかの区別
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .deep_read import (_close, _extract_numbers, converted_match, display_match,
                        foreign_chars, normalize_text, split_source_units)

__all__ = ["SourceIndex", "NumCell", "build_index", "verify_record", "check_statement",
           "stats_by_item", "representative", "record_line", "source_units", "foreign_chars",
           "squeeze", "tokens", "item_key", "label_matches", "parse_value", "shown_unit"]

_SEP_ROW = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")
_TOKEN_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9.\-+]*|[一-龥々ァ-ヶーぁ-ん]+")
_HEADER_UNIT_RE = re.compile(r"[（(\[［]\s*([^（）()\[\]［］]{1,12})\s*[）)\]］]")
_BLANK = {"", "-", "—", "–", "―", "ー", "－", "/", "／", "n/a", "na", "none", "無し", "なし"}


def squeeze(text: str) -> str:
    return re.sub(r"[\s|｜]+", "", normalize_text(str(text or ""))).lower()


def tokens(text: str) -> List[str]:
    return [t.lower().strip(".-+") for t in _TOKEN_RE.findall(normalize_text(str(text or "")))
            if t.strip(".-+")]


def _has_digit(tok: str) -> bool:
    return any(ch.isdigit() for ch in tok)


def _is_blank(cell: str) -> bool:
    return cell.strip().lower() in _BLANK


def _single_number(cell: str) -> Optional[Tuple[float, str, str]]:
    """セル全体が 1 つの数値（単位付きも可）なら (値, 単位, 表記)。"""
    t = normalize_text(cell).strip()
    if not t:
        return None
    nums = _extract_numbers(t)
    if len(nums) != 1:
        return None
    val, unit, raw = nums[0]
    rest = t.replace(raw.strip(), "", 1).strip(" :：=＝~〜約±+")
    return (val, unit, raw.strip()) if not rest else None


def _is_prose(cell: str) -> bool:
    """見出しではなく文（説明・注記）と見るセル。列の見出しには積まない。"""
    t = cell.strip()
    return len(t) > 40 or "。" in t or t.startswith(("※", "注", "*"))


def _uniq(items: Iterable[str]) -> List[str]:
    out: List[str] = []
    for x in items:
        if x not in out:
            out.append(x)
    return out


#: 内部で正規化した単位を、報告書・モデルに見せる表記に戻す
_UNIT_SHOWN = {"degC": "℃"}


def shown_unit(unit: str) -> str:
    return _UNIT_SHOWN.get(unit, unit)


def _same_value(a: float, b: float) -> bool:
    """「同じ値」と言える差（浮動小数の端数だけを許す）。"""
    return a == b or abs(a - b) <= 1e-9 * max(abs(a), abs(b))


@dataclass
class NumCell:
    value: float
    unit: str                 # 値に付いている単位、無ければ見出しの単位
    raw: str
    unit_name: str            # シート名・ページ（「p.3」）・""（資料全体）
    row: List[str]            # 同じ行のセル（表）／その文（文中の数値）
    headers: List[str]        # 同じ列の見出し（近い順）
    kind: str = "table"       # table / text
    row_no: int = 0
    cell_text: str = ""       # 文中の数値の場合、その文（セル・行）
    row_labels: Optional[List[str]] = None            # 行の中の文字セル（行ごとに 1 回だけ作る）
    _ctx: Optional[str] = field(default=None, repr=False, compare=False)
    _toks: Optional[set] = field(default=None, repr=False, compare=False)

    def labels(self) -> List[str]:
        """行の中の、数値でないセル（試料名など）。"""
        if self.row_labels is None:
            self.row_labels = _uniq(c for c in self.row
                                    if c and not _is_blank(c) and _single_number(c) is None)
        return self.row_labels

    def context(self) -> str:
        if self._ctx is None:
            self._ctx = squeeze(" ".join([self.unit_name] + self.row + self.headers))
        return self._ctx

    def context_tokens(self) -> set:
        if self._toks is None:
            self._toks = set(tokens(" ".join([self.unit_name] + self.row + self.headers)))
        return self._toks

    def describe(self) -> str:
        """原文での位置づけ（報告用）。"""
        parts = []
        if self.labels():
            parts.append(" / ".join(self.labels()[:4]))
        if self.headers:
            parts.append(" ".join(reversed(self.headers[:3])))
        return "：".join(parts) or self.raw


@dataclass
class SourceIndex:
    cells: List[NumCell] = field(default_factory=list)
    units: Dict[str, str] = field(default_factory=dict)       # 単位名 → その原文
    order: List[str] = field(default_factory=list)

    def find(self, value: float, raw: str = "", unit: str = "",
             unit_name: Optional[str] = None) -> List[NumCell]:
        pool = [c for c in self.cells if unit_name is None or c.unit_name == unit_name]
        # 画像の読み取りの照合（0.1% まで許す）より厳しく見る。ここで緩いと 999.9 が 1000 の
        # セルに当たり、別の値の行・見出しで確認したことになる。表示の丸めは下で別に扱う
        hits = [c for c in pool if _same_value(value, c.value)]
        if not hits and raw:
            hits = [c for c in pool if display_match(value, raw, c.value, unit)]
        if not hits and unit:
            pairs = [(c.value, c.unit, c.raw) for c in pool]
            got = converted_match(value, unit, pairs)
            if got:
                hits = [c for c in pool if c.raw == got]
        return hits

    def numeric_units(self) -> List[str]:
        """数値を含む単位（シート・ページ）の名前。"""
        seen = []
        for c in self.cells:
            if c.unit_name not in seen:
                seen.append(c.unit_name)
        return seen


# ----------------------------------------------------------------------
# 原文を単位（シート／ページ／全体）に分け、表を読み直す
# ----------------------------------------------------------------------

def source_units(source_text: str) -> List[Tuple[str, str]]:
    """[(単位名, 原文)]。Excel はシート、PDF・PPT はページ、どちらも無ければ全体 1 つ。
    シートの後ろにある「主な数式」「グラフ」などの節は、最後に「その他」として付ける。"""
    u = split_source_units(source_text)
    out: List[Tuple[str, str]] = []
    if u["sheets"]:
        for name in u["sheet_order"]:
            out.append((name, u["sheets"][name]))
        used = "".join(u["sheets"].values())
        rest = []
        for block in re.split(r"(?m)^(?=#{1,3}\s)", source_text or ""):
            head = block.split("\n", 1)[0]
            if block.strip() and not re.match(r"#{1,3}\s*シート\s*[:：]", head) and block.strip() not in used \
                    and re.match(r"#{2,3}\s", head):
                rest.append(block.strip())
        if rest:
            out.append(("その他（数式・グラフの定義など）", "\n\n".join(rest)))
        return out
    if u["pages"]:
        return [(f"p.{n}", u["pages"][n]) for n in sorted(u["pages"])]
    return [("", source_text or "")] if (source_text or "").strip() else []


def _parse_grid(lines: List[str]) -> List[List[str]]:
    grid = []
    for ln in lines:
        if _SEP_ROW.match(ln):
            continue
        s = ln.strip()
        if s.startswith("|"):
            s = s[1:]
        if s.endswith("|"):
            s = s[:-1]
        grid.append([c.strip() for c in s.split("|")])
    width = max((len(r) for r in grid), default=0)
    return [r + [""] * (width - len(r)) for r in grid]


def _unit_from_headers(headers: List[str]) -> str:
    for h in headers:
        for m in _HEADER_UNIT_RE.finditer(normalize_text(h)):
            nums = _extract_numbers("1 " + m.group(1).strip())
            if nums and nums[0][1]:
                return nums[0][1]
    return ""


def _index_grid(idx: SourceIndex, grid: List[List[str]], name: str, row_no: int, limit: int = 4) -> int:
    """表 1 つを索引に入れる。見出しは上から順に列ごとに積んでいく（行数に比例する時間で済む）。

    ある値の見出し＝同じ列で、その値より上にある文字セル（近い順に limit 個まで）。
    横に結合された見出し（文字だけの行で、その列が空で、その列の上に何も無い）は、
    同じ行の左隣で最も近い文字を引き継ぐ。上に自分の見出しがある列の空欄は
    「下の段の見出しが無い」だけなので、隣から引き継がない。
    """
    width = max((len(r) for r in grid), default=0)
    heads: List[List[str]] = [[] for _ in range(width)]
    seen_above = [False] * width
    for row in grid:
        row_no += 1
        parsed = [(_single_number(c) if c else None) for c in row]
        is_text = [bool(c) and not _is_blank(c) and parsed[i] is None for i, c in enumerate(row)]
        labels = _uniq(c for i, c in enumerate(row) if is_text[i])
        row_list = list(row)
        for c, cell in enumerate(row):
            if not cell:
                continue
            if parsed[c]:
                val, unit, raw = parsed[c]
                hs = heads[c][:limit]
                idx.cells.append(NumCell(val, unit or _unit_from_headers(hs), raw, name, row_list, hs,
                                         "table", row_no, "", labels))
            elif any(ch.isdigit() for ch in cell):
                # 文字セルの中の数値（「最大荷重は 1 μN とした」「ν=0.3」）
                for val, unit, raw in _extract_numbers(cell):
                    idx.cells.append(NumCell(val, unit, raw, name, row_list, heads[c][:limit],
                                             "text", row_no, cell, labels))
        # 見出しの行と言えるのは、文字のセルが 2 つ以上並ぶ行。文字が 1 つだけの行は
        # シートの題名・説明文・注記であることが多く、右の列へ引き継ぐと、離れた所にある
        # 表の見出しに題名が混ざる（表・図・説明文を自由に配置したシート）
        header_like = sum(is_text) >= 2 and not any(parsed)
        for c, cell in enumerate(row):
            if is_text[c]:
                if not _is_prose(cell):
                    heads[c].insert(0, cell)
            elif header_like and not cell and not seen_above[c]:
                for cc in range(c - 1, -1, -1):
                    if is_text[cc]:
                        heads[c].insert(0, row[cc])
                        break
            if cell:
                seen_above[c] = True
    return row_no


def build_index(source_text: str) -> SourceIndex:
    idx = SourceIndex()
    for name, text in source_units(source_text):
        idx.units[name] = text
        idx.order.append(name)
        lines = text.split("\n")
        i = 0
        row_no = 0
        while i < len(lines):
            ln = lines[i]
            if ln.lstrip().startswith("|"):
                j = i
                while j < len(lines) and lines[j].lstrip().startswith("|"):
                    j += 1
                row_no = _index_grid(idx, _parse_grid(lines[i:j]), name, row_no)
                i = j
                continue
            if ln.strip() and not ln.lstrip().startswith("#"):
                row_no += 1
                if any(ch.isdigit() for ch in ln):
                    for val, unit, raw in _extract_numbers(ln):
                        idx.cells.append(NumCell(val, unit, raw, name, [ln.strip()], [], "text", row_no,
                                                 ln.strip()))
            i += 1
    return idx


# ----------------------------------------------------------------------
# 測定記録の確認
# ----------------------------------------------------------------------

def label_matches(label: str, cell: NumCell) -> bool:
    """モデルが書いた試料名・項目名が、その数値の行・見出しと合うか。

    - 番号を含む語（No.5、12、A-3 など）は、行・見出しに同じ語が無ければ不一致
      （番号の取り違えは意味が変わるため）
    - それ以外の語は 6 割以上が行・見出しに含まれていれば一致
    """
    toks = [t for t in tokens(label) if t]
    if not toks:
        return True
    ctx = cell.context()
    ctx_toks = cell.context_tokens()
    for t in toks:
        if _has_digit(t) and t not in ctx_toks:
            return False
    found = sum(1 for t in toks if t in ctx_toks or t in ctx)
    return found / len(toks) >= 0.6


def parse_value(value: Any, unit: str = "") -> Optional[Tuple[float, str, str]]:
    text = normalize_text(f"{value} {unit}".strip()) if unit and str(unit) not in str(value) \
        else normalize_text(str(value))
    nums = _extract_numbers(text)
    if not nums:
        return None
    return nums[0]


def verify_record(rec: Dict[str, str], index: SourceIndex, *, unit_name: Optional[str] = None,
                  figure_text: str = "") -> Dict[str, Any]:
    """測定記録 1 件を原文で確かめる。

    status:
      ok        … 値が原文にあり、試料・項目もその行・見出しと合う
      corrected … 値は原文にあるが、試料または項目が行・見出しと合わない。
                  原文の行・見出しの表記に直した（どこを直したかは fixed に残す）
      figure    … 原文の文字には無いが、画像の読み取りにはある（図から読み取った値）
      text      … 数値でない記録（「良好」など）。確認の対象外
      missing   … 原文にも画像の読み取りにも無い。使わない
    """
    out = dict(rec)
    pv = parse_value(rec.get("value", ""), rec.get("unit", ""))
    if pv is None:
        out["status"] = "text"
        return out
    val, unit, raw = pv
    out["number"] = val
    cands = (index.find(val, raw, unit, unit_name) if unit_name is not None else []) \
        or index.find(val, raw, unit)
    if not cands:
        if figure_text and any(_close(val, v) or display_match(val, raw, v, unit)
                               for v, _, _ in _extract_numbers(figure_text)):
            out["status"] = "figure"
        else:
            out["status"] = "missing"
        return out

    sample, item = rec.get("sample", ""), rec.get("item", "")
    scored = []
    for c in cands:
        s_ok = label_matches(sample, c)
        i_ok = label_matches(item, c)
        scored.append((s_ok + i_ok, s_ok, i_ok, c))
    scored.sort(key=lambda x: -x[0])
    score, s_ok, i_ok, cell = scored[0]
    out["where"] = cell.unit_name
    if not out.get("unit") and cell.unit:
        out["unit"] = shown_unit(cell.unit)
    fixed = []
    # 条件（ν=0.3 など）：行・見出しと合わず、見出しが 2 段以上あるなら、項目以外の見出しを条件とする
    cond = rec.get("condition", "")
    if cond and cell.kind == "table" and len(cell.headers) >= 2 and not label_matches(cond, cell):
        ik = item_key(item)
        others = [h for h in cell.headers
                  if not (ik and (ik in item_key(h) or item_key(h) in ik))]
        new = " ".join(reversed(others[:2])) if others and len(others) < len(cell.headers) else ""
        if new:
            # 同じ種類の条件（ν=0.3 と ν=0.4）なら置き換え、別の種類（荷重など）なら見出しの条件を足す
            shape = lambda t: re.sub(r"[\d.\s]+", "", normalize_text(t)).lower()   # noqa: E731
            a, b = shape(cond), shape(new)
            if not (a and b and (a in b or b in a)):
                new = f"{new}、{cond}"
            fixed.append({"field": "condition", "from": cond, "to": new})
            out["condition"] = new
    if s_ok and i_ok:
        out["status"] = "corrected" if fixed else "ok"
        if fixed:
            out["fixed"] = fixed
        return out
    # 値のセルが 1 つに決まる（または最良の候補が片方は合っている）なら、原文の表記に直す
    if len(cands) > 1 and score == 0:
        out["status"] = "missing"
        out["reason"] = "値は原文にあるが、試料・項目のどちらも合う行が無い"
        return out
    if cell.kind == "text":
        # 文の中の数値：項目名を作り直さず、原文の文をそのまま使う
        out["quote"] = cell.cell_text[:160]
        fixed.append({"field": "item" if not i_ok else "sample",
                      "from": item if not i_ok else sample, "to": "（原文の文を引用）"})
    else:
        if not s_ok:
            new = " / ".join(cell.labels()[:3])
            fixed.append({"field": "sample", "from": sample, "to": new})
            out["sample"] = new
        if not i_ok:
            new = " ".join(reversed(cell.headers[:3])) if cell.headers else ""
            fixed.append({"field": "item", "from": item, "to": new})
            out["item"] = new
    out["status"] = "corrected"
    out["fixed"] = fixed
    return out


def record_line(r: Dict[str, Any]) -> str:
    if r.get("quote"):
        return r["quote"]
    head = r.get("sample", "")
    if r.get("condition"):
        head = f"{head}（{r['condition']}）" if head else r["condition"]
    body = " ".join(x for x in (r.get("item", ""), str(r.get("value", "")), r.get("unit", ""))
                    if x and (x != r.get("unit", "") or str(r.get("unit", "")) not in str(r.get("value", ""))))
    line = f"{head}：{body}" if head else body
    return line + ("（図から読み取り）" if r.get("status") == "figure" else "")


# ----------------------------------------------------------------------
# 集計（項目ごとの範囲）
# ----------------------------------------------------------------------

def item_key(item: str) -> str:
    """項目名の比較用の形（単位の括弧と空白を除く）。"""
    t = _HEADER_UNIT_RE.sub("", normalize_text(str(item or "")))
    return re.sub(r"[\s　:：]+", "", t).lower()


def stats_by_item(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    groups: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    names: Dict[Tuple[str, str], str] = {}
    for r in records:
        if "number" not in r or r.get("status") not in ("ok", "corrected", "figure"):
            continue
        k = (item_key(r.get("item", "")), r.get("unit", ""))
        groups.setdefault(k, []).append(r)
        names.setdefault(k, r.get("item", ""))
    out = []
    for k, rs in groups.items():
        rs2 = sorted(rs, key=lambda r: r["number"])
        lo, hi = rs2[0], rs2[-1]
        samples = []
        for r in rs:
            if r.get("sample") and r["sample"] not in samples:
                samples.append(r["sample"])
        out.append({"item": names[k], "unit": k[1], "count": len(rs),
                    "min": {"value": lo.get("value"), "sample": lo.get("sample", ""),
                            "condition": lo.get("condition", "")},
                    "max": {"value": hi.get("value"), "sample": hi.get("sample", ""),
                            "condition": hi.get("condition", "")},
                    "samples": samples[:30]})
    out.sort(key=lambda s: -s["count"])
    return out


def representative(records: List[Dict[str, Any]], limit: int = 60) -> List[Dict[str, Any]]:
    """文を書くモデルに渡す代表的な記録。全部で limit 件まで。項目ごとに最小・最大・中央と、
    残りは試料が偏らないように拾う。"""
    good = [r for r in records if r.get("status") in ("ok", "corrected", "figure") and "number" in r]
    if len(good) <= limit:
        return good
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in good:
        groups.setdefault(item_key(r.get("item", "")), []).append(r)
    per = max(3, limit // max(1, len(groups)))
    picked: List[Dict[str, Any]] = []
    for rs in groups.values():
        rs2 = sorted(rs, key=lambda r: r["number"])
        cand = [rs2[0], rs2[-1], rs2[len(rs2) // 2]]
        seen_samples = set()
        for r in rs:
            if r.get("sample") not in seen_samples:
                seen_samples.add(r.get("sample"))
                cand.append(r)
        uniq = []
        for r in cand:
            if not any(r is u for u in uniq):
                uniq.append(r)
        picked += uniq[:per]
    return picked[:limit]


# ----------------------------------------------------------------------
# 表の列ごとの集計（プログラムが原文から直接作る。モデルは通さない）
# ----------------------------------------------------------------------

def _is_id_like(cells: List[NumCell]) -> bool:
    """通し番号・面番号のような列（単位が無く、整数だけ）。集計の対象にしない。"""
    return all(not c.unit and float(c.value).is_integer() for c in cells)


def column_stats(index: SourceIndex, unit_name: Optional[str] = None,
                 limit: int = 40) -> List[Dict[str, Any]]:
    """見出しごとの件数・最小・最大。最小・最大には、その行の文字（試料名など）を添える。"""
    groups: Dict[Tuple[str, Tuple[str, ...]], List[NumCell]] = {}
    for c in index.cells:
        if c.kind != "table" or not c.headers:
            continue
        if unit_name is not None and c.unit_name != unit_name:
            continue
        groups.setdefault((c.unit_name, tuple(c.headers[:3])), []).append(c)
    out = []
    for (uname, headers), cells in groups.items():
        if len(cells) < 2 or _is_id_like(cells):
            continue
        cs = sorted(cells, key=lambda c: c.value)
        lo, hi = cs[0], cs[-1]
        out.append({"where": uname, "item": " ".join(reversed(headers)),
                    "unit": shown_unit(lo.unit or hi.unit),
                    "count": len(cells),
                    "min": {"value": lo.raw, "row": " / ".join(lo.labels()[:3])},
                    "max": {"value": hi.raw, "row": " / ".join(hi.labels()[:3])}})
    out.sort(key=lambda d: -d["count"])
    return out[:limit]


def row_labels(index: SourceIndex, unit_name: Optional[str] = None) -> List[str]:
    """表の行に書かれている文字（試料名など）。出てきた順、重複なし。"""
    seen: List[str] = []
    for c in index.cells:
        if c.kind != "table" or (unit_name is not None and c.unit_name != unit_name):
            continue
        for lab in c.labels():
            if len(squeeze(lab)) >= 2 and lab not in seen:
                seen.append(lab)
    return seen


# ----------------------------------------------------------------------
# 資料どうしの下ごしらえ：同じ行の文字・同じ値がどの資料にあるか
# ----------------------------------------------------------------------

def _significant(c: NumCell) -> bool:
    """偶然の一致になりにくい値（単位付き、または有効 3 桁以上）。"""
    digits = re.sub(r"[^0-9]", "", c.raw.split()[0] if c.raw.split() else c.raw).lstrip("0")
    return bool(c.unit) or len(digits) >= 3


def cross_file_base(indices: Dict[str, SourceIndex], sources: Dict[str, str],
                    *, max_examples: int = 8, max_labels: int = 40) -> Dict[str, Any]:
    """資料間の比較の材料を、原文から機械的に拾う。

    - labels … 表の行の文字（試料名など）ごとに、それが出てくる資料
    - same   … 2 つの資料に、同じ行の文字・同じ見出しで同じ値がある組（引き継がれたデータ）
    - differ … 同じ行の文字・同じ見出しなのに値が違う組
    モデルにはこれを材料として渡し、文章にさせる。「片方にしか無い」という記述の確認にも使う。
    """
    files = list(indices)
    sq_src = {f: squeeze(sources.get(f, "")) for f in files}
    presence: Dict[str, List[str]] = {}
    for f in files:
        for lab in row_labels(indices[f]):
            k = squeeze(lab)
            if k in presence or k.isdigit():
                continue
            presence[k] = [g for g in files if k in sq_src[g]]
    names = {}
    for f in files:
        for lab in row_labels(indices[f]):
            names.setdefault(squeeze(lab), lab)
    shared = [{"label": names[k], "files": fs} for k, fs in presence.items() if len(fs) >= 2]
    only = {f: [names[k] for k, fs in presence.items() if fs == [f]][:max_labels] for f in files}

    def keyed(idx: SourceIndex) -> Dict[Tuple[str, str], List[NumCell]]:
        d: Dict[Tuple[str, str], List[NumCell]] = {}
        for c in idx.cells:
            if c.kind != "table" or not c.headers or not c.labels() or not _significant(c):
                continue
            d.setdefault((squeeze(" ".join(c.labels()[:3])), squeeze(" ".join(c.headers[:3]))), []).append(c)
        return d

    keyed_by = {f: keyed(indices[f]) for f in files}
    same, differ = [], []
    for i, a in enumerate(files):
        for b in files[i + 1:]:
            n_same = n_diff = 0
            ex_same, ex_diff = [], []
            for k, ca in keyed_by[a].items():
                cb = keyed_by[b].get(k)
                if not cb:
                    continue
                for x in ca:
                    if any(_same_value(x.value, y.value) for y in cb):
                        n_same += 1
                        if len(ex_same) < max_examples:
                            ex_same.append(f"{x.describe()} {x.raw}")
                    elif len(ca) == 1 and len(cb) == 1:
                        n_diff += 1
                        if len(ex_diff) < max_examples:
                            ex_diff.append(f"{x.describe()}：『{a}』{x.raw} ／『{b}』{cb[0].raw}")
            if n_same:
                same.append({"files": [a, b], "count": n_same, "examples": ex_same})
            if n_diff:
                differ.append({"files": [a, b], "count": n_diff, "examples": ex_diff})
    return {"labels_in_several_files": shared[:max_labels], "labels_in_one_file": only,
            "same_values": same, "different_values": differ, "_presence": presence}


def only_claim_problem(text: str, files_named: List[str], presence: Dict[str, List[str]]) -> str:
    """「〜は『A』にだけある」という記述で、その語が他の資料にもあれば、その語を返す。"""
    if len(files_named) != 1 or not re.search(r"のみ|だけ|にしか|に限|固有|独自", text):
        return ""
    sq = squeeze(text)
    for k in sorted(presence, key=len, reverse=True):
        if len(k) >= 3 and k in sq and any(f != files_named[0] for f in presence[k]):
            return k
    return ""


# ----------------------------------------------------------------------
# 書き上がった文の確認：数値と、その前に書かれた項目・試料が合っているか
# ----------------------------------------------------------------------

def _term(t: str) -> str:
    return squeeze(_HEADER_UNIT_RE.sub("", t))


def statement_vocab(index: SourceIndex) -> Dict[str, Any]:
    """表の行の文字（試料名など）と、列の見出し（項目・条件）。見出しは段（値に近い順）も持つ。"""
    rows: set = set()
    heads: Dict[str, set] = {}
    for c in index.cells:
        if c.kind != "table":
            continue
        for d, h in enumerate(reversed(c.headers)):      # 段は上から数える（列によって段数が違うため）
            k = _term(h)
            if len(k) >= 2 and not k.replace(".", "").isdigit():
                heads.setdefault(k, set()).add(d)
        for t in c.labels():
            k = _term(t)
            if len(k) >= 2 and not k.replace(".", "").isdigit():
                rows.add(k)
    rows -= set(heads)
    return {"rows": rows, "heads": heads,
            "all": sorted(rows | set(heads), key=len, reverse=True)}


def _mentions(text_sq: str, vocab: List[str]) -> List[Tuple[int, str]]:
    """文中に出てくる語と位置（長い語を優先し、重なる短い語は拾わない）。"""
    taken = [False] * len(text_sq)
    out = []
    for v in vocab:
        start = 0
        while True:
            p = text_sq.find(v, start)
            if p < 0:
                break
            if not any(taken[p:p + len(v)]):
                out.append((p, v))
                for k in range(p, p + len(v)):
                    taken[k] = True
            start = p + 1
    return sorted(out)


def _cell_ok(gap: List[str], c: NumCell, vocab: Dict[str, Any]) -> List[str]:
    """値のセル c に対して、手前に書かれた語が食い違っていれば、その語を返す。

    - 行の文字（試料名）：書かれた語のどれか 1 つがその行にあればよい
      （「A は B より大きく 12.3」のように、比べる相手の名前も手前に出るため）
    - 見出し（項目・条件）：その行・見出しに無い語が、セルの見出しと同じ段の別の見出しで、
      かつセル自身のその段の見出しが文に書かれていなければ食い違い
      （「複合弾性率は ν=0.3 で 308」→ 値のセルは「押込弾性率」の列）
    """
    ctx = c.context()
    wrong: List[str] = []
    row_m = [g for g in gap if g in vocab["rows"]]
    if row_m and not any(g in ctx for g in row_m):
        wrong += row_m
    else:
        # 番号を含む語（No.5、A-3 など）は取り違えると別の試料になるので、行に無ければ食い違い
        row_toks = c.context_tokens()
        wrong += [g for g in row_m if _has_digit(g) and g not in ctx and g not in row_toks]
    own = [_term(h) for h in reversed(c.headers)]
    for g in gap:
        if g not in vocab["heads"] or g in ctx:
            continue
        depths = vocab["heads"][g]
        clash = [d for d in depths if d < len(own)]
        if not clash:
            continue
        if any(not any(own[d] and (own[d] in x or x in own[d]) for x in gap) for d in clash):
            wrong.append(g)
    return wrong


def check_statement(text: str, index: SourceIndex, vocab: Optional[Dict[str, Any]] = None
                    ) -> List[Dict[str, str]]:
    """文に書かれた数値が、原文の表での位置づけ（行の文字・列の見出し）と食い違って
    いないかを調べる。

    数値の手前（同じ文の中で、1 つ前の数値より後ろ。無ければ直前の 1 語）に書かれた
    見出し・行の文字を、その数値の説明とみなす。原文でその値を持つセルのどれを取っても
    説明と食い違うなら、食い違いとして返す。
    - 原文の表に無い数値（図から読み取った値・文中の値）は、ここでは判断しない
    - 手前に見出し・行の文字が 1 つも無い数値も判断しない
    """
    cells = [c for c in index.cells if c.kind == "table"]
    if not cells:
        return []
    vocab = vocab if vocab is not None else statement_vocab(index)
    problems: List[Dict[str, str]] = []
    for sent in re.split(r"(?<=[。\n])", str(text or "")):
        if not sent.strip():
            continue
        sq = squeeze(sent)
        ment = _mentions(sq, vocab["all"])
        if not ment:
            continue
        prev_end = 0
        cursor = 0
        for val, unit, raw in _extract_numbers(sent):
            pos = sq.find(squeeze(raw), cursor)
            if pos < 0:
                continue
            cursor = pos + len(squeeze(raw))
            if any(p <= pos < p + len(v) for p, v in ment):
                continue          # 見出しの一部になっている数字（「ν=0.3」の 0.3 など）は値ではない
            gap = [v for p, v in ment if prev_end <= p < pos]
            if not gap:
                gap = [v for p, v in ment if p < pos][-1:]
            small = not unit and float(val).is_integer() and abs(val) < 10
            if not small:
                prev_end = cursor
            if small or not gap:
                continue
            cands = [c for c in cells if _same_value(val, c.value) or display_match(val, raw, c.value, unit)]
            if not cands:
                continue
            results = [(_cell_ok(gap, c, vocab), c) for c in cands]
            if any(not w for w, _ in results):
                continue
            wrong, best = min(results, key=lambda wc: len(wc[0]))
            problems.append({"number": raw, "said": "・".join(wrong), "source": best.describe(),
                             "where": best.unit_name})
    return problems
