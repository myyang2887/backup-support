"""
案件の三段構え — 資料ごとの分析 → 資料間の比較 → 「判明した事実」の欄。

## 流れ（v3.34）

1. analyze_files … 資料 1 件を、範囲（Excel はシート、PDF・PowerPoint はページ、
   どちらも無ければ全体）ごとに整理してから、資料としての分析にまとめる。
     a. 範囲ごとの整理（モデル）：何が書かれているか、代表的な値、文章で書かれた
        事実、図が示していること
     b. 表の列ごとの集計（プログラム）：原文の全行から、見出しごとの件数・最小・最大
     c. 資料としての分析（モデル）：a と b を材料に、分析として文章にする
     d. 確認（プログラム）：数値がその資料にあるか、数値と項目・試料の対応が原文の
        表と合っているか、資料に無い種類の文字が混ざっていないか、数値の羅列に
        なっていないか、どの範囲も取り上げられているか
2. compare_files … 原文から機械的に拾った対応（同じ試料がどの資料にあるか、同じ値・
   違う値）を材料に、資料どうしの関係を文章にする。「片方にしか無い」は原文で確かめる。
3. case_findings … 「調査・対応により判明した事実」の欄を組み立てる。
   資料ごとの分析と資料間の比較は 1・2 の結果をそのまま使い（書き直さない）、
   案件としての結論だけをモデルに書かせる。

## これまでの経緯

- v3.32：三段構えを入れた。資料ごとの分析は「測定値を全部書き写す」形だった
- v3.33：モデルの出力の形が違うだけで分析が捨てられていたのを直した
- v3.34：実案件で次の誤りが残った
    - 数字は合っているのに、試料・項目との対応が違う（旧サンプル番号の取り違え、
      ある項目の値を別の項目として記述）
    - 長い表 1 枚が分析を占め、同じ資料の別のシートが抜けた
    - 浮動小数の端数を「値の違い」として比較した。他の資料にもあるデータを
      「この資料にだけある」と書いた
    - 1 項目に数十個の数値が並び、読める分析になっていなかった
  → 数値を「どの行の、どの見出しの値か」まで原文の表で確かめる（table_index）。
    測定値の書き写しはやめ、全行の集計はプログラムが作る。モデルには分析だけを書かせる。
    書き直しの回数を減らす（資料ごとの記述は、その資料の分析をそのまま使う）。

資料の種類・試料名・項目名は決め打ちしない。表の形（行と見出し）だけを使う。
表が無い資料（図と短い説明だけのシート、文章中心の PDF）では、表に基づく確認は
働かず、数値が資料にあるかどうかと画像の読み取りとの照合だけになる。
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field, ValidationError

from .config import AppConfig
from .contract import VisualEvidence, schema_skeleton
from .deep_read import (_extract_numbers, _name_key, foreign_chars, report_prompt_block,
                        unsupported_numbers)
from .evidence import visual_to_pack
from .llm_coerce import (_role_of, coerce_flat, describe, dumps, is_empty, to_list, to_text,
                         unwrap)
from .table_index import (SourceIndex, _same_value, build_index, check_statement, column_stats,
                          cross_file_base, only_claim_problem, record_line, row_labels,
                          source_units, squeeze, statement_vocab, verify_record)

CASE_ANALYSIS_VERSION = "3.34"

#: 「判明した事実」の各項目の頭に付ける目印。テンプレートがこれで見出しを分ける。
TAG_FILE = "【資料別】"
TAG_COMPARE = "【資料間】"
TAG_CONCLUSION = "【結論】"
CONCLUSION_KINDS = ("資料の結論", "データから読み取れること", "前提・制約", "未解決の点")

ANALYSIS_FILE = "file_analysis.json"
COMPARISON_FILE = "case_comparison.json"
FINDINGS_REPORT_FILE = "case_findings_report.json"

FIGURE_UNIT = "図・画像"


# ----------------------------------------------------------------------
# 出力の形（LLM との境界）
# ----------------------------------------------------------------------

class Record(BaseModel):
    sample: str = ""
    condition: str = ""
    item: str = ""
    value: str = ""
    unit: str = ""


class UnitAnalysis(BaseModel):
    summary: str = ""
    highlights: List[Record] = Field(default_factory=list)
    notes: List[str] = Field(default_factory=list)
    figures: List[str] = Field(default_factory=list)


class FileAnalysis(BaseModel):
    document_type: str = ""
    date_or_version: str = ""
    purpose: str = ""
    points: List[str] = Field(default_factory=list)
    conclusions: List[str] = Field(default_factory=list)
    limitations: List[str] = Field(default_factory=list)
    open_points: List[str] = Field(default_factory=list)


class CaseComparison(BaseModel):
    relations: List[str] = Field(default_factory=list)
    common: List[str] = Field(default_factory=list)
    added: List[str] = Field(default_factory=list)
    differences: List[str] = Field(default_factory=list)
    not_comparable: List[str] = Field(default_factory=list)


class ConclusionItem(BaseModel):
    kind: str = ""
    text: str = ""


class CaseConclusions(BaseModel):
    conclusions: List[ConclusionItem] = Field(default_factory=list)


#: 資料間の比較の各欄を、報告書の 1 行にするときの頭の言葉
COMPARE_LABELS = (("relations", "資料の関係"), ("common", "共通点"), ("added", "一方にだけある内容"),
                  ("differences", "違い"), ("not_comparable", "そのまま比べられない点"))


# ----------------------------------------------------------------------
# プロンプト
# ----------------------------------------------------------------------

UNIT_SYSTEM = """あなたは技術資料を読み、内容を正確に整理する担当です。
渡すのは、1 件の資料の一部（シート・ページなど）です。
この範囲に書かれていることだけを整理してください。

JSON のみを出力してください。

各項目の書き方：
- summary：この範囲に何が書かれているかを 1〜2 文で（何の表・図か、対象は何か）。
- highlights：この範囲を代表する値・重要な値を、多くても 15 件。表のすべての値を書く必要は
  ありません（列ごとの範囲は別に集計して渡しています）。1 件は表の 1 つの値です。
  - sample：試料名・番号（その値と同じ行に書かれている表記のまま）
  - condition：その値の条件（その値の列や行に書かれている物。無ければ空文字）
  - item：測定項目（その値の列の見出しの表記のまま）
  - value：値（原文の数字のまま）
  - unit：単位（見出しや欄外に書かれている場合はそこから取る）
- notes：文章で書かれている事実。結論・判断、前提、試験や解析の条件、注意書き、
  検討中・未完了の点など。1 項目に 1 つの内容。
- figures：図・グラフ・画像が示していること（何の図か、読み取れる傾向）。

守ること：
- 原文に無いことを書かない。分からない項目は空にする（空文字・空配列）。
- 試料名・項目名・条件・値の組み合わせを変えない。同じ行・同じ列にある物だけを 1 件にする。
- 項目名を言い換えない。見出しに書かれている言葉を使う。
- 画像からの読み取りにだけある値は highlights に入れず、figures に書く。
- 「原文との照合」の注意書きがある場合は、それに従う。"""


FILE_SYSTEM = """あなたは技術資料の内容を、読み手が判断に使える形にまとめる担当です。
1 件の資料を範囲（シート・ページ）ごとに整理した結果と、表の列ごとの集計を渡します。
この資料から分かることを、分析としてまとめてください。数値を書き写す作業ではありません。

JSON のみを出力してください。

各項目の書き方：
- document_type：資料の種類（測定結果の表、解析報告書、打ち合わせ資料、依頼書 など）。
- date_or_version：資料に書かれている日付・版。書かれていなければ空文字。
- purpose：この資料が何のために作られたか。分からなければ空文字。
- points：この資料から分かる事実。次の観点で、1 項目に 1 つの内容を書く。
  ・何を、どの試料・条件で測った（解析した）か
  ・項目ごとの値の範囲と、代表的な値（どの試料・条件の値かを添える）
  ・試料や条件による違い・傾向
  ・図やグラフが示していること
  1 項目は 1〜3 文。数値は 1 項目に多くても 6 個まで。値を並べるだけの項目は書かない。
  内容のある範囲（シート・ページ）は、すべて取り上げる。
- conclusions：資料自身が述べている結論・判断。
- limitations：資料に書かれている前提・条件の制約・注意書き。
- open_points：資料からは分からない点、検討中・未完了と書かれている点。

守ること：
- 渡した材料に無いことを書かない。数値を計算し直さない。
- 桁の多い値は、有効 4〜5 桁に丸めて「約」を付けてよい。
- 試料名・項目名・条件・値の組み合わせを変えない。項目名を言い換えない。
- 画像からの読み取りにだけある値を使うときは、「図から読み取った値」と分かるように書く。
- 各項目は 1 つの文字列にする。"""


COMPARE_SYSTEM = """あなたは複数の資料を突き合わせる担当です。
同じ案件フォルダに入っている資料について、1 件ずつまとめた分析と、原文から機械的に拾った
対応（同じ試料名がどの資料にあるか、同じ値・違う値）を渡します。
資料どうしの関係・共通点・違いを整理してください。

JSON のみを出力してください。

各項目の書き方（資料名は『』で囲む）：
- relations：資料どうしの関係。「速報と最終報告」「測定データとその報告書」
  「同じ測定の別条件」などを、内容と日付から判断して書く。後の資料が前の資料に
  何を足したか（測定の追加、解釈・結論、条件の説明）も書く。
- common：複数の資料に共通して書かれている内容と、それがどの資料にあるか。
  同じ値が引き継がれている場合は、その旨を書く（値を 1 つずつ並べない）。
- added：ある資料にだけ書かれている内容と、その資料名。
  「原文から機械的に拾った対応」で他の資料にもある試料は、ここに書かない。
- differences：同じ試料・同じ項目・同じ条件で、値や結論が違う点。両方の値を資料名付きで書く。
  どちらが正しいかは決めない。
- not_comparable：試料・条件・項目の種類が違うため、そのままでは比べられない点と、
  何をそろえれば比べられるか。

守ること：
- 渡した材料に無いことを書かない。数値は材料にある表記のまま使う。
- 条件や項目が違う値どうしを「違い」として比べない。
- 各項目は 1 つの文字列にする。"""


CONCLUSION_SYSTEM = """あなたは案件の要約のうち「案件としての結論」を書く担当です。
資料ごとの分析と、資料間の比較を渡します。案件全体として言えることをまとめてください。

JSON のみを出力してください。conclusions の各項目は kind と text を持ちます。
kind は次の 4 つのどれかにします。
- 資料の結論：資料に結論・判断として書かれていること
- データから読み取れること：値から直接言えること（比較・傾向）。資料に無い推測は書かない
- 前提・制約：結論を読むときに必要な前提、試験・解析の条件の制約、注意書き
- 未解決の点：資料からは分からないこと、決着していないこと

書き方：
- 判断を書くときは「どの試料の、どの条件の、どの値が、何と比べてどうか」が分かるようにする。
  根拠になる代表的な値を 1〜2 個添える。「範囲内」「範囲外」だけで終わらせない。
- 条件によって判断が変わる場合は、そのことを書く。
- 資料に書かれている前提・制約は、「前提・制約」として必ず取り上げる。
- 1 項目は 1〜3 文。数値は 1 項目に多くても 6 個まで。

守ること：
- 渡した材料に無い事実・数値を書かない。数値を計算し直さない。
- 試料名・項目名・条件・値の組み合わせを変えない。項目名を言い換えない。
- text は 1 つの文字列にする。頭に記号・番号を付けない。"""


# ----------------------------------------------------------------------
# 材料づくり
# ----------------------------------------------------------------------

def _load(p: Path) -> Any:
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def _read(p: str) -> str:
    try:
        return Path(p).read_text(encoding="utf-8", errors="ignore") if p else ""
    except OSError:
        return ""


def member_visuals(mdir: Path) -> List[dict]:
    doc = _load(mdir / "evidence_visual_checked.json") or _load(mdir / "evidence_visual.json") or {}
    return doc.get("evidence", []) or []


def _visual_pack(vis: List[dict], readable_text_limit: int = 0) -> List[dict]:
    items = []
    for d in vis:
        try:
            items.append(VisualEvidence.model_validate(d))
        except ValidationError:
            continue
    return visual_to_pack(items, max_total_chars=0, readable_text_limit=readable_text_limit)


def unit_label(name: str) -> str:
    """範囲の呼び名（報告書・画面用）。"""
    if not name:
        return "資料全体"
    if name == FIGURE_UNIT or name.startswith("その他（"):
        return name
    m = re.fullmatch(r"p\.(\d+)", name)
    return f"{m.group(1)}ページ" if m else f"シート「{name}」"


def shown_text(text: str, table_rows: int, max_chars: int) -> Tuple[str, Dict[str, Any]]:
    """モデルに見せる原文。長い表は先頭だけにする（全行の集計は別に渡す）。"""
    info: Dict[str, Any] = {"tables_cut": 0, "truncated": False}
    out: List[str] = []
    lines = (text or "").split("\n")
    i = 0
    while i < len(lines):
        if lines[i].lstrip().startswith("|"):
            j = i
            while j < len(lines) and lines[j].lstrip().startswith("|"):
                j += 1
            block = lines[i:j]
            if table_rows and len(block) > table_rows + 2:
                out += block[: table_rows + 2]
                out.append(f"（この表は全 {len(block) - 2} 行。ここには先頭 {table_rows} 行だけを示す。"
                           f"列ごとの範囲は下の集計を参照）")
                info["tables_cut"] += 1
            else:
                out += block
            i = j
            continue
        out.append(lines[i])
        i += 1
    shown = "\n".join(out)
    if max_chars and len(shown) > max_chars:
        cut = shown.rfind("\n", 0, max_chars)
        shown = shown[: cut if cut > 0 else max_chars] + f"\n（以下省略。全 {len(shown):,} 字のうち先頭だけを示す）"
        info["truncated"] = True
    return shown, info


def build_units(source: str, visuals: List[dict], *, merge_chars: int = 8000,
                max_visual_chars: int = 0) -> List[Dict[str, Any]]:
    """資料を範囲に分ける。画像の読み取りは、同じシート・同じページの範囲に付ける。
    小さい範囲は隣とまとめる（呼び出し回数を抑えるため）。大きい範囲は単独のまま。

    図が主役のシート（解析結果の図が何十枚も並び、セルは題名だけ）では、1 つの範囲に
    画像の読み取りが集中する。max_visual_chars を超える分は、同じ範囲の続きとして分ける
    （1 回の入力が文脈長を超えないように。分けた続きには part を付ける）。"""
    raw = source_units(source)
    names = [n for n, _ in raw]
    by_key = {_name_key(n): n for n in names}
    vis_of: Dict[str, List[dict]] = {}
    loose: List[dict] = []
    for v in visuals or []:
        target: Optional[str] = None
        if v.get("sheet_name"):
            k = _name_key(v["sheet_name"])
            target = by_key.get(k)
            if target is None:
                hits = [n for kk, n in by_key.items() if k and kk.startswith(k)]
                target = hits[0] if len(hits) == 1 else None
        elif v.get("page") is not None and f"p.{v['page']}" in names:
            target = f"p.{v['page']}"
        elif len(names) == 1:
            target = names[0]
        if target is None:
            loose.append(v)
        else:
            vis_of.setdefault(target, []).append(v)

    units = [{"names": [n], "text": t, "visual": vis_of.get(n, [])} for n, t in raw]
    if loose:
        units.append({"names": [FIGURE_UNIT], "text": "", "visual": loose})

    def size(u) -> int:
        return len(u["text"]) + sum(len(json.dumps(v, ensure_ascii=False)) for v in u["visual"])

    merged: List[Dict[str, Any]] = []
    for u in units:
        if not (u["text"].strip() or u["visual"]):
            continue
        if merged and size(merged[-1]) + size(u) <= merge_chars and FIGURE_UNIT not in u["names"]:
            last = merged[-1]
            last["names"] += u["names"]
            last["text"] = (last["text"].rstrip() + "\n\n" + u["text"]).strip()
            last["visual"] += u["visual"]
        else:
            merged.append({"names": list(u["names"]), "text": u["text"], "visual": list(u["visual"])})
    if not max_visual_chars:
        return merged
    out: List[Dict[str, Any]] = []
    for u in merged:
        groups: List[List[dict]] = [[]]
        used = 0
        for v in u["visual"]:
            n = len(json.dumps(v, ensure_ascii=False))
            if groups[-1] and used + n > max_visual_chars:
                groups.append([])
                used = 0
            groups[-1].append(v)
            used += n
        if len(groups) == 1:
            out.append(u)
            continue
        for k, g in enumerate(groups, 1):
            out.append({"names": list(u["names"]), "text": u["text"] if k == 1 else "", "visual": g,
                        "part": (k, len(groups))})
    return out


def stats_lines(stats: List[Dict[str, Any]]) -> List[str]:
    out = []
    for s in stats:
        u = s.get("unit") or ""
        lo = s["min"]["value"] + (f"（{s['min']['row']}）" if s["min"].get("row") else "")
        hi = s["max"]["value"] + (f"（{s['max']['row']}）" if s["max"].get("row") else "")
        where = f"{unit_label(s['where'])}の" if s.get("where") else ""
        out.append(f"{where}{s['item']}：{s['count']} 件、最小 {lo}、最大 {hi}" + (f"、単位 {u}" if u else ""))
    return out


# ----------------------------------------------------------------------
# モデルの出力を寄せる（範囲ごとの整理・結論）
# ----------------------------------------------------------------------

def _record_from(d: Dict[str, Any]) -> List[Record]:
    """オブジェクト 1 つを測定記録にする。{試料, 硬さ: 2.3, 弾性率: 45} のように
    1 つのオブジェクトに複数の値がある形は、値ごとに分ける。"""
    roles: Dict[str, str] = {}
    extra: List[Tuple[str, str]] = []
    for k, v in d.items():
        t = to_text(v)
        if not t:
            continue
        r = _role_of(k)
        if r and r not in roles:
            roles[r] = t
        else:
            extra.append((str(k), t))
    base = {"sample": roles.get("sample", ""), "condition": roles.get("condition", "")}
    if "value" in roles:
        return [Record(**base, item=roles.get("item", ""), value=roles["value"], unit=roles.get("unit", ""))]
    return [Record(**base, item=k, value=t, unit=roles.get("unit", ""))
            for k, t in extra if _extract_numbers(t)]


def coerce_unit(raw: Any) -> Tuple[UnitAnalysis, Dict[str, Any]]:
    names = list(UnitAnalysis.model_fields)
    raw = unwrap(raw, names + ["records", "measurements"])
    rep: Dict[str, Any] = {"fixed": [], "missing": [], "unusable": []}
    if not isinstance(raw, dict):
        rep["shape"] = type(raw).__name__
        return UnitAnalysis(), rep
    notes = to_list(raw.get("notes"))
    hl: List[Record] = []
    src = raw.get("highlights")
    if src is None:
        src = raw.get("records", raw.get("measurements"))
        if src is not None:
            rep["fixed"].append("highlights（別名の欄）")
    if isinstance(src, dict):
        src = [src]
    for x in src or []:
        if isinstance(x, dict):
            got = _record_from(x)
            if got:
                hl += got
            else:
                t = to_text(x)
                if t:
                    notes.append(t)
        else:
            t = to_text(x)            # 文で書かれた記録は事実として扱う
            if t:
                notes.append(t)
                if "highlights（文）" not in rep["fixed"]:
                    rep["fixed"].append("highlights（文）")
    for k in names:
        if k not in raw and not (k == "highlights" and src is not None):
            rep["missing"].append(k)
    return UnitAnalysis(summary=to_text(raw.get("summary")), highlights=hl, notes=notes,
                        figures=to_list(raw.get("figures"))), rep


def coerce_conclusions(raw: Any) -> Tuple[CaseConclusions, Dict[str, Any]]:
    """conclusions は {kind, text} の配列・文字列の配列・{種類: [文…]} の辞書のどれでもよい。"""
    rep: Dict[str, Any] = {"fixed": [], "missing": [], "unusable": []}
    if isinstance(raw, list):
        raw = {"conclusions": raw}
        rep["fixed"].append("conclusions（配列だけ）")
    raw = unwrap(raw, ["conclusions", "案件としての結論", "conclusion"] + list(CONCLUSION_KINDS))
    if not isinstance(raw, dict):
        rep["shape"] = type(raw).__name__
        return CaseConclusions(), rep
    cr = raw.get("conclusions", raw.get("案件としての結論", raw.get("conclusion")))
    if cr is None and set(raw) & set(CONCLUSION_KINDS):
        cr = {k: raw[k] for k in raw if k in CONCLUSION_KINDS}
    out: List[ConclusionItem] = []
    if cr is None:
        rep["missing"].append("conclusions")
    elif isinstance(cr, dict):
        rep["fixed"].append("conclusions（dict）")
        for kind, texts in cr.items():
            for t in to_list(texts):
                out.append(ConclusionItem(kind=str(kind), text=t))
    else:
        for x in (cr if isinstance(cr, list) else [cr]):
            if isinstance(x, dict):
                kind = to_text(x.get("kind") or x.get("種類") or x.get("type") or "")
                text = x.get("text") if "text" in x else x.get("内容")
                if text is None:
                    text = {k: v for k, v in x.items() if k not in ("kind", "種類", "type")}
                for t in to_list(text):
                    out.append(ConclusionItem(kind=kind, text=t))
            else:
                t = to_text(x)
                if t:
                    out.append(ConclusionItem(kind="", text=t))
    return CaseConclusions(conclusions=out), rep


# ----------------------------------------------------------------------
# 目印付きの文字列 ⇔ 構造
# ----------------------------------------------------------------------

_LEAD_MARK = re.compile(r"^\s*(?:[-・*●■□◆◇▼▶︎>]+|\(?\d{1,2}[.)）]|[①-⑳])\s*")


def _clean(text: str) -> str:
    t = re.sub(r"\s+", " ", str(text or "")).strip()
    t = _LEAD_MARK.sub("", t)
    for tag in (TAG_FILE, TAG_COMPARE, TAG_CONCLUSION):
        if t.startswith(tag):
            t = t[len(tag):].strip()
    return t


def _norm_name(name: str) -> str:
    return re.sub(r"[\s『』「」\"'（）()]+", "", str(name or "")).lower()


def match_file(name: str, files: List[str]) -> str:
    """モデルが書いた資料名を、実際の資料名に当てる（拡張子なし・パス違いも許す）。"""
    key = _norm_name(name)
    if not key:
        return ""
    for f in files:
        if _norm_name(f) == key:
            return f
    for f in files:
        nf = _norm_name(f)
        stem = _norm_name(Path(f).stem)
        base = _norm_name(Path(f).name)
        if key in (stem, base) or (len(key) >= 4 and (key in nf or nf.endswith(key))):
            return f
    return ""


def findings_to_strings(by_file: List[Tuple[str, List[str]]], comparison: List[str],
                        conclusions: List[Tuple[str, str]]) -> List[str]:
    out: List[str] = []
    for f, points in by_file:
        for p in points:
            out.append(f"{TAG_FILE}『{f}』{p}")
    for c in comparison:
        out.append(f"{TAG_COMPARE}{c}")
    for kind, text in conclusions:
        out.append(f"{TAG_CONCLUSION}{kind}：{text}" if kind else f"{TAG_CONCLUSION}{text}")
    return out


def files_in_findings(findings: List[str]) -> List[str]:
    """「資料ごとの分析」に出てくる資料名（出てきた順）。"""
    seen: List[str] = []
    for item in findings or []:
        s = str(item)
        if s.startswith(TAG_FILE):
            m = re.match(r"『(.+?)』", s[len(TAG_FILE):])
            if m and m.group(1) not in seen:
                seen.append(m.group(1))
    return seen


_FINDINGS_CANDIDATES = (("action_results", "findings"), ("findings",), ("key_results",),
                        ("main_content",), ("key_points",))


def findings_path(summary: Dict[str, Any]) -> Optional[Tuple[str, ...]]:
    for path in _FINDINGS_CANDIDATES:
        node: Any = summary
        ok = True
        for k in path:
            if isinstance(node, dict) and k in node:
                node = node[k]
            else:
                ok = False
                break
        if ok and isinstance(node, list):
            return path
    return None


def get_path(summary: Dict[str, Any], path: Tuple[str, ...]) -> Any:
    node: Any = summary
    for k in path:
        node = node[k]
    return node


def set_path(summary: Dict[str, Any], path: Tuple[str, ...], value: Any) -> None:
    node: Any = summary
    for k in path[:-1]:
        node = node[k]
    node[path[-1]] = value


# ----------------------------------------------------------------------
# 書いた文の確認
# ----------------------------------------------------------------------

REASON_TEXT = {
    "foreign": "資料に無い種類の文字が混ざっている",
    "number": "資料に無い数値がある",
    "mismatch": "数値と、項目・試料の対応が原文の表と違う",
    "too_long": "数値が多すぎる、または長すぎる（値の書き写しになっている）",
    "only": "他の資料にもある内容を「この資料にだけある」と書いている",
    "same_value": "同じ値を「違い」として比べている",
}


def _count_numbers(text: str) -> int:
    return sum(1 for v, u, _ in _extract_numbers(text)
               if u or not (float(v).is_integer() and abs(v) < 10))


def screen(text: str, *, blob: str, index: Optional[SourceIndex], vocab: Optional[List[str]],
           source: str, max_chars: int = 0, max_numbers: int = 0) -> Optional[Dict[str, Any]]:
    """文 1 つを確かめる。問題があれば {reason, detail}、無ければ None。"""
    fc = foreign_chars(text, source)
    if fc:
        return {"reason": "foreign", "detail": "".join(fc[:8])}
    bad = unsupported_numbers(text, blob)
    if bad:
        return {"reason": "number", "detail": "、".join(b["text"] for b in bad[:4])}
    if index is not None:
        pr = check_statement(text, index, vocab)
        if pr:
            p = pr[0]
            return {"reason": "mismatch",
                    "detail": f"{p['number']} は原文では「{p['source']}」の値（「{p['said']}」ではない）"}
    if (max_chars and len(text) > max_chars) or (max_numbers and _count_numbers(text) > max_numbers):
        return {"reason": "too_long", "detail": f"{len(text)} 字・数値 {_count_numbers(text)} 個"}
    return None


def trim_to_limits(text: str, max_chars: int, max_numbers: int) -> str:
    """長すぎる項目を、文の切れ目で制限内に収める。1 文目から収まらなければ空文字。"""
    out = ""
    for sent in re.split(r"(?<=。)", text):
        cand = out + sent
        if (max_chars and len(cand) > max_chars) or (max_numbers and _count_numbers(cand) > max_numbers):
            break
        out = cand
    return out.strip()


def problems_message(problems: List[Dict[str, Any]]) -> str:
    lines = ["次の項目に問題がありました。直したうえで、もう一度すべて出力してください。"]
    for p in problems[:12]:
        t = p["text"] if len(p["text"]) <= 70 else p["text"][:70] + "…"
        lines.append(f"・「{t}」：{REASON_TEXT.get(p['reason'], p['reason'])}（{p['detail']}）")
    return "\n".join(lines)


# ----------------------------------------------------------------------
# ノード
# ----------------------------------------------------------------------

#: モデルが取り上げなかった資料を、その資料の証拠から補うときの件数
FILL_FROM_EVIDENCE_PER_FILE = 12


def make_case_analysis_nodes(config: AppConfig, llm):
    from .nodes import _push_error, _save_json, _store, _update_status

    wf = config.workflow
    cc = config.case
    _idx: Dict[str, Tuple[str, SourceIndex, List[str]]] = {}

    def _members(state) -> List[Dict[str, Any]]:
        return [m for m in (state.get("case") or {}).get("members", []) if m.get("state") == "done"]

    def _titles(state) -> Dict[str, str]:
        docs = ((state.get("case_meta") or {}).get("documents")) or []
        return {d.get("file", ""): d.get("document_title", "") for d in docs}

    def _source_index(m) -> Tuple[str, SourceIndex, List[str]]:
        key = m["run_dir"]
        if key not in _idx:
            src = _read(m.get("markdown_path", ""))
            idx = build_index(src)
            _idx[key] = (src, idx, statement_vocab(idx))
        return _idx[key]

    def _file_evidence(state, rel: str) -> List[Dict[str, Any]]:
        """その資料自身の証拠（台帳は除く）。分析できなかった資料の代わりの材料。"""
        out = []
        for e in state.get("aggregated_evidence", []) or []:
            if (e.get("origin") or "text") == "reference":
                continue
            if e.get("file") != rel and rel not in (e.get("also_in") or []):
                continue
            d = {"content": e.get("content", "")}
            for k in ("category", "sheet_name", "page"):
                if e.get(k):
                    d[k] = e[k]
            out.append(d)
        return out

    def _file_blobs(state) -> Dict[str, str]:
        """資料ごとの裏付け：その資料の原文・照合済みの画像の読み取り・その資料の証拠。"""
        vis_by: Dict[str, list] = {}
        for v in state.get("visual_evidence", []) or []:
            vis_by.setdefault(v.get("file", ""), []).append(v)
        ev_by: Dict[str, list] = {}
        for e in state.get("aggregated_evidence", []) or []:
            if (e.get("origin") or "text") != "reference":
                for f in [e.get("file", "")] + list(e.get("also_in") or []):
                    ev_by.setdefault(f, []).append(e)
        blobs = {}
        for m in _members(state):
            rel = m["rel_in_case"]
            blobs[rel] = "\n".join([_read(m.get("markdown_path", "")),
                                    json.dumps(vis_by.get(rel, []), ensure_ascii=False),
                                    json.dumps(ev_by.get(rel, []), ensure_ascii=False)])
        return blobs

    def _layers(state) -> Dict[str, Any]:
        return dict(state.get("case_layers") or {})

    # ---- モデルに聞いて、形を寄せる。何も使えなければ理由を添えて 1 回だけやり直す ----
    def _ask(*, system: str, user: str, schema: dict, tag: str, max_tokens: int, coerce,
             empty=None, feedback: str = ""):
        attempts: List[Dict[str, Any]] = []
        best = None
        for n in (1, 2):
            u, mt = user, max_tokens
            if feedback and n == 1:
                u = user + "\n\n【前回の出力について】" + feedback
            if n == 2:
                u = (user + "\n\n【前回の出力について】" + (describe(attempts[-1]) or "使える内容がありませんでした")
                     + "。上の形式に合わせて、もう一度すべて出力してください。")
                if attempts[-1].get("error"):
                    mt = min(int(max_tokens * 1.5), 16384)   # 途中で切れた可能性があるので少し広げる
            try:
                raw = llm.chat_json(system=system, user=u, max_tokens=mt, json_schema=schema,
                                    tag=tag if n == 1 else tag + ":retry", temperature=0.0)
                inst, rep = coerce(raw)
                if (empty or is_empty)(inst):
                    rep["empty"] = True
                else:
                    best = inst
            except Exception as e:  # noqa: BLE001
                rep = {"error": repr(e)[:300]}
            attempts.append(rep)
            if best is not None:
                break
        return best, attempts

    # ------------------------------------------------------------------
    # 1. 資料ごとの分析
    # ------------------------------------------------------------------
    def _analyze_unit(rel: str, i_file: int, j: int, unit: Dict[str, Any], *, index: SourceIndex,
                      vocab: List[str], source: str, blob: str, check_block: str,
                      cache: Dict[str, Any]) -> Dict[str, Any]:
        label = "・".join(unit_label(n) for n in unit["names"])
        part = unit.get("part")
        if part:
            label += f"（画像 {part[0]}/{part[1]}）"
        shown, info = shown_text(unit["text"], int(cc.unit_table_rows), int(cc.unit_chars))
        # 画像だけの続きには、表の集計を付けない（1 つ目で渡している）
        stats = [] if part and part[0] > 1 else \
            [s for n in unit["names"] for s in column_stats(index, n, limit=int(cc.unit_stats_columns))]
        vis = _visual_pack(unit["visual"], wf.visual_readable_text_limit)
        parts = [f"資料名：{rel}", f"範囲：{label}"]
        if shown.strip():
            parts += ["", "【原文】（文字として取り出せた本文。Excel はセルの値を表にした物）", shown]
        if stats:
            parts += ["", "【表の列ごとの集計】（プログラムが原文の全行から作った物）"] \
                + ["- " + ln for ln in stats_lines(stats)]
        if vis:
            parts += ["", "【画像からの読み取り】（この範囲を画像にして読み取った物。原文と照らし合わせ済み）",
                      dumps(vis)]
        if check_block:
            parts += ["", check_block]
        parts += ["", "次の形式の JSON で出力してください：",
                  json.dumps(schema_skeleton(UnitAnalysis.model_json_schema()), ensure_ascii=False)]
        user = "\n".join(parts)
        key = hashlib.sha1((CASE_ANALYSIS_VERSION + config.llm.model + UNIT_SYSTEM + user)
                           .encode("utf-8")).hexdigest()[:16]
        base = {"names": unit["names"], "label": label, "stats": stats, "shown": info,
                "has_visual": bool(vis)}
        if wf.resume and key in cache:
            return {**base, **cache[key], "cached": True}
        ua, attempts = _ask(system=UNIT_SYSTEM, user=user, schema=UnitAnalysis.model_json_schema(),
                            tag=f"case:unit:{i_file:02d}:{j:02d}", max_tokens=int(cc.unit_max_tokens),
                            coerce=coerce_unit)
        if ua is None:
            return {**base, "status": "failed", "attempts": attempts,
                    "reason": describe(attempts[-1]) or "使える内容がありませんでした"}

        fig_text = json.dumps(unit["visual"], ensure_ascii=False)
        kept, dropped, fixed = [], [], []
        for r in ua.highlights:
            v = verify_record(r.model_dump(), index, figure_text=fig_text)
            if v["status"] in ("ok", "corrected", "figure"):
                kept.append(v)
                if v.get("fixed"):
                    fixed.append({"record": record_line(r.model_dump()), "fixed": v["fixed"]})
            elif v["status"] == "text":
                line = record_line(v)
                if line:
                    ua.notes.append(line)
            else:
                dropped.append({"record": record_line(r.model_dump()), "reason": v.get("reason", "原文に無い値")})

        def keep_texts(items: List[str], where: str) -> List[str]:
            out = []
            for t in items:
                t = _clean(t)
                if not t:
                    continue
                p = screen(t, blob=blob, index=index, vocab=vocab, source=source)
                if p:
                    dropped.append({"text": t, "where": where, **p})
                else:
                    out.append(t)
            return out

        res = {"status": "ok", "summary": (keep_texts([ua.summary], "summary") or [""])[0],
               "highlights": kept, "notes": keep_texts(ua.notes, "notes"),
               "figures": keep_texts(ua.figures, "figures"),
               "fixed": fixed, "dropped": dropped, "attempts": attempts}
        cache[key] = res
        return {**base, **res}

    def _stats_point(label: str, stats: List[Dict[str, Any]]) -> str:
        """集計から作る 1 項目（内容は原文の値そのもの）。"""
        bits = []
        for s in stats[:3]:
            unit = s.get("unit") or ""
            lo, hi = s["min"]["value"], s["max"]["value"]
            rng = f"{lo}〜{hi}" if lo != hi else lo
            item = re.sub(r"\s*[（(\[［][^（）()\[\]［］]{1,12}[）)\]］]", "", s["item"]).strip() or s["item"]
            bits.append(f"{item}は {rng}{(' ' + unit) if unit and unit not in rng else ''}（{s['count']} 件）")
        return f"{label}：" + "、".join(bits) + "。" if bits else ""

    def _name_covered(name: str, points: List[str], index: SourceIndex) -> bool:
        """シート・ページ 1 つが、分析のどこかで取り上げられているか（名前・行の文字・その範囲の値）。"""
        joined = squeeze(" ".join(points))
        if name and squeeze(name) in joined:
            return True
        for lab in row_labels(index, name)[:80]:
            if len(squeeze(lab)) >= 3 and squeeze(lab) in joined:
                return True
        for p in points:
            for v, un, raw in _extract_numbers(p):
                if (un or not (float(v).is_integer() and abs(v) < 10)) and index.find(v, raw, un, name):
                    return True
        return False

    def _texts_covered(u: Dict[str, Any], points: List[str]) -> bool:
        joined = squeeze(" ".join(points))
        for t in [u.get("summary", "")] + (u.get("notes") or []) + (u.get("figures") or []):
            k = squeeze(t)
            if len(k) >= 8 and (k[:12] in joined or k[-12:] in joined):
                return True
        return False

    def _analyze_file(state, i: int, m: Dict[str, Any], titles: Dict[str, str]) -> Dict[str, Any]:
        rel = m["rel_in_case"]
        mdir = Path(m["run_dir"])
        source, index, vocab = _source_index(m)
        visuals = member_visuals(mdir)
        report = _load(mdir / "page_report.json") or {}
        check_block = report_prompt_block(report) if report.get("version") == 2 else ""
        blob = "\n".join([source, json.dumps(visuals, ensure_ascii=False),
                          json.dumps(_file_evidence(state, rel), ensure_ascii=False)])
        units = build_units(source, visuals, merge_chars=int(cc.unit_merge_chars),
                            max_visual_chars=int(cc.unit_chars))
        if not units:
            return {"file": rel, "analysis": None, "status": "no_material",
                    "fallback_evidence": _file_evidence(state, rel)}

        cache_p = mdir / ANALYSIS_FILE
        cached = _load(cache_p) or {}
        same_version = cached.get("version") == CASE_ANALYSIS_VERSION
        ucache: Dict[str, Any] = dict(cached.get("unit_cache") or {}) if same_version else {}
        store = _store(state)
        results: List[Dict[str, Any]] = []
        for j, u in enumerate(units, 1):
            store.raise_if_cancelled()
            _update_status(state, "analyze_files", "running", f"資料 {i}：範囲 {j}/{len(units)}",
                           peek=f"『{rel}』の{'・'.join(unit_label(n) for n in u['names'])}を読んでいます…")
            results.append(_analyze_unit(rel, i, j, u, index=index, vocab=vocab, source=source,
                                         blob=blob, check_block=check_block, cache=ucache))
        ok_units = [r for r in results if r["status"] == "ok"]
        failed_units = [r["label"] for r in results if r["status"] != "ok"]

        # ---- 資料としての分析 ----
        limits = dict(max_chars=int(cc.point_max_chars), max_numbers=int(cc.point_max_numbers))
        material = {"file": rel, "title": titles.get(rel, ""), "ranges": [
            {"range": r["label"], "summary": r.get("summary", ""),
             "highlights": [record_line(h) for h in r.get("highlights", [])],
             "notes": r.get("notes", []), "figures": r.get("figures", []),
             "column_stats": stats_lines(r.get("stats", []))} for r in results
            if r["status"] == "ok" or r.get("stats")]}
        user = ("資料を範囲ごとに整理した結果です。\n\n" + dumps(material)
                + (("\n\n" + check_block) if check_block else "")
                + "\n\n次の形式の JSON で出力してください：\n"
                + json.dumps(schema_skeleton(FileAnalysis.model_json_schema()), ensure_ascii=False))
        skey = hashlib.sha1((CASE_ANALYSIS_VERSION + config.llm.model + FILE_SYSTEM + user
                             + json.dumps(limits)).encode("utf-8")).hexdigest()[:16]
        removed: List[Dict[str, Any]] = []
        fa_d: Optional[Dict[str, Any]] = None
        synth_attempts: List[Any] = []
        reused = bool(wf.resume and same_version and cached.get("synth_key") == skey
                      and isinstance(cached.get("analysis"), dict) and cached.get("status") == "ok")
        if reused:
            fa_d = cached["analysis"]
            removed = cached.get("removed", [])
        elif ok_units:
            def checks(fa: FileAnalysis) -> List[Dict[str, Any]]:
                probs = []
                for t in fa.points:
                    p = screen(_clean(t), blob=blob, index=index, vocab=vocab, source=source, **limits)
                    if p:
                        probs.append({"text": _clean(t), **p})
                return probs

            fa, synth_attempts = _ask(system=FILE_SYSTEM, user=user,
                                      schema=FileAnalysis.model_json_schema(),
                                      tag=f"case:analyze:{i:02d}", max_tokens=int(cc.analysis_max_tokens),
                                      coerce=lambda raw: coerce_flat(raw, FileAnalysis))
            if fa is not None:
                probs = checks(fa)
                if probs:      # 問題のある項目を伝えて、1 回だけ書き直させる
                    fa2, att2 = _ask(system=FILE_SYSTEM, user=user, schema=FileAnalysis.model_json_schema(),
                                     tag=f"case:analyze:{i:02d}:fix", max_tokens=int(cc.analysis_max_tokens),
                                     coerce=lambda raw: coerce_flat(raw, FileAnalysis),
                                     feedback=problems_message(probs))
                    synth_attempts += [{"fix": True, "problems": len(probs)}] + att2
                    if fa2 is not None and len(checks(fa2)) < len(probs):
                        fa = fa2
                fa_d = fa.model_dump()
                out_points = []
                for t in fa_d["points"]:
                    t = _clean(t)
                    p = screen(t, blob=blob, index=index, vocab=vocab, source=source, **limits) if t else None
                    if p and p["reason"] == "too_long":
                        short = trim_to_limits(t, limits["max_chars"], limits["max_numbers"])
                        if short and not screen(short, blob=blob, index=index, vocab=vocab,
                                                source=source, **limits):
                            removed.append({"text": t, "where": "points", **p, "kept": short})
                            out_points.append(short)
                            continue
                    if p:
                        removed.append({"text": t, "where": "points", **p})
                    elif t:
                        out_points.append(t)
                fa_d["points"] = out_points[: int(cc.points_per_file)]
                for fld in ("conclusions", "limitations", "open_points"):
                    keep = []
                    for t in fa_d[fld]:
                        t = _clean(t)
                        p = screen(t, blob=blob, index=index, vocab=vocab, source=source) if t else None
                        if p:
                            removed.append({"text": t, "where": fld, **p})
                        elif t:
                            keep.append(t)
                    fa_d[fld] = keep

        status = "ok"
        if fa_d is None:
            # 分析の文章が作れなかった：範囲ごとの整理と集計から、機械的に組み立てる
            pts = []
            for r in results:
                per_name = [_stats_point(unit_label(n), column_stats(index, n, limit=3)) for n in r["names"]]
                per_name = [p for p in per_name if p]
                pts += per_name or ([f"{r['label']}：{r['summary']}"] if r.get("summary") else [])
            notes = [t for r in ok_units for t in r.get("notes", [])]
            if not pts and not notes:
                return {"file": rel, "analysis": None, "status": "failed",
                        "reason": "範囲ごとの整理も、分析の文章も作れませんでした",
                        "units": [{k: r.get(k) for k in ("label", "status", "reason")} for r in results],
                        "fallback_evidence": _file_evidence(state, rel)}
            fa_d = FileAnalysis(points=pts).model_dump()
            fa_d["points"] += notes[: max(0, int(cc.points_per_file) - len(pts))]
            status = "auto"

        # ---- どの範囲も取り上げられているか。抜けた範囲は集計から補う ----
        auto_added, uncovered = [], []
        if reused:
            auto_added = (cached.get("coverage") or {}).get("auto_added", [])
            uncovered = (cached.get("coverage") or {}).get("uncovered", [])
        elif status == "ok":
            for r in results:
                # 表のある範囲は、まとめて読んだ場合でもシート・ページ 1 つずつ確かめる
                # （長い表だけが取り上げられ、同じ資料の別の表が抜けるのを防ぐ）
                with_table = [(n, column_stats(index, n, limit=3)) for n in r["names"]]
                with_table = [(n, st) for n, st in with_table if st]
                for n, st in with_table:
                    if _name_covered(n, fa_d["points"], index):
                        continue
                    ap = _stats_point(unit_label(n), st)
                    if ap and not screen(ap, blob=blob, index=None, vocab=None, source=source):
                        fa_d["points"].append(ap)
                        auto_added.append(unit_label(n))
                    else:
                        uncovered.append(unit_label(n))
                if with_table:
                    continue
                has_text = r.get("summary") or r.get("notes") or r.get("figures")
                if not has_text or _texts_covered(r, fa_d["points"]) or any(
                        _name_covered(n, fa_d["points"], index) for n in r["names"]):
                    continue
                ap = f"{r['label']}：{r['summary']}" if r.get("summary") else ""
                if ap and not screen(ap, blob=blob, index=index, vocab=vocab, source=source):
                    fa_d["points"].append(ap)
                    auto_added.append(r["label"])
                else:
                    uncovered.append(r["label"])

        coverage = {"ranges": len(results), "ok": len(ok_units), "failed": failed_units,
                    "auto_added": auto_added, "uncovered": uncovered}
        unit_report = [{"label": r["label"], "status": r["status"],
                        "highlights": len(r.get("highlights", [])), "corrected": len(r.get("fixed", [])),
                        "dropped": len(r.get("dropped", [])), "stats": len(r.get("stats", [])),
                        **({"reason": r["reason"]} if r.get("reason") else {}),
                        **({"cached": True} if r.get("cached") else {})} for r in results]
        _save_json({"version": CASE_ANALYSIS_VERSION, "file": rel, "synth_key": skey,
                    "unit_cache": ucache, "units": results, "analysis": fa_d, "removed": removed,
                    "coverage": coverage, "synth_attempts": synth_attempts, "status": status}, cache_p)
        return {"file": rel, "analysis": fa_d, "status": status, "units": unit_report,
                "coverage": coverage, "removed": removed,
                "corrected": sum(len(r.get("fixed", [])) for r in results),
                **({"cached": True} if reused and all(r.get("cached") for r in results) else {})}

    def analyze_files(state) -> Dict[str, Any]:
        members = _members(state)
        titles = _titles(state)
        _update_status(state, "analyze_files", peek=f"{len(members)} 件の資料を 1 件ずつ読んでいます…")
        out: List[Dict[str, Any]] = []
        for i, m in enumerate(members, 1):
            _store(state).raise_if_cancelled()
            try:
                res = _analyze_file(state, i, m, titles)
            except Exception as e:  # noqa: BLE001 1 件の失敗で案件を止めない
                if type(e).__name__ in ("RunCancelled", "CancelledError"):
                    raise
                res = {"file": m["rel_in_case"], "analysis": None, "status": "failed",
                       "reason": repr(e)[:200],
                       "fallback_evidence": _file_evidence(state, m["rel_in_case"])}
            if not res.get("analysis"):
                _push_error(state, "analyze_files",
                            f"資料『{res['file']}』を分析できませんでした。"
                            f"この資料は本文から抜き出した証拠を代わりに使います",
                            str(res.get("reason", ""))[:500])
            out.append(res)
        _save_json({"files": out}, Path(state["run_dir"]) / "case_file_analyses.json")

        ok = [x["file"] for x in out if x.get("analysis")]
        bad = [x["file"] for x in out if not x.get("analysis")]
        reused = sum(1 for x in out if x.get("cached"))
        layers = _layers(state)
        layers["analysis"] = {
            "total": len(members), "ok": len(ok), "failed": bad, "reused": reused,
            "auto": [x["file"] for x in out if x.get("status") == "auto"],
            "ranges_failed": [{"file": x["file"], "ranges": x["coverage"]["failed"]}
                              for x in out if (x.get("coverage") or {}).get("failed")],
            "ranges_uncovered": [{"file": x["file"], "ranges": x["coverage"]["uncovered"]}
                                 for x in out if (x.get("coverage") or {}).get("uncovered")],
            "ranges_auto_added": sum(len((x.get("coverage") or {}).get("auto_added", [])) for x in out),
            "records_corrected": sum(int(x.get("corrected") or 0) for x in out),
            "points_removed": sum(len([r for r in x.get("removed", []) if not r.get("kept")]) for x in out),
            "points_mismatch": sum(1 for x in out for r in x.get("removed", [])
                                   if r.get("reason") == "mismatch")}
        detail = f"{len(ok)}/{len(members)} 件" + (f"（前回の結果を使用 {reused} 件）" if reused else "")
        if bad:
            peek = (f"{len(bad)} 件の資料は分析できませんでした（"
                    + "、".join(f"『{f}』" for f in bad[:3]) + ("…" if len(bad) > 3 else "")
                    + "）。抜き出した証拠で代わりに書きます")
        else:
            peek = f"{len(ok)} 件の資料を整理しました"
        _update_status(state, "analyze_files", "done", detail, peek=peek)
        return {"file_analyses": out, "case_layers": layers, "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    # 2. 資料間の比較
    # ------------------------------------------------------------------
    def _file_materials(state) -> List[Dict[str, Any]]:
        """比較・結論に渡す資料ごとの材料。分析が無い資料は証拠で代える。"""
        titles = _titles(state)
        mats = []
        for a in state.get("file_analyses") or []:
            d: Dict[str, Any] = {"file": a["file"]}
            if titles.get(a["file"]):
                d["title"] = titles[a["file"]]
            if a.get("analysis"):
                d.update(a["analysis"])
            elif a.get("fallback_evidence"):
                d["note"] = "この資料は整理できなかったため、本文から抜き出した証拠を渡します"
                d["evidence"] = a["fallback_evidence"]
            else:
                d["note"] = "この資料からは内容を取り出せていません"
            mats.append(d)
        return mats

    def _merged_index(state) -> Tuple[SourceIndex, List[str], str]:
        merged = SourceIndex()
        srcs = []
        for m in _members(state):
            src, idx, _ = _source_index(m)
            merged.cells += idx.cells
            srcs.append(src)
        return merged, statement_vocab(merged), "\n".join(srcs)

    def compare_files(state) -> Dict[str, Any]:
        run_dir = Path(state["run_dir"])
        mats = _file_materials(state)
        usable = [m for m in mats if "evidence" in m or not m.get("note")]
        layers = _layers(state)
        reason = ""
        if len(mats) < 2:
            reason = "資料が 1 件のため"
        elif len(usable) < 2:
            ok = (layers.get("analysis") or {}).get("ok", 0)
            reason = (f"内容を取り出せた資料が {len(usable)} 件しかないため"
                      f"（資料ごとの分析 {ok}/{len(mats)} 件）")
        if reason:
            layers["comparison"] = {"ran": False, "reason": reason}
            _save_json({"ran": False, "reason": reason}, run_dir / COMPARISON_FILE)
            _update_status(state, "compare_files", "done", f"省略：{reason}",
                           peek=f"{reason}、資料間の比較は行いませんでした")
            return {"case_comparison": {}, "case_layers": layers}

        _update_status(state, "compare_files", peek=f"{len(mats)} 件の資料を突き合わせています…")
        members = _members(state)
        indices = {m["rel_in_case"]: _source_index(m)[1] for m in members}
        sources = {m["rel_in_case"]: _source_index(m)[0] for m in members}
        base = cross_file_base(indices, sources)
        presence = base.pop("_presence")
        user = ("同じ案件フォルダに入っている資料です。\n\n【資料ごとの分析】\n" + dumps(mats)
                + "\n\n【原文から機械的に拾った対応】（プログラムが表の行の文字と値を照らし合わせた物）\n"
                + dumps(base)
                + "\n\n次の形式の JSON で出力してください：\n"
                + json.dumps(schema_skeleton(CaseComparison.model_json_schema()), ensure_ascii=False))
        comp_m, attempts = _ask(system=COMPARE_SYSTEM, user=user,
                                schema=CaseComparison.model_json_schema(), tag="case:compare",
                                max_tokens=int(cc.compare_max_tokens),
                                coerce=lambda raw: coerce_flat(raw, CaseComparison))
        if comp_m is None:
            why = describe(attempts[-1]) or "使える内容がありませんでした"
            _push_error(state, "compare_files", "資料間の比較に失敗しました（2 回試しました。比較なしで続けます）",
                        dumps(attempts)[:1500])
            layers["comparison"] = {"ran": False, "reason": f"比較の出力が使えなかったため（{why}）"}
            _save_json({"ran": False, "attempts": attempts}, run_dir / COMPARISON_FILE)
            _update_status(state, "compare_files", "done", "失敗（続行）", peek="資料間の比較はできませんでした")
            return {"case_comparison": {}, "case_layers": layers, "errors": state.get("errors", [])}

        # ---- 確認：数値・対応・「片方にしか無い」・同じ値どうしの比較 ----
        merged, vocab, all_src = _merged_index(state)
        whole = "\n".join(_file_blobs(state).values())
        files = list(indices)
        removed: List[Dict[str, Any]] = []
        comp: Dict[str, List[str]] = {}
        for fld, _ in COMPARE_LABELS:
            keep = []
            for t in getattr(comp_m, fld):
                t = _clean(t)
                if not t:
                    continue
                p = screen(t, blob=whole, index=merged, vocab=vocab, source=all_src,
                           max_chars=int(cc.point_max_chars) * 2, max_numbers=int(cc.point_max_numbers) + 4)
                if not p and fld in ("added", "relations", "common"):
                    named = sorted({f for f in (match_file(n, files) for n in re.findall(r"『(.+?)』", t)) if f})
                    term = only_claim_problem(t, named, presence)
                    if term:
                        others = [f for f in presence.get(term, []) if f not in named]
                        p = {"reason": "only",
                             "detail": f"「{term}」は『{others[0]}』にもある" if others else term}
                if not p and fld == "differences":
                    nums = [v for v, u, _ in _extract_numbers(t) if u or abs(v) >= 10]
                    if len(nums) >= 2 and all(_same_value(nums[0], v) for v in nums[1:]):
                        p = {"reason": "same_value", "detail": "値が同じ"}
                if p:
                    removed.append({"text": t, "where": fld, **p})
                else:
                    keep.append(t)
            comp[fld] = keep
        n = sum(len(v) for v in comp.values())
        from_ev = [m["file"] for m in mats if "evidence" in m]
        layers["comparison"] = {"ran": True, "items": n, "from_evidence": from_ev, "removed": len(removed),
                                "removed_only_claims": sum(1 for r in removed if r["reason"] == "only")}
        _save_json({**comp, "_base": base, "_removed": removed, "_attempts": attempts}, run_dir / COMPARISON_FILE)
        _update_status(state, "compare_files", "done", f"{n} 項目",
                       peek=("資料どうしの関係と違いを整理しました" if n else "比較できる点が見つかりませんでした"))
        return {"case_comparison": comp, "case_layers": layers, "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    # 3. 「判明した事実」の欄を組み立てる（結論だけモデルに書かせる）
    # ------------------------------------------------------------------
    def case_findings(state) -> Dict[str, Any]:
        summary = state.get("summary") or {}
        path = findings_path(summary)
        files = [m["rel_in_case"] for m in _members(state)]
        run_dir = Path(state["run_dir"])
        layers = _layers(state)
        if path is None or not files:
            _update_status(state, "case_findings", "done", "対象の欄なし")
            return {}
        _update_status(state, "case_findings", peek="「判明した事実」の欄を組み立て、案件としての結論を書いています…")
        report: Dict[str, Any] = {"files": files, "removed": [], "filled_from_evidence": [],
                                  "not_analysed": [], "llm_failed": False, "added_by_program": []}
        amap = {a["file"]: a for a in state.get("file_analyses") or []}
        blobs = _file_blobs(state)
        merged, vocab, all_src = _merged_index(state)
        whole = "\n".join(blobs.values()) + "\n" + json.dumps(
            [e for e in state.get("aggregated_evidence", []) or [] if (e.get("origin") or "") == "reference"],
            ensure_ascii=False)

        # ---- 資料ごとの分析：各資料の分析をそのまま使う（ここでは書き直さない）----
        by_file: Dict[str, List[str]] = {}
        for f in files:
            a = amap.get(f) or {}
            pts = list((a.get("analysis") or {}).get("points") or [])
            if not pts:
                ev = [e["content"] for e in (a.get("fallback_evidence") or _file_evidence(state, f))
                      if e.get("content")][:FILL_FROM_EVIDENCE_PER_FILE]
                for t in ev:
                    t = _clean(t)
                    if t and not unsupported_numbers(t, blobs.get(f, "")) and not foreign_chars(t, all_src):
                        pts.append(t)
                if pts:
                    report["filled_from_evidence"].append(f)
                else:
                    report["not_analysed"].append(f)
                    pts = ["この資料は分析できませんでした（原文・画像の読み取りから、"
                           "要約に使える内容を取り出せませんでした）"]
            by_file[f] = pts

        # ---- 資料間の比較：比較の結果をそのまま使う ----
        comparison: List[str] = []
        comp = state.get("case_comparison") or {}
        for fld, label in COMPARE_LABELS:
            for t in comp.get(fld) or []:
                comparison.append(f"{label}：{t}")
        cmp_state = layers.get("comparison") or {}
        if len(files) > 1 and not comparison and cmp_state and not cmp_state.get("ran"):
            comparison = [f"資料間の比較は行っていません（{cmp_state.get('reason', '理由不明')}）"]

        # ---- 案件としての結論 ----
        mats = _file_materials(state)
        material = {"資料ごとの分析": mats,
                    "資料間の比較": comp if cmp_state.get("ran") else
                    (f"行っていません（{cmp_state.get('reason', '')}）" if len(files) > 1 else "資料は 1 件のみ")}
        check_block = state.get("case_page_block") or ""
        user = ("材料：\n" + dumps(material) + (("\n\n" + check_block) if check_block else "")
                + "\n\n次の形式の JSON で出力してください：\n"
                + json.dumps(schema_skeleton(CaseConclusions.model_json_schema()), ensure_ascii=False))
        limits = dict(max_chars=int(cc.point_max_chars), max_numbers=int(cc.point_max_numbers))

        def screened(cx: CaseConclusions) -> Tuple[List[Tuple[str, str]], List[Dict[str, Any]]]:
            good, probs = [], []
            for c in cx.conclusions:
                t = _clean(c.text)
                if not t:
                    continue
                kind = c.kind.strip() if c.kind.strip() in CONCLUSION_KINDS else ""
                p = screen(t, blob=whole, index=merged, vocab=vocab, source=all_src, **limits)
                if p:
                    probs.append({"text": t, "where": "案件としての結論", **p})
                else:
                    good.append((kind, t))
            return good, probs

        cx, attempts = _ask(system=CONCLUSION_SYSTEM, user=user, schema=CaseConclusions.model_json_schema(),
                            tag="case:findings", max_tokens=int(cc.findings_max_tokens),
                            coerce=coerce_conclusions, empty=lambda x: not x.conclusions)
        conclusions: List[Tuple[str, str]] = []
        if cx is None:
            _push_error(state, "case_findings",
                        "案件としての結論を書けませんでした（2 回試しました。資料ごとの結論を並べます）",
                        dumps(attempts)[:1500])
            report["llm_failed"] = True
        else:
            conclusions, probs = screened(cx)
            if probs:
                cx2, att2 = _ask(system=CONCLUSION_SYSTEM, user=user,
                                 schema=CaseConclusions.model_json_schema(), tag="case:findings:fix",
                                 max_tokens=int(cc.findings_max_tokens), coerce=coerce_conclusions,
                                 empty=lambda x: not x.conclusions, feedback=problems_message(probs))
                attempts += [{"fix": True, "problems": len(probs)}] + att2
                if cx2 is not None:
                    good2, probs2 = screened(cx2)
                    if len(probs2) < len(probs) and good2:
                        conclusions, probs = good2, probs2
            report["removed"] += probs
        report["attempts"] = attempts

        # 資料に書かれた結論・前提がモデルの出力に 1 つも無い種類は、資料ごとの分析から足す
        def from_analyses(field: str, kind: str, limit: int = 6) -> None:
            if any(k == kind for k, _ in conclusions):
                return
            added = 0
            for f in files:
                for t in ((amap.get(f) or {}).get("analysis") or {}).get(field) or []:
                    if added >= limit:
                        return
                    conclusions.append((kind, f"『{f}』{t}" if len(files) > 1 else t))
                    report["added_by_program"].append(kind)
                    added += 1

        from_analyses("conclusions", "資料の結論")
        from_analyses("limitations", "前提・制約")
        from_analyses("open_points", "未解決の点")
        order = {k: i for i, k in enumerate(CONCLUSION_KINDS)}
        conclusions.sort(key=lambda kc: order.get(kc[0], len(order)))

        items = findings_to_strings([(f, by_file[f]) for f in files], comparison, conclusions)
        report["counts"] = {"by_file": sum(len(v) for v in by_file.values()),
                            "comparison": len(comparison), "conclusions": len(conclusions)}
        set_path(summary, path, items)
        state["summary"] = summary
        _save_json(report, run_dir / FINDINGS_REPORT_FILE)
        layers["findings"] = {"llm_failed": report["llm_failed"], "not_analysed": report["not_analysed"],
                              "filled_from_evidence": report["filled_from_evidence"],
                              "removed": len(report["removed"]),
                              "removed_mismatch": sum(1 for r in report["removed"] if r["reason"] == "mismatch")}
        c = report["counts"]
        _update_status(state, "case_findings", "done",
                       f"資料別 {c['by_file']}・資料間 {c['comparison']}・結論 {c['conclusions']}",
                       peek="「判明した事実」の欄を組み立てました")
        return {"summary": summary, "case_layers": layers, "errors": state.get("errors", [])}

    return {"analyze_files": analyze_files, "compare_files": compare_files,
            "case_findings": case_findings}


def external_file_labels(summary: Dict[str, Any], files: List[str]) -> Dict[str, Any]:
    """社外版用：「判明した事実」の資料名（社内のファイル名）を「資料1」「資料2」…に置き換えた写し。"""
    import copy

    path = findings_path(summary)
    if path is None or not files:
        return summary
    out = copy.deepcopy(summary)
    label = {f: f"資料{i}" for i, f in enumerate(files, 1)}
    items = []
    for item in get_path(out, path) or []:
        s = str(item)
        for f, lab in label.items():
            s = s.replace(f"『{f}』", f"『{lab}』")
        items.append(s)
    set_path(out, path, items)
    return out


def analyses_prompt_block(state: Dict[str, Any]) -> str:
    """write_summary に渡す「資料ごとの分析」「資料間の比較」。"""
    fa = state.get("file_analyses") or []
    analyses = [{"file": a["file"], **a["analysis"]} for a in fa if a.get("analysis")]
    failed = [a["file"] for a in fa if not a.get("analysis")]
    if not analyses and not failed:
        return ""
    out = []
    if analyses:
        out += ["資料ごとの分析（各資料の原文を範囲ごとに読んで整理し、原文の表と照らし合わせた物。"
                "証拠と食い違う場合はこちらを優先）：",
                json.dumps(analyses, ensure_ascii=False, separators=(",", ":"))]
    if failed:
        out.append("次の資料は整理できませんでした。この資料については、証拠（file がこの資料名の物）"
                   "だけを根拠にしてください：" + "、".join(f"『{f}』" for f in failed))
    comp = state.get("case_comparison") or {}
    if any(comp.get(k) for k in comp):
        out += ["資料間の比較：", json.dumps(comp, ensure_ascii=False, separators=(",", ":"))]
    return "\n".join(out)
