"""
原生テキスト抽出（v3.28）。

Office → PDF 変換を経由せず、元ファイルから直接文字を取る。

使いどころは 2 つ：
  1. 融合ルート：全面レンダリング（画像）に**加えて**、原生テキストを証拠に渡す
  2. 視覚ルートで PDF 変換に失敗したとき：以前は text="" のまま進み、要約の
     材料が埋込画像の分析だけになっていた（十数分かけて中身の薄い要約になる）

変換後 PDF の文字層より原生抽取の方が良い理由：
  - PPTX のスピーカーノート、表のセル構造は PDF 化で消える
  - グループ化された図形内の文字は PDF 化で読み順が崩れやすい
  - 変換手段が無い環境でも動く

頁（スライド）の区切りを「## スライド N」「## p.N」の見出しで残す。
要約モデルが頁を手掛かりに図と本文を対応付けられるように。
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Tuple


def _pptx_text(path: str) -> str:
    from pptx import Presentation

    prs = Presentation(path)
    out: List[str] = []
    for sno, slide in enumerate(prs.slides, 1):
        title = ""
        try:
            if slide.shapes.title is not None:
                title = slide.shapes.title.text_frame.text.strip()
        except Exception:  # noqa: BLE001
            pass
        out.append(f"## スライド {sno}" + (f"：{title}" if title else ""))
        items = []
        for shp in slide.shapes:
            top, left = int(shp.top or 0), int(shp.left or 0)
            el = shp._element
            if getattr(shp, "has_table", False) and shp.has_table:
                rows = []
                for r in shp.table.rows:
                    cells = [c.text.strip().replace("\n", " ") for c in r.cells]
                    if any(cells):
                        rows.append("| " + " | ".join(cells) + " |")
                if rows:
                    items.append((top, left, "\n".join(rows)))
                continue
            try:
                paras = []
                for p in el.xpath(".//a:p"):
                    t = "".join(p.xpath(".//a:t/text()")).strip()
                    if t:
                        paras.append(t)
                t = "\n".join(paras)
            except Exception:  # noqa: BLE001
                t = ""
            if t and t != title:
                items.append((top, left, t))
        # 上→下、左→右の読み順
        for _, _, t in sorted(items, key=lambda x: (x[0], x[1])):
            out.append(t)
        try:
            if slide.has_notes_slide:
                notes = slide.notes_slide.notes_text_frame.text.strip()
                if notes:
                    out.append(f"（ノート）{notes}")
        except Exception:  # noqa: BLE001
            pass
        out.append("")
    return "\n".join(out).strip()


def _docx_text(path: str) -> str:
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    d = docx.Document(path)
    out: List[str] = []
    for el in d.element.body.iterchildren():
        tag = el.tag.split("}")[-1]
        if tag == "p":
            p = Paragraph(el, d)
            t = p.text.strip()
            if not t:
                continue
            name = (p.style.name if p.style is not None else "").lower()
            if name.startswith("heading") or name.startswith("見出し"):
                digits = "".join(ch for ch in name if ch.isdigit())
                level = min(4, int(digits)) if digits else 2
                out.append("#" * (level + 1) + " " + t)
            elif name == "title":
                out.append("# " + t)
            else:
                out.append(t)
        elif tag == "tbl":
            tbl = Table(el, d)
            for r in tbl.rows:
                cells = [c.text.strip().replace("\n", " ") for c in r.cells]
                if any(cells):
                    out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out).strip()


def _pdf_text(path: str) -> str:
    import pypdfium2 as pdfium

    pdf = pdfium.PdfDocument(path)
    out: List[str] = []
    try:
        for pno in range(len(pdf)):
            page = pdf[pno]
            tp = page.get_textpage()
            try:
                t = (tp.get_text_range() or "").strip()
            finally:
                tp.close()
                page.close()
            out.append(f"## p.{pno + 1}")
            if t:
                out.append(t)
            out.append("")
    finally:
        pdf.close()
    return "\n".join(out).strip()


def extract_native_text(path: str) -> Tuple[str, str]:
    """(本文, 使った手段) を返す。失敗・非対応は ("", 理由)。例外は投げない。"""
    suffix = Path(path).suffix.lower()
    try:
        if suffix in (".pptx", ".pptm"):
            return _pptx_text(path), "python-pptx"
        if suffix in (".docx", ".docm"):
            return _docx_text(path), "python-docx"
        if suffix == ".pdf":
            return _pdf_text(path), "pypdfium2"
    except Exception as e:  # noqa: BLE001
        return "", f"失敗: {type(e).__name__}: {str(e)[:120]}"
    return "", f"非対応の形式 {suffix}"
