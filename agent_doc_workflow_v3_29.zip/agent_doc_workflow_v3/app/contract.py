"""
数据契约（唯一真源 / Single Source of Truth）

v1 的核心病根：schema JSON、YAML 模板定义、Jinja 模板、fill_missing_fields
四处手抄同一份字段名，彼此漂移导致渲染全空。

v2 中：
- JSON Schema 由本模块自动生成（Pydantic -> model_json_schema）
- LLM 输出用 CaseSummary.model_validate 解析
- 缺省值由 Pydantic default 提供（不再需要 fill_missing_fields）
- Jinja 模板绑定本模型字段名（tests/test_contract.py 会静态校验模板变量）
"""
from __future__ import annotations

from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator

# 统一的"未知"哨兵值（v1 里「確認できず」和「明記なし」混用，v2 只留一个）
UNKNOWN = "資料内で確認できず"

# ---------------------------------------------------------------------------
# v3.8：UNKNOWN の三分割
# ---------------------------------------------------------------------------
#
# v3.7 は UNKNOWN ひとつで意味の違う 3 状態を表していた：
#
#   (a) この文書種別にはそもそも概念が無い（技術報告書に「依頼元」は無い）
#   (b) 有るはずだが資料から見つからなかった
#   (c) モデルが出力せず Pydantic の既定値で埋まった（＝抽出の失敗）
#
# 読み手にとって (a) と (b) は全く別の話なのに、同じ一文で描画されるため
# 「このシステムは何も読めていない」という印象になっていた。(c) に至っては
# 障害なのに正常出力と見分けが付かない。
#
# NOT_APPLICABLE を導入し、テンプレート側の applicability 宣言と突き合わせて
# 描画時に区別する。値そのものは日本語文字列のままなので、既存のテンプレート・
# Jinja・RAG 出力は壊れない（UNKNOWN と同じ扱いで通る）。
NOT_APPLICABLE = "該当なし（この文書種別には無い項目）"

# ---------------------------------------------------------------------------
# v3.12：推定で書いた項目の目印
# ---------------------------------------------------------------------------
#
# 「対応効果」など、資料に明記が無い項目が毎回まるごと空になるのは
# 読み手にとって不便だという要望への対応。ただし空欄を無条件に埋めさせるのは
# このシステムが一貫して避けてきた作話の入口そのものなので、次の線を引く：
#
#   - 関連する証拠から**定性的に言える範囲**は書いてよい
#   - 数値・日付・固有名詞・企業名を新たに作ることは禁止
#   - 書いたら必ずこの注記を末尾に付ける（読み手が事実と区別できる）
#   - 手掛かりが皆無なら従来どおり UNKNOWN
#
# 注記が付いた項目は加筆（expand_summary）の対象から外す。
# 推定をさらに膨らませるのは二重の作話になる。
INFERRED_NOTE = "（資料に明記なし・関連記述からの推定）"


def is_inferred(value) -> bool:
    """推定注記が付いているか。加筆対象の除外と品質集計に使う。"""
    if isinstance(value, str):
        return INFERRED_NOTE in value
    if isinstance(value, (list, tuple)):
        return any(is_inferred(v) for v in value)
    return False
EXTRACTION_FAILED = "抽出できず（処理エラー）"

#: 「値が無い」を表す全ての番兵。判定は必ずこの集合で行うこと。
BLANK_SENTINELS = frozenset({UNKNOWN, NOT_APPLICABLE, EXTRACTION_FAILED})


def is_blank(value) -> bool:
    """値が実質「空」か（番兵・空文字・番兵だけのリスト）。"""
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip() or value in BLANK_SENTINELS
    if isinstance(value, (list, tuple)):
        return all(is_blank(v) for v in value) if value else True
    return False


def schema_skeleton(schema: dict) -> "dict | list | str | float | bool":
    """把 JSON Schema 递归折叠成形状示例：{"name": "string", "items": ["string"], ...}"""
    defs = schema.get("$defs", {})

    def walk(node: dict):
        if "$ref" in node:
            return walk(defs[node["$ref"].split("/")[-1]])
        if "enum" in node:
            return " | ".join(str(v) for v in node["enum"])
        if "anyOf" in node:
            return walk(node["anyOf"][0])
        t = node.get("type")
        if t == "object":
            return {k: walk(v) for k, v in node.get("properties", {}).items()}
        if t == "array":
            return [walk(node.get("items", {"type": "string"}))]
        if t == "number":
            return 0.0
        if t == "integer":
            return 0
        if t == "boolean":
            return True
        return "string"

    return walk(schema)


# ---------------------------------------------------------------------------
# 证据（Agent 1 / Agent 2 的中间产物）
# ---------------------------------------------------------------------------

class EvidenceCategory(str, Enum):
    background = "background"
    requester = "requester"
    target = "target"
    issue = "issue"
    request_scope = "request_scope"
    action = "action"
    tool = "tool"
    period = "period"
    finding = "finding"
    effect = "effect"
    other = "other"


class EvidenceIn(BaseModel):
    # v3.4: category 放开为 str——各注册模板可定义自己的类别表；
    # 未知类别归一化为 "other" 而不是让整条证据报废
    evidence_id: str = ""
    category: str = "other"
    content: str = ""
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    source: str = ""

    @field_validator("category", mode="before")
    @classmethod
    def _coerce_category(cls, v):
        if isinstance(v, EvidenceCategory):
            return v.value
        if not isinstance(v, str) or not v.strip():
            return "other"
        return v.strip()

    @field_validator("confidence", mode="before")
    @classmethod
    def _coerce_confidence(cls, v):
        try:
            return max(0.0, min(1.0, float(v)))
        except (TypeError, ValueError):
            return 0.5


class Evidence(EvidenceIn):
    """内部用。EvidenceIn に溯源を足した物。

    LLM には EvidenceIn（元の 5 フィールド）だけを見せる。溯源はモデルの
    賢さに頼らずコードが確定的に埋めるので、スキーマに出すと
    「書けないフィールドを書け」と要求することになり有害。
    """
    chunk_id: str = ""
    page: Optional[int] = None      # 1 始まり。頁が特定できない場合は None
    heading: str = ""               # 直近の見出し（節タイトル / スライド名）
    sheet_name: str = ""            # Excel 用：シート名
    origin: str = "text"            # text | visual | excel | gap_fill


class EvidenceList(BaseModel):
    """LLM 境界。ここに溯源を混ぜてはいけない。"""
    evidence: List[EvidenceIn] = Field(default_factory=list)


class VisualEvidence(BaseModel):
    evidence_id: str = ""
    image_path: str = ""
    has_useful_visual_info: bool = False

    # ---- v3.8 溯源 ----
    # v3.7 では PDF の抽出画像はファイル名に頁番号を持っていた（pdf_p003_img01.png）
    # のに、_analyze_one_visual が asset_index しか渡さず**その情報を捨てていた**。
    # OOXML 由来の画像に至っては頁番号が最初から無い。ここで持たせる。
    page: Optional[int] = None
    sheet_name: str = ""            # Excel シート画像の場合
    asset_kind: str = "embedded"    # embedded | page_render | chart | sheet_render
    visual_type: str = "unknown"
    readable_text: List[str] = Field(default_factory=list)
    visual_summary: str = ""
    key_facts: List[str] = Field(default_factory=list)
    possible_relevance: List[str] = Field(default_factory=list)
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)

    # ---- v3.27.2 図版差し込み用 ----
    # 「この図を報告書に載せるとしたら」の観点は、図を 1 枚ずつ見ている
    # この時点でしか正確に取れない。後から N 枚を並べて選ばせるより、
    # 見ている最中に 1 枚ずつ判断させる方が弱いモデルでも当たる。
    figure_caption: str = ""        # 図の内容説明（要約モデルに渡す。長くてよい）
    figure_title: str = ""          # 図の見出し（成果物に表示。体言止め・20 字以内）
    figure_worthiness: str = ""     # core | supporting | incidental
    # v3.28：図の位置と周辺の文（位置索引から。VLM ではなくコードが付ける）
    figure_context: str = ""

    @field_validator("figure_worthiness", mode="before")
    @classmethod
    def _coerce_worthiness(cls, v):
        s = str(v or "").strip().lower()
        return s if s in ("core", "supporting", "incidental") else ""

    @field_validator("confidence", mode="before")
    @classmethod
    def _coerce_confidence(cls, v):
        try:
            return max(0.0, min(1.0, float(v)))
        except (TypeError, ValueError):
            return 0.0


# ---------------------------------------------------------------------------
# 最终摘要（Agent 3 的产物，也是渲染 MD 的输入）
# ---------------------------------------------------------------------------

def _unknown_list() -> List[str]:
    return [UNKNOWN]


class RequestDetails(BaseModel):
    main_title: str = ""
    requester: str = UNKNOWN
    target_product_or_system: str = UNKNOWN
    background: List[str] = Field(default_factory=_unknown_list)
    client_issues: List[str] = Field(default_factory=_unknown_list)
    scope_of_request: List[str] = Field(default_factory=_unknown_list)


class ActionResults(BaseModel):
    main_title: str = ""
    support_type: str = UNKNOWN
    tools_environment: List[str] = Field(default_factory=_unknown_list)
    period: str = UNKNOWN
    findings: List[str] = Field(default_factory=_unknown_list)
    effects: List[str] = Field(default_factory=_unknown_list)


class CaseSummary(BaseModel):
    case_name: str = UNKNOWN
    request_details: RequestDetails = Field(default_factory=RequestDetails)
    action_results: ActionResults = Field(default_factory=ActionResults)
    evidence: List[str] = Field(default_factory=list)

    def finalize_titles(self) -> "CaseSummary":
        """标题由代码统一生成，不信任 LLM 输出（v1 就是这么做的，保留）。"""
        self.request_details.main_title = f"依頼対応事例 ─「 {self.case_name} 」依頼内容"
        self.action_results.main_title = f"依頼対応事例 ─「 {self.case_name} 」対応結果"
        return self

    @classmethod
    def json_schema_for_llm(cls) -> dict:
        """给 llama.cpp 的 response_format / 校验用的 schema，自动生成，永不漂移。"""
        return cls.model_json_schema()

    @classmethod
    def skeleton(cls) -> dict:
        """从契约生成紧凑的"输出形状示例"。放进 prompt 比完整 JSON Schema
        （含 $defs/title 等噪声）省一半以上 token，且对本地小模型更易遵循。
        依然由契约自动生成——单一真源不破坏。"""
        return schema_skeleton(cls.model_json_schema())

    @classmethod
    def json_schema_for_validation(cls) -> dict:
        return cls.model_json_schema()
