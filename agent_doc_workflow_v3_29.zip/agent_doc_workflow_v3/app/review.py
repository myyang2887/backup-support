"""
確認・編集画面のための後端（v3.29）。

画面が必要とする物を 1 回で返す（要約・図版配置・全画像とその採否理由・根拠・
原資料のページ）。保存は「契約検証 → 版の保存 → 書き込み → 描画」の 1 本道で、
描画は figure_select.apply_figure_plan を必ず通る（修正タブで図が消えた
v3.28 までの不具合の再発防止）。
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .figure_select import (DEFAULTS, _resolve_original, apply_figure_plan, build_candidates,
                            find_anchors, load_plan, plan_from_report, rel_to_run, save_plan,
                            score_pair)

STATE_FILE = "review_state.json"
ANALYSIS_FILE = "review_analysis.json"

#: 画像を配信してよいディレクトリ（run 内のこれ以外は出さない）
ASSET_DIRS = {"visual_office", "visual_pdf", "visual_pages", "visual_excel",
              "visual_excel_sheets", "visual_filtered", "visual_contact", "figures"}
_IMG_SUFFIX = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}

#: 案件テンプレートの項目と見出し（出力と同じ順序・同じ言葉）
CASE_SECTIONS: List[Tuple[str, Optional[str], str]] = [
    ("title", "case_name", "案件名"),
    ("group", None, "依頼の概要"),
    ("text", "request_details.requester", "依頼元"),
    ("text", "request_details.target_product_or_system", "対象製品・システム"),
    ("list", "request_details.background", "背景"),
    ("list", "request_details.client_issues", "課題"),
    ("list", "request_details.scope_of_request", "依頼内容"),
    ("group", None, "実施内容"),
    ("text", "action_results.support_type", "対応種別"),
    ("list", "action_results.tools_environment", "使用機器・ソフト・ツール"),
    ("text", "action_results.period", "対応期間"),
    ("list", "action_results.findings", "調査・対応により判明した事実"),
    ("list", "action_results.effects", "対応効果・メリット"),
]
_SKIP_KEYS = {"evidence", "main_title"}


def _get(obj: Any, path: str) -> Any:
    cur = obj
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def review_sections(summary: Dict[str, Any]) -> List[Dict[str, Any]]:
    """画面に並べる項目。案件テンプレートは見出し付き、それ以外は構造から作る。"""
    if isinstance(summary.get("request_details"), dict) and isinstance(summary.get("action_results"), dict):
        out = []
        for kind, field, label in CASE_SECTIONS:
            if kind == "group" or _get(summary, field) is not None:
                out.append({"kind": kind, "field": field, "label": label})
        return out

    out: List[Dict[str, Any]] = []

    def walk(d: Dict[str, Any], prefix: str) -> None:
        for k, v in d.items():
            if k in _SKIP_KEYS:
                continue
            path = f"{prefix}.{k}" if prefix else k
            if isinstance(v, str):
                out.append({"kind": "text", "field": path, "label": k})
            elif isinstance(v, list) and all(isinstance(x, str) for x in v):
                out.append({"kind": "list", "field": path, "label": k})
            elif isinstance(v, dict):
                out.append({"kind": "group", "field": None, "label": k})
                walk(v, path)
    walk(summary, "")
    return out


# ----------------------------------------------------------------------
# 版・状態
# ----------------------------------------------------------------------

def version_token(run_dir: Path) -> str:
    """要約 JSON と配置データの内容から作る版。別の画面での更新を検出する。"""
    h = hashlib.sha1()
    for name in ("case_summary.json", "figure_plan.json"):
        p = Path(run_dir) / name
        h.update(p.read_bytes() if p.exists() else b"-")
    return h.hexdigest()[:16]


def read_state(run_dir: Path) -> Dict[str, Any]:
    try:
        return json.loads((Path(run_dir) / STATE_FILE).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {"reviewed": False, "external_stale": False}


def write_state(run_dir: Path, **kw: Any) -> Dict[str, Any]:
    st = read_state(run_dir)
    st.update(kw)
    if "reviewed" in kw:
        st["reviewed_at"] = time.strftime("%Y-%m-%d %H:%M:%S") if kw["reviewed"] else ""
    (Path(run_dir) / STATE_FILE).write_text(json.dumps(st, ensure_ascii=False, indent=2),
                                           encoding="utf-8")
    return st


# ----------------------------------------------------------------------
# 描画（唯一の経路）
# ----------------------------------------------------------------------

def ensure_plan(run_dir: Path, summary: Dict[str, Any]) -> Dict[str, Any]:
    plan = load_plan(run_dir)
    if plan is None:
        plan = plan_from_report(run_dir, summary) or {"version": 1, "source": "auto", "items": []}
        save_plan(run_dir, plan)
    return plan


def rerender(run_dir: Path, summary_model: Any, spec: Any,
             trust_index: bool = True) -> Tuple[str, Dict[str, Any]]:
    """要約 JSON → テンプレート → 図版配置 → md。修正タブと確認画面の両方が使う。"""
    from .render import render_markdown
    run_dir = Path(run_dir)
    summary = summary_model.model_dump(mode="json")
    plan = ensure_plan(run_dir, summary)
    md_path = run_dir / "case_summary.md"
    md = render_markdown(summary_model, str(spec.md_template_path), str(md_path))
    new_md, rep = apply_figure_plan(md, plan, run_dir, summary, trust_index=trust_index)
    md_path.write_text(new_md, encoding="utf-8")
    return new_md, rep


def clean_plan_items(items: List[Dict[str, Any]], run_dir: Path) -> List[Dict[str, Any]]:
    """画面から来た配置を検査する（run の外の画像を指させない）。"""
    out = []
    for i, it in enumerate(items or []):
        rel = str(it.get("image") or "")
        try:
            safe_asset(run_dir, rel)
        except ValueError:
            continue
        a = it.get("anchor") or {}
        if not isinstance(a.get("field"), str) or not isinstance(a.get("index"), int):
            continue
        out.append({"id": str(it.get("id") or f"u{i + 1}")[:40], "image": rel,
                    "anchor": {"field": a["field"], "index": a["index"],
                               "text": str(a.get("text") or "")[:400]},
                    "caption": str(it.get("caption") or "")[:120],
                    "label": str(it.get("label") or "")[:60],
                    "evidence_id": str(it.get("evidence_id") or "")[:40],
                    "origin": "user" if it.get("origin") == "user" else "auto"})
    return out


# ----------------------------------------------------------------------
# 画像
# ----------------------------------------------------------------------

def safe_asset(run_dir: Path, rel: str) -> Path:
    """run 内の許可ディレクトリにある画像だけを返す。それ以外は ValueError。"""
    rd = Path(run_dir).resolve()
    rel = (rel or "").replace("\\", "/").lstrip("/")
    parts = [p for p in rel.split("/") if p]
    if not parts or parts[0] not in ASSET_DIRS or ".." in parts:
        raise ValueError("許可されていない場所です")
    p = (rd / "/".join(parts)).resolve()
    try:
        p.relative_to(rd)
    except ValueError:
        raise ValueError("許可されていない場所です")
    if p.suffix.lower() not in _IMG_SUFFIX or not p.is_file():
        raise ValueError("画像が見つかりません")
    return p


def _key(path: str) -> str:
    s = Path(str(path)).stem
    return s[:-3] if s.endswith("_ds") else s


def _load(run_dir: Path, name: str, default: Any) -> Any:
    try:
        return json.loads((run_dir / name).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return default


def save_analysis(run_dir: Path, rel: str, result: Dict[str, Any]) -> None:
    data = _load(run_dir, ANALYSIS_FILE, {})
    data[rel] = result
    (run_dir / ANALYSIS_FILE).write_text(json.dumps(data, ensure_ascii=False, indent=2),
                                        encoding="utf-8")


def _clean_md_for_match(md: str) -> str:
    lines = [ln for ln in md.split("\n") if not ln.strip().startswith("![")]
    return "\n".join(re.sub(r"(（図[0-9・]+）)+\s*$", "", ln) for ln in lines)


def build_images(run_dir: Path, md: str, plan: Dict[str, Any]) -> List[Dict[str, Any]]:
    """全画像：採用中・候補・除外。位置による採点と、要約文との照合の両方の理由を付ける。"""
    rd = Path(run_dir)
    fc = _load(rd, "figure_candidates.json", {})
    ve = (_load(rd, "evidence_visual.json", {}) or {}).get("evidence", [])
    rep = _load(rd, "figures_report.json", {})
    analysis = _load(rd, ANALYSIS_FILE, {})
    items: Dict[str, Dict[str, Any]] = {}

    def slot(path: str) -> Dict[str, Any]:
        k = _key(path)
        if k not in items:
            rel = rel_to_run(rd, _resolve_original(str(path), rd))
            items[k] = {"key": k, "rel": rel, "page": None, "sheet_name": "", "unit_label": "",
                        "layout": None, "vlm": None, "match": None, "auto": None,
                        "evidence_id": "", "analyzed": False}
        return items[k]

    for c in (fc.get("candidates") or []):
        s = slot(c.get("path", ""))
        s.update({"page": c.get("page"), "sheet_name": c.get("sheet_name", ""),
                  "unit_label": c.get("unit_label", "")})
        s["layout"] = {k: c.get(k) for k in ("tier", "score", "parts", "reasons", "decor_reasons",
                                              "caption", "near_text", "title_text", "area_frac",
                                              "ref_count", "selected")}
    embedded = [v for v in ve if v.get("asset_kind") not in ("page_render", "sheet_render")]
    for v in embedded:
        s = slot(v.get("image_path", ""))
        s["evidence_id"] = v.get("evidence_id", "")
        s["analyzed"] = True
        if s["page"] is None:
            s["page"] = v.get("page")
        s["sheet_name"] = s["sheet_name"] or v.get("sheet_name", "")
        s["vlm"] = {k: v.get(k) for k in ("figure_title", "figure_caption", "figure_worthiness",
                                           "visual_summary", "visual_type", "confidence")}
    for rel, a in (analysis or {}).items():
        s = slot(str(rd / rel))
        s["analyzed"] = True
        s["vlm"] = {**(s["vlm"] or {}), **a}

    for p in (rep.get("picked") or []):
        k = _key(p.get("image", ""))
        if k in items:
            items[k]["auto"] = {"score": p.get("score"), "margin": p.get("margin"),
                                "via": p.get("via"), "bullet": p.get("bullet")}

    # 要約文との照合：各画像がどの項目に一番合うか（採用されなかった理由を数字で見せる）
    try:
        cfg = dict(DEFAULTS, min_image_confidence=0.0, allow_sections=[])
        _, anchors = find_anchors(_clean_md_for_match(md), cfg)
        fs = build_candidates(embedded, rd, cfg)
        for c in fs:
            k = _key(c.image_path)
            if k not in items or not anchors:
                continue
            scored = sorted(((score_pair(a.text, c, None)[0], a.text) for a in anchors),
                            key=lambda x: -x[0])
            best, text = scored[0]
            second = scored[1][0] if len(scored) > 1 else 0.0
            items[k]["match"] = {"best": round(best, 3), "margin": round(best - second, 3),
                                 "bullet": text[:90], "threshold": DEFAULTS["min_score"],
                                 "min_margin": DEFAULTS["min_margin"]}
    except Exception:  # noqa: BLE001 照合情報は補助。無くても画面は出す
        pass

    placed = {_key(it.get("image", "")) for it in (plan.get("items") or [])}
    out = []
    for k, s in items.items():
        tier = (s["layout"] or {}).get("tier")
        s["status"] = "inserted" if k in placed else ("excluded" if tier == "drop" else "candidate")
        thumb = rd / "visual_filtered" / f"{k}_ds.jpg"
        s["thumb_rel"] = thumb.relative_to(rd).as_posix() if thumb.exists() else s["rel"]
        s["label"] = (f"シート「{s['sheet_name']}」" if s["sheet_name"]
                      else (f"p.{s['page']}" if s["page"] else (s["unit_label"] or Path(s["rel"]).name)))
        if not (rd / s["rel"]).exists():
            continue
        out.append(s)
    order = {"inserted": 0, "candidate": 1, "excluded": 2}
    out.sort(key=lambda s: (order[s["status"]], -((s["match"] or {}).get("best") or 0),
                            -((s["layout"] or {}).get("score") or 0)))
    return out


def build_evidence(run_dir: Path) -> Dict[str, List[Dict[str, Any]]]:
    rd = Path(run_dir)
    raw = _load(rd, "evidence_text.json", {})
    ev = raw.get("evidence") if isinstance(raw, dict) else raw
    ev = ev or []
    pick = ("evidence_id", "category", "content", "page", "confidence", "source", "sheet_name")
    ledger = [{k: e.get(k) for k in pick} for e in ev if str(e.get("evidence_id", "")).startswith("ref_")]
    text = [{k: e.get(k) for k in pick} for e in ev if not str(e.get("evidence_id", "")).startswith("ref_")]
    pages = []
    for v in (_load(rd, "evidence_visual.json", {}) or {}).get("evidence", []):
        if v.get("asset_kind") in ("page_render", "sheet_render"):
            body = " ".join([v.get("visual_summary") or ""] + [str(x) for x in (v.get("key_facts") or [])])
            pages.append({"evidence_id": v.get("evidence_id"), "content": body.strip(),
                          "page": v.get("page"), "sheet_name": v.get("sheet_name", ""),
                          "confidence": v.get("confidence"), "category": "page"})
    return {"ledger": ledger, "text": text, "pages": pages}


def list_pages(run_dir: Path) -> List[Dict[str, Any]]:
    rd = Path(run_dir)
    out = []
    for d, label in (("visual_pages", "p."), ("visual_excel_sheets", "")):
        for p in sorted((rd / d).glob("*.png")) + sorted((rd / d).glob("*.jpg")):
            m = re.search(r"(\d+)", p.stem)
            name = f"p.{int(m.group(1))}" if (label and m) else p.stem
            out.append({"rel": p.relative_to(rd).as_posix(), "label": name})
    return out
