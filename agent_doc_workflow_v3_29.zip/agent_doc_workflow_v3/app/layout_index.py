"""
図版候補の位置索引と粗選別（v3.28）。

## 何のためにあるか

埋込画像を全部 VLM に読ませていたので、画像の多い資料で 50 回以上の
VLM 呼出（十数分）になっていた。しかも埋込画像を VLM に読ませる目的は
**図版差し込み**だけ（頁の内容は全面レンダリングが担う）。

そこで二段式にする：

    全埋込画像 → コードによる粗選別（安い・全量） → VLM による精読（高い・選ばれた物だけ）
               → figure_select による要約文との照合

粗選別の大原則は **「取りこぼしより拾いすぎ」**。ここで落とした画像は
二度と拾えない（VLM に読まれない＝差し込み候補にならない）が、多めに
拾ったコストは VLM 1 回分で済む。

## 使う手掛かり（形式ごとに取れる物が違う）

| 形式 | 位置 | 周辺テキスト | 装飾の判定 |
|---|---|---|---|
| PPTX | 図形の座標・スライドに占める面積 | 近い図形の文字・スライドタイトル・ノート | 3 枚以上のスライドで使用 / マスター・レイアウト由来 / ヘッダー・フッター帯 |
| PDF  | 画像オブジェクトの bbox（pypdfium2） | bbox 周辺の文字 | 同じ位置に 3 頁以上 / ヘッダー・フッター帯 |
| DOCX | 座標は無い。文書内の順序 | 前後の段落・直前の見出し | ヘッダー・フッター内の画像 |
| XLSX | アンカーのセル | アンカー周辺のセル・シート名・表頭 | （位置からは判定しにくい） |

**枚数で打ち切らない。** 旧実装は並び順で N 枚目以降を黙って捨てていた。
ここでは層分けとスコア分布で決める：

  - 必ず読む層：「図 3」「Fig. 2」「表 1」などの図題が近くにある（作者自身が図と
    明示した物）。上限なし
  - 捨てる層：装飾の証拠が確かな物（ロゴ・マスター画像・ヘッダー帯・極小）
  - 採点層：スコア分布の**急落点**で切る。なだらかなら閾値以上を全部取る
  - 網羅保証：候補のある頁（章・シート）には、最良の 1 枚を必ず残す
  - 安全網：頁数に比例した予算。超えたら**警告を出す**（黙って捨てない）
"""
from __future__ import annotations

import hashlib
import math
import posixpath
import re
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

# ----------------------------------------------------------------------
# 名前空間（ElementTree 用）
# ----------------------------------------------------------------------
NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "xdr": "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
    "m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
    "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
}
_R_EMBED = "{%s}embed" % NS["r"]
_R_ID = "{%s}id" % NS["r"]
_W = "{%s}" % NS["w"]

# ----------------------------------------------------------------------
# 既定のキーワード（config/figure_keywords.yaml で上書き・追加できる）
# ----------------------------------------------------------------------
DEFAULT_KEYWORDS: Dict[str, Any] = {
    "caption_patterns": [
        r"^(図|Fig\.?|Figure|表|Table|写真|グラフ|Photo)\s*[0-9０-９]+",
        r"^(図|表)\s*[一二三四五六七八九十]+",
        r"^[(（]?(図|表)[0-9０-９]+[)）]?",
    ],
    "categories": {
        "result": {"weight": 3.0, "words": [
            "結果", "測定結果", "解析結果", "評価結果", "試験結果", "計算結果", "比較",
            "推移", "分布", "相関", "傾向", "依存性", "変化", "差異", "向上", "低下",
            "改善", "増加", "減少", "ピーク", "最大", "最小", "平均"]},
        "method": {"weight": 2.0, "words": [
            "方法", "手法", "手順", "条件", "解析条件", "測定条件", "試験条件", "構成",
            "概要", "概略", "模式図", "構造", "原理", "フロー", "流れ", "モデル", "装置",
            "セットアップ", "配置", "寸法", "形状", "仕様"]},
        "data": {"weight": 2.0, "words": [
            "データ", "数値", "グラフ", "一覧", "ヒストグラム", "マップ", "コンター",
            "断面", "観察", "画像", "写真", "プロファイル", "スペクトル", "曲線",
            "特性", "実測", "計測", "定量"]},
        "conclusion": {"weight": 2.0, "words": [
            "考察", "結論", "まとめ", "所見", "推定", "予測", "検証", "妥当性", "効果",
            "要因", "メカニズム", "原因", "判明", "確認"]},
        "domain": {"weight": 1.5, "words": [
            "流速", "流量", "圧力", "圧力損失", "温度", "温度分布", "速度", "流線",
            "ベクトル", "メッシュ", "境界条件", "乱流", "熱伝達", "CFD", "CAE",
            "シミュレーション", "FloEFD",
            "弾性率", "粘弾性", "硬さ", "膜厚", "粗さ", "SEM", "AFM", "TEM", "XRD",
            "FT-IR", "ラマン", "組成", "結晶", "界面", "分散", "応力", "ひずみ",
            "透過率", "反射率", "屈折率", "輝度", "配光", "波長", "光学"]},
        "figure_ref": {"weight": 2.5, "words": [
            "下図", "上図", "右図", "左図", "次図", "に示す", "を示す", "示した",
            "以下の図", "参照", "図中"]},
    },
    "negative": {"weight": 1.0, "words": [
        "目次", "表紙", "会社概要", "会社紹介", "免責", "注意事項", "お問い合わせ",
        "問い合わせ先", "連絡先", "社外秘", "Confidential", "著作権", "Copyright",
        "改訂履歴", "変更履歴", "アジェンダ", "Agenda", "ご清聴", "Thank you"]},
    "location_weights": {"title": 3.0, "caption": 2.5, "near": 1.5,
                         "unit": 0.5, "page_reading": 1.0},
}

_NUM_UNIT_RE = re.compile(
    r"[0-9]+(?:[.,][0-9]+)?\s*(?:%|kPa|MPa|GPa|Pa|mm|cm|µm|μm|um|nm|℃|°C|K|Hz|kHz|rpm|"
    r"kN|N|kg|mg|g|m/s|L/min|mL|L|dB|kV|V|mA|A|kW|W|万円|円|日|時間|分|秒|倍|割|件|回)",
    re.IGNORECASE)


def _nfkc(s: str) -> str:
    return unicodedata.normalize("NFKC", str(s or ""))


def load_keywords(path: Optional[str | Path] = None) -> Dict[str, Any]:
    """キーワード表を読む。ファイルが無い・壊れている場合は既定表で動く。

    YAML 側は**追加・上書き**：categories は同名なら語を足し重みを置き換える。
    """
    kw = {
        "caption_patterns": list(DEFAULT_KEYWORDS["caption_patterns"]),
        "categories": {k: {"weight": v["weight"], "words": list(v["words"])}
                       for k, v in DEFAULT_KEYWORDS["categories"].items()},
        "negative": {"weight": DEFAULT_KEYWORDS["negative"]["weight"],
                     "words": list(DEFAULT_KEYWORDS["negative"]["words"])},
        "location_weights": dict(DEFAULT_KEYWORDS["location_weights"]),
    }
    if path:
        try:
            import yaml
            p = Path(path)
            data = yaml.safe_load(p.read_text(encoding="utf-8")) if p.is_file() else None
        except Exception:  # noqa: BLE001 壊れた設定で本流を止めない
            data = None
        if isinstance(data, dict):
            for pat in data.get("caption_patterns") or []:
                if pat not in kw["caption_patterns"]:
                    kw["caption_patterns"].append(str(pat))
            for name, spec in (data.get("categories") or {}).items():
                if not isinstance(spec, dict):
                    continue
                cur = kw["categories"].setdefault(name, {"weight": 1.0, "words": []})
                if "weight" in spec:
                    cur["weight"] = float(spec["weight"])
                for w in spec.get("words") or []:
                    if w not in cur["words"]:
                        cur["words"].append(str(w))
            neg = data.get("negative") or {}
            if isinstance(neg, dict):
                if "weight" in neg:
                    kw["negative"]["weight"] = float(neg["weight"])
                for w in neg.get("words") or []:
                    if w not in kw["negative"]["words"]:
                        kw["negative"]["words"].append(str(w))
            for k, v in (data.get("location_weights") or {}).items():
                kw["location_weights"][k] = float(v)
    kw["_caption_re"] = [re.compile(p, re.IGNORECASE) for p in kw["caption_patterns"]]
    kw["_cat_norm"] = {name: (spec["weight"], [_nfkc(w).lower() for w in spec["words"]])
                       for name, spec in kw["categories"].items()}
    kw["_neg_norm"] = [_nfkc(w).lower() for w in kw["negative"]["words"]]
    return kw


# ----------------------------------------------------------------------
# 候補
# ----------------------------------------------------------------------

@dataclass
class FigureCandidate:
    path: str
    key: str = ""                 # media の stem（image7）や PDF の (頁, 番号)
    unit_key: str = ""            # 網羅保証の単位（頁・シート・章）
    unit_label: str = ""          # 人に見せる単位名（p.6 / シート「売上」/ §解析結果）
    page: Optional[int] = None
    sheet_name: str = ""
    area_frac: Optional[float] = None   # 頁（スライド）に占める面積比
    px_area: int = 0
    px_short: int = 0
    nbytes: int = 0
    ref_count: int = 1
    title_text: str = ""
    near_text: str = ""
    unit_text: str = ""
    caption: str = ""
    decor_reasons: List[str] = field(default_factory=list)
    tier: str = "scored"          # keep / drop / scored
    score: float = 0.0
    parts: Dict[str, Optional[float]] = field(default_factory=dict)
    reasons: List[str] = field(default_factory=list)
    selected: bool = False

    def context(self, limit: int = 600) -> str:
        """VLM と figure_select に渡す周辺情報。"""
        bits = []
        if self.unit_label:
            bits.append(f"位置：{self.unit_label}")
        if self.title_text:
            bits.append(f"見出し：{self.title_text[:80]}")
        if self.caption:
            bits.append(f"図題：{self.caption[:80]}")
        if self.near_text:
            bits.append(f"周辺の文：{self.near_text}")
        return "\n".join(bits)[:limit]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ----------------------------------------------------------------------
# 安い前段（バイト数・短辺・重複）
# ----------------------------------------------------------------------

def _cheap_filter(cands: List[FigureCandidate], min_bytes: int, min_edge: int) -> None:
    """ファイルサイズ・短辺・完全重複で装飾を落とす。

    短辺（min(w, h)）が min_edge 未満なら落とす＝**両辺とも** min_edge 以上が必要。
    """
    seen: Dict[str, str] = {}
    for c in cands:
        try:
            data = Path(c.path).read_bytes()
        except OSError:
            c.tier = "drop"
            c.decor_reasons.append("画像ファイルを読めない")
            continue
        c.nbytes = len(data)
        digest = hashlib.sha1(data).hexdigest()
        if digest in seen:
            c.tier = "drop"
            c.decor_reasons.append(f"同一画像の重複（{Path(seen[digest]).name}）")
            continue
        seen[digest] = c.path
        try:
            from PIL import Image
            with Image.open(c.path) as im:
                w, h = im.size
            c.px_area, c.px_short = int(w) * int(h), int(min(w, h))
        except Exception:  # noqa: BLE001 開けない形式（EMF 等）はサイズ不明で通す
            pass
        if min_bytes and c.nbytes < min_bytes:
            c.tier = "drop"
            c.decor_reasons.append(f"ファイルサイズ {c.nbytes:,}B < {min_bytes:,}B")
        elif min_edge and c.px_short and c.px_short < min_edge:
            c.tier = "drop"
            c.decor_reasons.append(f"短辺 {c.px_short}px < {min_edge}px")


# ----------------------------------------------------------------------
# OOXML の小道具
# ----------------------------------------------------------------------

def _rels(zf: zipfile.ZipFile, name: str) -> Dict[str, str]:
    try:
        root = ET.fromstring(zf.read(name))
    except (KeyError, ET.ParseError):
        return {}
    return {r.get("Id"): r.get("Target", "")
            for r in root.iter("{%s}Relationship" % NS["rel"])}


def _rels_name(part: str) -> str:
    d, f = posixpath.split(part)
    return posixpath.join(d, "_rels", f + ".rels")


def _resolve(part: str, target: str) -> str:
    if target.startswith("/"):
        return target.lstrip("/")
    return posixpath.normpath(posixpath.join(posixpath.dirname(part), target))


def _office_stem(path: str) -> str:
    """office_p006_image11.png / office_image3_ds.jpg → image11 / image3"""
    name = Path(path).stem
    if name.endswith("_ds"):
        name = name[:-3]
    m = re.match(r"^office_(?:p\d+_)?(.+)$", name)
    return m.group(1) if m else name


def _pdf_key(path: str) -> Optional[Tuple[int, int]]:
    m = re.match(r"^pdf_p(\d+)_img(\d+)", Path(path).stem)
    return (int(m.group(1)), int(m.group(2))) if m else None


def _gap(a: Tuple[float, float, float, float], b: Tuple[float, float, float, float]) -> float:
    """2 つの矩形（left, top, width, height）の隙間の距離。重なれば 0。"""
    al, at, aw, ah = a
    bl, bt, bw, bh = b
    dx = max(0.0, max(al, bl) - min(al + aw, bl + bw))
    dy = max(0.0, max(at, bt) - min(at + ah, bt + bh))
    return math.hypot(dx, dy)


def _caption_in(texts: Iterable[str], kw: Dict[str, Any]) -> str:
    for t in texts:
        s = _nfkc(t).strip()
        for line in s.splitlines():
            line = line.strip()
            if line and any(r.search(line[:40]) for r in kw["_caption_re"]):
                return line[:120]
    return ""


def _in_header_footer_band(top_frac: float, bottom_frac: float, area_frac: Optional[float]) -> bool:
    """頁の上端 10%・下端 8% に収まる小さな画像。"""
    small = area_frac is None or area_frac < 0.05
    return small and (bottom_frac <= 0.10 or top_frac >= 0.92)


# ----------------------------------------------------------------------
# PPTX
# ----------------------------------------------------------------------

def _index_pptx(path: str, cands: List[FigureCandidate], kw: Dict[str, Any]) -> int:
    from pptx import Presentation

    prs = Presentation(path)
    sw, sh = float(prs.slide_width or 1), float(prs.slide_height or 1)
    diag = math.hypot(sw, sh)

    slide_refs: Dict[str, List[int]] = {}
    slides: Dict[int, Dict[str, Any]] = {}
    for sno, slide in enumerate(prs.slides, 1):
        title = ""
        try:
            if slide.shapes.title is not None:
                title = slide.shapes.title.text_frame.text.strip()
        except Exception:  # noqa: BLE001
            pass
        texts: List[Tuple[Tuple[float, float, float, float], str]] = []
        pics: Dict[str, Tuple[float, float, float, float]] = {}
        for shp in slide.shapes:
            bbox = (float(shp.left or 0), float(shp.top or 0),
                    float(shp.width or 0), float(shp.height or 0))
            el = shp._element
            try:
                rids = el.xpath(".//a:blip/@r:embed")
            except Exception:  # noqa: BLE001
                rids = []
            for rid in rids:
                try:
                    stem = Path(str(slide.part.related_part(rid).partname)).stem
                except Exception:  # noqa: BLE001
                    continue
                pics.setdefault(stem, bbox)
                refs = slide_refs.setdefault(stem, [])
                if sno not in refs:
                    refs.append(sno)
            try:
                t = " ".join(x.strip() for x in el.xpath(".//a:t/text()") if x.strip())
            except Exception:  # noqa: BLE001
                t = ""
            if t:
                texts.append((bbox, t))
        notes = ""
        try:
            if slide.has_notes_slide:
                notes = slide.notes_slide.notes_text_frame.text.strip()
        except Exception:  # noqa: BLE001
            pass
        slides[sno] = {"title": title, "texts": texts, "pics": pics, "notes": notes,
                       "n_pics": len(pics)}

    # マスター・レイアウトにだけ現れる画像＝全頁共通の装飾
    master_stems: set = set()
    with zipfile.ZipFile(path) as zf:
        for n in zf.namelist():
            if re.match(r"ppt/(slideMasters|slideLayouts)/_rels/[^/]+\.rels$", n):
                for tgt in _rels(zf, n).values():
                    if "media/" in tgt:
                        master_stems.add(Path(tgt).stem)

    for c in cands:
        stem = _office_stem(c.path)
        c.key = stem
        refs = slide_refs.get(stem, [])
        if not refs:
            if stem in master_stems:
                c.tier = "drop"
                c.decor_reasons.append("スライドマスター／レイアウトの画像（全ページ共通の装飾）")
            continue
        c.ref_count = len(refs)
        sno = refs[0]
        s = slides[sno]
        c.page = sno
        c.unit_key = f"p{sno}"
        c.unit_label = f"p.{sno}"
        c.title_text = s["title"]
        bbox = s["pics"].get(stem)
        if bbox:
            c.area_frac = (bbox[2] * bbox[3]) / (sw * sh)
            near = sorted(((_gap(bbox, b), t) for b, t in s["texts"] if t != s["title"]),
                          key=lambda x: x[0])
            close = [t for d, t in near if d <= 0.15 * diag][:5] or [t for _, t in near[:1]]
            c.near_text = " / ".join(close)[:500]
            c.caption = _caption_in([t for d, t in near if d <= 0.12 * diag], kw)
            if _in_header_footer_band(bbox[1] / sh, (bbox[1] + bbox[3]) / sh, c.area_frac):
                c.decor_reasons.append("ヘッダー／フッター帯にある小さな画像")
        c.unit_text = " ".join([s["title"]] + [t for _, t in s["texts"]] + [s["notes"]])[:2000]
        if c.ref_count >= 3:
            c.decor_reasons.append(f"{c.ref_count} 枚のスライドで繰り返し使用（ロゴ等）")
    return max(1, len(slides))


# ----------------------------------------------------------------------
# PDF（pypdfium2。PyMuPDF は AGPL なので使わない）
# ----------------------------------------------------------------------

def _obj_bounds(obj) -> Optional[Tuple[float, float, float, float]]:
    """画像オブジェクトの (left, bottom, right, top)。

    pypdfium2 は v5 で get_pos() を get_bounds() に改名した。利用環境の版に
    依存しないよう両方試す（片方だけだと、版によって全画像の位置が取れず
    サイズだけの採点に黙って落ちる）。
    """
    for name in ("get_bounds", "get_pos"):
        fn = getattr(obj, name, None)
        if fn is None:
            continue
        try:
            b = tuple(float(x) for x in fn())
            if len(b) == 4:
                return b  # type: ignore[return-value]
        except Exception:  # noqa: BLE001
            continue
    return None


def _index_pdf(path: str, cands: List[FigureCandidate], kw: Dict[str, Any]) -> int:
    import pypdfium2 as pdfium
    import pypdfium2.raw as pdfium_c

    pdf = pdfium.PdfDocument(path)
    recs: Dict[Tuple[int, int], Dict[str, Any]] = {}
    sig_pages: Dict[Tuple[int, int, int, int], set] = {}
    n_pages = len(pdf)
    try:
        for pno in range(n_pages):
            page = pdf[pno]
            W, H = page.get_size()
            tp = page.get_textpage()
            try:
                full = tp.get_text_range() or ""
            except Exception:  # noqa: BLE001
                full = ""
            title = next((ln.strip() for ln in full.splitlines()
                          if ln.strip() and len(ln.strip()) <= 60), "")
            try:
                objs = list(page.get_objects(filter=(pdfium_c.FPDF_PAGEOBJ_IMAGE,),
                                             max_depth=2))
            except Exception:  # noqa: BLE001
                objs = []
            for i, obj in enumerate(objs, 1):
                bounds = _obj_bounds(obj)
                if bounds is None:
                    continue
                l, b, r, t = bounds
                w, h = max(0.0, r - l), max(0.0, t - b)
                mx, my = max(36.0, 0.15 * W), max(36.0, 0.12 * H)
                try:
                    near = tp.get_text_bounded(left=max(0.0, l - mx), bottom=max(0.0, b - my),
                                               right=min(W, r + mx), top=min(H, t + my)) or ""
                except Exception:  # noqa: BLE001
                    near = ""
                sig = (round(l / 5), round(b / 5), round(w / 5), round(h / 5))
                sig_pages.setdefault(sig, set()).add(pno + 1)
                recs[(pno + 1, i)] = {
                    "area_frac": (w * h) / (W * H) if W and H else None,
                    "top_frac": 1.0 - (t / H) if H else 0.0,     # 上端からの位置
                    "bottom_frac": 1.0 - (b / H) if H else 1.0,
                    "near": re.sub(r"\s+", " ", near).strip(),
                    "title": title, "full": full, "sig": sig, "n": len(objs),
                }
            try:
                tp.close()
                page.close()
            except Exception:  # noqa: BLE001
                pass
    finally:
        try:
            pdf.close()
        except Exception:  # noqa: BLE001
            pass

    for c in cands:
        k = _pdf_key(c.path)
        if k is None:
            continue
        c.key = f"p{k[0]}_img{k[1]}"
        c.page = k[0]
        c.unit_key = f"p{k[0]}"
        c.unit_label = f"p.{k[0]}"
        rec = recs.get(k)
        if not rec:
            continue
        c.area_frac = rec["area_frac"]
        c.title_text = rec["title"]
        c.near_text = rec["near"][:500]
        c.unit_text = re.sub(r"\s+", " ", rec["full"])[:2000]
        c.caption = _caption_in(rec["near"].split("  ") + rec["near"].split("\n"), kw) \
            or _caption_in(re.split(r"(?<=[。．])", rec["near"]), kw)
        c.ref_count = len(sig_pages.get(rec["sig"], {k[0]}))
        if c.ref_count >= 3:
            c.decor_reasons.append(f"{c.ref_count} 頁の同じ位置に繰り返し出現（ロゴ等）")
        if _in_header_footer_band(rec["top_frac"], rec["bottom_frac"], c.area_frac):
            c.decor_reasons.append("ヘッダー／フッター帯にある小さな画像")
    return max(1, n_pages)


# ----------------------------------------------------------------------
# DOCX（頁の概念が無いので「章」を単位にする）
# ----------------------------------------------------------------------

def _docx_style_names(zf: zipfile.ZipFile) -> Dict[str, str]:
    try:
        root = ET.fromstring(zf.read("word/styles.xml"))
    except (KeyError, ET.ParseError):
        return {}
    out = {}
    for st in root.iter(_W + "style"):
        sid = st.get(_W + "styleId")
        nm = st.find(_W + "name")
        if sid and nm is not None:
            out[sid] = (nm.get(_W + "val") or "").lower()
    return out


def _index_docx(path: str, cands: List[FigureCandidate], kw: Dict[str, Any]) -> int:
    with zipfile.ZipFile(path) as zf:
        doc = ET.fromstring(zf.read("word/document.xml"))
        rels = _rels(zf, "word/_rels/document.xml.rels")
        styles = _docx_style_names(zf)
        header_stems: set = set()
        for n in zf.namelist():
            if re.match(r"word/_rels/(header|footer)\d*\.xml\.rels$", n):
                for tgt in _rels(zf, n).values():
                    if "media/" in tgt:
                        header_stems.add(Path(tgt).stem)

    body = doc.find(_W + "body")
    if body is None:
        return 1
    pg_w, pg_h = 11906.0, 16838.0                   # A4（twip）
    sect = body.find(_W + "sectPr")
    if sect is not None:
        sz = sect.find(_W + "pgSz")
        if sz is not None:
            pg_w = float(sz.get(_W + "w") or pg_w)
            pg_h = float(sz.get(_W + "h") or pg_h)
    page_emu = (pg_w * 635.0) * (pg_h * 635.0)

    blocks: List[Dict[str, Any]] = []
    for el in body:
        if el.tag == _W + "p":
            text = "".join(t.text or "" for t in el.iter(_W + "t")).strip()
            sid = ""
            ppr = el.find(_W + "pPr")
            is_head = False
            is_cap = False
            if ppr is not None:
                ps = ppr.find(_W + "pStyle")
                if ps is not None:
                    sid = ps.get(_W + "val") or ""
                if ppr.find(_W + "outlineLvl") is not None:
                    is_head = True
            sname = styles.get(sid, sid.lower())
            if re.match(r"(heading\s*\d|title|見出し)", sname):
                is_head = True
            if sname in ("caption",) or "図表番号" in sname:
                is_cap = True
            imgs = []
            for d in el.iter("{%s}drawing" % NS["w"]):
                blip = d.find(".//{%s}blip" % NS["a"])
                ext = d.find(".//{%s}extent" % NS["wp"])
                if blip is None:
                    continue
                tgt = rels.get(blip.get(_R_EMBED) or "", "")
                if not tgt:
                    continue
                cx = float(ext.get("cx") or 0) if ext is not None else 0.0
                cy = float(ext.get("cy") or 0) if ext is not None else 0.0
                imgs.append((Path(tgt).stem, cx, cy))
            blocks.append({"text": text, "head": is_head and bool(text), "cap": is_cap,
                           "imgs": imgs})
        elif el.tag == _W + "tbl":
            rows = []
            for tr in el.iter(_W + "tr"):
                cells = ["".join(t.text or "" for t in tc.iter(_W + "t")).strip()
                         for tc in tr.iter(_W + "tc")]
                if any(cells):
                    rows.append(" | ".join(cells))
            blocks.append({"text": "\n".join(rows)[:600], "head": False, "cap": False,
                           "imgs": []})

    heading, sec_no = "", 0
    where: Dict[str, Dict[str, Any]] = {}
    for bi, b in enumerate(blocks):
        if b["head"]:
            heading, sec_no = b["text"], sec_no + 1
        for stem, cx, cy in b["imgs"]:
            if stem in where:
                where[stem]["refs"] += 1
                continue
            prev = [blocks[j]["text"] for j in range(bi - 1, max(-1, bi - 3), -1)
                    if blocks[j]["text"]][:2]
            nxt = [blocks[j]["text"] for j in range(bi + 1, min(len(blocks), bi + 3))
                   if blocks[j]["text"]][:2]
            near = [x for x in ([b["text"]] + prev[::-1] + nxt) if x]
            cap_cands = [blocks[j]["text"] for j in (bi - 1, bi + 1)
                         if 0 <= j < len(blocks) and blocks[j]["text"]
                         and (blocks[j]["cap"] or True)]
            section_text = " ".join(x["text"] for x in blocks
                                    if x["text"])[:0]  # 章全体は下で埋める
            where[stem] = {"sec": sec_no, "heading": heading, "near": " / ".join(near)[:500],
                           "cap": _caption_in(cap_cands + ([b["text"]] if b["text"] else []), kw),
                           "area": (cx * cy / page_emu) if (cx and cy) else None,
                           "refs": 1, "section_text": section_text}

    # 章ごとの全文（単位テキスト）
    sec_text: Dict[int, List[str]] = {}
    cur = 0
    for b in blocks:
        if b["head"]:
            cur += 1
        if b["text"]:
            sec_text.setdefault(cur, []).append(b["text"])

    for c in cands:
        stem = _office_stem(c.path)
        c.key = stem
        if stem in header_stems and stem not in where:
            c.tier = "drop"
            c.decor_reasons.append("ヘッダー／フッター内の画像（全ページ共通の装飾）")
            continue
        w = where.get(stem)
        if not w:
            continue
        c.page = None                     # Word に頁は無い（出現順を頁と誤認させない）
        c.unit_key = f"sec{w['sec']}"
        c.unit_label = f"§{w['heading'][:30]}" if w["heading"] else "本文冒頭"
        c.title_text = w["heading"]
        c.near_text = w["near"]
        c.caption = w["cap"]
        c.area_frac = w["area"]
        c.ref_count = w["refs"]
        c.unit_text = " ".join(sec_text.get(w["sec"], []))[:2000]
    return max(1, len(sec_text))


# ----------------------------------------------------------------------
# XLSX（頁の代わりにシート。画像とシートの対応はここで初めて作る）
# ----------------------------------------------------------------------

def _index_xlsx(path: str, cands: List[FigureCandidate], kw: Dict[str, Any]) -> int:
    anchors: Dict[str, Dict[str, Any]] = {}
    sheet_names: List[str] = []
    with zipfile.ZipFile(path) as zf:
        try:
            wb = ET.fromstring(zf.read("xl/workbook.xml"))
        except (KeyError, ET.ParseError):
            return 1
        wb_rels = _rels(zf, "xl/_rels/workbook.xml.rels")
        for sidx, sh in enumerate(wb.iter("{%s}sheet" % NS["m"]), 1):
            name = sh.get("name") or f"Sheet{sidx}"
            sheet_names.append(name)
            tgt = wb_rels.get(sh.get(_R_ID) or "", "")
            if not tgt:
                continue
            spart = _resolve("xl/workbook.xml", tgt)
            for dtgt in _rels(zf, _rels_name(spart)).values():
                if "drawings/" not in dtgt:
                    continue
                dpart = _resolve(spart, dtgt)
                try:
                    droot = ET.fromstring(zf.read(dpart))
                except (KeyError, ET.ParseError):
                    continue
                drels = _rels(zf, _rels_name(dpart))
                for anc in list(droot):
                    frm = anc.find("{%s}from" % NS["xdr"])
                    col = row = 0
                    if frm is not None:
                        try:
                            col = int(frm.find("{%s}col" % NS["xdr"]).text or 0)
                            row = int(frm.find("{%s}row" % NS["xdr"]).text or 0)
                        except (AttributeError, ValueError):
                            pass
                    for blip in anc.iter("{%s}blip" % NS["a"]):
                        mt = drels.get(blip.get(_R_EMBED) or "", "")
                        if mt:
                            anchors.setdefault(Path(mt).stem, {
                                "sheet": name, "sidx": sidx, "row": row, "col": col})

    # 周辺セル（openpyxl）
    near_cache: Dict[Tuple[str, int, int], str] = {}
    head_cache: Dict[str, str] = {}
    try:
        import openpyxl
        wbk = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception:  # noqa: BLE001
        wbk = None

    def _cells(ws, r0, r1, c0, c1) -> List[str]:
        out = []
        try:
            for row in ws.iter_rows(min_row=r0, max_row=r1, min_col=c0, max_col=c1,
                                    values_only=True):
                for v in row:
                    if v is not None and str(v).strip():
                        out.append(str(v).strip())
        except Exception:  # noqa: BLE001
            pass
        return out

    for c in cands:
        stem = _office_stem(c.path)
        c.key = stem
        a = anchors.get(stem)
        if not a:
            continue
        c.sheet_name = a["sheet"]
        c.unit_key = f"sheet{a['sidx']}"
        c.unit_label = f"シート「{a['sheet']}」"
        c.title_text = a["sheet"]
        k = (a["sheet"], a["row"], a["col"])
        if wbk is not None and a["sheet"] in wbk.sheetnames:
            ws = wbk[a["sheet"]]
            if k not in near_cache:
                r, cc = a["row"] + 1, a["col"] + 1
                near_cache[k] = " / ".join(_cells(ws, max(1, r - 4), r + 20,
                                                  max(1, cc - 3), cc + 10))[:500]
            if a["sheet"] not in head_cache:
                head_cache[a["sheet"]] = " ".join(_cells(ws, 1, 3, 1, 20))[:600]
            c.near_text = near_cache[k]
            c.unit_text = (head_cache[a["sheet"]] + " " + near_cache[k])[:2000]
            c.caption = _caption_in(near_cache[k].split(" / "), kw)
    try:
        if wbk is not None:
            wbk.close()
    except Exception:  # noqa: BLE001
        pass
    return max(1, len(sheet_names))


# ----------------------------------------------------------------------
# 採点
# ----------------------------------------------------------------------

def _kw_raw(text: str, loc_weight: float, kw: Dict[str, Any]) -> float:
    """語の**種類数**で数える（長い文に同じ語が何度出ても膨らませない）。"""
    if not text:
        return 0.0
    s = _nfkc(text).lower()
    total = 0.0
    for _name, (w, words) in kw["_cat_norm"].items():
        hits = sum(1 for word in words if word and word in s)
        total += w * loc_weight * min(hits, 3)
    return total


def _neg_hit(text: str, kw: Dict[str, Any]) -> str:
    s = _nfkc(text or "").lower()
    return next((w for w in kw["_neg_norm"] if w and w in s), "")


def score_candidate(c: FigureCandidate, kw: Dict[str, Any], unit_size: int,
                    page_reading: Optional[str] = None) -> None:
    """0〜1 のスコアを付ける。装飾・図題による層分けもここで確定する。"""
    lw = kw["location_weights"]
    if c.tier != "drop" and c.decor_reasons:
        c.tier = "drop"
    if c.tier == "drop":
        c.score = 0.0
        return

    if c.area_frac is not None:
        size = min(1.0, c.area_frac / 0.20)
        if c.area_frac < 0.015:
            c.tier = "drop"
            c.decor_reasons.append(f"頁に占める面積 {c.area_frac * 100:.1f}% が小さすぎる")
            c.score = 0.0
            return
    else:
        size = min(1.0, (c.px_area or 0) / float(800 * 600))

    raw = (_kw_raw(c.title_text, lw["title"], kw)
           + _kw_raw(c.caption, lw["caption"], kw)
           + _kw_raw(c.near_text, lw["near"], kw)
           + _kw_raw(c.unit_text, lw["unit"], kw))
    kws = 1.0 - math.exp(-raw / 12.0)
    nums = min(1.0, len(_NUM_UNIT_RE.findall(_nfkc(c.near_text + " " + c.caption))) / 3.0)
    sparse = {1: 1.0, 2: 0.6, 3: 0.4}.get(max(1, unit_size), 0.2)

    parts: Dict[str, Optional[float]] = {"size": size, "keyword": kws, "numeric": nums,
                                         "sparse": sparse, "page_reading": None}
    weights = {"size": 0.28, "keyword": 0.34, "numeric": 0.14, "sparse": 0.10,
               "page_reading": 0.14}
    if page_reading:
        pr_kw = 1.0 - math.exp(-_kw_raw(page_reading, lw.get("page_reading", 1.0), kw) / 12.0)
        pr_num = min(1.0, len(_NUM_UNIT_RE.findall(_nfkc(page_reading))) / 5.0)
        parts["page_reading"] = 0.5 * pr_kw + 0.5 * pr_num
    usable = {k: v for k, v in parts.items() if v is not None}
    wsum = sum(weights[k] for k in usable) or 1.0
    score = sum(weights[k] * usable[k] for k in usable) / wsum

    neg = _neg_hit(c.title_text, kw) or _neg_hit(c.unit_text[:200], kw)
    if neg:
        score -= 0.25 * float(kw["negative"]["weight"])
        c.reasons.append(f"「{neg}」の頁（装飾の可能性）")
    if c.ref_count == 2:
        score -= 0.05

    c.parts = {k: (None if v is None else round(v, 3)) for k, v in parts.items()}
    c.score = round(max(0.0, min(1.0, score)), 4)
    if c.caption:
        c.tier = "keep"
        c.reasons.append(f"図題あり：{c.caption[:30]}")


def build_figure_candidates(input_path: str, image_paths: List[str],
                            kw: Optional[Dict[str, Any]] = None,
                            min_bytes: int = 5120, min_edge: int = 100,
                            ) -> Tuple[List[FigureCandidate], int, Dict[str, Any]]:
    """画像群に位置情報を付けて採点する（選別はまだしない）。

    位置の取得に失敗しても例外は投げず、サイズだけで採点した候補を返す
    （「読めなかったから全部捨てる」にはしない）。
    """
    kw = kw or load_keywords()
    cands = [FigureCandidate(path=str(p)) for p in image_paths]
    _cheap_filter(cands, min_bytes, min_edge)

    suffix = Path(input_path).suffix.lower()
    n_units = 1
    meta: Dict[str, Any] = {"format": suffix, "layout": "none"}
    live = [c for c in cands if c.tier != "drop"]
    try:
        if suffix in (".pptx", ".pptm"):
            n_units = _index_pptx(input_path, live, kw)
        elif suffix == ".pdf":
            n_units = _index_pdf(input_path, live, kw)
        elif suffix in (".docx", ".docm"):
            n_units = _index_docx(input_path, live, kw)
        elif suffix in (".xlsx", ".xlsm"):
            n_units = _index_xlsx(input_path, live, kw)
        meta["layout"] = "ok"
    except Exception as e:  # noqa: BLE001 位置が取れなくてもサイズで続行
        meta["layout"] = f"failed: {type(e).__name__}: {str(e)[:120]}"

    per_unit: Dict[str, int] = {}
    for c in cands:
        if c.tier != "drop" and not c.decor_reasons:
            per_unit[c.unit_key or c.path] = per_unit.get(c.unit_key or c.path, 0) + 1
    for c in cands:
        score_candidate(c, kw, per_unit.get(c.unit_key or c.path, 1))
    meta["units"] = n_units
    return cands, n_units, meta


def rescore_with_page_reading(cands: List[FigureCandidate], page_texts: Dict[int, str],
                              kw: Optional[Dict[str, Any]] = None) -> None:
    """頁の全面読み取り結果を足して採点し直す（視覚／融合ルートの第二段）。

    頁の VLM 読み取りには、その頁の図が何を示しているかが既に書かれている。
    追加の VLM 呼出なしで、キーワードだけより強い手掛かりになる。
    """
    kw = kw or load_keywords()
    per_unit: Dict[str, int] = {}
    for c in cands:
        if c.tier != "drop":
            per_unit[c.unit_key or c.path] = per_unit.get(c.unit_key or c.path, 0) + 1
    for c in cands:
        if c.tier == "drop":
            continue
        pr = page_texts.get(c.page) if c.page is not None else None
        c.reasons = [r for r in c.reasons if not r.startswith("図題あり")]
        was_keep = c.tier == "keep"
        c.tier = "scored"
        score_candidate(c, kw, per_unit.get(c.unit_key or c.path, 1), page_reading=pr)
        if was_keep:
            c.tier = "keep"


# ----------------------------------------------------------------------
# 選別（枚数で打ち切らない）
# ----------------------------------------------------------------------

SELECT_DEFAULTS: Dict[str, Any] = {
    "min_score": 0.20,        # これ未満は採点層から外す
    "elbow_abs": 0.10,        # 急落とみなす差（絶対）
    "elbow_rel": 0.35,        # 急落とみなす差（直前のスコアに対する比）
    "min_take": 3,            # 急落判定を始める前に最低限取る数
    "coverage_floor": 0.15,   # 頁の代表として残す最低スコア
    "budget_per_unit": 1.5,   # 安全網：頁（章・シート）あたり
    "budget_min": 8,          # 安全網：最低枠
}


def select_figure_candidates(cands: List[FigureCandidate], n_units: int,
                             cfg: Optional[Dict[str, Any]] = None,
                             ) -> Tuple[List[FigureCandidate], Dict[str, Any]]:
    conf = dict(SELECT_DEFAULTS)
    conf.update({k: v for k, v in (cfg or {}).items() if v is not None})

    drop_reasons: Dict[str, int] = {}
    for c in cands:
        c.selected = False
        if c.tier == "drop":
            key = re.sub(r"[0-9,.]+", "N", c.decor_reasons[0]) if c.decor_reasons else "装飾"
            drop_reasons[key] = drop_reasons.get(key, 0) + 1

    keep = [c for c in cands if c.tier == "keep"]
    scored = sorted([c for c in cands if c.tier == "scored"], key=lambda c: -c.score)
    above = [c for c in scored if c.score >= float(conf["min_score"])]

    cut = len(above)
    cut_reason = f"閾値 {conf['min_score']} 以上を全て採用（急落なし）"
    start = max(0, int(conf["min_take"]) - 1)
    for k in range(start, len(above) - 1):
        a, b = above[k].score, above[k + 1].score
        if (a - b) >= max(float(conf["elbow_abs"]), float(conf["elbow_rel"]) * a):
            cut = k + 1
            cut_reason = f"{k + 1} 件目と {k + 2} 件目の間でスコアが急落（{a:.2f}→{b:.2f}）"
            break
    chosen: List[FigureCandidate] = keep + above[:cut]

    # 網羅保証：候補のある頁（章・シート）に代表を 1 枚
    covered = {c.unit_key for c in chosen if c.unit_key}
    coverage_added = 0
    chosen_ids = {id(c) for c in chosen}
    for c in scored:
        if (c.unit_key and c.unit_key not in covered and id(c) not in chosen_ids
                and c.score >= float(conf["coverage_floor"])):
            c.reasons.append("この頁（章・シート）の代表として追加")
            chosen.append(c)
            chosen_ids.add(id(c))
            covered.add(c.unit_key)
            coverage_added += 1

    # 安全網：頁数比例の予算。図題付き（keep）は削らない
    budget = max(int(conf["budget_min"]),
                 int(math.ceil(max(1, n_units) * float(conf["budget_per_unit"]))))
    trimmed = 0
    warning = ""
    others = [c for c in chosen if c.tier != "keep"]
    allowed = max(0, budget - len(keep))
    if len(others) > allowed:
        others.sort(key=lambda c: -c.score)
        for c in others[allowed:]:
            c.reasons.append("予算上限のため見送り")
        trimmed = len(others) - allowed
        others = others[:allowed]
        warning = (f"図版候補が予算（{budget} 枚＝{n_units} 単位×{conf['budget_per_unit']}）を"
                   f"超えたため、スコアの低い {trimmed} 枚を見送りました")
    final = keep + others
    for c in final:
        c.selected = True

    order = {id(c): i for i, c in enumerate(cands)}
    final.sort(key=lambda c: order.get(id(c), 0))
    report = {
        "total": len(cands), "dropped": sum(drop_reasons.values()),
        "dropped_by": drop_reasons, "keep": len(keep), "scored": len(scored),
        "above_floor": len(above), "cut_reason": cut_reason,
        "coverage_added": coverage_added, "budget": budget, "budget_trimmed": trimmed,
        "selected": len(final), "units": n_units, "warning": warning,
    }
    return final, report
