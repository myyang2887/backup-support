"""
LangGraph 节点（v3）。

v3 相比 v2 的变化（按对"十页 PDF 一小时"的贡献排序）：
1. Docling 只转换一次（v2 转两次，解析时间减半）+ OCR 可关
2. 阶段级缓存（resume）：同内容文件重跑时，解析/证据提取/视觉分析直接复用产物
3. 视觉资产预过滤（尺寸/字节/SHA1 去重）+ 降采样到 1024px：
   VLM 调用次数和单次 prompt 体积同时下降，这通常是 PDF 场景最大的时间黑洞
4. 视觉分析并行化（v2 只有文本提取能并行）
5. 结构感知切块 + 信息量过滤：更少、更干净的 chunk = 更少的 LLM 调用
6. 证据提取 max_tokens 4096 -> 2048
7. 新增 gap_fill 节点：聚合后关键类别缺证据时做一次针对性补提取（agent 化的第一步）
8. 细粒度进度（节点内 i/N 计数）+ 每节点耗时写入 status.json，Web UI 可视化
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import time
import traceback
import datetime as _dt
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, TypedDict

from pydantic import ValidationError

from tools.doc_tools import xlsx_to_html
from tools.visual_asset_tools import collect_visual_assets, collect_html_text_sources

from .cell_format import parse_date_string
from .config import AppConfig, PROJECT_ROOT
from .contract import (INFERRED_NOTE, is_blank, is_inferred, Evidence, EvidenceList, VisualEvidence, UNKNOWN, schema_skeleton)
from .accounting import LossLedger, conservation_check
from .trace import (ENGINE_PYTHON_PPTX, ENGINE_PYTHON_DOCX, PipelineTrace, ENGINE_DOCLING, ENGINE_PYPDFIUM,
                    ENGINE_OPENPYXL, ENGINE_LIBREOFFICE, ENGINE_WIN32COM,
                    ENGINE_PILLOW, ENGINE_OFFICE_COM, ENGINE_OFFICE2PDF)
from .template_registry import TemplateSpec, get_registry
from .template_route import decide_template
from .reference_index import (build_index, load_reference_specs,
                              CONFIRMED_THRESHOLD, MatchResult,
                              ReferenceSpec, normalize_text)
from .evidence import aggregate_evidence, visual_to_pack
from .llm_client import LocalLLMClient, LLMJsonError
from .observability import RunCancelled, RunStore
from .rag_export import write_jsonl as rag_write_jsonl
from .redaction import NGDictionary, redact_summary
from .parsing import (build_page_text_index, convert_document_once, extract_office_visuals, extract_pdf_visuals,
                      office_to_pdf, pdf_text_fallback, render_pdf_pages,
                      prefilter_and_downscale_images, structural_chunks,
                      structural_chunks_traced)
from .route_decision import decide_route

#: v3.13 openpyxl 本文が「実質空」と見なす閾値。これ未満なら HTML 保険へ回す。
#: 見出し行（"# ファイル名"）だけでも数十字にはなるので、それより少し上に置く。
_EXCEL_MD_MIN_CHARS = 120
from .excel_extract import workbook_to_markdown, extract_charts, inspect_workbook, chart_to_markdown


class WorkflowState(TypedDict, total=False):
    input_path: str
    run_dir: str

    markdown_path: str
    docling_json_path: str
    # v3.11 テンプレート自動判定の結果
    template_id: str
    template_route_reason: str
    # v3.14 参照台帳
    reference_paths: List[str]
    # v3.21 元の置き場所（アップロードで inbox に移される前）。台帳照合に使う。
    source_name: str
    source_rel_path: str
    reference_match: Dict[str, Any]
    reference_evidence: List[Dict[str, Any]]
    excel_html_path: str

    # v3.6 解析ルート（"text" = Docling / "vision" = 全ページ画像化して VLM 直読）
    excel_info: Dict[str, Any]
    # v3.8 損失台帳（本文/視覚は並行に走るのでキーを分ける。合流点で merge）
    loss_text: Dict[str, Any]
    loss_visual: Dict[str, Any]
    # v3.9 実行トレース（どのルート・どの実装で処理したか）。分岐衝突を避けて分離
    trace_main: Dict[str, Any]
    trace_visual: Dict[str, Any]
    page_report: Dict[str, Any]
    expanded_fields: List[str]
    route: str
    route_reason: str
    vision_pdf_path: str

    html_text_sources: List[Dict[str, Any]]
    chunks: List[Dict[str, Any]]

    text_evidence: List[dict]
    aggregated_evidence: List[dict]
    visual_asset_paths: List[str]
    visual_evidence: List[dict]
    figure_candidates: List[Dict[str, Any]]   # v3.28 頁読み取り後に選ぶ図版候補
    figure_units: int
    figure_context_map: Dict[str, Any]

    summary: dict
    summary_raw: dict
    summary_degraded: bool
    summary_errors: List[str]
    validation: Dict[str, Any]
    repair_attempts: int

    output_markdown: str
    output_json: str
    figures: Dict[str, Any]               # v3.27 図版差し込みの採否レポート
    effects_pass: Dict[str, Any]          # v3.27.11 対応効果の専用パスの結果
    errors: List[Dict[str, Any]]
    errors_visual: List[Dict[str, Any]]   # 视觉分支专用（并行时避免写冲突）





# 视觉分支与文本分支并行运行时，两者不能写同一个 state key（LangGraph 会判为
# 并发写冲突）。因此视觉分支的错误进 errors_visual，在汇合节点合并回 errors。
# 【重要】parallel_branches 有効時、分支内のノードは「自分が書いた key だけ」を
# 返すこと（state 全体を返すと相手分支の key と衝突し InvalidUpdateError）。
# 対象：chunk_text / extract_text_evidence / aggregate_evidence / gap_fill（文本分支）と
#       collect_visual_assets / analyze_visual（視覚分支）。
# 分支外のノード（parse/write_summary 以降）は従来どおり state 全体を返してよい。
VISUAL_NODES = {"collect_visual_assets", "analyze_visual"}


def _error_key(node: str) -> str:
    return "errors_visual" if node in VISUAL_NODES else "errors"


def _push_error(state: WorkflowState, node: str, message: str, detail: str = "") -> None:
    state.setdefault(_error_key(node), []).append(
        {"node": node, "message": message, "detail": detail[:2000], "time": time.strftime("%Y-%m-%d %H:%M:%S")}
    )


def _all_errors(state: WorkflowState) -> List[Dict[str, Any]]:
    return list(state.get("errors", [])) + list(state.get("errors_visual", []))


def _save_json(data: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _store(state: WorkflowState) -> RunStore:
    return RunStore(state["run_dir"])


def _update_status(state: WorkflowState, node: str, phase: str = "running",
                   detail: str = "", peek: str = "") -> None:
    if not state.get("run_dir"):
        return
    _store(state).event(node, phase, detail, errors=_all_errors(state),
                        peek=peek or None)


def file_hash(path: str) -> str:
    """v3 改为内容哈希：同内容文件（哪怕改名/重新上传）命中同一 run_dir，缓存才有意义。"""
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()[:12]


# v3.29：確認画面から 1 枚だけ解析するときも同じ指示を使うため、モジュール直下に置く
VISION_SYSTEM = """あなたは視覚文書分析エージェントです。
文書から抽出された画像・図表・フロー図・アーキテクチャ図・実験結果・スクリーンショットを分析します。

JSON のみを出力してください。形式：
{
  "has_useful_visual_info": true,
  "visual_type": "architecture_diagram | workflow_diagram | chart | table | screenshot | photo | simulation_result | mixed | decoration | unknown",
  "readable_text": ["string"],
  "visual_summary": "string",
  "key_facts": ["string"],
  "possible_relevance": ["background", "issue", "request_scope", "action", "tool", "finding", "effect"],
  "figure_caption": "string",
  "figure_title": "string",
  "figure_worthiness": "core | supporting | incidental",
  "confidence": <0.0〜1.0 の実数>
}

ルール：
1. 装飾（ロゴ・飾り罫・背景）なら has_useful_visual_info=false。不確実なら捏造せず不確実と述べる。
2. confidence は**あなたがこの画像をどれだけ読み取れたか**を 0.0〜1.0 の実数で
   答えてください。上の書式に書いた数字は見本であって答えではありません。
   はっきり読めたなら 0.8〜0.95、部分的なら 0.4〜0.6、ほとんど読めないなら 0.2 以下。
3. figure_caption と figure_title は**二軌**です。
   - figure_caption：図の内容説明。要約を書くモデルに渡すので、
 「何を比べて、結果どうだったか」まで**しっかり**書いてください（1〜2 文）。
 例：「流路変更前後の圧力損失を比較したグラフ。変更後は 12.5 kPa まで低下し、目標を下回った」
   - figure_title：報告書の図の下に表示する**見出し**。学術論文の図表題と同じで、
 **体言止め・20 字以内・句点なし**。説明文にしないこと。
 例：「流路変更前後の圧力損失比較」「断面の弾性率分布（AFM）」「Q2 売上の内訳」
 ❌「表面の凹凸または応力分布を示す、マイクロメートルスケールの断面の顕微鏡画像です」
 （これは caption の書き方。title には長すぎる）
4. figure_worthiness は、この資料の要点を説明するのにこの図がどれだけ中心的かを、
   **この 1 枚だけを見て**判断してください。他の図と比べる必要はありません。
   - core       : 資料の主要な結果・結論そのものを示している図
   - supporting : 本文の補足として有用（構成図・条件表など）
   - incidental : 載せなくても要点は伝わる（現場写真・背景説明など）
"""


def build_vision_client(config: AppConfig) -> "LocalLLMClient":
    """パイプライン外（確認画面）で使う視覚モデルのクライアント。"""
    vc = config.llm.vision
    if vc and vc.base_url:
        return LocalLLMClient(base_url=vc.base_url, api_key=vc.api_key, model=vc.model,
                              temperature=config.llm.temperature,
                              structured_output=config.llm.structured_output,
                              max_retries=config.llm.max_retries,
                              timeout_seconds=config.llm.timeout_seconds,
                              mock=config.llm.mock)
    return LocalLLMClient(**config.llm.model_dump(exclude={"vision"}))


def make_nodes(config: AppConfig, llm: Optional[LocalLLMClient] = None,
               vision_llm: Optional[LocalLLMClient] = None,
               template_id: str = "case"):
    spec: TemplateSpec = get_registry().get(template_id)
    # 指标 hook：run_dir 在 create_run_dir 之后才确定，用可变盒子延迟绑定
    hook_box: Dict[str, Optional[RunStore]] = {"store": None}

    def _metrics_hook(record: dict) -> None:
        if hook_box["store"] is not None:
            hook_box["store"].llm_metric(record)

    llm = llm or LocalLLMClient(**config.llm.model_dump(exclude={"vision"}),
                                metrics_hook=_metrics_hook)
    if getattr(llm, "metrics_hook", None) is None:
        llm.metrics_hook = _metrics_hook
    if vision_llm is None:
        vc = config.llm.vision
        if vc and vc.base_url:
            vision_llm = LocalLLMClient(
                base_url=vc.base_url, api_key=vc.api_key, model=vc.model,
                temperature=config.llm.temperature,
                structured_output=config.llm.structured_output,
                max_retries=config.llm.max_retries,
                timeout_seconds=config.llm.timeout_seconds,
                mock=config.llm.mock,
                metrics_hook=_metrics_hook,
            )
        else:
            vision_llm = llm
    wf = config.workflow

    def _resume_ok(state: WorkflowState, artifact: Path) -> bool:
        return wf.resume and artifact.exists()

    # ------------------------------------------------------------------
    def create_run_dir(state: WorkflowState) -> WorkflowState:
        input_path = Path(state["input_path"]).resolve()
        out_dir = config.paths.resolve(config.paths.out_dir)
        run_id = f"{input_path.stem}_{file_hash(str(input_path))}"
        run_dir = out_dir / "runs" / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        state["run_dir"] = str(run_dir)
        state["errors"] = []
        state["repair_attempts"] = 0
        store = RunStore(run_dir)
        hook_box["store"] = store
        store.save_json(RunStore.MANIFEST, {"input_path": str(input_path), "run_dir": str(run_dir),
                                            "template_id": spec.id, "template_name": spec.name})
        store.reset_status()  # 重置 status/指标/取消标记（保留缓存产物）
        store.logger().info("run start: %s", input_path.name)
        _update_status(state, "create_run_dir", "done")
        return state

    # ------------------------------------------------------------------
    def parse_document(state: WorkflowState) -> WorkflowState:
        _update_status(state, "parse_document",
                       peek=f"『{Path(state['input_path']).name}』を読み込んでいます…")
        input_path = Path(state["input_path"]).resolve()
        run_dir = Path(state["run_dir"])
        parse_dir = run_dir / "parsed"
        parse_dir.mkdir(parents=True, exist_ok=True)
        suffix = input_path.suffix.lower()

        md_path = parse_dir / f"{input_path.stem}.md"
        json_path = parse_dir / f"{input_path.stem}.json"

        # ---- v3.6 解析ルート判定（LLM ゼロ・安価なプローブのみ）----
        store = _store(state)
        prev_route = (store.load_json("route.json", {}) or {}).get("route")
        route, reason, probe = decide_route(str(input_path), wf)
        state["route"] = route
        state["route_reason"] = reason
        store.save_json("route.json", {"route": route, "reason": reason, "probe": probe,
                                       "mode": getattr(wf, "input_mode", "auto")})
        manifest = store.load_json(RunStore.MANIFEST, {}) or {}
        manifest.update({"route": route, "route_reason": reason})
        store.save_json(RunStore.MANIFEST, manifest)
        # ルートが前回と違うならキャッシュは別物なので使わない
        route_changed = prev_route is not None and prev_route != route

        # ---- v3.9 実行トレース：ルートと使用実装を残す ----
        tr = PipelineTrace()
        tr.set_route(route, reason,
                     manual=(getattr(wf, "input_mode", "auto") != "auto"))
        tr.template_id = spec.id
        tr.deep_read = bool(getattr(wf, "deep_read", False))
        _update_status(state, "parse_document", "running",
                       f"経路: {'融合' if route == 'hybrid' else ('画像読み取り' if route == 'vision' else 'Docling')}",
                       peek=f"解析ルートを決めました：{reason}")

        if suffix in (".xlsx", ".xlsm") and not _resume_ok(state, md_path):
            tr.use("excel", ENGINE_OPENPYXL,
                   "セル計算結果とグラフ numCache を数値表として読み取り")
            _excel_text_pass(state, store, input_path, md_path)
            if route not in ("vision", "hybrid"):
                return state          # vision 指定時はページ画像化も続けて行う

        if route in ("vision", "hybrid"):
            # Docling を完全に飛ばす。テキストは「ただで取れる分だけ」拾い、
            # 主役は collect_visual_assets が作るページ画像 → Agent 2。
            text = ""
            if suffix == ".pdf":
                tr.use("parse", ENGINE_PYPDFIUM, "PDF のテキスト層を抽出（Docling は迂回）")
                text = pdf_text_fallback(str(input_path))
            elif suffix in (".pptx", ".docx", ".ppt", ".doc"):
                conv = office_to_pdf(
                    str(input_path), str(parse_dir / "as_pdf"),
                    office2pdf_path=getattr(wf, "office2pdf_path", ""),
                    office2pdf_font_path=getattr(wf, "office2pdf_font_path", ""),
                    use_office2pdf=getattr(wf, "office2pdf_enabled", True))
                if conv.get("ok"):
                    # v3.10/v3.11：変換元は COM / office2pdf / LibreOffice のいずれか。
                    # どれで通ったかは忠実度に直結するので必ず残す。
                    tr.use("parse",
                           {"office_com": ENGINE_OFFICE_COM,
                            "office2pdf": ENGINE_OFFICE2PDF}.get(
                               conv.get("engine", ""), ENGINE_LIBREOFFICE),
                           "Office → PDF 変換（全頁描画のため）")
                    state["vision_pdf_path"] = conv["pdf_path"]
                    text = pdf_text_fallback(conv["pdf_path"])
                else:
                    tr.unavailable("parse", ENGINE_OFFICE2PDF,
                                   str(conv.get("error"))[:200]
                                   or "変換に失敗したため頁画像化は不可・埋込画像のみ")
                    _push_error(state, "parse_document",
                                "画像読み取り：PDF に変換する手段が無いため、ページを画像化できません。"
                                "元ファイルのテキストと埋め込み画像で解析を続けます",
                                str(conv.get("error", "")))
            elif suffix in (".xlsx", ".xlsm", ".xls"):
                # v3.11：Excel をここで office_to_pdf に掛けるのを止めた。
                #
                # Excel の頁画像化は collect_visuals 側の Excel COM
                #（PageSetup で「横 1 ページに収める」）が担当しており、
                # この経路は最初から通らない。にもかかわらず変換を試みて
                # 失敗し「PDF 変換手段がありません」と警告を出していたため、
                # Excel COM が正常に動いている run でも画面上は
                # 「頁画像化は不可」と出て状態を誤認させていた。
                # テキスト層は _excel_text_pass が既に作っているので、
                # ここでは何もしないのが正しい。
                text = ""

            elif suffix in (".md", ".txt", ".markdown"):
                # v3.13：手動で視覚ルートを指定された素のテキスト。
                # 描画すべき頁が存在しないので視覚資産はゼロになる。
                # ここで本文まで空にすると run が丸ごと空回りするため、
                # 中身をそのまま持ち越す（自動判定なら text ルートへ行く
                # ケースだが、手動指定を握り潰さずに最善を尽くす）。
                text = input_path.read_text(encoding="utf-8", errors="ignore")

            # ---- v3.13：ここで既存の Markdown を消さない ----
            #
            # 直前まで `md_path.write_text(text)` を無条件に実行していた。
            # xlsx は上の分岐で text="" なので、_excel_text_pass が書いた
            # **数値表 6 万字が丸ごと空文字で上書きされて消えていた**。
            # 「何もしないのが正しい」という注釈は正しかったが、その下の
            # 一行が意図を無効化していた（実測：視覚ルートの Excel は
            # markdown 0 字・テキスト証拠 0 件）。
            #
            # 視覚ルートでも数値の正確さは openpyxl 経由の本文が持っている。
            # シート画像は「裏取りの目」であって数値の出所ではないので、
            # 本文を消してしまうと密なデータ表が要約から完全に落ちる。
            # ---- v3.28 原生テキスト ----
            # 融合ルート：変換後 PDF の文字層ではなく元ファイルから直接取る
            #   （ノート・表構造・グループ図形内の文字が残る）。
            # 視覚ルート：変換に失敗して text="" のまま進むと、要約の材料が
            #   埋込画像だけになる（十数分かけて中身の薄い要約になる）。その救済。
            if suffix in (".pptx", ".docx", ".pdf") and (route == "hybrid" or not text.strip()):
                from .native_text import extract_native_text
                nt, how = extract_native_text(str(input_path))
                if nt.strip():
                    text = nt
                    tr.use("parse", {"python-pptx": ENGINE_PYTHON_PPTX,
                                     "python-docx": ENGINE_PYTHON_DOCX}.get(how, ENGINE_PYPDFIUM),
                                     "原生テキスト抽出（融合ルート）" if route == "hybrid"
                                     else "原生テキスト抽出（PDF 変換に失敗したための代替）")
            if text or not md_path.exists():
                md_path.write_text(text, encoding="utf-8")
            state["markdown_path"] = str(md_path)

            # v3.13：Excel の HTML 生成は視覚ルートでも通す。
            # 従来はこのブロックが早期 return するため、視覚ルートでは
            # excel_html_path が永久に空だった。
            if suffix in (".xls", ".xlsx", ".xlsm"):
                _excel_html_fallback(state, parse_dir, input_path, md_path)

            state["trace_main"] = tr.raw()
            _update_status(state, "parse_document", "done",
                           (f"融合（画像＋テキスト {len(text):,} 字）" if route == "hybrid"
                            else f"画像読み取り（テキスト {len(text):,} 字）"))
            for line in tr.summary_lines():
                store.logger().info("[trace] %s", line)
            return state

        if _resume_ok(state, md_path) and not route_changed:
            state["markdown_path"] = str(md_path)
            if json_path.exists():
                state["docling_json_path"] = str(json_path)
            _update_status(state, "parse_document", "done", "キャッシュ再利用")
        elif suffix in (".md", ".txt", ".markdown"):
            md_path.write_text(input_path.read_text(encoding="utf-8", errors="ignore"), encoding="utf-8")
            state["markdown_path"] = str(md_path)
        else:
            # v3：一次转换导出两种格式（v2 是两次完整转换）
            result = convert_document_once(str(input_path), str(parse_dir), do_ocr=wf.docling_ocr)
            if result.get("ok"):
                tr.use("parse", ENGINE_DOCLING,
                       f"レイアウト解析＋表構造（OCR {'有効' if wf.docling_ocr else '無効'}）")
                state["markdown_path"] = result["markdown_path"]
                if result.get("json_path"):
                    state["docling_json_path"] = result["json_path"]
            elif suffix == ".pdf":
                tr.fallback("parse", ENGINE_DOCLING, ENGINE_PYPDFIUM,
                            "Docling が失敗。レイアウト・表構造は失われます")
                # 降级：Docling 失败时用 pypdfium2 文本层兜底（无布局/表格，
                # 质量下降但流水线不死；质量报告与 UI 都会显示该警告）
                text = pdf_text_fallback(str(input_path))
                md_path.write_text(text, encoding="utf-8")
                state["markdown_path"] = str(md_path)
                if text.strip():
                    _push_error(state, "parse_document",
                                "Docling での解析に失敗したため、pypdfium2 によるテキスト抽出に切り替えました（レイアウト・表の構造は失われます）",
                                str(result.get("error", "")))
                else:
                    # 纯图片 PDF（扫描件等）：文本通道为空，视觉通道继续工作
                    _push_error(state, "parse_document",
                                "Docling での解析に失敗し、PDF にテキスト層もありません（スキャン画像の可能性があります）。"
                                "テキスト経路は空、視覚経路のみで処理を継続します",
                                str(result.get("error", "")))
            else:
                raise RuntimeError(f"文档解析失败: {result}")

        state["trace_main"] = tr.raw()
        for line in tr.summary_lines():
            store.logger().info("[trace] %s", line)

        if suffix in (".xls", ".xlsx", ".xlsm"):
            _excel_html_fallback(state, parse_dir, input_path, md_path)

        _update_status(state, "parse_document", "done")
        return state

    # ------------------------------------------------------------------
    def route_template(state: WorkflowState) -> WorkflowState:
        """v3.11：テンプレートを **最初の LLM 呼出の前** に決める。

        なぜここ（parse_document の後）なのか：
            判定材料の一つが「本文の冒頭 2000 字」なので、解析前＝create_run_dir
            直後には置けない。最初の LLM 呼出は extract_text_evidence なので、
            ここに置けば「全部走り終えてから不一致に気付く」問題は解消される。

        なぜ `nonlocal spec` なのか：
            spec は make_nodes のクロージャ変数で、他ノードから 27 箇所参照
            されている。同じセルを差し替えれば全ノードが新しい spec を見るので、
            27 箇所に手を入れる必要がない（state 経由に変えると全書き換えになる）。
            make_nodes は run ごとに呼ばれるため、並行 run 同士は別セルで干渉しない。
        """
        nonlocal spec
        store = _store(state)
        mode = getattr(wf, "template_mode", "manual")

        if mode != "auto":
            state["template_id"] = spec.id
            state["template_route_reason"] = "手動指定"
            _update_status(state, "route_template", "done", f"テンプレート: {spec.name}")
            return state

        head = ""
        try:
            head = Path(state["markdown_path"]).read_text(
                encoding="utf-8", errors="ignore")[:4000]
        except Exception:  # noqa: BLE001 本文が無くてもファイル名だけで判定は出来る
            pass

        verdict = decide_template(
            state["input_path"], head, get_registry(),
            fallback_id=getattr(wf, "template_auto_fallback", "generic_doc"))
        chosen = verdict["template_id"]

        prev = (store.load_json("template_route.json", {}) or {}).get("template_id")
        store.save_json("template_route.json", verdict)

        if chosen != spec.id:
            try:
                spec = get_registry().get(chosen)   # ← 全ノードがこの束縛を見る
            except KeyError:
                _push_error(state, "route_template",
                            f"自動判定したテンプレート '{chosen}' が未登録のため据え置き", "")
                chosen = spec.id

        state["template_id"] = spec.id
        state["template_route_reason"] = verdict["reason"]
        # テンプレートが変わると証拠カテゴリも変わる。前回と違うなら
        # 証拠キャッシュは別物なので使わせない（ルート変更時と同じ扱い）。
        state["template_changed"] = bool(prev and prev != spec.id)  # type: ignore[typeddict-unknown-key]

        manifest = store.load_json(RunStore.MANIFEST, {}) or {}
        manifest.update({"template_id": spec.id, "template_name": spec.name,
                         "template_route_reason": verdict["reason"],
                         "template_auto": True})
        store.save_json(RunStore.MANIFEST, manifest)

        # parse_document が書いたトレースの template_id を実際の選択で上書きする
        tr = PipelineTrace.from_raw(state.get("trace_main", {}) or {})
        tr.template_id = spec.id
        state["trace_main"] = tr.raw()

        store.logger().info("[template] %s (%s)", spec.id, verdict["reason"])
        _update_status(state, "route_template", "done",
                       f"テンプレート: {spec.name}"
                       + ("" if verdict["confident"] else "（決め手なし→汎用）"))
        return state

    # ------------------------------------------------------------------
    def lookup_reference(state: WorkflowState) -> WorkflowState:
        """v3.14：参照台帳から該当行を引き、**証拠として**注入する。

        置き場所は route_template の直後、双方のチェーンより前。
        引いた行を Evidence にして流し込めば、write_summary は普段どおり
        「証拠にあることだけ書く」を守ったまま依頼者や依頼日を書ける。
        要約後にモデルへ書き直させる案は採らない——契約検証を通った成果物を
        もう一度書き換えさせるのは、せっかく塞いだ作話の口を開け直すのと同じで、
        しかも LLM 呼び出しが 1 回増える。

        照合そのものはコード。決定論的な join に賢さは要らないし、
        同じ入力から常に同じ行が返らないと追跡できない。
        """
        _update_status(state, "lookup_reference")
        state["reference_match"] = {}          # type: ignore[typeddict-unknown-key]
        state["reference_evidence"] = []       # type: ignore[typeddict-unknown-key]

        if not getattr(wf, "reference_enabled", False):
            _update_status(state, "lookup_reference", "done", "無効")
            return state

        paths = list(state.get("reference_paths") or [])
        lib = getattr(wf, "reference_library_dir", "")
        if lib:
            lib_path = Path(lib)
            if not lib_path.is_absolute():
                lib_path = PROJECT_ROOT / lib_path
            if lib_path.is_dir():
                paths.append(str(lib_path))
        if not paths:
            # v3.18：ここは黙って通り過ぎてはいけない。利用者から見ると
            # 「台帳を置いたのに効かない」と「そもそも読んでいない」が
            # 区別できず、原因の切り分けが不可能になる。
            _push_error(state, "lookup_reference",
                        f"参照台帳が 1 冊も見つかりません（{lib or '未設定'}）。"
                        f"台帳照合は行われませんでした", "")
            _update_status(state, "lookup_reference", "done", "台帳未登録")
            return state

        try:
            spec = load_reference_specs().get(
                getattr(wf, "reference_spec_id", "default")) or None
            index = build_index(paths, spec=spec)
            # v3.21：照合に使うのは **元の置き場所** であって、保存先ではない。
            #
            # ブラウザからアップロードした場合、実体は out/inbox/ に
            # 「元の名前_8桁ID.拡張子」で保存される。この状態で照合すると
            #   - 親フォルダが inbox になり、フォルダ名照合が死ぬ
            #   - ファイル名に 8 桁の ID が混ざって一致度が落ちる
            # ので、アップロード時に控えておいた元の名前と相対パスを使う。
            lookup_path = (state.get("source_rel_path")
                           or state.get("source_name")
                           or state["input_path"])
            result = index.match(
                str(lookup_path),
                allow_partial=getattr(wf, "reference_allow_partial", True))
        except Exception as e:  # noqa: BLE001 台帳が壊れていても本編は続ける
            _push_error(state, "lookup_reference",
                        "参照台帳の読み込み・照合に失敗しました（処理は継続）", repr(e))
            _update_status(state, "lookup_reference", "done", "失敗")
            return state

        payload = result.to_dict()
        payload["index"] = index.stats()
        # v3.19：候補は「捨てた物」ではなく「次点」。中身まで残して
        # 人が別の行を選び直せるようにする。
        payload["candidates"] = [c.to_dict() for c in result.candidates]
        state["reference_match"] = payload    # type: ignore[typeddict-unknown-key]
        _save_json(payload, Path(state["run_dir"]) / "reference_match.json")

        if not result.ok:
            if not result.candidates:
                # 「読んだが当たらなかった」ことを明示する。台帳の行数も出して
                # 「台帳自体は読めている」ことが分かるようにする。
                _push_error(state, "lookup_reference",
                            f"台帳 {index.stats().get('rows', 0)} 行を検索しましたが、"
                            f"『{Path(str(lookup_path)).name}』に該当する行は"
                            f"見つかりませんでした（フォルダ名も照合済み："
                            f"{Path(str(lookup_path)).parent}）", result.reason)
            if result.candidates:
                # 同点は「確度が低い」のではなく「どれか分からない」。
                # 一つ選ぶのはコイン投げなので、候補提示に留めて人に委ねる。
                _push_error(state, "lookup_reference",
                            f"台帳の候補が {len(result.candidates)} 行あり確定できません"
                            f"（採用せず候補のみ記録）", result.reason)
            _update_status(state, "lookup_reference", "done",
                           "候補複数" if result.candidates else "該当なし")
            return state

        if not result.confirmed and not getattr(wf, "reference_adopt_unconfirmed", True):
            _update_status(state, "lookup_reference", "done", "確度不足のため不採用")
            return state

        evs = _reference_to_evidence(
            result, confidence_factor=getattr(wf, "reference_confidence_factor", 0.9))
        state["reference_evidence"] = [e.model_dump(mode="json") for e in evs]  # type: ignore[typeddict-unknown-key]
        tr = PipelineTrace.from_raw(state.get("trace_main", {}) or {})
        tr.use("parse", ENGINE_OPENPYXL,
               f"参照台帳の照合（{result.method}・確度 {result.confidence:.2f}）")
        state["trace_main"] = tr.raw()

        label = "確定" if result.confirmed else "要確認"
        _update_status(state, "lookup_reference", "done",
                       f"台帳 {label}：{len(evs)} 件の証拠を追加",
                       peek=f"台帳から依頼情報が見つかりました（{result.method}・{label}）")
        return state

    # ------------------------------------------------------------------
    def prepare_html_text(state: WorkflowState) -> WorkflowState:
        _update_status(state, "prepare_html_text")
        html_paths = [state["excel_html_path"]] if state.get("excel_html_path") else []
        state["html_text_sources"] = collect_html_text_sources(html_paths=html_paths, max_chars_each=150000)
        _update_status(state, "prepare_html_text", "done")
        return state

    # ------------------------------------------------------------------
    def chunk_text(state: WorkflowState) -> WorkflowState:
        _update_status(state, "chunk_text")
        md_text = Path(state["markdown_path"]).read_text(encoding="utf-8", errors="ignore")

        led = LossLedger()
        recs, rep = structural_chunks_traced(
            md_text,
            chunk_chars=wf.chunk_chars,
            overlap=wf.chunk_overlap,
            min_informative_chars=wf.min_chunk_informative_chars,
            drop_low_info=wf.drop_low_info_chunks,
            repeat_table_header=True,
            source_label=Path(state["markdown_path"]).name,
        )
        led.drop("text_chunk", rep["dropped_low_info"],
                 f"情報量 < {wf.min_chunk_informative_chars} 文字", severity="medium")
        for src in state.get("html_text_sources", []):
            r2, rep2 = structural_chunks_traced(
                src["text"], chunk_chars=wf.chunk_chars, overlap=wf.chunk_overlap,
                min_informative_chars=wf.min_chunk_informative_chars,
                drop_low_info=wf.drop_low_info_chunks, repeat_table_header=True,
                source_label=str(src.get("label") or src.get("path") or "html"),
            )
            recs.extend(r2)
            led.drop("text_chunk", rep2["dropped_low_info"],
                     f"情報量 < {wf.min_chunk_informative_chars} 文字（HTML 由来）",
                     severity="medium")
        led.observe("text_chunk", len(recs) + led.dropped_total("text_chunk"))

        # v3.7 は texts[:40] で黙って尾部を捨てていた。v3.8 は既定で無制限
        # （max_text_chunks<=0）。上限を掛ける場合も必ず台帳に残す。
        if wf.max_text_chunks and wf.max_text_chunks > 0 and len(recs) > wf.max_text_chunks:
            led.drop("text_chunk", len(recs) - wf.max_text_chunks,
                     f"max_text_chunks={wf.max_text_chunks} 上限", severity="high",
                     detail="文書後半が要約に反映されません。上限を 0（無制限）に")
            recs = recs[: wf.max_text_chunks]

        chunks_dir = Path(state["run_dir"]) / "chunks"
        chunks_dir.mkdir(parents=True, exist_ok=True)
        chunks: List[Dict[str, Any]] = []
        for i, rec in enumerate(recs):
            cid = f"text_chunk_{i + 1:04d}"
            p = chunks_dir / f"{cid}.md"
            p.write_text(rec["text"], encoding="utf-8")
            chunks.append({"chunk_id": cid, "source_type": "structural",
                           "source": state["markdown_path"], "text": rec["text"],
                           "path": str(p),
                           # ---- v3.8 溯源 ----
                           "page": rec.get("page"),
                           "heading": rec.get("heading", ""),
                           "section_index": rec.get("section_index"),
                           "slice_index": rec.get("slice_index"),
                           "has_table": rec.get("has_table", False),
                           "table_header_repeated": rec.get("table_header_repeated", False),
                           "low_info": rec.get("low_info", False)})
        state["chunks"] = chunks
        state["loss_text"] = led.raw()
        _save_json({"chunk_report": rep, "conservation": conservation_check(led, "text_chunk")},
                   chunks_dir / "_chunk_report.json")
        if chunks:
            _update_status(state, "chunk_text", "running", f"{len(chunks)} チャンク",
                           peek=f"「{chunks[0]['text'][:60].strip()}…」から読み始めます")
        if not chunks and state.get("route") != "vision":
            # 視覚直読ルートでは本文が空なのは想定内（視覚分岐が主役）なのでエラー扱いしない
            _push_error(state, "chunk_text",
                        "本文から有効なチャンクが生成されませんでした（文書が短すぎるか、"
                        "min_chunk_informative_chars が高すぎる可能性）")
        _update_status(state, "chunk_text", "done", f"{len(chunks)} チャンク")
        return {"chunks": chunks, "loss_text": state["loss_text"],
                "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    _CATEGORIES = " | ".join(spec.categories)
    EXTRACT_SYSTEM = f"""あなたは文書整理エージェントです。
文書の断片から「{spec.name}」要約に使える証拠情報を抽出してください。
{spec.extraction_hint}

JSON のみを出力してください。形式：
{{
  "evidence": [
    {{
      "category": "{_CATEGORIES}",
      "content": "string",
      "confidence": 0.0
    }}
  ]
}}

ルール：
1. 捏造しない。断片に有用な情報がなければ evidence は空配列。
2. 製品名・システム名・部門名・日付・数値・ツール名は保持する。
3. content は日本語または原文で正確に。
"""

    def _extract_one(chunk: Dict[str, Any]) -> List[Evidence]:
        user = f"""以下は文書の断片です。テンプレート要約に関係する証拠を抽出してください。

chunk_id: {chunk["chunk_id"]}

--- 断片開始 ---
{chunk["text"]}
--- 断片終了 ---
"""
        raw = llm.chat_json(system=EXTRACT_SYSTEM, user=user,
                            max_tokens=wf.extract_max_tokens,
                            json_schema=EvidenceList.model_json_schema(),
                            tag=f"extract:{chunk['chunk_id']}")
        parsed = EvidenceList.model_validate(raw)
        out = []
        for i, raw_ev in enumerate(parsed.evidence):
            ev = Evidence.model_validate(raw_ev.model_dump())
            if not ev.evidence_id:
                ev.evidence_id = f"{chunk['chunk_id']}_ev_{i + 1:03d}"
            if not ev.source:
                ev.source = chunk["chunk_id"]
            # ---- v3.8：溯源はモデルに書かせず、コードが確定的に付ける ----
            ev.chunk_id = chunk["chunk_id"]
            ev.page = chunk.get("page")
            ev.heading = chunk.get("heading", "") or ""
            ev.origin = "text"
            out.append(ev)
        return out

    def extract_text_evidence(state: WorkflowState) -> WorkflowState:
        _update_status(state, "extract_text_evidence")
        cache = Path(state["run_dir"]) / "evidence_text.json"
        # v3.11：テンプレートが前回と変わったなら証拠カテゴリの語彙も変わる。
        # run_id はファイル内容だけで決まるので、そのまま再利用すると
        # 別テンプレート用のカテゴリが付いた証拠を使い回してしまう。
        if _resume_ok(state, cache) and not state.get("template_changed"):
            state["text_evidence"] = json.loads(cache.read_text(encoding="utf-8")).get("evidence", [])
            _update_status(state, "extract_text_evidence", "done", "キャッシュ再利用")
            return {"text_evidence": state["text_evidence"], "errors": state.get("errors", [])}

        chunks = state.get("chunks", [])
        total = len(chunks)
        all_evidence: List[Evidence] = []
        done = 0
        workers = max(1, wf.extract_workers)

        def _record(chunk, result_or_exc):
            nonlocal done
            done += 1
            if isinstance(result_or_exc, Exception):
                _push_error(state, "extract_text_evidence",
                            f"{chunk['chunk_id']} の根拠抽出に失敗したため飛ばしました", repr(result_or_exc))
                peek = f"{chunk['chunk_id']} は読めませんでした…次へ"
            else:
                all_evidence.extend(result_or_exc)
                snippet = chunk["text"][:56].replace("\n", " ").strip()
                found = f"（証拠 {len(result_or_exc)} 件）" if result_or_exc else "（証拠なし）"
                peek = f"「{snippet}…」を読みました {found}"
            _update_status(state, "extract_text_evidence", "running", f"{done}/{total}", peek=peek)

        store = _store(state)
        if workers == 1:
            for chunk in chunks:
                store.raise_if_cancelled()
                try:
                    _record(chunk, _extract_one(chunk))
                except (LLMJsonError, ValidationError, RuntimeError) as e:
                    _record(chunk, e)
        else:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {pool.submit(_extract_one, c): c for c in chunks}
                try:
                    for fut in as_completed(futures):
                        store.raise_if_cancelled()
                        chunk = futures[fut]
                        try:
                            _record(chunk, fut.result())
                        except (LLMJsonError, ValidationError, RuntimeError) as e:
                            _record(chunk, e)
                except RunCancelled:
                    pool.shutdown(cancel_futures=True)
                    raise

        state["text_evidence"] = [e.model_dump(mode="json") for e in all_evidence]
        _save_json({"evidence": state["text_evidence"]}, cache)
        _update_status(state, "extract_text_evidence", "done", f"{total} チャンク / {len(all_evidence)} 証拠")
        return {"text_evidence": state["text_evidence"], "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    def aggregate(state: WorkflowState) -> WorkflowState:
        _update_status(state, "aggregate_evidence")
        items = [Evidence.model_validate(d) for d in state.get("text_evidence", [])]
        led = LossLedger.from_raw(state.get("loss_text"))
        agg = aggregate_evidence(
            items,
            min_confidence=wf.min_evidence_confidence,
            max_per_category=wf.max_evidence_per_category,
            max_total_chars=wf.max_evidence_pack_chars,
            ledger=led,
        )

        # ---- v3.14：参照台帳の証拠は選抜を通さず先頭に置く ----
        #
        # 台帳から引いた依頼者・依頼日・依頼目的は、確度フィルタや
        # 類別ごとの上限で落ちてよい種類の情報ではない。本文から拾った
        # 証拠と枠を奪い合わせると、「台帳に書いてあるのに要約に出ない」
        # という一番間の抜けた失敗が起きうる。
        # 件数は 1 行ぶんなので予算を圧迫しない。
        ref = [Evidence.model_validate(d) for d in state.get("reference_evidence", []) or []]
        if ref:
            agg = ref + agg

        state["loss_text"] = led.raw()
        state["aggregated_evidence"] = [e.model_dump(mode="json") for e in agg]
        _save_json({"before": len(items), "after": len(agg),
                    "from_reference": len(ref),
                    "evidence": state["aggregated_evidence"]},
                   Path(state["run_dir"]) / "evidence_aggregated.json")
        extra = f"（うち台帳 {len(ref)} 件）" if ref else ""
        _update_status(state, "aggregate_evidence", "done", f"{len(items)} -> {len(agg)}",
                       peek=f"証拠 {len(items)} 件を整理して {len(agg)} 件に絞りました{extra}")
        return {"aggregated_evidence": state["aggregated_evidence"],
                "loss_text": state["loss_text"]}

    # ------------------------------------------------------------------
    def gap_fill(state: WorkflowState) -> WorkflowState:
        """
        agent 化的第一步：观察证据覆盖情况 -> 发现缺口 -> 针对性再行动。
        关键类别（依頼元/期間/効果等）没有任何证据时，用文档开头部分
        （标题页/概要通常在前面）做一次聚焦的补提取，只问缺的类别。
        单次调用、有界，不会显著拖慢流水线。
        """
        _update_status(state, "gap_fill")
        if not wf.gap_fill:
            _update_status(state, "gap_fill", "done", "無効")
            return {"aggregated_evidence": state.get("aggregated_evidence", [])}

        have = {d["category"] for d in state.get("aggregated_evidence", [])}
        missing = [c for c in spec.key_categories if c not in have]
        if not missing:
            _update_status(state, "gap_fill", "done", "欠落なし",
                           peek="必要な情報は揃っています")
            return {"aggregated_evidence": state.get("aggregated_evidence", [])}
        _update_status(state, "gap_fill", "running", "",
                       peek=f"『{'、'.join(missing)}』の情報が見つからないので探し直します…")

        doc_head = Path(state["markdown_path"]).read_text(encoding="utf-8", errors="ignore")[: wf.gap_fill_context_chars]
        user = f"""文書全体から、以下のカテゴリの証拠だけを重点的に探してください（他のカテゴリは不要）：

{", ".join(missing)}

--- 文書（先頭部分）---
{doc_head}
--- 文書終了 ---
"""
        try:
            raw = llm.chat_json(system=EXTRACT_SYSTEM, user=user,
                                max_tokens=wf.extract_max_tokens,
                                json_schema=EvidenceList.model_json_schema(),
                                tag="gap_fill:main")
            parsed = EvidenceList.model_validate(raw)
            added = 0
            for i, ev in enumerate(parsed.evidence):
                if ev.category not in missing:
                    continue  # 只收缺口类别，避免重复噪声
                ev.evidence_id = ev.evidence_id or f"gapfill_ev_{i + 1:03d}"
                ev.source = ev.source or "gap_fill"
                state["aggregated_evidence"].append(ev.model_dump(mode="json"))
                added += 1
            _save_json({"missing": missing, "added": added,
                        "evidence": state["aggregated_evidence"]},
                       Path(state["run_dir"]) / "evidence_aggregated.json")
            _update_status(state, "gap_fill", "done", f"欠落 {len(missing)} 類 / 補充 {added} 件")
        except (LLMJsonError, ValidationError, RuntimeError) as e:
            _push_error(state, "gap_fill", "不足項目の補完に失敗しました（処理は継続）", repr(e))
            _update_status(state, "gap_fill", "done", "失敗（続行）")
        return {"aggregated_evidence": state.get("aggregated_evidence", []),
                "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    def collect_visuals(state: WorkflowState) -> WorkflowState:
        _update_status(state, "collect_visual_assets", peek="図や画像を探しています…")
        suffix = Path(state["input_path"]).suffix.lower()
        raw_paths: List[str] = []
        pdf_meta = ""
        # v3.28：融合ルート（hybrid）も頁画像を読むルート。
        vision_route = state.get("route") in ("vision", "hybrid")
        figure_pool: List[str] = []      # 図版候補（頁画像とは別の経路で扱う）

        vtr = PipelineTrace()

        if vision_route and suffix in (".xlsx", ".xlsm") and _excel_com_ready():
            # ---- v3.8 修正：視覚ルートの Excel は LibreOffice ではなく Excel COM ----
            #
            # ここに分岐が無かったのが v3.8 の取りこぼし。視覚ルートは
            # `if vision_route:` が最優先で走るため、Excel も一律 LibreOffice
            # 変換の PDF（vision_pdf_path）を見に行っていた。つまり
            # excel_sheet_pdfs（PageSetup で横 1 ページに収める）は
            # **視覚ルートでは一度も呼ばれない**——横に広い表が数十ページの
            # 断片に飛び散る、まさに避けたかった経路をそのまま通っていた。
            #
            # Excel COM が使えるなら、シート単位・横 1 ページ設定で描画する。
            # 使えない環境では下の通常経路（LibreOffice）へ落ちる。
            vtr.use("visual", ENGINE_WIN32COM,
                    "各シートを横 1 ページ設定で PDF 化 → 頁画像")
            raw_paths, pdf_meta = _excel_page_images(state, wf)
            if raw_paths:
                # v3.27.3：シート頁画像は sheet_render で図版にできない。
                # xl/media の埋込画像を別枠で足す（無ければ図版は出ない）。
                figs, fmeta = _collect_figure_assets(state, wf, suffix)
                if figs:
                    figure_pool.extend(figs)
                    pdf_meta += f" / {fmeta}"
            if not raw_paths:
                vtr.fallback("visual", ENGINE_WIN32COM, ENGINE_LIBREOFFICE,
                             "Excel COM の描画が空だった")
                _push_error(state, "collect_visual_assets",
                            "Excel COM でのシート描画が空だったため LibreOffice 経路へ後退",
                            "")
                src_pdf = state.get("vision_pdf_path", "")
                if src_pdf:
                    result = render_pdf_pages(
                        src_pdf, out_dir=str(Path(state["run_dir"]) / "visual_pages"),
                        max_pages=wf.vision_route_max_render_pages,  # 0＝全頁
                        scale=wf.pdf_render_scale)
                    raw_paths = result.get("visual_asset_paths", [])
                    pdf_meta = f"頁描画 {result.get('pages_rendered', 0)}"
        elif vision_route:
            # v3.6 視覚直読：ページそのものを画像化して VLM に読ませる。
            # PDF はそのまま、Office は parse_document が作った PDF 経由。
            src_pdf = (state["input_path"] if suffix == ".pdf"
                       else state.get("vision_pdf_path", ""))
            if src_pdf:
                _update_status(state, "collect_visual_assets", "running", "",
                               peek="ページを画像にしています…")
                vtr.use("visual", ENGINE_PYPDFIUM,
                        f"全頁を画像化（scale {wf.pdf_render_scale}）")
                result = render_pdf_pages(
                    src_pdf, out_dir=str(Path(state["run_dir"]) / "visual_pages"),
                    max_pages=wf.vision_route_max_render_pages,
                    scale=wf.pdf_render_scale)
                raw_paths = result.get("visual_asset_paths", [])
                pdf_meta = f"頁描画 {result.get('pages_rendered', 0)}/{result.get('pages_total', 0)}"
                if not result.get("ok"):
                    _push_error(state, "collect_visual_assets", "ページの描画に失敗しました（処理は継続）",
                                str(result.get("error", "")))
            if not raw_paths and suffix in (".pptx", ".docx", ".xlsx", ".xlsm"):
                # PDF 変換手段が無い時のフォールバック：埋め込み画像だけでも視覚分析する
                #
                # v3.11：上限を vision_route_max_render_pages(40) から本文ルートと
                # 同じ max_visual_assets*4(120) に揃えた。頁数の上限を画像枚数の
                # 上限に流用していたのは単なる取り違えで、最も資産が少ない
                # この経路にだけ一番きつい上限が掛かっていた。
                result = extract_office_visuals(
                    state["input_path"],
                    out_dir=str(Path(state["run_dir"]) / "visual_office"),
                    max_assets=wf.max_visual_assets * 4)
                raw_paths = result.get("visual_asset_paths", [])
                pdf_meta = f"埋込 {result.get('embedded', 0)}（頁描画不可）"
                # v3.11：EMF/WMF は Pillow で開けず黙って捨てられる。日本語資料では
                # ここが最大の欠落源なので、何枚捨てたかを必ず表に出す。
                if result.get("skipped_vector"):
                    pdf_meta += f"・ベクタ図スキップ {result['skipped_vector']}"
            elif raw_paths:
                # ---- v3.27.3：頁描画が取れていても、図版用に埋込画像を別途集める ----
                # 頁画像は「VLM に読ませる」ための資産で、報告書に貼れる図では
                # ない。両方の用途を 1 種類の資産で賄おうとしていたのが誤り。
                # 頁の枠は削らず、figure_embedded_quota 枚だけ足す。
                figs, fmeta = _collect_figure_assets(state, wf, suffix)
                if figs:
                    figure_pool.extend(figs)
                    pdf_meta += f" / {fmeta}"
        elif suffix == ".pdf":
            # v3.2 修复：LibreOffice→HTML 对 PDF 基本产不出图，
            # 改用 pypdfium2 直接提取内嵌图对象 + 图像型页面整页渲染兜底
            result = extract_pdf_visuals(
                state["input_path"],
                out_dir=str(Path(state["run_dir"]) / "visual_pdf"),
                max_assets=wf.max_visual_assets * 4,
                extract_embedded=wf.pdf_extract_embedded,
                render_fallback=wf.pdf_render_fallback,
                render_min_text_chars=wf.pdf_render_min_text_chars,
                render_scale=wf.pdf_render_scale,
            )
            raw_paths = result.get("visual_asset_paths", [])
            pdf_meta = f"埋込 {result.get('embedded', 0)} / 頁描画 {result.get('pages_rendered', 0)}"
            if not result.get("ok"):
                _push_error(state, "collect_visual_assets", "PDF からの画像抽出に失敗しました（処理は継続）",
                            str(result.get("error", "")))
        elif suffix in (".xlsx", ".xlsm"):
            vtr.use("visual", ENGINE_WIN32COM if _excel_com_ready() else ENGINE_OPENPYXL,
                    "Excel のグラフ画像／シート画像"
                    if _excel_com_ready() else "埋込画像のみ（Excel COM 不在）")
            # v3.7：Excel のグラフは xl/media に無い（ベクタ定義）。Excel COM が
            # 使えるなら実画像として書き出して Agent 2 に渡す。無ければ
            # 埋め込み画像だけ拾い、グラフの数値は本文側で表になっている。
            raw_paths, pdf_meta = _excel_visuals(state, wf)
        elif suffix in (".pptx", ".docx"):
            # v3.5 修复：OOXML 直接解 ZIP 取 media/ 原图（旧 LibreOffice→HTML 链路
            # 在新版 LO 上因 data: URI 内联而静默产出 0 资产）
            result = extract_office_visuals(
                state["input_path"],
                out_dir=str(Path(state["run_dir"]) / "visual_office"),
                max_assets=wf.max_visual_assets * 4,
            )
            raw_paths = result.get("visual_asset_paths", [])
            pdf_meta = f"埋込 {result.get('embedded', 0)}"
            if result.get("skipped_vector"):
                pdf_meta += f" / ベクタ図スキップ {result['skipped_vector']}"
            if not result.get("ok"):
                _push_error(state, "collect_visual_assets",
                            "OOXML からの画像抽出に失敗したため、LibreOffice 経由に切り替えます", str(result.get("error", "")))
                raw_paths = []
        if suffix not in (".pdf",) and not raw_paths:
            # 旧格式（.ppt/.doc/.xls）或 ZIP 通道无产出时的兜底
            try:
                result = collect_visual_assets(
                    input_path=state["input_path"],
                    run_dir=state["run_dir"],
                    preferred_html_path=state.get("excel_html_path"),
                    max_assets=wf.max_visual_assets * 4,
                )
                if result.get("ok") and result.get("visual_asset_paths"):
                    raw_paths = result["visual_asset_paths"]
            except Exception:  # noqa: BLE001
                _push_error(state, "collect_visual_assets", "画像の収集中にエラーが発生しました（処理は継続）",
                            traceback.format_exc()[:2000])

        # v3.27.3：種別で枠を確保してから上限を掛ける。
        # 並び順の先着で切ると、Excel のようにシート頁画像を先に積む経路で
        # 埋込画像が一枚も残らない（抽出はできているのに使われない）。
        # ---- v3.28 図版候補：位置索引と粗選別 ----
        figure_candidates, fig_units = _layout_select_figures(
            state, raw_paths, figure_pool, vision_route)
        raw_paths = figure_candidates.pop("_raw_paths")
        _fig_note = figure_candidates.pop("_note", "")
        if _fig_note:
            pdf_meta = (pdf_meta + " / " if pdf_meta else "") + _fig_note
        state["figure_candidates"] = figure_candidates.pop("_deferred", [])
        state["figure_units"] = fig_units
        # v3.28：枚数では打ち切らない。頁は全頁（vision_route_max_render_pages＝0 は無制限）、
        # 埋込画像は粗選別で残った物だけがここに来る。
        base_cap = 0

        # v3：廉价预过滤 + 降采样，VLM 调用次数和 prompt 体积双降
        # v3.6：視覚直読ではページ全体を読ませるため、解像度と枚数の上限を上げる
        #       （1024px まで縮めると本文の文字が潰れて読めなくなる）
        filt = prefilter_and_downscale_images(
            raw_paths,
            work_dir=str(Path(state["run_dir"]) / "visual_filtered"),
            min_edge_px=wf.image_min_edge_px,
            min_bytes=wf.image_min_bytes,
            max_edge_px=(wf.vision_route_page_max_edge_px if vision_route else wf.image_max_edge_px),
            max_assets=base_cap,
        )
        state["visual_asset_paths"] = filt["kept"]

        # ---- v3.12：画像が密集した頁を圧縮する ----
        #
        # 同一頁に埋め込み画像が大量にある頁は、データの羅列や実験画像の
        # 並列であることが多い。1 枚ずつ VLM に送ると、文脈の無い断片的な
        # 所見が量産されるだけで時間だけが枚数に比例して増える。
        #   1) その頁の全面レンダリングが既に有る → 埋め込みは頁画像に任せて捨てる
        #   2) 無い → 連番ラベル付きの格子画像に束ねて 1 回で読む
        # どちらも VLM 呼び出しが N 回 → 1 回になる。
        dense_report: Dict[str, Any] = {}
        if wf.dense_page_threshold > 0 and state["visual_asset_paths"]:
            state["visual_asset_paths"], dense_report = _compress_dense_pages(
                state["visual_asset_paths"], state["run_dir"], wf)
            if dense_report.get("pages"):
                vtr.use("visual", ENGINE_PILLOW,
                        f"密集頁の圧縮（{dense_report['before']} → "
                        f"{dense_report['after']} 枚 / {len(dense_report['pages'])} 頁）")
        state["visual_dense_report"] = dense_report  # type: ignore[typeddict-unknown-key]

        # v3.8：prefilter は「装飾画像を間引く」ために書かれた関数だが、視覚ルートでは
        # 入力が「資料そのもののページ」になる。同じ閾値（SHA1 重複除去・最小バイト数・
        # 枚数上限）が真逆の意味を持つので、何をどれだけ落としたかを必ず記録する。
        vled = LossLedger()
        vled.observe("visual_asset", len(raw_paths))
        vled.drop("visual_asset", filt.get("deduped", 0),
                  "内容が同一（SHA1 重複）", severity=("high" if vision_route else "low"),
                  detail=("ページ画像の重複除去は白紙ページ等を消す恐れ" if vision_route else ""))
        vled.drop("visual_asset", filt.get("dropped", 0),
                  f"最小サイズ未満（{wf.image_min_bytes}B / {wf.image_min_edge_px}px）",
                  severity=("high" if vision_route else "low"))
        _cap = 0   # v3.28：枚数上限による切り捨ては廃止
        _left = len(raw_paths) - filt.get("deduped", 0) - filt.get("dropped", 0)
        if _cap and _left > _cap:
            vled.drop("visual_asset", _left - _cap, f"枚数上限 {_cap} 超過",
                      severity="high", detail="後半のページ/図が要約に届いていません")
        state["loss_visual"] = vled.raw()
        vtr.use("visual", ENGINE_PILLOW, f"前処理・降采样（{len(raw_paths)} → {len(filt['kept'])}）")
        state["trace_visual"] = vtr.raw()
        # v3.12：dropped_detail（どの図がなぜ落ちたか）と dense（密集頁の圧縮結果）
        # を必ず残す。件数だけでは「減った図」が意図的な圧縮なのか
        # 取りこぼしなのかを後から区別できない。
        _save_json({"raw_count": len(raw_paths), **{k: v for k, v in filt.items() if k != "kept"},
                    "kept_count": len(state["visual_asset_paths"]),
                    "kept": state["visual_asset_paths"],
                    "dense_pages": dense_report,
                    "loss": vled.to_dict()},
                   Path(state["run_dir"]) / "visual_assets_manifest.json")
        meta = f"{len(raw_paths)} -> {len(filt['kept'])}（重複 {filt['deduped']} / 除外 {filt['dropped']}）"
        if pdf_meta:
            meta = f"{pdf_meta}：{meta}"
        _update_status(state, "collect_visual_assets", "done", meta)
        # 并行分支节点只返回自己写的 key（返回整个 state 会与文本分支冲突）
        return {"visual_asset_paths": state["visual_asset_paths"],
                "figure_candidates": state.get("figure_candidates", []),
                "figure_units": state.get("figure_units", 1),
                "figure_context_map": state.get("figure_context_map", {}),
                "loss_visual": state.get("loss_visual", {}),
                "trace_visual": state.get("trace_visual", {}),
                "errors_visual": state.get("errors_visual", [])}

    # ------------------------------------------------------------------
    # ------------------------------------------------------------------


    # v3.8：ページ全体を読ませるときに上の VISION_SYSTEM を使い回すのは誤り。
    # 「装飾なら false」という指示のせいで、図の無い文字だけのスライドに対して
    # モデルが false を返し、ページ全文の書き起こしが丸ごと捨てられていた。
    # ページモードでは「これは資料の本文であって、挿絵ではない」と明示する。
    PAGE_SYSTEM = """あなたは視覚文書エージェントの中でも、ページ全体の読み取りを担当します。
入力画像は挿絵ではなく、**資料そのもののページ**です。OCR と読解を行います。

JSON のみを出力してください。形式：
{
  "has_useful_visual_info": true,
  "visual_type": "text_page | slide | table | chart | mixed | unknown",
  "readable_text": ["string"],
  "visual_summary": "string",
  "key_facts": ["string"],
  "possible_relevance": ["background", "issue", "request_scope", "action", "tool", "finding", "effect"],
  "confidence": 0.0
}

ルール：
1. has_useful_visual_info は**常に true**。ページに文字がある限り「無用」ではない。
2. readable_text はページ上の文字を上から順に、要約せず原文のまま列挙する。
   行数の上限は無い。表は行ごとに 1 要素として書く。
3. 読めない箇所は推測で埋めず「（判読不能）」と書く。捏造しない。
"""

    SHEET_SYSTEM = """あなたは視覚文書分析エージェントです。
入力画像は**複数の図を格子状に並べた 1 枚の合成画像**です。各セルの左上に
[1] [2] … と通し番号とファイル名が振ってあります。

JSON のみを出力してください。形式：
{
  "has_useful_visual_info": true,
  "visual_type": "chart | table | photo | simulation_result | mixed | unknown",
  "readable_text": ["string"],
  "visual_summary": "string",
  "key_facts": ["string"],
  "possible_relevance": ["background", "issue", "request_scope", "action", "tool", "finding", "effect"],
  "confidence": 0.0
}

ルール：
1. まず**全体として何の並びか**（系列データの羅列／条件違いの実験画像／
   スクリーンショット集など）を visual_summary に 1〜2 文で書く。
2. key_facts には「[3] 圧力分布・最大 12.3 kPa」のように**セル番号を頭に付けて**
   個別の事実を書く。読み取れたセルだけでよい。
3. 読めない箇所は推測で埋めず「（判読不能）」と書く。捏造しない。
"""

    #: 「資料そのもののページ」として読ませる資産の種別。
    #: これ以外（埋込図・グラフ）は挿絵として分析する。
    _PAGE_ASSET_KINDS = ("page_render", "sheet_render")

    def _analyze_one_visual(idx: int, img: str, route_vision: bool = False,
                            context: str = "", sheet_members: int = 0) -> VisualEvidence:
        # ---- v3.27.10：読ませ方は**資産ごと**に決める ----
        #
        # 以前はここに `page_mode = (route == "vision")` という実行単位の
        # フラグがそのまま渡っていた。視覚ルートの資産が頁画像しか無かった
        # 頃はそれで正しかったが、v3.27.3 で図版用の埋込画像を意図的に
        # 足したので前提が崩れた。結果、視覚ルートでは埋込図まで
        # PAGE_SYSTEM（頁の書き起こし）で読まれ、figure_caption /
        # figure_worthiness が付かず、図版差し込みが機能しなかった。
        #
        # ルートは「名前も出所も分からない資産をどちらとみなすか」の
        # 手掛かりとしてだけ使い、実際の読ませ方は種別から決める。
        meta = _asset_provenance(img, idx, route_vision)
        page_mode = meta["asset_kind"] in _PAGE_ASSET_KINDS

        if sheet_members:
            user = f"""これは同一ページ上にあった {sheet_members} 枚の図を 1 枚に並べた合成画像です。

{context}
全体として何を並べたものかを述べたうえで、読み取れるセルの事実を
セル番号付きで列挙してください。

以下のテンプレート項目に役立つか判断してください：
依頼元の課題 / 当部への依頼内容 / 実施内容 / 使用機器・ソフト・ツール / 判明した事実 / 対応効果
"""
        elif page_mode:
            # v3.6 視覚直読：入力は「資料そのもののページ」。図の説明ではなく
            # ページに書かれている内容の読み取りを最優先させる（Docling の代役）。
            user = f"""これは資料の {idx + 1} ページ目です。ページ全体を読み取ってください。

1. 本文・見出し・表・グラフの軸ラベル・注記など、**読み取れる文字は
   readable_text にできるだけ漏らさず**書き出す（要約せず原文で）。
2. visual_summary にはこのページが何を述べているかを 1〜3 文で。
3. key_facts には数値・条件・期間・製品名・ツール名など具体的な事実を。

以下のテンプレート項目に役立つか判断してください：
依頼元の課題 / 当部への依頼内容 / 実施内容 / 使用機器・ソフト・ツール / 判明した事実 / 対応効果
"""
        else:
            # v3.12：従来はここに asset_index しか無かった。図が何頁の何の話かを
            # モデルが全く知らないまま読んでいたので、単位や対象の取り違えが
            # 起きやすかった。同じ頁の本文を先頭だけ添える。
            user = f"""この画像を分析してください。

asset_index: {idx + 1}
{context}
以下のテンプレート項目に役立つか判断してください：
依頼元の課題 / 当部への依頼内容 / 実施内容 / 使用機器・ソフト・ツール / 判明した事実 / 対応効果
"""
        # v3.8：2048 では日本語 1 ページの全文書き起こしが途中で切れ、JSON が壊れ、
        # 例外扱いで**ページ丸ごと skip** されていた。ページモードでは上限を上げる。
        raw = vision_llm.chat_vision_json(
            image_path=img,
            system=(SHEET_SYSTEM if sheet_members
                    else (PAGE_SYSTEM if page_mode else VISION_SYSTEM)),
            user_text=user,
            # 合成画像は中身が複数あるので頁と同じ枠を与える（2048 では溢れる）
            max_tokens=(wf.vision_page_max_tokens if (page_mode or sheet_members)
                        else wf.vision_asset_max_tokens),
            json_schema=VisualEvidence.model_json_schema(),
            tag=f"vision:asset_{idx + 1:04d}",
        )
        ve = VisualEvidence.model_validate(raw)
        ve.evidence_id = f"visual_asset_{idx + 1:04d}"
        ve.image_path = img
        # ---- v3.8 溯源：ファイル名に埋まっている頁/シート情報を捨てない ----
        # meta は冒頭で求めた物を使う（読ませ方の判断と種別がずれないように）
        ve.page = meta["page"]
        ve.sheet_name = meta["sheet_name"]
        ve.asset_kind = meta["asset_kind"]
        if page_mode or sheet_members:
            ve.has_useful_visual_info = True   # ページ/合成画像は常に資料本体
        if sheet_members:
            ve.asset_kind = "contact_sheet"
        return ve

    # ==================================================================
    # v3.28 図版候補：位置索引 → 粗選別 →（視覚・融合ルートは頁読み取り後に）精読
    # ==================================================================
    def _keywords_path() -> Path:
        p = Path(getattr(wf, "figure_keywords_path", "") or "config/figure_keywords.yaml")
        return p if p.is_absolute() else PROJECT_ROOT / p

    def _figure_select_cfg() -> Dict[str, Any]:
        return {"min_score": wf.figure_min_score, "elbow_abs": wf.figure_elbow_abs,
                "elbow_rel": wf.figure_elbow_rel, "min_take": wf.figure_min_take,
                "coverage_floor": wf.figure_coverage_floor,
                "budget_per_unit": wf.figure_budget_per_unit,
                "budget_min": wf.figure_budget_min}

    def _layout_select_figures(state: WorkflowState, raw_paths: List[str],
                               figure_pool: List[str], vision_route: bool):
        """埋込画像に位置情報を付けて採点する。

        頁画像がある（視覚・融合ルート）なら、選別は頁の読み取り後に回す
        （頁の読み取り結果が強い手掛かりになるため）。ここでは装飾の除外と
        採点だけ。頁画像が無い（テキストルート・変換失敗）なら、ここで選ぶ。
        """
        out: Dict[str, Any] = {"_raw_paths": list(raw_paths), "_note": "", "_deferred": []}
        if not getattr(wf, "figure_layout_select", True):
            out["_raw_paths"] = list(raw_paths) + [p for p in figure_pool if p not in raw_paths]
            return out, 1
        embeds = [p for p in raw_paths
                  if _asset_provenance(p, 0, False).get("asset_kind") == "embedded"]
        pool = list(dict.fromkeys(list(figure_pool) + embeds))
        if not pool:
            return out, 1
        from .layout_index import (build_figure_candidates, load_keywords,
                                   select_figure_candidates)
        kw = load_keywords(_keywords_path())
        cands, n_units, lmeta = build_figure_candidates(
            state["input_path"], pool, kw,
            min_bytes=wf.image_min_bytes, min_edge=wf.image_min_edge_px)
        embed_set = set(embeds)
        rest = [p for p in raw_paths if p not in embed_set]
        has_pages = any(_asset_provenance(p, 0, vision_route).get("asset_kind")
                        in ("page_render", "sheet_render") for p in rest)
        live = [c for c in cands if c.tier != "drop"]
        n_drop = len(cands) - len(live)
        if vision_route and has_pages:
            out["_raw_paths"] = rest
            out["_deferred"] = [c.to_dict() for c in live]
            out["_note"] = f"図版候補 {len(pool)} 枚（装飾 {n_drop} 枚を除外・頁の読み取り後に選別）"
            report: Dict[str, Any] = {"stage": "deferred"}
        else:
            selected, report = select_figure_candidates(cands, n_units, _figure_select_cfg())
            report["stage"] = "layout_only"
            out["_raw_paths"] = rest + [c.path for c in selected]
            out["_note"] = f"図版候補 {len(pool)} → {len(selected)} 枚（装飾 {n_drop} 枚を除外）"
            # 頁画像が無い経路でも、選んだ図に位置・周辺文を持たせる（figure_select が使う）
            state["figure_context_map"] = {
                Path(c.path).stem: {"context": c.context(800), "page": c.page,
                                    "sheet_name": c.sheet_name} for c in selected}
            if report.get("warning"):
                _push_error(state, "collect_visual_assets", report["warning"], "")
        _save_json({"stage": report.get("stage"), "layout": lmeta, "units": n_units,
                    "report": report, "candidates": [c.to_dict() for c in cands]},
                   Path(state["run_dir"]) / "figure_candidates.json")
        return out, n_units

    def _analyze_figure_candidates(state: WorkflowState, cand_dicts: List[Dict[str, Any]],
                                   page_visual: List[VisualEvidence], route_vision: bool,
                                   start_idx: int, workers: int) -> List[VisualEvidence]:
        """頁の読み取り結果を足して採点し直し、選んだ図版候補だけを VLM で読む。"""
        from .layout_index import (FigureCandidate, load_keywords,
                                   rescore_with_page_reading, select_figure_candidates)
        kw = load_keywords(_keywords_path())
        cands: List[FigureCandidate] = []
        for d in cand_dicts:
            try:
                cands.append(FigureCandidate(**d))
            except TypeError:
                continue
        page_texts: Dict[int, str] = {}
        for v in page_visual:
            if v.asset_kind in ("page_render", "sheet_render") and v.page is not None:
                txt = " ".join([v.visual_summary or ""]
                               + [str(x) for x in (v.key_facts or [])]
                               + [str(x) for x in (v.readable_text or [])])
                page_texts[v.page] = (page_texts.get(v.page, "") + " " + txt)[:4000]
        rescore_with_page_reading(cands, page_texts, kw)
        n_units = int(state.get("figure_units") or 1)
        selected, report = select_figure_candidates(cands, n_units, _figure_select_cfg())
        report.update({"stage": "after_page_reading", "pages_read": len(page_texts)})
        run_dir = Path(state["run_dir"])
        _save_json({"stage": "after_page_reading", "units": n_units, "report": report,
                    "candidates": [c.to_dict() for c in cands]},
                   run_dir / "figure_candidates.json")
        if report.get("warning"):
            _push_error(state, "analyze_visual", report["warning"], "")
        if not selected:
            return []
        filt = prefilter_and_downscale_images(
            [c.path for c in selected], work_dir=str(run_dir / "visual_filtered"),
            min_edge_px=0, min_bytes=0, max_edge_px=wf.image_max_edge_px, max_assets=0)
        kept = filt.get("kept", [])
        imgs = kept if len(kept) == len(selected) else [c.path for c in selected]
        _update_status(state, "analyze_visual", "running",
                       peek=f"図版候補 {len(selected)} 枚を詳しく見ています（{len(cands)} 枚中）")

        def _one(j: int) -> VisualEvidence:
            c = selected[j]
            ve = _analyze_one_visual(start_idx + j, imgs[j], route_vision, context=c.context())
            ve.figure_context = c.context(800)
            ve.page = c.page                 # Word の出現順を頁と誤認させない
            if c.sheet_name:
                ve.sheet_name = c.sheet_name
            return ve

        out: List[VisualEvidence] = []
        store = _store(state)

        def _fail(j: int, e: Exception) -> None:
            _push_error(state, "analyze_visual",
                        f"図版候補 {Path(selected[j].path).name} の分析に失敗したため飛ばしました",
                        repr(e))

        if workers <= 1 or len(selected) <= 1:
            for j in range(len(selected)):
                store.raise_if_cancelled()
                try:
                    out.append(_one(j))
                except (LLMJsonError, ValidationError, RuntimeError) as e:
                    _fail(j, e)
        else:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futs = {pool.submit(_one, j): j for j in range(len(selected))}
                try:
                    for fut in as_completed(futs):
                        store.raise_if_cancelled()
                        try:
                            out.append(fut.result())
                        except (LLMJsonError, ValidationError, RuntimeError) as e:
                            _fail(futs[fut], e)
                except RunCancelled:
                    pool.shutdown(cancel_futures=True)
                    raise
        return out

    def analyze_visual(state: WorkflowState) -> WorkflowState:
        _update_status(state, "analyze_visual")
        cache = Path(state["run_dir"]) / "evidence_visual.json"
        if _resume_ok(state, cache):
            state["visual_evidence"] = json.loads(cache.read_text(encoding="utf-8")).get("evidence", [])
            _update_status(state, "analyze_visual", "done", "キャッシュ再利用")
            return {"visual_evidence": state["visual_evidence"],
                    "errors_visual": state.get("errors_visual", [])}

        paths = state.get("visual_asset_paths", [])
        total = len(paths)
        visual: List[VisualEvidence] = []
        done = 0
        workers = max(1, wf.vision_workers)
        # 視覚直読ルートでは 1 枚 = 資料 1 ページ。プロンプトを読み取り重視に切り替える
        # v3.27.10：これは「ルートの手掛かり」であって資産の種別ではない。
        # 読ませ方は _analyze_one_visual が資産ごとに決める。
        route_vision = state.get("route") in ("vision", "hybrid")

        # ---- v3.12：埋め込み画像に本文の文脈を添える ----
        # chunks は使えない（本文チェーンと並行なので出来ている保証が無い）。
        # 両分岐の上流にある Markdown から頁 -> 冒頭テキストの索引を作る。
        page_text: Dict[int, str] = {}
        if wf.visual_context_chars > 0:
            try:
                page_text = build_page_text_index(state["markdown_path"],
                                                  per_page_chars=wf.visual_context_chars)
            except Exception:  # noqa: BLE001 文脈が無くても視覚分析は続行できる
                page_text = {}

        # 合成画像（コンタクトシート）の構成枚数を引けるようにしておく
        sheet_sizes: Dict[str, int] = {}
        for pg in (state.get("visual_dense_report", {}) or {}).get("pages", []):
            for sp in pg.get("sheets", []) or []:
                sheet_sizes[sp] = pg.get("embedded", 0)

        def _ctx_for(img: str) -> str:
            meta = _asset_provenance(img, 0, False)
            pg = meta.get("page")
            body = page_text.get(pg or -1, "").strip() if pg else ""
            if not body:
                return ""
            return (f"\n--- このページ（{pg} 頁）の本文（抜粋・参考情報）---\n"
                    f"{body}\n--- 本文ここまで ---\n"
                    f"※ 本文は参考です。画像に写っていないことを本文から補って"
                    f"書かないでください。\n")

        def _label(idx: int) -> str:
            """v3.12：エラーに通し番号しか出ないと現物に辿り着けない。

            ファイル名・頁・種別まで出す。ファイル名には出所が畳み込まれている
            （office_p003_image7.png = 3 頁目の OOXML 埋込 7 番目）ので、
            これだけで visual_* フォルダの現物と突き合わせられる。
            """
            try:
                img = paths[idx]
            except IndexError:
                return f"#{idx + 1}"
            meta = _asset_provenance(img, idx, route_vision)
            bits = [f"#{idx + 1}", Path(img).name]
            if meta.get("page"):
                bits.append(f"{meta['page']} 頁")
            if meta.get("sheet_name"):
                bits.append(f"シート「{meta['sheet_name']}」")
            if img in sheet_sizes:
                bits.append(f"合成画像・{sheet_sizes[img]} 枚分")
            return " / ".join(bits)

        failed: List[int] = []

        def _record(idx, result_or_exc):
            nonlocal done
            done += 1
            if isinstance(result_or_exc, Exception):
                # v3.8：ここは「JSON が壊れてページ丸ごと消える」入口だった。
                # errors に 1 行残るだけで UI では埋もれるので、台帳にも積む。
                # v3.12：通し番号だけでは現物に辿り着けないので、ファイル名と頁を出す。
                failed.append(idx + 1)
                _push_error(state, "analyze_visual",
                            f"画像 {_label(idx)} の解析に失敗したため飛ばしました",
                            repr(result_or_exc))
                peek = f"画像 {Path(paths[idx]).name if idx < len(paths) else idx + 1} は解析できませんでした…次へ"
            else:
                visual.append(result_or_exc)
                vs = (result_or_exc.visual_summary or result_or_exc.visual_type or "").strip()
                peek = f"画像『{Path(paths[idx]).name}』を見ました：{vs[:50]}"
            _update_status(state, "analyze_visual", "running", f"{done}/{total}", peek=peek)

        store = _store(state)
        if workers == 1 or total <= 1:
            for idx, img in enumerate(paths):
                store.raise_if_cancelled()
                try:
                    _record(idx, _analyze_one_visual(
                        idx, img, route_vision, context=_ctx_for(img),
                        sheet_members=sheet_sizes.get(img, 0)))
                except (LLMJsonError, ValidationError, RuntimeError) as e:
                    _record(idx, e)
        else:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {pool.submit(_analyze_one_visual, i, p, route_vision,
                                       _ctx_for(p), sheet_sizes.get(p, 0)): i
                               for i, p in enumerate(paths)}
                try:
                    for fut in as_completed(futures):
                        store.raise_if_cancelled()
                        idx = futures[fut]
                        try:
                            _record(idx, fut.result())
                        except (LLMJsonError, ValidationError, RuntimeError) as e:
                            _record(idx, e)
                except RunCancelled:
                    pool.shutdown(cancel_futures=True)
                    raise

        ctx_map = state.get("figure_context_map") or {}
        if ctx_map:
            for v in visual:
                k = Path(v.image_path).stem
                k = k[:-3] if k.endswith("_ds") else k
                info = ctx_map.get(k)
                if info:
                    v.figure_context = v.figure_context or info.get("context", "")
                    v.page = info.get("page")
                    if info.get("sheet_name"):
                        v.sheet_name = info["sheet_name"]

        # ---- v3.28 第二段：頁の読み取り結果を使って図版候補を選び、選んだ物だけ読む ----
        fig_cands = state.get("figure_candidates") or []
        if fig_cands:
            visual.extend(_analyze_figure_candidates(
                state, fig_cands, visual, route_vision, len(paths), workers))

        # 頁順（頁が無ければ evidence_id 順）。信頼度順に並べ替えない。
        visual.sort(key=lambda v: (v.page if v.page is not None else 10**6, v.evidence_id))
        state["visual_evidence"] = [v.model_dump(mode="json") for v in visual]
        _save_json({"evidence": state["visual_evidence"]}, cache)

        vled = LossLedger.from_raw(state.get("loss_visual"))
        vled.observe("visual_evidence_analysis", total)
        vled.drop("visual_evidence_analysis", len(failed),
                  "VLM 応答の JSON 解析に失敗（出力上限超過の可能性）", severity="high",
                  detail=f"対象: {failed[:20]}" if failed else "")
        state["loss_visual"] = vled.raw()

        _update_status(state, "analyze_visual", "done", f"{total} 枚分析")
        return {"visual_evidence": state["visual_evidence"],
                "loss_visual": state["loss_visual"],
                "errors_visual": state.get("errors_visual", [])}

    # ------------------------------------------------------------------
    # v3.12：空欄の扱い。
    #
    # 「対応効果」などが毎回まるごと空になるのは読み手に不便だという要望。
    # ただし空欄を無条件に埋めさせるのは、このシステムが一貫して避けてきた
    # 作話の入口そのもの。そこで「定性的な推定は許すが、数値・日付・固有名詞を
    # 新しく作ることは禁じ、書いたら必ず注記を付ける」という線を引く。
    # 注記があれば読み手は事実と推定を見分けられるし、加筆段階でも除外できる。
    _MISSING_RULE = (
        f"""3. 証拠が直接無い項目でも、**関連する証拠から言える範囲を 1〜2 文書く**。
   その場合、文末に必ず「{INFERRED_NOTE}」を付けること。
   - 書いてよいのは定性的な内容だけ（例：「圧損低減を目的とした検討であり、
     形状変更による改善が期待される{INFERRED_NOTE}」）。
   - **数値・日付・企業名・製品名・ツール名を新しく作ってはいけない。**
     証拠に出てこない固有名詞や数字を推定文に入れることは固く禁じる。
   - 手掛かりが全く無い項目に限り「資料内で確認できず」と書く。
   - テンプレート上この文書種別に存在しない項目は「該当なし」のままにする。"""
        if wf.infer_when_missing else
        "3. 証拠が不足している項目は「資料内で確認できず」と書く。")

    # ------------------------------------------------------------------
    SUMMARY_SYSTEM = f"""あなたは日本語の業務文書要約エージェントです。
証拠に基づき、「{spec.name}」の構造化 JSON を生成します。

{spec.summary_instructions}

重要ルール：
1. evidence で確認できる情報のみ使用する。
2. 依頼元・システム名・期間・効果・ツールを捏造しない。
{_MISSING_RULE}
4. 出力は合法な JSON のみ。最終言語は日本語。
5. evidence フィールドには使用した証拠 ID を列挙する。
6. 図の内容をそのまま述べた項目には、その文の**末尾**に図の証拠 ID を
   [[ ]] で囲んで 1 つだけ付けてください。ID は visual_evidence の
   evidence_id を**そのまま**書き写すこと（例：[[visual_asset_0007]]）。
   短縮したり別名を作ったりしないでください。
   - 付けるのは「その文が、その図が示していることの言い換えになっている」
     場合だけです。図に描かれていない話に付けてはいけません。
   - 数値やグラフの結果を述べた文には、必ず出所の図 ID を付けてください。
   - figure_worthiness が core の図は、資料の要点そのものです。その内容を
     述べた項目が findings / effects に 1 つも無ければ、1 項目として書いて
     ID を付けてください。
   - 該当する図が無ければ何も付けないでください。無理に付けないこと。
7. **period と effects の書き分け**（間違えやすいので必ず読むこと）

   `action_results.period`（対応期間）と `action_results.effects`（対応効果）は
   別の項目です。期間の話だからといって period にまとめてはいけません。

   - `period` に書くのは **所要期間という事実だけ**。
     ✅「依頼から完了まで 28 日」
   - `effects` に書くのは **それが依頼者にとって何の得だったか**。
     ✅「希望納期より 22 日早く完了し、後工程の着手を前倒しできた」

   ❌ してはいけない書き方（period に両方詰め込み、effects を空にする）：
      period: 「依頼から完了まで 28 日。希望納期より 22 日早く完了した」
      effects: （期間に触れない）

   ✅ 正しい配置（同じ数字が両方に出てよい。重複を恐れないこと）：
      period:  「依頼から完了まで 28 日」
      effects: 「希望納期より 22 日早く完了した」

8. `action_results.effects`（対応効果）は、証拠から素直に書けばよい。
   **仕上げは後段の専用パスが行う**ので、ここで凝る必要はない。ただし：
   - 台帳にも本文にも無い金額・日数・評価を作らない
   - 日数計算の証拠があれば、その数字を計算し直さずに使う
   - 期間の便益は period に書いてあっても effects にも書く
"""

    EXPAND_SYSTEM = """あなたは日本語の業務文書要約エージェントです。
既に作られた要約の**特定の項目だけ**を、証拠に基づいて詳しく書き直します。

JSON のみを出力してください。形式：
{"items": ["string", "string"]}

ルール：
1. 証拠に無いことは書かない。一般論・推測で字数を埋めるのは禁止。
2. 1 項目につき 1 つの事実。60〜120 文字程度で、何を・どの条件で・
   どうなったかまで書く。「対応した」「改善した」で止めない。
3. 数値・単位・固有名詞・日付は証拠の表記どおりに保持する。
4. 証拠が足りなければ**項目を増やさない**。短いままで良い。
5. 元の項目の意味を変えない。言い換えて詳しくするだけ。
"""

    #: 二段目で書き足す対象。事実の羅列になりやすく、かつ読み手が
    #: 一番知りたい項目に絞る（全項目を伸ばすと呼び出し回数が跳ねる）。
    _EXPAND_FIELDS = ("findings", "effects", "background", "client_issues",
                      "scope_of_request", "key_results", "discussion",
                      "conclusions", "main_content", "key_points", "purpose")

    def _expand_one_field(label: str, current: List[str],
                          evidence_pack: str) -> Optional[List[str]]:
        """1 項目を証拠に基づいて書き足す。失敗したら None（元のまま使う）。"""
        user = f"""項目「{label}」を詳しく書き直してください。

現在の内容：
{json.dumps(current, ensure_ascii=False)}

根拠として使える証拠：
{evidence_pack}

現在の内容と同じ事実を、証拠の範囲内でより具体的に述べ直してください。
証拠に無い項目を新しく足してはいけません。"""
        try:
            raw = llm.chat_json(system=EXPAND_SYSTEM, user=user,
                                max_tokens=wf.expand_max_tokens,
                                temperature=wf.expand_temperature,
                                tag=f"expand:{label}")
        except (LLMJsonError, RuntimeError):
            return None
        items = raw.get("items") if isinstance(raw, dict) else None
        if not isinstance(items, list):
            return None
        out = [str(x).strip() for x in items if str(x).strip()]
        return out or None

    def expand_summary(state: WorkflowState) -> WorkflowState:
        """二段階書き出しの二段目：指定項目だけを証拠に基づいて伸ばす。

        一段目（write_summary）は temperature 0 ＋ 構造制約で「正しい骨格」を
        作ることに専念させ、ここで初めて表現を厚くする。一発で「正確かつ詳しく」
        を要求すると、弱いモデルは字数を満たすために作話を始める——だから
        課題を 2 つに割る。

        伸ばすのは**証拠がある項目だけ**。空欄・「確認できず」・v3.12 の
        推定注記が付いた項目は触らない（そこを埋めさせる／膨らませるのが
        作話の入口になる）。
        """
        if not wf.expand_summary or state.get("summary_degraded"):
            return {}
        summary = state.get("summary") or {}
        if not summary:
            return {}
        _update_status(state, "expand_summary", peek="要約を証拠に沿って書き足しています…")

        pack = json.dumps({"text_evidence": state.get("aggregated_evidence", [])},
                          ensure_ascii=False, separators=(",", ":"))
        pack = pack[: wf.expand_evidence_chars]

        labels = {f: (getattr(spec, "field_labels", {}) or {}).get(f, f)
                  for f in _EXPAND_FIELDS}
        changed: List[str] = []
        skipped: List[str] = []

        from .contract import is_blank

        # 加筆対象を先に集める。1 項目 = LLM 1 回なので上限を掛け、
        # 内容が多い項目（＝読み手が一番読む所）から優先して使う。
        targets: List[tuple] = []

        def _collect(node: Any) -> None:
            if not isinstance(node, dict):
                return
            for key, val in node.items():
                if isinstance(val, dict):
                    _collect(val)
                elif key in _EXPAND_FIELDS and isinstance(val, list):
                    if is_blank(val):
                        skipped.append(key)   # 空欄は触らない（埋めさせない）
                    elif is_inferred(val):
                        # v3.12：推定で書いた項目は伸ばさない。
                        # 推定をさらに膨らませるのは二重の作話になる。
                        skipped.append(key)
                    else:
                        targets.append((node, key, val))

        _collect(summary)
        targets.sort(key=lambda t: sum(len(str(x)) for x in t[2]), reverse=True)
        budget = max(0, int(wf.expand_max_fields))
        deferred = [k for _, k, _ in targets[budget:]]

        # 加筆結果は必ず数値検証を通す。字数を満たすために数値を作るのが
        # 弱いモデルの典型的な失敗なので、プロンプトの禁止だけに頼らない。
        from .deep_read import verify_items
        rejected: List[Dict[str, Any]] = []

        for parent, key, val in targets[:budget]:
            before = sum(len(str(x)) for x in val)
            got = _expand_one_field(labels.get(key, key), [str(x) for x in val], pack)
            if not got or sum(len(x) for x in got) <= before:
                continue
            if wf.expand_verify_numbers:
                check = verify_items(got, pack)
                if not check["ok"]:
                    # 1 つでも裏が取れない数値があれば、その回の加筆を丸ごと捨てる。
                    # 部分採用は文どうしの整合が崩れてかえって危ない。
                    rejected.append({"field": key, "reason": check["reason"],
                                     "unsupported": check["unsupported"][:5]})
                    _push_error(state, "expand_summary",
                                f"「{labels.get(key, key)}」の加筆を破棄しました"
                                f"（証拠に無い数値を含むため）",
                                check["reason"])
                    continue
            parent[key] = got
            changed.append(key)
        state["summary"] = summary
        state["expanded_fields"] = changed
        _save_json({"expanded": changed, "skipped_blank": skipped,
                    "deferred_over_budget": deferred,
                    "rejected_fabrication": rejected,
                    "llm_calls": min(len(targets), budget)},
                   Path(state["run_dir"]) / "expand_report.json")
        _update_status(state, "expand_summary", "done",
                       f"{len(changed)} 項目を加筆"
                       + (f" / {len(rejected)} 項目を破棄（作話検出）" if rejected else ""),
                       peek=(f"{len(changed)} 項目を証拠に沿って書き足しました"
                             if changed else "加筆できる項目はありませんでした"))
        return {"summary": summary, "expanded_fields": changed}

    # ------------------------------------------------------------------
    def deep_read(state: WorkflowState) -> WorkflowState:
        """精読モード：ページ単位で本文証拠と視覚証拠を突き合わせる。

        逐次 refine にはしない（誤りの伝播と直列の遅さを避けるため）。
        ページ内の突き合わせだけを確定的な規則で行い、集約は従来の
        map-reduce のまま残す。LLM 呼び出しは 1 回も増えない。
        """
        if not wf.deep_read:
            return {"page_report": {}}
        _update_status(state, "deep_read", peek="ページごとに本文と図を突き合わせています…")
        from .deep_read import build_page_report, summary_lines as dr_lines

        report = build_page_report(state.get("aggregated_evidence", []),
                                   state.get("visual_evidence", []))
        state["page_report"] = report
        _save_json(report, Path(state["run_dir"]) / "page_report.json")

        lines = dr_lines(report)
        store = _store(state)
        for line in lines:
            store.logger().info("[deep_read] %s", line)
        detail = (f"{report.get('page_count', 0)} ページ / 要確認 "
                  f"{report.get('conflict_count', 0)}")
        peek = (f"{report['conflict_count']} ページで数値の食い違いを見つけました"
                if report.get("conflict_count") else "ページ間の食い違いはありませんでした")
        _update_status(state, "deep_read", "done", detail, peek=peek)
        return {"page_report": report}

    # ------------------------------------------------------------------
    def _build_summary_user(state: WorkflowState) -> str:
        template_def = spec.raw_yaml
        fewshot = ""
        try:
            from .feedback import get_fewshot_block
            fewshot = get_fewshot_block(config, spec.id)
        except Exception:  # noqa: BLE001 飞轮不可用不影响主流程
            pass
        # 視覚直読ルートでは視覚証拠が本文そのもの。既定の 8000 字上限では
        # ページの読み取り結果が切り捨てられるので、証拠パック全体の予算を回す。
        visual_budget = (wf.max_evidence_pack_chars if state.get("route") in ("vision", "hybrid") else 8000)
        pack = {
            "text_evidence": state.get("aggregated_evidence", []),
            "visual_evidence": visual_to_pack(
                [VisualEvidence.model_validate(d) for d in state.get("visual_evidence", [])],
                max_total_chars=visual_budget,
                readable_text_limit=wf.visual_readable_text_limit,
            ),
        }
        # ---- v3.9：精読モードの突き合わせ結果 ----
        # 「食い違いがある」という事実だけを渡す。どちらが正しいかの裁定は
        # 弱いモデルに任せず、断定を避けるよう指示する。
        page_block = ""
        if wf.deep_read and state.get("page_report"):
            from .deep_read import report_to_prompt_block
            page_block = report_to_prompt_block(state["page_report"])
            if page_block:
                page_block = "\n" + page_block + "\n"

        # ---- v3.8：文書メタ（ファイル名・見出し）を prompt に入れる ----
        # v3.7 では入力ファイル名も文書タイトルも一度も prompt に届いていなかった。
        # 「ファイルに名前もタイトルも有るのに『資料内で確認できず』になる」の
        # 直接原因がこれ。モデルの賢さに頼らず、事実として渡す。
        doc_meta = _document_meta(state)
        # v3.1 prompt 瘦身：紧凑 JSON（indent=2 会放大 30-50% token）
        # + skeleton 替代完整 schema（1519 -> 410 chars，仍由契约自动生成）
        return f"""テンプレート定義（YAML）：

{template_def}
{fewshot}
文書メタ情報（ファイル自体から確定的に取得。推測ではありません）：

{json.dumps(doc_meta, ensure_ascii=False)}
{page_block}
抽出された証拠：

{json.dumps(pack, ensure_ascii=False, separators=(",", ":"))}

以下の形式に厳密に従う JSON を生成してください：

{json.dumps(spec.skeleton(), ensure_ascii=False)}
"""

    def write_summary(state: WorkflowState) -> WorkflowState:
        # 分支汇合点：把视觉分支的错误并回主 errors，后续节点与 UI 只需看一处
        if state.get("errors_visual"):
            state["errors"] = _all_errors(state)
            state["errors_visual"] = []
        n_ev = len(state.get("aggregated_evidence", [])) + len(state.get("visual_evidence", []))
        _update_status(state, "write_summary",
                       peek=f"{n_ev} 件の証拠をもとに要約を書いています…")
        raw = llm.chat_json(
            system=SUMMARY_SYSTEM, user=_build_summary_user(state),
            max_tokens=8192, json_schema=spec.json_schema(),
            tag="summary:main",
        )
        try:
            summary = spec.model.model_validate(raw)
            state["summary_degraded"] = False
            state["summary_errors"] = []
        except ValidationError as e:
            summary = _lenient_summary(raw, spec.model)
            state["summary_raw"] = raw
            state["summary_degraded"] = True
            state["summary_errors"] = [str(e)]
            _push_error(state, "write_summary", "要約の JSON が形式チェックを通らなかったため、修正処理に入ります", str(e))

        summary = spec.post_process(summary)
        summary = _fill_case_name(summary, state)
        state["summary"] = summary.model_dump(mode="json")
        _update_status(state, "write_summary", "done")
        return state

    # ------------------------------------------------------------------
    def validate_summary(state: WorkflowState) -> WorkflowState:
        _update_status(state, "validate_summary")
        try:
            spec.model.model_validate(state.get("summary", {}))
            errors: List[str] = []
        except ValidationError as e:
            errors = [str(e)]

        if state.get("summary_degraded"):
            errors = list(state.get("summary_errors", [])) + errors
            if not errors:
                errors = ["原始 LLM 输出未通过契约校验（已降级），需要修复"]

        summary = state.get("summary", {})
        title = spec.title_of(summary)
        warnings = (["主要項目が「確認できず」です。入力文書と証拠抽出を確認してください。"]
                    if title in ("", UNKNOWN) else [])

        state["validation"] = {"ok": not errors, "errors": errors, "warnings": warnings}
        # ---- v3.8：覆盖率とテンプレート不一致の判定 ----
        # 「ファイル名もタイトルも有るのに全項目が『資料内で確認できず』」の
        # 正体は多くの場合テンプレート不一致。人が気付く前に数値で示す。
        try:
            from .accounting import compute_fill_rate, template_mismatch_verdict
            from .contract import is_blank
            fill = compute_fill_rate(state.get("summary", {}) or {},
                                     getattr(spec, "field_applicability", {}) or {},
                                     is_blank)
            verdict = template_mismatch_verdict(
                fill, getattr(spec, "min_fill_rate", 0.4), spec.name)
            if isinstance(state.get("validation"), dict):
                state["validation"]["fill_rate"] = fill
                state["validation"]["template_verdict"] = verdict
                # ---- v3.12：推定で埋めた項目を別建てで数える ----
                # infer_when_missing を入れた結果、空欄が減って fill_rate は
                # 自動的に上がる。それを「読めるようになった」と誤読すると
                # テンプレート不一致の警報が鳴らなくなり、v3.8 で潰した
                # 「全部確認できず」問題が別の形で戻ってくる。
                # 事実で埋まった数と推定で埋まった数は必ず分けて出す。
                inferred_fields = _count_inferred(state.get("summary", {}) or {})
                state["validation"]["inferred_fields"] = inferred_fields

                # ---- v3.14：台帳との食い違いを検出（コードのみ・LLM 不使用）----
                match = state.get("reference_match") or {}
                if (getattr(wf, "reference_conflict_check", True)
                        and match.get("ok") and match.get("row")):
                    try:
                        conflicts = _reference_conflicts(
                            state.get("summary", {}) or {}, match)
                    except Exception:  # noqa: BLE001 検査の失敗で run を落とさない
                        conflicts = []
                    state["validation"]["reference_conflicts"] = conflicts
                    state["validation"]["reference_match"] = {
                        k: match.get(k) for k in ("method", "confidence", "confirmed")}
                    if conflicts:
                        names = "・".join(c["label"] for c in conflicts[:4])
                        state["validation"].setdefault("warnings", []).append(
                            f"参照台帳の値が要約に反映されていない項目があります（{names}）。"
                            f"どちらが正しいかは判定していません——内容をご確認ください。")
                    if not match.get("confirmed"):
                        state["validation"].setdefault("warnings", []).append(
                            f"参照台帳の照合が確定していません"
                            f"（方式 {match.get('method')}・確度 {match.get('confidence')}）。"
                            f"台帳由来の項目は要確認です。")
                if inferred_fields:
                    state["validation"].setdefault("warnings", []).append(
                        f"{inferred_fields} 項目は資料に明記が無く、関連記述からの"
                        f"推定です（本文中に注記あり）。事実確認のうえご利用ください。")
                if verdict.get("mismatch"):
                    state["validation"].setdefault("warnings", []).append(verdict["message"])
                    state["validation"]["suggested_template"] = "generic_doc"
        except Exception:  # noqa: BLE001 判定の失敗で本流を止めない
            pass

        # ---- v3.8：品質レポートに「どれだけ落としたか」を載せる ----
        # v3.7 の quality_report は JSON schema 検証だけだった。つまり
        # 「形式は正しいが中身が半分欠けている」を正常と判定していた。
        # ---- v3.9：要約本体の数値も証拠と突き合わせる ----
        # 加筆だけでなく一段目の要約も数値を作りうる。ここは破棄はせず
        # （骨格を捨てると出力が空になる）、警告として明示する。人が
        # 「根拠情報」から辿れるように、疑わしい数値をそのまま列挙する。
        try:
            from .deep_read import unsupported_numbers
            ev_blob = json.dumps(state.get("aggregated_evidence", []), ensure_ascii=False)
            vis = state.get("visual_evidence", []) or []
            ev_blob += json.dumps(vis, ensure_ascii=False)
            summary_blob = json.dumps(state.get("summary", {}), ensure_ascii=False)
            bad = unsupported_numbers(summary_blob, ev_blob)
            if isinstance(state.get("validation"), dict):
                state["validation"]["unsupported_numbers"] = bad[:20]
                if bad:
                    state["validation"].setdefault("warnings", []).append(
                        "証拠に見当たらない数値が要約に含まれています（"
                        + "、".join(b["text"] for b in bad[:5])
                        + "）。原文で確認してください")
        except Exception:  # noqa: BLE001 検証の失敗で本流を止めない
            pass

        # ---- v3.9：実行トレース（ルート・使用実装）を品質レポートへ ----
        try:
            tr = PipelineTrace.from_raw(state.get("trace_main"))
            tr.merge(PipelineTrace.from_raw(state.get("trace_visual")))
            if isinstance(state.get("validation"), dict):
                state["validation"]["pipeline_trace"] = tr.to_dict()
                state["validation"]["pipeline_summary"] = tr.summary_lines()
            _save_json(tr.to_dict(), Path(state["run_dir"]) / "pipeline_trace.json")
        except Exception:  # noqa: BLE001 トレースの失敗で本流を止めない
            pass

        led = LossLedger.from_raw(state.get("loss_text"))
        led.merge(LossLedger.from_raw(state.get("loss_visual")))
        loss = led.to_dict()
        if isinstance(state.get("validation"), dict):
            state["validation"]["loss_ledger"] = loss
            state["validation"]["coverage_summary"] = led.summary_lines()
            if loss.get("has_critical_loss"):
                state["validation"].setdefault("warnings", []).append(
                    "入力の相当部分が要約に届いていません（損失台帳を確認してください）")
        _save_json(state["validation"], Path(state["run_dir"]) / "quality_report.json")
        _update_status(state, "validate_summary", "done")
        return state

    # ------------------------------------------------------------------
    REPAIR_SYSTEM = """あなたは JSON 修復エージェントです。
与えられた JSON はスキーマ検証に失敗しました。エラーメッセージに基づいて修正し、
スキーマに厳密に従う合法な JSON のみを出力してください。値の内容は変えず、構造だけ直してください。
"""

    def repair_summary(state: WorkflowState) -> WorkflowState:
        _update_status(state, "repair_summary", peek="JSON の形が崩れていたので直しています…")
        state["repair_attempts"] = state.get("repair_attempts", 0) + 1
        errors = "\n".join(state.get("validation", {}).get("errors", []))
        target = state.get("summary_raw") or state.get("summary", {})
        user = f"""検証エラー：

{errors}

修復対象の JSON：

{json.dumps(target, ensure_ascii=False, indent=2)}

出力形式：

{json.dumps(spec.skeleton(), ensure_ascii=False)}
"""
        try:
            raw = llm.chat_json(system=REPAIR_SYSTEM, user=user, max_tokens=8192,
                                json_schema=spec.json_schema(),
                                tag="repair:summary")
            try:
                summary = spec.model.model_validate(raw)
                state["summary_degraded"] = False
                state["summary_errors"] = []
                state.pop("summary_raw", None)
            except ValidationError as ve:
                summary = _lenient_summary(raw, spec.model)
                state["summary_raw"] = raw
                state["summary_errors"] = [str(ve)]
            summary = spec.post_process(summary)
            summary = _fill_case_name(summary, state)
            state["summary"] = summary.model_dump(mode="json")
        except (LLMJsonError, RuntimeError) as e:
            _push_error(state, "repair_summary", f"修正の {state['repair_attempts']} 回目に失敗しました", repr(e))
        _update_status(state, "repair_summary", "done")
        return state

    # ------------------------------------------------------------------
    # ==================================================================
    # v3.27.11 対応効果の専用パス
    # ==================================================================
    #
    # 対応効果だけを、短い専用 prompt と関係する証拠だけで書き直す。
    # 本文の prompt は 1 万字を超え、この項目の指示は 3 か所に分散して
    # 互いに矛盾していた。弱いモデルは狭い課題なら守れる。広い課題の
    # 隅に置いた指示は守れない。
    #
    # 例文の数字は 〈N〉〈X〉 のような**穴**にしてある。具体的な数字を
    # 見本に書くと、証拠が無いときそれを答えとして書き写す
    # （VISION_SYSTEM の "confidence": 0.0 で実際に起きた）。穴なら
    # 写しても即座に検出できる。
    EFFECTS_SYSTEM = """あなたは技術支援案件の「対応効果・メリット」欄だけを書く担当です。
JSON のみを出力：{"effects": ["項目", "項目", ...]}

効果は**二つの方向**から書きます。証拠がある方向だけ、各 1〜3 項目。

【方向 A：この案件そのもので達成したこと】
解析・調査・対応によって「何が分かるようになったか」「何が良くなったか」
「それが何に使われたか」。findings の言い直しではなく、**依頼者にとっての意味**。
  ・〈対象〉の〈性質〉を数値として比較できるようになり、〈判断〉の根拠が得られた
  ・当初の仮説を〈結果〉が否定し、検討方針の変更につながった
  ・〈不良〉の再現条件を特定でき、〈工程〉の見直しに反映された
  ・定性的にしか語れなかった〈現象〉を可視化し、関係者間の認識が揃った

【方向 B：台帳とアンケートから分かる、時間・費用・評価】
  ・時間：「日数計算・コードによる確定値」があれば**その数字をそのまま使い、
    絶対に計算し直さない**。依頼日→完了日は所要期間（period 欄の話）。
    完了日→希望納期の差が「前倒し」で、これが効果。
      ・希望納期より〈N〉日早く完了し、後工程の着手を前倒しできた
      ・納期に〈N〉日の余裕が生まれ、追加条件での再測定まで実施できた
    日付が曖昧で計算不可とある場合だけ「約〈N〉ヶ月程度」と幅を持たせて概算。
  ・費用：台帳や回答に金額・工数・削減率があれば、数字と単位をそのまま引用。
      ・試作回数の削減により、試作費を約〈X〉万円圧縮できた
      ・外注を見込んでいた解析を内製化し、委託費〈X〉万円の発生を回避した
  ・評価：点数を復唱しない。**何が評価されたか**まで一段まとめる。
    低い評価や指摘事項も、あれば省かない。
      ❌ 満足度は 5 段階中 5。役に立った点は「試作前に不具合を潰せた」
      ✅ 試作前に不具合を特定できた点が評価され、手戻り回避につながったと受け止められている
      ・〈観点〉について、依頼者から特に有用との評価を受けた
      ・評価は高い一方、報告書の粒度には改善余地があるとの指摘を受けた
    - 回答欄が複数ある場合は、欄ごとに箇条書きせず**一つの流れとして統合**する
    - 回答から素直に導ける範囲なら、言い換えや**一段の推論をしてよい**
      （「判断が 2 週間早まった」→「意思決定の前倒しにつながった」）。
      許されるのは意味の言い換えと要約までで、**新しい事実の創作は禁止**
    - **点数しか無い場合**は、点数を評価として述べるにとどめる。
      記述が無いのに具体的な効果を作り出さない。
      回答が証拠に無い欄には触れず、空欄を**憶測で埋めない**
    - 「依頼者評価では」のように出所が分かる書き方にし、解析結果と混ぜない

【共通の禁止事項】
  - 方向 A（案件の成果）と方向 B（台帳・評価）は**別の項目として両方**書く。
    B があるからといって A を削らない。A を B で**置き換えない**。
  - 例文の 〈 〉 は穴。証拠の値で埋める。証拠に無い数字・固有名詞・評価を作らない。
  - 例文の型を穴埋めで繰り返さない。項目ごとに動詞と構文を変える。
    「〜が確認された」「〜に活用された」で全項目を終えない。
  - 日数の証拠があるのに期間に触れないのは誤り。period に書いてあっても effects に書く。
  - 証拠に無い方向は書かない。両方向とも無ければ空配列 [] を返す。
"""

    def _effects_evidence_block(state: WorkflowState, summary: Any) -> str:
        """効果欄に関係する証拠だけを、小さく束ねる。

        本文 prompt の証拠パック（最大 8000 字超）を丸ごと渡すと、専用パスに
        した意味が無い。台帳・日数計算・effect 系・findings だけ。
        """
        ev = state.get("aggregated_evidence", []) or []
        ledger = [e for e in ev if str(e.get("evidence_id", "")).startswith("ref_")]
        effect_ev = [e for e in ev
                     if str(e.get("category", "")) in ("effect", "period")
                     and not str(e.get("evidence_id", "")).startswith("ref_")]
        effect_ev.sort(key=lambda e: -float(e.get("confidence") or 0))
        parts: List[str] = []
        if ledger:
            parts.append("■ 参照台帳（依頼台帳と、依頼完了後のアンケート回答）\n"
                         + "\n".join(f"- {e.get('content', '')}" for e in ledger[:40]))
        if effect_ev:
            parts.append("■ 本文から抽出した効果・期間に関する証拠\n"
                         + "\n".join(f"- {e.get('content', '')}" for e in effect_ev[:12]))
        try:
            ar = summary.action_results
            findings = list(getattr(ar, "findings", []) or [])
            actions = list(getattr(ar, "actions", []) or [])
            draft = list(getattr(ar, "effects", []) or [])
        except AttributeError:
            findings, actions, draft = [], [], []
        if findings:
            parts.append("■ 判明した事実（要約済み・言い直しではなく意味を書くこと）\n"
                         + "\n".join(f"- {x}" for x in findings[:8]))
        if actions:
            parts.append("■ 実施内容（要約済み）\n" + "\n".join(f"- {x}" for x in actions[:6]))
        if draft:
            parts.append("■ 現在の効果欄の下書き（参考。良い項目は活かし、単調・復唱・欠落は直す）\n"
                         + "\n".join(f"- {x}" for x in draft[:8]))
        return "\n\n".join(parts)

    _EFFECTS_SCHEMA = {
        "type": "object",
        "properties": {"effects": {"type": "array", "items": {"type": "string"}}},
        "required": ["effects"],
    }

    def refine_effects(state: WorkflowState) -> WorkflowState:
        """対応効果だけを専用 prompt で書き直す（case テンプレート限定）。"""
        if not getattr(wf, "effects_pass", False):
            return state
        if llm is None:
            return state
        summary_dict = state.get("summary") or {}
        if not isinstance(summary_dict, dict) or "action_results" not in summary_dict:
            return state                                   # 効果欄の無いテンプレート
        try:
            summary = spec.model.model_validate(summary_dict)
        except ValidationError:
            return state

        _update_status(state, "refine_effects", "running", peek="対応効果を仕上げています…")
        block = _effects_evidence_block(state, summary)
        if not block.strip():
            return state

        try:
            raw = llm.chat_json(
                system=EFFECTS_SYSTEM,
                user=("次の材料だけを使って、対応効果・メリット欄を書いてください。\n\n"
                      + block + "\n\n"
                      + 'JSON のみ：{"effects": [...]}'),
                max_tokens=int(getattr(wf, "effects_pass_max_tokens", 1500)),
                json_schema=_EFFECTS_SCHEMA,
                tag="summary:effects",
            )
        except Exception:  # noqa: BLE001 専用パスの失敗で本文を失わない
            _push_error(state, "refine_effects", "対応効果の専用パスに失敗（本文の下書きを維持）",
                        traceback.format_exc()[:1200])
            return state

        items = raw.get("effects") if isinstance(raw, dict) else None
        cleaned: List[str] = []
        seen: set = set()
        for x in (items or []):
            s = re.sub(r"\s+", " ", str(x or "")).strip().rstrip("。")
            if len(s) < 8 or is_blank(s) or is_inferred(s):
                continue
            if "〈" in s or "〉" in s:
                continue                                    # 穴を埋めずに写した
            key = re.sub(r"[\s、。，．]", "", s)
            if key in seen:
                continue
            seen.add(key)
            cleaned.append(s)
        cleaned = cleaned[:8]

        before = list(summary.action_results.effects or [])
        if cleaned:
            summary.action_results.effects = cleaned
            state["summary"] = summary.model_dump(mode="json")
        state["effects_pass"] = {"before": len(before), "after": len(cleaned),
                                 "replaced": bool(cleaned)}
        _update_status(state, "refine_effects", "done",
                       f"効果欄 {len(before)} → {len(cleaned)} 項目")
        return state

    def render(state: WorkflowState) -> WorkflowState:
        _update_status(state, "render")
        from .render import render_markdown

        run_dir = Path(state["run_dir"])
        summary = spec.model.model_validate(state["summary"])

        out_json = run_dir / "case_summary.json"
        # v3.27.2：要約が付ける [[V3]] は図版差し込み用の内部マーカー。
        # **順序が重要**：md には一旦マーカー付きで書き出し（figure_select が
        # 読む）、JSON には最初から除いた物を保存する。md 側のマーカーは
        # attach_figures_to_run が採否にかかわらず必ず取り除く。
        # md だけ掃除して JSON を放置すると RAG 出力・案件台帳・HITL 画面に
        # 内部 ID が漏れるので、真源である JSON 側は先に消す。
        summary_dict = summary.model_dump(mode="json")
        try:
            from .figure_select import strip_citations_deep
            clean_dict = strip_citations_deep(summary_dict)
        except Exception:  # noqa: BLE001 掃除に失敗しても要約は出す
            clean_dict = summary_dict
        _save_json(clean_dict, out_json)
        state["summary"] = clean_dict
        state["output_json"] = str(out_json)

        out_md = run_dir / "case_summary.md"
        render_markdown(summary, str(spec.md_template_path), str(out_md))

        # v3.27.7：日数の証拠があるのに対応効果が期間に触れていない場合に報せる。
        # 直さないのは意図的——「効果」としての言い換えは意味の判断で、
        # コードに作れるのは「抜けている」という指摘だけ。
        try:
            ev = state.get("aggregated_evidence", [])
            for notice in (_effects_missing_period(summary, ev),
                           _example_number_leak(summary, ev)):
                if notice:
                    _push_error(state, "render", notice, "")
        except Exception:  # noqa: BLE001
            pass

        # ---- v3.27：要約文への図版差し込み ----
        # 選定は確定的なコード（app/figure_select.py）。ここでは証拠を渡すだけ。
        # 失敗しても要約そのものは既に書けているので、絶対に本流を止めない。
        fig_cfg = getattr(config, "figures", None)
        if fig_cfg is not None and fig_cfg.enabled:
            _update_status(state, "render", "running", peek="要約に合う図を探しています…")
            try:
                from .figure_select import attach_figures_to_run, make_vlm_verifier
                verifier = None
                if fig_cfg.verify_with_vlm and vision_llm is not None:
                    verifier = make_vlm_verifier(vision_llm)
                res = attach_figures_to_run(
                    run_dir, cfg=fig_cfg.to_dict(), tier="internal",
                    visual_evidence=state.get("visual_evidence", []),
                    text_evidence=state.get("aggregated_evidence", []),
                    verifier=verifier)
                state["figures"] = res.get("report", {})
                if res.get("figures"):
                    _update_status(state, "render", "running",
                                   f"図版 {res['figures']} 枚を差し込み",
                                   peek=f"{res['figures']} 枚の図を本文に差し込みました")
            except Exception:  # noqa: BLE001 図版は付加価値。失敗しても要約は出す
                _push_error(state, "render", "図版の差し込みに失敗しました（要約は出力済み）",
                            traceback.format_exc()[:1500])

        # 版本快照：每次成功渲染都归档一份（重跑/HITL 修订永不丢历史）
        try:
            from .versions import snapshot
            snapshot(run_dir, note="pipeline")
        except Exception:  # noqa: BLE001
            pass
        state["output_markdown"] = str(out_md)

        _update_status(state, "render", "done")
        return state

    # ------------------------------------------------------------------
    def redact_external(state: WorkflowState) -> WorkflowState:
        """社外脱敏版：规则层（NG 词典）→ LLM 泛化改写（泄漏复检，可回退）。"""
        if not config.redaction.enabled:
            _update_status(state, "redact_external", "done", "無効")
            return state
        _update_status(state, "redact_external", peek="社外公開用に固有情報を伏せています…")
        run_dir = Path(state["run_dir"])
        try:
            dictionary = NGDictionary.load(config.paths.resolve(config.redaction.dictionary_path))
            external, report = redact_summary(
                state["summary"], dictionary,
                llm=llm if config.redaction.llm_rewrite else None,
                llm_rewrite=config.redaction.llm_rewrite,
                model=spec.model,
            )
            _save_json(external.model_dump(mode="json"), run_dir / "case_summary_external.json")
            _save_json(report, run_dir / "redaction_report.json")
            from .render import render_markdown
            render_markdown(external, str(spec.md_template_path),
                            str(run_dir / "case_summary_external.md"))
            # v3.27：社外版の図版は既定 OFF。redaction.py は本文しか伏せず、
            # 画像の中の社名・ロゴ・製品外観・試験片の刻印は素通りするため。
            # 明示的に figures.external_tier: true にした場合だけ差し込む。
            fig_cfg = getattr(config, "figures", None)
            if fig_cfg is not None and fig_cfg.enabled and fig_cfg.external_tier:
                try:
                    from .figure_select import attach_figures_to_run
                    attach_figures_to_run(
                        run_dir, cfg=fig_cfg.to_dict(), tier="external",
                        visual_evidence=state.get("visual_evidence", []),
                        text_evidence=state.get("aggregated_evidence", []))
                except Exception:  # noqa: BLE001
                    _push_error(state, "redact_external", "社外版への図版の差し込みに失敗しました（要約は出力済み）",
                                traceback.format_exc()[:1200])
            n = sum(report.get("replacement_counts", {}).values()) if "replacement_counts" in report else                 sum(report.get("alias_map", {}) and [1] or [0])
            counts = report.get("replacement_counts", {})
            llm_used = report.get("llm_rewrite", {}).get("applied")
            detail = f"置換 {sum(counts.values())} 箇所" + ("・LLM による言い換えを採用" if llm_used else "・辞書による置換のみ")
            _update_status(state, "redact_external", "done", detail)
        except Exception:  # noqa: BLE001 脱敏失败不毁掉社内版产出
            _push_error(state, "redact_external", "社外版の作成に失敗しました（社内版には影響ありません）",
                        traceback.format_exc()[:2000])
            _update_status(state, "redact_external", "done", "失敗（続行）")
        return state

    # ------------------------------------------------------------------
    def rag_export(state: WorkflowState) -> WorkflowState:
        """RAG 出口：embedding-ready JSONL 落盘（internal 必出，external 视脱敏而定）。"""
        _update_status(state, "rag_export")
        run_dir = state["run_dir"]
        try:
            p_int = rag_write_jsonl(run_dir, "internal")
            p_ext = rag_write_jsonl(run_dir, "external")
            n_int = len(Path(p_int).read_text(encoding="utf-8").strip().split("\n")) if p_int else 0
            n_ext = len(Path(p_ext).read_text(encoding="utf-8").strip().split("\n")) if p_ext else 0
            _update_status(state, "rag_export", "done",
                           f"社内 {n_int} 件" + (f" / 社外 {n_ext} 件" if n_ext else ""))
        except Exception:  # noqa: BLE001
            _push_error(state, "rag_export", "RAG 用データの出力に失敗しました（処理は継続）", traceback.format_exc()[:1500])
            _update_status(state, "rag_export", "done", "失敗（続行）")
        _update_status(state, "finished", "done", peek="完成しました！")
        return state

    return {
        "create_run_dir": create_run_dir,
        "parse_document": parse_document,
        "route_template": route_template,
        "lookup_reference": lookup_reference,
        "prepare_html_text": prepare_html_text,
        "chunk_text": chunk_text,
        "extract_text_evidence": extract_text_evidence,
        "aggregate_evidence": aggregate,
        "deep_read": deep_read,
        "expand_summary": expand_summary,
        "gap_fill": gap_fill,
        "collect_visual_assets": collect_visuals,
        "analyze_visual": analyze_visual,
        "write_summary": write_summary,
        "validate_summary": validate_summary,
        "repair_summary": repair_summary,
        "refine_effects": refine_effects,
        "render": render,
        "redact_external": redact_external,
        "rag_export": rag_export,
    }



def _excel_html_fallback(state: WorkflowState, parse_dir: Path,
                         input_path: Path, md_path: Path) -> None:
    """Excel の HTML 変換。**openpyxl 本文が取れなかった時だけ**走る（v3.13）。

    v3.12 まではすべての Excel で無条件に HTML を作り、prepare_html_text が
    それを追加のテキスト源として証拠抽出に流していた。しかし消費側は
    `soup.get_text("\n")` で**表を平坦化**する。50 列の表は
    「列名が分からない裸の値が 50 行並ぶ」だけになり、行と列の対応が消える。

    openpyxl が作る Markdown の表は行列関係を保ったままなので、HTML は
    同じ情報の**劣化版**でしかなく、証拠パックの文字数予算を食うだけだった。

    そこで本来の役割——openpyxl が開けなかった時の保険——に戻す。
    その場合の平坦なテキストは「無いよりはまし」なので価値がある。
    """
    md_ok = False
    try:
        md_ok = md_path.exists() and len(md_path.read_text(
            encoding="utf-8", errors="ignore").strip()) >= _EXCEL_MD_MIN_CHARS
    except Exception:  # noqa: BLE001 読めないなら保険を動かす側に倒す
        md_ok = False

    if md_ok:
        state["excel_html_path"] = ""   # 本文が健在なら HTML は要らない
        return

    html_path = parse_dir / f"{input_path.stem}.html"
    # _resume_ok は make_nodes 内のクロージャなのでここからは呼べない。
    # 保険経路なので「既にあるなら作り直さない」だけで十分。
    if html_path.exists() and html_path.stat().st_size > 0:
        state["excel_html_path"] = str(html_path)
        return

    html_result = xlsx_to_html(str(input_path), str(html_path), engine="auto")
    if html_result.get("ok"):
        state["excel_html_path"] = html_result["output_path"]
        _push_error(state, "parse_document",
                    "openpyxl 本文が取得できなかったため、HTML 変換で代替します"
                    "（表の行列構造は失われます）", "")
    else:
        _push_error(state, "parse_document",
                    "Excel から HTML への変換に失敗しました（予備の経路のため処理は継続）", str(html_result))


def _excel_text_pass(state: WorkflowState, store: RunStore, input_path, md_path) -> bool:
    """
    v3.7 Excel 専用の本文抽出。

    Docling(openpyxl 既定) は数式セルを `=SUM(...)` という**文字列**のまま返し、
    グラフは `xl/media` に無いので丸ごと欠落する——大型 xlsm が「中身が取れない」
    と見える主因。ここで 計算結果・数式・グラフの実数値・注記 まで作り切る。
    """
    xl = workbook_to_markdown(str(input_path))
    if xl.get("ok") and xl.get("markdown", "").strip():
        md_path.write_text(xl["markdown"], encoding="utf-8")
        state["markdown_path"] = str(md_path)
        state["excel_info"] = xl.get("info", {})
        store.save_json("excel_info.json",
                        {"info": xl.get("info", {}), "charts": xl.get("charts", 0),
                         "notes": xl.get("notes", [])})
        for note in xl.get("notes", []):
            _push_error(state, "parse_document", note)   # 「見えていない物」を UI に出す
        _update_status(state, "parse_document", "done",
                       f"Excel 読み取り（グラフ {xl.get('charts', 0)} 件）")
        return True
    _push_error(state, "parse_document", "Excel の読み取りに失敗したため、別の方法に切り替えます",
                str(xl.get("error", "")))
    return False


def _excel_com_ready() -> bool:
    """Excel COM が使えるか（Windows + Excel 実機のみ true）。"""
    try:
        from tools.excel_com import excel_available
        return bool(excel_available())
    except Exception:  # noqa: BLE001
        return False


def _excel_page_images(state: WorkflowState, wf) -> tuple:
    """視覚ルート用：各シートを「横 1 ページに収める」設定でページ画像化する。

    数値表（numCache）経路は本文側で生きているので、ここは**裏取り用の目**。
    失敗しても空を返すだけで、呼び出し側が LibreOffice 経路へ後退する。
    """
    from tools.excel_com import excel_sheet_pdfs

    run_dir = Path(state["run_dir"])
    sheets = excel_sheet_pdfs(
        state["input_path"], str(run_dir / "visual_excel_sheets"),
        max_sheets=wf.excel_sheet_render_max_sheets,
        fit_to_width=True, landscape=wf.excel_sheet_render_landscape,
        timeout_seconds=wf.excel_sheet_render_timeout)
    pages = _render_sheet_pdfs(sheets.get("sheets", []),
                               run_dir / "visual_excel_sheets",
                               scale=wf.pdf_render_scale,
                               max_pages=(wf.vision_route_max_render_pages or 100000))
    skipped = [x for x in sheets.get("sheets", []) if x.get("skipped")]
    if skipped:
        _push_error(state, "collect_visual_assets",
                    f"Excel シート {len(skipped)} 件は画像化しませんでした（処理は継続）",
                    json.dumps(skipped, ensure_ascii=False)[:1500])
    meta = f"シート描画 {len(pages)} 枚（{sheets.get('exported', 0)} シート・Excel COM）"

    # ---- v3.11 修正：視覚ルートでも埋め込み画像を拾う ----
    #
    # ここが _excel_visuals との非対称だった。本文ルート（_excel_visuals）は
    # 「グラフ実画像化＋シート描画＋埋め込み画像」の三点セットなのに、
    # 視覚ルートのこちらはシート描画だけで return していた。
    #
    # シート描画は「印刷した見た目」なので貼り付け画像も一応写ってはいるが、
    # 縮小されて潰れる。元画像を別資産として渡せば VLM が細部を読める。
    # 重複は collect_visuals 側の SHA1 去重が面倒を見るので二重計上にならない。
    #
    # **シート描画が空の時は足さない**。呼び出し側は「戻り値が空か」だけで
    # 後退（LibreOffice 経路 → 埋め込み画像）を判断しているので、ここで
    # 埋め込み画像を混ぜると「COM は失敗したのに空でない」状態になり、
    # 後退そのものが黙って飛ばされてシート描画を永久に失う。
    # 空で返せば既存の後退チェーンが最終的に埋め込み画像へ辿り着くので、
    # 画像が失われることはない。
    if not pages:
        return pages, meta

    office = extract_office_visuals(
        state["input_path"],
        out_dir=str(run_dir / "visual_office"),
        max_assets=getattr(wf, "max_visual_assets", 30) * 4)
    pages.extend(office.get("visual_asset_paths", []))
    meta += f" / 埋込 {office.get('embedded', 0)}"
    if office.get("skipped_vector"):
        meta += f"・ベクタ図スキップ {office['skipped_vector']}"
    return pages, meta


def _image_area(path: str) -> int:
    """画像の面積（px）。開けない物は 0。密集頁で「どれを図版用に残すか」の
    順位付けに使う。小さい物は装飾・アイコンで、大きい物が本命の図。"""
    try:
        from PIL import Image
        with Image.open(path) as im:
            w, h = im.size
        return int(w) * int(h)
    except Exception:  # noqa: BLE001
        return 0


def _allocate_visual_quota(paths: List[str], reserve: int) -> List[str]:
    """図版になりうる資産を枠の先頭に確保してから、残りを元の順で並べる。

    従来は raw_paths の**並び順の先着**で上限を切っていた。これは暗黙の
    優先順位で、実際に壊れていた：_excel_visuals は
        グラフ画像 → シート頁画像 → 埋込画像
    の順に積むので、シート頁画像が上限（既定 30）を食い尽くし、最後尾の
    埋込画像は `visual_asset_paths` に一枚も入らなかった。ファイルは
    visual_office/ に書き出されているのに、パイプラインが一度も見ない
    ——「抽出はできているのに使われない」という気付きにくい欠落。

    ここでは切らずに**並べ替えるだけ**にする。上限は後段の
    prefilter_and_downscale_images が掛けるので、開けない画像が落ちた分は
    自動的に後ろ（頁画像）から詰められ、図版候補は残る。
    """
    if reserve <= 0 or not paths:
        return paths
    fig_idx: List[int] = []
    other_idx: List[int] = []
    for i, p in enumerate(paths):
        kind = _asset_provenance(p, 0, False).get("asset_kind")
        (fig_idx if kind in ("embedded", "chart") else other_idx).append(i)
    if not fig_idx or not other_idx:
        return paths                      # 片方しか無いなら並べ替える意味がない
    head = fig_idx[:reserve]
    taken = set(head)
    return [paths[i] for i in head] + [paths[i] for i in range(len(paths)) if i not in taken]


def _collect_figure_assets(state: WorkflowState, wf, suffix: str) -> Tuple[List[str], str]:
    """図版差し込み用の埋込画像を集める（頁描画とは別枠）。

    視覚ルートでは埋込抽出が「頁描画が失敗したときのフォールバック」に
    なっていて、しかも対象拡張子に **.pdf が入っていなかった**。つまり
    PDF は視覚ルートだと埋込図を得る経路が存在しなかった。
    PDF が内嵌図を抽出できないわけではない（pdf_extract_embedded は既定 True）。
    """
    # v3.28：枚数の割当ではなく「全部抽出して位置で選ぶ」。ここは暴走防止の上限だけ。
    quota = int(getattr(wf, "figure_extract_max", 500) or 500)
    if quota <= 0:
        return [], ""
    run_dir = Path(state["run_dir"])
    try:
        if suffix == ".pdf":
            res = extract_pdf_visuals(
                state["input_path"], out_dir=str(run_dir / "visual_pdf"),
                max_assets=quota, extract_embedded=True,
                render_fallback=False,          # 頁描画は別経路で既に取っている
                render_min_text_chars=wf.pdf_render_min_text_chars,
                render_scale=wf.pdf_render_scale)
        elif suffix in (".pptx", ".docx", ".xlsx", ".xlsm"):
            res = extract_office_visuals(
                state["input_path"], out_dir=str(run_dir / "visual_office"),
                max_assets=quota)
        else:
            return [], ""
    except Exception:  # noqa: BLE001 図版用の収集で本流を止めない
        _push_error(state, "collect_visual_assets",
                    "図版用の埋め込み画像の収集に失敗しました（処理は継続）", traceback.format_exc()[:1200])
        return [], ""

    paths = [p for p in res.get("visual_asset_paths", [])
             if _asset_provenance(p, 0, False).get("asset_kind") in ("embedded", "chart")]
    paths = paths[:quota]
    meta = f"図版用埋込 {len(paths)}"
    if res.get("skipped_vector"):
        meta += f"・ベクタ図スキップ {res['skipped_vector']}"
    return paths, meta


def _excel_visuals(state: WorkflowState, wf) -> tuple:
    """Excel の視覚資産を集める。Excel COM があればグラフを実画像化、
    無ければ埋め込み画像のみ（グラフの数値は本文の表として既に入っている）。"""
    from tools.excel_com import excel_available, excel_extract, excel_sheet_pdfs

    run_dir = Path(state["run_dir"])
    raw_paths: List[str] = []
    meta_parts: List[str] = []

    if excel_available():
        res = excel_extract(state["input_path"], str(run_dir / "visual_excel"),
                            export_pdf=False, export_charts=True,
                            max_charts=wf.max_visual_assets)
        imgs = res.get("chart_images", [])
        raw_paths.extend(imgs)
        meta_parts.append(f"グラフ画像 {len(imgs)}")
        if not res.get("ok") and res.get("error"):
            _push_error(state, "collect_visual_assets",
                        "Excel COM でのグラフ書き出しに失敗しました（処理は継続）", str(res.get("error")))

        # ---- v3.8：シート単位のページ画像化（win32com）----
        # LibreOffice 経由だと横に広い表が数十ページに飛び散り、しかも
        # SinglePageSheets には約 1022 行でデータが欠ける既知の不具合がある。
        # Excel COM なら PageSetup で「横 1 ページに収める・縦は流す」を
        # 直接指定できるので、人が印刷して読むのと同じ物を VLM に渡せる。
        if wf.excel_sheet_render:
            sheets = excel_sheet_pdfs(
                state["input_path"], str(run_dir / "visual_excel_sheets"),
                max_sheets=wf.excel_sheet_render_max_sheets,
                fit_to_width=True, landscape=wf.excel_sheet_render_landscape,
                timeout_seconds=wf.excel_sheet_render_timeout)
            pages = _render_sheet_pdfs(sheets.get("sheets", []),
                                       run_dir / "visual_excel_sheets",
                                       scale=wf.pdf_render_scale,
                                       max_pages=wf.excel_sheet_render_max_pages)
            raw_paths.extend(pages)
            meta_parts.append(f"シート画像 {len(pages)}（{sheets.get('exported', 0)} シート）")
            if sheets.get("skipped"):
                _push_error(state, "collect_visual_assets",
                            f"Excel シート {sheets.get('skipped')} 件は画像化しませんでした（処理は継続）",
                            json.dumps([x for x in sheets.get("sheets", []) if x.get("skipped")],
                                       ensure_ascii=False)[:1500])
            if not sheets.get("ok") and sheets.get("error"):
                _push_error(state, "collect_visual_assets",
                            "Excel シートの画像化に失敗しました（数値表からの読み取りは有効です）",
                            str(sheets.get("error")))
    else:
        n_charts = len(extract_charts(state["input_path"]))
        if n_charts:
            meta_parts.append(f"グラフ {n_charts} 件は数値表として本文に取込済")

    office = extract_office_visuals(state["input_path"],
                                    out_dir=str(run_dir / "visual_office"),
                                    max_assets=wf.max_visual_assets * 4)
    raw_paths.extend(office.get("visual_asset_paths", []))
    meta_parts.append(f"埋込 {office.get('embedded', 0)}")
    return raw_paths, " / ".join(meta_parts)


def _fill_case_name(summary, state: Dict[str, Any]):
    """case_name が空 / UNKNOWN のとき、確定的に埋める。

    「ファイルに名前もタイトルも有るのに『資料内で確認できず』になる」への
    最後の歯止め。モデルの判断を待たず、コードが事実で埋める：
        文書の先頭見出し > ファイル名（拡張子なし）
    これは推測ではない——ファイル名も見出しも資料そのものの一部。
    """
    try:
        current = (getattr(summary, "case_name", "") or "").strip()
    except Exception:  # noqa: BLE001 モデルに case_name が無いテンプレートもある
        return summary
    if current and current != UNKNOWN:
        return summary
    meta = _document_meta(state)
    fallback = (meta.get("document_title") or "").strip() or (meta.get("file_stem") or "").strip()
    if not fallback:
        return summary
    try:
        summary.case_name = fallback
        if hasattr(summary, "finalize_titles"):
            summary.finalize_titles()
    except Exception:  # noqa: BLE001
        pass
    return summary





_MAX_DATE_PAIRS = 10


def _reference_date_evidence(row: "ReferenceRow", conf: float, src: str,
                             tag: str) -> List[Evidence]:
    """台帳の日付列どうしの**日数差**を、先に計算して証拠に足す。

    なぜ計算だけコードでやるのか
    ---------------------------
    「完了日 − 依頼日 = 所要期間」という**意味付け**はモデルの仕事。
    列名が何を指すかを表で決めない、という v3.15 の方針は変えない。
    だが引き算そのものは意味の問題ではなく算術で、弱いモデルが月跨ぎで
    平気で間違える領域。そこで **コードは差だけ出し、生の表頭のまま並べる**。
    どの差が「所要期間」で、どの差が「前倒し日数」かはモデルが決める。

    解析できない日付は放置する
    -------------------------
    「6月末」「来月中旬」「Q2 中」のような曖昧な記述は datetime にできない。
    その場合ここでは何も足さない——生の値は既に証拠として渡っているので、
    モデルが概算する。**計算できるものは保証し、できないものだけ推定に回す**、
    という順序にしてある（常にモデルに投げると、確実に出せた答えまで
    確率的になる）。
    """
    dated: List[Tuple[str, "_dt.datetime"]] = []
    vague: List[str] = []
    for head, value in row.nonempty():
        label = head or "(無題列)"
        text = str(value).strip()
        dt = parse_date_string(text)
        if dt is not None:
            dated.append((label, dt))
        elif _looks_like_vague_date(text):
            vague.append(label)

    out: List[Evidence] = []
    if len(dated) >= 2:
        lines = [f"「{h}」{d.strftime('%Y-%m-%d')}" for h, d in dated]
        out.append(Evidence(
            evidence_id="ref_date_00", category="other",
            content=f"{tag}参照台帳（日付の正規化）：" + " / ".join(lines),
            confidence=conf, source=f"参照台帳 {src}", chunk_id="reference:dates"))

        n = 0
        for i in range(len(dated)):
            for j in range(i + 1, len(dated)):
                if n >= _MAX_DATE_PAIRS:
                    break
                (h1, d1), (h2, d2) = dated[i], dated[j]
                days = (d2 - d1).days
                if abs(days) > 365 * 5:
                    continue                 # 別物の日付（作成日と保管期限など）
                n += 1
                early, late = (h1, h2) if days >= 0 else (h2, h1)
                out.append(Evidence(
                    evidence_id=f"ref_date_{n:02d}", category="other",
                    content=(f"{tag}参照台帳（日数計算・コードによる確定値）："
                             f"「{early}」から「{late}」まで {abs(days)} 日"
                             f"（約 {abs(days) / 30.4:.1f} ヶ月）"),
                    confidence=conf, source=f"参照台帳 {src}",
                    chunk_id=f"reference:date_diff:{early}->{late}"))

    if vague:
        # 計算できなかったことを明示する。黙って落とすと、モデルは
        # 「日付の記載が無い」と解釈して期間に触れなくなる。
        out.append(Evidence(
            evidence_id="ref_date_99", category="other",
            content=(f"{tag}参照台帳（日付が曖昧で計算不可）：" + "・".join(vague)
                     + "。これらは記述から期間を概算すること"),
            confidence=max(0.05, conf * 0.8), source=f"参照台帳 {src}",
            chunk_id="reference:dates_vague"))
    return out


_VAGUE_DATE_RE = re.compile(
    r"(上旬|中旬|下旬|月末|月初|年度末|年内|今月|来月|再来月|翌月|"
    r"今週|来週|四半期|q[1-4]|至急|未定|以降|以内|頃|ごろ|めど|目処)", re.I)


def _looks_like_vague_date(text: str) -> bool:
    """曖昧な時期の記述か。数字の日付として解析できなかった値にだけ使う。"""
    if not text or len(text) > 40:
        return False
    s = unicodedata.normalize("NFKC", text).lower()
    return bool(_VAGUE_DATE_RE.search(s))


def _reference_to_evidence(result: "MatchResult",
                           confidence_factor: float = 0.9) -> List[Evidence]:
    """台帳の 1 行を Evidence の並びに変換する（v3.15 で全面的に作り直し）。

    v3.14 は語彙表で列を論理名へ翻訳し、翻訳できた列だけを証拠にしていた。
    それは二重に誤りだった：

      1. 表に無い列（「使用ソフト」「特記事項」…）が黙って消える。
         人が手で埋めた情報を、こちらの都合で無かったことにしていた。
      2. 「起案部門」が依頼者を指すかどうかは語彙ではなく **意味** の問題。
         コードが表引きで決めることではなく、モデルが判断すべきこと。

    なので今は **全列を生の表頭のまま** 渡す。
    「『起案部門』: 製造技術部」と書いてあれば、それがどの項目に当たるかは
    モデルが決める。これは追加の LLM 呼び出しではない——もともとの
    write_summary の証拠パックに混ざるだけ。

    分類は一律 "other"。ここで category を決め打ちすると、それ自体が
    語彙表の作り直しになる。

    v3.19：確度に係数を掛けて **元資料より少し低く** する。
    報告書そのものが一次資料で、台帳は補助——記載が古い場合もあれば、
    部分一致で行がずれている場合もある。両者が食い違ったときに
    本文側が優先されるよう、最初から差を付けておく。
    """
    row = result.row
    if row is None:
        return []

    tag = "" if result.confirmed else "【要確認】"
    src = f"{Path(row.source_file).name}#{row.sheet_name}:{row.row_number}"
    conf = max(0.05, min(1.0, float(result.confidence) * float(confidence_factor)))
    out: List[Evidence] = []

    for i, (head, value) in enumerate(row.nonempty()):
        label = head or "(無題列)"
        # 照合が当たった列は検索の鍵そのもの（保存パス等）なので要約には要らない
        if head and head == getattr(result, "matched_header", ""):
            continue
        out.append(Evidence(
            evidence_id=f"ref_{i + 1:02d}",
            category="other",
            content=f"{tag}参照台帳「{label}」：{value}",
            confidence=conf,
            source=f"参照台帳 {src}",
            chunk_id=f"reference:{label}",
            sheet_name=row.sheet_name,
            origin="ledger",
        ))

    # v3.27.4：日付どうしの差は先に計算して渡す（算術はモデルに投げない）。
    # 意味付け（どれが所要期間か）はモデルの仕事なので、生の表頭のまま並べる。
    try:
        out.extend(_reference_date_evidence(row, conf, src, tag))
    except Exception:  # noqa: BLE001 日付計算の失敗で台帳証拠ごと失うのは損
        pass
    return out


#: 例文由来の漏れを見張る目印（v3.27.11）。
#: 例文の数字は 〈N〉〈X〉 の穴にしたので、穴の記号そのものが出力に残れば
#: 「型を埋めずに写した」と即座に分かる。加えて、例文にしか無い具体語句を
#: 数個置く。証拠側にもあれば漏れではない（照合は空白を潰して行う）。
#: EFFECTS_SYSTEM の例文を書き換えたらここも必ず揃えること。
_PROMPT_EXAMPLE_FIGURES = ("〈", "〉", "試作前に不具合", "委託費", "後工程の着手を前倒し",
                           "追加条件での再測定", "報告書の粒度")


def _example_number_leak(summary: Any, evidence: List[dict]) -> Optional[str]:
    """プロンプトの例文の数字が、証拠に無いのに出力へ紛れ込んでいないか。

    これは「禁止したのに守られなかった」を検出するためのもので、
    自動では直さない。人が見て判断する材料として出す。

    照合は**空白を潰して**行う。台帳が「約120万円」、要約が「約 120 万円」
    と書くのはごく普通で、そこで誤検知すると警告そのものが無視される
    ようになる（誤検知は未検知より悪い）。
    """
    try:
        effects = summary.action_results.effects or []
    except AttributeError:
        return None
    body = re.sub(r"\s+", "", " ".join(str(x) for x in effects))
    if not body:
        return None
    ev_text = re.sub(r"\s+", "", " ".join(str(e.get("content", ""))
                                          for e in (evidence or [])))
    hits = []
    for fig in _PROMPT_EXAMPLE_FIGURES:
        f = re.sub(r"\s+", "", fig)
        if f in body and f not in ev_text:
            hits.append(f)
    if not hits:
        return None
    return ("対応効果に、プロンプトの例文に由来すると思われる数値が含まれています"
            f"（{'、'.join(sorted(set(hits)))}）。証拠側には見当たりません。"
            "捏造の可能性があるため確認してください")


_EFFECT_PERIOD_WORDS = ("短縮", "前倒し", "早く", "早期", "納期", "日数", "期間")


def _effects_missing_period(summary: Any, evidence: List[dict]) -> Optional[str]:
    """日数の証拠があるのに effects が期間に触れていない場合、その旨を返す。

    プロンプトで書き分けを指示しても、弱いモデルは「期間の話は period」と
    まとめてしまう（実際 v3.27.4 の初回実行がそうだった）。ここでは
    **直さない**——本文を機械が書き換えると、どちらが書いたか分からなくなる。
    人に見える形で報せるところまでが仕事。

    「効果」としての言い換えは意味の判断なので、コードには作れない。
    作れるのは「抜けている」という指摘だけ。
    """
    has_date_math = any("日数計算" in str(e.get("content", "")) for e in (evidence or []))
    if not has_date_math:
        return None
    try:
        effects = summary.action_results.effects or []
    except AttributeError:
        return None
    joined = " ".join(str(x) for x in effects)
    if any(w in joined for w in _EFFECT_PERIOD_WORDS):
        return None
    return ("台帳の日数計算はありますが、対応効果に期間短縮の項目がありません"
            "（対応期間の欄だけに書かれている可能性があります）。"
            "修訂タブで対応効果に移すか追記してください")


def _reference_conflicts(summary: Any, match: Dict[str, Any],
                         spec: "ReferenceSpec" = None) -> List[Dict[str, str]]:
    """台帳の値のうち、要約本文に現れていない物を挙げる（LLM 不使用）。

    名前に反して、これは **矛盾** ではなく **欠落** の検出。
    「要約が書き忘れた」と「要約が違うことを書いた」を区別できない点は
    自覚しておく必要がある（区別するには意味の照合が要り、それは
    弱いモデルに任せるべきでない領域）。

    どちらが正しいかは判定しない——精読モードと同じ立場。事実を並べて人に渡す。
    """
    row = (match or {}).get("row") or {}
    values = row.get("values") or {}
    if not values:
        return []

    def _flatten(node: Any) -> str:
        if isinstance(node, dict):
            return " ".join(_flatten(v) for v in node.values())
        if isinstance(node, (list, tuple)):
            return " ".join(_flatten(v) for v in node)
        return str(node) if node is not None else ""

    body = normalize_text(_flatten(summary))
    if not body:
        return []

    matched_head = (match or {}).get("matched_header") or ""
    out: List[Dict[str, str]] = []
    for head, raw in values.items():
        raw = (raw or "").strip()
        # 照合の鍵に使ったセルは要約に載る物ではない
        if head and head == matched_head:
            continue
        # 短すぎる値は誤検出の元（「A」「1」など）
        if len(raw) < 3:
            continue
        if normalize_text(raw) not in body:
            out.append({
                "field": head,
                "label": head,
                "ledger_value": raw,
                "note": "台帳の値が要約本文に現れていません（要確認）",
            })
    return out


def _count_inferred(node: Any) -> int:
    """要約の中で推定注記が付いた項目の数を数える（v3.12）。

    fill_rate だけを見ると「推定で埋めた」も「事実で埋まった」も同じに
    見えてしまうため、品質レポートで必ず分けて示す。
    """
    if isinstance(node, dict):
        return sum(_count_inferred(v) for v in node.values())
    if isinstance(node, list):
        return 1 if is_inferred(node) else 0
    if isinstance(node, str):
        return 1 if INFERRED_NOTE in node else 0
    return 0


def _compress_dense_pages(paths: List[str], run_dir: str, wf) -> Tuple[List[str], Dict[str, Any]]:
    """画像が密集した頁を「頁画像 1 枚」か「格子画像 1 枚」にまとめる（v3.12）。

    返り値: (新しい資産リスト, レポート)

    レポートは manifest に残す。何をどうまとめたかが見えないと、
    「図が減っている」のが圧縮なのか取りこぼしなのか区別が付かない。
    """
    from .parsing import make_contact_sheets

    # 頁ごとに「全面レンダリング」と「埋め込み」を仕分ける
    by_page: Dict[Optional[int], Dict[str, List[str]]] = {}
    order: List[str] = []
    for p in paths:
        meta = _asset_provenance(p, 0, False)
        page = meta.get("page")
        kind = meta.get("asset_kind")
        slot = by_page.setdefault(page, {"page_render": [], "embedded": []})
        slot["page_render" if kind in ("page_render", "sheet_render") else "embedded"].append(p)
        order.append(p)

    threshold = wf.dense_page_threshold
    kept: List[str] = []
    handled: set = set()
    pages_report: List[Dict[str, Any]] = []

    for page, slot in by_page.items():
        embedded = slot["embedded"]
        if page is None or len(embedded) < threshold:
            continue  # 頁が特定できない／密集していない → 通常どおり
        if slot["page_render"]:
            # 1) 頁画像が有るなら埋め込みは**本文を読む用途としては**重複情報。
            #    ただし v3.27.3 以降、埋め込み画像には図版差し込みという別の
            #    用途がある。頁画像は報告書に貼れないので、全部落とすと
            #    その頁からは図版が一枚も出せなくなる。
            #    面積の大きい順に keep_n 枚だけ残す（小さい物は装飾・アイコンで、
            #    大きい物が本命の図である公算が高い）。
            keep_n = max(0, int(getattr(wf, "dense_page_keep_for_figures", 2)))
            ranked = sorted(embedded, key=_image_area, reverse=True)
            keep, drop = ranked[:keep_n], ranked[keep_n:]
            handled.update(drop)
            pages_report.append({"page": page, "embedded": len(embedded),
                                 "action": "dropped_for_page_render",
                                 "kept_for_figures": len(keep), "produced": 0})
            continue
        if not wf.contact_sheet_enabled:
            continue
        sheets = make_contact_sheets(
            embedded, out_dir=str(Path(run_dir) / "visual_contact"), page=page,
            cols=wf.contact_sheet_cols, max_edge_px=wf.contact_sheet_max_edge_px,
            max_cells=wf.contact_sheet_max_cells)
        if not sheets:
            continue  # 合成できなければ元のまま送る（落とさない）
        handled.update(embedded)
        for sh in sheets:
            kept.append(sh["path"])
        pages_report.append({"page": page, "embedded": len(embedded),
                             "action": "contact_sheet", "produced": len(sheets),
                             "sheets": [s["path"] for s in sheets]})

    out = [p for p in order if p not in handled] + kept
    return out, {"before": len(paths), "after": len(out),
                 "threshold": threshold, "pages": pages_report}


def _asset_provenance(img: str, idx: int, page_mode: bool) -> Dict[str, Any]:
    """画像ファイル名に埋め込まれた頁/シート情報を取り出す。

    v3.7 は PDF 抽出画像が pdf_p003_img01.png と頁番号を持っていたのに、
    VLM へは asset_index しか渡さず、VisualEvidence にも頁の枠が無かった。
    せっかく有る情報を捨てていたので、ここで拾い直す。

    対応する命名（app/parsing.py と tools/excel_com.py 由来）：
        pdf_p003_img01.png  -> 3 頁の埋込画像
        pdf_p003_page.png   -> 3 頁の全面レンダリング
        page_003.png        -> 視覚ルートの全面レンダリング
        sheet_02_売上.png   -> Excel シート画像
        office_p003_image7.png -> 3 頁目に置かれた OOXML 埋込画像
        office_image3.png   -> OOXML 埋込（頁が辿れなかった場合）
    """
    name = Path(img).name
    out: Dict[str, Any] = {"page": None, "sheet_name": "", "asset_kind": "embedded"}
    m = re.match(r"pdf_p(\d+)_(img\d+|page)", name)
    if m:
        out["page"] = int(m.group(1))
        out["asset_kind"] = "page_render" if m.group(2) == "page" else "embedded"
        return out
    m = re.match(r"page_(\d+)", name)
    if m:
        out["page"] = int(m.group(1))
        out["asset_kind"] = "page_render"
        return out
    m = re.match(r"office_p(\d+)_", name)
    if m:
        out["page"] = int(m.group(1))
        out["asset_kind"] = "embedded"
        return out
    m = re.match(r"sheet_(\d+)_(.+?)_p(\d+)\.", name) or re.match(r"sheet_(\d+)_(.+?)\.", name)
    if m:
        out["page"] = int(m.group(3)) if m.lastindex and m.lastindex >= 3 else int(m.group(1))
        out["sheet_name"] = m.group(2)
        out["asset_kind"] = "sheet_render"
        return out
    if name.startswith("chart"):
        out["asset_kind"] = "chart"
        return out
    # v3.27.9：頁番号を辿れなかった OOXML 埋込（office_image3.png）。
    # Excel は「頁」が無いので xl/media の画像はこの形になる。PPTX は
    # スライド番号が付いて office_p006_image11.png になるため上で拾われる。
    # **この非対称が、PPTX では図が出て Excel では出ない原因だった。**
    if name.startswith("office_"):
        out["asset_kind"] = "embedded"
        return out

    # 置かれたディレクトリは出所そのものなので、名前より確かな手掛かり。
    # 命名規則が増えるたびに取りこぼすより、収集経路で判断する。
    parent = Path(img).parent.name.lower()
    if parent in ("visual_office", "visual_pdf", "figures"):
        out["asset_kind"] = "embedded"
        return out
    if parent == "visual_excel":
        out["asset_kind"] = "chart"
        return out
    if parent in ("visual_pages", "visual_contact"):
        out["asset_kind"] = "page_render"
        if page_mode:
            out["page"] = idx + 1
        return out
    if parent == "visual_excel_sheets":
        out["asset_kind"] = "sheet_render"
        return out

    # 出所も名前も分からない資産。視覚ルートでは頁画像である公算が高いので
    # 通し番号を頁の代わりに使う（順序が保てるだけでも突き合わせの役に立つ）。
    #
    # v3.27.9 注意：ここを「視覚ルートなら何でも page_render」にしていたのが
    # 直前の不具合。視覚ルートの資産が頁画像だけだった頃は正しかったが、
    # v3.27.3 で図版用の埋込画像を意図的に足したので前提が崩れていた。
    # 判定を足すときは、この分岐に落ちる前に拾うこと。
    if page_mode:
        out["page"] = idx + 1
        out["asset_kind"] = "page_render"
    return out


def _document_meta(state: Dict[str, Any]) -> Dict[str, Any]:
    """ファイル自体から確定的に取れるメタ情報を集める。

    LLM に推測させず「事実」として渡すための物。case_name が
    「資料内で確認できず」になる事故の大半は、そもそもファイル名も
    見出しも prompt に入っていなかったことが原因だった。
    """
    src = Path(state.get("input_path", "") or "")
    meta: Dict[str, Any] = {
        "file_name": src.name,
        "file_stem": src.stem,          # 拡張子を除いた名前＝人が付けた題名であることが多い
        "file_type": src.suffix.lstrip(".").lower(),
    }
    # 本文の最初の見出しを文書タイトル候補として拾う
    title = ""
    md = state.get("markdown_path")
    if md:
        try:
            for line in Path(md).read_text(encoding="utf-8", errors="ignore").split("\n")[:200]:
                if line.startswith("#"):
                    cand = line.lstrip("#").strip()
                    # 「ページ 1」等の機械的見出しはタイトルではない
                    if cand and not re.match(r"^(ページ|スライド|シート|page|slide|sheet)\s*\d+$",
                                             cand, re.I):
                        title = cand
                        break
        except Exception:  # noqa: BLE001
            pass
    meta["document_title"] = title
    chunks = state.get("chunks") or []
    pages = [c.get("page") for c in chunks if c.get("page")]
    if pages:
        meta["page_range"] = [min(pages), max(pages)]
    if state.get("excel_info"):
        # excel_extract の info["sheets"] は**枚数（int）**。シート名の一覧は
        # 別経路（COM / workbook_to_markdown）でしか取れないので型で分岐する。
        sheets = (state["excel_info"] or {}).get("sheets")
        if isinstance(sheets, int) and sheets > 0:
            meta["sheet_count"] = sheets
        elif isinstance(sheets, (list, tuple)) and sheets:
            meta["sheet_names"] = [str(x) for x in sheets][:30]
    meta["route"] = state.get("route", "")
    return meta


def _render_sheet_pdfs(sheet_meta: List[Dict[str, Any]], out_dir: Path,
                       scale: float = 2.0, max_pages: int = 40) -> List[str]:
    """excel_sheet_pdfs が出した 1 シート 1 PDF を、ページ画像へ展開する。

    ファイル名に `sheet_{index}_{name}_p{page}.png` の形でシート名と頁を埋める
    ——後段の `_asset_provenance` がここから溯源を復元する。
    """
    from .parsing import render_pdf_pages

    out_dir.mkdir(parents=True, exist_ok=True)
    produced: List[str] = []
    for meta in sheet_meta:
        if meta.get("skipped") or not meta.get("pdf_path"):
            continue
        if len(produced) >= max_pages:
            break
        try:
            res = render_pdf_pages(meta["pdf_path"], str(out_dir / "_tmp"),
                                   max_pages=max(1, max_pages - len(produced)), scale=scale)
        except Exception:  # noqa: BLE001 1 シート失敗しても他は続ける
            continue
        pages = res.get("visual_asset_paths", []) if isinstance(res, dict) else (res or [])
        safe = str(meta.get("name", "sheet")).replace(" ", "_")[:40]
        for i, src in enumerate(pages):
            dst = out_dir / f"sheet_{int(meta.get('index', 0)):02d}_{safe}_p{i + 1:03d}.png"
            try:
                shutil.move(str(src), str(dst))
                produced.append(str(dst))
            except Exception:  # noqa: BLE001
                continue
    return produced


def _lenient_summary(raw: dict, model) -> Any:
    """尽力解析（模板无关）：坏字段回落契约默认值。"""
    try:
        return model.model_validate(raw)
    except ValidationError:
        pass
    cleaned: Dict[str, Any] = {}
    for field in model.model_fields:
        if field not in raw:
            continue
        try:
            model.__pydantic_validator__.validate_assignment(model(), field, raw[field])
            cleaned[field] = raw[field]
        except ValidationError:
            continue
    try:
        return model.model_validate(cleaned)
    except ValidationError:
        return model()
