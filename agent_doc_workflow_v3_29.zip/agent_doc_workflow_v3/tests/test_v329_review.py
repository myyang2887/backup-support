"""v3.29：図版配置のデータ化、確認・編集画面、案件ごとの出力、社外版の表示スイッチ。

いちばん守りたいのは回帰：v3.28 までは修正タブで 1 文字でも直して保存すると、
テンプレートで描き直すだけだったので**差し込んだ図が全部消えていた**。
"""
from __future__ import annotations

import json
import os
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.figure_select import (apply_figure_plan, attach_figures_to_run,  # noqa: E402
                               find_field_path, load_plan, save_plan)


def _png(path: Path, size=(640, 480)) -> Path:
    from PIL import Image
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.frombytes("RGB", size, os.urandom(size[0] * size[1] * 3)).save(path)
    return path


def _spec(run_dir):
    import app.webapp as W
    return W._spec_of_run(run_dir)


@pytest.fixture()
def run(tmp_path):
    from app.contract import CaseSummary
    from app.render import render_markdown

    rd = tmp_path / "out" / "runs" / "case1"
    rd.mkdir(parents=True)
    s = CaseSummary()
    s.case_name = "断面 SPM 観察"
    s.action_results.findings = ["弾性率は 0.4〜1.0 GPa の範囲で分布した",
                                 "約 0.7 GPa 付近にピークを持つ"]
    s.action_results.effects = ["希望納期より 22 日早く完了した"]
    (rd / "case_summary.json").write_text(json.dumps(s.model_dump(mode="json"), ensure_ascii=False),
                                          encoding="utf-8")
    render_markdown(s, str(_spec(rd).md_template_path), str(rd / "case_summary.md"))
    a = _png(rd / "visual_office" / "office_p004_image8.png")
    b = _png(rd / "visual_office" / "office_p006_image11.png")
    _png(rd / "visual_office" / "office_image99.png", (300, 150))
    _png(rd / "visual_pages" / "page_001.png")
    (rd / "evidence_visual.json").write_text(json.dumps({"evidence": [
        {"evidence_id": "visual_asset_0002", "image_path": str(a), "asset_kind": "embedded",
         "page": 4, "visual_type": "chart", "visual_summary": "弾性率分布のマップ",
         "figure_title": "断面の弾性率分布", "figure_caption": "0.4〜1.0 GPa の分布",
         "key_facts": ["弾性率 0.4〜1.0 GPa"], "readable_text": ["GPa", "0.4", "1.0"],
         "figure_worthiness": "core", "confidence": 0.8, "has_useful_visual_info": True},
        {"evidence_id": "visual_asset_0001", "image_path": str(rd / "visual_pages" / "page_001.png"),
         "asset_kind": "page_render", "page": 1, "visual_summary": "表紙", "key_facts": []},
    ]}, ensure_ascii=False), encoding="utf-8")
    (rd / "figure_candidates.json").write_text(json.dumps({"candidates": [
        {"path": str(a), "tier": "keep", "score": 0.7, "page": 4, "unit_label": "p.4",
         "reasons": ["図題あり"], "decor_reasons": [], "parts": {"size": 0.8}},
        {"path": str(b), "tier": "scored", "score": 0.4, "page": 6, "unit_label": "p.6",
         "reasons": [], "decor_reasons": [], "parts": {"size": 0.5}},
        {"path": str(rd / "visual_office" / "office_image99.png"), "tier": "drop", "score": 0.0,
         "reasons": [], "decor_reasons": ["3 枚のスライドで繰り返し使用（ロゴ等）"]},
    ]}, ensure_ascii=False), encoding="utf-8")
    (rd / "evidence_text.json").write_text(json.dumps({"evidence": [
        {"evidence_id": "ref_01", "content": "参照台帳「満足度」：5", "category": "other"},
        {"evidence_id": "ev_001", "content": "AFM で弾性率を測定", "category": "finding", "page": 2},
    ]}, ensure_ascii=False), encoding="utf-8")
    return rd


def _summary(rd):
    return json.loads((rd / "case_summary.json").read_text(encoding="utf-8"))


def _plan(*items):
    return {"version": 1, "source": "user", "items": list(items)}


def _it(fid, image, idx, caption="図題", field="action_results.findings", text=None):
    a = {"field": field, "index": idx}
    if text is not None:
        a["text"] = text
    return {"id": fid, "image": image, "anchor": a, "caption": caption, "label": "p.4"}


# ======================================================================
# 図版配置の適用（描画の唯一の経路）
# ======================================================================

def test_plan_places_and_numbers_in_document_order(run):
    md = (run / "case_summary.md").read_text(encoding="utf-8")
    plan = _plan(_it("x", "visual_office/office_p006_image11.png", 1, "ピーク"),
                 _it("y", "visual_office/office_p004_image8.png", 0, "分布"))
    out, rep = apply_figure_plan(md, plan, run, _summary(run))
    assert rep["placed"] == 2 and not rep["missing"]
    assert out.index("0.4〜1.0 GPa の範囲で分布した（図1）") < out.index("![図1　分布（p.4）]")
    assert out.index("ピークを持つ（図2）") < out.index("![図2　ピーク（p.4）]")
    assert (run / "figures" / "fig01.png").exists() and (run / "figures" / "fig02.png").exists()


def test_two_figures_on_one_item(run):
    md = (run / "case_summary.md").read_text(encoding="utf-8")
    plan = _plan(_it("a", "visual_office/office_p004_image8.png", 0),
                 _it("b", "visual_office/office_p006_image11.png", 0))
    out, _ = apply_figure_plan(md, plan, run, _summary(run))
    assert "範囲で分布した（図1・図2）" in out


def test_missing_image_is_reported_not_fatal(run):
    md = (run / "case_summary.md").read_text(encoding="utf-8")
    out, rep = apply_figure_plan(md, _plan(_it("a", "visual_office/nope.png", 0)), run, _summary(run))
    assert rep["placed"] == 0 and rep["missing"][0]["why"] == "画像ファイルがありません"
    assert "![" not in out


def test_rerun_relocates_by_text_when_items_move(run):
    """再実行で要約が作り直されても、同じ本文の項目を探して付け直す。"""
    s = _summary(run)
    s["action_results"]["findings"] = ["新しく先頭に入った項目です", *s["action_results"]["findings"]]
    md = "## 調査・対応により判明した事実\n\n" + "\n".join(f"- {x}" for x in s["action_results"]["findings"])
    plan = _plan(_it("a", "visual_office/office_p004_image8.png", 1,
                     text="約 0.7 GPa 付近にピークを持つ"))
    out, rep = apply_figure_plan(md, plan, run, s, trust_index=False)
    assert rep["placed"] == 1 and "ピークを持つ（図1）" in out


def test_find_field_path_ignores_figure_suffix(run):
    assert find_field_path(_summary(run), "約 0.7 GPa 付近にピークを持つ（図2）") == \
        ("action_results.findings", 1)


# ======================================================================
# 回帰：修正して保存しても図が消えない
# ======================================================================

def test_rerender_after_edit_keeps_figures(run):
    import app.review as R
    from app.contract import CaseSummary
    save_plan(run, _plan(_it("a", "visual_office/office_p004_image8.png", 0, "分布")))
    s = _summary(run)
    s["action_results"]["findings"][0] = "弾性率は 0.4〜1.0 GPa に分布（修正済み）"
    md, rep = R.rerender(run, CaseSummary.model_validate(s), _spec(run), trust_index=True)
    assert rep["placed"] == 1
    assert "（修正済み）（図1）" in md and "![図1　分布（p.4）](figures/fig01.png)" in md


# ======================================================================
# パイプライン：自動選定の結果を配置データとして残し、利用者の配置は上書きしない
# ======================================================================

def test_auto_selection_is_saved_as_plan(run):
    ve = json.loads((run / "evidence_visual.json").read_text(encoding="utf-8"))["evidence"]
    res = attach_figures_to_run(run, tier="internal", visual_evidence=ve, text_evidence=[])
    plan = load_plan(run)
    assert res["figures"] >= 1 and plan["source"] == "auto"
    assert plan["items"][0]["anchor"]["field"] == "action_results.findings"
    assert plan["items"][0]["caption"] == "断面の弾性率分布"


def test_user_plan_survives_pipeline_rerun(run):
    save_plan(run, _plan(_it("u1", "visual_office/office_p006_image11.png", 1, "手で選んだ図",
                             text="約 0.7 GPa 付近にピークを持つ")))
    res = attach_figures_to_run(run, tier="internal", visual_evidence=[], text_evidence=[])
    md = (run / "case_summary.md").read_text(encoding="utf-8")
    assert res["figures"] == 1 and "手で選んだ図" in md
    assert load_plan(run)["source"] == "user"


def test_snapshots_include_plan_and_review_state():
    from app.versions import _SNAPSHOT_FILES
    assert "figure_plan.json" in _SNAPSHOT_FILES and "review_state.json" in _SNAPSHOT_FILES


# ======================================================================
# 確認画面の後端
# ======================================================================

@pytest.fixture()
def client(run, monkeypatch):
    import app.webapp as W
    from fastapi.testclient import TestClient
    monkeypatch.setattr(W.config.paths, "out_dir", str(run.parents[1]))
    monkeypatch.setattr(W, "_find_run", lambda rid: {"run_id": rid})
    monkeypatch.setattr(W, "_resolve_run_dir", lambda r: run)
    return TestClient(W.app)


def test_bundle_has_everything_the_screen_needs(client, run):
    b = client.get("/api/runs/case1/review").json()
    fields = [s["field"] for s in b["sections"] if s["kind"] == "list"]
    assert "action_results.findings" in fields and "action_results.effects" in fields
    labels = {s["field"]: s["label"] for s in b["sections"] if s["field"]}
    assert labels["action_results.findings"] == "調査・対応により判明した事実"
    st = {i["key"]: i["status"] for i in b["images"]}
    assert st["office_image99"] == "excluded" and st["office_p006_image11"] == "candidate"
    logo = next(i for i in b["images"] if i["key"] == "office_image99")
    assert "繰り返し" in logo["layout"]["decor_reasons"][0]
    chart = next(i for i in b["images"] if i["key"] == "office_p004_image8")
    assert chart["analyzed"] and chart["vlm"]["figure_title"] == "断面の弾性率分布"
    assert chart["match"]["best"] > 0 and "bullet" in chart["match"]
    assert b["evidence"]["ledger"][0]["evidence_id"] == "ref_01"
    assert b["pages"][0]["label"] == "p.1"
    assert b["version"] and b["reviewed"] is False


@pytest.mark.parametrize("bad", ["../case_summary.json", "visual_office/../../x.png",
                                 "case_summary.json", "/etc/passwd", "visual_office/nope.png"])
def test_asset_endpoint_refuses_anything_outside_image_dirs(client, bad):
    assert client.get("/api/runs/case1/asset", params={"p": bad}).status_code == 404


def test_asset_endpoint_serves_images(client):
    r = client.get("/api/runs/case1/asset", params={"p": "visual_office/office_p004_image8.png"})
    assert r.status_code == 200 and r.headers["content-type"] == "image/png"


def test_save_checks_version_then_renders_with_figures(client, run):
    b = client.get("/api/runs/case1/review").json()
    s = b["summary"]
    s["action_results"]["effects"].append("後工程の着手を前倒しできた")
    plan = [_it("u1", "visual_office/office_p006_image11.png", 1, "ピーク位置")]
    assert client.post("/api/runs/case1/review",
                       json={"summary": s, "plan": plan, "version": "stale"}).status_code == 409
    (run / "case_summary_external.md").write_text("# 社外", encoding="utf-8")
    r = client.post("/api/runs/case1/review", json={"summary": s, "plan": plan, "version": b["version"]})
    body = r.json()
    assert r.status_code == 200 and body["figures"] == 1 and body["external_stale"] is True
    md = (run / "case_summary.md").read_text(encoding="utf-8")
    assert "後工程の着手を前倒しできた" in md and "![図1　ピーク位置" in md
    assert load_plan(run)["source"] == "user"
    assert any((run / "versions").iterdir())                  # 保存前の版が残る
    assert body["version"] != b["version"]


def test_save_rejects_plan_pointing_outside_the_run(client, run):
    b = client.get("/api/runs/case1/review").json()
    plan = [_it("x", "../../secret.png", 0)]
    r = client.post("/api/runs/case1/review", json={"summary": b["summary"], "plan": plan,
                                                     "version": b["version"]})
    assert r.status_code == 200 and load_plan(run)["items"] == []


def test_invalid_summary_is_422(client):
    b = client.get("/api/runs/case1/review").json()
    r = client.post("/api/runs/case1/review", json={"summary": {"action_results": "壊れた"},
                                                     "plan": [], "version": b["version"]})
    assert r.status_code == 422


def test_reviewed_flag(client, run):
    r = client.post("/api/runs/case1/reviewed", json={"reviewed": True}).json()
    assert r["reviewed"] is True and r["reviewed_at"]
    assert client.get("/api/runs/case1/review").json()["reviewed"] is True


def test_edit_tab_no_longer_wipes_figures(client, run):
    """v3.28 までの不具合：修正タブで保存すると図が全部消えていた。"""
    save_plan(run, _plan(_it("a", "visual_office/office_p004_image8.png", 0, "分布")))
    s = _summary(run)
    s["action_results"]["findings"][1] = "ピーク位置を修正した"
    r = client.post("/api/runs/case1/summary", json=s)
    assert r.status_code == 200
    assert "![図1　分布" in r.json()["markdown"]


def test_review_page_is_served(client):
    r = client.get("/review/case1")
    assert r.status_code == 200 and "確認・編集" in r.text


# ======================================================================
# 案件ごとの出力（ZIP）
# ======================================================================

def test_separate_export_zip(tmp_path, monkeypatch):
    import app.webapp as W
    from app.export_doc import DocSection
    monkeypatch.setattr(W.config.paths, "out_dir", str(tmp_path / "out"))
    secs = [DocSection(title="断面観察", markdown="# 断面観察\n\n- a\n"),
            DocSection(title="断面観察", markdown="# 断面観察\n\n- b\n"),
            DocSection(title="流路/改善:試験", markdown="# x\n\n- c\n")]
    resp = W._export_separate(secs, "docx", "batch_個別.zip")
    with zipfile.ZipFile(resp.path) as zf:
        names = zf.namelist()
        csv_text = zf.read("一覧.csv").decode("utf-8-sig")
    docs = sorted(n for n in names if n.endswith(".docx"))
    assert len(docs) == 3 and docs[0].startswith("001_") and docs[2].startswith("003_")
    assert len(set(docs)) == 3                               # 同名でも衝突しない
    assert not any(c in "".join(docs) for c in ':*?"<>|')     # Windows で使えない文字を除く
    assert "断面観察" in csv_text and "出力ファイル" in csv_text


# ======================================================================
# 画面の切り替え
# ======================================================================

def test_new_switches_exist_with_expected_defaults():
    from app.config import DEFAULT_UI_FEATURES
    assert DEFAULT_UI_FEATURES["external_tier"] is False
    assert DEFAULT_UI_FEATURES["review_editor"] is True
    assert DEFAULT_UI_FEATURES["review_modal"] is False


def test_main_page_hides_external_tier_and_opens_review_both_ways():
    html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
    assert "if (!FEATURES.external_tier) { FEATURES.tier_switch = false; FEATURES.dictionary_card = false; }" in html
    assert 'feat("external_tier") ? `\n      <button class="ghost" onclick="batchExport' in html
    assert 'data-feature="external_tier"' in html               # RAG 社外
    assert "function openReview" in html and 'feat("review_modal")' in html
    assert "?embed=1" in html or 'q.set("embed", "1")' in html
    assert "案件ごとに分ける（ZIP）" in html and "確認済みのみ" in html


def test_review_page_has_the_expected_interactions():
    html = (Path(__file__).resolve().parents[1] / "static" / "review.html").read_text(encoding="utf-8")
    for needle in ('addEventListener("wheel"', "pointermove", "dblclick", "lb-one", "lb-open",
                   "dragstart", "review-close", "review-draft:", "onbeforeunload", '"s"'):
        assert needle in html, needle
    assert "external_tier" in html                              # 社外版の注意もスイッチに従う
