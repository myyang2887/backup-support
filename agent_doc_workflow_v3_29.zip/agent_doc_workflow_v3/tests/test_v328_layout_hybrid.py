"""v3.28：図版候補の位置索引・粗選別、融合ルート、出力から根拠情報を外す、画面の文言。

実ファイル（PPTX / DOCX / XLSX / PDF）をその場で作って通す。位置の取り方は
形式ごとにまるで違うので、合成データだけで試すと「実物では取れない」を
取り逃がす。

画像はノイズで作る（単色 PNG は数百バイトまで縮み、5120B の門で落ちてしまう）。
"""
from __future__ import annotations

import os
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.layout_index import (FigureCandidate, build_figure_candidates,  # noqa: E402
                              load_keywords, select_figure_candidates)


def _noise_png(path: Path, size=(800, 600)) -> Path:
    from PIL import Image
    path.parent.mkdir(parents=True, exist_ok=True)
    w, h = size
    Image.frombytes("RGB", size, os.urandom(w * h * 3)).save(path)
    return path


def _by_stem(cands, needle):
    return next(c for c in cands if needle in Path(c.path).name)


# ======================================================================
# PPTX
# ======================================================================

@pytest.fixture()
def deck(tmp_path):
    from pptx import Presentation
    from pptx.util import Emu, Inches

    main = _noise_png(tmp_path / "main.png", (900, 600))
    logo = _noise_png(tmp_path / "logo.png", (300, 150))
    toc = _noise_png(tmp_path / "toc.png", (700, 500))
    temp = _noise_png(tmp_path / "temp.png", (800, 600))

    prs = Presentation()
    layout = prs.slide_layouts[5]           # タイトルのみ

    def slide(title):
        s = prs.slides.add_slide(layout)
        s.shapes.title.text = title
        return s

    s1 = slide("解析結果")
    s1.shapes.add_picture(str(main), Inches(1.5), Inches(1.6), width=Inches(6.5))
    tb = s1.shapes.add_textbox(Inches(1.5), Inches(6.2), Inches(6.5), Inches(0.5))
    tb.text_frame.text = "図1 流路変更前後の圧力損失比較（12.5 kPa）"
    s1.notes_slide.notes_text_frame.text = "変更後は目標を下回った"

    for n in range(3):                      # 同じロゴを 3 枚のスライドの隅に
        s = slide(f"説明 {n + 1}")
        s.shapes.add_picture(str(logo), Inches(0.1), Inches(0.05), width=Inches(0.8))

    s5 = slide("目次")
    s5.shapes.add_picture(str(toc), Inches(2), Inches(2), width=Inches(4))

    s6 = slide("考察")
    s6.shapes.add_picture(str(temp), Inches(1), Inches(1.8), width=Inches(5))
    tb = s6.shapes.add_textbox(Inches(6.2), Inches(2.5), Inches(3), Inches(1))
    tb.text_frame.text = "温度分布を比較すると 45 ℃ 付近に偏りがある"

    out = tmp_path / "deck.pptx"
    prs.save(out)
    return out


def _extract(path, tmp_path):
    from app.parsing import extract_office_visuals
    res = extract_office_visuals(str(path), out_dir=str(tmp_path / "visual_office"),
                                 max_assets=500)
    return res["visual_asset_paths"]


def test_pptx_positions_captions_and_logos(deck, tmp_path):
    paths = _extract(deck, tmp_path)
    cands, n_units, meta = build_figure_candidates(str(deck), paths, load_keywords())
    assert meta["layout"] == "ok" and n_units == 6

    main = next(c for c in cands if c.page == 1)
    assert main.tier == "keep" and "図1" in main.caption      # 図題 → 必ず読む
    assert main.area_frac and main.area_frac > 0.2
    assert main.title_text == "解析結果"
    assert "圧力損失" in main.near_text

    logo = next(c for c in cands if c.ref_count >= 3)
    assert logo.tier == "drop"
    assert any("繰り返し" in r or "ヘッダー" in r for r in logo.decor_reasons)

    toc = next(c for c in cands if c.page == 5)
    assert any("目次" in r for r in toc.reasons)               # 目次の頁は減点
    temp = next(c for c in cands if c.page == 6)
    assert temp.score > toc.score


def test_pptx_selection_keeps_real_figures(deck, tmp_path):
    paths = _extract(deck, tmp_path)
    cands, n_units, _ = build_figure_candidates(str(deck), paths, load_keywords())
    selected, report = select_figure_candidates(cands, n_units)
    pages = {c.page for c in selected}
    assert 1 in pages and 6 in pages
    assert not any(c.ref_count >= 3 for c in selected)
    assert report["dropped"] >= 1 and report["keep"] >= 1


# ======================================================================
# DOCX
# ======================================================================

def test_docx_sections_and_header_logo(tmp_path):
    import docx
    from docx.shared import Inches

    fig = _noise_png(tmp_path / "fig.png")
    logo = _noise_png(tmp_path / "hdr.png", (400, 200))
    d = docx.Document()
    d.sections[0].header.paragraphs[0].add_run().add_picture(str(logo), width=Inches(1))
    d.add_heading("解析結果", level=1)
    d.add_paragraph("AFM による測定で弾性率の分布を得た。")
    d.add_picture(str(fig), width=Inches(5))
    d.add_paragraph("図1 断面の弾性率分布（0.4〜1.0 GPa）")
    path = tmp_path / "report.docx"
    d.save(path)

    cands, n_units, meta = build_figure_candidates(str(path), _extract(path, tmp_path),
                                                   load_keywords())
    assert meta["layout"] == "ok"
    header = [c for c in cands if any("ヘッダー" in r for r in c.decor_reasons)]
    body = [c for c in cands if c.unit_label.startswith("§")]
    assert header and header[0].tier == "drop"
    assert body and body[0].unit_label == "§解析結果"
    assert body[0].page is None              # Word の出現順を頁と誤認させない
    assert body[0].tier == "keep" and "図1" in body[0].caption


# ======================================================================
# XLSX（画像とシートの対応はここで初めて作られる）
# ======================================================================

def test_xlsx_images_are_mapped_to_sheets(tmp_path):
    import openpyxl
    from openpyxl.drawing.image import Image as XLImage

    a = _noise_png(tmp_path / "a.png")
    b = _noise_png(tmp_path / "b.png", (600, 400))
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "売上"
    ws["A1"] = "四半期別売上の比較"
    ws["A2"], ws["B2"] = "Q2", "18.4%"
    ws.add_image(XLImage(str(a)), "D2")
    ws2 = wb.create_sheet("メモ")
    ws2["A1"] = "連絡事項"
    ws2.add_image(XLImage(str(b)), "B3")
    path = tmp_path / "book.xlsx"
    wb.save(path)

    cands, n_units, _ = build_figure_candidates(str(path), _extract(path, tmp_path),
                                                load_keywords())
    assert n_units == 2
    sheets = {c.sheet_name for c in cands}
    assert sheets == {"売上", "メモ"}
    sales = next(c for c in cands if c.sheet_name == "売上")
    assert "比較" in sales.near_text and sales.unit_label == "シート「売上」"
    memo = next(c for c in cands if c.sheet_name == "メモ")
    assert sales.score > memo.score


# ======================================================================
# PDF（pypdfium2 の bbox と周辺文字）
# ======================================================================

def test_pdf_bbox_caption_and_repeated_logo(tmp_path):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    from reportlab.pdfgen import canvas

    pdfmetrics.registerFont(UnicodeCIDFont("HeiseiKakuGo-W5"))
    fig = _noise_png(tmp_path / "f.png")
    logo = _noise_png(tmp_path / "l.png", (300, 150))
    path = tmp_path / "doc.pdf"
    c = canvas.Canvas(str(path), pagesize=A4)
    W, H = A4
    for pno in range(3):
        c.drawImage(str(logo), W - 110, H - 50, width=90, height=40)   # 右上のロゴ
        c.setFont("HeiseiKakuGo-W5", 16)
        c.drawString(60, H - 90, "解析結果" if pno == 0 else f"補足 {pno}")
        if pno == 0:
            c.drawImage(str(fig), 80, 330, width=430, height=300)
            c.setFont("HeiseiKakuGo-W5", 11)
            c.drawString(80, 310, "図1 断面の弾性率分布 0.7 GPa 付近にピーク")
        c.showPage()
    c.save()

    from app.parsing import extract_pdf_visuals
    res = extract_pdf_visuals(str(path), out_dir=str(tmp_path / "visual_pdf"),
                              max_assets=500, render_fallback=False)
    cands, n_units, meta = build_figure_candidates(str(path), res["visual_asset_paths"],
                                                   load_keywords())
    assert meta["layout"] == "ok" and n_units == 3
    big = max(cands, key=lambda c: c.area_frac or 0)
    assert big.page == 1 and big.tier == "keep" and "図1" in big.caption
    logos = [c for c in cands if c is not big]
    assert logos and all(c.tier == "drop" for c in logos)


# ======================================================================
# 選別（枚数で打ち切らない）
# ======================================================================

def _cand(score, unit, tier="scored"):
    c = FigureCandidate(path=f"/x/{unit}_{score}.png", unit_key=unit, tier=tier)
    c.score = score
    return c


def test_elbow_cut_instead_of_fixed_count():
    cands = [_cand(s, f"p{i}") for i, s in enumerate([0.82, 0.78, 0.75, 0.71, 0.30, 0.28])]
    sel, rep = select_figure_candidates(cands, n_units=20, cfg={"coverage_floor": 0.99})
    assert [c.score for c in sel] == [0.82, 0.78, 0.75, 0.71]
    assert "急落" in rep["cut_reason"]


def test_smooth_scores_take_everything_above_floor():
    scores = [0.80, 0.74, 0.69, 0.63, 0.58, 0.52, 0.47, 0.41]
    cands = [_cand(s, f"p{i}") for i, s in enumerate(scores)]
    sel, rep = select_figure_candidates(cands, n_units=20)
    assert len(sel) == 8 and "急落なし" in rep["cut_reason"]


def test_captioned_figures_are_never_capped():
    keeps = [_cand(0.1, f"p{i}", tier="keep") for i in range(12)]
    sel, rep = select_figure_candidates(keeps, n_units=2)     # 予算 8 を超える
    assert len(sel) == 12


def test_budget_warns_instead_of_silently_dropping():
    cands = [_cand(0.9 - i * 0.01, f"p{i}") for i in range(30)]
    sel, rep = select_figure_candidates(cands, n_units=4)     # 予算 max(8, 6)=8
    assert len(sel) == 8 and rep["budget_trimmed"] == 22
    assert "予算" in rep["warning"]


def test_every_page_with_a_candidate_gets_a_representative():
    cands = [_cand(0.9, "p1"), _cand(0.85, "p1"), _cand(0.82, "p1"),
             _cand(0.40, "p1"), _cand(0.17, "p7")]
    sel, rep = select_figure_candidates(cands, n_units=10)
    assert any(c.unit_key == "p7" for c in sel)
    assert rep["coverage_added"] == 1


def test_keywords_file_extends_defaults(tmp_path):
    y = tmp_path / "kw.yaml"
    y.write_text("categories:\n  domain:\n    words: [独自装置X]\nnegative:\n  words: [社内限]\n",
                 encoding="utf-8")
    kw = load_keywords(y)
    assert "独自装置X" in kw["categories"]["domain"]["words"]
    assert "弾性率" in kw["categories"]["domain"]["words"]        # 既定は残る
    assert "社内限" in kw["negative"]["words"]


def test_project_keyword_file_loads():
    kw = load_keywords(Path(__file__).resolve().parents[1] / "config" / "figure_keywords.yaml")
    assert "結果" in kw["categories"]["result"]["words"]


# ======================================================================
# 融合ルートと原生テキスト
# ======================================================================

def test_hybrid_route_is_selectable():
    from types import SimpleNamespace

    from app.route_decision import decide_route
    route, reason, _ = decide_route("x.pptx", SimpleNamespace(input_mode="hybrid"))
    assert route == "hybrid" and "融合" in reason


def test_native_text_keeps_notes_and_slide_markers(deck):
    from app.native_text import extract_native_text
    text, how = extract_native_text(str(deck))
    assert how == "python-pptx"
    assert "## スライド 1：解析結果" in text
    assert "（ノート）変更後は目標を下回った" in text
    assert "図1 流路変更前後の圧力損失比較" in text


def test_native_text_never_raises(tmp_path):
    from app.native_text import extract_native_text
    bad = tmp_path / "broken.pptx"
    bad.write_bytes(b"not a zip")
    text, how = extract_native_text(str(bad))
    assert text == "" and how.startswith("失敗")


def test_all_pages_are_rendered_by_default(tmp_path):
    """40 頁で黙って止まっていた。全面レンダリングは情報を落とさないのが存在理由。"""
    from reportlab.pdfgen import canvas

    from app.config import AppConfig
    from app.parsing import render_pdf_pages
    assert AppConfig().workflow.vision_route_max_render_pages == 0
    path = tmp_path / "long.pdf"
    c = canvas.Canvas(str(path))
    for i in range(5):
        c.drawString(100, 700, f"page {i + 1}")
        c.showPage()
    c.save()
    res = render_pdf_pages(str(path), out_dir=str(tmp_path / "pages"), max_pages=0, scale=0.5)
    assert res["pages_rendered"] == 5


def test_prefilter_zero_means_unlimited(tmp_path):
    from app.parsing import prefilter_and_downscale_images
    paths = [str(_noise_png(tmp_path / f"i{i}.png", (300, 300))) for i in range(5)]
    res = prefilter_and_downscale_images(paths, work_dir=str(tmp_path / "f"), max_assets=0)
    assert len(res["kept"]) == 5


# ======================================================================
# 第二段：頁を先に読み、その結果で図版候補を選び、選んだ物だけ読む
# ======================================================================

class _Spy:
    def __init__(self):
        self.calls = []

    def chat_vision_json(self, image_path, system, user_text, **kw):
        self.calls.append({"image": Path(image_path).name, "system": system, "user": user_text})
        page = "ページ全体の読み取り" in system
        return {"has_useful_visual_info": True, "visual_type": "page" if page else "chart",
                "readable_text": ["解析結果", "12.5 kPa"], "visual_summary": "圧力損失の比較",
                "key_facts": ["変更後 12.5 kPa"], "possible_relevance": [],
                "figure_caption": "圧力損失の比較グラフ", "figure_title": "圧力損失比較",
                "figure_worthiness": "core", "confidence": 0.8}


def test_pages_first_then_selected_figures(tmp_path):
    from app.config import AppConfig
    from app.nodes import make_nodes

    run = tmp_path / "run"
    page = _noise_png(run / "visual_pages" / "page_001.png")
    fig = _noise_png(run / "visual_office" / "office_p001_image1.png")
    cand = FigureCandidate(path=str(fig), key="image1", unit_key="p1", unit_label="p.1",
                           page=1, title_text="解析結果", caption="図1 圧力損失の比較",
                           near_text="図1 圧力損失の比較（12.5 kPa）", tier="keep", score=0.6)
    spy = _Spy()
    nodes = make_nodes(AppConfig(), llm=None, vision_llm=spy)
    state = {"run_dir": str(run), "route": "hybrid", "visual_asset_paths": [str(page)],
             "figure_candidates": [cand.to_dict()], "figure_units": 1,
             "errors": [], "errors_visual": []}
    out = nodes["analyze_visual"](state)

    assert [c["image"] for c in spy.calls][0] == "page_001.png"       # 頁が先
    fig_call = next(c for c in spy.calls if c["image"].startswith("office_"))
    assert "ページ全体の読み取り" not in fig_call["system"]
    assert "図題" in fig_call["user"]                                  # 位置・周辺文が渡る
    ev = out.get("visual_evidence") or state["visual_evidence"]
    fig_ev = next(v for v in ev if v["asset_kind"] == "embedded")
    assert fig_ev["page"] == 1 and "図題" in fig_ev["figure_context"]
    assert (run / "figure_candidates.json").exists()


def test_figure_context_helps_matching(tmp_path):
    from app.figure_select import DEFAULTS, build_candidates, score_pair
    img = _noise_png(tmp_path / "visual_office" / "office_image1.png")
    base = {"evidence_id": "v1", "image_path": str(img), "asset_kind": "embedded",
            "visual_type": "chart", "visual_summary": "グラフ", "key_facts": ["値"],
            "readable_text": ["値"], "confidence": 0.8}
    plain = build_candidates([base], tmp_path, DEFAULTS)[0]
    ctx = build_candidates([dict(base, figure_context="周辺の文：弾性率の分布は 0.7 GPa 付近にピーク")],
                           tmp_path, DEFAULTS)[0]
    b = "弾性率の分布は 0.7 GPa 付近にピークを持つ"
    assert score_pair(b, ctx, None)[0] > score_pair(b, plain, None)[0]


# ======================================================================
# 出力から根拠情報を外す
# ======================================================================

MD = """# 案件

## 対応効果・メリット (Effects)

- 納期より 22 日早く完了した

---

# 根拠情報

- ref_01
- ref_02
"""


def test_evidence_section_is_removed_from_exports():
    from app.export_doc import prepare_for_export
    out = prepare_for_export(MD, include_evidence=False)
    assert "根拠情報" not in out and "ref_01" not in out
    assert "22 日早く" in out
    assert not out.rstrip().endswith("---")          # 区切り線も一緒に外す
    assert prepare_for_export(MD, include_evidence=True) == MD


def test_evidence_removed_only_until_next_same_level_heading():
    from app.export_doc import prepare_for_export
    md = "# A\n\n## 根拠情報\n\n- ref_01\n\n## 次の節\n\n- 残る\n"
    out = prepare_for_export(md, include_evidence=False)
    assert "ref_01" not in out and "次の節" in out and "残る" in out


def test_docx_export_has_no_evidence(tmp_path):
    import zipfile

    from app.export_doc import DocSection, export_docx
    out = export_docx([DocSection(title="案件", markdown=MD)], tmp_path / "r.docx")
    xml = zipfile.ZipFile(out).read("word/document.xml").decode("utf-8")
    assert "根拠情報" not in xml and "22 日早く" in xml


# ======================================================================
# 画面の文言
# ======================================================================

_SIMPLIFIED_ONLY = set("证视觉资产导换异败过这们么没对时间处务论认读写译识让说请话语误输边运进"
                       "还选错键长门问队阶际难题额验传优备复头实审层带开录总单变发结续级给统继"
                       "编网联节补装见规订设评试该详转轻较达远连递释针顺预领频风执创缓储页码图库辑")


def test_frontend_has_no_chinese_or_awkward_terms():
    html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
    for w in ("脱敏", "修訂", "視覚モデル直読", "走査", "清空", "保持率"):
        assert w not in html, w
    assert 'value="hybrid"' in html


def test_backend_ui_messages_are_japanese():
    root = Path(__file__).resolve().parents[1] / "app"
    src = (root / "nodes.py").read_text(encoding="utf-8") + (root / "webapp.py").read_text(encoding="utf-8")
    pat = r"(?:peek=f?\"|_push_error\([^,]+,\s*[^,]+,\s*f?\")([^\"\n]{2,120})"
    bad = [m.group(1) for m in re.finditer(pat, src)
           if any(ch in _SIMPLIFIED_ONLY for ch in m.group(1))]
    assert not bad, bad[:5]
    assert "（非致命）" not in src
