"""v3.27.11：対応効果の専用パスと、図注の二軌制。

## 対応効果
本文 prompt は 1 万字を超え、効果欄の指示は 3 か所に散って互いに矛盾していた。
弱いモデルは狭い課題なら守れる。広い課題の隅に置いた指示は守れない。
効果欄だけを、短い専用 prompt と関係する証拠だけで書き直す。

## 図注
figure_caption（説明文・要約モデル向け）をそのまま図注に使い、60 字で
ちょん切っていた。表示用には figure_title（体言止め・短い）を別に持つ。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class _SpyLLM:
    def __init__(self, reply):
        self.reply = reply
        self.calls = []

    def chat_json(self, system, user, **kw):
        self.calls.append({"system": system, "user": user, **kw})
        return self.reply


def _state_with_summary(tmp_path, effects, ledger_lines=(), findings=()):
    from app.contract import CaseSummary
    s = CaseSummary()
    s.action_results.effects = list(effects)
    s.action_results.findings = list(findings)
    ev = [{"evidence_id": f"ref_{i:02d}", "content": c, "category": "other", "confidence": 0.8}
          for i, c in enumerate(ledger_lines, 1)]
    return {"run_dir": str(tmp_path), "summary": s.model_dump(mode="json"),
            "aggregated_evidence": ev, "visual_evidence": [], "errors": []}


def _nodes(llm):
    from app.config import AppConfig
    from app.nodes import make_nodes
    return make_nodes(AppConfig(), llm=llm, vision_llm=None)


# ---- 専用パスの本体 ----

def test_pass_replaces_effects_with_focused_rewrite(tmp_path):
    llm = _SpyLLM({"effects": [
        "希望納期より 22 日早く完了し、後工程の着手を前倒しできた",
        "試作前に不具合を特定できた点が評価され、手戻り回避につながったと受け止められている",
    ]})
    st = _state_with_summary(tmp_path, ["満足度は 5"],
                             ledger_lines=["参照台帳（日数計算・コードによる確定値）：「完了日」から「希望納期」まで 22 日",
                                           "参照台帳「満足度」：5"])
    out = _nodes(llm)["refine_effects"](st)
    eff = out["summary"]["action_results"]["effects"]
    assert len(eff) == 2 and "22 日" in eff[0]
    assert out["effects_pass"] == {"before": 1, "after": 2, "replaced": True}


def test_pass_uses_its_own_short_prompt_and_only_relevant_evidence(tmp_path):
    """本文の証拠パックを丸ごと渡すと専用パスにした意味が無い。"""
    llm = _SpyLLM({"effects": ["x" * 20]})
    st = _state_with_summary(tmp_path, ["下書き"],
                             ledger_lines=["参照台帳「満足度」：5"])
    st["aggregated_evidence"].append(
        {"evidence_id": "ev_099", "content": "無関係な背景説明が延々と続く", "category": "background",
         "confidence": 0.9})
    _nodes(llm)["refine_effects"](st)
    call = llm.calls[0]
    assert "対応効果・メリット」欄だけを書く" in call["system"]
    assert len(call["system"]) < 1600
    assert "参照台帳「満足度」" in call["user"]
    assert "無関係な背景説明" not in call["user"]       # background は渡さない
    assert call["tag"] == "summary:effects"


def test_pass_keeps_draft_when_model_returns_nothing(tmp_path):
    llm = _SpyLLM({"effects": []})
    st = _state_with_summary(tmp_path, ["元の下書き項目"], ledger_lines=["参照台帳「満足度」：5"])
    out = _nodes(llm)["refine_effects"](st)
    assert out["summary"]["action_results"]["effects"] == ["元の下書き項目"]
    assert out["effects_pass"]["replaced"] is False


def test_pass_drops_unfilled_placeholders(tmp_path):
    """穴（〈N〉）を埋めずに写した項目は採らない。"""
    llm = _SpyLLM({"effects": ["希望納期より〈N〉日早く完了した", "有効な項目がここにあります"]})
    st = _state_with_summary(tmp_path, [], ledger_lines=["参照台帳「満足度」：5"])
    out = _nodes(llm)["refine_effects"](st)
    eff = out["summary"]["action_results"]["effects"]
    assert eff == ["有効な項目がここにあります"]


def test_pass_drops_placeholders_and_dedupes(tmp_path):
    llm = _SpyLLM({"effects": ["資料内で確認できず", "同じ内容の項目が並んでいます。",
                               "同じ内容の項目が並んでいます", "短い"]})
    st = _state_with_summary(tmp_path, [], ledger_lines=["参照台帳「満足度」：5"])
    out = _nodes(llm)["refine_effects"](st)
    assert out["summary"]["action_results"]["effects"] == ["同じ内容の項目が並んでいます"]


def test_pass_survives_llm_failure(tmp_path):
    class _Boom:
        def chat_json(self, *a, **k):
            raise RuntimeError("timeout")
    st = _state_with_summary(tmp_path, ["下書きは残る"], ledger_lines=["参照台帳「満足度」：5"])
    out = _nodes(_Boom())["refine_effects"](st)
    assert out["summary"]["action_results"]["effects"] == ["下書きは残る"]
    assert any("専用パスに失敗" in e.get("message", str(e)) for e in out["errors"])


def test_pass_can_be_disabled(tmp_path):
    from app.config import AppConfig
    from app.nodes import make_nodes
    cfg = AppConfig()
    cfg.workflow.effects_pass = False
    llm = _SpyLLM({"effects": ["書き換えられてはいけない"]})
    st = _state_with_summary(tmp_path, ["下書き"], ledger_lines=["参照台帳「満足度」：5"])
    out = make_nodes(cfg, llm=llm, vision_llm=None)["refine_effects"](st)
    assert out["summary"]["action_results"]["effects"] == ["下書き"]
    assert llm.calls == []


def test_pass_skips_templates_without_effects(tmp_path):
    llm = _SpyLLM({"effects": ["x" * 20]})
    st = {"run_dir": str(tmp_path), "summary": {"title": "t"}, "aggregated_evidence": [], "errors": []}
    _nodes(llm)["refine_effects"](st)
    assert llm.calls == []


def test_graph_routes_validated_summary_through_effects_pass():
    src = (Path(__file__).resolve().parents[1] / "app" / "graph.py").read_text(encoding="utf-8")
    assert '{"render": "refine_effects", "repair_summary": "repair_summary"}' in src
    assert 'graph.add_edge("refine_effects", "render")' in src


# ---- 図注の二軌制 ----

def test_display_caption_prefers_short_title():
    from app.figure_select import DEFAULTS, Candidate, Pick, Anchor, build_caption
    c = Candidate(evidence_id="v", image_path="x.png", display_path="x.png", page=4,
                  figure_caption="表面の凹凸または応力分布を示す、マイクロメートルスケールの断面の顕微鏡画像です。縦軸はμm単位",
                  figure_title="断面の弾性率分布（AFM）")
    p = Pick(anchor=Anchor(0, "t", "h"), cand=c, score=1, runner_up=0, breakdown={}, figure_no=1)
    assert build_caption(p, DEFAULTS) == "図1　断面の弾性率分布（AFM）（p.4）"


def test_display_caption_falls_back_to_caption_cut_at_a_break():
    from app.figure_select import DEFAULTS, Candidate, Pick, Anchor, build_caption
    c = Candidate(evidence_id="v", image_path="x.png", display_path="x.png", page=2,
                  figure_caption="横方向に走る縞模様状の構造を示す、マイクロメートルスケールの応力分布図。カラーバーは")
    p = Pick(anchor=Anchor(0, "t", "h"), cand=c, score=1, runner_up=0, breakdown={}, figure_no=2)
    cap = build_caption(p, DEFAULTS)
    assert cap == "図2　横方向に走る縞模様状の構造を示す（p.2）"
    assert "…" not in cap                     # 単語の途中で切っていない


def test_shortener_never_splits_a_decimal():
    from app.figure_select import _shorten_at_break
    out = _shorten_at_break("流路変更前後の圧力損失比較。変更後は 12.5 kPa まで低下", 28)
    assert out == "流路変更前後の圧力損失比較"
    out = _shorten_at_break("圧損 12.5 kPa、動力 18.4 % 削減、期間 28 日、コスト 120 万円の効果", 28)
    assert "12.5" in out and not out.endswith("12")


def test_long_caption_still_reaches_the_summarizer():
    """二軌制：表示は短く、要約モデルには長い説明を渡す。"""
    from app.contract import VisualEvidence
    from app.evidence import visual_to_pack
    v = VisualEvidence(evidence_id="visual_asset_0001", image_path="x.png",
                       figure_caption="流路変更前後の圧力損失を比較したグラフ。変更後は 12.5 kPa まで低下し、目標を下回った",
                       figure_title="流路変更前後の圧力損失比較", visual_summary="s", confidence=0.8,
                       has_useful_visual_info=True)
    pack = visual_to_pack([v])
    assert pack[0]["figure_caption"].startswith("流路変更前後の圧力損失を比較したグラフ。")


def test_vision_prompt_asks_for_both_tracks():
    src = (Path(__file__).resolve().parents[1] / "app" / "nodes.py").read_text(encoding="utf-8")
    i = src.index('VISION_SYSTEM = """'); v = src[i:src.index('"""', i + 20)]
    assert '"figure_title": "string"' in v
    assert "体言止め・20 字以内・句点なし" in v
