"""v3 新增功能的测试。运行: python -m pytest tests/ -v"""
import json
import sys
import time
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.config import AppConfig
from app.contract import UNKNOWN
from app.graph import run_workflow
from app.llm_client import LocalLLMClient
from app.parsing import prefilter_and_downscale_images, structural_chunks


# ----------------------------------------------------------------------
# 1. 结构感知切块
# ----------------------------------------------------------------------

def test_structural_chunks_split_by_headings():
    md = "# 章1\n" + "内容あ" * 100 + "\n## 章2\n" + "内容い" * 100 + "\n## 章3\n" + "内容う" * 100
    chunks = structural_chunks(md, chunk_chars=400, overlap=50, min_informative_chars=10)
    # 各章节应完整保留标题行（不被腰斩），小节按预算合并
    assert all(len(c) <= 400 + 50 for c in chunks)
    joined = "\n".join(chunks)
    assert "# 章1" in joined and "## 章2" in joined and "## 章3" in joined


def test_structural_chunks_merges_small_sections():
    md = "\n".join(f"## 節{i}\n短い内容です{i}" for i in range(10))
    chunks = structural_chunks(md, chunk_chars=6000, overlap=0, min_informative_chars=10)
    assert len(chunks) == 1  # 10 个小节合并成 1 个 chunk，10 次 LLM 调用变 1 次


def test_structural_chunks_drops_noise():
    md = "# タイトル\n実質的な内容がここにあります。装置Aの解析を実施。\n\n# \n- 3 -\n\n#  \n…"
    chunks = structural_chunks(md, chunk_chars=6000, overlap=0, min_informative_chars=15)
    # 页码/空节被信息量过滤器丢弃
    assert len(chunks) == 1
    assert "装置A" in chunks[0]


def test_structural_chunks_splits_oversized_with_overlap():
    md = "# 長大章\n" + "x" * 15000
    chunks = structural_chunks(md, chunk_chars=6000, overlap=500, min_informative_chars=10)
    assert len(chunks) >= 3
    assert chunks[0][-100:] in chunks[1]  # overlap 生效


# ----------------------------------------------------------------------
# 2. 图片预过滤 + 降采样
# ----------------------------------------------------------------------

def _make_png(path: Path, w: int, h: int, color=(200, 40, 40)):
    from PIL import Image
    Image.new("RGB", (w, h), color).save(path, "PNG")


def test_image_prefilter(tmp_path):
    big = tmp_path / "big.png"; _make_png(big, 2400, 1400)          # 需降采样
    normal = tmp_path / "normal.png"; _make_png(normal, 640, 480)   # 原样保留
    icon = tmp_path / "icon.png"; _make_png(icon, 32, 32)           # 太小，丢弃
    dup = tmp_path / "dup.png"; dup.write_bytes(normal.read_bytes())  # 重复，去重

    result = prefilter_and_downscale_images(
        [str(big), str(normal), str(icon), str(dup)],
        work_dir=str(tmp_path / "work"),
        min_edge_px=100, min_bytes=100, max_edge_px=1024, max_assets=10,
    )
    assert result["deduped"] == 1
    assert result["dropped"] == 1
    assert result["downscaled"] == 1
    assert len(result["kept"]) == 2

    from PIL import Image
    ds = [p for p in result["kept"] if p.endswith("_ds.jpg")]
    assert ds
    with Image.open(ds[0]) as im:
        assert max(im.size) <= 1024


# ----------------------------------------------------------------------
# 3. 缓存续跑 + 缺口回填（mock 端到端）
# ----------------------------------------------------------------------

class CountingMock:
    """按调用类型计数的 mock，验证缓存命中后 LLM 调用次数下降。"""

    def __init__(self, omit_period: bool = False):
        self.calls = {"extract": 0, "gap": 0, "vision": 0, "summary": 0, "redact": 0,
                      "effects": 0}
        self.omit_period = omit_period

    def __call__(self, system: str, user: str):
        if "文書整理エージェント" in system:
            if "重点的に探して" in user:
                self.calls["gap"] += 1
                return {"evidence": [
                    {"category": "period", "content": "2026年3月〜5月（補充抽出）", "confidence": 0.7},
                ]}
            self.calls["extract"] += 1
            evs = [
                {"category": "requester", "content": "光学設計部", "confidence": 0.9},
                {"category": "tool", "content": "FloEFD 2024", "confidence": 0.85},
                {"category": "effect", "content": "工数30%削減", "confidence": 0.8},
                {"category": "issue", "content": "解析リソース不足", "confidence": 0.8},
                {"category": "request_scope", "content": "流体解析の代行", "confidence": 0.8},
                {"category": "target", "content": "レンズユニット", "confidence": 0.8},
                {"category": "finding", "content": "特定条件で異常", "confidence": 0.8},
            ]
            if not self.omit_period:
                evs.append({"category": "period", "content": "2026年1月", "confidence": 0.8})
            return {"evidence": evs}
        if "視覚" in system:
            self.calls["vision"] += 1
            return {"has_useful_visual_info": False, "visual_type": "unknown",
                    "readable_text": [], "visual_summary": "", "key_facts": [],
                    "possible_relevance": [], "confidence": 0.0}
        # v3.27.11：対応効果の専用パス。本文要約とは別に数える
        if "対応効果・メリット」欄だけを書く" in system:
            self.calls["effects"] += 1
            return {"effects": []}
        if "匿名化エージェント" in system:
            self.calls["redact"] += 1
            import json as _json
            return _json.loads(user)  # 原样返回（已是规则脱敏后的 JSON）
        self.calls["summary"] += 1
        return {
            "case_name": "光学解析支援",
            "request_details": {
                "requester": "光学設計部", "target_product_or_system": "レンズユニット",
                "background": ["歩留まり低下"], "client_issues": ["解析リソース不足"],
                "scope_of_request": ["流体解析の代行"],
            },
            "action_results": {
                "support_type": "解析代行", "tools_environment": ["FloEFD 2024"],
                "period": "2026年1月", "findings": ["特定条件で異常"], "effects": ["工数30%削減"],
            },
            "evidence": ["text_chunk_0001_ev_001"],
        }


def _setup(tmp_path: Path, mock: CountingMock):
    doc = tmp_path / "case.md"
    doc.write_text("# 光学解析支援\n\n"
        "光学設計部より、レンズユニットの流体解析代行の依頼を受けた。"
        "背景として試作段階での歩留まり低下があり、原因が特定できていなかった。"
        "使用ツールは FloEFD 2024。対応期間は2026年1月。"
        "解析の結果、特定条件で異常が判明し、解析工数を30%削減する効果が得られた。\n",
                   encoding="utf-8")
    config = AppConfig()
    config.paths.out_dir = str(tmp_path / "out")
    config.llm.mock = True
    llm = LocalLLMClient(base_url="", api_key="", mock=True, mock_handler=mock)
    return doc, config, llm


def test_resume_cache_skips_llm_calls(tmp_path):
    mock = CountingMock()
    doc, config, llm = _setup(tmp_path, mock)
    # このテストが見たいのは「キャッシュが効いて再抽出しないこと」。
    # v3.9 の加筆（expand_summary）は 1 項目 = LLM 1 回で summary バケットに
    # 入るため、有効なままだと呼び出し回数の等式が加筆件数に依存してしまう。
    # 加筆自体は test_v39_features.py 側で検証する。
    config.workflow.expand_summary = False

    run_workflow(str(doc), config, llm)
    first_extract = mock.calls["extract"]
    assert first_extract >= 1

    # 第二次跑同一文件：解析/证据提取/视觉分析全部走缓存
    run_workflow(str(doc), config, llm)
    assert mock.calls["extract"] == first_extract, "缓存命中时不应再调用证据提取"
    # 摘要不缓存（人可能改模板/契约后重跑），仍会调用
    assert mock.calls["summary"] == 2


def test_resume_disabled_recomputes(tmp_path):
    mock = CountingMock()
    doc, config, llm = _setup(tmp_path, mock)
    config.workflow.resume = False
    run_workflow(str(doc), config, llm)
    n1 = mock.calls["extract"]
    run_workflow(str(doc), config, llm)
    assert mock.calls["extract"] == n1 * 2


def test_gap_fill_recovers_missing_category(tmp_path):
    mock = CountingMock(omit_period=True)  # 常规提取拿不到 period
    doc, config, llm = _setup(tmp_path, mock)
    final = run_workflow(str(doc), config, llm)

    assert mock.calls["gap"] == 1, "period 缺失时应触发一次缺口回填"
    cats = {d["category"] for d in final["aggregated_evidence"]}
    assert "period" in cats, "回填的 period 证据应进入聚合结果"


def test_gap_fill_skips_when_complete(tmp_path):
    mock = CountingMock(omit_period=False)
    doc, config, llm = _setup(tmp_path, mock)
    run_workflow(str(doc), config, llm)
    assert mock.calls["gap"] == 0, "证据齐全时不应浪费回填调用"


# ----------------------------------------------------------------------
# 4. Web 新端点（evidence / HITL 修订 / chat）
# ----------------------------------------------------------------------

@pytest.fixture()
def web_client(tmp_path, monkeypatch):
    import app.webapp as W
    from fastapi.testclient import TestClient
    monkeypatch.setattr(W.config.llm, "mock", True)
    monkeypatch.setattr(W.config.paths, "out_dir", str(tmp_path / "out"))
    monkeypatch.setattr(W.config.paths, "inbox_dir", str(tmp_path / "inbox"))
    W._runs.clear()
    return TestClient(W.app)


def _upload_and_wait(client) -> str:
    r = client.post("/api/runs", files={"files": (
        "web_case.md",
        ("# 光学解析支援\n光学設計部より、レンズユニットの流体解析代行の依頼を受けた。"
         "背景として試作段階での歩留まり低下があり、原因が特定できていなかった。"
         "使用ツールは FloEFD 2024。対応期間は2026年1月。"
         "解析の結果、特定条件で異常が判明し、解析工数を30%削減する効果が得られた。").encode("utf-8"),
        "text/markdown")})
    run_id = r.json()["run_id"]
    for _ in range(80):
        st = client.get(f"/api/runs/{run_id}").json()["state"]
        if st in ("done", "failed"):
            break
        time.sleep(0.25)
    assert st == "done"
    return run_id


def test_web_evidence_endpoint(web_client):
    run_id = _upload_and_wait(web_client)
    r = web_client.get(f"/api/runs/{run_id}/evidence")
    assert r.status_code == 200
    body = r.json()
    assert isinstance(body["text"], list) and len(body["text"]) >= 1
    assert {"category", "content", "confidence"} <= set(body["text"][0].keys())


def test_web_hitl_edit_revalidates_and_rerenders(web_client):
    run_id = _upload_and_wait(web_client)
    summary = web_client.get(f"/api/runs/{run_id}/summary").json()

    # 合法编辑 -> 保存并重渲染
    summary["action_results"]["effects"] = ["人手で修正した効果：工数50%削減"]
    r = web_client.post(f"/api/runs/{run_id}/summary", json=summary)
    assert r.status_code == 200
    assert "工数50%削減" in r.json()["markdown"]
    md = web_client.get(f"/api/runs/{run_id}/markdown_text").json()["markdown"]
    assert "工数50%削減" in md

    # 非法编辑（结构破坏）-> 422 拒绝，磁盘不落坏数据
    bad = dict(summary); bad["request_details"] = "壊れた文字列"
    r = web_client.post(f"/api/runs/{run_id}/summary", json=bad)
    assert r.status_code == 422
    md2 = web_client.get(f"/api/runs/{run_id}/markdown_text").json()["markdown"]
    assert "工数50%削減" in md2  # 上一次合法版本仍在


def test_web_chat_endpoint(web_client):
    run_id = _upload_and_wait(web_client)
    r = web_client.post(f"/api/runs/{run_id}/chat",
                        json={"messages": [{"role": "user", "content": "効果は？"}]})
    assert r.status_code == 200
    assert r.json()["reply"]

    r = web_client.post(f"/api/runs/{run_id}/chat", json={"messages": []})
    assert r.status_code == 400


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
