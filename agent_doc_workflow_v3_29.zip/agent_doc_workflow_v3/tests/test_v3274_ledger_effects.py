"""v3.27.4：対応効果に「コスト削減」「期間短縮」を出すための下ごしらえ。

方針：**計算できるものはコードが保証し、できないものだけモデルに回す。**
常にモデルへ投げると、確実に出せた答えまで確率的になる。
意味付け（どの差が所要期間か）はモデルの仕事なので、コードは
生の表頭のまま差だけ並べる（v3.15 の「列の意味を表で決めない」を維持）。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.nodes import _looks_like_vague_date, _reference_date_evidence  # noqa: E402
from app.reference_index import ReferenceRow  # noqa: E402


def _row(cells):
    return ReferenceRow(source_file="台帳.xlsx", sheet_name="依頼一覧",
                        row_number=12, cells=list(cells))


def _contents(evs):
    return "\n".join(e.content for e in evs)


# ---- 計算できる日付 ----

def test_day_difference_is_computed_in_code():
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("希望納期", "2023/06/30"),
              ("完了日", "2023/06/02"), ("依頼部門", "製造技術部")]),
        conf=0.8, src="台帳.xlsx#依頼一覧:12", tag="")
    text = _contents(evs)
    assert "「依頼日」から「完了日」まで 53 日" in text
    assert "「完了日」から「希望納期」まで 28 日" in text
    assert "2023-04-10" in text            # 正規化した日付も並べる
    assert "製造技術部" not in text        # 日付でない列は触らない


def test_pair_is_ordered_earliest_first():
    """列の並び順ではなく時系列で「から/まで」を決める。"""
    evs = _reference_date_evidence(
        _row([("完了日", "2023/06/02"), ("依頼日", "2023/04/10")]),
        conf=0.8, src="s", tag="")
    assert "「依頼日」から「完了日」まで 53 日" in _contents(evs)


def test_months_are_included_for_readability():
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/01/10"), ("完了日", "2023/06/02")]),
        conf=0.8, src="s", tag="")
    assert "ヶ月" in _contents(evs)


def test_far_apart_dates_are_not_paired():
    """保管期限のような無関係な日付と組ませない。"""
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("完了日", "2023/06/02"),
              ("保管期限", "2043/04/10")]),
        conf=0.8, src="s", tag="")
    text = _contents(evs)
    assert "「依頼日」から「完了日」まで 53 日" in text
    assert "保管期限」まで" not in text


def test_single_date_produces_nothing():
    assert _reference_date_evidence(_row([("依頼日", "2023/04/10")]), 0.8, "s", "") == []


def test_no_dates_produces_nothing():
    assert _reference_date_evidence(_row([("依頼部門", "製造技術部")]), 0.8, "s", "") == []


# ---- 計算できない日付はモデルに回す ----

def test_vague_dates_are_flagged_not_dropped():
    """曖昧な記述を黙って落とすと、モデルは「日付の記載が無い」と読んで
    期間に触れなくなる。計算不可であることを明示的に伝える。"""
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("完了日", "2023/06/02"),
              ("希望納期", "6月末までに")]),
        conf=0.8, src="s", tag="")
    text = _contents(evs)
    assert "日付が曖昧で計算不可" in text and "希望納期" in text
    assert "概算" in text
    # 解析できた 2 つは通常どおり計算される
    assert "53 日" in text


def test_all_vague_still_reports():
    evs = _reference_date_evidence(
        _row([("依頼日", "来月中旬"), ("完了日", "6月末")]), 0.8, "s", "")
    text = _contents(evs)
    assert "日付が曖昧で計算不可" in text
    assert "日数計算" not in text          # 計算できないものを計算したふりをしない


def test_vague_detector_scope():
    for s in ("6月末", "来月中旬", "Q2中", "至急", "未定", "8月上旬頃"):
        assert _looks_like_vague_date(s), s
    for s in ("2023/06/02", "製造技術部", "", "A" * 60):
        assert not _looks_like_vague_date(s), s


def test_pair_count_is_capped():
    """日付列が多い台帳で証拠パックを食い潰さない。"""
    cells = [(f"日付{i}", f"2023/01/{i + 1:02d}") for i in range(12)]
    evs = _reference_date_evidence(_row(cells), 0.8, "s", "")
    diffs = [e for e in evs if "日数計算" in e.content]
    assert len(diffs) <= 10


def test_unconfirmed_tag_is_carried():
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("完了日", "2023/06/02")]),
        0.8, "s", "【要確認】")
    assert all(e.content.startswith("【要確認】") for e in evs)


# ---- プロンプト側 ----

def test_prompt_states_the_two_effects_and_bans_recomputation():
    src = (Path(__file__).resolve().parents[1] / "app" / "nodes.py").read_text(encoding="utf-8")
    e = _effects_prompt()
    assert "費用" in e and "時間" in e
    # 計算済みの値を モデルが引き直すと、保証していたはずの数字が崩れる
    assert "計算し直さない" in src
    assert "証拠に無い数字・固有名詞・評価を作らない" in e


# ---- v3.27.7：period と effects の書き分け ----

def test_prompt_separates_period_from_effects():
    """実測：モデルは「依頼から完了まで 28 日。希望納期より 22 日早く完了した」を
    まるごと period に入れ、effects を空にした。プロンプトの例文が
    その並びのままだったのが誘因なので、配置を明示する。"""
    src = (Path(__file__).resolve().parents[1] / "app" / "nodes.py").read_text(encoding="utf-8")
    assert "period と effects の書き分け" in src
    assert "period に書いてあっても effects にも書く" in src
    # 悪い例を悪い例として示していること（良い例のつもりで並べない）
    bat = src.index("してはいけない書き方")
    good = src.index("正しい配置")
    assert bat < good


def test_notice_when_effects_omit_the_period():
    from types import SimpleNamespace

    from app.nodes import _effects_missing_period
    ev = [{"content": "参照台帳（日数計算・コードによる確定値）：「依頼日」から「完了日」まで 28 日"}]
    s = SimpleNamespace(action_results=SimpleNamespace(
        effects=["満足度は 5 段階中 5 と非常に高い"]))
    assert "期間短縮の項目がありません" in _effects_missing_period(s, ev)


def test_no_notice_when_effects_mention_the_period():
    from types import SimpleNamespace

    from app.nodes import _effects_missing_period
    ev = [{"content": "参照台帳（日数計算・コードによる確定値）：28 日"}]
    for text in ("希望納期より 22 日早く完了した", "期間を短縮できた",
                 "納期に対し前倒しで完了"):
        s = SimpleNamespace(action_results=SimpleNamespace(effects=[text]))
        assert _effects_missing_period(s, ev) is None, text


def test_no_notice_without_date_evidence():
    """日数の証拠が無ければ、effects に期間が無いのは当たり前。騒がない。"""
    from types import SimpleNamespace

    from app.nodes import _effects_missing_period
    s = SimpleNamespace(action_results=SimpleNamespace(effects=["満足度 5"]))
    assert _effects_missing_period(s, [{"content": "参照台帳「依頼部門」：製造技術部"}]) is None


def test_notice_does_not_rewrite_the_summary():
    """報せるだけで直さない。機械が本文を書き換えると出所が分からなくなる。"""
    from types import SimpleNamespace

    from app.nodes import _effects_missing_period
    effects = ["満足度は 5"]
    s = SimpleNamespace(action_results=SimpleNamespace(effects=effects))
    _effects_missing_period(s, [{"content": "日数計算：28 日"}])
    assert effects == ["満足度は 5"]


# ---- v3.27.8：effects の観点と言い回しの多様性 ----

def _prompt() -> str:
    return (Path(__file__).resolve().parents[1] / "app" / "nodes.py").read_text(encoding="utf-8")


def _effects_prompt() -> str:
    """v3.27.11：効果欄の方針は EFFECTS_SYSTEM に一本化された。"""
    src = _prompt()
    i = src.index('EFFECTS_SYSTEM = """')
    return src[i:src.index('"""', i + 20)]


def test_effects_prompt_has_two_directions():
    e = _effects_prompt()
    assert "方向 A：この案件そのもので達成したこと" in e
    assert "方向 B：台帳とアンケートから分かる、時間・費用・評価" in e


def test_each_direction_has_several_examples():
    """1 観点 1 例だと、その 1 文がそのまま量産される。"""
    e = _effects_prompt()
    a = e[e.index("方向 A"):e.index("方向 B")]
    b = e[e.index("方向 B"):e.index("共通の禁止事項")]
    assert a.count("\n  ・") >= 3
    assert b.count("・") >= 6          # 時間・費用・評価で各 2 以上


def test_examples_use_placeholders_not_real_numbers():
    """具体的な数字を見本に書くと、証拠が無いときそれを答えとして写す。
    穴（〈N〉）なら写しても即座に検出できる。"""
    e = _effects_prompt()
    assert "〈N〉" in e and "〈X〉" in e
    import re
    for m in re.finditer(r"^\s+・.*$", e, re.M):
        line = m.group(0)
        if "❌" in line or "✅" in line:
            continue
        assert not re.search(r"\d{2,}\s*(万円|日|%)", line), f"例文に具体値: {line.strip()}"


def test_effects_prompt_warns_against_monotony():
    e = _effects_prompt()
    assert "項目ごとに動詞と構文を変える" in e
    assert "「〜が確認された」「〜に活用された」で全項目を終えない" in e


def test_negative_feedback_is_not_filtered_out():
    """低い評価を省くと、効果欄が宣伝文になる。"""
    assert "低い評価や指摘事項も、あれば省かない" in _effects_prompt()


def test_score_parroting_is_shown_as_bad_example():
    """instructions.md にあった「復唱するな」と、旧 system prompt の例文
    （復唱している）が矛盾していた。一本化後は悪い例として明示。"""
    e = _effects_prompt()
    assert "❌ 満足度は 5 段階中 5" in e
    assert "点数を復唱しない" in e


def test_main_prompt_no_longer_carries_effects_examples():
    """3 か所分散の解消：本文 prompt からは例文を抜き、専用パスへ寄せる。"""
    src = _prompt()
    i = src.index('SUMMARY_SYSTEM = f"""')
    main = src[i:src.index('"""', i + 22)]
    assert "仕上げは後段の専用パスが行う" in main
    assert "コスト・工数の削減" not in main
    assert len(main) < 1800, f"本文 prompt が再び太っている: {len(main)}"


def test_instructions_file_is_a_pointer_now():
    md = (Path(__file__).resolve().parents[1] / "templates" / "case_summary_instructions.md"
          ).read_text(encoding="utf-8")
    assert "refine_effects" in md
    assert "アンケート回答の書き方" not in md      # 効果の細則は残さない
    assert "■ その他の項目" in md                 # 無関係な段落は消していない


# ---- 例文の数値が答えとして漏れていないか ----

def test_placeholder_leak_is_detected():
    """穴（〈N〉）を埋めずに写した出力を捕まえる。
    VISION_SYSTEM の "confidence": 0.0 と同じ事故を、出力側でも見張る。"""
    from types import SimpleNamespace

    from app.nodes import _example_number_leak
    s = SimpleNamespace(action_results=SimpleNamespace(
        effects=["希望納期より〈N〉日早く完了した"]))
    msg = _example_number_leak(s, [{"content": "参照台帳「依頼部門」：製造技術部"}])
    assert msg and "〈" in msg


def test_example_phrase_leak_is_detected():
    from types import SimpleNamespace

    from app.nodes import _example_number_leak
    s = SimpleNamespace(action_results=SimpleNamespace(
        effects=["外注を見込んでいた解析を内製化し、委託費の発生を回避した"]))
    msg = _example_number_leak(s, [{"content": "参照台帳「依頼部門」：製造技術部"}])
    assert msg and "委託費" in msg


def test_same_phrase_is_fine_when_evidence_has_it():
    from types import SimpleNamespace

    from app.nodes import _example_number_leak
    s = SimpleNamespace(action_results=SimpleNamespace(
        effects=["委託費 80 万円の発生を回避した"]))
    ev = [{"content": "参照台帳「自由記述」：委託費80万円が不要になった"}]
    assert _example_number_leak(s, ev) is None


def test_leak_detector_tokens_exist_in_the_prompt():
    """例文を書き換えたのに検出語を直し忘れると、番人が何も見張らなくなる。"""
    from app.nodes import _PROMPT_EXAMPLE_FIGURES
    e = _effects_prompt()
    present = [tok for tok in _PROMPT_EXAMPLE_FIGURES if tok in e]
    assert len(present) >= 4, present


def test_leak_detector_ignores_empty_effects():
    from types import SimpleNamespace

    from app.nodes import _example_number_leak
    s = SimpleNamespace(action_results=SimpleNamespace(effects=[]))
    assert _example_number_leak(s, []) is None
