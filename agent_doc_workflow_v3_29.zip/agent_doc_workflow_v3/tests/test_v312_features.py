"""v3.12 の 7 項目に対するテスト。

1. 一括処理の中止（次が自動で始まらないこと）
2. 一括処理でも精読モードを指定できること
3. 証拠が無い項目を推定で埋める／推定は加筆しないこと
4. デバッグ情報にファイル名・頁が出ること
5. ページ描画の解像度
6. 画像が密集した頁の圧縮
7. 埋め込み画像への本文文脈の付与
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


# ======================================================================
# 1 & 2. 一括処理：中止と精読モード
# ======================================================================

@pytest.fixture()
def batch_dir(tmp_path):
    from app import batch as B

    items = [{"name": f"f{i}.md", "rel": f"f{i}.md", "path": f"/x/f{i}.md",
              "run_id": f"r{i}", "state": "queued"} for i in range(5)]
    rec = B.create_batch(tmp_path, "/x", items, template_id="case",
                         input_mode="auto", deep_read=True)
    return tmp_path, rec


def test_batch_records_deep_read(batch_dir):
    """UI は以前から送っていたのに API が読み捨てていた（＝実質選べなかった）。"""
    _, rec = batch_dir
    assert rec["deep_read"] is True


def test_batch_cancel_sets_flag_workers_check(batch_dir):
    """中止フラグはディスクに残り、ワーカーが実行直前に読める。

    これが無いと、1 件止めるたびに空いた枠へ次が入って走り出すため
    事実上バッチを止められない。
    """
    from app import batch as B

    out_dir, rec = batch_dir
    bid = rec["batch_id"]
    assert B.is_cancelled(out_dir, bid) is False

    res = B.cancel_batch(out_dir, bid)
    assert res["ok"] is True
    assert B.is_cancelled(out_dir, bid) is True


def test_batch_cancel_does_not_rewind_finished(batch_dir):
    """完了済みの run は巻き戻さない。"""
    from app import batch as B

    out_dir, rec = batch_dir
    bid = rec["batch_id"]
    B.set_item_state(out_dir, bid, "r0", "done")
    B.set_item_state(out_dir, bid, "r1", "failed")
    B.cancel_batch(out_dir, bid)

    after = B.load_batch(out_dir, bid)
    states = {i["run_id"]: i["state"] for i in after["items"]}
    assert states["r0"] == "done"
    assert states["r1"] == "failed"
    assert states["r2"] == states["r3"] == states["r4"] == "cancelled"


def test_batch_summary_exposes_cancel_and_deep_read(batch_dir):
    from app import batch as B

    out_dir, rec = batch_dir
    B.cancel_batch(out_dir, rec["batch_id"])
    summ = B.summarize(B.load_batch(out_dir, rec["batch_id"]), {})
    assert summ["cancelled"] is True
    assert summ["deep_read"] is True
    assert summ["cancelled_count"] == 5


def test_batch_cancel_endpoint_exists():
    import inspect

    import app.webapp as W

    src = inspect.getsource(W)
    assert '@app.post("/api/batches/{batch_id}/cancel")' in src
    # ワーカーは枠を取った直後にフラグを見る（LLM を呼ぶ前）
    assert "B.is_cancelled(_out_dir(), batch_id)" in src


# ======================================================================
# 3. 証拠が無い項目の推定
# ======================================================================

def test_inferred_note_detected():
    from app.contract import INFERRED_NOTE, is_inferred

    assert is_inferred([f"改善が見込まれる{INFERRED_NOTE}"]) is True
    assert is_inferred(["圧損は 12.3 kPa 低減した"]) is False
    assert is_inferred(None) is False


def test_count_inferred_walks_nested_summary():
    from app.contract import INFERRED_NOTE
    from app.nodes import _count_inferred

    summary = {
        "case_name": "A 社案件",
        "detail": {"merit": [f"効果が期待される{INFERRED_NOTE}"],
                   "finding": ["圧損 12.3 kPa"]},
        "note": f"背景は限定的{INFERRED_NOTE}",
    }
    assert _count_inferred(summary) == 2


def test_summary_prompt_forbids_inventing_specifics():
    """推定を許すこととでっち上げを許すことは違う。

    定性的な推定は認めるが、数値・日付・固有名詞の新規生成は明示的に禁じる。
    ここが緩むとシステムの根幹（証拠主義）が崩れる。
    """
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert "_MISSING_RULE" in src
    assert "数値・日付・企業名・製品名・ツール名を新しく作ってはいけない" in src
    assert "手掛かりが全く無い項目に限り" in src
    # 従来動作にも戻せること
    assert "if wf.infer_when_missing else" in src


def test_inferred_fields_are_not_expanded():
    """推定をさらに膨らませるのは二重の作話になる。"""
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert "elif is_inferred(val):" in src


def test_infer_toggle_defaults_on_but_reversible():
    from app.config import load_config

    wf = load_config().workflow
    assert isinstance(wf.infer_when_missing, bool)


# ======================================================================
# 4. デバッグ情報の具体性
# ======================================================================

def test_prefilter_reports_reason_per_file(tmp_path):
    """件数だけでは「どの図が落ちたか」が分からず現物に辿り着けない。"""
    from PIL import Image

    from app.parsing import prefilter_and_downscale_images

    tiny = tmp_path / "office_p002_image9.png"
    Image.new("RGB", (10, 10), "red").save(tiny)          # 最小サイズ未満
    big = tmp_path / "office_p003_image1.png"
    Image.new("RGB", (600, 400), "blue").save(big)
    dup = tmp_path / "office_p004_image1.png"
    dup.write_bytes(big.read_bytes())                      # 完全な重複

    res = prefilter_and_downscale_images(
        [str(tiny), str(big), str(dup)], work_dir=str(tmp_path / "w"),
        min_edge_px=100, min_bytes=100, max_edge_px=1024, max_assets=30)

    detail = res["dropped_detail"]
    names = {d["name"]: d["reason"] for d in detail}
    assert "office_p002_image9.png" in names
    assert "office_p004_image1.png" in names
    # 重複は「どれと同じか」まで書く
    assert "office_p003_image1.png" in names["office_p004_image1.png"]
    # 実ファイルに辿り着けるようフルパスも持つ
    assert all("path" in d for d in detail)


def test_analyze_visual_error_includes_filename_and_page():
    """「視覚資産 15 分析失敗」では現物に辿り着けない。"""
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert "def _label(idx: int) -> str:" in src
    assert "画像 {_label(idx)}" in src      # v3.28 文言：視覚資産 → 画像


# ======================================================================
# 5. ページ描画の解像度
# ======================================================================

def test_page_render_edge_raised_to_avoid_jpeg_reencode():
    """16:9 スライドは scale 2.0 で 1920px。上限 1536 だと縮小＋JPEG 再圧縮。

    2048 なら 1920px がそのまま通るので PNG のまま無劣化で VLM に届く。
    """
    from app.config import load_config

    wf = load_config().workflow
    assert wf.vision_route_page_max_edge_px >= 1920, \
        "16:9 スライド（scale 2.0 で 1920px）が縮小・再エンコードされてしまう"


# ======================================================================
# 6. 画像が密集した頁の圧縮
# ======================================================================

class _WF:
    dense_page_threshold = 6
    contact_sheet_enabled = True
    contact_sheet_cols = 3
    contact_sheet_max_edge_px = 2048
    contact_sheet_max_cells = 12


def _mk(dirpath: Path, name: str) -> str:
    from PIL import Image

    p = dirpath / name
    Image.new("RGB", (400, 300), "steelblue").save(p)
    return str(p)


def test_dense_page_becomes_contact_sheet(tmp_path):
    """頁画像が無い密集頁は 1 枚に束ねる → VLM 呼び出し N 回が 1 回に。"""
    from app.nodes import _compress_dense_pages

    imgs = [_mk(tmp_path, f"office_p003_image{i + 1}.png") for i in range(10)]
    out, rep = _compress_dense_pages(imgs, str(tmp_path / "run"), _WF())

    assert rep["before"] == 10
    assert rep["after"] == 1
    assert rep["pages"][0]["action"] == "contact_sheet"
    assert any("contact_" in o for o in out)


def test_dense_page_prefers_existing_page_render(tmp_path):
    """頁画像が有るなら合成は無駄。頁画像の方が文脈を持っている。"""
    from app.nodes import _compress_dense_pages

    imgs = [_mk(tmp_path, f"office_p003_image{i + 1}.png") for i in range(10)]
    imgs.append(_mk(tmp_path, "pdf_p003_page.png"))
    out, rep = _compress_dense_pages(imgs, str(tmp_path / "run"), _WF())

    assert rep["pages"][0]["action"] == "dropped_for_page_render"
    assert not any("contact_" in o for o in out)
    assert any("pdf_p003_page" in o for o in out)


def test_sparse_page_untouched(tmp_path):
    from app.nodes import _compress_dense_pages

    imgs = [_mk(tmp_path, f"office_p009_image{i + 1}.png") for i in range(3)]
    out, rep = _compress_dense_pages(imgs, str(tmp_path / "run"), _WF())
    assert out == imgs
    assert rep["pages"] == []


def test_contact_sheet_splits_without_losing_images(tmp_path):
    """max_cells を超えても切り捨てず次のシートへ回す。"""
    from app.parsing import make_contact_sheets

    imgs = [_mk(tmp_path, f"img{i}.png") for i in range(10)]
    sheets = make_contact_sheets(imgs, str(tmp_path / "cs"), page=3,
                                 cols=3, max_edge_px=2048, max_cells=4)
    assert len(sheets) == 3
    assert sum(s["count"] for s in sheets) == 10


def test_contact_sheet_prompt_is_separate():
    """合成画像に頁用/単図用のプロンプトを使い回さない。

    「装飾なら false」も「これは資料の N ページ目」も合成画像には当てはまらない。
    """
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert "SHEET_SYSTEM" in src
    assert "セル番号を頭に付けて" in src
    # 合成画像は中身が複数なので頁と同じトークン枠を与える
    assert "page_mode or sheet_members" in src


# ======================================================================
# 7. 埋め込み画像への本文文脈
# ======================================================================

def test_page_text_index_from_markdown(tmp_path):
    from app.parsing import build_page_text_index

    md = tmp_path / "doc.md"
    md.write_text("# ページ 1\n最初の頁。\n\n# ページ 3\n三頁目：圧損は 12.3 kPa。\n",
                  encoding="utf-8")
    idx = build_page_text_index(str(md), per_page_chars=500)
    assert 1 in idx and 3 in idx
    assert "12.3" in idx[3]


def test_page_text_index_survives_missing_file():
    """本文が無くても視覚分析は続行できなければならない。"""
    from app.parsing import build_page_text_index

    assert build_page_text_index("/nonexistent/none.md") == {}


def test_context_built_from_markdown_not_chunks():
    """chunks は使えない：本文チェーンと並行なので出来ている保証が無い。

    両分岐の上流にある Markdown を直接読むこと。
    """
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert "build_page_text_index(state[\"markdown_path\"]" in src
    assert "def _ctx_for(img: str) -> str:" in src


def test_context_warns_model_not_to_borrow_from_text():
    """本文はあくまで参考。画像に無いことを本文から補わせない。"""
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert "画像に写っていないことを本文から補って" in src
