@echo off
rem FLOEFD automation - Week 3: export the structure of the open FLOEFD project (read-only).
rem Open a COPY of the model in FLOEFD first, then double-click this file.
rem Options are passed through, e.g.:
rem   run_export.bat --results
rem   run_export.bat --project "Case A" --results
rem   run_export.bat --no-getters --no-cad          (quick run)
setlocal
cd /d "%~dp0"
set PY=python
where python >nul 2>nul
if errorlevel 1 set PY=py
%PY% "%~dp0efd_export.py" %*
echo.
echo Exit code: %ERRORLEVEL%   (0 ok, 1 some failures, 2 timeout, 3 environment, 4 connect failed, 5 no document open)
echo Open the newest export_* folder and read summary.md first.
pause
