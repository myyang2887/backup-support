"""Shared plumbing for the FLOEFD automation scripts (week 3 onward).

Contents
  Recorder     log file, per-call records, failure list, method statistics
  Watchdog     one background thread that ends the process if a COM call hangs
  EnumBook     enum value <-> name lookup (this machine's type library first,
               the bundled API reference as fallback)
  connect()    launcher ProgID discovery + attach / start FLOEFD
  helpers      COM error decoding, JSON-safe conversion, [out]-parameter unpacking

Later weeks build the FLOEFD adapter on top of this module, so every COM call
in every script goes through Recorder.invoke() and is logged the same way.
"""

from __future__ import annotations

import datetime as _dt
import glob
import json
import os
import re
import sys
import threading
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
KIT_ROOT = os.path.dirname(HERE)

PRODUCT_NAMES = {"0": "Standalone", "2": "CATIA V5", "3": "Creo", "4": "NX", "5": "Solid Edge"}
PROGID_RE = re.compile(r"^EFDApiSrv\.EFDLauncher\.(\d+)\.(\d+)$")

# HRESULTs meaning "this object has no such member" -> the getter does not apply here.
_NOT_APPLICABLE_HR = {0x80020006, 0x80020003, 0x80004001}

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass


# --------------------------------------------------------------------------- errors and values

def hresult_of(exc: BaseException):
    args = getattr(exc, "args", ())
    if type(exc).__name__ == "com_error" and args and isinstance(args[0], int):
        return args[0] & 0xFFFFFFFF
    return None


def describe_error(exc: BaseException) -> dict:
    """COM error -> readable fields (HRESULT in hex, source, description)."""
    info: dict = {"type": type(exc).__name__, "summary": str(exc)}
    args = getattr(exc, "args", ())
    if type(exc).__name__ == "com_error" and len(args) >= 2:
        hr = hresult_of(exc)
        info["hresult"] = f"0x{hr:08X}" if hr is not None else str(args[0])
        info["message"] = args[1]
        if len(args) >= 3 and args[2]:
            ex = args[2]
            try:
                info["source"], info["description"] = ex[1], ex[2]
                if len(ex) > 5 and isinstance(ex[5], int):
                    info["scode"] = f"0x{ex[5] & 0xFFFFFFFF:08X}"
            except Exception:  # noqa: BLE001
                info["excepinfo"] = str(ex)
        info["summary"] = " | ".join(str(info[k]) for k in ("hresult", "message", "description") if info.get(k))
    return info


def is_not_applicable(exc: BaseException) -> bool:
    if isinstance(exc, AttributeError):
        return True
    hr = hresult_of(exc)
    return hr in _NOT_APPLICABLE_HR


def is_com_object(v) -> bool:
    return hasattr(v, "_oleobj_") or type(v).__name__ in ("PyIDispatch", "PyIUnknown")


def jsonable(v, depth: int = 0, max_items: int = 500, max_depth: int = 6):
    """Converts COM results into JSON-safe values (tuples -> lists, COM objects -> marker)."""
    if v is None or isinstance(v, (bool, int, str)):
        return v
    if isinstance(v, float):
        return v if v == v and v not in (float("inf"), float("-inf")) else str(v)
    if is_com_object(v):
        return "<COM object>"
    if isinstance(v, (list, tuple)):
        if depth > max_depth:
            return f"<nested {len(v)} items>"
        items = [jsonable(x, depth + 1, max_items, max_depth) for x in list(v)[:max_items]]
        if len(v) > max_items:
            items.append(f"... {len(v) - max_items} more")
        return items
    if isinstance(v, dict):
        return {str(k): jsonable(x, depth + 1, max_items, max_depth) for k, x in v.items()}
    if isinstance(v, (bytes, bytearray)):
        return v.hex()
    return str(v)


def as_list(v) -> list:
    """COM arrays arrive as tuples; a single object or None becomes a list."""
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return list(v)
    return [v]


def split_ret_outs(result, n_outs: int, has_retval: bool):
    """Splits a pywin32 result into (retval, [outs]).

    pywin32 returns (retval, out1, out2, ...) for methods with [out] parameters,
    or (out1, out2, ...) when there is no [out, retval]. A plain value means the
    binding returned only the retval.
    """
    if isinstance(result, tuple):
        if has_retval and len(result) == n_outs + 1:
            return result[0], list(result[1:])
        if not has_retval and len(result) == n_outs:
            return None, list(result)
        if n_outs == 1 and len(result) == 2:
            return result[0], [result[1]]
    if has_retval:
        return result, []
    return None, [result] if n_outs == 1 else as_list(result)


def out_value(result):
    """Value of a getter with one [out] value and a VARIANT_BOOL success retval.

    Returns (value, success_flag). Tuples are (retval, value) in pywin32; a plain
    non-bool result is taken as the value itself (some bindings drop the retval).
    """
    if isinstance(result, tuple):
        if len(result) >= 2:
            return result[-1], result[0]
        return (result[0], None) if result else (None, None)
    if isinstance(result, bool):
        return None, result
    return result, None


def short(v, limit: int = 160) -> str:
    s = json.dumps(jsonable(v), ensure_ascii=False)
    return s if len(s) <= limit else s[:limit] + "..."


# --------------------------------------------------------------------------- recorder and watchdog

class Watchdog:
    """One daemon thread checks a deadline; a hung COM call ends the process.

    A blocked COM call cannot be interrupted from Python. On timeout the
    on_timeout callback writes what has been collected so far, then the
    process exits with code 2.
    """

    def __init__(self, on_timeout):
        self._on_timeout = on_timeout
        self._deadline = None
        self._label = None
        self._lock = threading.Lock()
        t = threading.Thread(target=self._run, daemon=True)
        t.start()

    def arm(self, label: str, seconds: float) -> None:
        with self._lock:
            self._label, self._deadline = label, time.monotonic() + seconds

    def disarm(self) -> None:
        with self._lock:
            self._label, self._deadline = None, None

    def _run(self) -> None:
        while True:
            time.sleep(0.5)
            with self._lock:
                hit = self._deadline is not None and time.monotonic() > self._deadline
                label = self._label
            if hit:
                try:
                    self._on_timeout(label)
                finally:
                    os._exit(2)


class Recorder:
    """Log, call statistics and failure list for one script run."""

    def __init__(self, out_dir: str, tool: str, version: str, default_timeout: float = 120):
        self.out_dir = out_dir
        os.makedirs(out_dir, exist_ok=True)
        self._log = open(os.path.join(out_dir, "run.log"), "a", encoding="utf-8")
        self.default_timeout = default_timeout
        self.failures: list[dict] = []
        self.stats: dict[str, dict] = {}
        self.report: dict = {"tool": tool, "tool_version": version,
                             "started": _dt.datetime.now().isoformat(timespec="seconds"), "status": "running"}
        self.timeout_writer = None  # set by the script: writes partial outputs on timeout
        self.watchdog = Watchdog(self._timed_out)
        self._lock = threading.Lock()

    # ---- logging
    def log(self, msg: str) -> None:
        line = f"[{_dt.datetime.now():%H:%M:%S}] {msg}"
        with self._lock:
            print(line, flush=True)
            self._log.write(line + "\n")
            self._log.flush()

    def _timed_out(self, label: str) -> None:
        self.log(f"TIMEOUT: {label} did not return in time. FLOEFD may be showing a dialog. "
                 f"Partial results are written; the process now exits.")
        self.report["timed_out_call"] = label
        self.failures.append({"call": label, "error": {"summary": "timeout"}})
        if self.timeout_writer:
            try:
                self.timeout_writer("timeout")
            except Exception as exc:  # noqa: BLE001
                self.log(f"Could not write partial results: {exc}")

    def _stat(self, method: str, outcome: str) -> None:
        s = self.stats.setdefault(method, {"ok": 0, "failed": 0, "not_applicable": 0})
        s[outcome] += 1

    # ---- calls
    def invoke(self, label: str, obj, method: str, *args, timeout: float | None = None,
               quiet: bool = False, optional: bool = False):
        """Calls obj.method(*args) through COM. Returns (ok, value); never raises.

        optional=True: "no such member" is counted as not applicable, not as a failure.
        Works with early and late binding (a late-bound property is read once, not called twice).
        """
        t0 = time.time()
        self.watchdog.arm(label, timeout or self.default_timeout)
        try:
            attr = getattr(obj, method)
            if callable(attr) and not is_com_object(attr):
                value = attr(*args)
            elif args:
                raise TypeError(f"{method} behaved like a property but arguments were given")
            else:
                value = attr
            ok, err = True, None
        except Exception as exc:  # noqa: BLE001 - failures are data here
            value, ok, err = exc, False, exc
        finally:
            self.watchdog.disarm()
        dt = round(time.time() - t0, 3)
        if ok:
            self._stat(method, "ok")
            if not quiet:
                self.log(f"OK   {label} -> {short(value)}  [{dt}s]")
            return True, value
        if optional and is_not_applicable(err):
            self._stat(method, "not_applicable")
            return False, None
        self._stat(method, "failed")
        info = describe_error(err)
        self.failures.append({"call": label, "method": method, "args": jsonable(list(args)), "error": info,
                              "seconds": dt})
        if not quiet:
            self.log(f"FAIL {label} -> {info.get('summary')}  [{dt}s]")
        return False, None

    def value(self, label: str, obj, method: str, *args, default=None, **kw):
        ok, v = self.invoke(label, obj, method, *args, **kw)
        return v if ok else default

    # ---- output
    def write_json(self, name: str, data) -> str:
        path = os.path.join(self.out_dir, name)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(jsonable(data, max_items=100000, max_depth=60), f, ensure_ascii=False, indent=1)
        return path

    def finish_report(self, status: str) -> None:
        self.report["status"] = status
        self.report["finished"] = _dt.datetime.now().isoformat(timespec="seconds")
        self.report["failures"] = self.failures
        self.report["method_stats"] = dict(sorted(self.stats.items()))
        self.write_json("run_report.json", self.report)


# --------------------------------------------------------------------------- enums

class EnumBook:
    """Enum lookup. Values are only unique inside one enum, so lookups name the enum."""

    def __init__(self, sources: list[tuple[str, dict]]):
        self.enums: dict[str, dict[str, int]] = {}
        self.sources = [s for s, _ in sources]
        for _, enums in sources:            # first source wins
            for en, values in enums.items():
                self.enums.setdefault(en, dict(values))
        self._rev = {en: {} for en in self.enums}
        for en, values in self.enums.items():
            for name, v in values.items():
                self._rev[en].setdefault(v, []).append(name)

    @classmethod
    def load(cls, typelib_dump: str | None = None) -> "EnumBook":
        sources = []
        if typelib_dump and os.path.isfile(typelib_dump):
            with open(typelib_dump, encoding="utf-8") as f:
                dumps = json.load(f)
            merged = {}
            for d in dumps.values():
                merged.update(d.get("enums", {}))
            sources.append((typelib_dump, merged))
        ref = os.path.join(HERE, "reference", "api_reference.json")
        if os.path.isfile(ref):
            with open(ref, encoding="utf-8") as f:
                sources.append((ref, json.load(f)["enums"]))
        return cls(sources)

    def name(self, enum: str, value) -> str | None:
        if value is None:
            return None
        names = self._rev.get(enum, {}).get(value)
        return "|".join(names) if names else None

    def value(self, enum: str, name: str, default=None):
        return self.enums.get(enum, {}).get(name, default)


def find_typelib_dump() -> str | None:
    """Newest typelib_dump.json written by the week 2 probe, if any."""
    cands = glob.glob(os.path.join(KIT_ROOT, "week2", "probe_*", "typelib_dump.json"))
    return max(cands, key=os.path.getmtime) if cands else None


# --------------------------------------------------------------------------- connection

def find_launchers() -> list[dict]:
    import winreg
    hkcr = winreg.HKEY_CLASSES_ROOT
    found, i = [], 0
    try:
        root = winreg.OpenKey(hkcr, "")
    except OSError:
        return found
    with root:
        while True:
            try:
                name = winreg.EnumKey(root, i)
            except OSError:
                break
            i += 1
            if name.startswith("EFDApiSrv.EFDLauncher"):
                m = PROGID_RE.match(name)
                found.append({"progid": name,
                              "product": PRODUCT_NAMES.get(m.group(1)) if m else None,
                              "version": int(m.group(2)) if m else None,
                              "product_code": m.group(1) if m else None})
    return found


def choose_progid(wanted: str | None, rec: Recorder) -> str:
    if wanted:
        return wanted
    try:
        launchers = [e for e in find_launchers() if e["version"]]
    except Exception as exc:  # noqa: BLE001
        rec.log(f"Registry lookup failed ({exc}); using EFDApiSrv.EFDLauncher")
        launchers = []
    if not launchers:
        return "EFDApiSrv.EFDLauncher"
    standalone = [e for e in launchers if e["product_code"] == "0"]
    pick = max(standalone or launchers, key=lambda e: e["version"])
    return pick["progid"]


def connect(rec: Recorder, progid: str | None, mode: str, pid: int = 0,
            attach_timeout: float = 90, start_timeout: float = 900):
    """Returns (app, info). mode: attach | run | auto (attach first, start if none)."""
    import pythoncom
    import win32com.client.dynamic
    pythoncom.CoInitialize()
    progid = choose_progid(progid, rec)
    info = {"progid": progid, "mode_requested": mode, "mode_used": None}
    ok, srv = rec.invoke("Dispatch", win32com.client.dynamic, "Dispatch", progid, timeout=120)
    if not ok:
        return None, info
    app = None
    if mode in ("attach", "auto"):
        ok, app = rec.invoke("Launcher.Attach2RunningCADInstance", srv, "Attach2RunningCADInstance", pid,
                             timeout=attach_timeout)
        if ok and app is not None:
            info["mode_used"] = "attach"
        else:
            app = None
    if app is None and mode in ("run", "auto"):
        rec.log(f"Starting FLOEFD (limit {start_timeout:.0f}s) ...")
        ok, app = rec.invoke("Launcher.RunProduct", srv, "RunProduct", timeout=start_timeout)
        if ok and app is not None:
            info["mode_used"] = "run"
        else:
            app = None
    if app is not None:
        info["floefd_version"] = rec.value("App.GetVersion", app, "GetVersion")
    return app, info


def require_windows_com(rec: Recorder) -> bool:
    if os.name != "nt" and os.environ.get("EFD_ALLOW_NON_WINDOWS") != "1":   # test harness only
        rec.log("Run this on the Windows machine where FLOEFD is installed.")
        return False
    try:
        import pythoncom  # noqa: F401
        import win32com.client  # noqa: F401
    except ImportError as exc:
        rec.log(f"pywin32 is not installed ({exc}).")
        return False
    return True


def environment_info() -> dict:
    import platform
    info = {"python": sys.version.split()[0], "python_bits": 64 if sys.maxsize > 2**32 else 32,
            "computer": os.environ.get("COMPUTERNAME", platform.node()), "user": os.environ.get("USERNAME", ""),
            "session": os.environ.get("SESSIONNAME", "")}
    try:
        from importlib.metadata import version
        info["pywin32"] = version("pywin32")
    except Exception:  # noqa: BLE001
        info["pywin32"] = None
    return info


def format_exc(exc: BaseException) -> str:
    return "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
