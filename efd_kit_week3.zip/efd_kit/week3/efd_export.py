"""FLOEFD automation - Week 3: project structure export (read-only).

Reads one FLOEFD document (normally the colleague's base project) and writes
everything a CSV-driven batch run needs to know about it:

  - every project in the document: general settings, ambient parameters,
    global mesh, calculation control (finishing, refinement, solving, saving)
  - every feature: type, name, UUID, suppressed state, bound faces/components,
    and every parameter with its type code, display name, value type,
    dependency type and current value (combo options included)
  - goals, and with --results the goal values of already-solved results, with units
  - the CAD tree: components, part files, bodies, CAD variables (dimensions),
    and a test of the component-selection mechanism used later to bind features

Nothing is modified and nothing is saved. With --results the last results are
loaded for reading and unloaded again afterwards (unless --keep-results).

Usage (normally via run_export.bat)
  python efd_export.py                          attach to the open FLOEFD, export the active document
  python efd_export.py --results                also read goal values of existing results
  python efd_export.py --project "Case A"       only this project (repeatable)
  python efd_export.py --mode run --open "D:\\work\\copy\\model.SLDASM"

Outputs (export_<computer>_<time>\\)
  summary.md          Chinese summary for the weekly report
  structure.json      everything, nested
  parameters.csv      one row per feature parameter
  features.csv        one row per feature
  goals.csv           goal definitions (and values with --results)
  settings.csv        general / mesh / calculation-control settings
  cad_components.csv  CAD tree
  cad_variables.csv   CAD variables (dimensions) per part file
  mapping_draft.csv   input/output candidates for the colleague to mark
  run.log, run_report.json   call log, failures, per-method statistics

Exit codes: 0 ok, 1 finished with failures, 2 a call timed out,
            3 environment problem, 4 could not connect, 5 no document open
"""

from __future__ import annotations

import argparse
import csv
import datetime as _dt
import json
import os
import platform
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import efd_common as ec  # noqa: E402

TOOL_VERSION = "1.0"
HERE = os.path.dirname(os.path.abspath(__file__))

# Constants used below (values from the API reference; checked against this machine's enums at run time).
SEL_COMPONENTS_DEFAULT = 20   # efdSelCOMPONENTS
MESH_BCF_DEFAULT = 1          # efdMeshType_bcf
XXYYZZ_DEFAULT = 1            # efdXXYYZZ
FLD_DEFAULT = 3               # efdFLD
ANY_RESULT_DEFAULT = 9        # efdAnyResult
VALUE_BOOL, VALUE_COMBO, VALUE_DOUBLE = 0, 1, 2   # efdParamValueType
DEP_CONST, DEP_CELLCONST = 0, 1                  # efdParamDependencesType

GOAL_FEATURE_TYPES = {"efdGlobalGoal", "efdSurfaceGoal", "efdVolumeGoal", "efdPointGoal", "efdEquationGoal",
                      "efdNodalGoal"}

# Settings whose integer value is an enum: getter -> enum name.
DECODE = {
    "GetProblemType": "efdProblemType", "GetFluidType": "efdSubstanceType", "GetFlowType": "efdFlowType",
    "GetFlowSpaceType": "efdFlowSpaceType", "GetRadiationModel": "efdRadiationModelType",
    "GetRotationType": "efdRotationType", "GetGeometryRecognition": "efdGeometryRecognition",
    "GetFEMAnalysisType": "efdFEMAnalysisType", "GetFinishCondition": "efdFinishCond",
    "GetRefStrategy": "efdRefStrategy", "get_FCType": "efdFlowConditionType", "get_SourceType": "efdSourceType",
    "get_GoalType": "efdGoalType", "get_CalculateValue": "efdGoalCalculatedValue", "get_FanType": "efdFanType",
    "get_SubstanceType": "efdSubstanceType", "GetWallVelocityType": "efdMovingWallType",
    "get_DirectionAxis": "efdCoordinateAxis", "GetPointDefType": "efdPointDefType",
}


class Exporter:
    def __init__(self, rec: ec.Recorder, enums: ec.EnumBook, catalog: dict, args):
        self.rec, self.enums, self.catalog, self.args = rec, enums, catalog, args
        self.sel_components = enums.value("efdSelectType", "efdSelCOMPONENTS", SEL_COMPONENTS_DEFAULT)
        self.mesh_bcf = enums.value("efdMeshType", "efdMeshType_bcf", MESH_BCF_DEFAULT)
        self.xxyyzz = enums.value("efdDimensionBoxArrayType", "efdXXYYZZ", XXYYZZ_DEFAULT)
        self.fld = enums.value("efdResultsFileType", "efdFLD", FLD_DEFAULT)
        self.any_result = enums.value("efdResultsFileType", "efdAnyResult", ANY_RESULT_DEFAULT)
        self.data: dict = {}

    # ------------------------------------------------------------------ generic readers
    def sweep(self, obj, catalog_key: str, prefix: str, skip: set | None = None) -> dict:
        """Calls every read-only getter the API reference lists for this interface."""
        out = {}
        getters = self.catalog.get(catalog_key, {})
        for name, meta in sorted(getters.items()):
            if meta.get("returns_object") or (skip and name in skip):
                continue
            ok, v = self.rec.invoke(f"{prefix}.{name}", obj, name, quiet=True, optional=True)
            if ok:
                out[name] = self._decode(name, v)
        return out

    def _decode(self, getter: str, v):
        enum = DECODE.get(getter)
        if enum is not None and isinstance(v, int) and not isinstance(v, bool):
            return {"code": v, "name": self.enums.name(enum, v)}
        return ec.jsonable(v)

    def read_param(self, p, project, owner, idx: int, owner_label: str) -> dict:
        r, inv = {"index": idx}, self.rec.invoke
        lab = f"{owner_label}.param[{idx}]"
        ok, code = inv(f"{lab}.GetType", p, "GetType", quiet=True)
        r["type_code"] = code if ok else None
        r["type"] = self.enums.name("efdParameterType", code) if ok else None
        ok, nm = inv(f"{lab}.GetParameterName", p, "GetParameterName", project, owner, quiet=True)
        r["display_name"] = nm if ok else None
        ok, vt = inv(f"{lab}.GetValueType", p, "GetValueType", quiet=True)
        vt = vt if ok else None
        r["value_type_code"] = vt
        r["value_type"] = self.enums.name("efdParamValueType", vt)
        ok, dep = inv(f"{lab}.GetDependenceType", p, "GetDependenceType", quiet=True)
        dep = dep if ok else None
        r["dependence_code"] = dep
        r["dependence"] = self.enums.name("efdParamDependencesType", dep)
        ok, u = inv(f"{lab}.GetUUID", p, "GetUUID", quiet=True, optional=True)
        r["uuid"] = u if ok else None

        # Unknown value type: try every reader.
        if vt in (VALUE_DOUBLE, None):
            ok, res = inv(f"{lab}.GetValue", p, "GetValue", quiet=True, optional=True)
            if ok:
                val, flag = ec.out_value(res)
                r["value"] = ec.jsonable(val)
                r["value_read_ok"] = ec.jsonable(flag)
                r["value_raw"] = ec.jsonable(res)
        if vt == VALUE_COMBO or vt is None:
            ok, res = inv(f"{lab}.GetComboValue", p, "GetComboValue", quiet=True, optional=True)
            if ok:
                val, _ = ec.out_value(res)
                r["combo_value"] = ec.jsonable(val)
                r["combo_raw"] = ec.jsonable(res)
            ok, res = inv(f"{lab}.GetComboParameterPossibleNamesAndValues", p,
                          "GetComboParameterPossibleNamesAndValues", project, owner, quiet=True, optional=True)
            if ok:
                _, outs = ec.split_ret_outs(res, 2, False)
                if len(outs) == 2:
                    vals, names = ec.as_list(outs[0]), ec.as_list(outs[1])
                    r["combo_options"] = [{"value": ec.jsonable(v), "name": ec.jsonable(n)}
                                          for v, n in zip(vals, names)]
                    for o in r["combo_options"]:
                        if o["value"] == r.get("combo_value"):
                            r["combo_name"] = o["name"]
        if vt == VALUE_BOOL or vt is None:
            ok, res = inv(f"{lab}.GetBooleanValue", p, "GetBooleanValue", quiet=True, optional=True)
            if ok:
                if isinstance(res, tuple) and len(res) >= 2:
                    r["bool_value"] = ec.jsonable(res[-1])
                else:
                    r["bool_value_raw"] = ec.jsonable(res)   # cannot tell value from success flag
        if dep not in (None, DEP_CONST, DEP_CELLCONST):
            ok, res = inv(f"{lab}.GetTable", p, "GetTable", quiet=True, optional=True)
            if ok:
                r["table"] = ec.jsonable(res)
        return r

    def read_params(self, owner, project, owner_label: str) -> list[dict]:
        ok, ps = self.rec.invoke(f"{owner_label}.GetParameters", owner, "GetParameters", quiet=True, optional=True)
        if not ok:
            return []
        return [self.read_param(p, project, owner, i, owner_label) for i, p in enumerate(ec.as_list(ps))]

    def refs(self, obj, label: str):
        for m in ("GetTopologicalReferencesUUIDsAndNames", "GetTopologicalReferencesUUIDsAndNames_VAR"):
            ok, res = self.rec.invoke(f"{label}.{m}", obj, m, quiet=True, optional=True)
            if ok:
                _, outs = ec.split_ret_outs(res, 2, False)
                if len(outs) == 2:
                    return {"uuids": ec.jsonable(ec.as_list(outs[0])), "names": ec.jsonable(ec.as_list(outs[1]))}
        return None

    # ------------------------------------------------------------------ project
    def export_project(self, project, pname: str) -> dict:
        rec, inv = self.rec, self.rec.invoke
        rec.log(f"--- Project: {pname}")
        P: dict = {"name": pname}
        P["description"] = rec.value(f"{pname}.GetDescription", project, "GetDescription", quiet=True, optional=True)
        ok, cfg = inv(f"{pname}.GetConfiguration", project, "GetConfiguration", quiet=True, optional=True)
        if ok and cfg is not None:
            P["configuration"] = rec.value(f"{pname}.Configuration.GetName", cfg, "GetName", quiet=True)
        ok, names = inv(f"{pname}.GetProblemNames", project, "GetProblemNames", quiet=True, optional=True)
        if ok and names is not None:
            P["paths"] = self.sweep(names, "IProjectNames", f"{pname}.ProblemNames")
        ok, us = inv(f"{pname}.GetUnitsSystem", project, "GetUnitsSystem", quiet=True, optional=True)
        if ok and us is not None:
            P["unit_system"] = rec.value(f"{pname}.UnitSystem.GetName", us, "GetName", quiet=True, optional=True)

        # General settings, ambient parameters, global mesh
        ok, gs = inv(f"{pname}.GetGeneralSettings", project, "GetGeneralSettings")
        if ok and gs is not None:
            P["general_settings"] = self.sweep(gs, "IGeneralSettings", f"{pname}.GS")
            okd, cd = inv(f"{pname}.GS.GetComputationalDomain", gs, "GetComputationalDomain", self.xxyyzz,
                          quiet=True, optional=True)
            if okd:
                P["computational_domain_xxyyzz"] = ec.jsonable(cd)
            oka, amb = inv(f"{pname}.GS.GetAmbientParameters", gs, "GetAmbientParameters", quiet=True)
            if oka and amb is not None:
                P["ambient"] = {"getters": self.sweep(amb, "IAmbientParameters", f"{pname}.Ambient"),
                                "parameters": self.read_params(amb, project, f"{pname}.Ambient")}
            okm, mesh = inv(f"{pname}.GS.GetDefaultMeshSettings", gs, "GetDefaultMeshSettings", self.mesh_bcf,
                            quiet=True)
            if okm and mesh is not None:
                P["global_mesh"] = {"getters": self.sweep(mesh, "IGlobalMeshSettings", f"{pname}.Mesh"),
                                    "parameters": self.read_params(mesh, project, f"{pname}.Mesh")}

        # Calculation control
        ok, cco = inv(f"{pname}.GetCalculationControlOptions", project, "GetCalculationControlOptions", quiet=True)
        if ok and cco is not None:
            cc = {}
            for getter, iface in (("GetFinishConditions", "IFinishingConditions"),
                                  ("GetRefinementOptions", "IRefinementOptions"),
                                  ("GetSolvingOptions", "ISolvingOptions"),
                                  ("GetSavingOptions", "ISavingOptions")):
                okc, sub = inv(f"{pname}.CCO.{getter}", cco, getter, quiet=True, optional=True)
                if okc and sub is not None:
                    cc[iface] = self.sweep(sub, iface, f"{pname}.CCO.{iface}")
            P["calculation_control"] = cc

        P["features"] = self.export_features(project, pname)

        ok, upm = inv(f"{pname}.GetUserParamsManager", project, "GetUserParamsManager", quiet=True, optional=True)
        if ok and upm is not None:
            okp, allp = inv(f"{pname}.UserParams.GetAllParameters", upm, "GetAllParameters", quiet=True, optional=True)
            P["user_parameters"] = [self.read_param(p, project, None, i, f"{pname}.UserParam")
                                    for i, p in enumerate(ec.as_list(allp))] if okp else []

        P["results"] = self.export_results(project, pname)
        return P

    def export_features(self, project, pname: str) -> list[dict]:
        rec, inv = self.rec, self.rec.invoke
        ok, feats = inv(f"{pname}.GetFeatures", project, "GetFeatures")
        if not ok or feats is None:
            return []
        seen, ordered = {}, []
        for flag in (True, False):
            okf, lst = inv(f"{pname}.Features.GetFeatures1({flag})", feats, "GetFeatures1", flag)
            for f in ec.as_list(lst) if okf else []:
                uuid = rec.value(f"{pname}.Feature.GetUUID", f, "GetUUID", quiet=True)
                key = uuid or f"noid-{len(ordered)}"
                if key in seen:
                    seen[key]["listed_in"].append(flag)
                    continue
                entry = {"obj": f, "uuid": uuid, "listed_in": [flag]}
                seen[key] = entry
                ordered.append(entry)
        rec.log(f"{pname}: {len(ordered)} features")

        union = [g for g in self.catalog.get("feature_getter_union", [])]
        object_getters = set()
        for iface in self.catalog.get("feature_interfaces", {}).values():
            for name, meta in iface.items():
                if meta.get("returns_object"):
                    object_getters.add(name)
        out = []
        for i, e in enumerate(ordered):
            f = e["obj"]
            lab = f"{pname}.F[{i}]"
            code = rec.value(f"{lab}.GetType", f, "GetType", quiet=True)
            name = rec.value(f"{lab}.GetName", f, "GetName", quiet=True)
            F = {"index": i, "name": name, "uuid": e["uuid"], "type_code": code,
                 "type": self.enums.name("efdFeatureType", code),
                 "listed_in_GetFeatures1": e["listed_in"],
                 "suppressed": ec.jsonable(rec.value(f"{lab}.IsSuppressed", f, "IsSuppressed", quiet=True,
                                                     optional=True))}
            label = f"{pname}.{name or i}"
            F["references"] = self.refs(f, label)
            F["parameters"] = self.read_params(f, project, label)
            if not self.args.no_getters:
                props = {}
                for g in union:
                    if g in object_getters:
                        continue
                    okg, v = rec.invoke(f"{label}.{g}", f, g, quiet=True, optional=True)
                    if okg:
                        props[g] = self._decode(g, v)
                F["properties"] = props
            out.append(F)
        return out

    def export_results(self, project, pname: str) -> dict:
        rec, inv = self.rec, self.rec.invoke
        R: dict = {"requested": bool(self.args.results)}
        ok, res = inv(f"{pname}.GetResults", project, "GetResults", quiet=True, optional=True)
        if not ok or res is None:
            return R
        before = rec.value(f"{pname}.Results.GetResultsFileType", res, "GetResultsFileType", quiet=True,
                           optional=True)
        R["file_type_before"] = {"code": before, "name": self.enums.name("efdResultsFileType", before)}
        if not self.args.results:
            return R
        loaded_by_us = False
        for rtype in (self.fld, self.any_result):
            okl, _ = inv(f"{pname}.Results.LoadLastResults({rtype})", res, "LoadLastResults", rtype,
                         timeout=self.args.load_timeout)
            if okl:
                loaded_by_us = True
                R["loaded_with"] = self.enums.name("efdResultsFileType", rtype)
                break
        after = rec.value(f"{pname}.Results.GetResultsFileType", res, "GetResultsFileType", quiet=True, optional=True)
        R["file_type_after"] = {"code": after, "name": self.enums.name("efdResultsFileType", after)}
        R["summary_text"] = rec.value(f"{pname}.Results.GetResultsSummary", res, "GetResultsSummary", quiet=True,
                                      optional=True)
        conv = rec.value(f"{pname}.GetUnitsConverter", project, "GetUnitsConverter", quiet=True, optional=True)
        okg, pg = inv(f"{pname}.Results.GetPostGoals", res, "GetPostGoals", quiet=True)
        goals = []
        if okg and pg is not None:
            R["goals_count"] = rec.value(f"{pname}.PostGoals.GetGoalsCount", pg, "GetGoalsCount", quiet=True)
            R["service_goals_count"] = rec.value(f"{pname}.PostGoals.GetServiceGoalsCount", pg,
                                                 "GetServiceGoalsCount", quiet=True, optional=True)
            R["iterations_count"] = rec.value(f"{pname}.PostGoals.GetIterationsCount", pg, "GetIterationsCount",
                                              quiet=True, optional=True)
            n = R["goals_count"] if isinstance(R.get("goals_count"), int) else 0
            total = n + (R["service_goals_count"] if isinstance(R.get("service_goals_count"), int) else 0)
            R["index_base"] = None
            for base in (0, 1):
                okb, first = inv(f"{pname}.PostGoals.GetGoalByIndex({base})", pg, "GetGoalByIndex", base,
                                 quiet=True, optional=True)
                if okb and first is not None:
                    R["index_base"] = base
                    break
            if R["index_base"] is not None:
                for k in range(R["index_base"], R["index_base"] + total):
                    okk, g = inv(f"{pname}.PostGoals.GetGoalByIndex({k})", pg, "GetGoalByIndex", k, quiet=True)
                    if not okk or g is None:
                        continue
                    G = {"index": k}
                    for getter in ("GetGoalName", "GetGoalUUID", "GetGoalType", "GetCalculateValue", "GetValue",
                                   "GetAvValue", "GetMinValue", "GetMaxValue", "GetGoalUnitID", "GetProgress",
                                   "GetDelta", "IsInvalid", "IsServiceGoal", "IsUserDefinedGoal",
                                   "GetUseInConvergence", "GetStartIter"):
                        okv, v = inv(f"{pname}.Goal[{k}].{getter}", g, getter, quiet=True, optional=True)
                        if okv:
                            G[getter] = ec.jsonable(v)
                    okc, crit = inv(f"{pname}.Goal[{k}].GetCriteria", g, "GetCriteria", quiet=True, optional=True)
                    if okc:
                        G["GetCriteria"] = ec.jsonable(crit)
                    G["goal_type_name"] = self.enums.name("efdGoalType", G.get("GetGoalType"))
                    q = G.get("GetGoalUnitID")
                    G["quantity"] = self.enums.name("efdPhysicalQuantity", q)
                    if conv is not None and isinstance(q, int):
                        G["unit"] = rec.value(f"{pname}.Units.GetUnitShortName", conv, "GetUnitShortName", q,
                                              quiet=True, optional=True)
                        if isinstance(G.get("GetValue"), (int, float)):
                            G["value_display"] = rec.value(f"{pname}.Units.UnitToString", conv, "UnitToString",
                                                           G["GetValue"], q, True, True, quiet=True, optional=True)
                    goals.append(G)
        R["goals"] = goals
        if loaded_by_us and not self.args.keep_results:
            inv(f"{pname}.Results.UnloadResults", res, "UnloadResults", quiet=True, optional=True)
            R["unloaded_after_reading"] = True
        rec.log(f"{pname}: results {R.get('file_type_after', {}).get('name')}, {len(goals)} goal values read")
        return R

    # ------------------------------------------------------------------ CAD
    def export_cad(self, model_doc, project) -> dict:
        rec, inv = self.rec, self.rec.invoke
        C: dict = {"components": [], "variables": [], "documents": {}}
        ok, root = inv("ModelDoc.GetRootComponent", model_doc, "GetRootComponent")
        if not ok or root is None:
            return C
        ce = None
        if project is not None:
            ok, ce = inv("Project.GetComponentExplorer", project, "GetComponentExplorer", quiet=True, optional=True)
            if not ok:
                ce = None
        seen_docs: set = set()
        count = [0]

        def read_vars(md, owner: str):
            path = rec.value(f"{owner}.ModelDoc.GetPathName", md, "GetPathName", quiet=True, optional=True)
            key = path or owner
            if key in seen_docs:
                return path
            seen_docs.add(key)
            C["documents"][key] = {"path": path, "type": self.enums.name(
                "efdDocumentType", rec.value(f"{owner}.ModelDoc.GetType", md, "GetType", quiet=True, optional=True))}
            okv, vs = inv(f"{owner}.ModelDoc.GetVariables", md, "GetVariables", quiet=True, optional=True)
            for j, v in enumerate(ec.as_list(vs) if okv else []):
                lab = f"{owner}.Var[{j}]"
                sysv = rec.value(f"{lab}.GetSystemValue", v, "GetSystemValue", quiet=True)
                q = rec.value(f"{lab}.GetType", v, "GetType", quiet=True, optional=True)
                row = {"document": path, "first_component": owner,
                       "name": rec.value(f"{lab}.GetName", v, "GetName", quiet=True),
                       "system_value": ec.jsonable(sysv), "quantity_code": q,
                       "quantity": self.enums.name("efdPhysicalQuantity", q),
                       "driven": ec.jsonable(rec.value(f"{lab}.IsDriven", v, "IsDriven", quiet=True, optional=True))}
                if isinstance(sysv, (int, float)):
                    row["user_value"] = ec.jsonable(rec.value(f"{lab}.ConvertToUserUnit", v, "ConvertToUserUnit",
                                                              sysv, quiet=True, optional=True))
                C["variables"].append(row)
            return path

        def walk(comp, chain: list[str], depth: int):
            if count[0] >= self.args.max_components:
                return
            count[0] += 1
            name = rec.value("Component.GetName", comp, "GetName", quiet=True)
            lab = f"Comp[{'/'.join(chain + [str(name)])}]"
            row = {"depth": depth, "name": name, "path": "/".join(chain + [str(name)]) if depth else str(name)}
            row["box"] = ec.jsonable(rec.value(f"{lab}.GetBox", comp, "GetBox", quiet=True, optional=True))
            row["transform"] = ec.jsonable(rec.value(f"{lab}.GetTransform", comp, "GetTransform", quiet=True,
                                                     optional=True))
            okm, md = inv(f"{lab}.GetModelDoc", comp, "GetModelDoc", quiet=True, optional=True)
            row["model_path"] = read_vars(md, str(name)) if okm and md is not None else None
            for btype, key in ((0, "solid_bodies"), (1, "sheet_bodies")):
                okb, bodies = inv(f"{lab}.GetBodies({btype})", comp, "GetBodies", btype, quiet=True, optional=True)
                blist = ec.as_list(bodies) if okb else []
                row[key] = len(blist)
                if blist and md is not None:
                    row[key + "_names"] = [rec.value(f"{lab}.Body.GetName", b, "GetName", md, quiet=True,
                                                     optional=True) for b in blist[:50]]
            okc, kids = inv(f"{lab}.GetChildren", comp, "GetChildren", quiet=True, optional=True)
            kids = ec.as_list(kids) if okc else []
            row["children"] = len(kids)
            if depth >= 1 and not self.args.no_selection_test:
                row.update(self.selection_test(model_doc, ce, chain[1:] + [str(name)], lab))
            C["components"].append(row)
            for k in kids:
                walk(k, chain + [str(name)], depth + 1)

        read_vars(model_doc, "(root document)")
        walk(root, [], 0)
        if count[0] >= self.args.max_components:
            C["truncated_at"] = self.args.max_components
        rec.log(f"CAD: {len(C['components'])} components, {len(C['documents'])} part/assembly files, "
                f"{len(C['variables'])} variables")
        return C

    def selection_test(self, model_doc, ce, names: list[str], lab: str) -> dict:
        """Selects the component by its instance-name path, the way features are bound later."""
        rec, inv = self.rec, self.rec.invoke
        r = {"select_path": "/".join(names)}
        okp, path = inv(f"{lab}.CreatePath", model_doc, "CreatePath", quiet=True)
        if not okp or path is None:
            r["select_ok"] = False
            return r
        for n in names:
            ok1, el = inv(f"{lab}.Path.CreateElement", path, "CreateElement", quiet=True)
            if not ok1 or el is None:
                r["select_ok"] = False
                return r
            inv(f"{lab}.Elem.SetType", el, "SetType", self.sel_components, quiet=True)
            inv(f"{lab}.Elem.SetName", el, "SetName", n, quiet=True)
            inv(f"{lab}.Path.AddElement", path, "AddElement", el, quiet=True)
        oke, ents = inv(f"{lab}.ModelDoc.GetEntities", model_doc, "GetEntities", path, quiet=True)
        ents = ec.as_list(ents) if oke else []
        r["select_ok"] = bool(ents)
        r["select_entities"] = len(ents)
        if ents and ce is not None:
            okd, res = inv(f"{lab}.IsDisabledBodyOrComponent", ce, "IsDisabledBodyOrComponent", ents[0],
                           self.mesh_bcf, quiet=True, optional=True)
            if okd:
                ret, outs = ec.split_ret_outs(res, 1, True)
                r["disabled_in_component_control"] = ec.jsonable(ret)
                r["locked"] = ec.jsonable(outs[0]) if outs else None
        return r


# --------------------------------------------------------------------------- flat tables

def _fmt(v):
    if isinstance(v, float):
        return repr(v)
    if isinstance(v, (list, dict)):
        return json.dumps(v, ensure_ascii=False)
    return "" if v is None else v


def write_csv(path: str, rows: list[dict], columns: list[str]) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: _fmt(r.get(k)) for k in columns})


def strip_efd(name: str | None) -> str:
    if not name:
        return ""
    first = name.split("|")[0]
    return first[3:] if first.startswith("efd") else first


def build_tables(data: dict) -> dict:
    t = {k: [] for k in ("parameters", "features", "goals", "settings", "cad_components", "cad_variables", "mapping")}
    for P in data.get("projects", []):
        pn = P["name"]

        def add_params(owner_kind, owner_name, owner_type, suppressed, params):
            for p in params:
                row = {"project": pn, "owner_kind": owner_kind, "owner": owner_name, "owner_type": owner_type,
                       "owner_suppressed": suppressed, **{k: p.get(k) for k in (
                           "index", "type_code", "type", "display_name", "value_type", "dependence", "value",
                           "combo_value", "combo_name", "bool_value", "uuid")}}
                row["combo_options"] = p.get("combo_options")
                t["parameters"].append(row)
                if (p.get("value_type_code") == VALUE_DOUBLE and p.get("dependence_code") == DEP_CONST
                        and suppressed is not True and owner_kind in ("feature", "ambient")):
                    t["mapping"].append({"include": "", "side": "input",
                                         "suggested_column": f"{owner_name}.{strip_efd(p.get('type'))}",
                                         "source_kind": f"{owner_kind}_parameter", "project": pn,
                                         "owner": owner_name, "item": p.get("display_name"),
                                         "type": p.get("type"), "current_value": p.get("value"),
                                         "note": "数值按 SI 读出（待第 4 周确认）"})

        amb = P.get("ambient") or {}
        add_params("ambient", "Ambient", "AmbientParameters", None, amb.get("parameters", []))
        mesh = P.get("global_mesh") or {}
        add_params("global_mesh", "GlobalMesh", "GlobalMeshSettings", None, mesh.get("parameters", []))
        for F in P.get("features", []):
            refs = F.get("references") or {}
            t["features"].append({"project": pn, "index": F["index"], "name": F["name"], "type": F["type"],
                                  "type_code": F["type_code"], "suppressed": F["suppressed"],
                                  "parameters": len(F.get("parameters", [])),
                                  "references": len(refs.get("names") or []),
                                  "reference_names": refs.get("names"), "uuid": F["uuid"],
                                  "properties": F.get("properties")})
            add_params("feature", F["name"], F["type"], F["suppressed"], F.get("parameters", []))
            if (F.get("type") or "").split("|")[0] in GOAL_FEATURE_TYPES:
                props = F.get("properties") or {}
                t["goals"].append({"project": pn, "source": "definition", "name": F["name"], "feature_type": F["type"],
                                   "goal_type": (props.get("get_GoalType") or {}).get("name")
                                   if isinstance(props.get("get_GoalType"), dict) else None,
                                   "calculate": (props.get("get_CalculateValue") or {}).get("name")
                                   if isinstance(props.get("get_CalculateValue"), dict) else None,
                                   "use_in_convergence": props.get("get_UseInConvergence"),
                                   "suppressed": F["suppressed"]})
        add_params("user", "UserParameters", "UserParameter", None, P.get("user_parameters", []))
        for G in (P.get("results") or {}).get("goals", []):
            t["goals"].append({"project": pn, "source": "results", "name": G.get("GetGoalName"),
                               "goal_type": G.get("goal_type_name"), "value": G.get("GetValue"),
                               "average": G.get("GetAvValue"), "min": G.get("GetMinValue"), "max": G.get("GetMaxValue"),
                               "unit": G.get("unit"), "value_display": G.get("value_display"),
                               "quantity": G.get("quantity"), "progress": G.get("GetProgress"),
                               "invalid": G.get("IsInvalid"), "service_goal": G.get("IsServiceGoal")})
        goal_names = {g["name"] for g in t["goals"] if g["project"] == pn and g["name"]}
        for name in sorted(goal_names):
            vals = [g.get("value") for g in t["goals"] if g["project"] == pn and g["name"] == name
                    and g["source"] == "results"]
            t["mapping"].append({"include": "", "side": "output", "suggested_column": name, "source_kind": "goal",
                                 "project": pn, "owner": "", "item": name, "type": "",
                                 "current_value": vals[0] if vals else "", "note": ""})
        def setting(section, k, v):
            if isinstance(v, dict) and set(v) == {"code", "name"}:
                v = f"{v['name']} ({v['code']})"
            t["settings"].append({"project": pn, "section": section, "name": k, "value": v})
        for k, v in (P.get("general_settings") or {}).items():
            setting("general_settings", k, v)
        if P.get("computational_domain_xxyyzz") is not None:
            setting("general_settings", "GetComputationalDomain(XXYYZZ)", P["computational_domain_xxyyzz"])
        for section in ("ambient", "global_mesh"):
            for k, v in ((P.get(section) or {}).get("getters") or {}).items():
                setting(section, k, v)
        for iface, vals in (P.get("calculation_control") or {}).items():
            for k, v in vals.items():
                setting(iface, k, v)
    cad = data.get("cad") or {}
    t["cad_components"] = cad.get("components", [])
    t["cad_variables"] = cad.get("variables", [])
    for v in t["cad_variables"]:
        if v.get("driven") is not True:
            nm = str(v.get("name") or "").strip('"')
            t["mapping"].append({"include": "", "side": "input", "suggested_column": f"{v.get('first_component')}.{nm}",
                                 "source_kind": "cad_variable", "project": "(all)", "owner": v.get("first_component"),
                                 "item": v.get("name"), "type": v.get("quantity"),
                                 "current_value": v.get("system_value"),
                                 "note": "CAD 变量，SI 值；属于零件文件，改一次所有实例都会变"})
    return t


def write_tables(out_dir: str, t: dict) -> None:
    write_csv(os.path.join(out_dir, "parameters.csv"), t["parameters"],
              ["project", "owner_kind", "owner", "owner_type", "owner_suppressed", "index", "type_code", "type",
               "display_name", "value_type", "dependence", "value", "combo_value", "combo_name", "combo_options",
               "bool_value", "uuid"])
    write_csv(os.path.join(out_dir, "features.csv"), t["features"],
              ["project", "index", "name", "type", "type_code", "suppressed", "parameters", "references",
               "reference_names", "uuid", "properties"])
    write_csv(os.path.join(out_dir, "goals.csv"), t["goals"],
              ["project", "source", "name", "feature_type", "goal_type", "calculate", "use_in_convergence",
               "suppressed", "value", "average", "min", "max", "unit", "value_display", "quantity", "progress",
               "invalid", "service_goal"])
    write_csv(os.path.join(out_dir, "settings.csv"), t["settings"], ["project", "section", "name", "value"])
    write_csv(os.path.join(out_dir, "cad_components.csv"), t["cad_components"],
              ["depth", "path", "name", "children", "model_path", "solid_bodies", "solid_bodies_names",
               "sheet_bodies", "select_path", "select_ok", "select_entities", "disabled_in_component_control",
               "locked", "box", "transform"])
    write_csv(os.path.join(out_dir, "cad_variables.csv"), t["cad_variables"],
              ["document", "first_component", "name", "system_value", "user_value", "quantity", "driven"])
    write_csv(os.path.join(out_dir, "mapping_draft.csv"), t["mapping"],
              ["include", "side", "suggested_column", "source_kind", "project", "owner", "item", "type",
               "current_value", "note"])


# --------------------------------------------------------------------------- summary

def render_summary(data: dict, t: dict, rec: ec.Recorder) -> str:
    L = []
    env = data.get("environment", {})
    conn = data.get("connection", {})
    doc = data.get("document", {})
    L += [f"# 项目结构导出结果：{doc.get('title') or ''}", "",
          f"运行时间：{rec.report.get('started')} 至 {rec.report.get('finished')}　状态：{rec.report.get('status')}", "",
          "## 连接与文档", "",
          f"- FLOEFD：{conn.get('floefd_version')}（{conn.get('progid')}，方式 {conn.get('mode_used')}）",
          f"- Python {env.get('python')}，pywin32 {env.get('pywin32')}",
          f"- 文档：{doc.get('title')}　路径：{doc.get('path')}　类型：{doc.get('type')}",
          f"- 配置：{doc.get('configurations')}，当前 {doc.get('active_configuration')}",
          f"- 文档内的项目：{doc.get('project_names')}（当前项目 {doc.get('active_project')}）",
          f"- 本次导出：{[p.get('name') for p in data.get('projects', [])]}", ""]
    for P in data.get("projects", []):
        pn = P["name"]
        L += [f"## 项目：{pn}", ""]
        gs = P.get("general_settings") or {}

        def nm(k):
            v = gs.get(k)
            return v.get("name") if isinstance(v, dict) else v
        L.append(f"- 解析类型 {nm('GetProblemType')}，流体 {nm('GetFluidType')}，流态 {nm('GetFlowType')}，"
                 f"流动 {gs.get('GetFluidFlow')}，固体导热 {gs.get('GetConduction')}，重力 {gs.get('GetGravitation')}，"
                 f"瞬态 {gs.get('GetTransient')}，辐射 {gs.get('GetRadiation')}")
        if P.get("unit_system"):
            L.append(f"- 单位制：{P['unit_system']}")
        feats = P.get("features", [])
        L.append(f"- 条件（feature）共 {len(feats)} 个，其中被抑制 {sum(1 for f in feats if f.get('suppressed') is True)} 个")
        cnt = Counter(f.get("type") or f"code {f.get('type_code')}" for f in feats)
        L += ["", "| 类型 | 个数 |", "| --- | --- |"]
        for k, v in cnt.most_common():
            L.append(f"| {k} | {v} |")
        params = [r for r in t["parameters"] if r["project"] == pn]
        inputs = [m for m in t["mapping"] if m["project"] == pn and m["side"] == "input"]
        outs = [m for m in t["mapping"] if m["project"] == pn and m["side"] == "output"]
        L += ["", f"- 参数共 {len(params)} 个；可作为 CSV 左侧输入的候选（数值型、常数、未抑制）{len(inputs)} 个",
              f"- Goal：{len(outs)} 个（可作为 CSV 右侧输出）"]
        R = P.get("results") or {}
        if R.get("requested"):
            L.append(f"- 结果读取：加载前 {(R.get('file_type_before') or {}).get('name')}，"
                     f"加载后 {(R.get('file_type_after') or {}).get('name')}，读到 {len(R.get('goals', []))} 个 Goal 值")
            if not R.get("goals"):
                L.append("- 没有读到 Goal 值：这个项目可能还没有计算结果，或结果文件不在默认位置")
            elif not R.get("loaded_with"):
                L.append("- 注意：加载结果失败，下表的值来自 FLOEFD 当前已加载的结果，请在界面上核对")
            if R.get("goals"):
                L += ["", "| Goal | 值（SI） | 显示值 | 单位 |", "| --- | --- | --- | --- |"]
                for G in R["goals"][:40]:
                    L.append(f"| {G.get('GetGoalName')} | {G.get('GetValue')} | {G.get('value_display')} | {G.get('unit')} |")
        else:
            L.append(f"- 结果文件状态：{(R.get('file_type_before') or {}).get('name')}（加 --results 可读取已有结果的 Goal 值）")
        L.append("")
    cad = data.get("cad") or {}
    comps = cad.get("components", [])
    sel = [c for c in comps if "select_ok" in c]
    vars_ = cad.get("variables", [])
    L += ["## CAD", "",
          f"- 组件 {len(comps)} 个（最深 {max([c['depth'] for c in comps], default=0)} 层），零件/装配文件 {len(cad.get('documents', {}))} 个",
          f"- CAD 变量 {len(vars_)} 个，其中被驱动（不可直接改）{sum(1 for v in vars_ if v.get('driven') is True)} 个",
          f"- 组件选取测试：{sum(1 for c in sel if c.get('select_ok'))} / {len(sel)} 个组件能按名称路径选中", ""]
    st = rec.stats
    failed = sorted(((m, s["failed"]) for m, s in st.items() if s["failed"]), key=lambda x: -x[1])
    L += ["## 读取失败的方法", ""]
    if failed:
        L += ["| 方法 | 失败次数 |", "| --- | --- |"] + [f"| {m} | {n} |" for m, n in failed[:30]]
        L.append("")
        L.append("错误明细见 run_report.json 的 failures。")
    else:
        L.append("- 无")
    L += ["", "## 下一步", "",
          "- 把 mapping_draft.csv 交给同事，在 include 列标出要变化的输入和要取的输出，补上取值范围",
          "- 在界面上对照 parameters.csv 抽查几个值，确认显示单位与导出的 SI 值的关系", ""]
    return "\n".join(L) + "\n"


# --------------------------------------------------------------------------- main

def parse_args(argv=None):
    p = argparse.ArgumentParser(description="FLOEFD week 3: export the structure of a project (read-only).")
    p.add_argument("--mode", default="attach", choices=["attach", "run", "auto"],
                   help="attach = use the FLOEFD you opened (default); run = start FLOEFD; auto = attach, else start")
    p.add_argument("--progid", help="launcher ProgID (default: auto-detect, Standalone and highest version)")
    p.add_argument("--pid", type=int, default=0, help="CAD process id for attach; 0 = the only running instance")
    p.add_argument("--open", help="model file to open first (use a COPY of the colleague's model)")
    p.add_argument("--project", action="append", help="export only this project (repeatable; default: all)")
    p.add_argument("--results", action="store_true", help="load the last results and read goal values")
    p.add_argument("--keep-results", action="store_true", help="do not unload results after reading them")
    p.add_argument("--no-cad", action="store_true", help="skip the CAD tree")
    p.add_argument("--no-getters", action="store_true", help="skip the per-feature property sweep (faster)")
    p.add_argument("--no-selection-test", action="store_true", help="skip the component selection test")
    p.add_argument("--max-components", type=int, default=2000)
    p.add_argument("--typelib-dump", help="typelib_dump.json from week 2 (default: newest one found)")
    p.add_argument("--timeout", type=float, default=120, help="seconds per COM call (default 120)")
    p.add_argument("--load-timeout", type=float, default=900, help="seconds for loading results (default 900)")
    p.add_argument("--start-timeout", type=float, default=900, help="seconds for starting FLOEFD / opening a model")
    p.add_argument("--out", help="output folder (default: export_<COMPUTER>_<time> next to this script)")
    return p.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    computer = os.environ.get("COMPUTERNAME", platform.node() or "pc")
    out_dir = args.out or os.path.join(HERE, f"export_{computer}_{stamp}")
    rec = ec.Recorder(out_dir, "floefd-week3-export", TOOL_VERSION, default_timeout=args.timeout)
    rec.report["arguments"] = vars(args)
    data: dict = {"tool": "floefd-week3-export", "tool_version": TOOL_VERSION,
                  "environment": ec.environment_info(), "projects": []}
    tables: dict = {}

    def write_all(status: str) -> None:
        rec.finish_report(status)
        rec.write_json("structure.json", data)
        t = build_tables(data)
        tables.update(t)
        write_tables(out_dir, t)
        with open(os.path.join(out_dir, "summary.md"), "w", encoding="utf-8") as f:
            f.write(render_summary(data, t, rec))

    rec.timeout_writer = write_all
    rec.log(f"FLOEFD export {TOOL_VERSION} | output: {out_dir}")
    if not ec.require_windows_com(rec):
        write_all("environment_problem")
        return 3

    dump = args.typelib_dump or ec.find_typelib_dump()
    enums = ec.EnumBook.load(dump)
    data["enum_sources"] = enums.sources
    rec.log(f"Enum sources: {enums.sources}")
    with open(os.path.join(HERE, "reference", "getter_catalog.json"), encoding="utf-8") as f:
        catalog = json.load(f)
    exp = Exporter(rec, enums, catalog, args)

    try:
        app, conn = ec.connect(rec, args.progid, args.mode, args.pid, start_timeout=args.start_timeout)
        data["connection"] = conn
        if app is None:
            write_all("connect_failed")
            return 4
        cad = rec.value("App.GetCAD", app, "GetCAD")
        doc = None
        if args.open and cad is not None:
            rec.log(f"Opening {args.open} (not saved afterwards) ...")
            okd, cad_doc = rec.invoke("CAD.OpenDoc", cad, "OpenDoc", args.open, timeout=args.start_timeout)
            if okd and cad_doc is not None:
                doc = rec.value("App.GetDocument", app, "GetDocument", cad_doc, optional=True)
        if doc is None:
            doc = rec.value("App.GetActiveDoc", app, "GetActiveDoc")
        if doc is None:
            rec.log("No FLOEFD document is open. Open the model in FLOEFD first, or pass --open <model file>.")
            write_all("no_document")
            return 5

        D: dict = {"title": rec.value("Doc.GetTitle", doc, "GetTitle")}
        model_doc = rec.value("Doc.GetCADModelDoc", doc, "GetCADModelDoc")
        if model_doc is not None:
            D["path"] = rec.value("ModelDoc.GetPathName", model_doc, "GetPathName", optional=True)
            D["type"] = enums.name("efdDocumentType", rec.value("ModelDoc.GetType", model_doc, "GetType", optional=True))
            okc, cfgs = rec.invoke("ModelDoc.GetConfigurations", model_doc, "GetConfigurations", optional=True)
            D["configurations"] = [rec.value("Config.GetName", c, "GetName", quiet=True) for c in ec.as_list(cfgs)] \
                if okc else None
            ac = rec.value("ModelDoc.GetActiveConfiguration", model_doc, "GetActiveConfiguration", optional=True)
            D["active_configuration"] = rec.value("ActiveConfig.GetName", ac, "GetName") if ac is not None else None
        data["document"] = D

        okp, projects = rec.invoke("Doc.GetProjects1", doc, "GetProjects1")
        projects = ec.as_list(projects) if okp else []
        active = rec.value("Doc.GetActiveProject", doc, "GetActiveProject")
        D["active_project"] = rec.value("ActiveProject.GetName", active, "GetName") if active is not None else None
        named = [(rec.value(f"Project[{i}].GetName", p, "GetName"), p) for i, p in enumerate(projects)]
        D["project_names"] = [n for n, _ in named]
        if args.project:
            missing = [w for w in args.project if w not in D["project_names"]]
            if missing:
                rec.log(f"Project(s) not found: {missing}. Available: {D['project_names']}")
            named = [(n, p) for n, p in named if n in args.project]
        if not named and active is not None and not args.project:
            named = [(D["active_project"], active)]

        for pname, project in named:
            data["projects"].append(exp.export_project(project, pname))
            write_all("running")      # keep partial results on disk after each project

        if not args.no_cad and model_doc is not None:
            data["cad"] = exp.export_cad(model_doc, active)
    except Exception as exc:  # noqa: BLE001
        rec.log("Unexpected error: " + ec.format_exc(exc))
        rec.report["unexpected_error"] = ec.describe_error(exc)
        write_all("unexpected_error")
        return 1

    status = "finished_with_failures" if rec.failures else "ok"
    write_all(status)
    rec.log(f"Done: {status}. {len(tables.get('parameters', []))} parameters, "
            f"{len(tables.get('features', []))} features, {len(tables.get('cad_variables', []))} CAD variables. "
            f"Open {os.path.join(out_dir, 'summary.md')}")
    return 0 if status == "ok" else 1


if __name__ == "__main__":
    sys.exit(main())
