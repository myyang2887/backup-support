/** A slider whose readout is an editable field: drag it, or type the number.
 *
 *  Two details make this behave rather than fight the user:
 *
 *  1. **A draft string while focused.** A naively controlled input that
 *     re-formats on every keystroke is unusable — typing "0.02" reformats to
 *     "0.00000" the moment you reach "0.", and the caret jumps. So while the
 *     field has focus we render the raw text the user typed and only re-sync
 *     from the store on blur.
 *  2. **Clamp the committed value, not the text.** Each valid keystroke maps
 *     to the slider immediately (clamped to range), but the text box keeps
 *     exactly what was typed until blur. Clamping mid-typing makes
 *     intermediate states like "0.0005" impossible to reach.
 *
 *  Enter commits and leaves the field; Escape reverts to the stored value.
 */
import { useRef, useState } from "react";

export interface NumberSliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  /** Fired once when a drag ends — for callers that recompute on release. */
  onCommit?: () => void;
  unit?: string;
  /** Digits shown when the field is not being edited. */
  decimals?: number;
  /** Round values onto the step grid (typed ones too). */
  snap?: boolean;
  /** Small grey text after the unit, e.g. an index readout. */
  note?: string;
  disabled?: boolean;
  /** Overrides the numeric display entirely (non-editable readout). */
  fmt?: (v: number) => string;
  /** A typed value was confirmed (Enter or leaving the field). */
  onTypedCommit?: () => void;
  /** Arrow keys on the slider call this instead of moving by `step`
   *  (lets the caller step by something smarter than a fixed increment). */
  onArrow?: (dir: 1 | -1) => void;
}

export default function NumberSlider(props: NumberSliderProps) {
  // A fixed 5 decimals cannot express 10 um (1e-5) or anything below it, and
  // silently rounds what the user typed. Pick the digits from the magnitude
  // of the step unless the caller insists.
  const dec = props.decimals ?? (() => {
    const st = Math.abs(props.step) || Math.abs(props.value) || 1;
    return Math.min(9, Math.max(3, Math.ceil(-Math.log10(st)) + 2));
  })();
  const [draft, setDraft] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const typed = useRef(false);

  const clamp = (v: number) => Math.min(props.max, Math.max(props.min, v));
  const snap = (v: number) => (props.snap && props.step > 0
    ? props.min + Math.round((v - props.min) / props.step) * props.step
    : v);
  const commit = (v: number) => props.onChange(clamp(snap(v)));

  // while typing show the raw draft; otherwise mirror the stored value
  const text = draft ?? props.value.toFixed(dec);

  const onType = (t: string) => {
    setDraft(t);
    typed.current = true;
    const v = Number(t);
    if (t.trim() !== "" && Number.isFinite(v)) commit(v);   // live mapping
  };

  return (
    <div style={{ marginTop: 8 }}>
      <div className="row" style={{ marginBottom: 2, gap: 4 }}>
        <label>{props.label}</label>
        <div className="row" style={{ marginLeft: "auto", gap: 4 }}>
          {props.note && (
            <span className="mono" style={{ fontSize: 10,
                  color: "var(--text-faint)" }}>{props.note}</span>
          )}
          {props.fmt ? (
            <span className="mono" style={{ fontSize: 11 }}>
              {props.fmt(props.value)}
            </span>
          ) : (
            <input
              ref={inputRef}
              className="mono"
              type="text"
              inputMode="decimal"
              disabled={props.disabled}
              value={text}
              title={`${props.min.toFixed(dec)} 〜 ${props.max.toFixed(dec)}`}
              style={{ width: 96, fontSize: 11, textAlign: "right",
                       padding: "1px 4px" }}
              onChange={(e) => onType(e.target.value)}
              onFocus={(e) => { setDraft(e.target.value); e.target.select();
                                typed.current = false; }}
              onBlur={() => {                    // re-sync display from store
                setDraft(null);
                if (typed.current) { typed.current = false; props.onTypedCommit?.(); }
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") { setDraft(null); inputRef.current?.blur(); }
                if (e.key === "Escape") { setDraft(null); inputRef.current?.blur(); }
              }}
            />
          )}
          {props.unit && (
            <span style={{ fontSize: 11, color: "var(--text-dim)",
                           minWidth: 14 }}>{props.unit}</span>
          )}
        </div>
      </div>
      <input
        type="range"
        min={props.min} max={props.max} step={props.step}
        disabled={props.disabled}
        value={clamp(props.value)}
        onInput={(e) => {
          setDraft(null);                        // dragging wins over a draft
          commit(+(e.target as HTMLInputElement).value);
        }}
        onPointerUp={props.onCommit}
        onKeyDown={(e) => {
          if (!props.onArrow) return;
          const dir = (e.key === "ArrowRight" || e.key === "ArrowUp") ? 1
                    : (e.key === "ArrowLeft" || e.key === "ArrowDown") ? -1 : 0;
          if (!dir) return;
          e.preventDefault();
          setDraft(null);
          props.onArrow(dir as 1 | -1);
        }}
      />
    </div>
  );
}
