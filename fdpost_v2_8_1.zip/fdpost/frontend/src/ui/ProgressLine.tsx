/** A 2-px progress line along the top edge of whatever is computing.
 *
 *  Deliberately quiet: it sits on an existing edge instead of taking a row of
 *  its own, so adding progress to a panel never pushes its layout around.
 *  Determinate when the job reports progress, a gliding segment otherwise.
 *  The parent must be `position: relative`. An optional caption (label,
 *  percent, ETA) can be shown by the caller wherever it fits; `ProgressText`
 *  formats it the same way everywhere. */
import { fmtEta, type TaskState } from "../tasks";

export default function ProgressLine({ task, inset = 0 }: {
  task: TaskState; inset?: number;
}) {
  if (!task.active) return null;
  const det = task.progress != null;
  return (
    <div role="progressbar" aria-label={task.label}
         aria-valuemin={0} aria-valuemax={100}
         aria-valuenow={det ? Math.round((task.progress as number) * 100) : undefined}
         className="progress-line" style={{ left: inset, right: inset }}>
      {det
        ? <div className="progress-line-fill"
               style={{ width: `${Math.max(2, (task.progress as number) * 100)}%` }} />
        : <div className="progress-line-glide" />}
    </div>
  );
}

export function ProgressText({ task, style }: {
  task: TaskState; style?: React.CSSProperties;
}) {
  if (!task.active) return null;
  const pct = task.progress != null ? ` ${Math.round(task.progress * 100)}%` : "…";
  const eta = fmtEta(task.etaS);
  return (
    <span className="progress-text" style={style}>
      {task.label}{pct}{eta && <span className="progress-eta"> · {eta}</span>}
    </span>
  );
}
