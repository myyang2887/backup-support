/** Long computations, one way: start a server job, follow its progress,
 *  cancel it when it is no longer wanted.
 *
 *  `useTask()` gives a component a task slot: `run(label, start)` starts the
 *  job, `cancel()` stops it (client and server), and `state` feeds a
 *  <ProgressLine>. Starting a new run cancels the previous one, so a slot
 *  never has two jobs racing to update the screen. Requests without a server
 *  job (plain fetches) can use `track(label, promise)`, which shows an
 *  indeterminate line for their duration. */
import { useCallback, useEffect, useRef, useState } from "react";

export interface JobSnap {
  id: string; status: string; progress: number; message?: string;
  result?: any; error?: string | null; elapsed_s?: number | null;
  eta_s?: number | null; has_blob?: boolean;
}

export class Cancelled extends Error {
  constructor() { super("cancelled"); this.name = "Cancelled"; }
}

const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((res, rej) => {
    const t = window.setTimeout(res, ms);
    signal?.addEventListener("abort", () => { window.clearTimeout(t); rej(new Cancelled()); },
                            { once: true });
  });

export const cancelJob = (id: string) =>
  fetch(`/api/jobs/${id}/cancel`, { method: "POST" }).catch(() => undefined);

/** Follow a job until it ends. Aborting `signal` cancels it on the server. */
export async function followJob(id: string, onProgress: (s: JobSnap) => void,
                                signal?: AbortSignal): Promise<JobSnap> {
  const onAbort = () => { void cancelJob(id); };
  signal?.addEventListener("abort", onAbort, { once: true });
  try {
    for (let i = 0; ; i++) {
      if (signal?.aborted) throw new Cancelled();
      const r = await fetch(`/api/jobs/${id}`, { signal });
      if (!r.ok) throw new Error(await r.text());
      const s: JobSnap = await r.json();
      onProgress(s);
      if (s.status === "done") return s;
      if (s.status === "cancelled") throw new Cancelled();
      if (s.status === "error") throw new Error(s.error ?? "job failed");
      await sleep(i < 8 ? 120 : 300, signal);          // quick at first, then calmer
    }
  } catch (e: any) {
    if (e?.name === "AbortError") throw new Cancelled();
    throw e;
  } finally {
    signal?.removeEventListener("abort", onAbort);
  }
}

export interface TaskState {
  active: boolean;
  label: string;
  /** 0..1, or null while the progress is unknown (indeterminate line). */
  progress: number | null;
  etaS: number | null;
}
const IDLE: TaskState = { active: false, label: "", progress: null, etaS: null };

export function useTask() {
  const [state, setState] = useState<TaskState>(IDLE);
  const ctl = useRef<AbortController | null>(null);
  const live = useRef(true);
  useEffect(() => () => { live.current = false; ctl.current?.abort(); }, []);

  const cancel = useCallback(() => {
    ctl.current?.abort();
    ctl.current = null;
    if (live.current) setState(IDLE);
  }, []);

  /** Start a server job (`start` returns its snapshot) and follow it. */
  const run = useCallback(async (label: string,
                                 start: (signal: AbortSignal) => Promise<{ id: string }>)
    : Promise<JobSnap> => {
    ctl.current?.abort();
    const c = new AbortController();
    ctl.current = c;
    setState({ active: true, label, progress: 0, etaS: null });
    try {
      const first = await start(c.signal);
      return await followJob(first.id, (s) => {
        if (live.current && ctl.current === c) {
          setState({ active: true, label, progress: s.progress, etaS: s.eta_s ?? null });
        }
      }, c.signal);
    } finally {
      if (live.current && ctl.current === c) { ctl.current = null; setState(IDLE); }
    }
  }, []);

  /** Indeterminate progress for a plain request. */
  const track = useCallback(async <T,>(label: string,
                                       fn: (signal: AbortSignal) => Promise<T>): Promise<T> => {
    ctl.current?.abort();
    const c = new AbortController();
    ctl.current = c;
    setState({ active: true, label, progress: null, etaS: null });
    try {
      return await fn(c.signal);
    } finally {
      if (live.current && ctl.current === c) { ctl.current = null; setState(IDLE); }
    }
  }, []);

  return { state, run, track, cancel };
}

export function fmtEta(s: number | null): string {
  if (s == null || !Number.isFinite(s)) return "";
  if (s < 1.5) return "まもなく";
  if (s < 90) return `残り約 ${Math.round(s)} 秒`;
  return `残り約 ${(s / 60).toFixed(1)} 分`;
}
