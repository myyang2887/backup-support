/** Plotly 2D slice view: heatmap + optional adaptive velocity arrows.
 *
 *  `detail` (optional) is an exact result for the visible part of a zoomed
 *  plot; it is drawn over the full-extent `slice`, so panning never shows
 *  holes. Zoom survives data updates (uirevision) and is reported through
 *  `onView` -- null when the plot shows everything again. */
import Plotly from "plotly.js-dist-min";
import { useEffect, useRef } from "react";
import { QuiverOptions, buildQuiver } from "./quiver";
import type { SlicePlot, ViewRange } from "./sliceSource";

export default function Contour2D(props: {
  slice: SlicePlot | null; detail?: SlicePlot | null;
  field: string; unit: string;
  clim: [number, number]; title: string; hover?: boolean;
  quiver?: QuiverOptions | null;
  /** false = draw raw cells (useful to see the true sample grid). */
  smooth?: boolean;
  /** Paint solid cells (they are null in z) instead of letting the plot
   *  background show through. null = leave them transparent. */
  solidColor?: string | null;
  /** Zoom state key: changing it resets the zoom (e.g. another axis). */
  viewKey?: string;
  onView?: (r: ViewRange | null) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const onView = useRef(props.onView);
  onView.current = props.onView;

  useEffect(() => {
    if (!ref.current || !props.slice) return;
    const s = props.slice;
    const traces: any[] = [];
    const heat = (p: SlicePlot, scale: boolean) => ({
      type: "heatmap", x: p.x, y: p.y, z: p.z,
      colorscale: "Jet", zmin: props.clim[0], zmax: props.clim[1],
      // Without zsmooth every cell is drawn as a flat rectangle, so even a
      // fine slice looks like hard colour blocks with no gradient between.
      zsmooth: props.smooth === false ? false : "best",
      showscale: scale,
      colorbar: scale ? { title: { text: `${props.field} [${props.unit}]`, side: "right" },
                          tickfont: { size: 10 } } : undefined,
      hovertemplate: props.hover
        ? "x %{x:.6f}<br>y %{y:.6f}<br>" + props.field + " %{z:.5g}<extra></extra>"
        : undefined,
      hoverinfo: props.hover ? undefined : "skip",
    });
    const mask = (p: SlicePlot) => ({
      type: "heatmap", x: p.x, y: p.y,
      z: p.z.map((row) => row.map((v) => (v === null ? 1 : null))),
      colorscale: [[0, props.solidColor], [1, props.solidColor]],
      showscale: false, hoverinfo: "skip", zsmooth: false,
    });
    // Solid cells are null in z, so a mask drawn underneath is what gives
    // explicit control over them (plot_bgcolor would also paint the outside).
    if (props.solidColor) traces.push(mask(s));
    traces.push(heat(s, true));
    const d = props.detail;
    if (d) {
      if (props.solidColor) traces.push(mask(d));
      traces.push(heat(d, false));
    }
    const vs = d ?? s;
    if (props.quiver && vs.vecU && vs.vecV) {
      const q = buildQuiver(vs.x, vs.y, vs.vecU, vs.vecV, props.quiver);
      if (q) traces.push({
        type: "scatter", mode: "lines", x: q.x, y: q.y,
        line: { color: props.quiver.color, width: 1 },
        hoverinfo: "skip", showlegend: false,
      });
    }
    Plotly.react(ref.current, traces, {
      title: { text: props.title, font: { color: "#dde1e8", size: 12 } },
      xaxis: { title: { text: s.xLabel }, scaleanchor: "y", color: "#8b93a1" },
      yaxis: { title: { text: s.yLabel }, color: "#8b93a1" },
      plot_bgcolor: "rgba(0,0,0,0)", paper_bgcolor: "#1c1f26",
      font: { color: "#dde1e8", size: 11 },
      hoverlabel: { bgcolor: "#0b0d10", bordercolor: "#2e6f85",
                    font: { family: "Consolas, monospace", size: 11,
                            color: "#dde1e8" } },
      margin: { t: 34, r: 8, b: 42, l: 52 },
      autosize: true,
      uirevision: props.viewKey ?? "slice",
    }, { responsive: true, displaylogo: false });
  }, [props.slice, props.detail, props.clim, props.field, props.unit, props.title,
      props.hover, props.quiver, props.smooth, props.solidColor, props.viewKey]);

  // zoom / pan / reset -> visible range (attached once per plot element)
  useEffect(() => {
    const el = ref.current as any;
    if (!el?.on) return;
    const h = (ev: any) => {
      if (!ev) return;
      if (ev["xaxis.autorange"] || ev["yaxis.autorange"] || ev.autosize) {
        onView.current?.(null);
        return;
      }
      const x0 = ev["xaxis.range[0]"], x1 = ev["xaxis.range[1]"];
      const y0 = ev["yaxis.range[0]"], y1 = ev["yaxis.range[1]"];
      if ([x0, x1, y0, y1].every((v) => typeof v === "number")) {
        onView.current?.({ x: [x0, x1], y: [y0, y1] });
      }
    };
    el.on("plotly_relayout", h);
    return () => { el.removeListener?.("plotly_relayout", h); };
  }, [props.slice !== null]);

  return <div ref={ref} style={{ width: "100%", height: "100%", minHeight: 220 }} />;
}
