/** What the results drawer shows for an axis slice, and when.
 *
 *    while moving     : the preview grid, blended at the exact position
 *                       (in the browser, instant)
 *    after 0.16 s     : the full preprocessing grid at the exact position
 *    after 1 s still  : (sliceExact != off)
 *                       1. IDW from the source data, 256 samples (~0.2 s)
 *                       2. local-linear from the source data, as a job
 *                          with a progress bar: 256 samples ("standard") or
 *                          as many as the plot has pixels ("high"; when
 *                          zoomed in, only the visible range)
 *
 *  A deliberate commit (typed value + Enter, slider released, arrow key
 *  released) skips the one-second wait. Any new movement cancels whatever is
 *  still computing -- on the server too -- so stale results never overwrite
 *  newer ones. Every plot says which kind of result it is.
 */
import { useEffect, useRef, useState } from "react";
import { getSliceField, getSliceFieldDirect } from "../api";
import { interpolateSlice } from "../gridSlice";
import { useStore } from "../store";
import { Cancelled, useTask, type TaskState } from "../tasks";
import type { SliceField } from "../types";

export type PlotKind = "grid-local" | "grid" | "fast" | "exact";

export interface SlicePlot {
  x: number[]; y: number[];
  z: (number | null)[][];              // [row = v][col = u]
  vecU: (number | null)[][] | null;
  vecV: (number | null)[][] | null;
  xLabel: string; yLabel: string;
  /** Position actually drawn (always the requested one since v2.8.1). */
  position: number;
  requested: number;
  dims: [number, number];
  kind: PlotKind;
  /** Sample spacing [du, dv] in metres. */
  spacing: [number, number];
  /** Exact result restricted to the visible range of a zoomed plot. */
  roi?: boolean;
}

export interface ViewRange { x: [number, number]; y: [number, number] }

const GRID_DELAY_MS = 160;
const EXACT_IDLE_MS = 1000;
const STANDARD_SAMPLES = 256;

function toRows(a: Float32Array, nu: number, nv: number): (number | null)[][] {
  const out: (number | null)[][] = new Array(nv);
  for (let iv = 0; iv < nv; iv++) {
    const row: (number | null)[] = new Array(nu);
    const base = iv * nu;
    for (let iu = 0; iu < nu; iu++) {
      const v = a[base + iu];
      row[iu] = Number.isNaN(v) ? null : v;
    }
    out[iv] = row;
  }
  return out;
}

const coords = (o: number, d: number, n: number): number[] =>
  Array.from({ length: n }, (_, i) => o + d * i);

function fromField(f: SliceField, requested: number, kind: PlotKind,
                   roi = false): SlicePlot {
  const [nu, nv] = f.dims;
  return {
    x: coords(f.origin[0], f.spacing[0], nu),
    y: coords(f.origin[1], f.spacing[1], nv),
    z: toRows(f.values, nu, nv),
    vecU: f.vecU ? toRows(f.vecU, nu, nv) : null,
    vecV: f.vecV ? toRows(f.vecV, nu, nv) : null,
    xLabel: f.labels[0], yLabel: f.labels[1],
    position: requested, requested, dims: [nu, nv], kind,
    spacing: [f.spacing[0], f.spacing[1]], roi,
  };
}

function fromPreview(): SlicePlot | null {
  const s = useStore.getState();
  const g = s.previewGrid;
  if (!g) return null;
  const a = { x: 0, y: 1, z: 2 }[s.slice.axis];
  const ua = [0, 1, 2].filter((i) => i !== a);
  const sl = interpolateSlice(g, s.slice.axis, s.slice.pos);
  return {
    x: sl.x, y: sl.y, z: sl.z, vecU: null, vecV: null,
    xLabel: sl.xLabel, yLabel: sl.yLabel, position: s.slice.pos,
    requested: s.slice.pos, dims: [sl.x.length, sl.y.length], kind: "grid-local",
    spacing: [g.spacing[ua[0]], g.spacing[ua[1]]],
  };
}

/** Fetch the binary result of a finished preview job. */
async function fetchJobSlice(dsId: string, jobId: string,
                             signal: AbortSignal): Promise<SliceField> {
  const r = await fetch(`/api/datasets/${dsId}/preview/slice_job/${jobId}`, { signal });
  if (!r.ok) throw new Error(await r.text());
  const meta = JSON.parse(r.headers.get("X-Meta") ?? "{}");
  const buf = await r.arrayBuffer();
  const n = meta.dims[0] * meta.dims[1];
  return {
    dims: meta.dims, origin: meta.origin, spacing: meta.spacing,
    labels: meta.labels, axis: meta.axis, index: meta.index,
    position: meta.position, unit: meta.unit,
    values: new Float32Array(buf, 0, n),
    vecU: meta.vectors ? new Float32Array(buf, n * 4, n) : null,
    vecV: meta.vectors ? new Float32Array(buf, n * 8, n) : null,
  };
}

export function useSliceData(withVectors: boolean, opts: {
  /** Long edge of the plot area in device pixels ("high" sample count). */
  pxLongEdge: number;
  /** Visible range when zoomed in, null when showing everything. */
  view: ViewRange | null;
}): { plot: SlicePlot | null; detail: SlicePlot | null; task: TaskState } {
  const { activeId, activeField, previewGrid, slice, drawerOpen, drawerTab,
          display, sliceCommit } = useStore();
  const [plot, setPlot] = useState<SlicePlot | null>(null);
  const [detail, setDetail] = useState<SlicePlot | null>(null);
  const task = useTask();
  const lastCommit = useRef(sliceCommit);
  const lastKey = useRef("");
  /** The full-extent exact result already on screen (skip recomputing it
   *  when a zoom is undone). */
  const baseExact = useRef("");

  const live = drawerOpen && drawerTab === "contour" && slice.submode === "axis";
  const mode = display.sliceExact;
  const pos = slice.pos;
  const highPx = Math.max(STANDARD_SAMPLES, Math.min(1600, Math.round(opts.pxLongEdge)));
  const zoomed = mode === "high" && opts.view !== null;
  const viewKey = zoomed ? JSON.stringify(opts.view) : "";

  useEffect(() => {
    if (!live || !activeId || !previewGrid) {
      setPlot(null); setDetail(null); task.cancel(); return;
    }
    const sliceKey = [activeId, activeField, slice.axis, pos, withVectors].join("|");
    const moved = sliceKey !== lastKey.current;
    lastKey.current = sliceKey;
    const committed = sliceCommit !== lastCommit.current;
    lastCommit.current = sliceCommit;

    task.cancel();                                   // stale work stops here
    const ctl = new AbortController();
    const timers: number[] = [];
    if (moved) {
      baseExact.current = "";
      setDetail(null);
      setPlot(fromPreview());                        // instant
      timers.push(window.setTimeout(async () => {
        try {
          const f = await getSliceField(activeId, activeField,
            { axis: slice.axis, position: pos, withVectors, interp: true }, ctl.signal);
          if (!ctl.signal.aborted) setPlot(fromField(f, pos, "grid"));
        } catch { /* superseded or offline: the instant paint stays */ }
      }, GRID_DELAY_MS));
    } else if (!zoomed) {
      setDetail(null);
    }

    if (mode !== "off") {
      const exact = async () => {
        try {
          if (moved) {
            const f = await getSliceFieldDirect(activeId, activeField,
              { axis: slice.axis, position: pos, withVectors, res: STANDARD_SAMPLES,
                mode: "idw" }, ctl.signal);
            if (ctl.signal.aborted) return;
            setPlot(fromField(f, pos, "fast"));
          }
          const samples = mode === "high" ? highPx : STANDARD_SAMPLES;
          const fullKey = `${sliceKey}|${samples}`;
          if (!zoomed && baseExact.current === fullKey) return;
          const body: any = { axis: slice.axis, position: pos, field: activeField,
                              samples, method: "local_linear", with_vectors: withVectors };
          if (zoomed && opts.view) { body.u_range = opts.view.x; body.v_range = opts.view.y; }
          const snap = await task.run("精確計算", (signal) =>
            fetch(`/api/datasets/${activeId}/preview/slice_job`, {
              method: "POST", headers: { "Content-Type": "application/json" },
              body: JSON.stringify(body), signal,
            }).then(async (r) => {
              if (!r.ok) throw new Error(await r.text());
              return r.json();
            }));
          if (ctl.signal.aborted) return;
          const f = await fetchJobSlice(activeId, snap.id, ctl.signal);
          if (ctl.signal.aborted) return;
          if (zoomed) setDetail(fromField(f, pos, "exact", true));
          else { setPlot(fromField(f, pos, "exact")); baseExact.current = fullKey; }
        } catch (e) {
          if (!(e instanceof Cancelled) && (e as any)?.name !== "AbortError") {
            console.warn("exact slice failed", e);
          }
        }
      };
      const wait = committed ? 0 : (moved ? EXACT_IDLE_MS : 250);
      timers.push(window.setTimeout(exact, wait));
    }
    return () => {
      timers.forEach((t) => window.clearTimeout(t));
      ctl.abort();
      task.cancel();
    };
  }, [live, activeId, activeField, slice.axis, pos, withVectors, mode, highPx,
      viewKey, sliceCommit, previewGrid]);

  return { plot, detail, task: task.state };
}

export const KIND_LABEL: Record<PlotKind, string> = {
  "grid-local": "格子(即時)",
  grid: "格子",
  fast: "精確・IDW",
  exact: "精確・局所線形",
};
