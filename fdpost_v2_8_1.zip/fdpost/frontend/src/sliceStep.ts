/** How finely the slice moves, derived from the data itself.
 *
 *  The server measures how far apart the source data is along the slice
 *  direction, as a function of position (GET /preview/spacing_profile): on a
 *  FloEFD mesh that is the layer thickness -- 0.05 mm at a wall, millimetres
 *  further out. Two things use it:
 *    - the automatic arrow-key step: one press = the next data layer;
 *    - the batch hint: which part of a sweep gets new data per slice, and
 *      which part is interpolation between data layers.
 *  Profiles are cached per dataset and direction. */
import { useEffect, useState } from "react";
import { dataBounds } from "./exportSpecs";
import { MIN_STEP_M, useStore } from "./store";
import type { SliceParams } from "./store";
import type { DatasetOut } from "./types";

export interface SpacingProfile {
  direction: number[]; origin: number[];
  t_min: number; t_max: number;
  t: number[]; spacing: number[]; spacing_p10: number[];
  spacing_min: number; spacing_max: number;
}

const AXIS = { x: 0, y: 1, z: 2 } as const;

/** Same convention as the server and the 3D gizmo:
 *  n = Rz(azimuth) Rx(tilt) [0,0,1]. */
export function eulerNormal(tiltDeg: number, azimuthDeg: number): [number, number, number] {
  const t = (tiltDeg * Math.PI) / 180, a = (azimuthDeg * Math.PI) / 180;
  return [Math.sin(a) * Math.sin(t), -Math.cos(a) * Math.sin(t), Math.cos(t)];
}

interface Req { key: string; query: string }

/** Profile request for the direction the slice currently moves along.
 *  Axis mode: position = the coordinate. Free plane: position = signed
 *  distance from the data centre along the normal (the sweep variable). */
function requestFor(id: string, meta: DatasetOut, s: SliceParams): Req {
  if (s.submode === "axis") {
    return { key: `${id}|${s.axis}`, query: `axis=${s.axis}` };
  }
  const n = eulerNormal(s.tilt, s.azimuth).map((v) => +v.toFixed(5));
  const [lo, hi] = dataBounds(meta);
  const c = [0, 1, 2].map((i) => (lo[i] + hi[i]) / 2);
  return { key: `${id}|n${n.join(",")}`,
           query: `nx=${n[0]}&ny=${n[1]}&nz=${n[2]}&ox=${c[0]}&oy=${c[1]}&oz=${c[2]}` };
}

const cache = new Map<string, SpacingProfile>();
const pending = new Map<string, Promise<void>>();
const listeners = new Set<() => void>();
const notify = () => listeners.forEach((f) => f());

function load(id: string, r: Req): void {
  if (cache.has(r.key) || pending.has(r.key)) return;
  const p = fetch(`/api/datasets/${id}/preview/spacing_profile?${r.query}`)
    .then(async (res) => {
      if (res.ok) cache.set(r.key, await res.json());
    })
    .catch(() => undefined)
    .finally(() => { pending.delete(r.key); notify(); });
  pending.set(r.key, p);
}

/** Current profile, or null while it loads (loading starts on first ask). */
export function currentProfile(): SpacingProfile | null {
  const st = useStore.getState();
  if (!st.activeId || !st.meta?.bounds) return null;
  const r = requestFor(st.activeId, st.meta, st.slice);
  const hit = cache.get(r.key);
  if (!hit) load(st.activeId, r);
  return hit ?? null;
}

export function useSpacingProfile(): { profile: SpacingProfile | null; loading: boolean } {
  const { activeId, meta, slice } = useStore();
  const [, bump] = useState(0);
  useEffect(() => {
    const f = () => bump((x) => x + 1);
    listeners.add(f);
    return () => { listeners.delete(f); };
  }, []);
  if (!activeId || !meta?.bounds) return { profile: null, loading: false };
  const r = requestFor(activeId, meta, slice);
  const hit = cache.get(r.key) ?? null;
  if (!hit) load(activeId, r);
  return { profile: hit, loading: !hit && pending.has(r.key) };
}

/** Piecewise-linear lookup, clamped at the ends. */
export function spacingAt(p: SpacingProfile, t: number,
                          which: "median" | "p10" = "median"): number {
  const ys = which === "p10" ? p.spacing_p10 : p.spacing;
  const xs = p.t;
  if (t <= xs[0]) return ys[0];
  if (t >= xs[xs.length - 1]) return ys[ys.length - 1];
  let lo = 0, hi = xs.length - 1;
  while (hi - lo > 1) {
    const m = (lo + hi) >> 1;
    if (xs[m] <= t) lo = m; else hi = m;
  }
  const w = (t - xs[lo]) / Math.max(xs[hi] - xs[lo], 1e-300);
  return ys[lo] + w * (ys[hi] - ys[lo]);
}

/** The slice's position along its direction (see requestFor). */
export function sliceT(s: SliceParams): number {
  return s.submode === "axis" ? s.pos : s.distance;
}

/** One arrow-key step in metres, at the current position. */
export function arrowStepM(): number {
  const st = useStore.getState();
  const s = st.slice;
  if (s.arrowMode === "fixed") return Math.max(MIN_STEP_M, s.arrowFixedMm / 1000);
  const p = currentProfile();
  if (p) return Math.max(MIN_STEP_M, spacingAt(p, sliceT(s), "p10"));
  // profile still loading: fall back to the preview grid pitch
  const g = st.previewGrid;
  if (g && s.submode === "axis") return Math.max(MIN_STEP_M, g.spacing[AXIS[s.axis]]);
  return g ? Math.max(MIN_STEP_M, Math.min(...g.spacing)) : 1e-3;
}

/** Move the slice by `dir` arrow steps, clamped to the data range. */
export function stepSlice(dir: number): void {
  const st = useStore.getState();
  if (!st.meta?.bounds) return;
  const s = st.slice;
  const h = arrowStepM() * dir;
  if (s.submode === "axis") {
    const a = AXIS[s.axis];
    const [lo, hi] = dataBounds(st.meta);
    st.setSlice({ pos: +Math.min(hi[a], Math.max(lo[a], s.pos + h)).toFixed(9) });
  } else {
    const p = currentProfile();
    const lo = p ? p.t_min : -Infinity, hi = p ? p.t_max : Infinity;
    st.setSlice({ distance: +Math.min(hi, Math.max(lo, s.distance + h)).toFixed(9) });
  }
}

export interface SweepSegment { from: number; to: number; dense: boolean }

/** Split a sweep [a, b] with step `step` into stretches where every slice
 *  reaches new data (step >= data spacing, dense=false) and stretches where
 *  slices fall between data layers (step < spacing, dense=true). */
export function sweepSegments(p: SpacingProfile, a: number, b: number,
                              step: number, which: "median" | "p10")
  : { segments: SweepSegment[]; minSp: number; maxSp: number } {
  const lo = Math.min(a, b), hi = Math.max(a, b);
  const n = 240;
  const segs: SweepSegment[] = [];
  let minSp = Infinity, maxSp = 0;
  for (let i = 0; i < n; i++) {
    const t0 = lo + ((hi - lo) * i) / n, t1 = lo + ((hi - lo) * (i + 1)) / n;
    const sp = spacingAt(p, 0.5 * (t0 + t1), which);
    minSp = Math.min(minSp, sp); maxSp = Math.max(maxSp, sp);
    const dense = step < sp * 0.999;
    const last = segs[segs.length - 1];
    if (last && last.dense === dense) last.to = t1;
    else segs.push({ from: t0, to: t1, dense });
  }
  return { segments: segs, minSp, maxSp };
}
