"""v2.8.1 (step 1): data-spacing profile, preview slice jobs with progress
and cancellation."""
from __future__ import annotations

import json
import time

import numpy as np
import pytest

from fdpost.domain.field_data import FieldData
from fdpost.services.field_evaluator import FieldEvaluator
from fdpost.services.jobs import JobManager

WALL = 0.12


def layered():
    nxy = 24
    h = 0.1 / nxy
    xc = (np.arange(nxy) + 0.5) * h
    zs = np.arange(0.002, WALL, 0.004)
    f, d = [WALL], 5e-5
    while f[-1] < 0.3:
        f.append(min(0.3, f[-1] + d))
        d *= 1.12
    f = np.array(f)
    z = np.concatenate([zs, 0.5 * (f[1:] + f[:-1])])
    X, Y, Z = np.meshgrid(xc, xc, z, indexing="ij")
    p = np.column_stack([X.ravel(), Y.ravel(), Z.ravel()])
    return p, h, z


# --- spacing profile ---------------------------------------------------------

def test_profile_follows_layers_and_columns():
    p, h, z = layered()
    ev = FieldEvaluator(FieldData(points=p, fields={"f": p[:, 2]},
                                  is_fluid=p[:, 2] > WALL, units={}))
    pz = ev.spacing_profile(np.array([0, 0, 1.0]))
    t, sp = np.array(pz["t"]), np.array(pz["spacing"])
    gaps = np.diff(z)
    for zq in (0.05, WALL + 2e-4, 0.14, 0.2):
        j = np.clip(np.searchsorted(z, zq) - 1, 0, len(gaps) - 1)
        assert np.interp(zq, t, sp) == pytest.approx(gaps[j], rel=0.35), zq
    px = ev.spacing_profile(np.array([1.0, 0, 0]))
    assert np.allclose(px["spacing"], h, rtol=1e-6)
    assert px["t_min"] == pytest.approx(h / 2) and px["t_max"] == pytest.approx(0.1 - h / 2)


def test_profile_tilted_plane_reaches_thin_layers():
    p, h, z = layered()
    ev = FieldEvaluator(FieldData(points=p, fields={"f": p[:, 2]},
                                  is_fluid=np.ones(len(p), bool), units={}))
    n = np.array([1.0, 0, 1.0]) / np.sqrt(2)
    pr = ev.spacing_profile(n)
    # the thinnest layer (5e-5) seen at 45 degrees: 5e-5 * cos 45
    assert min(pr["spacing_p10"]) < 2 * 5e-5 * np.sqrt(0.5)


def test_profile_on_scattered_data_is_near_point_spacing():
    rng = np.random.default_rng(1)
    pts = rng.uniform(0, 0.1, (60_000, 3))
    ev = FieldEvaluator(FieldData(points=pts, fields={"f": pts[:, 0]},
                                  is_fluid=np.ones(len(pts), bool), units={}))
    nn = 0.554 * (1e-3 / len(pts)) ** (1 / 3)       # mean nearest-neighbour distance
    med = np.median(ev.spacing_profile(np.array([0, 1.0, 0]))["spacing"])
    assert 0.5 * nn < med < 2.0 * nn


# --- jobs: progress, cancellation, ETA ------------------------------------------

def test_job_progress_cancel_and_queue():
    jm = JobManager(workers=1, interactive_workers=1)
    seen = []

    def slow(report):
        for i in range(200):
            report(i / 200, "x")
            seen.append(i)
            time.sleep(0.01)
        return {"ok": True}

    a = jm.submit("slow", slow, pool="interactive")
    b = jm.submit("slow", slow, pool="interactive")       # queued behind a
    time.sleep(0.3)
    snap = a.snapshot()
    assert snap["status"] == "running" and 0 < snap["progress"] < 1
    assert snap["eta_s"] is not None and snap["elapsed_s"] > 0
    jm.cancel(b.id)                                        # never starts
    jm.cancel(a.id)
    for _ in range(100):
        if a.status == "cancelled" and b.status == "cancelled":
            break
        time.sleep(0.02)
    assert a.status == "cancelled" and b.status == "cancelled"
    assert len(seen) < 200 and b.started is None


def test_evaluator_progress_is_monotone_and_cancellable():
    p, h, z = layered()
    ev = FieldEvaluator(FieldData(points=p, fields={"f": p[:, 2]},
                                  is_fluid=np.ones(len(p), bool), units={}))
    g = np.linspace(0.01, 0.09, 200)
    gx, gy = np.meshgrid(g, g, indexing="ij")
    q = np.column_stack([gx.ravel(), gy.ravel(), np.full(gx.size, WALL + 3e-4)])
    st, _ = ev.classify(q)
    fr = []
    ev.evaluate(["f"], q, st, progress=fr.append)
    assert fr and fr[-1] == pytest.approx(1.0) and np.all(np.diff(fr) >= 0)

    class Stop(Exception):
        pass

    def stopper(x):
        if x > 0.3:
            raise Stop

    with pytest.raises(Stop):
        ev.evaluate(["f"], q, st, progress=stopper)


# --- API -------------------------------------------------------------------------

def _wait(c, jid, timeout=120):
    t0 = time.time()
    while time.time() - t0 < timeout:
        j = c.get(f"/api/jobs/{jid}").json()
        if j["status"] in ("done", "error", "cancelled"):
            return j
        time.sleep(0.05)
    raise TimeoutError


def test_preview_slice_job_matches_direct_and_reports_progress(api_client, api_dataset):
    c, _ = api_client
    ds = api_dataset
    body = {"axis": "z", "position": 0.437, "field": "pressure", "samples": 64,
            "method": "local_linear"}
    r = c.post(f"/api/datasets/{ds}/preview/slice_job", json=body)
    assert r.status_code == 200, r.text
    j = _wait(c, r.json()["id"])
    assert j["status"] == "done" and j["has_blob"] and j["progress"] == 1.0
    d = c.get(f"/api/datasets/{ds}/preview/slice_job/{j['id']}")
    meta = json.loads(d.headers["X-Meta"])
    a = np.frombuffer(d.content, np.float32)
    assert meta["position"] == pytest.approx(0.437) and max(meta["dims"]) == 64
    direct = c.get(f"/api/datasets/{ds}/preview/slice_direct/pressure",
                   params={"axis": "z", "position": 0.437, "res": 64, "mode": "hifi"})
    b = np.frombuffer(direct.content, np.float32)
    assert np.allclose(a, b, equal_nan=True)
    again = c.get(f"/api/datasets/{ds}/preview/slice_job/{j['id']}")
    assert again.status_code == 409                       # fetched once, then freed


def test_preview_slice_job_roi_and_cancel(api_client, api_dataset):
    c, _ = api_client
    ds = api_dataset
    r = c.post(f"/api/datasets/{ds}/preview/slice_job", json={
        "axis": "z", "position": 0.5, "field": "pressure", "samples": 50,
        "method": "idw", "u_range": [0.2, 0.4], "v_range": [0.6, 0.7]})
    j = _wait(c, r.json()["id"])
    meta = json.loads(c.get(f"/api/datasets/{ds}/preview/slice_job/{j['id']}")
                      .headers["X-Meta"])
    x0, y0 = meta["origin"]
    nu, nv = meta["dims"]
    du, dv = meta["spacing"]
    assert x0 == pytest.approx(0.2, abs=1e-9) and y0 == pytest.approx(0.6, abs=1e-9)
    assert x0 + du * (nu - 1) == pytest.approx(0.4, abs=1e-9)
    assert nu == 50 and meta["roi"] is True
    # a large local-linear job, cancelled right away, ends as "cancelled"
    r = c.post(f"/api/datasets/{ds}/preview/slice_job", json={
        "axis": "z", "position": 0.5, "field": "pressure", "samples": 1500,
        "method": "local_linear"})
    jid = r.json()["id"]
    c.post(f"/api/jobs/{jid}/cancel")
    assert _wait(c, jid)["status"] == "cancelled"


def test_spacing_profile_endpoint(api_client, api_dataset):
    c, _ = api_client
    j = c.get(f"/api/datasets/{api_dataset}/preview/spacing_profile",
              params={"axis": "x"}).json()
    assert len(j["t"]) == len(j["spacing"]) == len(j["spacing_p10"]) > 10
    assert all(s > 0 for s in j["spacing"])
    j2 = c.get(f"/api/datasets/{api_dataset}/preview/spacing_profile",
               params={"nx": 0, "ny": 1, "nz": 1, "ox": 0.5, "oy": 0.5, "oz": 0.5}).json()
    assert j2["t_min"] < 0 < j2["t_max"]
    bad = c.get(f"/api/datasets/{api_dataset}/preview/spacing_profile",
                params={"nx": 0, "ny": 0, "nz": 0})
    assert bad.status_code == 400


def test_grid_preview_interpolates_at_the_exact_position(api_client, api_dataset):
    """interp=1: values at exactly `position`, between two grid planes; the
    default keeps the nearest-plane behaviour (and says it snapped)."""
    c, _ = api_client
    ds = api_dataset
    m = c.get(f"/api/datasets/{ds}/preview/meta").json()
    z0, dz = m["origin"][2], (m["bounds"][1][2] - m["bounds"][0][2]) / (m["full_dims"][2] - 1)
    zq = z0 + dz * 10.37

    def get(interp):
        r = c.get(f"/api/datasets/{ds}/preview/slice/pressure",
                  params={"axis": "z", "position": zq, "interp": interp})
        meta = json.loads(r.headers["X-Meta"])
        return np.frombuffer(r.content, np.float32), meta

    a, ma = get(True)
    b, mb = get(False)
    assert ma["position"] == pytest.approx(zq) and ma["snapped"] is False
    assert mb["snapped"] is True and mb["position"] != pytest.approx(zq)
    lo, _ = get_plane(c, ds, z0 + dz * 10)
    hi, _ = get_plane(c, ds, z0 + dz * 11)
    want = 0.63 * lo + 0.37 * hi
    ok = np.isfinite(a) & np.isfinite(want)
    assert ok.mean() > 0.5 and np.allclose(a[ok], want[ok], rtol=1e-5, atol=1e-5)


def get_plane(c, ds, z):
    r = c.get(f"/api/datasets/{ds}/preview/slice/pressure", params={"axis": "z", "position": z})
    return np.frombuffer(r.content, np.float32), json.loads(r.headers["X-Meta"])
