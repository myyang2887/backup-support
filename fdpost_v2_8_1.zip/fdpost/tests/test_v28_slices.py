"""v2.8 slice acceptance tests.

Numbered after the improvement plan (T01-T20). They check correct values and
observable behaviour, not only shapes or HTTP 200. Three data families are
used so the evaluator is not tuned to one dataset:

  iso   - isotropic random scatter
  wall  - Cartesian lattice with a solid substrate below z = 0.120 m
  layer - Cartesian lattice with thin layers near a wall (strong anisotropy)
"""
from __future__ import annotations

import io
import json
import time
import zipfile
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

from fdpost.domain.field_data import FieldData
from fdpost.services.field_evaluator import (FLUID, OUTSIDE, SOLID, FieldEvaluator)

WALL = 0.120


# --- data families -----------------------------------------------------------

def lattice_wall(nx=30, ny=25, nz=80, ext=(0.1, 0.1, 0.3)):
    """Cell-centred lattice; solid below the substrate top z = 0.120 m."""
    xs = [(np.arange(n) + 0.5) * e / n for n, e in zip((nx, ny, nz), ext)]
    X, Y, Z = np.meshgrid(*xs, indexing="ij")
    p = np.column_stack([X.ravel(), Y.ravel(), Z.ravel()])
    return p, p[:, 2] > WALL


def lattice_layers(nxy=24, dz0=5e-5, growth=1.12, top=0.18):
    h = 0.1 / nxy
    xc = (np.arange(nxy) + 0.5) * h
    f, d = [WALL], dz0
    while f[-1] < top:
        f.append(min(top, f[-1] + d))
        d *= growth
    f = np.array(f)
    zc = 0.5 * (f[1:] + f[:-1])
    X, Y, Z = np.meshgrid(xc, xc, zc, indexing="ij")
    return np.column_stack([X.ravel(), Y.ravel(), Z.ravel()])


def scatter_iso(n=40_000, seed=3):
    return np.random.default_rng(seed).uniform([0, 0, 0], [0.1, 0.1, 0.3], (n, 3))


def affine(p):
    return 1.0 + 2.0 * p[:, 0] - 3.0 * p[:, 1] + 1000.0 * p[:, 2]


def write_tsv(path: Path, pts: np.ndarray, fields: dict[str, np.ndarray],
              fluid: np.ndarray) -> Path:
    cols = ["X (m)", "Y (m)", "Z (m)"] + list(fields) + ["Fluid"]
    lines = ["\t".join(cols)]
    arr = [pts[:, 0], pts[:, 1], pts[:, 2]] + list(fields.values()) + [fluid.astype(int)]
    for row in zip(*arr):
        lines.append("\t".join("" if (isinstance(v, float) and v != v)
                               else f"{v:.10g}" for v in row))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def upload(c, path: Path, dims: int = 32) -> str:
    with open(path, "rb") as f:
        r = c.post("/api/datasets/upload", files={"file": (path.name, f, "text/plain")},
                   data={"method": "idw", "target_dims": str(dims)})
    assert r.status_code == 200, r.text
    ds, job = r.json()["dataset_id"], r.json()["job_id"]
    for _ in range(600):
        j = c.get(f"/api/jobs/{job}").json()
        if j["status"] in ("done", "error"):
            assert j["status"] == "done", j
            return ds
        time.sleep(0.1)
    raise TimeoutError


def wait_job(c, jid: str) -> dict:
    for _ in range(1200):
        j = c.get(f"/api/jobs/{jid}").json()
        if j["status"] in ("done", "error"):
            return j
        time.sleep(0.1)
    raise TimeoutError


@pytest.fixture(scope="module")
def wall_ds(api_client, tmp_path_factory):
    c, _ = api_client
    p, fluid = lattice_wall()
    fz = 1000.0 * p[:, 2]
    vel = np.where(fluid, np.sin(40 * p[:, 0]) + p[:, 2], np.nan)
    path = write_tsv(tmp_path_factory.mktemp("wall") / "wall.txt", p,
                     {"Fz (-)": np.where(fluid, fz, np.nan),
                      "Temperature (K)": 300 + 100 * p[:, 2],
                      "Velocity (X) (m/s)": vel, "Velocity (Y) (m/s)": 0 * vel,
                      "Velocity (Z) (m/s)": 0.5 * vel}, fluid)
    return upload(c, path), path


def export(c, ds, body, stream=False):
    q = "?deliver=stream" if stream else ""
    return c.post(f"/api/datasets/{ds}/slices/export{q}", json=body)


def manifest_of(c, j) -> dict:
    url = j.get("manifest_url")
    assert url, j
    return c.get(url).json()


def zip_members(r) -> dict[str, bytes]:
    z = zipfile.ZipFile(io.BytesIO(r.content))
    return {n: z.read(n) for n in z.namelist()}


# --- T01 / T02 / T03: evaluator correctness -----------------------------------

@pytest.mark.parametrize("family", ["iso", "wall", "layer"])
def test_T01_constant_field_stays_constant(family):
    p = {"iso": scatter_iso(), "wall": lattice_wall()[0], "layer": lattice_layers()}[family]
    fd = FieldData(points=p, fields={"f": np.full(len(p), 7.25)},
                   is_fluid=np.ones(len(p), bool), units={})
    ev = FieldEvaluator(fd)
    q = np.random.default_rng(0).uniform(p.min(0), p.max(0), (3000, 3))
    st, _ = ev.classify(q)
    v = ev.evaluate(["f"], q, st).values["f"][st == FLUID]
    assert v.size > 0 and np.max(np.abs(v / 7.25 - 1)) <= 1e-10


@pytest.mark.parametrize("family", ["iso", "wall", "layer"])
def test_T02_affine_field_is_reproduced(family):
    p = {"iso": scatter_iso(), "wall": lattice_wall()[0], "layer": lattice_layers()}[family]
    fd = FieldData(points=p, fields={"f": affine(p)}, is_fluid=np.ones(len(p), bool),
                   units={})
    ev = FieldEvaluator(fd)
    q = np.random.default_rng(1).uniform(p.min(0), p.max(0), (4000, 3))
    st, _ = ev.classify(q)
    e = ev.evaluate(["f"], q, st)
    lin = np.isin(e.quality, [1, 2]) & (st == FLUID)
    assert lin.mean() > 0.95, e.counts
    err = np.abs(e.values["f"][lin] - affine(q)[lin]) / np.ptp(affine(p))
    assert err.max() <= 1e-8


def test_T02_thin_layers_use_balanced_neighbourhoods():
    """The isotropic neighbourhood degenerates on thin layers; the adaptive
    path must take over there (and is recorded per sample)."""
    p = lattice_layers()
    fd = FieldData(points=p, fields={"f": affine(p)}, is_fluid=np.ones(len(p), bool),
                   units={})
    ev = FieldEvaluator(fd)
    g = np.linspace(0.01, 0.09, 40)
    gx, gy = np.meshgrid(g, g, indexing="ij")
    q = np.column_stack([gx.ravel(), gy.ravel(), np.full(gx.size, WALL + 5e-4)])
    st, _ = ev.classify(q)
    e = ev.evaluate(["f"], q, st)
    assert e.counts.get("local_linear_balanced", 0) > 0.5 * len(q)
    assert np.max(np.abs(e.values["f"] - affine(q))) / np.ptp(affine(p)) <= 1e-8


def test_T03_row_order_does_not_change_the_result():
    p, fluid = lattice_wall()
    f = np.sin(30 * p[:, 0]) * np.cos(20 * p[:, 1]) + 50 * p[:, 2]
    q = np.random.default_rng(2).uniform(p.min(0), p.max(0), (3000, 3))
    outs = []
    for perm in (np.arange(len(p)), np.arange(len(p))[::-1],
                 np.random.default_rng(9).permutation(len(p))):
        fd = FieldData(points=p[perm], fields={"f": f[perm]}, is_fluid=fluid[perm], units={})
        ev = FieldEvaluator(fd)
        st, _ = ev.classify(q)
        outs.append((st, ev.evaluate(["f"], q, st).values["f"]))
    for st, v in outs[1:]:
        assert (st == outs[0][0]).all()
        assert np.nanmax(np.abs(v - outs[0][1])) <= 1e-9


# --- T04 / E05 / E07: substrate cut ---------------------------------------------

def test_T04_cut_above_substrate_is_fluid_and_exact(api_client, wall_ds):
    """E05 + E07 replay: f = 1000 z on a cut 1 mm above the substrate must be
    the constant 121, and nothing on that cut may be painted solid."""
    c, _ = api_client
    ds, _ = wall_ds
    r = export(c, ds, {"mode": "axis", "axis": "z", "position": 0.121, "field": "fz",
                       "sampling": {"mode": "long_edge", "long_edge_samples": 64},
                       "formats": ["npz", "json"]})
    assert r.status_code == 200, r.text
    j = r.json()
    z = np.load(Path(j["npz"]))
    assert (z["state"] == FLUID).all()
    assert np.max(np.abs(z["values"] - 121.0)) <= 121.0 * 1e-8
    assert j["classification_summary"]["counts"]["solid"] == 0


def test_T05_solid_region_values_are_not_blended_with_fluid(api_client, wall_ds):
    """Temperature exists in fluid and solid: a solid sample uses only solid
    points and a fluid sample only fluid points."""
    c, _ = api_client
    ds, _ = wall_ds
    r = export(c, ds, {"mode": "axis", "axis": "y", "position": 0.05,
                       "field": "temperature",
                       "sampling": {"mode": "long_edge", "long_edge_samples": 120},
                       "formats": ["npz"]})
    j = r.json()
    z = np.load(Path(j["npz"]))
    w = z["col_z_m"].reshape(z["values"].shape)
    exact = 300 + 100 * w
    for code in (FLUID, SOLID):
        m = z["state"] == code
        assert m.any()
        assert np.max(np.abs(z["values"][m] - exact[m])) <= 1e-6


# --- T06 / E12: oblique cut outside the data box -------------------------------

def test_T06_oblique_plane_outside_the_box_is_outside(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    body = {"mode": "point_normal", "origin": [0.05, 0.05, 0.2], "normal": [1, 0, 1],
            "extent_u": [-0.12, 0.12], "extent_v": [-0.12, 0.12],
            "field": "temperature", "sampling": {"mode": "counts", "counts": [60, 60]},
            "formats": ["npz", "csv", "png"]}
    j = export(c, ds, body).json()
    z = np.load(Path(j["npz"]))
    pts = np.column_stack([z["col_x_m"], z["col_y_m"], z["col_z_m"]])
    lo, hi = np.array([0, 0, 0]), np.array([0.1, 0.1, 0.3])
    far = ((pts < lo - 0.01) | (pts > hi + 0.01)).any(1)
    st = z["state"].ravel()
    assert far.any() and (st[far] == OUTSIDE).all()
    assert np.isnan(z["values"].ravel()[far]).all()
    import pandas as pd
    df = pd.read_csv(j["csv"])
    assert (df.loc[far, "state"] == "outside").all()
    assert df.loc[far, "temperature"].isna().all()


# --- T07 / E09 / E10: empty, all-solid, point-normal titles ---------------------

def test_T07_all_solid_cut_exports_with_a_status(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    r = export(c, ds, {"mode": "axis", "axis": "z", "position": 0.05,
                       "field": "velocity_magnitude", "formats": ["png", "json"],
                       "sampling": {"mode": "long_edge", "long_edge_samples": 64}})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["render_actual"]["clim"] is None and j["render_actual"]["colorbar"] is False
    assert j["classification_summary"]["counts"]["fluid"] == 0
    r = export(c, ds, {"mode": "axis", "axis": "z", "position": 0.2,
                       "field": "no_such_field", "formats": ["png"]})
    assert r.status_code == 404


def test_E10_point_normal_export_renders_its_title(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    r = export(c, ds, {"mode": "point_normal", "origin": [0.05, 0.05, 0.2],
                       "normal": [0, 0.3, 1], "field": "temperature",
                       "sampling": {"mode": "long_edge", "long_edge_samples": 48},
                       "formats": ["png"]})
    assert r.status_code == 200, r.text


# --- T08: exact position --------------------------------------------------------

def test_T08_position_is_kept_exactly_unless_snapping_is_asked(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    base = {"mode": "axis", "axis": "z", "position": 0.120000, "field": "temperature",
            "sampling": {"mode": "long_edge", "long_edge_samples": 32}, "formats": ["npz"]}
    j = export(c, ds, base).json()
    assert abs(j["geometry_actual"]["position_m"] - 0.12) <= 1e-9
    assert j["geometry_actual"]["snapped_to_grid"] is False
    j2 = export(c, ds, {**base, "snap_to_grid": True}).json()
    g = c.get(f"/api/datasets/{ds}/preview/meta").json()
    k = round((0.12 - g["origin"][2]) / g["spacing"][2])
    snapped = g["origin"][2] + g["spacing"][2] * k
    assert j2["geometry_actual"]["snapped_to_grid"] is True
    assert abs(j2["geometry_actual"]["position_m"] - snapped) < 1e-6
    assert j2["geometry_requested"]["position_m"] == 0.12
    r = export(c, ds, {**base, "position": 0.5})
    assert r.status_code == 400 and "outside the data range" in r.text


# --- T09 / E11: ROI ---------------------------------------------------------------

def test_T09_roi_is_respected_with_the_stated_endpoint_rule(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    roi = {"mode": "euler", "tilt_deg": 30, "azimuth_deg": 20, "distance": 0.0,
           "extent_u": [-0.01, 0.01], "extent_v": [-0.01, 0.01], "field": "temperature"}
    j = export(c, ds, {**roi, "sampling": {"mode": "counts", "counts": [21, 21]},
                       "formats": ["npz"]}).json()
    z = np.load(Path(j["npz"]))
    assert z["u_m"][0] == -0.01 and z["u_m"][-1] == 0.01 and z["u_m"].size == 21
    j = export(c, ds, {**roi, "sampling": {"mode": "spacing", "spacing_m": [0.003, 0.003]},
                       "formats": ["npz"]}).json()
    z = np.load(Path(j["npz"]))
    assert np.allclose(np.diff(z["u_m"]), 0.003)
    assert z["u_m"][0] == -0.01 and z["u_m"][-1] <= 0.01 + 1e-12


# --- T10: equivalent plane definitions --------------------------------------------

def test_T10_axis_and_point_normal_definitions_agree(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    common = {"field": "temperature", "formats": ["npz"],
              "sampling": {"mode": "counts", "counts": [25, 25]}}
    a = np.load(Path(export(c, ds, {"mode": "axis", "axis": "z", "position": 0.2,
                                     **common}).json()["npz"]))
    b = np.load(Path(export(c, ds, {"mode": "point_normal", "origin": [0.05, 0.05, 0.2],
                                     "normal": [0, 0, 1], **common}).json()["npz"]))

    def keyed(z):
        pts = np.column_stack([z["col_x_m"], z["col_y_m"]]).round(9)
        order = np.lexsort((pts[:, 1], pts[:, 0]))
        return pts[order], z["values"].ravel()[order]

    pa, va = keyed(a)
    pb, vb = keyed(b)
    assert np.allclose(pa, pb, atol=1e-9)
    assert np.nanmax(np.abs(va - vb)) <= 1e-9


# --- T11 / T12 / E02: batch parameters take effect, batch == single ---------------

def test_T11_free_plane_batch_honours_quality_parameters(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    base = {"mode": "euler", "tilt_deg": 20, "azimuth_deg": 0, "distance": 0.0,
            "distance_start": -0.01, "distance_stop": 0.01, "distance_step": 0.01,
            "field": "temperature",
            "sampling": {"mode": "long_edge", "long_edge_samples": 72},
            "render": {"long_edge_px": 600, "dpi": 100}}
    out = {}
    for src in ("original", "grid"):
        r = c.post(f"/api/datasets/{ds}/slices/plane-batch",
                   json={**base, "evaluation": {"source": src}})
        j = wait_job(c, r.json()["id"])
        assert j["status"] == "done", j
        man = json.loads(zipfile.ZipFile(j["result"]["zip"]).read("manifest.json"))
        out[src] = man
        assert man["n_done"] == 3
        for it in man["items"]:
            assert max(it["sample_shape"]) == 72
            assert max(it["render_actual"]["image_width_px"],
                       it["render_actual"]["image_height_px"]) == 600
    assert "local_linear" in out["original"]["items"][0]["method_used"] or \
        "local_linear_balanced" in out["original"]["items"][0]["method_used"]
    assert "grid_trilinear" in out["grid"]["items"][0]["method_used"]


def test_T12_batch_item_matches_the_single_export(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    spec = {"sampling": {"mode": "long_edge", "long_edge_samples": 40},
            "render": {"long_edge_px": 500, "dpi": 100}}
    r = c.post(f"/api/datasets/{ds}/slices/axis-batch",
               json={"axis": "z", "start": 0.2, "stop": 0.2, "step": 0.01,
                     "field": "temperature", **spec})
    j = wait_job(c, r.json()["id"])
    man = json.loads(zipfile.ZipFile(j["result"]["zip"]).read("manifest.json"))
    single = export(c, ds, {"mode": "axis", "axis": "z", "position": 0.2,
                            "field": "temperature", **spec, "formats": ["png"]}).json()
    it = man["items"][0]
    assert it["geometry_actual"] == single["geometry_actual"]
    assert it["method_used"] == single["method_used"]
    assert it["sample_shape"] == single["dims"]


# --- T13 / T14: DPI independence and exact pixels ----------------------------------

def test_T13_dpi_never_changes_the_numbers(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    base = {"mode": "axis", "axis": "y", "position": 0.05, "field": "temperature",
            "sampling": {"mode": "long_edge", "long_edge_samples": 80},
            "formats": ["png", "csv"]}
    a = zip_members(export(c, ds, {**base, "render": {"long_edge_px": 900, "dpi": 150}},
                           stream=True))
    b = zip_members(export(c, ds, {**base, "render": {"long_edge_px": 900, "dpi": 600}},
                           stream=True))
    assert a["slice.csv"] == b["slice.csv"]
    ia, ib = (Image.open(io.BytesIO(x["slice.png"])) for x in (a, b))
    assert max(ia.size) == max(ib.size) == 900          # pixels mode: dpi = label only
    pa = zip_members(export(c, ds, {**base, "render": {"size_mode": "print",
                     "print_long_edge_mm": 100, "dpi": 150}}, stream=True))
    pb = zip_members(export(c, ds, {**base, "render": {"size_mode": "print",
                     "print_long_edge_mm": 100, "dpi": 300}}, stream=True))
    sa = max(Image.open(io.BytesIO(pa["slice.png"])).size)
    sb = max(Image.open(io.BytesIO(pb["slice.png"])).size)
    assert sb == round(100 / 25.4 * 300) and sa == round(100 / 25.4 * 150)


@pytest.mark.parametrize("axis,show_axes", [("z", True), ("y", True), ("y", False)])
def test_T14_png_long_edge_is_exact(api_client, wall_ds, axis, show_axes):
    c, _ = api_client
    ds, _ = wall_ds
    j = export(c, ds, {"mode": "axis", "axis": axis, "position": 0.05,
                       "field": "temperature",
                       "sampling": {"mode": "long_edge", "long_edge_samples": 64},
                       "render": {"long_edge_px": 1500, "dpi": 300, "show_axes": show_axes},
                       "formats": ["png"]}).json()
    ra = j["render_actual"]
    with Image.open(j["png"]) as im:
        assert max(im.size) == 1500
        assert (im.size[0], im.size[1]) == (ra["image_width_px"], ra["image_height_px"])
    assert ra["field_width_px"] <= ra["image_width_px"]


# --- T15: masks ---------------------------------------------------------------------

def test_T15_solid_layer_colour_transparency_and_no_dark_seams(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    base = {"mode": "axis", "axis": "y", "position": 0.05, "field": "temperature",
            "sampling": {"mode": "long_edge", "long_edge_samples": 150},
            "formats": ["png"]}
    j = export(c, ds, {**base, "render": {"long_edge_px": 800, "dpi": 100,
                                          "show_axes": False, "cmap": "viridis",
                                          "solid_color": "#ff0000"}}).json()
    im = np.asarray(Image.open(j["png"]).convert("RGB")).astype(int)
    red = (im[..., 0] > 240) & (im[..., 1] < 15) & (im[..., 2] < 15)
    assert 0.25 < red.mean() < 0.55                     # z < 0.12 of 0.3 is solid
    black = (im.sum(-1) < 30)
    assert black.sum() == 0                              # no black seams / bad colour
    j = export(c, ds, {**base, "render": {"long_edge_px": 800, "dpi": 100,
                                          "show_axes": False, "show_solid": False,
                                          "transparent_background": True}}).json()
    rgba = np.asarray(Image.open(j["png"]).convert("RGBA"))
    assert rgba[..., 3].min() >= 0 and (rgba[..., 3] == 255).mean() > 0.9


# --- T16: colour range ---------------------------------------------------------------

def test_T16_batch_shares_one_range_and_fixed_range_is_kept(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    r = c.post(f"/api/datasets/{ds}/slices/axis-batch",
               json={"axis": "z", "start": 0.15, "stop": 0.25, "step": 0.05,
                     "field": "temperature",
                     "sampling": {"mode": "long_edge", "long_edge_samples": 32},
                     "render": {"long_edge_px": 400, "dpi": 100}})
    man = json.loads(zipfile.ZipFile(wait_job(c, r.json()["id"])["result"]["zip"])
                     .read("manifest.json"))
    clims = {tuple(it["render_actual"]["clim"]) for it in man["items"]}
    assert len(clims) == 1 and man["clim_used"] is not None
    j = export(c, ds, {"mode": "axis", "axis": "z", "position": 0.2, "field": "temperature",
                       "render": {"clim": [310, 330], "clim_mode": "fixed",
                                  "long_edge_px": 400, "dpi": 100},
                       "sampling": {"mode": "long_edge", "long_edge_samples": 32},
                       "formats": ["png"]}).json()
    assert j["render_actual"]["clim"] == [310, 330]


# --- T17: budgets refuse instead of shrinking ------------------------------------------

def test_T17_over_budget_requests_are_refused(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    r = export(c, ds, {"mode": "axis", "axis": "z", "position": 0.2, "field": "temperature",
                       "sampling": {"mode": "long_edge", "long_edge_samples": 4096},
                       "formats": ["png"]})
    assert r.status_code == 413 and "exceeds the limit" in r.text
    r = export(c, ds, {"mode": "axis", "axis": "z", "position": 0.2, "field": "temperature",
                       "render": {"long_edge_px": 15000}, "formats": ["png"]})
    assert r.status_code == 413
    r = export(c, ds, {"mode": "axis", "axis": "z", "position": 0.2, "field": "temperature",
                       "resolution": 64, "sampling": {"long_edge_samples": 64},
                       "formats": ["png"]})
    assert r.status_code == 400 and "not both" in r.text


# --- T18 / T19: source availability and cache keys ---------------------------------------

def test_T18_T19_missing_source_fails_loudly_and_changes_invalidate(api_client,
                                                                    tmp_path):
    c, _ = api_client
    p, fluid = lattice_wall(10, 10, 20)
    path = write_tsv(tmp_path / "small.txt", p,
                     {"Temperature (K)": 300 + 100 * p[:, 2]}, fluid)
    ds = upload(c, path, dims=16)
    body = {"mode": "axis", "axis": "z", "position": 0.2, "field": "temperature",
            "sampling": {"mode": "long_edge", "long_edge_samples": 16}, "formats": ["npz"]}
    store = c.app.state.store
    info = store.info(ds)
    src = Path(info.source_path)
    a = store.get_evaluator(ds)
    assert store.get_evaluator(ds) is a                  # cached
    write_tsv(src, p, {"Temperature (K)": 500 + 100 * p[:, 2]}, fluid)
    b = store.get_evaluator(ds)
    assert b is not a                                    # new signature -> new fit
    v = np.load(Path(export(c, ds, body).json()["npz"]))["values"]
    assert np.nanmin(v) > 500                            # never the stale values
    src.unlink()
    r = export(c, ds, body)
    assert r.status_code == 400 and "not readable" in r.text
    r = export(c, ds, {**body, "evaluation": {"source": "grid"}})
    assert r.status_code == 200                          # grid output still works


# --- T20: partial failure ------------------------------------------------------------------

def test_T20_batch_reports_failed_items_and_ships_the_rest(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    r = c.post(f"/api/datasets/{ds}/slices/axis-batch",
               json={"axis": "z", "start": 0.20, "stop": 0.32, "step": 0.05,
                     "field": "temperature",
                     "sampling": {"mode": "long_edge", "long_edge_samples": 24},
                     "render": {"long_edge_px": 300, "dpi": 100}})
    j = wait_job(c, r.json()["id"])
    res = j["result"]
    assert res["status"] == "partial" and res["n_slices"] == 2
    assert len(res["failed"]) == 1 and "outside the data range" in res["failed"][0]["error"]
    names = zipfile.ZipFile(res["zip"]).namelist()
    assert "manifest.json" in names and len([n for n in names if n.endswith(".png")]) == 2


# --- preview endpoints ----------------------------------------------------------------------

def test_preview_direct_reports_caps_and_method(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    r = c.get(f"/api/datasets/{ds}/preview/slice_direct/temperature",
              params={"axis": "z", "position": 0.2, "res": 5000})
    m = json.loads(r.headers["X-Meta"])
    assert m["capped"] is True and m["requested_px"] == 5000
    assert max(m["dims"]) <= c.app.state.settings.slice_direct_max_px
    j = c.get(f"/api/datasets/{ds}/preview/slice_native/temperature",
              params={"axis": "z", "position": 0.2}).json()
    assert abs(j["spacing_u_m"] - 0.1 / 30) < 1e-6 and abs(j["spacing_v_m"] - 0.1 / 25) < 1e-6


def test_original_source_plane_csv(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    r = c.post(f"/api/datasets/{ds}/region/plane",
               json={"mode": "point_normal", "origin": [0.05, 0.05, 0.2],
                     "normal": [0, 0, 1], "resolution": [10, 12],
                     "fields": ["temperature", "fz"], "source": "original"})
    assert r.status_code == 200, r.text
    assert r.json()["n_rows"] == 120 and r.json()["source"] == "original"


# --- frontend contract: the exact bodies exportSpecs.ts builds ------------------

def _ui_specs(source="original", method="local_linear"):
    ev = {"source": "original", "method": method} if source == "original" \
        else {"source": "grid"}
    return {"sampling": {"mode": "long_edge", "long_edge_samples": 96},
            "evaluation": ev,
            "render": {"size_mode": "pixels", "long_edge_px": 700, "dpi": 300,
                       "show_solid": True, "solid_color": "#000000",
                       "transparent_background": False, "show_axes": True}}


@pytest.mark.parametrize("source,method", [("original", "local_linear"),
                                           ("original", "idw"), ("grid", None)])
def test_ui_export_dialog_body(api_client, wall_ds, source, method):
    c, _ = api_client
    ds, _ = wall_ds
    body = {"mode": "axis", "axis": "z", "position": 0.123456, "field": "temperature",
            "with_vectors": False, "formats": ["png", "json", "csv"],
            **_ui_specs(source, method or "local_linear")}
    r = export(c, ds, body, stream=True)
    assert r.status_code == 200, r.text
    summ = json.loads(r.headers["X-Fdpost-Summary"])
    assert abs(summ["position_m"] - 0.123456) < 1e-12
    assert max(summ["image_px"]) == 700 and max(summ["dims"]) == 96
    names = set(zip_members(r))
    assert {"slice.png", "slice.csv", "manifest.json"} <= names


def test_ui_free_plane_render_and_batches(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    sp = _ui_specs()
    geo = {"mode": "euler", "tilt_deg": 25, "azimuth_deg": 10, "distance": 0.01}
    r = c.post(f"/api/datasets/{ds}/slices/plane",
               json={**geo, "field": "temperature", "sampling": sp["sampling"],
                     "evaluation": sp["evaluation"],
                     "render": {**sp["render"], "long_edge_px": 800, "dpi": 150}})
    assert r.status_code == 200, r.text
    assert r.json()["file_url"].endswith(".png")
    for path, body in (
        ("axis-batch", {"axis": "z", "start": 0.15, "stop": 0.2, "step": 0.05,
                        "field": "temperature", "with_vectors": False, **sp}),
        ("plane-batch", {**geo, "distance": 0, "field": "temperature",
                         "with_vectors": False, "distance_start": -0.01,
                         "distance_stop": 0.01, "distance_step": 0.01, **sp})):
        rr = c.post(f"/api/datasets/{ds}/slices/{path}", json=body)
        assert rr.status_code == 200, rr.text
        j = wait_job(c, rr.json()["id"])
        assert j["status"] == "done" and j["result"]["status"] == "complete", j


def test_ui_plane_csv_with_source(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    for src, extra in (("original", {"method": "local_linear"}), ("grid", {})):
        r = c.post(f"/api/datasets/{ds}/region/plane?deliver=stream",
                   json={"mode": "point_normal", "origin": [0.05, 0.05, 0.2],
                         "normal": [0, 0, 1], "spacing": [0.005, 0.005],
                         "source": src, **extra})
        assert r.status_code == 200, r.text


# --- speed / quality control ------------------------------------------------------

def _smooth_field(p):
    return np.sin(2 * np.pi * p[:, 0] / 0.025) * np.cos(2 * np.pi * p[:, 1] / 0.03) \
        * (1 - np.exp(-(p[:, 2] - WALL) / 0.002))


@pytest.mark.parametrize("method", ["local_linear", "local_linear_hq"])
def test_no_seams_where_the_neighbour_set_changes(method):
    """A dense line of queries (1 um steps) across thin-layer data: the result
    must be continuous. v2.8.0-dev showed ~4e-3 jumps (visible one-pixel seams
    at 1024 samples); hard method switches and neighbour-set changes are now
    tapered/blended."""
    p = lattice_layers()
    f = _smooth_field(p)
    ev = FieldEvaluator(FieldData(points=p, fields={"f": f},
                                  is_fluid=np.ones(len(p), bool), units={}))
    x = np.linspace(0.03, 0.05, 20001)
    q = np.column_stack([x, np.full_like(x, 0.0437), np.full_like(x, WALL + 5e-4)])
    st, _ = ev.classify(q)
    v = ev.evaluate(["f"], q, st, method=method).values["f"]
    jump = np.nanmax(np.abs(np.diff(v))) / np.ptp(f)
    assert jump < 2e-3, jump


def test_hq_method_is_exact_on_affine_fields_and_labelled():
    p = lattice_layers()
    ev = FieldEvaluator(FieldData(points=p, fields={"f": affine(p)},
                                  is_fluid=np.ones(len(p), bool), units={}))
    g = np.linspace(0.01, 0.09, 30)
    gx, gy = np.meshgrid(g, g, indexing="ij")
    q = np.column_stack([gx.ravel(), gy.ravel(), np.full(gx.size, WALL + 5e-4)])
    st, _ = ev.classify(q)
    e = ev.evaluate(["f"], q, st, method="local_linear_hq")
    assert e.counts.get("local_linear_scaled", 0) > 0.5 * len(q)
    assert np.max(np.abs(e.values["f"] - affine(q))) / np.ptp(affine(p)) <= 1e-8


def test_estimate_endpoint_measures_and_scales(api_client, wall_ds):
    c, _ = api_client
    ds, _ = wall_ds
    body = {"mode": "axis", "axis": "z", "position": 0.2, "field": "temperature",
            "formats": ["png", "csv"], "render": {"long_edge_px": 3000, "dpi": 300}}
    small = c.post(f"/api/datasets/{ds}/slices/estimate", json={
        **body, "sampling": {"mode": "long_edge", "long_edge_samples": 256}}).json()
    big = c.post(f"/api/datasets/{ds}/slices/estimate", json={
        **body, "sampling": {"mode": "long_edge", "long_edge_samples": 2048}}).json()
    assert max(small["sample_shape"]) == 256 and max(big["sample_shape"]) == 2048
    assert big["n_samples"] == big["sample_shape"][0] * big["sample_shape"][1]
    assert big["estimate_s"]["compute"] > small["estimate_s"]["compute"]
    assert big["estimate_s"]["csv"] > small["estimate_s"]["csv"]
    grid = c.post(f"/api/datasets/{ds}/slices/estimate", json={
        **body, "evaluation": {"source": "grid"},
        "sampling": {"mode": "long_edge", "long_edge_samples": 2048}}).json()
    assert grid["method"] == "grid_trilinear"
    r = c.post(f"/api/datasets/{ds}/slices/estimate", json={
        **body, "sampling": {"mode": "long_edge", "long_edge_samples": 4096}})
    assert r.status_code == 413                          # same budget as the export
    j = export(c, ds, {**body, "position": 0.2, "formats": ["png"],
                       "evaluation": {"source": "original", "method": "local_linear_hq"},
                       "sampling": {"mode": "long_edge", "long_edge_samples": 48},
                       "render": {"long_edge_px": 400, "dpi": 100}}).json()
    assert j["method_requested"] == "local_linear_hq"
