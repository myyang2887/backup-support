"""fdpost: inspect the structure of a FloEFD export before choosing a slice algorithm.

Usage (inside the fdpost environment):
    python check_data_structure.py <export.txt> --wall-z 0.12

Prints a plain-text report. Nothing is written or modified.
What it answers:
  1. Do the points sit on Cartesian lattices (FloEFD cells), and with which spacings per axis?
  2. Are cells strongly anisotropic near the substrate (thin z layers)?
  3. Are there partial cells (Volume far below the regular cell volume)?
  4. Do isotropic k-NN neighbourhoods degenerate (all neighbours in 1-2 vertical columns)?
"""
from __future__ import annotations

import argparse
from collections import Counter

import numpy as np
from scipy.spatial import cKDTree

from fdpost.io.tsv_loader import load_floefd_table


def spacing_table(coord: np.ndarray, top: int = 8) -> str:
    u = np.unique(np.round(coord, 9))
    d = np.round(np.diff(u), 7)
    d = d[d > 0]
    if d.size == 0:
        return f"    unique values: {u.size} (no spacing)"
    common = Counter(d.tolist()).most_common(top)
    ref = common[0][0]
    rows = [f"    unique values: {u.size:,}   distinct gaps: {len(set(d.tolist())):,}"]
    for gap, n in common:
        rows.append(f"    gap {gap*1e3:10.5f} mm  x{n:<7d} ratio to most common {gap/ref:8.4f}"
                    f"  (log2 {np.log2(gap/ref):+.2f})")
    return "\n".join(rows)


def neighbour_degeneracy(pts: np.ndarray, queries: np.ndarray, k: int = 32) -> str:
    k = min(k, len(pts))
    tree = cKDTree(pts)
    d, idx = tree.query(queries, k=k, workers=-1)
    cols, conds = [], []
    for row in idx:
        nb = pts[row]
        cols.append(len(np.unique(np.round(nb[:, :2], 7), axis=0)))
        off = nb - nb.mean(axis=0)
        s = np.linalg.svd(off, compute_uv=False)
        conds.append(s[0] / max(s[-1], 1e-300))
    cols, conds = np.array(cols), np.array(conds)
    return (f"    k={k}: distinct (x,y) columns among neighbours  median {np.median(cols):.0f}"
            f"  min {cols.min()}\n"
            f"    neighbour radius median {np.median(d[:, -1])*1e3:.3f} mm\n"
            f"    offsets ill-conditioned (cond > 1e6): {(conds > 1e6).mean()*100:.1f}%")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--wall-z", type=float, default=None, help="substrate top z [m]")
    ap.add_argument("--band", type=float, default=0.005, help="band above wall [m]")
    ap.add_argument("--samples", type=int, default=2000)
    a = ap.parse_args()

    fd = load_floefd_table(a.path)
    p, fl = fd.points, fd.is_fluid
    lo, hi = fd.bounds
    print(f"file: {a.path}")
    print(f"points {fd.n_points:,}  fluid {int(fl.sum()):,}  solid {int((~fl).sum()):,}")
    print(f"bounds  x {lo[0]:.6f}..{hi[0]:.6f}  y {lo[1]:.6f}..{hi[1]:.6f}  z {lo[2]:.6f}..{hi[2]:.6f} m")
    print(f"fields: {sorted(fd.fields)}")

    print("\n[1] coordinate gaps per axis (fluid points)")
    for i, ax in enumerate("xyz"):
        print(f"  {ax}:")
        print(spacing_table(p[fl, i]))

    if "volume" in fd.fields:
        v = fd.fields["volume"][fl]
        v = v[np.isfinite(v) & (v > 0)]
        if v.size:
            q = np.quantile(v, [0, 0.01, 0.5, 0.99, 1])
            med = q[2]
            print("\n[2] Volume of fluid cells [m^3]")
            print("    min {:.3e}  p1 {:.3e}  median {:.3e}  p99 {:.3e}  max {:.3e}".format(*q))
            print(f"    cube-root of median: {np.cbrt(med)*1e3:.4f} mm")
            print(f"    cells with V < 1% of median (likely partial / wall-cut): "
                  f"{(v < 0.01*med).mean()*100:.2f}%")

    rng = np.random.default_rng(0)
    pf = p[fl]
    if a.wall_z is not None:
        band = (pf[:, 2] >= a.wall_z) & (pf[:, 2] <= a.wall_z + a.band)
        print(f"\n[3] band {a.wall_z} .. {a.wall_z + a.band} m above the wall")
        print(f"    fluid points in band: {int(band.sum()):,}")
        if band.sum() > 10:
            zb = np.unique(np.round(pf[band, 2], 9))
            dz = np.diff(zb)
            xb = np.unique(np.round(pf[band, 0], 9))
            dx = np.diff(xb)
            print(f"    distinct z levels: {zb.size}   lowest z: {zb[0]:.9f} m "
                  f"({(zb[0]-a.wall_z)*1e6:.4f} um above wall)")
            if dz.size and dx.size:
                print(f"    median dz {np.median(dz)*1e3:.4f} mm   median dx {np.median(dx)*1e3:.4f} mm"
                      f"   anisotropy dx/dz {np.median(dx)/max(np.median(dz),1e-15):.1f}")
        qz = a.wall_z + 0.0005
        qxy = rng.uniform(lo[:2] + 0.1*(hi[:2]-lo[:2]), hi[:2] - 0.1*(hi[:2]-lo[:2]),
                          size=(a.samples, 2))
        q = np.column_stack([qxy, np.full(a.samples, qz)])
        print(f"\n[4] isotropic k-NN neighbourhoods at z = wall + 0.5 mm")
        print(neighbour_degeneracy(pf, q))

    mid = pf[rng.choice(len(pf), size=min(a.samples, len(pf)), replace=False)]
    print("\n[5] isotropic k-NN neighbourhoods at random fluid points")
    print(neighbour_degeneracy(pf, mid))


if __name__ == "__main__":
    main()
