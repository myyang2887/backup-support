"""Project exception tree (see spec section 3.5)."""
from __future__ import annotations


class FdPostError(Exception):
    """Base class for all fdpost errors."""


class DataLoadError(FdPostError):
    """File missing / parse failure / missing coordinate columns / too few points."""


class FieldNotFoundError(FdPostError):
    """A requested physical field does not exist."""


class GridBuildError(FdPostError):
    """Invalid resampling parameters or degenerate point cloud."""


class RegionTooLargeError(FdPostError):
    """Region export would exceed the configured row limit."""


class CacheError(FdPostError):
    """Grid cache file is corrupt or incompatible (deleted for rebuild)."""


class JobNotFoundError(FdPostError):
    """Unknown background job id."""


class SliceGeometryError(FdPostError):
    """A slice request that cannot be placed: position outside the data,
    plane missing the data box, or an ROI with no extent."""


class SampleBudgetError(RegionTooLargeError):
    """A slice request whose sample lattice exceeds the configured budget.
    Refused explicitly instead of being shrunk without notice."""
