"""Translate old flat slice parameters into the v2.8 specs.

Old requests keep working, but their meaning is now stated explicitly and
recorded (`notes`) in every result and manifest:

  resolution / sample_px (int)   -> SamplingSpec(mode='long_edge')
  resolution (nu, nv) (plane)    -> SamplingSpec(mode='counts')
  fidelity='scatter'             -> EvaluationSpec(source='original')
  fidelity='grid'                -> EvaluationSpec(source='grid')
  dpi set, no render block       -> RenderOptions(size_mode='print',
                                    9-inch long edge at that dpi: the old figure)
  cmap / smooth / show_solid /
  solid_color / clim / vector_stride -> the same RenderOptions fields

Giving an old parameter *and* the new block for the same concern is an error:
which one wins would otherwise be a guess.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from fdpost.domain.errors import SliceGeometryError
from fdpost.domain.requests import EvaluationSpec, RenderOptions, SamplingSpec

LEGACY_FIGURE_LONG_EDGE_MM = 9 * 25.4        # the v2.x figure was 9 in wide


class SpecConflictError(SliceGeometryError, ValueError):
    """Old and new parameters given for the same concern (HTTP 400)."""


@dataclass
class ResolvedSpecs:
    sampling: SamplingSpec
    evaluation: EvaluationSpec
    render: RenderOptions
    notes: list[str] = field(default_factory=list)


def _set(req: Any, name: str) -> bool:
    return name in getattr(req, "model_fields_set", set())


def resolve_specs(req: Any, *, default_long_edge: int, default_image_px: int,
                  default_dpi: int, batch: bool = False) -> ResolvedSpecs:
    notes: list[str] = []

    # -- sampling --------------------------------------------------------------
    legacy_samp = [n for n in ("resolution", "sample_px") if _set(req, n)
                   and getattr(req, n) is not None]
    if req.sampling is not None:
        if legacy_samp:
            raise SpecConflictError(
                f"give either 'sampling' or the legacy {legacy_samp}, not both")
        sampling = req.sampling
    elif legacy_samp:
        name = legacy_samp[0]
        val = getattr(req, name)
        if isinstance(val, (tuple, list)):
            sampling = SamplingSpec(mode="counts", counts=(int(val[0]), int(val[1])))
            notes.append(f"legacy {name}={tuple(val)} -> sampling counts")
        else:
            sampling = SamplingSpec(mode="long_edge", long_edge_samples=int(val))
            notes.append(f"legacy {name}={val} -> sampling long_edge")
    else:
        sampling = SamplingSpec(mode="long_edge", long_edge_samples=default_long_edge)

    # -- evaluation ------------------------------------------------------------
    has_fid = hasattr(req, "fidelity") and _set(req, "fidelity")
    if req.evaluation is not None:
        if has_fid:
            want = "original" if req.fidelity == "scatter" else "grid"
            if want != req.evaluation.source:
                raise SpecConflictError(
                    f"fidelity='{req.fidelity}' contradicts evaluation.source="
                    f"'{req.evaluation.source}'")
        evaluation = req.evaluation
    elif hasattr(req, "fidelity"):
        evaluation = EvaluationSpec(source="original" if req.fidelity == "scatter" else "grid")
        notes.append(f"fidelity='{req.fidelity}' -> source='{evaluation.source}'")
    else:
        evaluation = EvaluationSpec(source="original")

    # -- render ------------------------------------------------------------------
    legacy_render = [n for n in ("dpi", "cmap", "smooth", "show_solid", "solid_color",
                                 "clim", "vector_stride")
                     if hasattr(req, n) and _set(req, n)]
    if req.render is not None:
        if legacy_render:
            raise SpecConflictError(
                f"give either 'render' or the legacy {legacy_render}, not both")
        r = req.render
    else:
        kw: dict[str, Any] = {}
        for n in ("cmap", "smooth", "show_solid", "solid_color", "vector_stride"):
            if hasattr(req, n):
                kw[n] = getattr(req, n)
        if getattr(req, "clim", None) is not None:
            kw["clim"] = tuple(req.clim)
            kw["clim_mode"] = "fixed"
        if _set(req, "dpi"):
            kw.update(size_mode="print", dpi=int(req.dpi),
                      print_long_edge_mm=LEGACY_FIGURE_LONG_EDGE_MM)
            notes.append(f"legacy dpi={req.dpi} -> print size {LEGACY_FIGURE_LONG_EDGE_MM:.1f} mm"
                         f" at {req.dpi} dpi")
        r = RenderOptions(**kw)
    upd: dict[str, Any] = {}
    if r.dpi is None:
        upd["dpi"] = default_dpi
    if r.size_mode == "pixels" and r.long_edge_px is None:
        upd["long_edge_px"] = default_image_px
    if r.size_mode == "print" and r.print_long_edge_mm is None:
        upd["print_long_edge_mm"] = LEGACY_FIGURE_LONG_EDGE_MM
    if batch and r.clim_mode == "auto":
        upd["clim_mode"] = "batch_global"
    if upd:
        r = r.model_copy(update=upd)
    return ResolvedSpecs(sampling=sampling, evaluation=evaluation, render=r, notes=notes)
