"""One plane definition for every slice output (preview, PNG, CSV, batch).

Axis cuts, Euler-angle cuts and point+normal cuts are all turned into a
`ResolvedPlane` before anything is sampled. Everything downstream (sampling,
classification, rendering, CSV) reads only this object, so the same request
can no longer land on different cuts depending on which button produced it.

Two rules this module enforces:

* The physical position is the state. An axis cut at 0.120000 m stays at
  0.120000 m; snapping to a grid plane happens only on request and both the
  requested and the actual position are reported.
* Extents come from the data, not from the preview grid. The default extent
  of a free plane is the bounding box of the plane's intersection with the
  data box, so a tilted cut is not padded with corners that lie off the plane.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from fdpost.domain.errors import SampleBudgetError, SliceGeometryError
from fdpost.domain.requests import QUALITY_PRESETS, SamplingSpec

AXIS_INDEX = {"x": 0, "y": 1, "z": 2}
IN_PLANE = {"x": ("y", "z"), "y": ("x", "z"), "z": ("x", "y")}


def plane_basis(normal: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Orthonormal (u_hat, v_hat) for a unit normal; right-handed with n.
    Matches the basis the v2.x grid path used, so free-plane images keep
    their orientation."""
    n = np.asarray(normal, dtype=np.float64)
    n = n / np.linalg.norm(n)
    ref = np.array([0.0, 0.0, 1.0]) if abs(n[2]) < 0.9 else np.array([1.0, 0.0, 0.0])
    u = np.cross(ref, n)
    u /= np.linalg.norm(u)
    v = np.cross(n, u)
    return u, v


def euler_normal(tilt_deg: float, azimuth_deg: float) -> np.ndarray:
    """n = Rz(azimuth) @ Rx(tilt) @ [0,0,1] (requirement書: XY平面回転角度+方位角)."""
    t, a = np.deg2rad(tilt_deg), np.deg2rad(azimuth_deg)
    n = np.array([np.sin(a) * np.sin(t), -np.cos(a) * np.sin(t), np.cos(t)])
    return n / np.linalg.norm(n)


_BOX_EDGES = [(0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7),
              (0, 4), (1, 5), (2, 6), (3, 7)]


def _box_corners(lo: np.ndarray, hi: np.ndarray) -> np.ndarray:
    return np.array([[x, y, z] for x in (lo[0], hi[0])
                     for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])


def plane_box_extent(origin: np.ndarray, normal: np.ndarray, u_hat: np.ndarray,
                     v_hat: np.ndarray, lo: np.ndarray, hi: np.ndarray
                     ) -> tuple[tuple[float, float], tuple[float, float]] | None:
    """(u, v) bounding box of plane ∩ box, relative to `origin`; None if the
    plane misses the box."""
    c = _box_corners(lo, hi)
    s = (c - origin) @ normal
    pts = [c[i] for i in range(8) if abs(s[i]) <= 1e-12 * max(1.0, np.abs(c).max())]
    for i, j in _BOX_EDGES:
        if (s[i] < 0) != (s[j] < 0) and s[i] != s[j]:
            t = s[i] / (s[i] - s[j])
            pts.append(c[i] + t * (c[j] - c[i]))
    if len(pts) < 3:
        return None
    p = np.asarray(pts) - origin
    pu, pv = p @ u_hat, p @ v_hat
    if pu.max() - pu.min() <= 0 or pv.max() - pv.min() <= 0:
        return None
    return (float(pu.min()), float(pu.max())), (float(pv.min()), float(pv.max()))


@dataclass(frozen=True)
class ResolvedPlane:
    """A plane ready to be sampled.

    origin    : a point on the plane [m]. For axis cuts it is the centre of the
                data box moved onto the cut, so (u, v) offsets map to world x/y/z
                by simple addition.
    extent_u/v: in-plane range relative to `origin` [m].
    """

    kind: str                          # axis | euler | point_normal
    origin: np.ndarray
    normal: np.ndarray
    u_hat: np.ndarray
    v_hat: np.ndarray
    extent_u: tuple[float, float]
    extent_v: tuple[float, float]
    axis: str | None = None
    requested: dict[str, Any] = field(default_factory=dict)
    snapped: bool = False
    roi: bool = False                  # extents came from the request

    # -- coordinates -------------------------------------------------------
    def world(self, u: np.ndarray, v: np.ndarray) -> np.ndarray:
        """(nu*nv, 3) world points of the lattice, C-order rows = u."""
        gu, gv = np.meshgrid(u, v, indexing="ij")
        return (self.origin + gu.ravel()[:, None] * self.u_hat
                + gv.ravel()[:, None] * self.v_hat)

    def display(self, u: np.ndarray, v: np.ndarray
                ) -> tuple[np.ndarray, np.ndarray, str, str]:
        """Plot coordinates + labels. Axis cuts show world coordinates of the
        two in-plane axes; free planes show in-plane offsets from the origin."""
        if self.kind == "axis" and self.axis:
            ua, va = IN_PLANE[self.axis]
            return (u + self.origin[AXIS_INDEX[ua]], v + self.origin[AXIS_INDEX[va]],
                    f"{ua.upper()} [m]", f"{va.upper()} [m]")
        return u, v, "u [m]", "v [m]"

    @property
    def position(self) -> float | None:
        return float(self.origin[AXIS_INDEX[self.axis]]) if self.axis else None

    def title(self) -> str:
        if self.kind == "axis" and self.axis:
            return f"{self.axis.upper()} = {self.position:.6f} m"
        r = self.requested
        if self.kind == "euler":
            return (f"tilt {r.get('tilt_deg', 0):g} deg, azimuth {r.get('azimuth_deg', 0):g} deg,"
                    f" distance {r.get('distance', 0):g} m")
        o, n = self.origin, self.normal
        return (f"o=({o[0]:.4g}, {o[1]:.4g}, {o[2]:.4g}) m  "
                f"n=({n[0]:.3f}, {n[1]:.3f}, {n[2]:.3f})")

    def describe(self) -> dict[str, Any]:
        return {"kind": self.kind, "axis": self.axis,
                "position_m": self.position,
                "origin_m": self.origin.tolist(), "normal": self.normal.tolist(),
                "u_hat": self.u_hat.tolist(), "v_hat": self.v_hat.tolist(),
                "extent_u_m": list(self.extent_u), "extent_v_m": list(self.extent_v),
                "snapped_to_grid": self.snapped, "roi_from_request": self.roi}


def resolve_plane(req: Any, bounds: np.ndarray, *,
                  grid_planes: tuple[np.ndarray, np.ndarray] | None = None,
                  center: np.ndarray | None = None) -> ResolvedPlane:
    """Request (anything with PlaneGeometry fields) -> ResolvedPlane.

    bounds      : (2,3) data box the default extents are taken from.
    grid_planes : (origin, spacing) of the preprocessing grid; needed only when
                  the request asks for snap_to_grid.
    center      : centre for Euler distances (default: centre of `bounds`).
    """
    lo, hi = np.asarray(bounds[0], float), np.asarray(bounds[1], float)
    c = (lo + hi) / 2 if center is None else np.asarray(center, float)
    mode = getattr(req, "mode", "axis")
    requested: dict[str, Any] = {"mode": mode}

    if mode == "axis":
        axis = req.axis
        ai = AXIS_INDEX[axis]
        pos = float(req.position)
        requested.update(axis=axis, position_m=pos)
        snapped = False
        if getattr(req, "snap_to_grid", False):
            if grid_planes is None:
                raise SliceGeometryError("snap_to_grid needs the preprocessing grid")
            go, gs = grid_planes
            k = round((pos - go[ai]) / gs[ai])
            pos = float(go[ai] + gs[ai] * k)
            snapped = True
        span = hi[ai] - lo[ai]
        tol = 1e-9 * max(span, 1e-12)
        if not (lo[ai] - tol <= pos <= hi[ai] + tol):
            raise SliceGeometryError(
                f"{axis}={pos:.9g} m is outside the data range "
                f"[{lo[ai]:.9g}, {hi[ai]:.9g}] m")
        origin = c.copy()
        origin[ai] = pos
        normal = np.zeros(3)
        normal[ai] = 1.0
        ua, va = IN_PLANE[axis]
        u_hat = np.zeros(3)
        u_hat[AXIS_INDEX[ua]] = 1.0
        v_hat = np.zeros(3)
        v_hat[AXIS_INDEX[va]] = 1.0
        eu = (float(lo[AXIS_INDEX[ua]] - origin[AXIS_INDEX[ua]]),
              float(hi[AXIS_INDEX[ua]] - origin[AXIS_INDEX[ua]]))
        ev = (float(lo[AXIS_INDEX[va]] - origin[AXIS_INDEX[va]]),
              float(hi[AXIS_INDEX[va]] - origin[AXIS_INDEX[va]]))
        roi = False
        if getattr(req, "extent_u", None) is not None:
            eu, roi = tuple(map(float, req.extent_u)), True
        if getattr(req, "extent_v", None) is not None:
            ev, roi = tuple(map(float, req.extent_v)), True
        return ResolvedPlane("axis", origin, normal, u_hat, v_hat, eu, ev,
                             axis=axis, requested=requested, snapped=snapped, roi=roi)

    if mode == "euler":
        normal = euler_normal(req.tilt_deg, req.azimuth_deg)
        origin = c + normal * float(req.distance)
        requested.update(tilt_deg=req.tilt_deg, azimuth_deg=req.azimuth_deg,
                         distance=req.distance)
    elif mode == "point_normal":
        n = np.asarray(req.normal, dtype=np.float64)
        nn = np.linalg.norm(n)
        if not np.isfinite(nn) or nn < 1e-15:
            raise SliceGeometryError("normal must be a finite non-zero vector")
        normal = n / nn
        origin = np.asarray(req.origin, dtype=np.float64)
        requested.update(origin=list(map(float, req.origin)),
                         normal=list(map(float, req.normal)))
    else:
        raise SliceGeometryError(f"unknown plane mode '{mode}'")

    u_hat, v_hat = plane_basis(normal)
    eu = getattr(req, "extent_u", None)
    ev = getattr(req, "extent_v", None)
    roi = eu is not None or ev is not None
    if eu is None or ev is None:
        auto = plane_box_extent(origin, normal, u_hat, v_hat, lo, hi)
        if auto is None:
            raise SliceGeometryError("the plane does not intersect the data box")
        eu = eu if eu is not None else auto[0]
        ev = ev if ev is not None else auto[1]
    return ResolvedPlane(mode, origin, normal, u_hat, v_hat,
                         (float(eu[0]), float(eu[1])), (float(ev[0]), float(ev[1])),
                         requested=requested, roi=roi)


# --- sample lattice ------------------------------------------------------------

@dataclass(frozen=True)
class Lattice:
    u: np.ndarray
    v: np.ndarray
    mode: str
    endpoint_rule: str

    @property
    def shape(self) -> tuple[int, int]:
        return (int(self.u.size), int(self.v.size))

    @property
    def spacing(self) -> tuple[float, float]:
        du = float(self.u[1] - self.u[0]) if self.u.size > 1 else 0.0
        dv = float(self.v[1] - self.v[0]) if self.v.size > 1 else 0.0
        return du, dv

    def describe(self) -> dict[str, Any]:
        du, dv = self.spacing
        return {"mode": self.mode, "endpoint_rule": self.endpoint_rule,
                "sample_shape": list(self.shape),
                "spacing_m": [du, dv],
                "u_range_m": [float(self.u[0]), float(self.u[-1])],
                "v_range_m": [float(self.v[0]), float(self.v[-1])]}


def _steps(lo: float, hi: float, h: float) -> np.ndarray:
    n = int(np.floor((hi - lo) / h + 1e-9)) + 1
    return lo + h * np.arange(max(n, 1), dtype=np.float64)


def plan_lattice(plane: ResolvedPlane, spec: SamplingSpec, *,
                 default_long_edge: int, max_points: int) -> Lattice:
    """SamplingSpec -> concrete (u, v). Refuses (never shrinks) over budget."""
    eu, ev = plane.extent_u, plane.extent_v
    su, sv = eu[1] - eu[0], ev[1] - ev[0]
    if su <= 0 or sv <= 0:
        raise SliceGeometryError(f"empty in-plane extent ({su:g} x {sv:g} m)")
    mode = spec.mode
    if mode == "counts":
        nu, nv = spec.counts  # type: ignore[misc]
        nu, nv = int(nu), int(nv)
        rule = "both endpoints included"
    elif mode == "spacing":
        du, dv = spec.spacing_m  # type: ignore[misc]
        nu = int(np.floor(su / du + 1e-9)) + 1
        nv = int(np.floor(sv / dv + 1e-9)) + 1
        rule = "exact step from the lower edge; last sample is the last that fits"
    else:
        n = (QUALITY_PRESETS[spec.quality or "standard"] if mode == "auto"
             else int(spec.long_edge_samples or default_long_edge))
        h = max(su, sv) / max(n - 1, 1)
        nu = max(2, int(round(su / h)) + 1)
        nv = max(2, int(round(sv / h)) + 1)
        rule = "both endpoints included; near-equal physical spacing"
    total = nu * nv
    if total > max_points:
        raise SampleBudgetError(
            f"{nu} x {nv} = {total:,} samples exceeds the limit of {max_points:,}; "
            "lower the sample count, enlarge the spacing or narrow the range")
    if mode == "spacing":
        u = _steps(eu[0], eu[1], spec.spacing_m[0])  # type: ignore[index]
        v = _steps(ev[0], ev[1], spec.spacing_m[1])  # type: ignore[index]
    else:
        u = np.linspace(eu[0], eu[1], nu) if nu > 1 else np.array([0.5 * (eu[0] + eu[1])])
        v = np.linspace(ev[0], ev[1], nv) if nv > 1 else np.array([0.5 * (ev[0] + ev[1])])
    return Lattice(u=u, v=v, mode=mode, endpoint_rule=rule)
