"""Evaluate the ORIGINAL scattered data at exact 3D positions.

Replaces the v2.4-v2.7 "slab" path, which collected the points within a few
spacings of a plane and projected them onto it. That threw away each point's
distance to the plane: on layered data (FloEFD's thin near-wall cells) a
horizontal cut 0.5 mm above a substrate mixed ~20 layers into one picture, a
constant-in-plane field came out as patches, and the result changed with the
row order of the file. Nothing here projects; every value is computed at the
query point itself.

Methods
-------
local_linear (default)
    Weighted least-squares fit of a + b·dx + c·dy + d·dz around the query,
    read at the query. Reproduces any affine field exactly when the
    neighbourhood supports it. The neighbourhood is chosen adaptively, so the
    method makes no assumption about how the data was sampled:

    1. isotropic k-nearest neighbours (fast; correct for scattered or
       isotropic data);
    2. if that neighbourhood is degenerate -- ill-conditioned, or spread far
       more along one axis than another, which is what thin layers produce:
       all k neighbours sit in one or two columns -- re-select neighbours
       balanced over the 8 octants around the query from a larger candidate
       pool and refit;
    3. if still degenerate, modified-Shepard IDW on that balanced set.

    Weights fall to zero at the edge of each neighbourhood and the hand-over
    between 1 and 2 is blended, so changes of the neighbour set do not show
    up as seams. (Residual: an octant's membership still changes when the
    query crosses a data column's coordinate; measured jumps are ~1e-3 of the
    value at 1 um steps -- a locally scaled metric removes them but costs an
    order of magnitude more time on layered data, so it is not used.)

    Every sample records which of the three produced it (`quality`).
idw
    k-NN inverse-distance weighting (isotropic). Fast; plateaus around data
    points; does not reproduce linear fields.
nearest
    Value of the nearest valid source point.

Domain classification (`classify`)
----------------------------------
Each query gets one of FLUID / SOLID / OUTSIDE / UNKNOWN, from 3D positions:

* OUTSIDE: beyond the source bounding box by more than half the local data
  radius (the outermost points are cell centres; the domain extends a little
  past them).
* UNKNOWN: farther from every source point than `support_gap_factor` times
  the local neighbourhood radius of the nearest point -- a hole in the data
  that nearest-neighbour filling would otherwise paint over.
* SOLID / FLUID: the nearest source point's flag, in 3D (never in a 2D
  projection).

Values are then evaluated per region: a fluid query only uses fluid points, a
solid query only solid points (so a temperature field that exists in both is
never blended across a wall). A field with no values in a region yields NaN
there.
"""
from __future__ import annotations

import hashlib
import logging
import threading
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np
from scipy.spatial import cKDTree

from fdpost.domain.field_data import FieldData

log = logging.getLogger("fdpost.services.field_evaluator")

# domain state codes
FLUID, SOLID, OUTSIDE, UNKNOWN = 0, 1, 2, 3
STATE_NAMES = {FLUID: "fluid", SOLID: "solid", OUTSIDE: "outside", UNKNOWN: "unknown"}

# per-sample method codes
(Q_NONE, Q_LINEAR, Q_LINEAR_BALANCED, Q_IDW_FALLBACK, Q_IDW, Q_NEAREST, Q_GRID,
 Q_LINEAR_SCALED) = range(8)
QUALITY_NAMES = {Q_NONE: "none", Q_LINEAR: "local_linear",
                 Q_LINEAR_BALANCED: "local_linear_balanced",
                 Q_IDW_FALLBACK: "idw_fallback", Q_IDW: "idw",
                 Q_NEAREST: "nearest", Q_GRID: "grid_trilinear",
                 Q_LINEAR_SCALED: "local_linear_scaled"}

ALGORITHM_VERSION = "2.8.0-adaptive-ll-1"


@dataclass(frozen=True)
class EvaluatorConfig:
    neighbors: int = 32
    balanced_search: int = 512
    per_octant: int = 4
    hq_max_pool: int = 4096
    anisotropy_trigger: float = 4.0
    max_condition: float = 1e6
    idw_neighbors: int = 8
    idw_power: float = 2.0
    support_gap_factor: float = 2.0
    chunk: int = 16_384

    @classmethod
    def from_settings(cls, s: Any, neighbors: int | None = None) -> EvaluatorConfig:
        return cls(neighbors=int(neighbors or s.local_linear_neighbors),
                   balanced_search=int(s.balanced_search_neighbors),
                   per_octant=int(s.balanced_per_octant),
                   hq_max_pool=int(s.hq_max_pool),
                   anisotropy_trigger=float(s.anisotropy_trigger),
                   max_condition=float(s.max_condition),
                   idw_neighbors=int(s.idw_neighbors), idw_power=float(s.idw_power),
                   support_gap_factor=float(s.support_gap_factor),
                   chunk=int(s.chunk_query_points))


@dataclass
class _Fit:
    """Points of one region whose values are valid for a group of fields."""
    points: np.ndarray            # (n,3)
    values: np.ndarray            # (n,F)
    names: tuple[str, ...]
    tree: cKDTree
    gaps: np.ndarray | None = None     # (n,3) local data spacing (hq method)


@dataclass
class Evaluation:
    values: dict[str, np.ndarray]
    quality: np.ndarray                      # (M,) uint8
    nearest_distance: np.ndarray             # (M,) distance to nearest used point
    counts: dict[str, int] = field(default_factory=dict)


def _ascii_hash(mask: np.ndarray) -> str:
    return hashlib.blake2b(np.packbits(mask).tobytes(), digest_size=12).hexdigest()


class FieldEvaluator:
    """Thread-safe; fits (KD-trees) are built lazily and cached per
    (region, field-validity group)."""

    def __init__(self, fd: FieldData, cfg: EvaluatorConfig | None = None,
                 signature: str = "") -> None:
        self.fd = fd
        self.cfg = cfg or EvaluatorConfig()
        self.signature = signature
        self._lock = threading.RLock()
        self._fits: dict[tuple[str, str], _Fit | None] = {}
        self._all_tree: cKDTree | None = None
        self._radius: np.ndarray | None = None

    # -- basic facts ---------------------------------------------------------
    @property
    def n_points(self) -> int:
        return int(self.fd.points.shape[0])

    @property
    def bounds(self) -> np.ndarray:
        return self.fd.bounds

    def _tree_all(self) -> cKDTree:
        with self._lock:
            if self._all_tree is None:
                self._all_tree = cKDTree(self.fd.points)
            return self._all_tree

    def local_radius(self) -> np.ndarray:
        """Per source point: distance to its k-th neighbour (k = neighbors).
        The neighbourhood scale used for support and edge decisions; robust to
        anisotropy because it is a radius that must reach k points."""
        with self._lock:
            if self._radius is None:
                tree = self._tree_all()
                pts = self.fd.points
                k = int(min(self.cfg.neighbors, max(pts.shape[0] - 1, 1))) + 1
                r = np.empty(pts.shape[0])
                step = 65_536
                for s in range(0, pts.shape[0], step):
                    d, _ = tree.query(pts[s:s + step], k=k, workers=-1)
                    r[s:s + step] = np.atleast_2d(d)[:, -1]
                self._radius = r
            return self._radius

    # -- classification ------------------------------------------------------
    def classify(self, pts: np.ndarray, progress: Callable[[float], None] | None = None
                 ) -> tuple[np.ndarray, np.ndarray]:
        """(state (M,) uint8, distance to nearest source point (M,)).
        `progress(fraction)` is called per chunk (and may raise to cancel)."""
        pts = np.asarray(pts, dtype=np.float64)
        tree = self._tree_all()
        rad = self.local_radius()
        lo, hi = self.bounds
        state = np.empty(pts.shape[0], dtype=np.uint8)
        dist = np.empty(pts.shape[0])
        step = max(self.cfg.chunk * 4, 1)
        for s in range(0, pts.shape[0], step):
            q = pts[s:s + step]
            d1, i1 = tree.query(q, k=1, workers=-1)
            r = rad[i1]
            out = np.sqrt((np.maximum(lo - q, 0) ** 2 + np.maximum(q - hi, 0) ** 2).sum(1))
            st = np.where(self.fd.is_fluid[i1], FLUID, SOLID).astype(np.uint8)
            st[d1 > self.cfg.support_gap_factor * r] = UNKNOWN
            st[out > 0.5 * r] = OUTSIDE
            state[s:s + step] = st
            dist[s:s + step] = d1
            if progress is not None:
                progress(min(1.0, (s + step) / max(pts.shape[0], 1)))
        return state, dist

    # -- fits --------------------------------------------------------------
    def _groups(self, names: list[str], region_fluid: bool) -> list[tuple[_Fit | None, list[str]]]:
        """Group fields by their validity mask inside one region."""
        region = self.fd.is_fluid if region_fluid else ~self.fd.is_fluid
        buckets: dict[str, list[str]] = {}
        masks: dict[str, np.ndarray] = {}
        for n in names:
            m = region & np.isfinite(self.fd.require(n))
            key = _ascii_hash(m) if m.any() else "empty"
            buckets.setdefault(key, []).append(n)
            masks[key] = m
        out = []
        tag = "F" if region_fluid else "S"
        for key, group in buckets.items():
            out.append((self._fit((tag, key), masks[key], group), group))
        return out

    def _fit(self, key: tuple[str, str], mask: np.ndarray, names: list[str]) -> _Fit | None:
        with self._lock:
            cached = self._fits.get(key)
            if cached is not None and set(names) <= set(cached.names):
                return cached
            if key[1] == "empty" or mask.sum() < 1:
                self._fits[key] = None
                return None
            all_names = sorted(set(names) | set(cached.names if cached else ()))
            pts = self.fd.points[mask]
            vals = np.column_stack([self.fd.fields[n][mask] for n in all_names])
            fit = _Fit(points=pts, values=vals, names=tuple(all_names), tree=cKDTree(pts))
            self._fits[key] = fit
            log.info("fit %s region=%s on %d points for %s", key[1][:8], key[0],
                     pts.shape[0], all_names)
            return fit

    # -- evaluation --------------------------------------------------------
    def evaluate(self, names: list[str], pts: np.ndarray, state: np.ndarray,
                 method: str = "local_linear",
                 progress: Callable[[float], None] | None = None) -> Evaluation:
        """Values for `names` at `pts`, region-restricted by `state`.
        OUTSIDE / UNKNOWN samples stay NaN. `progress(fraction)` is called
        after every chunk of samples; it may raise to cancel the work."""
        pts = np.asarray(pts, dtype=np.float64)
        m = pts.shape[0]
        plan = []
        for region_fluid, code in ((True, FLUID), (False, SOLID)):
            sel = np.flatnonzero(state == code)
            if sel.size:
                plan.append((region_fluid, code, sel))
        total = max(1, sum(sel.size * max(1, len(names)) for _, _, sel in plan))
        done = [0]

        def tick(n: int) -> None:
            done[0] += n
            if progress is not None:
                progress(min(1.0, done[0] / total))

        values = {n: np.full(m, np.nan) for n in names}
        quality = np.zeros(m, dtype=np.uint8)
        dnear = np.full(m, np.nan)
        for region_fluid, code, sel in plan:
            for fit, group in self._groups(names, region_fluid):
                if fit is None:
                    tick(sel.size * len(group))
                    continue
                cols = [fit.names.index(n) for n in group]
                v, q, d = self._run(fit, pts[sel], method, cols,
                                    tick=lambda k, g=len(group): tick(k * g))
                for j, n in enumerate(group):
                    values[n][sel] = v[:, j]
                # all groups share positions; keep the most conservative label
                quality[sel] = np.maximum(quality[sel], q)
                dnear[sel] = np.fmax(dnear[sel], d)
        counts = {QUALITY_NAMES[c]: int((quality == c).sum())
                  for c in np.unique(quality)}
        return Evaluation(values=values, quality=quality, nearest_distance=dnear,
                          counts=counts)

    def _run(self, fit: _Fit, q: np.ndarray, method: str, cols: list[int],
             tick: Callable[[int], None] | None = None
             ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        V = fit.values[:, cols]
        n = fit.points.shape[0]
        out = np.empty((q.shape[0], len(cols)))
        qual = np.empty(q.shape[0], dtype=np.uint8)
        dn = np.empty(q.shape[0])
        step = self.cfg.chunk
        for s in range(0, q.shape[0], step):
            qq = q[s:s + step]
            if method == "nearest" or n < 4:
                d, i = fit.tree.query(qq, k=1, workers=-1)
                out[s:s + step] = V[i]
                qual[s:s + step] = Q_NEAREST
                dn[s:s + step] = d
            elif method == "idw":
                o, d0 = _idw(fit, V, qq, self.cfg.idw_neighbors, self.cfg.idw_power)
                out[s:s + step] = o
                qual[s:s + step] = Q_IDW
                dn[s:s + step] = d0
            elif method in ("local_linear", "local_linear_hq"):
                o, qq_code, d0 = self._local_linear(fit, V, qq,
                                                    scaled=method == "local_linear_hq")
                out[s:s + step] = o
                qual[s:s + step] = qq_code
                dn[s:s + step] = d0
            else:
                raise ValueError(f"unknown method '{method}'")
            if tick is not None:
                tick(qq.shape[0])
        return out, qual, dn

    # -- adaptive local linear --------------------------------------------
    def _local_linear(self, fit: _Fit, V: np.ndarray, q: np.ndarray,
                      scaled: bool = False
                      ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        cfg = self.cfg
        n = fit.points.shape[0]
        k = int(min(cfg.neighbors, n))
        d, i = fit.tree.query(q, k=k, workers=-1)
        d = np.atleast_2d(d)
        i = np.atleast_2d(i)
        off = fit.points[i] - q[:, None, :]                      # (m,k,3)
        r = d[:, -1:] + 1e-300
        A = np.concatenate([np.ones(i.shape + (1,)), off / r[..., None]], axis=2)
        w = _taper(d, r)
        coef, good = _wls(A, V[i], w, cfg.max_condition)
        # Hand-over to the balanced fit, blended over T..2T of a degeneracy
        # indicator: sqrt(lambda_max/lambda_min) of the weighted covariance of
        # the neighbour offsets. Orientation-free (a tilted layer counts),
        # zero-support directions give lambda_min = 0 (fully balanced), and
        # with the gentle weights 1-(d/r)^2 it grows continuously as real 3D
        # support enters -- so no seam where one method takes over.
        wg = np.clip(1.0 - (d / r) ** 2, 0.0, None)
        wg = wg / np.maximum(wg.sum(1, keepdims=True), 1e-300)
        mu = np.einsum("mk,mka->ma", wg, off)
        c = off - mu[:, None, :]
        C = np.einsum("mk,mka,mkb->mab", wg, c, c)
        lam = np.linalg.eigvalsh(C)
        ratio = np.sqrt(lam[:, -1] / np.maximum(lam[:, 0], lam[:, -1] * 1e-16 + 1e-300))
        T = cfg.anisotropy_trigger
        t = np.clip((ratio - T) / T, 0.0, 1.0)
        t[~good] = 1.0
        out = np.where(good[:, None], coef, 0.0)
        code = np.full(q.shape[0], Q_LINEAR, dtype=np.uint8)
        need = np.flatnonzero(t > 0)
        if need.size:
            o2, c2 = (self._scaled(fit, V, q[need]) if scaled
                      else self._balanced(fit, V, q[need]))
            tt = t[need][:, None]
            out[need] = (1 - tt) * out[need] + tt * o2
            code[need] = np.where(t[need] >= 0.5, c2, Q_LINEAR)
        return out, code, d[:, 0]

    def _balanced(self, fit: _Fit, V: np.ndarray, q: np.ndarray
                  ) -> tuple[np.ndarray, np.ndarray]:
        """Octant-balanced refit. A first pass draws candidates from a modest
        pool; rows that still fail (very strong anisotropy, or edges) are
        retried once with the full `balanced_search` pool."""
        cfg = self.cfg
        n = fit.points.shape[0]
        k_full = int(min(cfg.balanced_search, n))
        k_first = int(min(max(4 * cfg.neighbors, 8 * cfg.per_octant), k_full))
        out, code = self._balanced_pass(fit, V, q, k_first)
        retry = np.flatnonzero(code == Q_IDW_FALLBACK)
        if retry.size and k_full > k_first:
            o2, c2 = self._balanced_pass(fit, V, q[retry], k_full)
            better = c2 == Q_LINEAR_BALANCED
            out[retry[better]] = o2[better]
            code[retry[better]] = c2[better]
        return out, code

    def _balanced_pass(self, fit: _Fit, V: np.ndarray, q: np.ndarray, ks: int
                       ) -> tuple[np.ndarray, np.ndarray]:
        cfg = self.cfg
        out = np.empty((q.shape[0], V.shape[1]))
        code = np.empty(q.shape[0], dtype=np.uint8)
        step = max(1, min(cfg.chunk, 2_097_152 // max(ks, 1)))
        for s0 in range(0, q.shape[0], step):
            qq = q[s0:s0 + step]
            d, i = fit.tree.query(qq, k=ks, workers=-1)
            d = np.atleast_2d(d)
            i = np.atleast_2d(i)
            off_all = fit.points[i] - qq[:, None, :]
            slot, valid, thr = _octant_select(off_all, d, cfg.per_octant)
            ic = np.take_along_axis(i, slot, 1)
            off = np.take_along_axis(off_all, slot[..., None], 1)
            ds = np.take_along_axis(d, slot, 1)
            cnt = np.maximum(valid.sum(1), 1)
            scale = np.sqrt((np.where(valid[..., None], off, 0.0) ** 2).sum(1)
                            / cnt[:, None]) + 1e-300                 # (m,3)
            offn = off / scale[:, None, :]
            A = np.concatenate([np.ones(ic.shape + (1,)), offn], axis=2)
            # per-axis normalisation only conditions the matrix (the fitted
            # value is invariant to it); weights use true distances, tapered
            # to zero at the candidate that would enter each octant next
            w = np.where(valid, _taper(ds, thr), 0.0)
            coef, good = _wls(A, V[ic], w, cfg.max_condition)
            good &= (w > 0).sum(1) >= 4
            wi = np.where(valid, _shepard(ds, thr, cfg.idw_power), 0.0)
            ws = wi.sum(1)
            flat = ws <= 0
            if flat.any():
                wi[flat] = valid[flat].astype(float)
                ws[flat] = np.maximum(wi[flat].sum(1), 1.0)
            idw = np.einsum("mk,mkf->mf", wi, V[ic]) / ws[:, None]
            dmin = np.where(valid, ds, np.inf)
            exact = dmin.min(1) <= 1e-12
            if exact.any():
                j = np.argmin(dmin, axis=1)
                idw[exact] = V[ic[exact, j[exact]]]
            out[s0:s0 + step] = np.where(good[:, None], coef, idw)
            code[s0:s0 + step] = np.where(good, Q_LINEAR_BALANCED, Q_IDW_FALLBACK)
        return out, code

    # -- high-quality variant: locally scaled metric -----------------------
    # Instead of 8 hard octants, neighbours are the k nearest in a metric where
    # each axis is divided by the local data spacing along it (estimated per
    # source point, tapered-averaged at the query). Everything is continuous
    # in the query position, so no seams at all -- at a cost that grows with
    # the anisotropy (the Euclidean candidate pool must hold the scaled ball).
    def _gaps(self, fit: _Fit) -> np.ndarray:
        with self._lock:
            if fit.gaps is not None:
                return fit.gaps
            pts = fit.points
            n = pts.shape[0]
            k = int(min(self.cfg.neighbors, max(n - 1, 1))) + 1
            g = np.empty((n, 3))
            for s0 in range(0, n, 32_768):
                d, i = fit.tree.query(pts[s0:s0 + 32_768], k=k, workers=-1)
                d = np.atleast_2d(d)
                off = np.abs(pts[np.atleast_2d(i)[:, 1:]] - pts[s0:s0 + 32_768, None, :])
                tol = 1e-6 * np.maximum(d[:, -1:], 1e-300)
                gg = np.where(off > tol[..., None], off, np.inf).min(1)
                mx = np.where(np.isfinite(gg), gg, -np.inf).max(1)
                mx = np.where(np.isfinite(mx), mx, d[:, -1])
                g[s0:s0 + 32_768] = np.where(np.isfinite(gg), gg, mx[:, None])
            fit.gaps = np.maximum(g, 1e-300)
            return fit.gaps

    def _scaled(self, fit: _Fit, V: np.ndarray, q: np.ndarray
                ) -> tuple[np.ndarray, np.ndarray]:
        cfg = self.cfg
        n = fit.points.shape[0]
        gaps = self._gaps(fit)
        k = int(min(cfg.neighbors, n - 1))
        scale = np.empty((q.shape[0], 3))
        for s0 in range(0, q.shape[0], cfg.chunk):
            d0, i0 = fit.tree.query(q[s0:s0 + cfg.chunk], k=k, workers=-1)
            d0 = np.atleast_2d(d0)
            w0 = _taper(d0, d0[:, -1:]) + 1e-12
            g = np.einsum("mk,mka->ma", w0, gaps[np.atleast_2d(i0)]) / w0.sum(1)[:, None]
            scale[s0:s0 + cfg.chunk] = g / g.max(1, keepdims=True)
        scale = np.maximum(scale, 1e-6)
        cap = int(min(cfg.hq_max_pool, n))
        need = np.clip(2.0 * k / scale.min(1), 64, None)
        sizes = np.minimum(2 ** np.ceil(np.log2(need)).astype(int), cap)
        out = np.empty((q.shape[0], V.shape[1]))
        code = np.empty(q.shape[0], dtype=np.uint8)
        for ks in np.unique(sizes):
            sel = np.flatnonzero(sizes == ks)
            ks_i = int(ks)
            while True:
                o, c, short = self._scaled_pass(fit, V, q[sel], scale[sel], ks_i, k)
                out[sel], code[sel] = o, c
                if not short.any() or ks_i >= cap:
                    break
                sel, ks_i = sel[short], min(ks_i * 2, cap)
        return out, code

    def _scaled_pass(self, fit: _Fit, V: np.ndarray, q: np.ndarray, scale: np.ndarray,
                     ks: int, k: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        cfg = self.cfg
        k = int(min(k, ks - 1))
        out = np.empty((q.shape[0], V.shape[1]))
        code = np.empty(q.shape[0], dtype=np.uint8)
        short = np.zeros(q.shape[0], dtype=bool)
        step = max(1, min(cfg.chunk, 2_097_152 // max(ks, 1)))
        for s0 in range(0, q.shape[0], step):
            qq, sc = q[s0:s0 + step], scale[s0:s0 + step]
            d, i = fit.tree.query(qq, k=ks, workers=-1)
            d, i = np.atleast_2d(d), np.atleast_2d(i)
            off = fit.points[i] - qq[:, None, :]
            dsc = np.linalg.norm(off / sc[:, None, :], axis=2)
            sel = np.argpartition(dsc, k, axis=1)[:, :k + 1]
            dsel = np.take_along_axis(dsc, sel, 1)
            o = np.argsort(dsel, axis=1)
            sel, dsel = np.take_along_axis(sel, o, 1), np.take_along_axis(dsel, o, 1)
            edge = dsel[:, -1:]
            sel, dsel = sel[:, :k], dsel[:, :k]
            # scales <= 1: a point at scaled distance e is at Euclidean <= e
            short[s0:s0 + step] = (edge[:, 0] > d[:, -1]) & (ks < fit.points.shape[0])
            ic = np.take_along_axis(i, sel, 1)
            offs = np.take_along_axis(off, sel[..., None], 1) / sc[:, None, :]
            r = edge + 1e-300
            A = np.concatenate([np.ones(ic.shape + (1,)), offs / r[..., None]], axis=2)
            w = _taper(dsel, r)
            coef, good = _wls(A, V[ic], w, cfg.max_condition)
            good &= (w > 0).sum(1) >= 4
            wi = _shepard(dsel, r, cfg.idw_power)
            ws = wi.sum(1)
            flat = ws <= 0
            if flat.any():
                wi[flat] = 1.0
                ws[flat] = wi[flat].sum(1)
            idw = np.einsum("mk,mkf->mf", wi, V[ic]) / ws[:, None]
            out[s0:s0 + step] = np.where(good[:, None], coef, idw)
            code[s0:s0 + step] = np.where(good, Q_LINEAR_SCALED, Q_IDW_FALLBACK)
        return out, code, short


    # -- data spacing along a direction --------------------------------------
    def along_spacing(self, direction: np.ndarray, max_points: int = 200_000
                      ) -> tuple[np.ndarray, np.ndarray]:
        """Per source point: how far a plane with normal `direction` must move
        to reach the next data point "ahead of" this one.

        For each point, among its k nearest neighbours, take those inside a
        60-degree cone around +-direction (lateral offset <= tan 60 x offset
        along the direction) and use the smallest offset along the direction.
        On a layered lattice that is the layer thickness for an axis
        direction, and layer thickness x cos(tilt) for a tilted one (how far
        the plane moves before it reaches the next layer); on scattered data
        it is close to the nearest-neighbour distance. No neighbour in the
        cone (rare): the k-th neighbour distance is used.

        Evaluated on at most `max_points` source points (fixed subsample;
        their neighbours come from the full data), which is plenty for the
        per-position medians of spacing_profile."""
        n = np.asarray(direction, dtype=np.float64)
        n = n / np.linalg.norm(n)
        key = tuple(np.round(n, 6))
        with self._lock:
            cache = self.__dict__.setdefault("_along_cache", OrderedDict())
            if key in cache:
                cache.move_to_end(key)
                return cache[key]
        allp = self.fd.points
        tree = self._tree_all()
        idx = np.arange(allp.shape[0])
        if idx.size > max_points:
            idx = np.sort(np.random.default_rng(0).choice(idx.size, max_points, replace=False))
        pts = allp[idx]
        k = int(min(max(self.cfg.neighbors, 48), max(allp.shape[0] - 1, 1))) + 1
        out = np.empty(pts.shape[0])
        for s0 in range(0, pts.shape[0], 32_768):
            q = pts[s0:s0 + 32_768]
            d, i = tree.query(q, k=k, workers=-1)
            d = np.atleast_2d(d)
            off = allp[np.atleast_2d(i)[:, 1:]] - q[:, None, :]
            dn = np.abs(off @ n)
            dp = np.sqrt(np.maximum((off ** 2).sum(2) - dn ** 2, 0.0))
            tol = 1e-6 * np.maximum(d[:, -1:], 1e-300)
            ok = (dn > tol) & (dp <= 1.7320508 * dn)
            cand = np.where(ok, dn, np.inf).min(1)
            out[s0:s0 + 32_768] = np.where(np.isfinite(cand), cand, d[:, -1])
        with self._lock:
            cache[key] = (idx, out)
            while len(cache) > 6:
                cache.popitem(last=False)
        return idx, out

    def spacing_profile(self, direction: np.ndarray, origin: np.ndarray | None = None,
                        bins: int = 512) -> dict[str, Any]:
        """Data spacing as a function of position t = (p - origin) . n.

        Equal-count bins over the sorted positions, so dense regions (thin
        layers) get narrow bins automatically. Per bin: median position,
        median spacing and 10th-percentile spacing. Arrays are small
        (<= `bins` entries)."""
        n = np.asarray(direction, dtype=np.float64)
        n = n / np.linalg.norm(n)
        o = np.zeros(3) if origin is None else np.asarray(origin, dtype=np.float64)
        idx, sp = self.along_spacing(n)
        t = (self.fd.points[idx] - o) @ n
        order = np.argsort(t, kind="stable")
        ts, ss = t[order], sp[order]
        b = int(max(1, min(bins, ts.size // 40)))
        # full data extent (the subsample may miss the extreme points)
        tall = (self.fd.points - o) @ n
        edges = np.linspace(0, ts.size, b + 1).astype(int)
        tc = np.array([np.median(ts[a:z]) for a, z in zip(edges[:-1], edges[1:])])
        sc = np.array([np.median(ss[a:z]) for a, z in zip(edges[:-1], edges[1:])])
        # 10th percentile: on a tilted plane one position mixes thin and
        # thick layers; stepping by the median would skip the thin ones
        s10 = np.array([np.percentile(ss[a:z], 10) for a, z in zip(edges[:-1], edges[1:])])
        return {"direction": n.tolist(), "origin": o.tolist(),
                "t_min": float(tall.min()), "t_max": float(tall.max()),
                "t": tc.tolist(), "spacing": sc.tolist(), "spacing_p10": s10.tolist(),
                "spacing_min": float(sc.min()), "spacing_max": float(sc.max())}

    # -- diagnostics ---------------------------------------------------------
    def in_plane_spacing(self, pts: np.ndarray, u_hat: np.ndarray, v_hat: np.ndarray,
                         k: int = 32) -> dict[str, Any]:
        """Typical gap between neighbouring source points along u and along v
        near the given positions. 'How fine is the data here', per direction,
        so thin layers and coarse columns are reported separately."""
        pts = np.asarray(pts, dtype=np.float64)
        if pts.shape[0] == 0:
            return {"spacing_u_m": None, "spacing_v_m": None}
        tree = self._tree_all()
        _, i1 = tree.query(pts, k=1, workers=-1)
        src = np.unique(i1)
        kk = int(min(k, self.n_points - 1)) + 1
        d, i = tree.query(self.fd.points[src], k=kk, workers=-1)
        off = self.fd.points[np.atleast_2d(i)[:, 1:]] - self.fd.points[src][:, None, :]
        res: dict[str, Any] = {"n_reference_points": int(src.size)}
        for name, axv in (("u", u_hat), ("v", v_hat)):
            g = np.abs(off @ axv)
            tol = 1e-6 * np.maximum(np.atleast_2d(d)[:, -1:], 1e-300)
            g = np.where(g > tol, g, np.inf).min(1)
            g = g[np.isfinite(g)]
            if g.size:
                p10, p50, p90 = np.percentile(g, [10, 50, 90])
                res[f"spacing_{name}_m"] = float(p50)
                res[f"spacing_{name}_p10_m"] = float(p10)
                res[f"spacing_{name}_p90_m"] = float(p90)
            else:
                res[f"spacing_{name}_m"] = None
        return res


# --- numerics -------------------------------------------------------------------

def _wls(A: np.ndarray, b: np.ndarray, w: np.ndarray, max_cond: float,
         return_cond: bool = False):
    """Batched weighted least squares, value at the origin (coef[:,0]).
    `w` are the least-squares weights (residual i counts w_i times).

    Coordinates are centred on the query and scaled to O(1). The fit is
    solved by QR of the weighted design matrix (error ~ eps*cond(A), not
    eps*cond(A)^2 as with normal equations). Fits whose cond(A) exceeds
    `max_cond` are reported as not good rather than returned.
    """
    sw = np.sqrt(w)[..., None]
    Aw = A * sw                                          # (m,k,4)
    G = np.einsum("mki,mkj->mij", Aw, Aw)
    ev = np.linalg.eigvalsh(G)
    cond2 = ev[:, -1] / np.maximum(ev[:, 0], 1e-300)
    good = (ev[:, 0] > 0) & (cond2 < max_cond ** 2)
    out = np.full((A.shape[0], b.shape[2]), np.nan)
    if good.any():
        Q, R = np.linalg.qr(Aw[good])                    # (g,k,4), (g,4,4)
        y = np.einsum("gki,gkf->gif", Q, (b * sw)[good])
        sol = np.linalg.solve(R, y)
        out[good] = sol[:, 0, :]
    if return_cond:
        return out, good, np.sqrt(np.maximum(cond2, 1.0))
    return out, good


def _octant_select(off: np.ndarray, d: np.ndarray, per: int
                   ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Pick the `per` nearest candidates in each of the 8 octants around the
    query. Candidates arrive sorted by distance (cKDTree.query).

    Returns (slot (m, 8*per): column into the candidate axis,
             valid (m, 8*per): slot holds a real candidate,
             thr (m, 8*per): taper radius for that slot = distance of the
             octant's next candidate, or of the farthest pool member when the
             octant has no further candidate). At thr the weight is zero, so a
             candidate entering or leaving an octant's selection by distance
             changes nothing."""
    m, k = off.shape[:2]
    oc = ((off[..., 0] > 0).astype(np.int8) + 2 * (off[..., 1] > 0)
          + 4 * (off[..., 2] > 0)).astype(np.int8)
    order = np.argsort(oc, axis=1, kind="stable")       # distance order kept per octant
    cnt = np.stack([(oc == o).sum(1) for o in range(8)], 1)          # (m,8)
    start = np.cumsum(cnt, 1) - cnt
    j = np.arange(per)
    pos = start[:, :, None] + j[None, None, :]                        # (m,8,per)
    valid = (j[None, None, :] < cnt[:, :, None]).reshape(m, -1)
    pos = np.minimum(pos, k - 1).reshape(m, -1)
    slot = np.take_along_axis(order, pos, 1)
    nxt = np.minimum(start + per, k - 1)                              # (m,8)
    nxt_d = np.take_along_axis(d, np.take_along_axis(order, nxt, 1), 1)
    thr8 = np.where(cnt > per, nxt_d, d[:, -1:])                      # (m,8)
    thr = np.repeat(thr8, per, axis=1)
    return slot, valid, thr


def _taper(d: np.ndarray, r: np.ndarray) -> np.ndarray:
    """Least-squares weight: inverse distance, tapered to 0 at radius r.
    Continuous in the query position for k-NN neighbourhoods (Franke-Nielson
    style), which is what keeps seams out of a densely sampled image."""
    x = np.clip(d / np.maximum(r, 1e-300), 0.0, 1.0)
    return ((1.0 - x) / (x + 1e-3)) ** 2


def _shepard(d: np.ndarray, r: np.ndarray, power: float) -> np.ndarray:
    """Modified Shepard weight ((r-d)/(r d))^p: IDW without plateau seams."""
    r = np.maximum(r, 1e-300)
    return (np.clip(r - d, 0.0, None) / (r * np.maximum(d, 1e-12))) ** power


def _idw(fit: _Fit, V: np.ndarray, q: np.ndarray, k: int, power: float
         ) -> tuple[np.ndarray, np.ndarray]:
    k = int(min(k + 1, fit.points.shape[0]))          # +1: the taper radius
    d, i = fit.tree.query(q, k=k, workers=-1)
    d = np.atleast_2d(d)
    i = np.atleast_2d(i)
    w = _shepard(d, d[:, -1:], power)
    w[:, -1] = 0.0
    wsum = w.sum(1)
    flat = wsum <= 0                                    # all k at equal distance
    if flat.any():
        w[flat] = 1.0
        wsum[flat] = w[flat].sum(1)
    out = np.einsum("mk,mkf->mf", w, V[i]) / wsum[:, None]
    exact = d[:, 0] <= 1e-12
    if exact.any():
        out[exact] = V[i[exact, 0]]
    return out, d[:, 0]
