"""Slice use-cases: single plane, axis batches, plane batches.

All of them now run through SliceComputeService -- the same geometry,
sampling, classification and evaluation as the single-slice export -- so a
batch item and a single export with the same parameters produce the same
numbers. In v2.7 the free-plane batch ignored fidelity/sample_px and always
read the grid at 400x400.

Batch memory is bounded: each slice is computed, written to a temporary NPZ
and released; the shared colour range is accumulated on the way, and the
PNGs are rendered in a second pass. A slice that fails is recorded and the
batch continues; the result says which items failed, and the ZIP (written
atomically, with manifest.json inside) contains only completed items.
"""
from __future__ import annotations

import json
import shutil
import time
import uuid
import zipfile
from pathlib import Path
from typing import Any

import numpy as np

from fdpost import __version__
from fdpost.config import Settings
from fdpost.core.plane import euler_normal
from fdpost.core.query import positions_from_range
from fdpost.domain.errors import SampleBudgetError
from fdpost.domain.requests import (AxisSliceBatch, PlaneSliceBatch,
                                    PlaneSliceRequest, SliceExportRequest)
from fdpost.render.contour import compute_global_clim, render_slice_result
from fdpost.services.dataset_store import DatasetStore
from fdpost.services.slice_compute_service import SliceComputeService, SliceResult


def _save_tmp(res: SliceResult, path: Path) -> None:
    np.savez(path, values=res.values, state=res.state, quality=res.quality,
             **({"vec": res.vec_world} if res.vec_world is not None else {}))


def _load_tmp(res_shell: SliceResult, path: Path) -> SliceResult:
    with np.load(path) as z:
        res_shell.values = z["values"]
        res_shell.state = z["state"]
        res_shell.quality = z["quality"]
        res_shell.vec_world = z["vec"] if "vec" in z.files else None
    return res_shell


class SliceService:
    def __init__(self, store: DatasetStore, settings: Settings) -> None:
        self.store = store
        self.settings = settings
        self.compute = SliceComputeService(store, settings)

    def _out_dir(self, tag: str) -> Path:
        d = Path(self.settings.output_dir) / f"{tag}_{uuid.uuid4().hex[:8]}"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _export(self):
        from fdpost.services.slice_export_service import SliceExportService
        return SliceExportService(self.store, self.settings)

    # -- single free plane (「高解像度描画」) ---------------------------------
    def run_plane_slice(self, ds_id: str, req: PlaneSliceRequest) -> dict[str, Any]:
        exp = self._export()
        specs = exp.specs(req)
        exp._check_image(specs)
        res = self.compute.compute(ds_id, req, req.field, specs.sampling, specs.evaluation,
                                   with_vectors=req.with_vectors)
        out = self._out_dir("plane")
        p = out / "plane_slice.png"
        ra = render_slice_result(res, p, specs.render)
        from fdpost.services.slice_export_service import build_manifest
        man = build_manifest(res, req, specs, ra, {"png": str(p)}, self.settings)
        (out / "manifest.json").write_text(json.dumps(man, ensure_ascii=False, indent=2),
                                           encoding="utf-8")
        return {"file": str(p), "origin": res.plane.origin.tolist(),
                "normal": res.plane.normal.tolist(),
                "dims": list(res.shape), "source": res.meta.get("source"),
                "method_used": res.meta.get("method_used"), "render_actual": ra,
                "adapter_notes": specs.notes}

    # -- batches ---------------------------------------------------------------
    def run_axis_batch(self, ds_id: str, req: AxisSliceBatch,
                       report=lambda f, m="": None) -> dict[str, Any]:
        positions = positions_from_range(req.start, req.stop, req.step)
        items = []
        for pos in positions:
            g = SliceExportRequest(mode="axis", axis=req.axis, position=float(pos))
            items.append((g, f"slice_{req.axis}_{{i:04d}}_{float(pos):+.6f}m.png",
                          {"position_m": float(pos)}))
        return self._batch(ds_id, req, items, "slices", report)

    def run_plane_batch(self, ds_id: str, req: PlaneSliceBatch,
                        report=lambda f, m="": None) -> dict[str, Any]:
        distances = positions_from_range(req.distance_start, req.distance_stop,
                                         req.distance_step)
        items = []
        for d in distances:
            if req.mode == "euler":
                g = SliceExportRequest(mode="euler", tilt_deg=req.tilt_deg,
                                       azimuth_deg=req.azimuth_deg, distance=float(d),
                                       extent_u=req.extent_u, extent_v=req.extent_v)
            else:
                n = np.asarray(req.normal, dtype=np.float64)
                n = n / np.linalg.norm(n)
                o = np.asarray(req.origin, dtype=np.float64) + n * float(d)
                g = SliceExportRequest(mode="point_normal", origin=tuple(o),
                                       normal=tuple(n), extent_u=req.extent_u,
                                       extent_v=req.extent_v)
            items.append((g, f"plane_{{i:04d}}_{float(d):+.6f}m.png", {"distance_m": float(d)}))
        return self._batch(ds_id, req, items, "planes", report)

    def _batch(self, ds_id: str, req: Any, items: list, tag: str,
               report) -> dict[str, Any]:
        if len(items) > self.settings.batch_max_slices:
            raise SampleBudgetError(
                f"{len(items)} slices exceeds the batch limit of "
                f"{self.settings.batch_max_slices}")
        exp = self._export()
        specs = exp.specs(req, batch=True)
        exp._check_image(specs)
        out = self._out_dir(tag)
        tmp = out / "_work"
        tmp.mkdir()
        t0 = time.perf_counter()
        shells: list[tuple[int, SliceResult, Path, str, dict]] = []
        failed: list[dict[str, Any]] = []
        all_vals: list[np.ndarray] = []
        lo, hi = np.inf, -np.inf
        n = len(items)
        # pass 1: compute, spill to disk, accumulate the colour range
        for i, (geom, name_t, label) in enumerate(items):
            try:
                res = self.compute.compute(ds_id, geom, req.field, specs.sampling,
                                           specs.evaluation, with_vectors=req.with_vectors)
                vv = res.valid_values()
                if vv.size:
                    lo, hi = min(lo, float(vv.min())), max(hi, float(vv.max()))
                p = tmp / f"{i:04d}.npz"
                _save_tmp(res, p)
                res.values = res.state = res.quality = None  # type: ignore[assignment]
                res.vec_world = None
                shells.append((i, res, p, name_t.format(i=i), label))
            except Exception as e:  # noqa: BLE001 - recorded per item
                failed.append({"index": i, **label, "error": f"{type(e).__name__}: {e}"})
            report(0.6 * (i + 1) / n, f"sampled {i + 1}/{n}")
        r = specs.render
        if r.clim_mode == "fixed" and r.clim is not None:
            clim = (float(r.clim[0]), float(r.clim[1]))
        elif r.clim_mode == "batch_global":
            clim = compute_global_clim([np.array([lo, hi])]) if np.isfinite(lo) else None
        else:
            clim = None                       # per-slice automatic
        # pass 2: render with the shared range
        paths: list[Path] = []
        entries = []
        for j, (i, shell, p, name, label) in enumerate(shells):
            res = _load_tmp(shell, p)
            try:
                png = out / name
                ra = render_slice_result(res, png, r, clim=clim)
                paths.append(png)
                entries.append({"index": i, **label, "file": png.name,
                                "geometry_actual": res.meta["geometry_actual"],
                                "sample_shape": list(res.shape),
                                "method_used": res.meta["method_used"],
                                "classification": res.meta["classification_summary"]["counts"],
                                "render_actual": ra})
            except Exception as e:  # noqa: BLE001
                failed.append({"index": i, **label, "error": f"{type(e).__name__}: {e}"})
            p.unlink(missing_ok=True)
            res.values = res.state = res.quality = None  # type: ignore[assignment]
            report(0.6 + 0.35 * (j + 1) / max(len(shells), 1), f"rendered {name}")
        shutil.rmtree(tmp, ignore_errors=True)
        manifest = {
            "schema_version": 2, "program": {"name": "fdpost", "version": __version__},
            "kind": tag, "request": req.model_dump(mode="json"),
            "adapter_notes": specs.notes,
            "resolved": {"sampling": specs.sampling.model_dump(exclude_none=True),
                         "evaluation": specs.evaluation.model_dump(exclude_none=True),
                         "render": r.model_dump(exclude_none=True)},
            "clim_used": list(clim) if clim else None,
            "n_requested": n, "n_done": len(entries), "failed": failed,
            "items": entries, "elapsed_s": round(time.perf_counter() - t0, 3),
            "settings_in_force": {k: v for k, v in self.settings.effective().items()
                                  if k.startswith(("export_", "source_", "local_",
                                                   "balanced_", "anisotropy", "max_cond",
                                                   "idw_", "support_"))},
        }
        mpath = out / "manifest.json"
        mpath.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        zip_path = out / f"{tag}.zip"
        part = out / f"{tag}.zip.part"
        with zipfile.ZipFile(part, "w", zipfile.ZIP_DEFLATED) as z:
            for pth in paths:
                z.write(pth, pth.name)
            z.write(mpath, mpath.name)
        part.replace(zip_path)                    # publish only a complete archive
        report(1.0, "done" if not failed else f"done with {len(failed)} failure(s)")
        return {"n_slices": len(paths), "n_requested": n,
                "status": "complete" if not failed else "partial",
                "failed": failed, "dir": str(out),
                "files": [str(p) for p in paths], "zip": str(zip_path),
                "manifest": str(mpath), "clim": list(clim) if clim else None}
