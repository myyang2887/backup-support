"""Region export use-cases: resolution-controlled CSV for a 3D box or a plane.

Both entry points share one shape — resolve geometry, sample the cached grid
at the requested resolution, write one CSV — so adding another region kind
later means adding one `run_*` method, not a new service.
"""
from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any

import numpy as np

from fdpost.config import Settings
from fdpost.core.query import plane_frame, resolve_plane, sample_box, sample_plane
from fdpost.domain.requests import BoxRegionRequest, PlaneRegionRequest
from fdpost.io.csv_writer import write_csv
from fdpost.services.dataset_store import DatasetStore


class RegionService:
    def __init__(self, store: DatasetStore, settings: Settings) -> None:
        self.store = store
        self.settings = settings

    def _write(self, df, grid, tag: str) -> tuple[Path, int]:
        out = Path(self.settings.output_dir) / f"{tag}_{uuid.uuid4().hex[:8]}"
        out.mkdir(parents=True, exist_ok=True)
        return write_csv(df, out / f"{tag}.csv", units=grid.units), len(df)

    def run_box(self, ds_id: str, req: BoxRegionRequest) -> dict[str, Any]:
        grid = self.store.get_grid(ds_id)
        fields = req.fields or sorted(grid.arrays)
        df = sample_box(grid, req.min_point, req.max_point, req.resolution,
                        fields, max_rows=self.settings.max_export_rows,
                        spacing=req.spacing)
        csv_path, n = self._write(df, grid, "region")
        return {"csv": str(csv_path), "n_rows": n, "fields": fields}

    def run_plane(self, ds_id: str, req: PlaneRegionRequest) -> dict[str, Any]:
        if req.source == "original":
            return self._run_plane_original(ds_id, req)
        grid = self.store.get_grid(ds_id)
        fields = req.fields or sorted(grid.arrays)
        origin, normal = resolve_plane(req, grid)
        df = sample_plane(grid, origin, normal, fields,
                          max_rows=self.settings.max_export_rows,
                          extent_u=req.extent_u, extent_v=req.extent_v,
                          resolution=req.resolution, spacing=req.spacing)
        csv_path, n = self._write(df, grid, "plane_region")
        fr = plane_frame(grid, origin, normal, req.extent_u, req.extent_v)
        return {"csv": str(csv_path), "n_rows": n, "fields": fields,
                "origin": origin.tolist(), "normal": normal.tolist(),
                "extent_u": list(fr.extent_u), "extent_v": list(fr.extent_v)}

    def _run_plane_original(self, ds_id: str, req: PlaneRegionRequest) -> dict[str, Any]:
        """Plane CSV from the source data via the slice compute path."""
        from fdpost.domain.requests import EvaluationSpec, SamplingSpec
        from fdpost.services.slice_compute_service import SliceComputeService

        ev = self.store.get_evaluator(ds_id)
        fields = req.fields or sorted(f for f in ev.fd.fields
                                      if f not in ("volume", "surface"))
        sampling = (SamplingSpec(mode="spacing", spacing_m=req.spacing) if req.spacing
                    else SamplingSpec(mode="counts", counts=req.resolution))
        res = SliceComputeService(self.store, self.settings).compute(
            ds_id, req, fields[0], sampling,
            EvaluationSpec(source="original", method=req.method),
            max_points=self.settings.max_export_rows, extra_fields=fields[1:])
        import pandas as pd
        df = pd.DataFrame(res.table())
        csv_path, n = self._write(df, self.store.get_grid(ds_id), "plane_region")
        return {"csv": str(csv_path), "n_rows": n, "fields": fields,
                "origin": res.plane.origin.tolist(), "normal": res.plane.normal.tolist(),
                "extent_u": list(res.plane.extent_u), "extent_v": list(res.plane.extent_v),
                "source": "original", "method_used": res.meta.get("method_used")}
