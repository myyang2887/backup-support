"""Source-data access cache.

v2.4-v2.7 kept a `SourceSampler` here whose slice path gathered the points
near a plane and interpolated them in a 2D projection ("slab"). That path
mixed different heights into one picture and has been removed; all source
evaluation now happens at exact 3D positions in
`fdpost.services.field_evaluator.FieldEvaluator`.

What remains is the small LRU that keeps loaded evaluators (source table +
KD-trees, the expensive part) between requests. Keys include the source
file signature, the fluid rule and the evaluator configuration, so a changed
file, a changed rule or a changed algorithm setting never reuses a stale fit.
"""
from __future__ import annotations

import threading
from collections import OrderedDict
from typing import Generic, TypeVar

T = TypeVar("T")


class LRU(Generic[T]):
    def __init__(self, size: int = 2) -> None:
        self.size = max(1, int(size))
        self._items: OrderedDict[str, T] = OrderedDict()
        self._lock = threading.RLock()

    def get(self, key: str) -> T | None:
        with self._lock:
            if key in self._items:
                self._items.move_to_end(key)
                return self._items[key]
        return None

    def put(self, key: str, item: T) -> T:
        with self._lock:
            self._items[key] = item
            self._items.move_to_end(key)
            while len(self._items) > self.size:
                self._items.popitem(last=False)
        return item

    def drop_prefix(self, prefix: str) -> None:
        with self._lock:
            for k in [k for k in self._items if k.startswith(prefix)]:
                self._items.pop(k, None)


# kept for imports from older code paths
SourceSamplerCache = LRU
