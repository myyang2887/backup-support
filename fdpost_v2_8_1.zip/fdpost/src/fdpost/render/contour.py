"""Slice rendering (matplotlib, headless).

`render_slice_result` is the v2.8 formal renderer: it only colours an already
computed `SliceResult` -- numbers are never re-sampled or smoothed here.

Pixel contract
--------------
size_mode='pixels'  the PNG's long edge is exactly `long_edge_px`; `dpi` only
                    sets the print size written into the file.
size_mode='print'   long edge = print_long_edge_mm at `dpi`.
The layout (margins, colour bar, title) is fixed in advance and the canvas is
never cropped after drawing, then the saved size is read back and reported
together with the size of the field area itself.

Layers (bottom -> top)
----------------------
background  outside-the-data area (white, or transparent)
values      field values on fluid samples (and on solid samples when solids
            are not painted and the field exists there)
unknown     samples without data support, or fluid samples without a value
solid       solid samples in `solid_color` (when show_solid)
vectors     optional in-plane arrows
Masks are drawn nearest-sample, so no colour is ever blended across a
solid/fluid edge.
"""
from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any

import matplotlib
import numpy as np
from matplotlib.colors import to_rgba

from fdpost.core.query import Slice2D
from fdpost.render.style import BASE_RC, apply_style, make_cmap

# Matplotlib is not thread-safe; the server renders from job threads.
RENDER_LOCK = threading.RLock()

_ASCII_NO_DATA = "No valid data in this section"


def compute_global_clim(arrays: list[np.ndarray]) -> tuple[float, float] | None:
    """NaN-ignoring (vmin, vmax) over arrays; None when nothing is finite.
    A constant field gets a tiny symmetric display margin (values unchanged)."""
    lo, hi = np.inf, -np.inf
    for a in arrays:
        a = np.asarray(a, dtype=np.float64)
        f = a[np.isfinite(a)]
        if f.size:
            lo, hi = min(lo, float(f.min())), max(hi, float(f.max()))
    if not np.isfinite(lo):
        return None
    if hi <= lo:
        pad = max(abs(lo) * 1e-6, 1e-12)
        return lo - pad, hi + pad
    return lo, hi


# --- formal renderer ----------------------------------------------------------

def _layout(aspect: float, long_in: float, show_axes: bool, colorbar: bool,
            font_pt: float) -> tuple[float, float, dict[str, float]]:
    """Figure (W, H) inches and the axes rectangle, long side == long_in."""
    em = font_pt / 72.0
    if show_axes:
        left, bottom, top = 6.2 * em, 3.8 * em, 3.4 * em
        right = 8.0 * em if colorbar else 1.5 * em
    else:
        left = right = bottom = top = 0.0
    lr, tb = left + right, top + bottom
    fw = max(long_in - lr, 0.1)
    fh = fw / aspect
    w, h = long_in, fh + tb
    if h > long_in:
        fh = max(long_in - tb, 0.1)
        fw = fh * aspect
        w, h = fw + lr, long_in
    return w, h, {"left": left, "right": right, "bottom": bottom, "top": top,
                  "fw": fw, "fh": fh, "em": em}


def render_slice_result(res: Any, path: str | Path, opts: Any,
                        clim: tuple[float, float] | None = None,
                        title_extra: str = "") -> dict[str, Any]:
    """Draw a SliceResult. `clim` overrides opts (used for batch-shared
    ranges). Returns `render_actual` for the manifest."""
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.figure import Figure
    from PIL import Image

    from fdpost.services.field_evaluator import FLUID, SOLID, UNKNOWN

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    u, v, xl, yl = res.display_axes()
    nu, nv = res.shape
    du = float(u[1] - u[0]) if nu > 1 else max(float(v[-1] - v[0]) / max(nv - 1, 1), 1e-9)
    dv = float(v[1] - v[0]) if nv > 1 else du
    extent = [float(u[0] - du / 2), float(u[-1] + du / 2),
              float(v[0] - dv / 2), float(v[-1] + dv / 2)]
    aspect = (extent[1] - extent[0]) / (extent[3] - extent[2])

    dpi = int(opts.dpi)
    if opts.size_mode == "pixels":
        long_px = int(opts.long_edge_px)
    else:
        long_px = int(round(opts.print_long_edge_mm / 25.4 * dpi))
    long_in = long_px / dpi

    if clim is None:
        if opts.clim_mode == "fixed" and opts.clim is not None:
            clim = (float(opts.clim[0]), float(opts.clim[1]))
        else:
            clim = compute_global_clim([res.valid_values()])
    has_cbar = clim is not None and opts.show_axes
    font_pt = float(np.clip(long_in * 1.05, 6.0, 30.0))
    w_in, h_in, L = _layout(aspect, long_in, opts.show_axes, has_cbar, font_pt)
    # integer canvas, long side exact
    if w_in >= h_in:
        w_px, h_px = long_px, max(1, int(round(h_in * dpi)))
    else:
        w_px, h_px = max(1, int(round(w_in * dpi))), long_px
    W, H = w_px / dpi, h_px / dpi

    show_solid = bool(opts.show_solid)
    st = res.state
    vals = res.values
    finite = np.isfinite(vals)
    show_val = finite & ((st == FLUID) | ((st == SOLID) & (not show_solid)))
    unknown = (st == UNKNOWN) | ((st == FLUID) & ~finite)

    bg = (1, 1, 1, 0) if opts.transparent_background else (1, 1, 1, 1)
    rc = {**BASE_RC, "font.size": font_pt, "savefig.bbox": None}
    with RENDER_LOCK, matplotlib.rc_context(rc):
        fig = Figure(figsize=(W, H), dpi=dpi, facecolor=bg)
        FigureCanvasAgg(fig)
        if opts.show_axes:
            ax = fig.add_axes((L["left"] / W, L["bottom"] / H, L["fw"] / W, L["fh"] / H))
        else:
            ax = fig.add_axes((0, 0, 1, 1))
            ax.set_axis_off()
        ax.set_facecolor(bg)
        downsample = nu > L["fw"] * dpi * 1.05 or nv > L["fh"] * dpi * 1.05
        interp = ("bilinear" if opts.smooth else
                  ("antialiased" if downsample else "nearest"))
        im = None
        if clim is not None:
            data = np.ma.masked_array(vals, mask=~show_val).T
            im = ax.imshow(data, origin="lower", extent=extent, aspect="auto",
                           cmap=make_cmap(opts.cmap), vmin=clim[0], vmax=clim[1],
                           interpolation=interp)

        def layer(mask: np.ndarray, color: str) -> None:
            if not mask.any():
                return
            rgba = np.zeros(mask.T.shape + (4,), dtype=np.float32)
            rgba[mask.T] = to_rgba(color)
            ax.imshow(rgba, origin="lower", extent=extent, aspect="auto",
                      interpolation="nearest")

        layer(unknown, opts.unknown_color)
        if show_solid:
            layer(st == SOLID, opts.solid_color)

        uv = res.vec_uv
        if uv is not None:
            s = int(opts.vector_stride or max(1, min(nu, nv) // 24))
            gu, gv = np.meshgrid(u[::s], v[::s], indexing="ij")
            vu, vv = uv[0][::s, ::s], uv[1][::s, ::s]
            ok = (st[::s, ::s] == FLUID) & np.isfinite(vu) & np.isfinite(vv)
            if ok.any():
                ax.quiver(gu[ok], gv[ok], vu[ok], vv[ok], color="white",
                          edgecolor="black", linewidth=0.3, width=0.0022,
                          scale_units="width")
        ax.set_xlim(extent[0], extent[1])
        ax.set_ylim(extent[2], extent[3])
        if opts.show_axes:
            ax.set_xlabel(xl)
            ax.set_ylabel(yl)
            unit = f" [{res.unit}]" if res.unit else ""
            du_mm, dv_mm = (abs(x) * 1e3 for x in res.lattice.spacing)
            src = res.meta.get("source", "")
            meth = res.meta.get("method_requested", "")
            line2 = (f"{res.field}{unit}  |  {src}: {meth}  |  {nu} x {nv} samples, "
                     f"{du_mm:.3g} x {dv_mm:.3g} mm{title_extra}")
            ax.set_title(f"{res.plane.title()}\n{line2}", fontsize=font_pt * 0.82)
            if has_cbar and im is not None:
                cax = fig.add_axes(((L["left"] + L["fw"] + 1.2 * L["em"]) / W,
                                    L["bottom"] / H, 1.3 * L["em"] / W, L["fh"] / H))
                fig.colorbar(im, cax=cax, label=f"{res.field}{unit}")
        if clim is None:
            ax.text(0.5, 0.5, _ASCII_NO_DATA, transform=ax.transAxes,
                    ha="center", va="center", fontsize=font_pt,
                    bbox={"facecolor": "white", "alpha": 0.8, "edgecolor": "none"})
        summary = {"field": res.field, "plane": res.plane.describe(),
                   "sample_shape": [nu, nv], "clim": list(clim) if clim else None,
                   "method": res.meta.get("method_requested")}
        fig.savefig(path, dpi=dpi, facecolor=bg, transparent=opts.transparent_background,
                    metadata={"Software": "fdpost", "Description": json.dumps(summary)})
    with Image.open(path) as img:
        real_w, real_h = img.size
    return {"file": path.name, "image_width_px": real_w, "image_height_px": real_h,
            "requested_long_edge_px": long_px,
            "field_width_px": int(round(L["fw"] * dpi)),
            "field_height_px": int(round(L["fh"] * dpi)),
            "dpi": dpi, "size_mode": opts.size_mode,
            "print_size_mm": [round(real_w / dpi * 25.4, 2), round(real_h / dpi * 25.4, 2)],
            "clim": list(clim) if clim else None,
            "clim_mode": opts.clim_mode, "cmap": opts.cmap,
            "colorbar": bool(has_cbar), "show_solid": show_solid,
            "solid_color": opts.solid_color, "unknown_color": opts.unknown_color,
            "transparent_background": bool(opts.transparent_background),
            "display_smoothing": bool(opts.smooth), "interpolation": interp}


# --- legacy grid renderer (CLI) -------------------------------------------------

def render_slice_png(sl: Slice2D, path: str | Path,
                     clim: tuple[float, float] | None = None,
                     cmap: str = "jet", dpi: int = 150,
                     vector_stride: int = 8, smooth: bool = False,
                     show_solid: bool = True,
                     solid_color: str = "black") -> Path:
    """v2.x figure for grid slices (CLI). Kept for compatibility; cropped
    tight per save. The web export uses render_slice_result."""
    apply_style()
    import matplotlib.pyplot as plt

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    du = float(sl.u[-1] - sl.u[0]) or 1.0
    dv = float(sl.v[-1] - sl.v[0]) or 1.0
    if du >= dv:
        figsize = (9.0, max(3.0, 7.0 * dv / du + 1.2))
    else:
        figsize = (max(4.0, 7.0 * du / dv + 1.8), 8.0)
    with RENDER_LOCK:
        fig, ax = plt.subplots(figsize=figsize)
        lim = clim if clim else compute_global_clim([sl.values])
        vmin, vmax = lim if lim else (0.0, 1.0)
        ax.set_facecolor(solid_color if show_solid else "none")
        mesh = ax.pcolormesh(sl.u, sl.v, sl.values.T, cmap=make_cmap(cmap),
                             vmin=vmin, vmax=vmax,
                             shading="gouraud" if smooth else "nearest")
        if sl.vec_u is not None and sl.vec_v is not None:
            s = max(1, int(vector_stride))
            gu, gv = np.meshgrid(sl.u[::s], sl.v[::s], indexing="ij")
            ax.quiver(gu, gv, sl.vec_u[::s, ::s], sl.vec_v[::s, ::s],
                      color="white", width=0.0022, scale_units="width")
        ax.set_xlabel(sl.u_label)
        ax.set_ylabel(sl.v_label)
        ax.set_title(sl.title, fontsize=10)
        ax.set_aspect("equal", adjustable="box")
        unit = f" [{sl.unit}]" if sl.unit else ""
        if lim is not None:
            fig.colorbar(mesh, ax=ax, label=f"{sl.field}{unit}")
        else:
            ax.text(0.5, 0.5, _ASCII_NO_DATA, transform=ax.transAxes,
                    ha="center", va="center")
        fig.savefig(path, dpi=dpi, bbox_inches="tight")
        plt.close(fig)
    return path


def render_slice_batch(slices: list[Slice2D], out_dir: str | Path, axis: str,
                       positions: np.ndarray,
                       clim: tuple[float, float] | None = None,
                       cmap: str = "jet", dpi: int = 150,
                       vector_stride: int = 8,
                       progress=None, smooth: bool = False,
                       show_solid: bool = True,
                       solid_color: str = "black") -> list[Path]:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if clim is None:
        clim = compute_global_clim([s.values for s in slices])
    paths = []
    for i, (sl, pos) in enumerate(zip(slices, positions)):
        p = out_dir / f"slice_{axis}_{i:04d}_{pos:+.6f}m.png"
        render_slice_png(sl, p, clim=clim, cmap=cmap, dpi=dpi,
                         vector_stride=vector_stride, smooth=smooth,
                         show_solid=show_solid, solid_color=solid_color)
        paths.append(p)
        if progress:
            progress((i + 1) / len(slices), f"rendered {p.name}")
    return paths
