"""Matplotlib style. Agg backend MUST be selected before pyplot import.

v2.8: no global `savefig.bbox = "tight"` any more. A global tight bbox crops
every saved figure to its contents, so no caller could produce an image of a
requested pixel size. Callers that want tight cropping ask for it per save.
"""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")  # headless; must precede any pyplot import

import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import Colormap  # noqa: E402

FONT_FALLBACK = ["Noto Sans CJK JP", "Yu Gothic", "Meiryo", "MS Gothic", "DejaVu Sans"]

BASE_RC = {
    "font.family": "sans-serif",
    "font.sans-serif": FONT_FALLBACK,
    "axes.unicode_minus": False,
    "figure.dpi": 100,
    "savefig.bbox": None,
    "axes.grid": False,
}

_applied = False


def apply_style() -> None:
    global _applied
    if _applied:
        return
    plt.rcParams.update(BASE_RC)
    _applied = True


def make_cmap(name: str = "jet") -> Colormap:
    """Colormap whose 'bad' (NaN / masked) colour is fully transparent.

    Solid, outside and unknown samples are painted by their own layers in the
    slice renderer; letting the colormap paint them black (v2.x) tied three
    different states to one colour and broke transparent output."""
    cmap = plt.get_cmap(name).copy()
    cmap.set_bad(color=(0.0, 0.0, 0.0, 0.0))
    return cmap
