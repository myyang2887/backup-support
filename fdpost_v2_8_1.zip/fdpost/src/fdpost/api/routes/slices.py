from __future__ import annotations

from fastapi import APIRouter, Request

from fdpost.api.schemas import JobOut
from fdpost.api.ephemeral import stream_export
from fdpost.api.urlize import add_urls
from fdpost.services.slice_export_service import SliceExportService
from fdpost.domain.requests import SliceExportRequest, AxisSliceBatch, PlaneSliceBatch, PlaneSliceRequest

router = APIRouter(prefix="/api/datasets/{ds_id}/slices", tags=["slices"])


@router.post("/axis-batch", response_model=JobOut)
def axis_batch(ds_id: str, req: AxisSliceBatch, request: Request):
    svc = request.app.state.slice_service
    job = request.app.state.jobs.submit(
        "axis_slice_batch", lambda report: svc.run_axis_batch(ds_id, req, report))
    return job.snapshot()


@router.post("/plane", )
def plane(ds_id: str, req: PlaneSliceRequest, request: Request):
    """Single arbitrary plane: synchronous (~100ms) for interactive use."""
    res = request.app.state.slice_service.run_plane_slice(ds_id, req)
    return add_urls(res, request.app.state.settings.output_dir)


@router.post("/plane-batch", response_model=JobOut)
def plane_batch(ds_id: str, req: PlaneSliceBatch, request: Request):
    svc = request.app.state.slice_service
    job = request.app.state.jobs.submit(
        "plane_slice_batch", lambda report: svc.run_plane_batch(ds_id, req, report))
    return job.snapshot()


@router.post("/export")
def slice_export(ds_id: str, req: SliceExportRequest, request: Request,
                 deliver: str = "url"):
    """Export the slice currently on screen.

    deliver=url    — write into output_dir and return links (default).
    deliver=stream — build in a temp dir, return the bytes, keep nothing.
                     Use this when the server is shared: a remote user's
                     downloads should not pile up on the host's disk.
    """
    svc = request.app.state.slice_export_service
    settings = request.app.state.settings
    if deliver == "stream":
        return stream_export(
            settings,
            lambda s: SliceExportService(svc.store, s).run(ds_id, req),
            stem=f"slice_{req.axis}")
    return add_urls(svc.run(ds_id, req), settings.output_dir)


@router.post("/estimate")
def slice_estimate(ds_id: str, req: SliceExportRequest, request: Request):
    """How long would this export take? Measured on a sample of the actual
    lattice with the actual method (see services.slice_compute_service.estimate).
    Also warms the caches, so the export that follows starts hot."""
    from fdpost.services.slice_compute_service import estimate

    svc = request.app.state.slice_export_service
    specs = svc.specs(req)
    r = specs.render
    long_px = (r.long_edge_px if r.size_mode == "pixels"
               else int(round(r.print_long_edge_mm / 25.4 * r.dpi)))
    return estimate(svc.compute, ds_id, req, req.field, specs.sampling, specs.evaluation,
                    image_long_px=long_px, with_csv="csv" in req.formats)
