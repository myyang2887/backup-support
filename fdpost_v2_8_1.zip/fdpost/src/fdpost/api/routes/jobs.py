from __future__ import annotations

from fastapi import APIRouter, Request

from fdpost.api.schemas import JobOut
from fdpost.api.urlize import add_urls

router = APIRouter(prefix="/api/jobs", tags=["jobs"])


@router.get("/{job_id}", response_model=JobOut)
def get_job(job_id: str, request: Request):
    snap = request.app.state.jobs.get(job_id).snapshot()
    if snap.get("result"):
        snap["result"] = add_urls(snap["result"],
                                  request.app.state.settings.output_dir)
    return snap


@router.post("/{job_id}/cancel", response_model=JobOut)
def cancel_job(job_id: str, request: Request):
    """Request cancellation. Takes effect at the job's next checkpoint (a
    chunk of samples); a queued job never starts. Idempotent."""
    return request.app.state.jobs.cancel(job_id).snapshot()
