"""Run an export without leaving anything on the server's disk.

Exports are rendered server-side (matplotlib and the sampler run there), so
a file has to exist somewhere. Normally that is `output_dir`, which is fine
for a single-user desktop run but wrong when colleagues use the machine as a
shared server: their downloads accumulate on someone else's drive forever.

This runs the same service against a throwaway directory, streams the bytes
back in the HTTP response, and deletes the directory. Nothing persists.

Multiple files become a zip, because one HTTP response can carry one body.
"""
from __future__ import annotations

import io
import json
import mimetypes
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Callable

from fastapi import Response

from fdpost.config import Settings

# result keys that hold a generated file path
_FILE_KEYS = ("png", "csv", "npz", "manifest", "zip", "file")


def stream_export(settings: Settings, build: Callable[[Settings], dict[str, Any]],
                  stem: str = "export") -> Response:
    """`build` receives Settings pointed at a temp dir and returns the usual
    service result dict; its output files are returned as the response body."""
    with tempfile.TemporaryDirectory(prefix="fdpost-stream-") as td:
        scoped = settings.model_copy(update={"output_dir": Path(td)})
        result = build(scoped)

        paths = [Path(result[k]) for k in _FILE_KEYS
                 if isinstance(result.get(k), str) and Path(result[k]).is_file()]
        extra = result.get("files")
        if isinstance(extra, list):
            paths += [Path(p) for p in extra
                      if isinstance(p, str) and Path(p).is_file()]
        if not paths:
            raise FileNotFoundError("export produced no files")

        summary = _summary(result)
        if len(paths) == 1:
            p = paths[0]
            media = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
            return _attachment(p.read_bytes(), p.name, media, summary)

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for p in paths:
                z.write(p, arcname=p.name)
        return _attachment(buf.getvalue(), f"{stem}.zip", "application/zip", summary)


def _summary(result: dict[str, Any]) -> str:
    """What was actually produced, small enough for a response header, so a
    streamed download can still tell the UI the real position / samples /
    image size (the full record is manifest.json inside the download)."""
    ga = result.get("geometry_actual") or {}
    ra = result.get("render_actual") or {}
    s = {"dims": result.get("dims"), "spacing_m": result.get("spacing_m"),
         "position_m": ga.get("position_m"), "source": result.get("source"),
         "method_used": result.get("method_used"),
         "image_px": ([ra.get("image_width_px"), ra.get("image_height_px")]
                      if ra else None),
         "states": (result.get("classification_summary") or {}).get("counts")}
    return json.dumps(s, ensure_ascii=True, separators=(",", ":"))


def _attachment(data: bytes, filename: str, media_type: str,
                summary: str | None = None) -> Response:
    headers = {"Content-Disposition": f'attachment; filename="{filename}"',
               "Content-Length": str(len(data)),
               # tells the client this came straight from memory
               "X-Fdpost-Ephemeral": "1"}
    if summary:
        headers["X-Fdpost-Summary"] = summary
    return Response(content=data, media_type=media_type, headers=headers)
