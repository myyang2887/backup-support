"""API response schemas (requests reuse domain models directly)."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class JobOut(BaseModel):
    id: str
    kind: str
    status: str
    progress: float
    message: str = ""
    result: dict[str, Any] | None = None
    error: str | None = None
    elapsed_s: float | None = None
    eta_s: float | None = None
    has_blob: bool = False


class DatasetOut(BaseModel):
    id: str
    source_path: str
    status: str
    error: str | None = None
    fields: list[str] = []
    units: dict[str, str] = {}
    bounds: list[list[float]] | None = None
    dims: list[int] | None = None
    spacing: list[float] | None = None
    meta: dict[str, Any] = {}
    config: dict[str, Any] = {}
    # Disk footprint, so the UI can show what a deletion will actually free.
    # A response_model silently drops fields it does not declare, which is
    # why this has to be listed here and not just returned by the service.
    storage: dict[str, Any] | None = None


class RegisterOut(BaseModel):
    dataset_id: str
    job_id: str
