"""
案件フォルダ単位の要約（v3.31）。

1 案件 = 1 フォルダ（台帳との照合で決める。app/case_detect.py）。
配下の資料をまとめて読み、テンプレートどおりに **1 つの要約** を書く。

流れ：

  1. 読む   … 各資料を既存のパイプラインで「精読まで」読む（要約は書かない）。
              置き場は out/case_members/<資料名>_<内容ハッシュ>/。内容で決まる
              ので、同じ資料を別の案件で使っても読み直さない。
  2. 合わせる … merge_case：全資料の証拠を、出典（資料名・頁）付きで 1 つにする。
              **圧縮しない**。消すのは資料をまたいだ完全な重複だけで、その場合も
              「どの資料にも書いてあったか」は残す。台帳は案件フォルダ名で 1 回だけ引く。
  3. 書く   … 既存の write_summary 以降（加筆・検証・修復・対応効果・描画・社外版・RAG）を
              そのまま使う。case_mode のときだけ上限を外し、案件用の規則を足す。

方針：情報の真実性と網羅性が最優先。文脈長は足りる前提で、証拠を削って収める
ことはしない（大きさは記録し、設定値を超えたら警告する）。
"""
from __future__ import annotations

import hashlib
import json
import re
import threading
import time
import traceback
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from langgraph.graph import END, StateGraph

from .case_detect import load_index, safe_case_name
from .config import AppConfig
from .llm_client import LocalLLMClient
from .observability import RunCancelled, RunStore

PROGRESS_FILE = "case_progress.json"

# 同じ資料（＝同じ置き場）を 2 つの案件が同時に読まないための錠。
# 既定の同時実行数 1 では起きないが、max_concurrent_runs を上げた場合の備え。
_member_locks: Dict[str, threading.Lock] = {}
_member_locks_guard = threading.Lock()


def _member_lock(mdir: Path) -> threading.Lock:
    with _member_locks_guard:
        return _member_locks.setdefault(str(Path(mdir).resolve()), threading.Lock())
CASE_VISUAL_FILE = "case_evidence_visual.json"   # 既定名にしない：図版機能は v3.32 で対応
MERGE_REPORT_FILE = "case_merge_report.json"


# ----------------------------------------------------------------------
# 置き場と識別子
# ----------------------------------------------------------------------

def members_root(config: AppConfig) -> Path:
    return config.paths.resolve(config.paths.out_dir) / "case_members"


def case_id_for(name: str, member_paths: List[str]) -> str:
    """案件 ID = 名前 + 全資料の内容ハッシュ。資料が 1 つ変われば別の ID。"""
    from .nodes import file_hash

    h = hashlib.sha1()
    for p in sorted(member_paths):
        h.update(file_hash(p).encode("ascii"))
    return f"case_{safe_case_name(name)}_{h.hexdigest()[:8]}"


def member_dir_for(config: AppConfig, path: str) -> Path:
    from .nodes import file_hash

    p = Path(path).resolve()
    return members_root(config) / f"{p.stem}_{file_hash(str(p))}"


def is_case_dir(run_dir: Path) -> bool:
    return (Path(run_dir) / PROGRESS_FILE).exists()


# ----------------------------------------------------------------------
# 進捗（画面表示用。ディスクが真源）
# ----------------------------------------------------------------------

def read_progress(case_dir: Path) -> Dict[str, Any]:
    try:
        return json.loads((Path(case_dir) / PROGRESS_FILE).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def _write_progress(case_dir: Path, prog: Dict[str, Any]) -> None:
    RunStore(case_dir).save_json(PROGRESS_FILE, prog)


def prepare_case_dir(case_dir: Path, case: Dict[str, Any], template_id: str,
                     template_name: str = "") -> None:
    """manifest と進捗を書く。manifest の input_path は案件名（台帳・履歴の表示名になる）。"""
    store = RunStore(case_dir)
    store.save_json(RunStore.MANIFEST, {
        "input_path": case["name"], "run_dir": str(case_dir),
        "template_id": template_id, "template_name": template_name,
        "case": True, "case_name": case["name"], "folders": case.get("folders", []),
        "match": case.get("match", {}),
        "members": [{k: m.get(k) for k in ("rel", "rel_in_case", "name", "path")}
                    for m in case["members"]],
    })
    _write_progress(case_dir, {
        "phase": "queued", "current": None, "updated": time.time(),
        "case_name": case["name"], "folders": case.get("folders", []),
        "members": [{"rel_in_case": m["rel_in_case"], "name": m["name"], "state": "queued"}
                    for m in case["members"]],
    })


# ----------------------------------------------------------------------
# 実行
# ----------------------------------------------------------------------

def run_case(case_dir: Path, case: Dict[str, Any], config: AppConfig, *,
             template_id: str = "case", input_mode: Optional[str] = None,
             deep_read: Optional[bool] = None, llm: Optional[LocalLLMClient] = None,
             on_active: Optional[Callable[[Optional[Path]], None]] = None) -> Dict[str, Any]:
    """案件 1 件を最後まで処理する。中止は case_dir の cancel.flag で受け付ける。"""
    from .graph import run_workflow

    case_dir = Path(case_dir)
    store = RunStore(case_dir)
    prog = read_progress(case_dir) or {}
    prog.update({"phase": "reading", "started": time.time()})
    if not prog.get("members"):
        prog["members"] = [{"rel_in_case": m["rel_in_case"], "name": m["name"], "state": "queued"}
                           for m in case["members"]]
    _write_progress(case_dir, prog)
    store.logger().info("case start: %s (%d 資料)", case["name"], len(case["members"]))

    mroot = members_root(config)
    results: List[Dict[str, Any]] = []
    for i, m in enumerate(case["members"]):
        store.raise_if_cancelled()
        mdir = member_dir_for(config, m["path"])
        prog["current"] = i
        prog["members"][i].update({"state": "running", "run_dir": str(mdir),
                                   "started": time.time()})
        prog["updated"] = time.time()
        _write_progress(case_dir, prog)
        if on_active:
            on_active(mdir)
        res = {**m, "run_dir": str(mdir), "state": "failed"}
        try:
            with _member_lock(mdir):
                final = run_workflow(
                    m["path"], config, template_id=template_id, input_mode=input_mode,
                    deep_read=deep_read, runs_root=str(mroot), read_only=True,
                    case_member=True, source_name=m["name"], source_rel_path=m.get("rel", ""))
            res.update(_member_result(final, mdir))
            res["state"] = "done"
        except RunCancelled:
            prog["members"][i]["state"] = "cancelled"
            _write_progress(case_dir, prog)
            raise
        except Exception as e:  # noqa: BLE001 1 資料の失敗で案件ごと捨てない（要約に明記する）
            res["error"] = f"{type(e).__name__}: {e}"
            store.logger().error("member failed: %s\n%s", m["rel_in_case"], traceback.format_exc())
        finally:
            if on_active:
                on_active(None)
        # 中止は資料の切れ目でも見る（資料側の中止フラグは次の実行で消えるため）
        if (mdir / RunStore.CANCEL_FLAG).exists():
            store.request_cancel()
        results.append(res)
        prog["members"][i].update({"state": res["state"], "error": res.get("error", ""),
                                   "text_evidence": res.get("n_text", 0),
                                   "visual_evidence": res.get("n_visual", 0),
                                   "finished": time.time()})
        prog["updated"] = time.time()
        _write_progress(case_dir, prog)

    store.raise_if_cancelled()
    if not any(r["state"] == "done" for r in results):
        raise RuntimeError("案件内のすべての資料の読み取りに失敗しました")

    # ---- 書く ----
    prog.update({"phase": "writing", "current": None, "updated": time.time()})
    _write_progress(case_dir, prog)
    store.reset_status()
    if llm is None:
        llm = LocalLLMClient(**config.llm.model_dump(exclude={"vision"}),
                             metrics_hook=store.llm_metric)
    app = build_case_graph(config, llm, template_id=template_id)
    state = app.invoke({
        "run_dir": str(case_dir),
        "input_path": case["name"],
        "case_mode": True,
        "case": {**{k: v for k, v in case.items() if k != "members"}, "members": results},
        "errors": [], "repair_attempts": 0,
    }, config={"recursion_limit": 60})

    prog.update({"phase": "done", "updated": time.time()})
    _write_progress(case_dir, prog)
    return state


def _member_result(final: Dict[str, Any], mdir: Path) -> Dict[str, Any]:
    text = final.get("aggregated_evidence")
    if text is None:
        text = (_load(mdir / RunStore.EVIDENCE_AGGREGATED) or {}).get("evidence", [])
    vis = final.get("visual_evidence")
    if vis is None:
        vis = (_load(mdir / RunStore.EVIDENCE_VISUAL) or {}).get("evidence", [])
    out = {"n_text": len(text or []), "n_visual": len(vis or []),
           "route": final.get("route", ""),
           "markdown_path": final.get("markdown_path", ""),
           "page_report": final.get("page_report") or {},
           "member_errors": [e.get("message", "") for e in (final.get("errors") or [])
                             + (final.get("errors_visual") or []) if isinstance(e, dict)][:20]}
    pages = [c.get("page") for c in (final.get("chunks") or []) if c.get("page")]
    if pages:
        out["page_range"] = [min(pages), max(pages)]
    return out


def _load(p: Path) -> Any:
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


# ----------------------------------------------------------------------
# 統合ノードとグラフ
# ----------------------------------------------------------------------

def _norm_content(text: str) -> str:
    return re.sub(r"[\s　、。，．,.]+", "", str(text or ""))


def _first_heading(md_path: str) -> str:
    if not md_path:
        return ""
    try:
        for line in Path(md_path).read_text(encoding="utf-8", errors="ignore").split("\n")[:200]:
            if line.startswith("#"):
                cand = line.lstrip("#").strip()
                if cand and not re.match(r"^(ページ|スライド|シート|page|slide|sheet|p\.)\s*\d+$",
                                         cand, re.I):
                    return cand
    except Exception:  # noqa: BLE001
        pass
    return ""


def make_merge_node(config: AppConfig):
    from .nodes import _push_error, _reference_to_evidence, _update_status

    wf = config.workflow

    def merge_case(state: Dict[str, Any]) -> Dict[str, Any]:
        case = state["case"]
        run_dir = Path(state["run_dir"])
        _update_status(state, "merge_case", peek=f"{len(case['members'])} 件の資料の証拠を統合しています…")

        text_all: List[dict] = []
        vis_all: List[dict] = []
        seen: Dict[str, dict] = {}
        documents: List[Dict[str, Any]] = []
        per_file: List[Dict[str, Any]] = []
        page_lines: List[str] = []
        dup = 0

        for idx, m in enumerate(case["members"], 1):
            rel = m["rel_in_case"]
            doc = {"file": rel, "file_type": Path(rel).suffix.lstrip(".").lower()}
            if m.get("state") != "done":
                doc["status"] = "読み取り失敗（この資料の内容は要約に入っていません）"
                documents.append(doc)
                per_file.append({"file": rel, "state": m.get("state"), "error": m.get("error", ""),
                                 "text": 0, "visual": 0, "duplicates": 0})
                _push_error(state, "merge_case",
                            f"資料『{rel}』の読み取りに失敗したため、要約に含まれていません",
                            m.get("error", ""))
                continue
            mdir = Path(m["run_dir"])
            prefix = f"f{idx:02d}_"
            title = _first_heading(m.get("markdown_path", ""))
            if title:
                doc["document_title"] = title
            if m.get("page_range"):
                doc["page_range"] = m["page_range"]
            if m.get("route"):
                doc["route"] = m["route"]
            documents.append(doc)

            text = (_load(mdir / "evidence_aggregated.json") or {}).get("evidence", []) or []
            vis = (_load(mdir / "evidence_visual.json") or {}).get("evidence", []) or []
            n_dup = 0
            for e in text:
                d = dict(e)
                d["evidence_id"] = prefix + str(d.get("evidence_id", ""))
                d["file"] = rel
                key = _norm_content(d.get("content", ""))
                if key and key in seen:
                    # 資料をまたいだ完全な重複：1 件にするが「どの資料にもあった」は残す
                    seen[key].setdefault("also_in", []).append(rel)
                    n_dup += 1
                    continue
                if key:
                    seen[key] = d
                text_all.append(d)
            for v in vis:
                d = dict(v)
                d["evidence_id"] = prefix + str(d.get("evidence_id", ""))
                d["file"] = rel
                vis_all.append(d)
            dup += n_dup
            per_file.append({"file": rel, "state": "done", "text": len(text) - n_dup,
                             "visual": len(vis), "duplicates": n_dup})

            # 各資料の精読結果（本文と図の食い違い）を資料名付きで渡す
            for r in ((m.get("page_report") or {}).get("pages") or [])[:40]:
                for c in r.get("conflicts") or []:
                    page_lines.append(
                        f"- 『{rel}』{r.get('page')}ページ：本文と図で {c.get('unit')} の値が"
                        f"食い違っています（本文 {c.get('text_values')} / 図 {c.get('visual_values')}）。"
                        f"どちらか一方だけを断定しないこと。")

        # ---- 台帳：案件フォルダの名前で 1 回だけ引く ----
        ref_ev: List[dict] = []
        ref_payload: Dict[str, Any] = {}
        try:
            index = load_index(config)
            best = None
            if index is not None:
                for folder in case.get("folders") or []:
                    r = index.match_folder(folder.rsplit("/", 1)[-1], folder,
                                           allow_partial=getattr(wf, "reference_allow_partial", True))
                    if r.ok and (best is None or r.confidence > best.confidence):
                        best = r
            if best is not None:
                ref_payload = best.to_dict()
                ref_payload["candidates"] = [c.to_dict() for c in best.candidates]
                if best.confirmed or getattr(wf, "reference_adopt_unconfirmed", True):
                    evs = _reference_to_evidence(
                        best, confidence_factor=getattr(wf, "reference_confidence_factor", 0.9))
                    ref_ev = [e.model_dump(mode="json") for e in evs]
            else:
                _push_error(state, "merge_case",
                            "案件フォルダの名前が参照台帳に見つからなかったため、台帳の情報は要約に入っていません", "")
        except Exception as e:  # noqa: BLE001 台帳の故障で案件を止めない
            _push_error(state, "merge_case", "参照台帳の照合に失敗しました（処理は継続）", repr(e))
        (run_dir / "reference_match.json").write_text(
            json.dumps(ref_payload, ensure_ascii=False, indent=2), encoding="utf-8")

        aggregated = ref_ev + text_all
        meta = {
            "case_name": case["name"],
            "case_folders": case.get("folders", []),
            "document_count": len(documents),
            "documents": documents,
            # _fill_case_name の最後の拠り所（案件名が空になった場合）
            "document_title": case["name"],
            "file_stem": case["name"],
            "route": "case",
        }
        page_block = ""
        if page_lines:
            page_block = ("各資料のページ突き合わせ（精読モード）で見つかった食い違い：\n"
                          + "\n".join(page_lines[:60]))

        pack_chars = len(json.dumps({"t": aggregated, "v": vis_all}, ensure_ascii=False))
        warn = int(getattr(config.case, "pack_warn_chars", 0) or 0)
        if warn and pack_chars > warn:
            _push_error(state, "merge_case",
                        f"案件全体の証拠が約 {pack_chars:,} 字あります（警告の目安 {warn:,} 字）。"
                        f"LLM の文脈長（llama.cpp の -c）が足りない場合は要約が途中で切れる"
                        f"ことがあります。証拠は削っていません", "")

        report = {"files": per_file, "documents": len(documents),
                  "text_evidence": len(text_all), "visual_evidence": len(vis_all),
                  "ledger_evidence": len(ref_ev), "cross_file_duplicates": dup,
                  "pack_chars": pack_chars}
        (run_dir / MERGE_REPORT_FILE).write_text(
            json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        (run_dir / "evidence_aggregated.json").write_text(json.dumps(
            {"before": len(text_all) + dup, "after": len(aggregated), "from_reference": len(ref_ev),
             "evidence": aggregated}, ensure_ascii=False, indent=2), encoding="utf-8")
        (run_dir / CASE_VISUAL_FILE).write_text(
            json.dumps({"evidence": vis_all}, ensure_ascii=False, indent=2), encoding="utf-8")

        _update_status(state, "merge_case", "done",
                       f"資料 {len(documents)} 件・本文証拠 {len(text_all)} 件・図の読み取り {len(vis_all)} 件"
                       + (f"・台帳 {len(ref_ev)} 件" if ref_ev else ""),
                       peek=f"{len(documents)} 件の資料をまとめました（約 {pack_chars:,} 字）")
        return {"aggregated_evidence": aggregated, "visual_evidence": vis_all,
                "reference_match": ref_payload, "reference_evidence": ref_ev,
                "case_meta": meta, "case_page_block": page_block, "route": "case",
                "errors": state.get("errors", [])}

    return merge_case


def build_case_graph(config: AppConfig, llm: Optional[LocalLLMClient] = None,
                     template_id: str = "case"):
    """merge_case → 既存の write_summary 以降。"""
    from .graph import route_after_validation
    from .nodes import WorkflowState, make_nodes

    nodes = make_nodes(config, llm, template_id=template_id)
    g = StateGraph(WorkflowState)
    g.add_node("merge_case", make_merge_node(config))
    for name in ("write_summary", "expand_summary", "validate_summary", "repair_summary",
                 "refine_effects", "render", "redact_external", "rag_export"):
        g.add_node(name, nodes[name])
    g.set_entry_point("merge_case")
    g.add_edge("merge_case", "write_summary")
    g.add_edge("write_summary", "expand_summary")
    g.add_edge("expand_summary", "validate_summary")
    g.add_conditional_edges("validate_summary", route_after_validation,
                            {"render": "refine_effects", "repair_summary": "repair_summary"})
    g.add_edge("repair_summary", "validate_summary")
    g.add_edge("refine_effects", "render")
    g.add_edge("render", "redact_external")
    g.add_edge("redact_external", "rag_export")
    g.add_edge("rag_export", END)
    return g.compile()


# ----------------------------------------------------------------------
# 後片付け
# ----------------------------------------------------------------------

def referenced_member_dirs(runs_root: Path) -> set:
    """どこかの案件が使っている資料の置き場（削除時に残す物）。"""
    used: set = set()
    root = Path(runs_root)
    if not root.exists():
        return used
    for d in root.iterdir():
        prog = read_progress(d) if d.is_dir() else {}
        for m in prog.get("members") or []:
            if m.get("run_dir"):
                used.add(str(Path(m["run_dir"]).resolve()))
    return used
