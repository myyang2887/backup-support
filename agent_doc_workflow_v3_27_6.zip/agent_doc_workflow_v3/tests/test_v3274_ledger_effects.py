"""v3.27.4：対応効果に「コスト削減」「期間短縮」を出すための下ごしらえ。

方針：**計算できるものはコードが保証し、できないものだけモデルに回す。**
常にモデルへ投げると、確実に出せた答えまで確率的になる。
意味付け（どの差が所要期間か）はモデルの仕事なので、コードは
生の表頭のまま差だけ並べる（v3.15 の「列の意味を表で決めない」を維持）。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.nodes import _looks_like_vague_date, _reference_date_evidence  # noqa: E402
from app.reference_index import ReferenceRow  # noqa: E402


def _row(cells):
    return ReferenceRow(source_file="台帳.xlsx", sheet_name="依頼一覧",
                        row_number=12, cells=list(cells))


def _contents(evs):
    return "\n".join(e.content for e in evs)


# ---- 計算できる日付 ----

def test_day_difference_is_computed_in_code():
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("希望納期", "2023/06/30"),
              ("完了日", "2023/06/02"), ("依頼部門", "製造技術部")]),
        conf=0.8, src="台帳.xlsx#依頼一覧:12", tag="")
    text = _contents(evs)
    assert "「依頼日」から「完了日」まで 53 日" in text
    assert "「完了日」から「希望納期」まで 28 日" in text
    assert "2023-04-10" in text            # 正規化した日付も並べる
    assert "製造技術部" not in text        # 日付でない列は触らない


def test_pair_is_ordered_earliest_first():
    """列の並び順ではなく時系列で「から/まで」を決める。"""
    evs = _reference_date_evidence(
        _row([("完了日", "2023/06/02"), ("依頼日", "2023/04/10")]),
        conf=0.8, src="s", tag="")
    assert "「依頼日」から「完了日」まで 53 日" in _contents(evs)


def test_months_are_included_for_readability():
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/01/10"), ("完了日", "2023/06/02")]),
        conf=0.8, src="s", tag="")
    assert "ヶ月" in _contents(evs)


def test_far_apart_dates_are_not_paired():
    """保管期限のような無関係な日付と組ませない。"""
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("完了日", "2023/06/02"),
              ("保管期限", "2043/04/10")]),
        conf=0.8, src="s", tag="")
    text = _contents(evs)
    assert "「依頼日」から「完了日」まで 53 日" in text
    assert "保管期限」まで" not in text


def test_single_date_produces_nothing():
    assert _reference_date_evidence(_row([("依頼日", "2023/04/10")]), 0.8, "s", "") == []


def test_no_dates_produces_nothing():
    assert _reference_date_evidence(_row([("依頼部門", "製造技術部")]), 0.8, "s", "") == []


# ---- 計算できない日付はモデルに回す ----

def test_vague_dates_are_flagged_not_dropped():
    """曖昧な記述を黙って落とすと、モデルは「日付の記載が無い」と読んで
    期間に触れなくなる。計算不可であることを明示的に伝える。"""
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("完了日", "2023/06/02"),
              ("希望納期", "6月末までに")]),
        conf=0.8, src="s", tag="")
    text = _contents(evs)
    assert "日付が曖昧で計算不可" in text and "希望納期" in text
    assert "概算" in text
    # 解析できた 2 つは通常どおり計算される
    assert "53 日" in text


def test_all_vague_still_reports():
    evs = _reference_date_evidence(
        _row([("依頼日", "来月中旬"), ("完了日", "6月末")]), 0.8, "s", "")
    text = _contents(evs)
    assert "日付が曖昧で計算不可" in text
    assert "日数計算" not in text          # 計算できないものを計算したふりをしない


def test_vague_detector_scope():
    for s in ("6月末", "来月中旬", "Q2中", "至急", "未定", "8月上旬頃"):
        assert _looks_like_vague_date(s), s
    for s in ("2023/06/02", "製造技術部", "", "A" * 60):
        assert not _looks_like_vague_date(s), s


def test_pair_count_is_capped():
    """日付列が多い台帳で証拠パックを食い潰さない。"""
    cells = [(f"日付{i}", f"2023/01/{i + 1:02d}") for i in range(12)]
    evs = _reference_date_evidence(_row(cells), 0.8, "s", "")
    diffs = [e for e in evs if "日数計算" in e.content]
    assert len(diffs) <= 10


def test_unconfirmed_tag_is_carried():
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("完了日", "2023/06/02")]),
        0.8, "s", "【要確認】")
    assert all(e.content.startswith("【要確認】") for e in evs)


# ---- プロンプト側 ----

def test_prompt_states_the_two_effects_and_bans_recomputation():
    src = (Path(__file__).resolve().parents[1] / "app" / "nodes.py").read_text(encoding="utf-8")
    assert "コスト削減の額・率" in src
    assert "期間短縮" in src
    # 計算済みの値を モデルが引き直すと、保証していたはずの数字が崩れる
    assert "絶対に自分で計算し直さないこと" in src
    assert "作り出すことは固く禁じる" in src
