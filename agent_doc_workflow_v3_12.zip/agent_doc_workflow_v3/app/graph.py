"""
LangGraph 图定义。

拓扑（v1 是纯直线，v2 加入真正的条件边）：

parallel_branches: true（既定）— 文本分支と視覚分支は依存関係が無いため並行実行：

create_run_dir -> parse_document -> route_template（v3.11・LLM 不使用）-> prepare_html_text
    ├─[文本分支] chunk_text -> extract_text_evidence -> aggregate_evidence -> gap_fill ─┐
    └─[視覚分支] collect_visual_assets -> analyze_visual ───────────────────────────────┤
                                                                                        ↓
    write_summary（分支汇合）-> validate_summary
         ├─ ok ──> render -> redact_external(社外脱敏) -> rag_export -> END
         ├─ 失败且还有重试额度 ─> repair_summary ─> validate_summary（回路）
         └─ 失败且额度用尽 ────────────────> render（用尽力解析的结果渲染，
                                              quality_report.json 保留失败记录）
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from langgraph.graph import StateGraph, END

from .config import AppConfig
from .llm_client import LocalLLMClient
from .nodes import WorkflowState, make_nodes


def route_after_validation(state: WorkflowState) -> str:
    validation = state.get("validation", {})
    if validation.get("ok"):
        return "render"
    max_attempts = state.get("_max_repair_attempts", 2)
    if state.get("repair_attempts", 0) < max_attempts:
        return "repair_summary"
    return "render"  # 额度用尽：带着 quality_report 里的错误记录照常出稿，不让整个 run 白跑


def build_graph(config: AppConfig, llm: Optional[LocalLLMClient] = None,
                template_id: str = "case", checkpointer=None):
    nodes = make_nodes(config, llm, template_id=template_id)

    graph = StateGraph(WorkflowState)
    for name, fn in nodes.items():
        graph.add_node(name, fn)

    graph.set_entry_point("create_run_dir")
    graph.add_edge("create_run_dir", "parse_document")
    # v3.11：テンプレート自動判定は「解析済み・最初の LLM 呼出の前」に置く。
    # 本文冒頭を材料に使うので create_run_dir 直後には置けない。
    graph.add_edge("parse_document", "route_template")
    graph.add_edge("route_template", "prepare_html_text")

    if getattr(config.workflow, "parallel_branches", True):
        # 扇出：解析完成后，文本链与视觉链互不依赖，同时开工
        graph.add_edge("prepare_html_text", "chunk_text")
        graph.add_edge("prepare_html_text", "collect_visual_assets")
        graph.add_edge("chunk_text", "extract_text_evidence")
        graph.add_edge("extract_text_evidence", "aggregate_evidence")
        graph.add_edge("aggregate_evidence", "gap_fill")
        graph.add_edge("collect_visual_assets", "analyze_visual")
        # 扇入：必须用「列表源」写法 —— 分别 add_edge(A,C)+add_edge(B,C) 是
        # 「任一触发」，会让 write_summary 在另一分支还没跑完时就启动。
        # v3.9：精読モードはページ単位で本文証拠と視覚証拠を突き合わせるので、
        # 両分岐が揃った後・要約の前に置く（扇入の合流点）。
        graph.add_edge(["gap_fill", "analyze_visual"], "deep_read")
        graph.add_edge("deep_read", "write_summary")
    else:
        # 顺序模式（调试用：日志与耗时更容易归因）
        graph.add_edge("prepare_html_text", "chunk_text")
        graph.add_edge("chunk_text", "extract_text_evidence")
        graph.add_edge("extract_text_evidence", "aggregate_evidence")
        graph.add_edge("aggregate_evidence", "gap_fill")
        graph.add_edge("gap_fill", "collect_visual_assets")
        graph.add_edge("collect_visual_assets", "analyze_visual")
        graph.add_edge("analyze_visual", "deep_read")
        graph.add_edge("deep_read", "write_summary")

    # v3.9：加筆は「骨格が出来た後・検証の前」。検証は加筆後の文面に対して行う。
    graph.add_edge("write_summary", "expand_summary")
    graph.add_edge("expand_summary", "validate_summary")

    graph.add_conditional_edges(
        "validate_summary",
        route_after_validation,
        {"render": "render", "repair_summary": "repair_summary"},
    )
    graph.add_edge("repair_summary", "validate_summary")
    graph.add_edge("render", "redact_external")
    graph.add_edge("redact_external", "rag_export")
    graph.add_edge("rag_export", END)

    return graph.compile(checkpointer=checkpointer)


def _make_checkpointer(config: AppConfig):
    """LangGraph SqliteSaver（可选）：节点级断点。进程崩溃/重启后同一 run
    从最后完成的节点继续，与文件级缓存互补（文件缓存跳过昂贵阶段的重算，
    checkpointer 恢复图内精确位置与 state）。包缺失时静默降级。"""
    if not getattr(config.workflow, "checkpoint_enabled", False):
        return None
    try:
        import sqlite3
        from langgraph.checkpoint.sqlite import SqliteSaver
        db = config.paths.resolve(config.paths.out_dir) / "checkpoints.sqlite3"
        db.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(db), check_same_thread=False)
        return SqliteSaver(conn)
    except Exception:  # noqa: BLE001
        return None


def run_workflow(input_path: str, config: AppConfig, llm: Optional[LocalLLMClient] = None,
                 template_id: str = "case",
                 input_mode: Optional[str] = None,
                 deep_read: Optional[bool] = None) -> WorkflowState:
    """input_mode（v3.6）: "auto" | "text" | "vision"。UI からの都度指定を
    config に焼き込んでから走らせる（グローバル設定は書き換えない）。

    deep_read（v3.9）: 精読モード。同じく実行ごとに切り替えられる。
    """
    # v3.11：template_id="auto" は input_mode="auto" と同じ扱いにする。
    # 実際の選択は route_template ノードが行うので、ここでは暫定として
    # 受け皿テンプレートを渡しておく（判定に失敗してもこれで走れる）。
    if template_id == "auto":
        config = config.model_copy(deep=True)
        config.workflow.template_mode = "auto"
        template_id = getattr(config.workflow, "template_auto_fallback", "generic_doc")
    if input_mode and input_mode != getattr(config.workflow, "input_mode", "auto"):
        config = config.model_copy(deep=True)
        config.workflow.input_mode = input_mode
    if deep_read is not None and bool(deep_read) != bool(
            getattr(config.workflow, "deep_read", False)):
        config = config.model_copy(deep=True)
        config.workflow.deep_read = bool(deep_read)
    checkpointer = _make_checkpointer(config)
    app = build_graph(config, llm, template_id=template_id, checkpointer=checkpointer)
    initial: WorkflowState = {
        "input_path": input_path,
        "_max_repair_attempts": config.workflow.max_repair_attempts,  # type: ignore[typeddict-unknown-key]
    }
    invoke_cfg = {"recursion_limit": 60}
    if checkpointer is not None:
        from .nodes import file_hash
        thread_id = (f"{Path(input_path).stem}_{file_hash(input_path)}_{template_id}"
                     f"_{getattr(config.workflow, 'template_mode', 'manual')}")
        invoke_cfg["configurable"] = {"thread_id": thread_id}
    return app.invoke(initial, config=invoke_cfg)
