"""
v3.11 の変更点に対するテスト。

対象：
  1. Excel 視覚ルートの埋め込み画像取りこぼし修正（後退の合図を壊さないこと）
  2. office2pdf（Office → PDF・Rust 単一バイナリ）の探索と優先順
  3. テンプレート前段ルータ（LLM 不使用）

特に 1 は実装中に**自分で作り込んだ回帰**をこのテストが捕まえた箇所なので、
「なぜ空を返さなければならないか」を必ず検証する形で残しておく。
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


# ======================================================================
# 1. Excel 視覚ルート：埋め込み画像の追加が「後退の合図」を壊さないこと
# ======================================================================

class _WF:
    """_excel_page_images が読む設定だけを持つスタブ。"""
    excel_sheet_render_max_sheets = 20
    excel_sheet_render_landscape = True
    excel_sheet_render_timeout = 60.0
    pdf_render_scale = 2.0
    vision_route_max_render_pages = 40
    max_visual_assets = 30


def test_excel_page_images_appends_embedded_on_success(tmp_path, monkeypatch):
    """シート描画が成功したら埋め込み画像も足す（v3.11 で埋めた非対称）。"""
    import app.nodes as N
    import tools.excel_com as EC

    sheet_png = tmp_path / "sheet_p001.png"
    sheet_png.write_bytes(b"x")
    embed_png = tmp_path / "embed_1.png"
    embed_png.write_bytes(b"y")

    monkeypatch.setattr(EC, "excel_sheet_pdfs",
                        lambda *a, **k: {"ok": True, "sheets": [{"pdf": "s.pdf"}],
                                         "exported": 1, "skipped": 0})
    monkeypatch.setattr(N, "_render_sheet_pdfs", lambda *a, **k: [str(sheet_png)])
    monkeypatch.setattr(N, "extract_office_visuals",
                        lambda *a, **k: {"ok": True,
                                         "visual_asset_paths": [str(embed_png)],
                                         "embedded": 1, "skipped_vector": 3})

    state = {"run_dir": str(tmp_path), "input_path": str(tmp_path / "x.xlsx"),
             "errors_visual": []}
    pages, meta = N._excel_page_images(state, _WF())

    assert str(sheet_png) in pages
    assert str(embed_png) in pages, "シート描画に成功したら埋め込み画像も渡すべき"
    assert "埋込 1" in meta
    # EMF/WMF を何枚捨てたかは必ず表に出す（日本語資料の最大の欠落源）
    assert "ベクタ図スキップ 3" in meta


def test_excel_page_images_stays_empty_when_render_fails(tmp_path, monkeypatch):
    """シート描画が空なら**埋め込み画像を足さずに空を返す**。

    呼び出し側（collect_visuals）は `if not raw_paths:` だけで後退を決めている。
    ここで埋め込み画像を混ぜると「COM は失敗したのに戻り値は空でない」状態に
    なり、後退チェーンごと黙って飛ばされてシート描画を永久に失う。
    埋め込み画像は後退チェーンの終点で改めて拾われるので損はしない。
    """
    import app.nodes as N
    import tools.excel_com as EC

    monkeypatch.setattr(EC, "excel_sheet_pdfs",
                        lambda *a, **k: {"ok": False, "sheets": [], "exported": 0,
                                         "skipped": 0, "error": "Excel なし"})

    called = {"n": 0}

    def _should_not_run(*a, **k):
        called["n"] += 1
        return {"ok": True, "visual_asset_paths": ["/tmp/ghost.png"], "embedded": 1}

    monkeypatch.setattr(N, "extract_office_visuals", _should_not_run)

    state = {"run_dir": str(tmp_path), "input_path": str(tmp_path / "x.xlsx"),
             "errors_visual": []}
    pages, meta = N._excel_page_images(state, _WF())

    assert pages == [], "空でないと呼び出し側の後退が発火しない"
    assert called["n"] == 0, "描画失敗時に埋め込み抽出を走らせてはいけない"
    assert "シート描画 0 枚" in meta


# ======================================================================
# 2. office2pdf
# ======================================================================

def test_find_office2pdf_prefers_explicit_path(tmp_path, monkeypatch):
    from app.parsing import find_office2pdf

    exe = tmp_path / "office2pdf.exe"
    exe.write_bytes(b"#!/bin/sh\n")
    monkeypatch.delenv("OFFICE2PDF_PATH", raising=False)
    assert find_office2pdf(str(exe)) == str(exe.resolve())


def test_find_office2pdf_reads_env(tmp_path, monkeypatch):
    from app.parsing import find_office2pdf

    exe = tmp_path / "o2p"
    exe.write_bytes(b"#!/bin/sh\n")
    monkeypatch.setenv("OFFICE2PDF_PATH", str(exe))
    assert find_office2pdf("") == str(exe.resolve())


def test_find_office2pdf_missing_returns_empty(monkeypatch):
    """未導入なら空文字。例外にしない（後退できるようにするため）。"""
    import shutil

    from app.parsing import find_office2pdf

    monkeypatch.delenv("OFFICE2PDF_PATH", raising=False)
    monkeypatch.setattr(shutil, "which", lambda _n: None)
    monkeypatch.setattr("app.parsing.PROJECT_ROOT", Path("/nonexistent-root"))
    assert find_office2pdf("") == ""


def test_office_to_pdf_falls_through_to_office2pdf(tmp_path, monkeypatch):
    """COM が使えない時に office2pdf が第二手段として呼ばれる。"""
    import app.parsing as P

    src = tmp_path / "deck.pptx"
    src.write_bytes(b"PK\x03\x04")
    out = tmp_path / "as_pdf"
    made = out / "deck.pdf"

    monkeypatch.setattr(P, "find_office2pdf", lambda _p="": "/fake/office2pdf")

    def _fake_convert(input_path, out_dir, exe, font_path="", timeout=300):
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        made.write_bytes(b"%PDF-1.4\n")
        return {"ok": True, "pdf_path": str(made), "engine": "office2pdf"}

    monkeypatch.setattr(P, "_office2pdf_convert", _fake_convert)

    res = P.office_to_pdf(str(src), str(out))
    assert res["ok"] is True
    assert res["engine"] == "office2pdf", "COM 不在なら office2pdf が担当する"


def test_office_to_pdf_error_lists_all_three_engines(tmp_path, monkeypatch):
    """全滅時のメッセージに三手段すべての理由が載る。

    v3.10 までは LibreOffice しか書いておらず、Excel COM が動いている run でも
    「LibreOffice が無いため不可」と出て状態を誤認させていた。
    """
    import app.parsing as P
    import tools.visual_asset_tools as V

    src = tmp_path / "deck.pptx"
    src.write_bytes(b"PK\x03\x04")

    monkeypatch.setattr(P, "find_office2pdf", lambda _p="": "")
    monkeypatch.setattr(V, "find_soffice", lambda: None)

    res = P.office_to_pdf(str(src), str(tmp_path / "o"))
    assert res["ok"] is False
    err = res["error"]
    assert "COM" in err and "office2pdf" in err and "LibreOffice" in err


def test_office2pdf_can_be_disabled(tmp_path, monkeypatch):
    import app.parsing as P
    import tools.visual_asset_tools as V

    src = tmp_path / "deck.pptx"
    src.write_bytes(b"PK\x03\x04")

    def _boom(*a, **k):
        raise AssertionError("無効化したのに呼ばれた")

    monkeypatch.setattr(P, "_office2pdf_convert", _boom)
    monkeypatch.setattr(V, "find_soffice", lambda: None)

    res = P.office_to_pdf(str(src), str(tmp_path / "o"), use_office2pdf=False)
    assert res["ok"] is False


# ======================================================================
# 3. テンプレート前段ルータ
# ======================================================================

class _Spec:
    def __init__(self, tid, fh, ch):
        self.id, self.filename_hints, self.content_hints = tid, fh, ch


class _Reg:
    def __init__(self, specs):
        self._s = {s.id: s for s in specs}

    def list(self):
        return [{"id": i} for i in self._s]

    def get(self, i):
        return self._s[i]


@pytest.fixture()
def reg():
    return _Reg([
        _Spec("case", ["依頼", "案件", "対応事例", "事例"],
              ["依頼元", "依頼内容", "ご依頼", "対応内容", "納期"]),
        _Spec("tech_report", ["レポート", "報告書", "報告", "解析", "評価"],
              ["目的", "手法", "解析条件", "結果", "考察", "結論"]),
        _Spec("bulk_requests", ["一覧", "台帳", "リスト", "管理表"],
              ["依頼番号", "受付日", "依頼者", "ステータス"]),
        _Spec("generic_doc", [], []),
    ])


def test_router_picks_tech_report(reg):
    from app.template_route import decide_template

    v = decide_template("2026_流体解析_報告書.pptx", "目的\n手法\n結果\n考察", reg)
    assert v["template_id"] == "tech_report"
    assert v["confident"] is True


def test_router_picks_bulk_from_content(reg):
    from app.template_route import decide_template

    v = decide_template("解析依頼一覧.xlsx", "依頼番号 受付日 依頼者 ステータス", reg)
    assert v["template_id"] == "bulk_requests"


def test_router_falls_back_when_no_signal(reg):
    from app.template_route import decide_template

    v = decide_template("会議メモ.docx", "本日の議題は次の通り。", reg)
    assert v["template_id"] == "generic_doc"
    assert v["confident"] is False


def test_router_falls_back_on_tie(reg):
    """各テンプレに 1 語ずつしか当たらない同点は決め打ちしない。"""
    from app.template_route import decide_template

    v = decide_template("依頼_報告.docx", "", reg)
    assert v["template_id"] == "generic_doc"
    assert v["confident"] is False


def test_router_margin_is_ratio_not_absolute(reg):
    """僅差判定は比率。絶対差だと得点の大きい領域で 1 語が結論をひっくり返す。"""
    from app.template_route import MIN_MARGIN_RATIO, decide_template

    assert MIN_MARGIN_RATIO > 1.0
    # 解析(3)+報告(3)+目的(1)+手法(1)=8 対 依頼(3)+依頼元(1)+対応内容(1)=5
    v = decide_template("依頼対応_解析報告.pptx", "目的 手法 依頼元 対応内容", reg)
    assert v["template_id"] == "tech_report"


def test_router_normalizes_fullwidth(reg):
    """全角英数（ＲＥＰＯＲＴ）も NFKC で拾える。"""
    from app.template_route import decide_template

    v = decide_template("解析ＲＥＰＯＲＴ_評価.pptx", "目的 手法 結論", reg)
    assert v["template_id"] == "tech_report"


def test_router_never_returns_the_fallback_as_a_winner(reg):
    """受け皿は競争に参加しない（ヒントを持たないので必ず 0 点になる）。"""
    from app.template_route import decide_template

    v = decide_template("解析報告書.pptx", "目的 手法 結果 考察", reg)
    assert "generic_doc" not in v["scores"]


def test_router_survives_empty_head_text(reg):
    from app.template_route import decide_template

    v = decide_template("解析評価報告書.pptx", "", reg)
    assert v["template_id"] == "tech_report", "本文が無くてもファイル名だけで決まる"


# ---- 実レジストリとの結線 -------------------------------------------------

def test_real_registry_templates_declare_hints():
    """受け皿以外のテンプレートは自動判定用のヒントを持っていること。"""
    from app.template_registry import get_registry

    r = get_registry()
    for entry in r.list():
        spec = r.get(entry["id"])
        if spec.id == "generic_doc":
            assert not spec.filename_hints and not spec.content_hints
        else:
            assert spec.filename_hints or spec.content_hints, \
                f"{spec.id} にヒントが無いと自動判定の候補にならない"


def test_route_template_node_is_wired_before_first_llm_call():
    """グラフ上で route_template が parse_document の直後に居ること。

    ここが崩れると「全部走り終えてから不一致に気付く」v3.8 の状態に戻る。
    """
    import inspect

    import app.graph as G

    src = inspect.getsource(G.build_graph)
    assert '"parse_document", "route_template"' in src
    assert '"route_template", "prepare_html_text"' in src


def test_ui_template_default_is_not_auto():
    """既定は従来どおり先頭テンプレート。自動判定は opt-in にする。

    既定を auto にすると、暗黙に先頭テンプレートを使っていた利用者の
    出力書式が予告なく変わる（実際に起きた）。挙動の変更は新機能に
    同梱しない、という線をテストで固定しておく。
    """
    html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(
        encoding="utf-8")
    # 解析ルートの #mode-select は auto が正しい既定なので、
    # テンプレート下拉（#tpl-select）に限定して見る。
    tpl_lines = [ln for ln in html.splitlines() if "#tpl-select" in ln and "?.value" in ln]
    assert len(tpl_lines) == 2, f"想定外の参照数: {len(tpl_lines)}"
    for ln in tpl_lines:
        assert '|| "auto"' not in ln, f"既定を auto にしてはいけない: {ln.strip()}"
        assert '|| "case"' in ln
    # 自動判定の選択肢自体は残っている（消したわけではない）
    assert 'value="auto"' in html and "自動判定" in html
