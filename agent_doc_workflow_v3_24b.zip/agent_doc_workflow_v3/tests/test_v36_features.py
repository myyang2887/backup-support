"""v3.6 测试：计时修复 / 解析ルート判定 / フォルダ一括処理 / PDF・Word 出力 / 多 agent UI。"""
import json
import sys
import time
from pathlib import Path

import pytest
from PIL import Image, ImageDraw

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app import batch as B
from app.config import AppConfig, load_config
from app.export_doc import (DocSection, export_docx, export_pdf, parse_markdown,
                            section_from_run_dir)
from app.observability import RunStore
from app.route_decision import decide_route, probe_document

SAMPLE_MD = """# 依頼対応事例：冷却ファン最適化

**依頼元**: 生産技術部

---

## 依頼内容

- 冷却効率が不足している
- FloEFD で熱流体解析を実施したい

## 対応結果

| 項目 | 内容 |
|---|---|
| 使用ツール | FloEFD |
| 期間 | 2026年1月 |

圧力損失が **18%** 低減した。
"""


# ----------------------------------------------------------------------
# 1. 計時バグ（秒表が上下に飛ぶ）
# ----------------------------------------------------------------------

def test_progress_updates_keep_original_start_time(tmp_path):
    """ノード内 i/N 更新で開始時刻が書き換わらないこと。
    旧実装は history 末尾を丸ごと差し替えており、前端の秒表が毎回 0 に戻っていた。"""
    store = RunStore(tmp_path / "run")
    store.reset_status()
    store.event("extract_text_evidence", "running")
    first = json.loads(store.path(RunStore.STATUS).read_text(encoding="utf-8"))
    t0 = first["history"][-1]["time"]

    time.sleep(0.05)
    store.event("extract_text_evidence", "running", "1/12")
    time.sleep(0.05)
    store.event("extract_text_evidence", "running", "2/12")

    status = json.loads(store.path(RunStore.STATUS).read_text(encoding="utf-8"))
    hist = status["history"]
    assert len(hist) == 1, "i/N 更新は 1 件に畳まれる（history を溢れさせない）"
    assert hist[-1]["time"] == t0, "開始時刻は最初のまま"
    assert hist[-1]["updated"] > t0, "最新時刻は updated に別途記録される"
    assert hist[-1]["detail"] == "2/12"


def test_parallel_branches_tracked_as_a_set(tmp_path):
    """並行分岐では複数ノードが同時に running。単一 current_node では表現できない。"""
    store = RunStore(tmp_path / "run")
    store.reset_status()
    store.event("extract_text_evidence", "running")
    store.event("analyze_visual", "running")
    status = json.loads(store.path(RunStore.STATUS).read_text(encoding="utf-8"))
    assert set(status["running_nodes"]) == {"extract_text_evidence", "analyze_visual"}

    store.event("analyze_visual", "done")
    status = json.loads(store.path(RunStore.STATUS).read_text(encoding="utf-8"))
    assert status["running_nodes"] == ["extract_text_evidence"]
    assert status["current_node"] == "analyze_visual"   # 旧フィールドは互換のため残す


def test_events_jsonl_keeps_every_raw_event(tmp_path):
    """status は畳んでも、監査用の events.jsonl は畳まない。"""
    store = RunStore(tmp_path / "run")
    store.reset_status()
    for i in range(4):
        store.event("extract_text_evidence", "running", f"{i}/4")
    lines = store.path(RunStore.EVENTS).read_text(encoding="utf-8").strip().split("\n")
    assert len(lines) == 4


def test_peeks_recorded_per_node(tmp_path):
    """多 agent UI 用：ノードごとに最新のひとことを保持する。"""
    store = RunStore(tmp_path / "run")
    store.reset_status()
    store.event("extract_text_evidence", "running", peek="本文を読んでいます")
    store.event("analyze_visual", "running", peek="画像を見ています")
    status = json.loads(store.path(RunStore.STATUS).read_text(encoding="utf-8"))
    assert status["peeks"]["extract_text_evidence"] == "本文を読んでいます"
    assert status["peeks"]["analyze_visual"] == "画像を見ています"


# ----------------------------------------------------------------------
# 2. 解析ルート判定（Docling / 視覚モデル直読）
# ----------------------------------------------------------------------

def _make_pdf(path: Path, pages, text_per_page="", with_image=False):
    """reportlab で試験用 PDF を作る（本番依存と同じライブラリ）。"""
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    c = canvas.Canvas(str(path), pagesize=A4)
    for pno in range(pages):
        c.drawString(40, 820, f"page {pno + 1}")   # ページごとに差を付ける
        if text_per_page:
            for i in range(0, len(text_per_page), 90):
                c.drawString(40, 800 - (i / 90) * 14, text_per_page[i:i + 90])
        if with_image:
            img = path.parent / f"_tmp{pno}.png"
            im = Image.new("RGB", (300, 200), (240, 240, 245))
            d = ImageDraw.Draw(im)
            d.ellipse([20, 20, 280, 180], fill=(200, 60 + pno * 30, 60))
            d.text((30, 30), f"figure {pno}", fill=(0, 0, 0))
            im.save(img)
            c.drawImage(str(img), 60, 300, width=300, height=200)
            c.drawImage(str(img), 60, 80, width=300, height=200)
        c.showPage()
    c.save()


def test_manual_mode_skips_the_probe(tmp_path):
    wf = AppConfig().workflow
    wf.input_mode = "vision"
    route, reason, probe = decide_route(str(tmp_path / "nonexistent.pdf"), wf)
    assert route == "vision" and probe == {}, "手動指定ならプローブすら走らせない"
    wf.input_mode = "text"
    assert decide_route(str(tmp_path / "nonexistent.pdf"), wf)[0] == "text"


def test_text_heavy_pdf_routes_to_docling(tmp_path):
    pdf = tmp_path / "text.pdf"
    _make_pdf(pdf, pages=3, text_per_page="解析条件と結果の説明文がぎっしり詰まった本文。" * 22)
    wf = AppConfig().workflow
    route, reason, probe = decide_route(str(pdf), wf)
    assert probe["chars_per_page"] > wf.vision_route_text_chars_per_page
    assert route == "text", reason


def test_image_heavy_pdf_routes_to_vision(tmp_path):
    pdf = tmp_path / "figs.pdf"
    _make_pdf(pdf, pages=3, text_per_page="図1", with_image=True)
    wf = AppConfig().workflow
    route, reason, probe = decide_route(str(pdf), wf)
    assert route == "vision", f"{reason} / {probe}"


def test_long_document_stays_on_text_route(tmp_path):
    """ページ数が多い資料は、たとえ図版主体でも画像化が割高なので text に倒す。"""
    pdf = tmp_path / "long.pdf"
    _make_pdf(pdf, pages=6, text_per_page="短い", with_image=True)
    wf = AppConfig().workflow
    wf.vision_route_max_pages = 4
    route, reason, _ = decide_route(str(pdf), wf)
    assert route == "text" and "ページ" in reason


def test_probe_is_safe_on_junk_input(tmp_path):
    bad = tmp_path / "broken.pdf"
    bad.write_bytes(b"not really a pdf")
    info = probe_document(str(bad))
    assert info["kind"] in ("unknown", "pdf")     # 例外を投げないことが要件
    assert decide_route(str(bad), AppConfig().workflow)[0] in ("text", "vision")


def test_markdown_input_always_text_route(tmp_path):
    md = tmp_path / "note.md"
    md.write_text("# メモ\n本文", encoding="utf-8")
    assert decide_route(str(md), AppConfig().workflow)[0] == "text"


def test_vision_route_end_to_end(tmp_path):
    """視覚直読ルートの通し運転：Docling を一切呼ばずに要約まで到達すること。"""
    from app.graph import run_workflow

    pdf = tmp_path / "figs.pdf"
    _make_pdf(pdf, pages=3, text_per_page="図", with_image=True)

    cfg = load_config()
    cfg.llm.mock = True
    cfg.paths.out_dir = str(tmp_path / "out")
    final = run_workflow(str(pdf), cfg, template_id="case", input_mode="vision")

    run_dir = Path(final["run_dir"])
    route = json.loads((run_dir / "route.json").read_text(encoding="utf-8"))
    assert route["route"] == "vision"
    assert not (run_dir / "parsed" / "figs.json").exists(), "Docling の JSON は生成されない"

    pages = list((run_dir / "visual_pages").glob("*.png"))
    assert len(pages) == 3, "全ページが画像化される（低文字ページだけではない）"
    # 同一内容のページは SHA1 で重複排除されるため、枚数は「描画数以下」で判定する
    n_visual = len(json.loads((run_dir / "evidence_visual.json").read_text(encoding="utf-8"))
                   ["evidence"])
    assert 1 <= n_visual <= 3 and n_visual == json.loads(
        (run_dir / "visual_assets_manifest.json").read_text(encoding="utf-8"))["kept_count"]
    assert (run_dir / "case_summary.md").exists()

    status = json.loads((run_dir / "status.json").read_text(encoding="utf-8"))
    assert status["running_nodes"] == [], "終了後に running が残らない（秒表が回り続けない）"
    assert status["peeks"], "agent ごとのひとことが残る"


def test_vision_route_reruns_when_mode_changes(tmp_path):
    """同じファイルでもルートを変えたらキャッシュを使い回さないこと。"""
    from app.graph import run_workflow

    pdf = tmp_path / "doc.pdf"
    _make_pdf(pdf, pages=2, text_per_page="本文がそれなりに書かれている資料。" * 20)

    cfg = load_config()
    cfg.llm.mock = True
    cfg.paths.out_dir = str(tmp_path / "out")
    first = run_workflow(str(pdf), cfg, template_id="case", input_mode="text")
    assert json.loads((Path(first["run_dir"]) / "route.json").read_text(encoding="utf-8")
                      )["route"] == "text"
    second = run_workflow(str(pdf), cfg, template_id="case", input_mode="vision")
    assert Path(second["run_dir"]) == Path(first["run_dir"])   # 内容ハッシュは同じ
    assert json.loads((Path(second["run_dir"]) / "route.json").read_text(encoding="utf-8")
                      )["route"] == "vision"
    assert list((Path(second["run_dir"]) / "visual_pages").glob("*.png"))


# ----------------------------------------------------------------------
# 3. フォルダ一括処理
# ----------------------------------------------------------------------

def _make_folder(root: Path):
    (root / "sub").mkdir(parents=True, exist_ok=True)
    (root / "a.md").write_text("# A\n本文A", encoding="utf-8")
    (root / "b.txt").write_text("本文B", encoding="utf-8")
    (root / "sub" / "c.md").write_text("# C\n本文C", encoding="utf-8")
    (root / "note.xyz").write_text("対象外", encoding="utf-8")
    (root / "~$lock.docx").write_text("ロック", encoding="utf-8")
    return root


def test_scan_folder_recursive_and_filters(tmp_path):
    root = _make_folder(tmp_path / "docs")
    deep = B.scan_folder(root, recursive=True)
    assert deep["count"] == 3
    assert deep["skipped_unsupported"] >= 1
    assert not any(f["name"].startswith("~$") for f in deep["files"])

    flat = B.scan_folder(root, recursive=False)
    assert flat["count"] == 2, "recursive=false ならサブフォルダは辿らない"


def test_scan_folder_reports_bad_path(tmp_path):
    assert not B.scan_folder(tmp_path / "nope")["ok"]
    f = tmp_path / "file.md"
    f.write_text("x", encoding="utf-8")
    assert not B.scan_folder(f)["ok"], "ファイルを渡されたら拒否する"


def test_allowed_roots_guard(tmp_path):
    inside = tmp_path / "allowed" / "docs"
    inside.mkdir(parents=True)
    assert B.check_allowed(inside, [str(tmp_path / "allowed")]) is None
    assert B.check_allowed(tmp_path / "elsewhere", [str(tmp_path / "allowed")])
    assert B.check_allowed(tmp_path, []) is None, "空リスト = 制限なし"


def test_batch_roundtrip_and_progress(tmp_path):
    out = tmp_path / "out"
    items = [{"name": f"f{i}.md", "rel": f"f{i}.md", "path": f"/x/f{i}.md",
              "run_id": f"f{i}_hash", "state": "queued"} for i in range(3)]
    rec = B.create_batch(out, "/x", items, template_id="case", input_mode="vision")

    assert B.load_batch(out, rec["batch_id"])["items"][0]["run_id"] == "f0_hash"
    assert [r["batch_id"] for r in B.all_batches(out)] == [rec["batch_id"]]
    assert B.run_to_batch_map(out)["f1_hash"] == rec["batch_id"]

    summary = B.summarize(rec, {"f0_hash": "done", "f1_hash": "running"})
    assert (summary["total"], summary["done"], summary["complete"]) == (3, 1, False)

    B.set_item_state(out, rec["batch_id"], "f0_hash", "done")
    assert B.load_batch(out, rec["batch_id"])["items"][0]["state"] == "done"

    live = {"f0_hash": "done", "f1_hash": "done", "f2_hash": "failed"}
    done_summary = B.summarize(rec, live)
    assert done_summary["complete"] and done_summary["failed"] == 1

    assert B.delete_batch(out, rec["batch_id"])
    assert B.load_batch(out, rec["batch_id"]) is None


def test_batch_id_traversal_is_rejected(tmp_path):
    assert B.load_batch(tmp_path, "../../etc") is None


# ----------------------------------------------------------------------
# 4. PDF / Word エクスポート
# ----------------------------------------------------------------------

def test_markdown_parsed_into_blocks():
    kinds = [b.kind for b in parse_markdown(SAMPLE_MD)]
    assert kinds[0] == "heading"
    assert "rule" in kinds and "bullet" in kinds and "table" in kinds
    table = next(b for b in parse_markdown(SAMPLE_MD) if b.kind == "table")
    assert table.rows[0] == ["項目", "内容"]
    assert ["使用ツール", "FloEFD"] in table.rows      # 区切り行 |---| は落ちている


def test_export_single_pdf_and_docx(tmp_path):
    sec = [DocSection("冷却ファン最適化", SAMPLE_MD, "sample.pptx")]
    pdf = export_pdf(sec, tmp_path / "one.pdf", doc_title="冷却ファン最適化")
    docx = export_docx(sec, tmp_path / "one.docx", doc_title="冷却ファン最適化")
    assert pdf.read_bytes()[:4] == b"%PDF"
    assert pdf.stat().st_size > 2000 and docx.stat().st_size > 2000

    import zipfile
    with zipfile.ZipFile(docx) as zf:                 # docx は ZIP（OOXML）
        body = zf.read("word/document.xml").decode("utf-8")
    assert "冷却ファン最適化" in body and "FloEFD" in body


def test_export_multiple_sections_has_index(tmp_path):
    """複数件（フォルダ一括処理）は索引ページ付きで 1 冊にまとまる。"""
    secs = [DocSection(f"案件{i}", SAMPLE_MD, f"f{i}.pdf") for i in range(3)]
    one = export_pdf(secs[:1], tmp_path / "a.pdf")
    many = export_pdf(secs, tmp_path / "b.pdf")
    assert many.stat().st_size > one.stat().st_size


def test_section_from_run_dir(tmp_path):
    run_dir = tmp_path / "runs" / "case_abc"
    run_dir.mkdir(parents=True)
    (run_dir / "case_summary.md").write_text(SAMPLE_MD, encoding="utf-8")
    (run_dir / "case_summary.json").write_text(
        json.dumps({"case_name": "冷却ファン最適化"}, ensure_ascii=False), encoding="utf-8")
    (run_dir / "manifest.json").write_text(
        json.dumps({"input_path": "/inbox/sample.pptx"}), encoding="utf-8")

    sec = section_from_run_dir(run_dir)
    assert sec.title == "冷却ファン最適化" and sec.source_name == "sample.pptx"
    assert section_from_run_dir(run_dir, "external") is None, "未生成の社外版は None"


# ----------------------------------------------------------------------
# 5. Web 層の結線（新 API と UI 開関）
# ----------------------------------------------------------------------

@pytest.fixture()
def client(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient

    import app.webapp as W
    monkeypatch.setattr(W.config.paths, "out_dir", str(tmp_path / "out"))
    monkeypatch.setattr(W.config.llm, "mock", True)
    return TestClient(W.app)


def test_ui_exposes_new_feature_groups(client):
    features = client.get("/api/ui").json()["features"]
    for key in ("route_select", "batch_card", "doc_export"):
        assert key in features, f"{key} は前端の開関として配信される"


def test_batch_scan_endpoint(client, tmp_path):
    root = _make_folder(tmp_path / "docs")
    res = client.post("/api/batches/scan", json={"folder": str(root), "recursive": True})
    assert res.status_code == 200 and res.json()["count"] == 3
    assert client.post("/api/batches/scan",
                       json={"folder": str(tmp_path / "nope")}).status_code == 400


def test_batch_list_empty_then_404_on_unknown(client):
    assert client.get("/api/batches").json() == []
    assert client.get("/api/batches/does_not_exist").status_code == 404
    assert client.get("/api/batches/x/export.pdf").status_code == 404


def test_export_rejects_unknown_format(client, tmp_path, monkeypatch):
    import app.webapp as W
    run_dir = tmp_path / "out" / "runs" / "r1"
    run_dir.mkdir(parents=True)
    (run_dir / "case_summary.md").write_text(SAMPLE_MD, encoding="utf-8")
    (run_dir / "manifest.json").write_text(json.dumps({"input_path": "a.pdf"}), encoding="utf-8")
    W._runs["r1"] = {"run_id": "r1", "input_name": "a.pdf", "state": "done",
                     "run_dir": str(run_dir), "created": time.time()}
    try:
        assert client.get("/api/runs/r1/export.txt").status_code == 400
        ok = client.get("/api/runs/r1/export.pdf")
        assert ok.status_code == 200 and ok.content[:4] == b"%PDF"
        assert client.get("/api/runs/r1/export.docx").status_code == 200
        assert client.get("/api/runs/r1/export.pdf?tier=external").status_code == 404
    finally:
        W._runs.pop("r1", None)


def test_runs_scope_separates_batch_history(client):
    """一括処理の run は単発の実行履歴に混ざらない（履歴分離の要望）。"""
    import app.webapp as W
    W._runs["solo"] = {"run_id": "solo", "state": "done", "created": 1}
    W._runs["in_batch"] = {"run_id": "in_batch", "state": "done", "created": 2,
                           "batch_id": "batch_x"}
    try:
        single = {r["run_id"] for r in client.get("/api/runs").json()}
        every = {r["run_id"] for r in client.get("/api/runs?scope=all").json()}
        only = {r["run_id"] for r in client.get("/api/runs?scope=batch").json()}
        assert "solo" in single and "in_batch" not in single
        assert {"solo", "in_batch"} <= every
        assert only == {"in_batch"}
    finally:
        W._runs.pop("solo", None)
        W._runs.pop("in_batch", None)


# ----------------------------------------------------------------------
# 6. 前端（多 agent / 計時）の静的検査
# ----------------------------------------------------------------------

def test_frontend_declares_agent_squad_and_timer_fix():
    html = (PROJECT_ROOT / "static" / "index.html").read_text(encoding="utf-8")
    for token in ("AGENTS", "pixelBot", "buildSquad", "SPRITE"):
        assert token in html, f"{token} が前端に無い（多 agent 表示）"
    assert "buildRobot" not in html, "単体ロボットの旧実装は残さない"
    assert "serverNow" in html and "running_nodes" in html, "計時修復の要点が前端に無い"
    assert "Date.now() / 1000 - runEv.time" not in html, "クライアント時計での引き算は廃止"
    for token in ("batchStart", "selectBatch", "export.pdf", "export.docx", "mode-select"):
        assert token in html, f"{token} が前端に無い"


def test_sprite_rows_are_rectangular():
    """ドット絵の行長が揃っていないと SVG が崩れる。"""
    html = (PROJECT_ROOT / "static" / "index.html").read_text(encoding="utf-8")
    block = html.split("const SPRITE = [", 1)[1].split("];", 1)[0]
    rows = [r.strip().strip(",").strip('"') for r in block.strip().split("\n")]
    rows = [r for r in rows if r]
    assert len(rows) == 13 and len({len(r) for r in rows}) == 1
