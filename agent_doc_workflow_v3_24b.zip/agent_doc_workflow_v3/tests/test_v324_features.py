"""v3.24：Excel の日付を正規化する（台帳・本文の両経路）。

利用者報告：台帳から完了日を抽出すると、まったく無関係な数値になる。
さらに、アンケートの回答日時を案件の完了日と取り違える。

原因は二つ重なっていた：

  1. Excel の日付は画面に 2023/12/15 と出ていても中身は 1900-01-01 からの
     通算日数（45275）でしかない。openpyxl が datetime に直すのは書式が
     日付と判別できた場合だけで、書式が「標準」のままの列は生の数値で返る。
  2. 生の数値になった「完了日」の隣に、書式の整った「回答日時」がある。
     モデルは意味の分からない数字より、日付に見える方を選ぶ。

つまり日付を壊したうえで、より紛らわしい代替物を並べて置いていた。
"""
from __future__ import annotations

import datetime
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

openpyxl = pytest.importorskip("openpyxl")


# ======================================================================
# 書式判定
# ======================================================================

@pytest.mark.parametrize("fmt", [
    "yyyy/mm/dd", "yyyy-mm-dd", "m/d/yy", "yyyy年m月d日",
    "yyyy/mm/dd hh:mm",
    # 和暦とロケール指定子つき。日本企業の台帳でごく普通に使われる。
    "[$-ja-JP]ge.m.d", '[$-411]yyyy"年"m"月"d"日"', "[$-409]m/d/yy",
])
def test_date_formats_detected(fmt):
    from app.cell_format import is_date_format

    assert is_date_format(fmt) is True


@pytest.mark.parametrize("fmt", [
    "General", "@", "標準", "#,##0", "¥#,##0", "0.00%", "0.00E+00", None, "",
    "[$¥-411]#,##0",     # 通貨記号つきロケール指定子は日付ではない
])
def test_non_date_formats_rejected(fmt):
    """通貨やパーセントを日付と誤認すると、今度は数値を壊す。"""
    from app.cell_format import is_date_format

    assert is_date_format(fmt) is False


# ======================================================================
# シリアル値の変換
# ======================================================================

def test_serial_converts_to_correct_date():
    from app.cell_format import serial_to_datetime

    assert serial_to_datetime(45275).date() == datetime.date(2023, 12, 15)


@pytest.mark.parametrize("serial", [0, -5, 3_000_000, "abc", None])
def test_out_of_range_serial_returns_none(serial):
    from app.cell_format import serial_to_datetime

    assert serial_to_datetime(serial) is None


# ======================================================================
# 文字列化
# ======================================================================

def test_midnight_time_is_dropped():
    """00:00:00 のゼロ並びは情報ではなく雑音。

    他の列（アンケートの回答日時など）との見栄えの差にもなり、
    モデルがそちらへ乗り換える一因になっていた。
    """
    from app.cell_format import cell_to_text

    assert cell_to_text(datetime.datetime(2023, 12, 15)) == "2023-12-15"


def test_real_time_is_kept():
    from app.cell_format import cell_to_text

    assert cell_to_text(datetime.datetime(2024, 1, 20, 14, 30)) == "2024-01-20 14:30"


def test_serial_with_date_format_is_restored():
    from app.cell_format import cell_to_text

    assert cell_to_text(45275, "yyyy/mm/dd") == "2023-12-15"


def test_number_with_currency_format_is_left_alone():
    """同じ 45275 でも、書式が通貨なら金額。日付にしてはいけない。"""
    from app.cell_format import cell_to_text

    assert cell_to_text(45275, "¥#,##0") == "45275"


def test_plain_number_is_not_guessed():
    """書式が「標準」のままの数値は触らない。

    日付かもしれないが金額や個数かもしれない。推測して日付に変えると、
    今度は数値を壊す。壊さない方を選ぶ。
    """
    from app.cell_format import cell_to_text

    assert cell_to_text(45275, "General") == "45275"
    assert cell_to_text(45275, None) == "45275"


def test_float_integers_stay_integers():
    from app.cell_format import cell_to_text

    assert cell_to_text(12.0) == "12"


def test_none_becomes_empty():
    from app.cell_format import cell_to_text

    assert cell_to_text(None) == ""


# ======================================================================
# 両経路で同じ結果になること
# ======================================================================

@pytest.fixture()
def dated_ledger(tmp_path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["管理No", "件名", "完了日", "回答日時", "金額"])
    r = ws.max_row + 1
    ws.cell(r, 1, "2023-0450")
    ws.cell(r, 2, "アルミ外材硬さ試験")
    c = ws.cell(r, 3, 45275)
    c.number_format = "yyyy/mm/dd"
    c = ws.cell(r, 4, datetime.datetime(2024, 1, 20, 14, 30))
    c.number_format = "yyyy/mm/dd hh:mm"
    c = ws.cell(r, 5, 45275)
    c.number_format = "¥#,##0"
    p = tmp_path / "台帳.xlsx"
    wb.save(p)
    return p


def test_ledger_reader_normalizes_dates(dated_ledger):
    from app.reference_index import build_index, clear_cache

    clear_cache()
    values = build_index([str(dated_ledger)]).rows[0].values
    assert values["完了日"] == "2023-12-15"
    assert values["回答日時"] == "2024-01-20 14:30"
    assert values["金額"] == "45275"


def test_body_reader_normalizes_dates_the_same_way(dated_ledger):
    """経路によって同じ列が違う形で出てはいけない。"""
    from app.excel_extract import workbook_to_markdown

    md = workbook_to_markdown(str(dated_ledger)).get("markdown") or ""
    line = next(l for l in md.splitlines() if "2023-0450" in l)
    assert "2023-12-15" in line
    assert "2024-01-20 14:30" in line
    assert "00:00:00" not in line


def test_evidence_shows_readable_dates(dated_ledger):
    """要約の証拠に 45275 のような数値が完了日として載らないこと。"""
    from app.nodes import _reference_to_evidence
    from app.reference_index import build_index, clear_cache

    clear_cache()
    idx = build_index([str(dated_ledger)])
    blob = " ".join(e.content for e in _reference_to_evidence(
        idx.match("アルミ外材硬さ試験.pptx")))
    assert "「完了日」：2023-12-15" in blob
    assert "「完了日」：45275" not in blob
