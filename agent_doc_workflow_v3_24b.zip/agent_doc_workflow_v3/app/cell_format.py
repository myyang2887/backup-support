"""
Excel セル値の文字列化（v3.24）— 特に日付。

## なぜ要るのか

Excel の日付は、画面に `2023/12/15` と表示されていても、ファイルの中身は
**1900-01-01 からの通算日数**（シリアル値）でしかない。日付らしく見えるのは
セルの表示書式が変換しているだけ。

openpyxl は書式が日付と分かる場合だけ datetime に直してくれるが、
書式が「標準」のまま数値として入っている列（他システムからの取り込みや
コピー貼り付けでよく起きる）は **`45275` という生の数値のまま返る**。

それをそのまま要約の証拠に載せると、モデルは意味の分からない数字を
「完了日」として書き写すか、あるいは近くにある見た目のきれいな日付
（アンケートの回答日時など）に乗り換えてしまう。実際その両方が起きた。

## 方針

- **書式（number_format）を見て日付かどうかを判断する。** 数値の範囲から
  推測しない——`45275` は日数にも見えるが、単なる金額や個数かもしれない。
  推測で日付に変えると、今度は数値を壊す。
- 時刻が 00:00:00 のものは日付だけにする。「2023-12-15 00:00:00」の
  ゼロ並びは情報ではなく雑音で、他の列との見栄えの差にもなる。
- 判断が付かないものは**触らない**。壊さないことを優先する。
"""
from __future__ import annotations

import datetime as _dt
import re
from typing import Any, Optional

#: 表示書式が日付・時刻を表しているか。
#: yyyy / mm / dd / h / s、和暦の ge、日本語の年月日 などを拾う。
_DATE_FORMAT_RE = re.compile(r"(yy|mm?|dd|hh?|ss|ge?|年|月|日|時|分)", re.I)

#: 逆に、これらが主役の書式は日付ではない（通貨・パーセント・指数）。
_NON_DATE_FORMAT_RE = re.compile(r"[¥$€%]|0\.00E|##0\.0")

#: ロケール指定子 [$-ja-JP] や [$-409]。中に $ を含むので通貨と誤認されるが、
#: これは書式の言語指定であって通貨ではない。和暦（[$-ja-JP]ge.m.d）は
#: 日本企業の台帳でごく普通に使われるので、取り違えると日付が全滅する。
_LOCALE_TAG_RE = re.compile(r"\[\$-[0-9A-Za-z\-]+\]")

#: Excel のシリアル値として現実的な範囲。
#: 下限 1（1900-01-01）だと 1〜100 のような普通の数値まで拾ってしまうので、
#: 書式が日付だと分かっている場合にのみ使う補助的な下限を置く。
_SERIAL_MIN = 1
_SERIAL_MAX = 2958465          # 9999-12-31

#: Excel の 1900 年うるう年バグに合わせた基準日
_EXCEL_EPOCH = _dt.datetime(1899, 12, 30)


def is_date_format(number_format: Optional[str]) -> bool:
    """セルの表示書式が日付・時刻を表しているか。"""
    if not number_format:
        return False
    fmt = str(number_format)
    if fmt in ("General", "@", "標準"):
        return False
    # ロケール指定子を先に外す。[$-ja-JP] の $ を通貨記号と読むと、
    # 和暦書式が丸ごと日付ではないと判定されてしまう。
    fmt = _LOCALE_TAG_RE.sub("", fmt)
    if _NON_DATE_FORMAT_RE.search(fmt):
        return False
    return bool(_DATE_FORMAT_RE.search(fmt))


def serial_to_datetime(serial: float) -> Optional[_dt.datetime]:
    """Excel のシリアル値を datetime に直す。範囲外なら None。"""
    try:
        n = float(serial)
    except (TypeError, ValueError):
        return None
    if not (_SERIAL_MIN <= n <= _SERIAL_MAX):
        return None
    try:
        return _EXCEL_EPOCH + _dt.timedelta(days=n)
    except (OverflowError, ValueError):
        return None


def format_datetime(value: _dt.datetime | _dt.date | _dt.time) -> str:
    """日付を人にもモデルにも読める形にする。

    時刻が 00:00:00 なら日付だけ。ゼロ並びは情報量ゼロなうえ、
    他の列（アンケートの回答日時など）との見栄えの差を作ってしまう。
    """
    if isinstance(value, _dt.datetime):
        if value.hour == 0 and value.minute == 0 and value.second == 0:
            return value.strftime("%Y-%m-%d")
        return value.strftime("%Y-%m-%d %H:%M")
    if isinstance(value, _dt.date):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, _dt.time):
        return value.strftime("%H:%M")
    return str(value)


def cell_to_text(value: Any, number_format: Optional[str] = None) -> str:
    """セルの値を文字列にする。日付は正規化する。

    `number_format` を渡せる場合は必ず渡すこと。これが無いと、
    書式だけが日付でデータが数値のセル（シリアル値）を救えない。
    """
    if value is None:
        return ""

    # 1) 既に日付型：書式を見るまでもない
    if isinstance(value, (_dt.datetime, _dt.date, _dt.time)):
        return format_datetime(value)

    # 2) 数値だが書式が日付：シリアル値なので直す
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if is_date_format(number_format):
            dt = serial_to_datetime(value)
            if dt is not None:
                return format_datetime(dt)
        # 日付でない数値。1.0 のような整数値の float は整数として出す
        if isinstance(value, float) and value == int(value):
            return str(int(value))
        return str(value)

    # 3) それ以外は素通し（改行と表の区切り文字だけ整える）
    return str(value).replace("\n", " ").replace("|", "／").strip()
