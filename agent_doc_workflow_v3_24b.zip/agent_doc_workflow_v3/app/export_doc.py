"""
書面エクスポート（v3.6 新增）：要約 Markdown → **体裁の整った PDF / Word**。

これまでの出口は Web プレビューと生 Markdown だけで、そのまま上長へ回したり
客先へ出せる形ではなかった。ここでは同じ Markdown を単一の中間表現
（`parse_markdown`）に落としてから、PDF と Word の二つのレンダラに流す。
書式の定義は 1 か所（_THEME）なので、両フォーマットの見た目がずれない。

ライブラリ選定（部内の許可条件：MIT / Apache / BSD のみ）
- PDF  : reportlab（BSD-3-Clause）。日本語は ①システムの日本語 TrueType を
         埋め込む → ②無ければ Adobe 標準 CID フォント HeiseiKakuGo-W5 に
         フォールバック、の二段構え。LibreOffice も wkhtmltopdf も要らない。
- Word : python-docx（MIT）。

複数案件（フォルダ一括処理）は先頭に一覧ページを付け、案件ごとに改ページする。
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# ---- 体裁の定義（PDF/Word 共通の唯一の真源）----
_THEME = {
    "accent": (0x0F, 0x6B, 0x5C),      # UI と同じ深緑
    "ink": (0x1E, 0x24, 0x30),
    "muted": (0x6B, 0x72, 0x80),
    "rule": (0xE4, 0xE1, 0xD8),
    "title_size": 19,
    "h1_size": 14,
    "h2_size": 12,
    "body_size": 10.5,
    "small_size": 8.5,
}

# Windows / Linux でよく見つかる日本語 TrueType（順に試す）
_JP_FONT_CANDIDATES = [
    (r"C:\Windows\Fonts\YuGothM.ttc", 0),
    (r"C:\Windows\Fonts\YuGothR.ttc", 0),
    (r"C:\Windows\Fonts\meiryo.ttc", 0),
    (r"C:\Windows\Fonts\msgothic.ttc", 0),
    ("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", 0),
    ("/usr/share/fonts/truetype/fonts-japanese-gothic.ttf", None),
    ("/usr/share/fonts/opentype/ipafont-gothic/ipagp.ttf", None),
]


# ----------------------------------------------------------------------
# 中間表現：Markdown を素朴なブロック列に
# ----------------------------------------------------------------------

@dataclass
class Block:
    kind: str                      # heading | bullet | para | rule | table
    text: str = ""
    level: int = 1
    rows: List[List[str]] = field(default_factory=list)


def parse_markdown(md: str) -> List[Block]:
    """要約テンプレートが吐く範囲（見出し / 箇条書き / 表 / 罫線 / 段落）だけを扱う。"""
    blocks: List[Block] = []
    lines = md.replace("\r\n", "\n").split("\n")
    i = 0
    while i < len(lines):
        line = lines[i].rstrip()
        if not line.strip():
            i += 1
            continue
        if re.match(r"^-{3,}\s*$", line):
            blocks.append(Block("rule"))
            i += 1
            continue
        m = re.match(r"^(#{1,4})\s+(.*)$", line)
        if m:
            blocks.append(Block("heading", m.group(2).strip(), level=len(m.group(1))))
            i += 1
            continue
        if line.lstrip().startswith("|") and line.rstrip().endswith("|"):
            rows: List[List[str]] = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.match(r"^:?-{2,}:?$", c or "-") for c in cells):
                    rows.append(cells)
                i += 1
            if rows:
                blocks.append(Block("table", rows=rows))
            continue
        m = re.match(r"^\s*[-*]\s+(.*)$", line)
        if m:
            blocks.append(Block("bullet", m.group(1).strip()))
            i += 1
            continue
        blocks.append(Block("para", line.strip()))
        i += 1
    return blocks


_INLINE_BOLD = re.compile(r"\*\*(.+?)\*\*")


def _strip_inline(text: str) -> str:
    return _INLINE_BOLD.sub(r"\1", text).replace("`", "")


# ----------------------------------------------------------------------
# 1 件 = 1 ドキュメント分の入力
# ----------------------------------------------------------------------

@dataclass
class DocSection:
    title: str                 # 案件名（見出し）
    markdown: str              # 要約 Markdown
    source_name: str = ""      # 元ファイル名
    meta: Dict[str, Any] = field(default_factory=dict)


def section_from_run_dir(run_dir: str | Path, tier: str = "internal") -> Optional[DocSection]:
    """run ディレクトリ（ディスクが真源）から 1 セクション分を組み立てる。"""
    import json

    d = Path(run_dir)
    md_name = "case_summary_external.md" if tier == "external" else "case_summary.md"
    md_path = d / md_name
    if not md_path.exists():
        return None
    title = d.name
    source = ""
    js = d / ("case_summary_external.json" if tier == "external" else "case_summary.json")
    if js.exists():
        try:
            data = json.loads(js.read_text(encoding="utf-8"))
            title = (data.get("case_name") or data.get("report_title")
                     or data.get("sheet_title") or title)
        except Exception:  # noqa: BLE001
            pass
    mf = d / "manifest.json"
    if mf.exists():
        try:
            source = Path(json.loads(mf.read_text(encoding="utf-8"))
                          .get("input_path", "")).name
        except Exception:  # noqa: BLE001
            pass
    return DocSection(title=str(title), markdown=md_path.read_text(encoding="utf-8"),
                      source_name=source)


# ----------------------------------------------------------------------
# PDF（reportlab）
# ----------------------------------------------------------------------

def _register_jp_font() -> Tuple[str, str]:
    """(通常, 太字) のフォント名を返す。日本語 TTF が無ければ CID フォント。"""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    for path, subfont in _JP_FONT_CANDIDATES:
        p = Path(path)
        if not p.exists():
            continue
        try:
            if subfont is None:
                pdfmetrics.registerFont(TTFont("JPFont", str(p)))
            else:
                pdfmetrics.registerFont(TTFont("JPFont", str(p), subfontIndex=subfont))
            return "JPFont", "JPFont"      # 太字は疑似ボールドに任せる
        except Exception:  # noqa: BLE001 壊れたフォントは飛ばす
            continue
    # フォールバック：Adobe 標準の日本語 CID フォント（埋め込み不要・軽量）
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    pdfmetrics.registerFont(UnicodeCIDFont("HeiseiKakuGo-W5"))
    pdfmetrics.registerFont(UnicodeCIDFont("HeiseiMin-W3"))
    return "HeiseiKakuGo-W5", "HeiseiKakuGo-W5"


def _pdf_styles(font: str, bold: str):
    from reportlab.lib.colors import Color
    from reportlab.lib.styles import ParagraphStyle

    def col(rgb):
        return Color(rgb[0] / 255, rgb[1] / 255, rgb[2] / 255)

    t = _THEME
    return {
        "title": ParagraphStyle("t", fontName=bold, fontSize=t["title_size"],
                                leading=t["title_size"] * 1.35, textColor=col(t["ink"]),
                                spaceAfter=2),
        "subtitle": ParagraphStyle("st", fontName=font, fontSize=t["small_size"],
                                   leading=t["small_size"] * 1.5, textColor=col(t["muted"]),
                                   spaceAfter=10),
        "h1": ParagraphStyle("h1", fontName=bold, fontSize=t["h1_size"],
                             leading=t["h1_size"] * 1.4, textColor=col(t["accent"]),
                             spaceBefore=14, spaceAfter=5),
        "h2": ParagraphStyle("h2", fontName=bold, fontSize=t["h2_size"],
                             leading=t["h2_size"] * 1.4, textColor=col(t["ink"]),
                             spaceBefore=10, spaceAfter=4),
        "body": ParagraphStyle("b", fontName=font, fontSize=t["body_size"],
                               leading=t["body_size"] * 1.75, textColor=col(t["ink"]),
                               spaceAfter=4),
        "bullet": ParagraphStyle("bl", fontName=font, fontSize=t["body_size"],
                                 leading=t["body_size"] * 1.75, textColor=col(t["ink"]),
                                 leftIndent=14, bulletIndent=3, spaceAfter=2),
        "cell": ParagraphStyle("c", fontName=font, fontSize=t["small_size"],
                               leading=t["small_size"] * 1.5, textColor=col(t["ink"])),
        "index": ParagraphStyle("ix", fontName=font, fontSize=t["body_size"],
                                leading=t["body_size"] * 1.9, textColor=col(t["ink"]),
                                leftIndent=14, bulletIndent=3),
    }


def _blocks_to_flowables(blocks: List[Block], styles, font: str):
    from reportlab.lib.colors import Color
    from reportlab.lib.units import mm
    from reportlab.platypus import HRFlowable, Paragraph, Spacer, Table, TableStyle

    accent = Color(*[c / 255 for c in _THEME["accent"]])
    rule = Color(*[c / 255 for c in _THEME["rule"]])
    out: List[Any] = []
    for b in blocks:
        if b.kind == "rule":
            out.append(Spacer(1, 4))
            out.append(HRFlowable(width="100%", thickness=0.6, color=rule,
                                  spaceBefore=2, spaceAfter=8))
        elif b.kind == "heading":
            if b.level <= 2:
                out.append(Paragraph(_esc(b.text), styles["h1"]))
                out.append(HRFlowable(width="100%", thickness=1.1, color=accent,
                                      spaceBefore=1, spaceAfter=7))
            else:
                out.append(Paragraph(_esc(b.text), styles["h2"]))
        elif b.kind == "bullet":
            out.append(Paragraph(_inline_to_rl(b.text), styles["bullet"], bulletText="・"))
        elif b.kind == "table" and b.rows:
            data = [[Paragraph(_inline_to_rl(c), styles["cell"]) for c in row] for row in b.rows]
            tbl = Table(data, hAlign="LEFT", colWidths=None, repeatRows=1)
            tbl.setStyle(TableStyle([
                ("GRID", (0, 0), (-1, -1), 0.4, rule),
                ("BACKGROUND", (0, 0), (-1, 0), Color(0.89, 0.94, 0.93)),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]))
            out.append(Spacer(1, 3 * mm))
            out.append(tbl)
            out.append(Spacer(1, 3 * mm))
        else:
            out.append(Paragraph(_inline_to_rl(b.text), styles["body"]))
    return out


def _esc(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _inline_to_rl(s: str) -> str:
    """**強調** を reportlab のミニマークアップへ。エスケープしてから変換する。"""
    return _INLINE_BOLD.sub(r"<b>\1</b>", _esc(s)).replace("`", "")


def export_pdf(sections: List[DocSection], out_path: str | Path,
               doc_title: str = "要約レポート", subtitle: str = "") -> Path:
    """1 件でも複数件でも同じ入口。複数件なら索引ページ＋案件ごとに改ページ。"""
    from reportlab.lib.colors import Color
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.platypus import (HRFlowable, PageBreak, Paragraph,
                                    SimpleDocTemplate, Spacer)

    font, bold = _register_jp_font()
    styles = _pdf_styles(font, bold)
    accent = Color(*[c / 255 for c in _THEME["accent"]])
    muted = Color(*[c / 255 for c in _THEME["muted"]])

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(out), pagesize=A4,
        leftMargin=20 * mm, rightMargin=18 * mm,
        topMargin=18 * mm, bottomMargin=16 * mm,
        title=doc_title, author="agent_doc_workflow",
    )

    stamp = time.strftime("%Y-%m-%d %H:%M")
    story: List[Any] = [
        Paragraph(_esc(doc_title), styles["title"]),
        HRFlowable(width="100%", thickness=2.2, color=accent, spaceBefore=3, spaceAfter=5),
        Paragraph(_esc(subtitle or f"生成日時 {stamp}　／　{len(sections)} 件"),
                  styles["subtitle"]),
    ]

    if len(sections) > 1:                       # 索引ページ
        story.append(Paragraph("収録案件", styles["h1"]))
        story.append(HRFlowable(width="100%", thickness=1.1, color=accent,
                                spaceBefore=1, spaceAfter=7))
        for i, sec in enumerate(sections, 1):
            label = _esc(sec.title)
            if sec.source_name:
                label += f"　<font size='8' color='#6b7280'>（{_esc(sec.source_name)}）</font>"
            story.append(Paragraph(label, styles["index"], bulletText=f"{i}."))
        story.append(PageBreak())

    for i, sec in enumerate(sections):
        if i > 0:
            story.append(PageBreak())
        if len(sections) > 1:
            story.append(Paragraph(_esc(sec.title), styles["title"]))
            if sec.source_name:
                story.append(Paragraph(f"出典: {_esc(sec.source_name)}", styles["subtitle"]))
            story.append(HRFlowable(width="100%", thickness=2.2, color=accent,
                                    spaceBefore=1, spaceAfter=8))
        story.extend(_blocks_to_flowables(parse_markdown(sec.markdown), styles, font))

    def _decorate(canvas, doc_):
        """フッタ：ページ番号と生成元。全ページ共通。"""
        canvas.saveState()
        canvas.setFont(font, 8)
        canvas.setFillColor(muted)
        canvas.drawString(20 * mm, 10 * mm, doc_title)
        canvas.drawRightString(A4[0] - 18 * mm, 10 * mm, f"- {doc_.page} -")
        canvas.setStrokeColor(Color(0.89, 0.88, 0.85))
        canvas.setLineWidth(0.4)
        canvas.line(20 * mm, 13 * mm, A4[0] - 18 * mm, 13 * mm)
        canvas.restoreState()

    doc.build(story, onFirstPage=_decorate, onLaterPages=_decorate)
    return out


# ----------------------------------------------------------------------
# Word（python-docx）
# ----------------------------------------------------------------------

def export_docx(sections: List[DocSection], out_path: str | Path,
                doc_title: str = "要約レポート", subtitle: str = "") -> Path:
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Pt, RGBColor

    accent = RGBColor(*_THEME["accent"])
    muted = RGBColor(*_THEME["muted"])

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    doc = Document()

    # 既定スタイルを日本語向けに（游ゴシックは Windows 既定で存在する）
    normal = doc.styles["Normal"]
    normal.font.name = "Yu Gothic"
    normal.font.size = Pt(_THEME["body_size"])
    try:                                     # 日本語フォントは東アジア用の指定が別
        from docx.oxml.ns import qn
        normal.element.rPr.rFonts.set(qn("w:eastAsia"), "Yu Gothic")
    except Exception:  # noqa: BLE001
        pass

    def _title_block(text: str, sub: str = ""):
        p = doc.add_paragraph()
        run = p.add_run(text)
        run.bold = True
        run.font.size = Pt(_THEME["title_size"])
        run.font.color.rgb = RGBColor(*_THEME["ink"])
        if sub:
            sp = doc.add_paragraph()
            srun = sp.add_run(sub)
            srun.font.size = Pt(_THEME["small_size"])
            srun.font.color.rgb = muted

    stamp = time.strftime("%Y-%m-%d %H:%M")
    _title_block(doc_title, subtitle or f"生成日時 {stamp}　／　{len(sections)} 件")

    if len(sections) > 1:
        h = doc.add_paragraph()
        hr = h.add_run("収録案件")
        hr.bold = True
        hr.font.size = Pt(_THEME["h1_size"])
        hr.font.color.rgb = accent
        for i, sec in enumerate(sections, 1):
            label = f"{i}. {sec.title}"
            if sec.source_name:
                label += f"（{sec.source_name}）"
            doc.add_paragraph(label, style="List Number" if False else None)
        doc.add_page_break()

    for i, sec in enumerate(sections):
        if i > 0:
            doc.add_page_break()
        if len(sections) > 1:
            _title_block(sec.title, f"出典: {sec.source_name}" if sec.source_name else "")
        for b in parse_markdown(sec.markdown):
            if b.kind == "rule":
                p = doc.add_paragraph()
                p.paragraph_format.space_before = Pt(2)
                p.paragraph_format.space_after = Pt(2)
            elif b.kind == "heading":
                p = doc.add_paragraph()
                run = p.add_run(_strip_inline(b.text))
                run.bold = True
                run.font.size = Pt(_THEME["h1_size"] if b.level <= 2 else _THEME["h2_size"])
                run.font.color.rgb = accent if b.level <= 2 else RGBColor(*_THEME["ink"])
                p.paragraph_format.space_before = Pt(10)
                p.paragraph_format.space_after = Pt(3)
            elif b.kind == "bullet":
                p = doc.add_paragraph(style="List Bullet")
                _add_inline_runs(p, b.text)
            elif b.kind == "table" and b.rows:
                cols = max(len(r) for r in b.rows)
                table = doc.add_table(rows=0, cols=cols)
                table.style = "Table Grid"
                for ri, row in enumerate(b.rows):
                    cells = table.add_row().cells
                    for ci in range(cols):
                        text = row[ci] if ci < len(row) else ""
                        para = cells[ci].paragraphs[0]
                        run = para.add_run(_strip_inline(text))
                        run.font.size = Pt(_THEME["small_size"])
                        if ri == 0:
                            run.bold = True
            else:
                p = doc.add_paragraph()
                _add_inline_runs(p, b.text)
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT

    doc.save(str(out))
    return out


def _add_inline_runs(paragraph, text: str) -> None:
    """**強調** だけを太字ランに分解する（それ以外は素の文字）。"""
    pos = 0
    for m in _INLINE_BOLD.finditer(text):
        if m.start() > pos:
            paragraph.add_run(text[pos:m.start()].replace("`", ""))
        paragraph.add_run(m.group(1).replace("`", "")).bold = True
        pos = m.end()
    if pos < len(text):
        paragraph.add_run(text[pos:].replace("`", ""))
