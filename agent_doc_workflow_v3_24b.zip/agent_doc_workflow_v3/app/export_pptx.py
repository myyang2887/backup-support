"""
要約 → PPTX 自動生成（v3.9）。

## 設計方針：モデルには 1 行も PPTX を書かせない

弱いモデルに python-pptx のコードや OOXML を直接書かせると高確率で壊れる
（PowerPoint の XML は索引参照とスタイル分離が絡むので、生成させるには
向いていない）。ここでは既に契約検証を通った**要約 JSON / Markdown だけ**を
入力にし、スライドの組み立ては全てこのモジュールの確定的なコードが行う。

つまり LLM の担当は「何を書くか」まで。「どう並べるか」は一切任せない。

## 日本語レイアウトの実害への対処

- **文字溢れ**：PowerPoint は自動縮小が効かない場面が多いので、
  文字数に応じてフォントサイズを段階的に落とす（`_fit_size`）。
  それでも入らない分は箇条書きを次のスライドへ送る（切り捨てない）。
- **フォント**：日本語グリフを持つフォントを明示指定しないと、環境に
  よっては豆腐（□）になる。`_JP_FONTS` を順に試す。
- **1 枚あたりの行数**：詰め込むと読めないので上限を決め、超えたら
  「（続き）」スライドを足す。**内容を落とすことはしない**。

## テンプレート（.potx / .pptx）対応

会社の書式がある場合は `template_path` を渡せばそれを土台にする。
無ければ既定の白地レイアウトを組む。pptxgenjs 系と違い python-pptx は
既存ファイルを開いて使えるので、社内テンプレートをそのまま活かせる。
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from .export_doc import Block, DocSection, parse_markdown, _strip_inline

# UI / PDF / Word と同じ配色（別々に持つと必ずずれる）
_ACCENT = (0x0F, 0x6B, 0x5C)
_INK = (0x1E, 0x24, 0x30)
_MUTED = (0x6B, 0x72, 0x80)

#: 日本語グリフを持つフォント候補。先頭から順に使う。
#: 指定しないと環境によって豆腐になるので、必ず明示する。
_JP_FONTS = ["Yu Gothic", "Meiryo", "MS PGothic", "Noto Sans JP", "Hiragino Kaku Gothic ProN"]

#: 1 スライドに載せる箇条書きの上限。超えた分は「（続き）」へ送る。
_MAX_BULLETS_PER_SLIDE = 7
#: 1 項目の文字数上限。超えたら折り返し前提でフォントを落とす。
_LONG_BULLET_CHARS = 60


def pptx_available() -> bool:
    try:
        import pptx  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def _fit_size(texts: List[str], base: float) -> float:
    """内容量からフォントサイズを決める。

    PowerPoint の自動縮小は当てにならないので、こちらで先に決めてしまう。
    """
    if not texts:
        return base
    longest = max(len(t) for t in texts)
    total = sum(len(t) for t in texts)
    size = base
    if longest > _LONG_BULLET_CHARS or total > 260:
        size -= 2
    if longest > _LONG_BULLET_CHARS * 1.6 or total > 420:
        size -= 2
    return max(11.0, size)


def _apply_font(run, size: float, bold: bool = False,
                color: tuple = _INK, font: Optional[str] = None) -> None:
    from pptx.dml.color import RGBColor
    from pptx.util import Pt

    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = RGBColor(*color)
    run.font.name = font or _JP_FONTS[0]
    # 東アジア用フォントは別枠で指定しないと効かない（ここが抜けると豆腐になる）
    try:
        from pptx.oxml.ns import qn
        run.font._rPr.set(qn("a:eastAsianFont"), run.font.name)
        ea = run.font._rPr.find(qn("a:ea"))
        if ea is None:
            ea = run.font._rPr.makeelement(qn("a:ea"), {})
            run.font._rPr.append(ea)
        ea.set("typeface", run.font.name)
    except Exception:  # noqa: BLE001 python-pptx の内部構造に依存するので保険
        pass


def _blank_layout(prs):
    """余計なプレースホルダの無いレイアウトを選ぶ。

    テンプレートによって並びが違うので、名前で探して駄目なら末尾を使う。
    """
    for layout in prs.slide_layouts:
        if (layout.name or "").lower() in ("blank", "白紙"):
            return layout
    return prs.slide_layouts[-1]


def _add_title_slide(prs, title: str, subtitle: str, font: str) -> None:
    from pptx.util import Emu

    slide = prs.slides.add_slide(_blank_layout(prs))
    w, h = prs.slide_width, prs.slide_height
    box = slide.shapes.add_textbox(Emu(int(w * 0.08)), Emu(int(h * 0.34)),
                                   Emu(int(w * 0.84)), Emu(int(h * 0.3)))
    tf = box.text_frame
    tf.word_wrap = True

    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = title
    _apply_font(r, 30 if len(title) < 30 else 24, bold=True, color=_ACCENT, font=font)

    if subtitle:
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = subtitle
        _apply_font(r2, 13, color=_MUTED, font=font)


def _add_content_slide(prs, heading: str, bullets: List[str],
                       paras: List[str], font: str, cont: bool = False) -> None:
    from pptx.util import Emu, Pt

    slide = prs.slides.add_slide(_blank_layout(prs))
    w, h = prs.slide_width, prs.slide_height

    head = slide.shapes.add_textbox(Emu(int(w * 0.06)), Emu(int(h * 0.07)),
                                    Emu(int(w * 0.88)), Emu(int(h * 0.12)))
    hp = head.text_frame.paragraphs[0]
    hr = hp.add_run()
    hr.text = heading + ("（続き）" if cont else "")
    _apply_font(hr, 20 if len(heading) < 28 else 16, bold=True, color=_ACCENT, font=font)

    body = slide.shapes.add_textbox(Emu(int(w * 0.06)), Emu(int(h * 0.22)),
                                    Emu(int(w * 0.88)), Emu(int(h * 0.68)))
    tf = body.text_frame
    tf.word_wrap = True
    size = _fit_size(bullets + paras, 16.0)

    first = True
    for text in paras:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        r = p.add_run()
        r.text = text
        _apply_font(r, size, font=font)
        p.space_after = Pt(6)
    for text in bullets:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        r = p.add_run()
        r.text = "• " + text
        _apply_font(r, size, font=font)
        p.space_after = Pt(5)


def _pick_font() -> str:
    """実在するフォントを選びたいが、pptx からは列挙できない。

    Windows なら Yu Gothic がほぼ確実に有るので既定に置き、
    それ以外の環境では Noto を優先する（Linux のコンテナ実行を想定）。
    """
    import os
    if os.name == "nt":
        return _JP_FONTS[0]
    for cand in ("Noto Sans JP", "Yu Gothic", "Meiryo"):
        if cand in _JP_FONTS:
            return cand
    return _JP_FONTS[0]


def _sections_to_slides(blocks: List[Block]) -> List[Dict[str, Any]]:
    """Block 列を「見出し + 中身」の塊へ畳む。

    Markdown の見出し階層をそのままスライド境界に使う。段落と箇条書きは
    見出しに属させ、どこにも属さない冒頭要素は「概要」に入れる。
    """
    groups: List[Dict[str, Any]] = []
    cur: Optional[Dict[str, Any]] = None
    for b in blocks:
        if b.kind == "heading":
            if b.level <= 1 and cur is None:
                continue                     # 文書タイトルはタイトルスライドで使う
            cur = {"heading": _strip_inline(b.text), "bullets": [], "paras": []}
            groups.append(cur)
        elif b.kind == "bullet":
            if cur is None:
                cur = {"heading": "概要", "bullets": [], "paras": []}
                groups.append(cur)
            cur["bullets"].append(_strip_inline(b.text))
        elif b.kind == "para":
            if cur is None:
                cur = {"heading": "概要", "bullets": [], "paras": []}
                groups.append(cur)
            cur["paras"].append(_strip_inline(b.text))
        elif b.kind == "table" and b.rows:
            if cur is None:
                cur = {"heading": "概要", "bullets": [], "paras": []}
                groups.append(cur)
            # 表はスライドでは読みづらいので行を箇条書きへ落とす
            # （情報は落とさない。見た目より欠落しないことを優先する）
            head = b.rows[0] if b.rows else []
            for row in b.rows[1:]:
                pairs = [f"{h}: {c}" for h, c in zip(head, row) if str(c).strip()]
                if pairs:
                    cur["bullets"].append(" / ".join(pairs))
    return [g for g in groups if g["bullets"] or g["paras"]]


def export_pptx(sections: List[DocSection], out_path: str | Path,
                deck_title: str = "要約レポート", subtitle: str = "",
                template_path: Optional[str] = None) -> Path:
    """要約セクション群から PPTX を組み立てる。

    `template_path` に社内テンプレート（.potx / .pptx）を渡すと、その書式を
    土台にする。python-pptx は既存ファイルを開いて使えるので、会社の
    マスタースライドをそのまま活かせる。
    """
    from pptx import Presentation
    from pptx.util import Inches

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    if template_path and Path(template_path).exists():
        prs = Presentation(str(template_path))
        # テンプレートに既存スライドがあると要約の前に付いてしまうので取り除く。
        # ここで `_sldIdLst` から消すだけでは**パッケージ内のパートが残り**、
        # 保存時に ppt/slides/slide1.xml が重複する（python-pptx の落とし穴）。
        # 関連を drop_rel してからでないと本当に消えない。
        _RID = ("{http://schemas.openxmlformats.org/officeDocument"
                "/2006/relationships}id")
        xml_slides = prs.slides._sldIdLst
        for sld in list(xml_slides):
            rid = sld.get(_RID)
            if rid:
                try:
                    prs.part.drop_rel(rid)
                except Exception:  # noqa: BLE001 既に無い場合もある
                    pass
            xml_slides.remove(sld)
    else:
        prs = Presentation()
        prs.slide_width = Inches(13.333)      # 16:9
        prs.slide_height = Inches(7.5)

    font = _pick_font()
    _add_title_slide(prs, deck_title, subtitle, font)

    for sec in sections:
        if len(sections) > 1:
            _add_title_slide(prs, sec.title, sec.source_name, font)
        groups = _sections_to_slides(parse_markdown(sec.markdown))
        for g in groups:
            bullets, paras = g["bullets"], g["paras"]
            if not bullets:
                _add_content_slide(prs, g["heading"], [], paras, font)
                continue
            # 詰め込みすぎると読めないので分割する。**内容は落とさない**。
            for i in range(0, len(bullets), _MAX_BULLETS_PER_SLIDE):
                chunk = bullets[i:i + _MAX_BULLETS_PER_SLIDE]
                _add_content_slide(prs, g["heading"], chunk,
                                   paras if i == 0 else [], font, cont=(i > 0))

    prs.save(str(out))
    return out


def export_pptx_from_run(run_dir: str | Path, out_path: str | Path,
                         tier: str = "internal",
                         template_path: Optional[str] = None) -> Optional[Path]:
    """run ディレクトリ 1 件から PPTX を作る（ディスクが真源）。"""
    from .export_doc import section_from_run_dir

    sec = section_from_run_dir(run_dir, tier=tier)
    if sec is None:
        return None
    return export_pptx([sec], out_path, deck_title=sec.title,
                       subtitle=sec.source_name, template_path=template_path)
