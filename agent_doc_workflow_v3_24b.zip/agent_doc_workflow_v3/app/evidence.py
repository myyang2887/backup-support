"""
证据归并（v1 缺失的 reduce 步骤）。

v1 的问题：40 个 chunk 的证据原样拼成一个巨型 JSON 塞给 Agent 3，
- 重复证据（chunk overlap 必然产生）浪费 context
- confidence 采集了但从不使用
- 无总量控制，容易爆本地模型 context window

v2：去重 -> 置信度过滤 -> 按类别分组排序 -> 每类别截断 -> 全局字符预算。
"""
from __future__ import annotations

import re
import unicodedata
from typing import Dict, List

from .contract import Evidence, VisualEvidence


def _normalize(text: str) -> str:
    """用于去重的规范化：NFKC 全半角统一、去空白、小写。"""
    t = unicodedata.normalize("NFKC", text)
    t = re.sub(r"\s+", "", t)
    return t.lower()


def dedupe_evidence(items: List[Evidence]) -> List[Evidence]:
    """按规范化内容去重，重复时保留 confidence 最高的一条。"""
    best: Dict[str, Evidence] = {}
    order: List[str] = []
    for ev in items:
        key = f"{ev.category}::{_normalize(ev.content)}"
        if not ev.content.strip():
            continue
        if key not in best:
            best[key] = ev
            order.append(key)
        elif ev.confidence > best[key].confidence:
            best[key] = ev
    return [best[k] for k in order]


def aggregate_evidence(
    items: List[Evidence],
    min_confidence: float = 0.3,
    max_per_category: int = 12,
    max_total_chars: int = 24000,
    *,
    ledger=None,
) -> List[Evidence]:
    """去重 + 过滤 + 每类别 top-N + 全局字符预算。

    v3.8：どの段で何件落ちたかを台帳に記録する（挙動自体は据え置き）。
    重複除去は無害だが、信頼度フィルタと類別上限は「本当は要る証拠」を
    落としうるので、数を見えるようにしておく。
    """
    if ledger is not None:
        ledger.observe("text_evidence", len(items))

    deduped = dedupe_evidence(items)
    if ledger is not None:
        ledger.drop("text_evidence", len(items) - len(deduped),
                    "重複（チャンク overlap 由来）", severity="low")

    filtered = [ev for ev in deduped if ev.confidence >= min_confidence]
    if ledger is not None:
        ledger.drop("text_evidence", len(deduped) - len(filtered),
                    f"confidence < {min_confidence}", severity="medium")

    by_cat: Dict[str, List[Evidence]] = {}
    for ev in filtered:
        by_cat.setdefault(ev.category, []).append(ev)

    selected: List[Evidence] = []
    cat_overflow = 0
    for cat, group in by_cat.items():
        group.sort(key=lambda e: e.confidence, reverse=True)
        cat_overflow += max(0, len(group) - max_per_category)
        selected.extend(group[:max_per_category])
    if ledger is not None:
        ledger.drop("text_evidence", cat_overflow,
                    f"類別ごとの上限 {max_per_category} 件超過", severity="medium")

    # 全局预算：优先保留高置信度
    selected.sort(key=lambda e: e.confidence, reverse=True)
    budgeted: List[Evidence] = []
    used = 0
    over_budget = 0
    for ev in selected:
        cost = len(ev.content) + 60  # 60 ≈ JSON 结构开销
        if used + cost > max_total_chars:
            over_budget += 1
            continue
        budgeted.append(ev)
        used += cost
    if ledger is not None:
        ledger.drop("text_evidence", over_budget,
                    f"証拠パック文字数上限 {max_total_chars} 超過", severity="high")

    # 恢复按类别的稳定顺序，方便人读中间产物
    budgeted.sort(key=lambda e: (e.category, -e.confidence))
    return budgeted


# ---------------------------------------------------------------------------
# 視覚証拠のパッキング
# ---------------------------------------------------------------------------
#
# v3.7 のこの関数は PPTX の視覚ルートで情報が大量に落ちる**主犯**だった。
# 4 行の中に 4 つの独立した欠陥が同居していた：
#
#   useful = [v for v in items if v.has_useful_visual_info]   # ①
#   useful.sort(key=..., reverse=True)                        # ②
#   "readable_text": v.readable_text[:10],                    # ③
#   if used + cost > max_total_chars: break                   # ④
#
# ① VISION_SYSTEM は「装飾なら has_useful_visual_info=false」と指示している。
#    ページ全体をレンダリングした画像（＝文字だけのスライド）に対して VLM は
#    「これは有用な"視覚"素材ではない」と至極まっとうに false を返す。すると
#    ページ全文の書き起こしが**一字残らず捨てられる**。
# ② 信頼度の降順に並べるため、パック結果が頁順ではなくなる。
# ③ ページモードの readable_text は「そのページの全文を行単位で書き起こした物」。
#    先頭 10 行だけ残す ＝ 1 ページの 6〜7 割を捨てる。しかも VLM に金を払って
#    読ませた**後**に捨てている。これが単独で最大の損失源。
# ④ 予算超過で break。②の並びのせいで「信頼度が低い頁」から落ちる。
#
# v3.8：ページ由来の資産は「捨ててよい装飾画像」ではなく「資料そのもの」として
# 扱う。フィルタしない・頁順を保つ・全文を残す・予算超過は打ち切りでなく記録。

_PAGE_KINDS = {"page_render", "sheet_render"}


def visual_to_pack(items: List[VisualEvidence],
                   max_total_chars: int = 8000,
                   *,
                   ledger=None,
                   readable_text_limit: int = 0) -> List[dict]:
    """視覚証拠をパックする。

    - `asset_kind` が page_render / sheet_render の物は has_useful_visual_info に
      よらず必ず残す（ページ丸ごとの書き起こしを捨てないため）
    - 並びは 頁番号 → evidence_id の昇順（人が読める順序）
    - readable_text_limit=0 で無制限（既定）。>0 のときだけ行数を絞る
    - 予算超過分は break せず記録して落とす（何を落としたか分かるように）
    """
    if ledger is not None:
        ledger.observe("visual_evidence", len(items))

    kept: List[VisualEvidence] = []
    for v in items:
        is_page = (getattr(v, "asset_kind", "embedded") or "embedded") in _PAGE_KINDS
        if v.has_useful_visual_info or is_page:
            kept.append(v)
    if ledger is not None:
        ledger.drop("visual_evidence", len(items) - len(kept),
                    "has_useful_visual_info=false の埋込画像", severity="low")

    # 頁順（頁が無い物は末尾へ）。信頼度で並べ替えない＝落とすなら末尾から。
    kept.sort(key=lambda v: (v.page if v.page is not None else 10**6, v.evidence_id))

    packed: List[dict] = []
    used = 0
    over_budget = 0
    truncated_lines = 0
    for v in kept:
        text = v.readable_text
        if readable_text_limit and len(text) > readable_text_limit:
            truncated_lines += len(text) - readable_text_limit
            text = text[:readable_text_limit]
        d = {
            "evidence_id": v.evidence_id,
            "visual_type": v.visual_type,
            "visual_summary": v.visual_summary,
            "key_facts": v.key_facts,
            "readable_text": text,
            "possible_relevance": v.possible_relevance,
            "confidence": v.confidence,
        }
        if v.page is not None:
            d["page"] = v.page
        if v.sheet_name:
            d["sheet_name"] = v.sheet_name
        cost = len(str(d))
        if max_total_chars and used + cost > max_total_chars:
            over_budget += 1
            continue          # break しない：後続に小さい物があれば入れる
        packed.append(d)
        used += cost

    if ledger is not None:
        ledger.drop("visual_evidence", over_budget,
                    f"証拠パック文字数上限 {max_total_chars} 超過", severity="high",
                    detail="上限を上げるか、ページ数を絞ってください")
        ledger.drop("visual_readable_text", truncated_lines,
                    f"readable_text 行数上限 {readable_text_limit}", severity="high")
    return packed
