"""
台帳の日付が正しく読めているかを、パイプラインを通さずに単体で確認する。

使い方（プロジェクト直下で実行）：

    python tools/check_ledger_dates.py "C:\\path\\to\\台帳.xlsx"

    # 台帳ライブラリを丸ごと見る場合
    python tools/check_ledger_dates.py data\\references

何が分かるか：
  - openpyxl が各セルをどう読んだか（型と生の値）
  - セルの表示書式（number_format）
  - この仕組みを通した後の最終的な文字列
  - 45275 のような値が残っている場合、その原因がどこにあるか

「直したはずなのに効かない」時は、まずこれを実行して結果を見てください。
コードが動いていないのか、そもそもデータ側の問題なのかが切り分けられます。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    import openpyxl
except ImportError:
    print("openpyxl が入っていません。pip install openpyxl")
    raise SystemExit(1)

from app.cell_format import cell_to_text, is_date_format, serial_to_datetime


#: 日付シリアル値としてありえそうな範囲（1995-05-28 〜 2035-01-01 あたり）
_SUSPECT_MIN, _SUSPECT_MAX = 34_800, 49_500


def check_workbook(path: Path, max_rows: int = 8) -> None:
    print("=" * 78)
    print(f"■ {path.name}")
    print("=" * 78)

    try:
        wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    except Exception as e:  # noqa: BLE001
        print(f"  開けません: {type(e).__name__}: {e}")
        return

    suspects: list[tuple[str, str, str]] = []

    for ws in wb.worksheets:
        if getattr(ws, "sheet_state", "visible") != "visible":
            continue
        rows = []
        for i, row in enumerate(ws.iter_rows()):
            rows.append(row)
            if i >= max_rows:
                break
        if len(rows) < 2:
            continue

        headers = ["" if c.value is None else str(c.value).strip() for c in rows[0]]
        print(f"\n  --- シート「{ws.title}」 ---")
        print(f"  {'列名':<16} {'openpyxl の型':<12} {'生の値':<22} "
              f"{'表示書式':<22} 最終出力")
        print("  " + "-" * 96)

        for r in rows[1:]:
            if not any(c.value is not None and str(c.value).strip() for c in r):
                continue
            for c_idx, cell in enumerate(r):
                v = cell.value
                if v is None or str(v).strip() == "":
                    continue
                head = headers[c_idx] if c_idx < len(headers) else f"({c_idx+1}列目)"
                fmt = getattr(cell, "number_format", None)
                out = cell_to_text(v, fmt)
                mark = ""
                # 日付のはずが数値のまま残っているものに印を付ける
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    if _SUSPECT_MIN <= float(v) <= _SUSPECT_MAX:
                        mark = "  ← ★ 日付かもしれません"
                        suspects.append((ws.title, head, str(fmt)))
                print(f"  {head[:16]:<16} {type(v).__name__:<12} {str(v)[:22]:<22} "
                      f"{str(fmt)[:22]:<22} {out}{mark}")
            break  # 1 行見れば十分

    try:
        wb.close()
    except Exception:  # noqa: BLE001
        pass

    if suspects:
        print("\n  " + "!" * 74)
        print("  ★ が付いた列は、日付シリアル値の可能性があります。")
        print("  Excel の中身が数値で、表示書式も日付ではないため、")
        print("  ライブラリを変えても日付としては復元できません。")
        print("  Excel でその列を選び、[セルの書式設定] → [日付] にすると直ります。")
        print("  " + "!" * 74)
        for sheet, head, fmt in suspects:
            print(f"    シート「{sheet}」列「{head}」 現在の書式: {fmt}")
    else:
        print("\n  日付シリアル値らしき数値は見つかりませんでした。")


def main() -> None:
    if len(sys.argv) < 2:
        print(__doc__)
        raise SystemExit(1)

    target = Path(sys.argv[1])
    if target.is_dir():
        files = sorted(p for p in target.rglob("*.xls*") if not p.name.startswith("~$"))
        if not files:
            print(f"{target} に Excel ファイルが見つかりません")
            raise SystemExit(1)
    elif target.is_file():
        files = [target]
    else:
        print(f"見つかりません: {target}")
        raise SystemExit(1)

    print(f"\n判定ロジックの動作確認:")
    print(f"  is_date_format('yyyy/mm/dd')     -> {is_date_format('yyyy/mm/dd')}")
    print(f"  is_date_format('General')        -> {is_date_format('General')}")
    print(f"  serial_to_datetime(45275)        -> {serial_to_datetime(45275)}")
    print(f"  cell_to_text(45275,'yyyy/mm/dd') -> {cell_to_text(45275, 'yyyy/mm/dd')!r}")
    print()

    for f in files:
        check_workbook(f)


if __name__ == "__main__":
    main()
