/** Translucent shell material for layered isosurfaces.
 *
 *  A flat MeshStandardMaterial with opacity turned down looks like cling
 *  film: uniformly see-through, so nested shells read as overlapping decals
 *  rather than volumes. Real post-processors get their look from a Fresnel
 *  term — surfaces are near-transparent when you face them head-on and
 *  bright where they curve away. That single cue is what makes a stack of
 *  shells read as a three-dimensional envelope.
 *
 *  Also lit from both sides so back faces of a closed shell still shade
 *  correctly, and depth-write disabled so the layers blend instead of
 *  occluding one another.
 */
import * as THREE from "three";

const VERT = `
  varying vec3 vNormalV;
  varying vec3 vViewDir;
  void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vNormalV = normalize(normalMatrix * normal);
    vViewDir = normalize(-mv.xyz);
    gl_Position = projectionMatrix * mv;
  }
`;

const FRAG = `
  uniform vec3  uColor;
  uniform vec3  uRim;
  uniform float uOpacity;
  uniform float uRimPower;
  varying vec3 vNormalV;
  varying vec3 vViewDir;
  void main() {
    vec3 n = normalize(vNormalV);
    vec3 v = normalize(vViewDir);
    // two-sided: flip the normal for back faces so shading stays sane
    if (!gl_FrontFacing) n = -n;
    float facing = clamp(abs(dot(n, v)), 0.0, 1.0);
    float fresnel = pow(1.0 - facing, uRimPower);

    // soft key light roughly from the camera, plus ambient fill
    float lambert = 0.55 + 0.45 * facing;
    vec3  color = mix(uColor * lambert, uRim, fresnel * 0.65);

    // edges opaque, flat faces sheer -> the shell reads as a volume
    float alpha = clamp(uOpacity + (1.0 - uOpacity) * fresnel, 0.0, 1.0);
    gl_FragColor = vec4(color, alpha);
  }
`;

export function shellMaterial(color: THREE.Color, opacity: number,
                              rimPower = 2.6): THREE.ShaderMaterial {
  const rim = color.clone().lerp(new THREE.Color(0xffffff), 0.55);
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: color },
      uRim: { value: rim },
      uOpacity: { value: opacity },
      uRimPower: { value: rimPower },
    },
    vertexShader: VERT,
    fragmentShader: FRAG,
    transparent: true,
    depthWrite: false,          // let the layers blend
    side: THREE.DoubleSide,
    blending: THREE.NormalBlending,
  });
}
