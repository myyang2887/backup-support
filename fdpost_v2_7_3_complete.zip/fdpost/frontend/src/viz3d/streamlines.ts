/** Streamline polylines -> one LineSegments with per-vertex speed colors. */
import * as THREE from "three";
import { jet, normalize } from "../colormap";
import type { StreamData } from "../types";

export function buildStreamlines(data: StreamData): THREE.LineSegments {
  let nSeg = 0;
  for (let i = 0; i < data.counts.length; i++) nSeg += Math.max(0, data.counts[i] - 1);
  const pos = new Float32Array(nSeg * 6);
  const col = new Float32Array(nSeg * 6);
  let base = 0, w = 0;
  const put = (idx: number, o: number) => {
    pos[o] = data.points[idx * 3];
    pos[o + 1] = data.points[idx * 3 + 1];
    pos[o + 2] = data.points[idx * 3 + 2];
    const [r, g, b] = jet(normalize(data.speeds[idx], data.speedRange));
    col[o] = r; col[o + 1] = g; col[o + 2] = b;
  };
  for (let li = 0; li < data.counts.length; li++) {
    const n = data.counts[li];
    for (let k = 0; k + 1 < n; k++) {
      put(base + k, w); put(base + k + 1, w + 3);
      w += 6;
    }
    base += n;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  return new THREE.LineSegments(
    geo, new THREE.LineBasicMaterial({ vertexColors: true }));
}
