/** Slice / probe / region gizmos with grabbable handles (industrial widgets).
 *  Handles are highlighted on hover; DragManager drives them. */
import * as THREE from "three";

const ACCENT = 0x4db3d4;
const ACCENT_HOVER = 0x8fd4ea;
const PROBE = 0xff5588;
const REGION = 0x44dd88;
const AXIS_COLOR = [0xff5f56, 0x5fd35f, 0x5b9dff];      // X red, Y green, Z blue
const AXIS_HOVER = [0xffa39e, 0xa8f0a8, 0xa9caff];

/** A three-arrow translate widget.
 *
 *  Dragging a bare point in 3D with a 2D mouse is ambiguous — the depth is
 *  a guess, which is why free-dragging endpoints never felt controllable.
 *  Axis handles remove the ambiguity: each arrow constrains motion to one
 *  world axis, so the drag maps onto exactly one number. Same widget is
 *  reused for probe endpoints, streamline seeds and region corners.
 */
export class AxisHandles {
  group = new THREE.Group();
  /** One Group per axis (shaft + cone) — used as a DragManager pick target. */
  arrows: THREE.Group[] = [];
  private mats: THREE.MeshBasicMaterial[] = [];

  constructor() {
    for (let a = 0; a < 3; a++) {
      const mat = new THREE.MeshBasicMaterial({
        color: AXIS_COLOR[a], depthTest: false, transparent: true, opacity: 0.95 });
      this.mats.push(mat);
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 1, 8), mat);
      const cone = new THREE.Mesh(new THREE.ConeGeometry(1, 1, 12), mat);
      const g = new THREE.Group();
      g.add(shaft, cone);
      g.renderOrder = 999;                       // always on top of the data
      this.arrows.push(g);
      this.group.add(g);
    }
  }

  setHover(axis: number, on: boolean): void {
    this.mats[axis].color.setHex(on ? AXIS_HOVER[axis] : AXIS_COLOR[axis]);
  }

  /** Place at `pos`; `len` is the arrow length in world units. */
  update(pos: THREE.Vector3, len: number): void {
    const r = len * 0.045, head = len * 0.28;
    for (let a = 0; a < 3; a++) {
      const dir = new THREE.Vector3(); dir.setComponent(a, 1);
      const q = new THREE.Quaternion().setFromUnitVectors(
        new THREE.Vector3(0, 1, 0), dir);
      const [shaft, cone] = this.arrows[a].children as THREE.Mesh[];
      shaft.quaternion.copy(q);
      shaft.scale.set(r, len - head, r);
      shaft.position.copy(pos).addScaledVector(dir, (len - head) / 2);
      cone.quaternion.copy(q);
      cone.scale.set(r * 2.6, head, r * 2.6);
      cone.position.copy(pos).addScaledVector(dir, len - head / 2);
    }
  }
}

export function eulerToNormal(tiltDeg: number, azimuthDeg: number): THREE.Vector3 {
  // Rz(azimuth) * Rx(tilt) applied to +Z — must match backend euler_to_point_normal
  const t = (tiltDeg * Math.PI) / 180, a = (azimuthDeg * Math.PI) / 180;
  const v = new THREE.Vector3(0, 0, 1);
  v.applyAxisAngle(new THREE.Vector3(1, 0, 0), t);
  v.applyAxisAngle(new THREE.Vector3(0, 0, 1), a);
  return v;
}

/** Inverse of eulerToNormal: n = (sin a sin t, -cos a sin t, cos t). */
export function normalToEuler(n: THREE.Vector3, prevAzimuth: number,
                              ): { tilt: number; azimuth: number } {
  const nn = n.clone().normalize();
  const tilt = (Math.acos(THREE.MathUtils.clamp(nn.z, -1, 1)) * 180) / Math.PI;
  if (tilt < 0.5 || tilt > 179.5) return { tilt, azimuth: prevAzimuth };
  const azimuth = (Math.atan2(nn.x, -nn.y) * 180) / Math.PI;
  return { tilt, azimuth };
}

/** Orient a PlaneGeometry(1,1) so its local +X lands on `u` and local +Y on
 *  `v`, then scale it by (w, h).
 *
 *  Do NOT use `setFromUnitVectors(+Z, normal)` for this. That gives the
 *  shortest-arc rotation, which fixes where +Z goes but says nothing about
 *  where +X and +Y land — for an X-normal plane it puts local X on world Z
 *  and local Y on world Y, i.e. width and height swapped, which reads as a
 *  90-degree rotation. Building the basis explicitly is the only way to tie
 *  the two in-plane extents to the axes they were measured on.
 *
 *  The third basis vector is u x v rather than the normal, so the matrix is
 *  always a proper rotation (an (X, Z) in-plane pair is left-handed, and a
 *  mirrored matrix does not convert to a quaternion). The plane is
 *  double-sided, so a flipped normal is invisible.
 */
export function orientPlane(mesh: THREE.Object3D, pos: THREE.Vector3,
                            u: THREE.Vector3, v: THREE.Vector3,
                            w: number, h: number): void {
  const uu = u.clone().normalize();
  const vv = v.clone().normalize();
  const m = new THREE.Matrix4().makeBasis(uu, vv, uu.clone().cross(vv));
  mesh.position.copy(pos);
  mesh.quaternion.setFromRotationMatrix(m);
  mesh.scale.set(w, h, 1);
}

/** In-plane basis for a free plane. Mirrors the backend's `_plane_basis`, so
 *  the u/v the gizmo shows are the u_m/v_m columns of an exported CSV. */
export function planeBasis(n: THREE.Vector3): [THREE.Vector3, THREE.Vector3] {
  const nn = n.clone().normalize();
  const ref = Math.abs(nn.z) < 0.9 ? new THREE.Vector3(0, 0, 1)
                                   : new THREE.Vector3(1, 0, 0);
  const u = new THREE.Vector3().crossVectors(ref, nn).normalize();
  const v = new THREE.Vector3().crossVectors(nn, u);
  return [u, v];
}

export class SliceGizmo {
  group = new THREE.Group();
  planeMesh: THREE.Mesh;
  headMesh: THREE.Mesh;
  origin = new THREE.Vector3();
  normal = new THREE.Vector3(0, 0, 1);
  private shaft: THREE.ArrowHelper;
  private planeMat: THREE.MeshBasicMaterial;
  private headMat: THREE.MeshBasicMaterial;

  constructor() {
    this.planeMat = new THREE.MeshBasicMaterial({
      color: ACCENT, transparent: true, opacity: 0.20, side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.planeMesh = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), this.planeMat);
    const edge = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.PlaneGeometry(1, 1)),
      new THREE.LineBasicMaterial({ color: ACCENT, transparent: true, opacity: 0.8 }));
    this.planeMesh.add(edge);
    this.shaft = new THREE.ArrowHelper(
      new THREE.Vector3(0, 0, 1), new THREE.Vector3(), 1, ACCENT, 0, 0);
    this.headMat = new THREE.MeshBasicMaterial({ color: ACCENT });
    this.headMesh = new THREE.Mesh(new THREE.ConeGeometry(1, 2.4, 16), this.headMat);
    this.group.add(this.planeMesh, this.shaft, this.headMesh);
  }

  setHover(part: "plane" | "head", on: boolean): void {
    if (part === "plane") this.planeMat.opacity = on ? 0.34 : 0.20;
    else this.headMat.color.setHex(on ? ACCENT_HOVER : ACCENT);
  }

  updateAxis(bounds: number[][], axis: "x" | "y" | "z", position: number): void {
    const [lo, hi] = bounds;
    const c = [(lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2];
    const ext = [hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]];
    const ia = { x: 0, y: 1, z: 2 }[axis];
    const inplane = { 0: [1, 2], 1: [0, 2], 2: [0, 1] }[ia] as [number, number];
    const n = new THREE.Vector3(); n.setComponent(ia, 1);
    const pos = new THREE.Vector3(c[0], c[1], c[2]); pos.setComponent(ia, position);
    // width follows inplane[0], height follows inplane[1] — state it, don't
    // hope the shortest-arc rotation happens to agree
    const u = new THREE.Vector3(); u.setComponent(inplane[0], 1);
    const v = new THREE.Vector3(); v.setComponent(inplane[1], 1);
    this.apply(pos, n, u, v, ext[inplane[0]] * 1.02, ext[inplane[1]] * 1.02,
               Math.max(...ext) * 0.28);
  }

  updateEuler(bounds: number[][], tilt: number, azimuth: number,
              distance: number): void {
    const [lo, hi] = bounds;
    const c = new THREE.Vector3(
      (lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2);
    const n = eulerToNormal(tilt, azimuth);
    const pos = c.clone().addScaledVector(n, distance);
    const L = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]) * 1.25;
    const [u, v] = planeBasis(n);
    this.apply(pos, n, u, v, L, L, L * 0.22);
  }

  private apply(pos: THREE.Vector3, n: THREE.Vector3,
                u: THREE.Vector3, v: THREE.Vector3,
                w: number, h: number, arrowLen: number): void {
    const nn = n.clone().normalize();
    this.origin.copy(pos);
    this.normal.copy(nn);
    orientPlane(this.planeMesh, pos, u, v, w, h);
    this.shaft.position.copy(pos);
    this.shaft.setDirection(nn);
    this.shaft.setLength(arrowLen, 1e-6, 1e-6);
    const r = arrowLen * 0.10;
    this.headMesh.scale.set(r, r, r);
    this.headMesh.position.copy(pos).addScaledVector(nn, arrowLen);
    this.headMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), nn);
  }
}

export class ProbeGizmo {
  group = new THREE.Group();
  s0: THREE.Mesh; s1: THREE.Mesh;
  /** Axis translate widgets, one per endpoint (shown in edit mode). */
  handles: [AxisHandles, AxisHandles] = [new AxisHandles(), new AxisHandles()];
  private line: THREE.Line;
  private m0: THREE.MeshBasicMaterial; private m1: THREE.MeshBasicMaterial;

  constructor() {
    this.line = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]),
      new THREE.LineBasicMaterial({ color: PROBE }),
    );
    this.m0 = new THREE.MeshBasicMaterial({ color: PROBE });
    this.m1 = new THREE.MeshBasicMaterial({ color: PROBE });
    this.s0 = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 14), this.m0);
    this.s1 = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 14), this.m1);
    this.group.add(this.line, this.s0, this.s1,
                   this.handles[0].group, this.handles[1].group);
  }

  setHover(which: 0 | 1, on: boolean): void {
    (which === 0 ? this.m0 : this.m1).color.setHex(on ? 0xffa0c0 : PROBE);
  }

  update(p0: number[], p1: number[], domainSize: number): void {
    const a = new THREE.Vector3(...p0), b = new THREE.Vector3(...p1);
    this.line.geometry.setFromPoints([a, b]);
    const r = domainSize * 0.014;
    this.s0.position.copy(a); this.s0.scale.setScalar(r);
    this.s1.position.copy(b); this.s1.scale.setScalar(r);
    const len = domainSize * 0.16;
    this.handles[0].update(a, len);
    this.handles[1].update(b, len);
  }

  showHandles(on: boolean): void {
    this.handles[0].group.visible = on;
    this.handles[1].group.visible = on;
  }
}

/** The 12 edges of a unit box, as [axis, sign_a, sign_b] where the two
 *  signs place the bar on the other two axes. */
const EDGE_SPEC: [number, number, number][] = [];
for (let axis = 0; axis < 3; axis++) {
  for (const sa of [-1, 1]) for (const sb of [-1, 1]) {
    EDGE_SPEC.push([axis, sa, sb]);
  }
}

export class RegionGizmo {
  group = new THREE.Group();
  /** Drag target: the 12 edge bars, NOT the solid interior. Grabbing only
   *  on the frame leaves the middle of the box free for camera orbit —
   *  dragging the box over the viewport used to lock rotation completely. */
  pickMesh: THREE.Group;
  private helper: THREE.Box3Helper;
  private box = new THREE.Box3();
  private pickMat: THREE.MeshBasicMaterial;
  private bars: THREE.Mesh[] = [];
  /** Corner translate widgets: [min corner, max corner]. Dragging one axis
   *  moves that face -> this is how the box is resized with the mouse. */
  handles: [AxisHandles, AxisHandles] = [new AxisHandles(), new AxisHandles()];

  constructor() {
    this.helper = new THREE.Box3Helper(this.box, new THREE.Color(REGION));
    this.pickMat = new THREE.MeshBasicMaterial({
      color: REGION, transparent: true, opacity: 0.35, depthWrite: false,
    });
    this.pickMesh = new THREE.Group();
    for (let i = 0; i < EDGE_SPEC.length; i++) {
      const bar = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), this.pickMat);
      this.bars.push(bar);
      this.pickMesh.add(bar);
    }
    this.group.add(this.helper, this.pickMesh,
                   this.handles[0].group, this.handles[1].group);
  }

  setHover(on: boolean): void { this.pickMat.opacity = on ? 0.85 : 0.35; }

  update(min: number[], max: number[]): void {
    this.box.min.set(min[0], min[1], min[2]);
    this.box.max.set(max[0], max[1], max[2]);
    const c = this.box.getCenter(new THREE.Vector3());
    const s = this.box.getSize(new THREE.Vector3());
    const size = [Math.max(s.x, 1e-9), Math.max(s.y, 1e-9), Math.max(s.z, 1e-9)];
    const ctr = [c.x, c.y, c.z];
    // grab band: thick enough to hit comfortably, thin enough to leave the
    // interior clear (capped so a huge box does not become a solid block)
    const t = Math.min(...size) * 0.12;
    const grab = Math.max(Math.min(t, Math.max(...size) * 0.04), 1e-9);
    EDGE_SPEC.forEach(([axis, sa, sb], i) => {
      const other = [0, 1, 2].filter((k) => k !== axis);
      const bar = this.bars[i];
      const scale = [grab, grab, grab];
      scale[axis] = size[axis] + grab;          // run the full edge length
      const pos = [...ctr];
      pos[other[0]] = ctr[other[0]] + sa * size[other[0]] / 2;
      pos[other[1]] = ctr[other[1]] + sb * size[other[1]] / 2;
      bar.position.set(pos[0], pos[1], pos[2]);
      bar.scale.set(scale[0], scale[1], scale[2]);
    });
    const len = Math.max(...size) * 0.20;
    this.handles[0].update(this.box.min.clone(), len);
    this.handles[1].update(this.box.max.clone(), len);
  }

  showHandles(on: boolean): void {
    this.handles[0].group.visible = on;
    this.handles[1].group.visible = on;
  }
}


/** Ghost planes showing where a batch sweep starts, ends and steps.
 *
 *  Batch parameters are three numbers on a form; seeing them as planes in
 *  the scene is what makes them checkable before spending minutes rendering.
 *  Start and end are drawn solid-ish, intermediate steps faint.
 */
export class BatchPreviewGizmo {
  group = new THREE.Group();
  private edgeMat: THREE.LineBasicMaterial;
  private endMat: THREE.LineBasicMaterial;
  private pool: THREE.LineSegments[] = [];

  constructor() {
    this.edgeMat = new THREE.LineBasicMaterial({
      color: 0xffc95c, transparent: true, opacity: 0.30 });
    this.endMat = new THREE.LineBasicMaterial({
      color: 0xffc95c, transparent: true, opacity: 0.95 });
  }

  /** `positions` in sweep order; `normal` is shared by every plane. */
  update(bounds: number[][], normal: THREE.Vector3, center: THREE.Vector3,
         positions: number[], size: number): void {
    while (this.pool.length < positions.length) {
      const ls = new THREE.LineSegments(
        new THREE.EdgesGeometry(new THREE.PlaneGeometry(1, 1)), this.edgeMat);
      this.pool.push(ls);
      this.group.add(ls);
    }
    const [bu, bv] = planeBasis(normal);
    this.pool.forEach((ls, i) => {
      const on = i < positions.length;
      ls.visible = on;
      if (!on) return;
      const isEnd = i === 0 || i === positions.length - 1;
      ls.material = isEnd ? this.endMat : this.edgeMat;
      ls.renderOrder = isEnd ? 2 : 1;
      orientPlane(ls, center.clone().addScaledVector(normal, positions[i]),
                  bu, bv, size, size);
    });
  }

  clear(): void { this.pool.forEach((l) => { l.visible = false; }); }
}
