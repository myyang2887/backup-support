/** Tier-2 full-3D: a slice plane sampling a Data3DTexture in a fragment shader.
 *  Fully isolated; throws FallbackToPointCloud when the environment can't do it,
 *  and Viewer3D degrades to the Tier-1 colored point cloud. Solid = alpha 0. */
import * as THREE from "three";
import { jet, normalize } from "../colormap";
import type { PreviewGrid } from "../types";
import { detectWebGL2 } from "./capability";

export class FallbackToPointCloud extends Error {}

const VERT = /* glsl */ `
  varying vec3 vWorld;
  void main() {
    vWorld = (modelMatrix * vec4(position, 1.0)).xyz;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;
const FRAG = /* glsl */ `
  precision highp float;
  precision highp sampler3D;
  varying vec3 vWorld;
  uniform sampler3D uVol;      // RGBA8, colormap pre-applied on CPU, solid alpha=0
  uniform vec3 uOrigin;
  uniform vec3 uSpan;          // spacing * (dims-1)
  void main() {
    vec3 t = (vWorld - uOrigin) / uSpan;
    if (any(lessThan(t, vec3(0.0))) || any(greaterThan(t, vec3(1.0)))) discard;
    vec4 c = texture(uVol, t);
    if (c.a < 0.5) discard;    // solid / NaN -> invisible (== "blacked out")
    gl_FragColor = vec4(c.rgb, 1.0);
  }
`;

export class Volume3D {
  mesh: THREE.Mesh | null = null;
  private tex: THREE.Data3DTexture | null = null;

  mount(grid: PreviewGrid, clim: [number, number], planeSize: number): THREE.Mesh {
    if (!detectWebGL2()) throw new FallbackToPointCloud("WebGL2 unavailable");
    const [nx, ny, nz] = grid.dims;
    // CPU-side colormap -> RGBA8 3D texture (portable: avoids float-texture pitfalls)
    const rgba = new Uint8Array(nx * ny * nz * 4);
    for (let i = 0; i < grid.data.length; i++) {
      const v = grid.data[i];
      if (Number.isNaN(v)) { rgba[4 * i + 3] = 0; continue; }
      const [r, g, b] = jet(normalize(v, clim));
      rgba[4 * i] = r * 255; rgba[4 * i + 1] = g * 255;
      rgba[4 * i + 2] = b * 255; rgba[4 * i + 3] = 255;
    }
    this.tex = new THREE.Data3DTexture(rgba, nx, ny, nz);
    this.tex.format = THREE.RGBAFormat;
    this.tex.minFilter = this.tex.magFilter = THREE.LinearFilter;
    this.tex.unpackAlignment = 1;
    this.tex.needsUpdate = true;
    const span = new THREE.Vector3(
      grid.spacing[0] * (nx - 1), grid.spacing[1] * (ny - 1), grid.spacing[2] * (nz - 1));
    const mat = new THREE.ShaderMaterial({
      vertexShader: VERT, fragmentShader: FRAG, side: THREE.DoubleSide,
      uniforms: {
        uVol: { value: this.tex },
        uOrigin: { value: new THREE.Vector3(...grid.origin) },
        uSpan: { value: span },
      },
    });
    this.mesh = new THREE.Mesh(new THREE.PlaneGeometry(planeSize, planeSize), mat);
    return this.mesh;
  }

  /** Move the sampling plane (driven by the slice gizmo params). */
  setPlane(pos: THREE.Vector3, normal: THREE.Vector3): void {
    if (!this.mesh) return;
    this.mesh.position.copy(pos);
    this.mesh.quaternion.setFromUnitVectors(
      new THREE.Vector3(0, 0, 1), normal.clone().normalize());
  }

  unmount(): void {
    this.tex?.dispose();
    if (this.mesh) {
      this.mesh.geometry.dispose();
      (this.mesh.material as THREE.Material).dispose();
    }
    this.mesh = null; this.tex = null;
  }
}
