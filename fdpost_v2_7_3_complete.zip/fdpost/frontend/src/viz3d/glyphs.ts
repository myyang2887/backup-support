/** 3D velocity arrow field.
 *
 *  One InstancedMesh for the shafts and one for the heads, so tens of
 *  thousands of arrows cost two draw calls. Each instance is oriented along
 *  its local velocity, coloured by speed, and sized by the shared adaptive
 *  rule (arrowScale.ts): fast = longer and thicker, slow = shorter and
 *  thinner, both clamped so the field stays readable.
 */
import * as THREE from "three";
import { ArrowScale, arrowGirth, arrowLength, speedQuantile } from "../arrowScale";
import { jet, normalize } from "../colormap";
import type { VectorField } from "../types";

export interface ArrowOptions {
  pitch: number;                       // lattice spacing in world units
  scale: number;
  minFrac: number;
  maxFrac: number;
  /** Speed window to keep; drops the near-stagnant clutter. */
  range: [number, number] | null;
  /** Colour scale for speed (usually the active field's clim). */
  clim: [number, number];
}

const UP = new THREE.Vector3(0, 1, 0);   // cone/cylinder default axis

/** Group holding shaft + head instanced meshes; dispose via disposeObject. */
export function buildArrowField(vf: VectorField, o: ArrowOptions): THREE.Group | null {
  const m = Math.floor(vf.coords.length / 3);
  if (!m) return null;

  // pass 1: filter by speed, remember what survives
  const speeds = new Float32Array(m);
  const idx: number[] = [];
  for (let i = 0; i < m; i++) {
    const s = Math.hypot(vf.vectors[3 * i], vf.vectors[3 * i + 1],
                         vf.vectors[3 * i + 2]);
    speeds[i] = s;
    if (!(s > 0)) continue;
    if (o.range && (s < o.range[0] || s > o.range[1])) continue;
    idx.push(i);
  }
  if (!idx.length) return null;

  const sc: ArrowScale = {
    pitch: o.pitch, speedMax: speedQuantile(speeds),
    minFrac: o.minFrac, maxFrac: o.maxFrac, scale: o.scale,
  };

  // unit-height primitives, scaled per instance
  const shaftGeo = new THREE.CylinderGeometry(1, 1, 1, 6, 1, true);
  const headGeo = new THREE.ConeGeometry(1, 1, 7);
  // NOTE: no `vertexColors` here. InstancedMesh takes its per-instance
  // colour from `instanceColor`; turning on vertexColors would additionally
  // define USE_COLOR and look for a per-vertex `color` attribute the
  // geometry does not have, which renders every arrow black.
  const mat = () => new THREE.MeshStandardMaterial({
    roughness: 0.5, metalness: 0.1,
  });
  const shafts = new THREE.InstancedMesh(shaftGeo, mat(), idx.length);
  const heads = new THREE.InstancedMesh(headGeo, mat(), idx.length);
  const shaftCol = new Float32Array(idx.length * 3);
  const headCol = new Float32Array(idx.length * 3);

  const dir = new THREE.Vector3(), pos = new THREE.Vector3();
  const quat = new THREE.Quaternion(), mtx = new THREE.Matrix4();
  const scl = new THREE.Vector3();
  const HEAD = 0.34;                    // head is this fraction of total length

  idx.forEach((i, k) => {
    const s = speeds[i];
    const len = arrowLength(s, sc);
    const girth = arrowGirth(len, o.pitch);
    dir.set(vf.vectors[3 * i], vf.vectors[3 * i + 1], vf.vectors[3 * i + 2])
       .divideScalar(s);
    quat.setFromUnitVectors(UP, dir);
    pos.set(vf.coords[3 * i], vf.coords[3 * i + 1], vf.coords[3 * i + 2]);

    // shaft: centred on the sample point, spanning the non-head part
    const shaftLen = len * (1 - HEAD);
    scl.set(girth * 0.32, shaftLen, girth * 0.32);
    mtx.compose(pos.clone().addScaledVector(dir, -len / 2 + shaftLen / 2),
                quat, scl);
    shafts.setMatrixAt(k, mtx);

    // head: cone sitting on the shaft tip
    scl.set(girth, len * HEAD, girth);
    mtx.compose(pos.clone().addScaledVector(dir, len / 2 - len * HEAD / 2),
                quat, scl);
    heads.setMatrixAt(k, mtx);

    const [r, g, b] = jet(normalize(s, o.clim));
    shaftCol[3 * k] = r; shaftCol[3 * k + 1] = g; shaftCol[3 * k + 2] = b;
    headCol[3 * k] = r; headCol[3 * k + 1] = g; headCol[3 * k + 2] = b;
  });

  shafts.instanceColor = new THREE.InstancedBufferAttribute(shaftCol, 3);
  heads.instanceColor = new THREE.InstancedBufferAttribute(headCol, 3);
  shafts.instanceColor.needsUpdate = true;
  heads.instanceColor.needsUpdate = true;
  shafts.instanceMatrix.needsUpdate = true;
  heads.instanceMatrix.needsUpdate = true;
  // instanced bounds are not derived from the base geometry
  shafts.frustumCulled = false;
  heads.frustumCulled = false;

  const g = new THREE.Group();
  g.add(shafts, heads);
  g.userData.arrowCount = idx.length;
  return g;
}
