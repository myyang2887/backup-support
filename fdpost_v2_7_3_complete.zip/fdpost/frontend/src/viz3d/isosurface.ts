/** Isosurface mesh renderer (lit, translucent, level-colored). */
import * as THREE from "three";
import { jet, normalize } from "../colormap";
import type { IsoMesh } from "../types";
import { shellMaterial } from "./shellMaterial";

export function buildIsosurface(mesh: IsoMesh, range: [number, number],
                                opacity: number): THREE.Mesh {
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(mesh.verts, 3));
  geo.setAttribute("normal", new THREE.BufferAttribute(mesh.normals, 3));
  geo.setIndex(new THREE.BufferAttribute(mesh.faces, 1));
  const [r, g, b] = jet(normalize(mesh.level, range));
  const mat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(r, g, b), roughness: 0.55, metalness: 0.05,
    transparent: opacity < 0.999, opacity, side: THREE.DoubleSide,
  });
  return new THREE.Mesh(geo, mat);
}

/** Layered translucent isosurfaces ("shells").
 *
 *  A nest of iso-levels reads far better than a point cloud: the outer shell
 *  gives the envelope of the flow, the inner ones the core. Each layer uses
 *  the Fresnel shell material, is drawn back-to-front, and does not write
 *  depth — so the stack blends into one volume instead of a pile of films.
 */
export function buildShells(meshes: IsoMesh[], range: [number, number],
                            baseOpacity: number): THREE.Group {
  const g = new THREE.Group();
  // low level = outermost shell -> draw first, most transparent
  const sorted = [...meshes].sort((a, b) => a.level - b.level);
  sorted.forEach((m, i) => {
    const t = sorted.length > 1 ? i / (sorted.length - 1) : 1;
    const opacity = baseOpacity + (0.85 - baseOpacity) * t * t;
    const [r, gg, b] = jet(normalize(m.level, range));
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(m.verts, 3));
    geo.setAttribute("normal", new THREE.BufferAttribute(m.normals, 3));
    geo.setIndex(new THREE.BufferAttribute(m.faces, 1));
    const mesh = new THREE.Mesh(
      geo, shellMaterial(new THREE.Color(r, gg, b), opacity));
    mesh.renderOrder = i;
    g.add(mesh);
  });
  return g;
}

/** Levels for a nested shell stack.
 *
 *  Quantiles when the server supplies them, because a linear split of
 *  [min, max] behaves badly on the usual CFD shape — mostly slow fluid with
 *  a small fast core. There, most of the range is empty, so linear levels
 *  cluster in near-void and the topmost shell can fail to exist at all.
 *  Quantile levels are evenly populated by construction.
 */
export function shellLevels(range: [number, number], count: number,
                            quantiles?: Record<string, number>): number[] {
  const n = Math.max(1, Math.min(5, count));
  if (quantiles && Object.keys(quantiles).length) {
    // spread n picks across the 50..95% band, inner shells tighter
    const qs = [0.50, 0.60, 0.70, 0.80, 0.85, 0.90, 0.95, 0.98];
    const pick = Array.from({ length: n },
      (_, i) => qs[Math.min(qs.length - 1,
                            Math.round((i / Math.max(1, n - 1)) * (qs.length - 2)))]);
    const vals = pick.map((q) => quantiles[String(q)]).filter(Number.isFinite);
    // strictly increasing and distinct, or fall through to linear
    if (vals.length === n && vals.every((v, i) => i === 0 || v > vals[i - 1])) {
      return vals;
    }
  }
  const [lo, hi] = range;
  return Array.from({ length: n },
                    (_, i) => lo + ((i + 1) / (n + 1)) * (hi - lo));
}
