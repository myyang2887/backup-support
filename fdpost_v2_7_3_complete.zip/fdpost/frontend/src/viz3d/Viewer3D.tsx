/** Persistent three.js viewport.
 *  - bounds + axes + fluid point cloud (guide) / volume slice (full3d)
 *  - grabbable slice / probe / region gizmos (DragManager)
 *  - streamlines + isosurface layers
 *  - instrument-HUD cursor readout (toggleable)
 *  - keyboard: arrows nudge the slice, R resets the view */
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { featureOn, useFeature } from "../features";
import { sampleNearest } from "../gridSlice";
import { loadSolidPoints } from "../actions";
import { useStore } from "../store";
import { toast } from "../toast";
import { DragManager, DragTarget } from "./interaction";
import { buildIsosurface } from "./isosurface";
import { AxisHandles, BatchPreviewGizmo, ProbeGizmo, RegionGizmo, SliceGizmo,
         eulerToNormal, normalToEuler } from "./gizmos";
import { buildArrowField } from "./glyphs";
import { buildShells } from "./isosurface";
import { buildAxes, buildBoundsBox, buildPointCloud, buildSolidCloud,
         disposeObject } from "./scene";
import { buildStreamlines } from "./streamlines";
import { FallbackToPointCloud, Volume3D } from "./Volume3D";

const AXIS_IDX = { x: 0, y: 1, z: 2 } as const;

interface Chip { left: number; top: number; lines: [string, string, string, string];
                 solid: boolean; }

export default function Viewer3D() {
  const ref = useRef<HTMLDivElement>(null);
  const [degraded, setDegraded] = useState(false);
  const [chip, setChip] = useState<Chip | null>(null);
  const { meta, points, previewGrid, clim, vizMode, activeTool,
          slice, probe, region, streamData, isoMesh, iso,
          display, vectors, shellMeshes, solidPoints,
          interactMode, setInteractMode, batch } = useStore();
  const world = useRef<{
    renderer?: THREE.WebGLRenderer; scene?: THREE.Scene;
    camera?: THREE.PerspectiveCamera; controls?: OrbitControls;
    dataGroup?: THREE.Group; cloud?: THREE.Points;
    sliceG?: SliceGizmo; probeG?: ProbeGizmo; regionG?: RegionGizmo;
    batchG?: BatchPreviewGizmo;
    streamObj?: THREE.Object3D; isoObj?: THREE.Mesh;
    arrowObj?: THREE.Object3D; shellObj?: THREE.Object3D;
    solidObj?: THREE.Object3D;
    volume?: Volume3D; drag?: DragManager;
    dataBox?: THREE.Box3; dirty: boolean; viewerReset?: () => void;
  }>({ dirty: true });

  // ---- one-time scene setup -------------------------------------------
  useEffect(() => {
    const el = ref.current!;
    const w = world.current;
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(el.clientWidth, el.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    el.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0d10);
    scene.add(new THREE.AmbientLight(0xffffff, 0.85));
    const dir = new THREE.DirectionalLight(0xffffff, 0.65);
    dir.position.set(1, 2, 3);
    scene.add(dir);
    const camera = new THREE.PerspectiveCamera(
      50, el.clientWidth / el.clientHeight, 1e-4, 1e4);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.addEventListener("change", () => { w.dirty = true; });
    const dataGroup = new THREE.Group();
    scene.add(dataGroup);
    const sliceG = new SliceGizmo(), probeG = new ProbeGizmo(),
          regionG = new RegionGizmo(), batchG = new BatchPreviewGizmo();
    scene.add(sliceG.group, probeG.group, regionG.group, batchG.group);
    const drag = new DragManager(camera, renderer.domElement, controls,
                                 () => { w.dirty = true; });
    Object.assign(w, { renderer, scene, camera, controls, dataGroup,
                       sliceG, probeG, regionG, batchG, drag });
    // targets are (re)installed by the viewport.drag feature effect below

    // camera API for sessions / snapshots
    useStore.getState().set({
      viewerApi: {
        getCamera: () => ({
          position: camera.position.toArray(),
          target: controls.target.toArray(),
        }),
        setCamera: (c) => {
          camera.position.fromArray(c.position as [number, number, number]);
          controls.target.fromArray(c.target as [number, number, number]);
          w.dirty = true;
        },
        resetView: () => { frameCamera(w); },
      },
    });
    w.viewerReset = () => { framedFor.current = null; frameCamera(w); };

    // cursor readout (instrument HUD)
    let raf = 0, chipPending: Chip | null | undefined;
    const onHudMove = (e: PointerEvent) => {
      const st = useStore.getState();
      if (!featureOn("viewport.cursorHud") || !st.cursorReadout
          || drag.dragging || !st.meta || !st.previewGrid) {
        chipPending = null;
      } else {
        chipPending = computeChip(w, e, el);
      }
    };
    const onHudLeave = () => { chipPending = null; };
    renderer.domElement.addEventListener("pointermove", onHudMove);
    renderer.domElement.addEventListener("pointerleave", onHudLeave);

    // keyboard nudges
    const onKey = (e: KeyboardEvent) => {
      if (!featureOn("viewport.keyboard")) return;
      const st = useStore.getState();
      if (e.key === "r" || e.key === "R") { frameCamera(w); return; }
      if (e.key === "g" || e.key === "G") {
        const cur = useStore.getState().interactMode;
        useStore.getState().setInteractMode(cur === "edit" ? "camera" : "edit");
        return;
      }
      if (st.activeTool !== "slice" || !st.meta || !st.previewGrid) return;
      const dirn = (e.key === "ArrowUp" || e.key === "ArrowRight") ? 1
                 : (e.key === "ArrowDown" || e.key === "ArrowLeft") ? -1 : 0;
      if (!dirn) return;
      e.preventDefault();
      if (st.slice.submode === "axis") {
        const n = st.previewGrid.dims[AXIS_IDX[st.slice.axis]];
        st.setSlice({ k: Math.min(n - 1, Math.max(0, st.slice.k + dirn)) });
      } else {
        const fine = e.shiftKey ? 0.2 : 1.0;
        const h = Math.min(...st.previewGrid.spacing) * fine;
        st.setSlice({ distance: +(st.slice.distance + dirn * h).toFixed(6) });
      }
    };
    el.tabIndex = 0;
    el.addEventListener("keydown", onKey);
    const onFocusDown = () => el.focus();
    el.addEventListener("pointerdown", onFocusDown);

    // ---- free-plane orientation by keyboard-modified drag ---------------
    // Dragging the arrow head sets tilt and azimuth together, which makes a
    // small correction to just one of them fiddly. Holding a key locks the
    // drag to a single angle: T = 回転角, A = 方位角.
    let spin: { key: "T" | "A"; x: number; y: number;
                tilt: number; azimuth: number } | null = null;
    const spinKey = (e: KeyboardEvent): "T" | "A" | null =>
      (e.key === "t" || e.key === "T") ? "T"
      : (e.key === "a" || e.key === "A") ? "A" : null;
    let heldKey: "T" | "A" | null = null;
    const onSpinKeyDown = (e: KeyboardEvent) => {
      const k = spinKey(e);
      const st2 = useStore.getState();
      if (!k || st2.activeTool !== "slice" || st2.slice.submode !== "plane") return;
      heldKey = k;
      renderer.domElement.style.cursor = k === "T" ? "ns-resize" : "ew-resize";
    };
    const onSpinKeyUp = () => {
      heldKey = null;
      if (!spin) renderer.domElement.style.cursor = "";
    };
    const onSpinDown = (e: PointerEvent) => {
      if (!heldKey || e.button !== 0) return;
      const s2 = useStore.getState().slice;
      spin = { key: heldKey, x: e.clientX, y: e.clientY,
               tilt: s2.tilt, azimuth: s2.azimuth };
      controls.enabled = false;
      renderer.domElement.setPointerCapture(e.pointerId);
      e.stopPropagation();
      e.preventDefault();
    };
    const onSpinMove = (e: PointerEvent) => {
      if (!spin) return;
      const st2 = useStore.getState();
      if (spin.key === "T") {                       // vertical drag -> 回転角
        const d = (spin.y - e.clientY) * 0.4;
        st2.setSlice({ tilt: +Math.max(0, Math.min(180, spin.tilt + d)).toFixed(1) });
      } else {                                      // horizontal drag -> 方位角
        const d = (e.clientX - spin.x) * 0.4;
        let a = (spin.azimuth + d) % 360;
        if (a > 180) a -= 360; else if (a < -180) a += 360;
        st2.setSlice({ azimuth: +a.toFixed(1) });
      }
      e.stopPropagation();
    };
    const onSpinUp = (e: PointerEvent) => {
      if (!spin) return;
      spin = null;
      controls.enabled = true;
      renderer.domElement.style.cursor = heldKey ? renderer.domElement.style.cursor : "";
      try { renderer.domElement.releasePointerCapture(e.pointerId); } catch { /**/ }
    };
    window.addEventListener("keydown", onSpinKeyDown);
    window.addEventListener("keyup", onSpinKeyUp);
    window.addEventListener("blur", onSpinKeyUp);
    // capture phase: beat DragManager and OrbitControls to the event
    renderer.domElement.addEventListener("pointerdown", onSpinDown, true);
    renderer.domElement.addEventListener("pointermove", onSpinMove, true);
    renderer.domElement.addEventListener("pointerup", onSpinUp, true);
    renderer.domElement.addEventListener("pointercancel", onSpinUp, true);

    const loop = () => {
      raf = requestAnimationFrame(loop);
      controls.update();
      if (chipPending !== undefined) { setChip(chipPending); chipPending = undefined; }
      if (w.dirty) { renderer.render(scene, camera); w.dirty = false; }
    };
    loop();
    const onResize = () => {
      renderer.setSize(el.clientWidth, el.clientHeight);
      camera.aspect = el.clientWidth / el.clientHeight || 1;
      camera.updateProjectionMatrix();
      w.dirty = true;
    };
    const ro = new ResizeObserver(onResize);
    ro.observe(el);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      window.removeEventListener("keydown", onSpinKeyDown);
      window.removeEventListener("keyup", onSpinKeyUp);
      window.removeEventListener("blur", onSpinKeyUp);
      renderer.domElement.removeEventListener("pointerdown", onSpinDown, true);
      renderer.domElement.removeEventListener("pointermove", onSpinMove, true);
      renderer.domElement.removeEventListener("pointerup", onSpinUp, true);
      renderer.domElement.removeEventListener("pointercancel", onSpinUp, true);
      renderer.domElement.removeEventListener("pointermove", onHudMove);
      renderer.domElement.removeEventListener("pointerleave", onHudLeave);
      el.removeEventListener("keydown", onKey);
      el.removeEventListener("pointerdown", onFocusDown);
      drag.dispose();
      w.volume?.unmount();
      useStore.getState().set({ viewerApi: null });
      disposeObject(scene);
      renderer.dispose();
      el.removeChild(renderer.domElement);
    };
  }, []);

  // ---- feature flags ---------------------------------------------------
  const dragOn = useFeature("viewport.drag");
  const streamToolOn = useFeature("tool.stream");
  const isoToolOn = useFeature("tool.iso");
  const arrowsOn = useFeature("viewport.arrows");
  const batchOn = useFeature("slice.batch");
  const shellsOn = useFeature("viewport.shells");
  const framedFor = useRef<string | null>(null);
  useEffect(() => {
    const w = world.current;
    if (!w.drag) return;
    // Targets exist ONLY in edit mode. In camera mode nothing is pickable,
    // so there is no code path that can leave OrbitControls disabled.
    const editing = dragOn && interactMode === "edit";
    w.drag.setTargets(editing ? buildDragTargets(w) : []);
    if (!editing) w.drag.releaseAll();
    w.probeG?.showHandles(editing);
    w.regionG?.showHandles(editing);
    w.dirty = true;
  }, [dragOn, interactMode]);

  // ---- dataset changed: rebuild static geometry, frame camera ---------
  useEffect(() => {
    const w = world.current;
    if (!w.dataGroup || !meta?.bounds) return;
    while (w.dataGroup.children.length) {
      const c = w.dataGroup.children.pop()!;
      disposeObject(c);
    }
    const [lo, hi] = meta.bounds;
    w.dataBox = new THREE.Box3(new THREE.Vector3(lo[0], lo[1], lo[2]),
                               new THREE.Vector3(hi[0], hi[1], hi[2]));
    w.dataGroup.add(buildBoundsBox(meta.bounds), buildAxes(meta.bounds));
    const L = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]);
    if (points) {
      w.cloud = buildPointCloud(points, clim, L * 0.012 * display.pointSize, {
        style: display.pointStyle, opacity: display.pointOpacity,
        range: display.filterEnabled
          ? [display.filterMin, display.filterMax] : null,
      });
      w.cloud.visible = display.pointsVisible && vizMode !== "full3d";
      w.dataGroup.add(w.cloud);
    }
    if (framedFor.current !== meta.id) {
      frameCamera(w);                    // only reframe on a real dataset swap
      framedFor.current = meta.id;
    }
    w.dirty = true;
  }, [meta, points, clim, display.pointSize, display.pointStyle,
      display.pointOpacity, display.pointsVisible, display.filterEnabled,
      display.filterMin, display.filterMax, vizMode]);

  // ---- batch sweep preview: show start / end / step planes -------------
  useEffect(() => {
    const w = world.current;
    if (!w.batchG || !meta?.bounds) return;
    const show = activeTool === "slice" && batch.preview && batchOn;
    w.batchG.group.visible = show;
    if (!show) { w.batchG.clear(); w.dirty = true; return; }
    const [lo, hi] = meta.bounds;
    const c = new THREE.Vector3((lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2,
                                (lo[2] + hi[2]) / 2);
    const L = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]);
    const n = slice.submode === "axis"
      ? new THREE.Vector3().setComponent(AXIS_IDX[slice.axis], 1)
      : eulerToNormal(slice.tilt, slice.azimuth);
    // positions are offsets from the data centre along the normal
    const base = slice.submode === "axis" ? c.getComponent(AXIS_IDX[slice.axis]) : 0;
    const step = Math.abs(batch.step) || 1e-9;
    const lim = Math.min(200, Math.floor(Math.abs(batch.end - batch.start) / step) + 1);
    const dirn = batch.end >= batch.start ? 1 : -1;
    const pos = Array.from({ length: lim },
                           (_, i) => batch.start + dirn * step * i - base);
    w.batchG.update(meta.bounds, n, c, pos, L * 1.05);
    w.dirty = true;
  }, [meta, activeTool, slice.submode, slice.axis, slice.tilt, slice.azimuth,
      batch.start, batch.end, batch.step, batch.preview, batchOn]);

  // ---- solid voxel shell -----------------------------------------------
  // Not affected by the value filter: solid cells carry no field value, so
  // there is nothing to filter them by.
  useEffect(() => {
    const w = world.current;
    if (!w.scene || !meta?.bounds) return;
    if (w.solidObj) { w.scene.remove(w.solidObj); disposeObject(w.solidObj); }
    w.solidObj = undefined;
    if (solidPoints?.length && display.solidVisible) {
      const [lo, hi] = meta.bounds;
      const L = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]);
      w.solidObj = buildSolidCloud(
        solidPoints, L * 0.012 * display.solidSize, display.solidOpacity);
      w.scene.add(w.solidObj);
    }
    w.dirty = true;
  }, [solidPoints, display.solidVisible, display.solidOpacity,
      display.solidSize, meta]);

  // ---- velocity arrow field -------------------------------------------
  useEffect(() => {
    const w = world.current;
    if (!w.scene || !meta?.bounds) return;
    if (w.arrowObj) { w.scene.remove(w.arrowObj); disposeObject(w.arrowObj); }
    w.arrowObj = undefined;
    if (vectors && display.arrowsVisible && arrowsOn) {
      const [lo, hi] = meta.bounds;
      const L = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]);
      const obj = buildArrowField(vectors, {
        pitch: L / Math.max(4, display.arrowDensity),
        scale: display.arrowScale,
        minFrac: display.arrowMinFrac, maxFrac: display.arrowMaxFrac,
        range: display.filterEnabled
          ? [display.filterMin, display.filterMax] : null,
        clim,
      });
      if (obj) { w.arrowObj = obj; w.scene.add(obj); }
    }
    w.dirty = true;
  }, [vectors, display.arrowsVisible, display.arrowScale, display.arrowDensity,
      display.arrowMinFrac, display.arrowMaxFrac, display.filterEnabled,
      display.filterMin, display.filterMax, clim, meta, arrowsOn]);

  // ---- layered isosurface shells ---------------------------------------
  useEffect(() => {
    const w = world.current;
    if (!w.scene) return;
    if (w.shellObj) { w.scene.remove(w.shellObj); disposeObject(w.shellObj); }
    w.shellObj = undefined;
    if (shellMeshes?.length && display.shellsVisible && shellsOn) {
      w.shellObj = buildShells(shellMeshes, iso.range, display.shellOpacity);
      w.scene.add(w.shellObj);
    }
    w.dirty = true;
  }, [shellMeshes, display.shellsVisible, display.shellOpacity, iso.range,
      shellsOn]);

  // ---- full3d mount/unmount with graceful degradation -----------------
  useEffect(() => {
    const w = world.current;
    if (!w.scene || !meta?.bounds) return;
    if (w.volume?.mesh) w.scene.remove(w.volume.mesh);
    w.volume?.unmount();
    w.volume = undefined;
    setDegraded(false);
    if (vizMode === "full3d" && previewGrid) {
      try {
        const [lo, hi] = meta.bounds;
        const L = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]) * 1.6;
        const vol = new Volume3D();
        w.scene.add(vol.mount(previewGrid, clim, L));
        w.volume = vol;
        if (w.cloud) w.cloud.visible = false;
      } catch (e) {
        if (e instanceof FallbackToPointCloud) {
          setDegraded(true);
          if (w.cloud) w.cloud.visible = display.pointsVisible;
        } else throw e;
      }
    } else if (w.cloud) w.cloud.visible = display.pointsVisible;
    w.dirty = true;
  }, [vizMode, previewGrid, meta, clim, display.pointsVisible]);

  // ---- gizmo transforms (pure, real-time) -----------------------------
  const stream = useStore((s) => s.stream);
  useEffect(() => {
    const w = world.current;
    if (!w.sliceG || !meta?.bounds) return;
    const [lo, hi] = meta.bounds;
    const size = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]);
    w.sliceG.group.visible = activeTool === "slice";
    w.probeG!.group.visible = activeTool === "probe" || activeTool === "stream";
    w.regionG!.group.visible = activeTool === "region";
    if (activeTool === "slice") {
      if (slice.submode === "axis") {
        const a = AXIS_IDX[slice.axis];
        const pos = (previewGrid ? previewGrid.origin[a] : lo[a])
                    + (previewGrid?.spacing[a] ?? 0) * slice.k;
        w.sliceG.updateAxis(meta.bounds, slice.axis, pos);
        w.volume?.setPlane(
          new THREE.Vector3(
            slice.axis === "x" ? pos : (lo[0] + hi[0]) / 2,
            slice.axis === "y" ? pos : (lo[1] + hi[1]) / 2,
            slice.axis === "z" ? pos : (lo[2] + hi[2]) / 2),
          new THREE.Vector3(a === 0 ? 1 : 0, a === 1 ? 1 : 0, a === 2 ? 1 : 0));
      } else {
        w.sliceG.updateEuler(meta.bounds, slice.tilt, slice.azimuth, slice.distance);
        const c = new THREE.Vector3(
          (lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2);
        const n = eulerToNormal(slice.tilt, slice.azimuth);
        w.volume?.setPlane(c.addScaledVector(n, slice.distance), n);
      }
    }
    if (activeTool === "probe") w.probeG!.update(probe.p0, probe.p1, size);
    if (activeTool === "stream") w.probeG!.update(stream.p0, stream.p1, size);
    if (activeTool === "region") w.regionG!.update(region.min, region.max);
    w.dirty = true;
  }, [meta, previewGrid, activeTool, slice, probe, region, stream, vizMode]);

  // ---- streamlines layer ----------------------------------------------
  useEffect(() => {
    const w = world.current;
    if (!w.scene) return;
    if (w.streamObj) { w.scene.remove(w.streamObj); disposeObject(w.streamObj); }
    w.streamObj = undefined;
    if (streamData && streamData.counts.length && streamToolOn) {
      w.streamObj = buildStreamlines(streamData);
      w.scene.add(w.streamObj);
    }
    w.dirty = true;
  }, [streamData, streamToolOn]);

  // ---- isosurface layer -----------------------------------------------
  useEffect(() => {
    const w = world.current;
    if (!w.scene) return;
    if (w.isoObj) { w.scene.remove(w.isoObj); disposeObject(w.isoObj); }
    w.isoObj = undefined;
    if (isoMesh && iso.visible && isoToolOn) {
      w.isoObj = buildIsosurface(isoMesh, iso.range, iso.opacity);
      w.scene.add(w.isoObj);
    }
    w.dirty = true;
  }, [isoMesh, iso.visible, iso.opacity, iso.range, isoToolOn]);

  return (
    <div style={{ position: "relative", width: "100%", height: "100%" }}>
      <div ref={ref} style={{ width: "100%", height: "100%", outline: "none" }} />
      {chip && (
        <div className="cursor-chip" style={{ left: chip.left, top: chip.top }}>
          {chip.lines[0]}{"\n"}{chip.lines[1]}{"\n"}{chip.lines[2]}{"\n"}
          <span className={chip.solid ? "s" : "v"}>{chip.lines[3]}</span>
        </div>
      )}
      <div style={{ position: "absolute", top: 10, left: 10, display: "flex",
                    gap: 6, alignItems: "center", zIndex: 5 }}>
        <div className="tabs" style={{ background: "rgba(16,18,23,0.82)",
                                       borderRadius: 5 }}>
          <button className={interactMode === "camera" ? "on" : ""}
                  title="マウスは常に視点操作 (G で切替)"
                  onClick={() => setInteractMode("camera")}>視点</button>
          <button className={interactMode === "edit" ? "on" : ""}
                  title="ギズモの矢印をドラッグして編集 (G で切替)"
                  onClick={() => setInteractMode("edit")}>編集</button>
        </div>
        <button title={solidPoints ? "固体セルの表示切替" : "固体セルを読み込んで表示"}
                style={{ background: "rgba(16,18,23,0.82)", padding: "3px 9px",
                         color: display.solidVisible
                           ? "var(--accent)" : "var(--text-faint)" }}
                onClick={async () => {
                  const st2 = useStore.getState();
                  if (!solidPoints) {
                    try { await loadSolidPoints(); }
                    catch (e: any) { toast(e.message, "err"); return; }
                    st2.setDisplay({ solidVisible: true });
                  } else {
                    st2.setDisplay({ solidVisible: !display.solidVisible });
                  }
                }}>■ 固体</button>
        <button title="視点をリセット (R)"
                style={{ background: "rgba(16,18,23,0.82)", padding: "3px 9px" }}
                onClick={() => world.current.viewerReset?.()}>⟲ リセット</button>
      </div>
      {interactMode === "edit" && (
        <div style={{ position: "absolute", bottom: 10, left: 10, fontSize: 11,
                      background: "rgba(16,18,23,0.82)", padding: "3px 9px",
                      borderRadius: 4, color: "var(--text-dim)", zIndex: 5 }}>
          編集モード: 色付き矢印をドラッグ (赤=X 緑=Y 青=Z)。
          何もない所のドラッグは視点操作のままです。
        </div>
      )}
      {degraded && (
        <div style={{ position: "absolute", top: 46, left: 10, fontSize: 11,
                      background: "#4a3a12", border: "1px solid #6b5a2a",
                      padding: "4px 10px", borderRadius: 4 }}>
          この環境は完全3Dモード非対応のため、ポイントクラウド表示に切替えました
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------

function frameCamera(w: { camera?: THREE.PerspectiveCamera;
                          controls?: OrbitControls; dataBox?: THREE.Box3;
                          dirty: boolean }): void {
  if (!w.camera || !w.controls || !w.dataBox) return;
  const c = w.dataBox.getCenter(new THREE.Vector3());
  const s = w.dataBox.getSize(new THREE.Vector3());
  const L = Math.max(s.x, s.y, s.z) || 1;
  w.camera.position.set(c.x + L * 1.45, c.y - L * 1.45, c.z + L * 1.0);
  w.camera.up.set(0, 0, 1);
  w.controls.target.copy(c);
  w.dirty = true;
}

/** Drag targets read live state via useStore.getState() — no stale closures. */
function buildDragTargets(w: {
  sliceG?: SliceGizmo; probeG?: ProbeGizmo; regionG?: RegionGizmo;
  dataBox?: THREE.Box3;
}): DragTarget[] {
  const st = () => useStore.getState();
  let regionSnap: { min: number[]; max: number[] } | null = null;
  let headAnchor = new THREE.Vector3();
  // Endpoint editing is axis-constrained: each arrow maps the drag onto one
  // world coordinate. Free 3D dragging of a bare point is unusable because
  // the depth under the cursor is a guess.
  const pointTargets: DragTarget[] = [];
  const addPointHandles = (
    idBase: string, handles: AxisHandles, get: () => number[],
    setPos: (v: [number, number, number]) => void,
  ) => {
    for (let a = 0; a < 3; a++) {
      let snap: number[] = [];
      pointTargets.push({
        id: `${idBase}-${a}`,
        object: handles.arrows[a],
        mode: "axis",
        axis: () => { const v = new THREE.Vector3(); v.setComponent(a, 1); return v; },
        onHover: (on) => handles.setHover(a, on),
        onStart: () => { snap = [...get()]; },
        onDrag: (hit, start) => {
          const d = hit.getComponent(a) - start.getComponent(a);
          const v = [...snap] as [number, number, number];
          v[a] = +(snap[a] + d).toFixed(6);
          setPos(v);
        },
      });
    }
  };
  const probeKey = () => (st().activeTool === "stream" ? "stream" : "probe");
  addPointHandles("probe-p0", w.probeG!.handles[0],
    () => (probeKey() === "stream" ? st().stream.p0 : st().probe.p0),
    (v) => (probeKey() === "stream" ? st().setStream({ p0: v })
                                    : st().setProbe({ p0: v })));
  addPointHandles("probe-p1", w.probeG!.handles[1],
    () => (probeKey() === "stream" ? st().stream.p1 : st().probe.p1),
    (v) => (probeKey() === "stream" ? st().setStream({ p1: v })
                                    : st().setProbe({ p1: v })));
  // region corners: dragging one axis moves that face -> resize with the mouse
  addPointHandles("region-min", w.regionG!.handles[0],
    () => st().region.min,
    (v) => {
      const mx = st().region.max;
      st().setRegion({ min: [Math.min(v[0], mx[0]), Math.min(v[1], mx[1]),
                             Math.min(v[2], mx[2])] });
    });
  addPointHandles("region-max", w.regionG!.handles[1],
    () => st().region.max,
    (v) => {
      const mn = st().region.min;
      st().setRegion({ max: [Math.max(v[0], mn[0]), Math.max(v[1], mn[1]),
                             Math.max(v[2], mn[2])] });
    });

  return [
    {
      id: "slice-plane",
      object: w.sliceG!.planeMesh,
      mode: "axis",
      axis: () => w.sliceG!.normal.clone(),
      onHover: (on) => w.sliceG!.setHover("plane", on),
      onDrag: (hit) => {
        const s = st();
        if (!s.meta?.bounds || !s.previewGrid) return;
        if (s.slice.submode === "axis") {
          const a = AXIS_IDX[s.slice.axis];
          const g = s.previewGrid;
          const k = Math.round((hit.getComponent(a) - g.origin[a]) / g.spacing[a]);
          s.setSlice({ k: Math.min(g.dims[a] - 1, Math.max(0, k)) });
        } else {
          const [lo, hi] = s.meta.bounds;
          const c = new THREE.Vector3(
            (lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2);
          const n = eulerToNormal(s.slice.tilt, s.slice.azimuth);
          s.setSlice({ distance: +hit.clone().sub(c).dot(n).toFixed(6) });
        }
      },
    },
    {
      id: "slice-head",
      object: w.sliceG!.headMesh,
      mode: "screen",
      onHover: (on) => w.sliceG!.setHover("head", on),
      onStart: () => {
        const s = st();
        if (s.slice.submode === "axis" && s.meta?.bounds && s.previewGrid) {
          // grabbing the arrow in axis mode promotes the cut to a free plane
          const a = AXIS_IDX[s.slice.axis];
          const [lo, hi] = s.meta.bounds;
          const c = [(lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2];
          const g = s.previewGrid;
          const n = new THREE.Vector3(); n.setComponent(a, 1);
          const eu = normalToEuler(n, 0);
          s.setSlice({ submode: "plane", tilt: +eu.tilt.toFixed(1),
                       azimuth: +eu.azimuth.toFixed(1),
                       distance: +((g.origin[a] + g.spacing[a] * s.slice.k)
                                   - c[a]).toFixed(6) });
        }
        headAnchor = w.sliceG!.origin.clone();
      },
      onDrag: (hit) => {
        const s = st();
        const dirv = hit.clone().sub(headAnchor);
        if (dirv.lengthSq() < 1e-12) return;
        const eu = normalToEuler(dirv, s.slice.azimuth);
        s.setSlice({ tilt: +eu.tilt.toFixed(1), azimuth: +eu.azimuth.toFixed(1) });
      },
    },
    ...pointTargets,
    {
      id: "region-body",
      object: w.regionG!.pickMesh,
      mode: "screen",
      onHover: (on) => w.regionG!.setHover(on),
      onStart: () => {
        const r = st().region;
        regionSnap = { min: [...r.min], max: [...r.max] };
      },
      onDrag: (hit, start) => {
        if (!regionSnap) return;
        const d = hit.clone().sub(start);
        const mv = (v: number[], i: number) => +(v[i] + d.getComponent(i)).toFixed(6);
        st().setRegion({
          min: [mv(regionSnap.min, 0), mv(regionSnap.min, 1), mv(regionSnap.min, 2)],
          max: [mv(regionSnap.max, 0), mv(regionSnap.max, 1), mv(regionSnap.max, 2)],
        });
      },
      onEnd: () => { regionSnap = null; },
    },
  ];
}

/** Cursor HUD: prefer a precise hit on the slice plane, else the data box. */
function computeChip(w: { sliceG?: SliceGizmo; dataBox?: THREE.Box3;
                          camera?: THREE.PerspectiveCamera },
                     e: PointerEvent, el: HTMLElement): Chip | null {
  const s = useStore.getState();
  if (!w.dataBox || !w.camera || !s.previewGrid) return null;
  const r = el.getBoundingClientRect();
  const ndc = new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1,
                                -((e.clientY - r.top) / r.height) * 2 + 1);
  const ray = new THREE.Raycaster();
  ray.setFromCamera(ndc, w.camera);
  let p: THREE.Vector3 | null = null;
  if (s.activeTool === "slice" && w.sliceG?.group.visible) {
    const hits = ray.intersectObject(w.sliceG.planeMesh, false);
    if (hits.length) p = hits[0].point;
  }
  if (!p) p = ray.ray.intersectBox(w.dataBox, new THREE.Vector3());
  if (!p) return null;
  const sample = sampleNearest(s.previewGrid, p.x, p.y, p.z);
  const unit = s.meta?.units?.[s.activeField] ?? "";
  const fmt = (v: number) => (v >= 0 ? "+" : "") + v.toFixed(6);
  const valueLine = sample === null ? s.activeField + "  ---"
    : sample.solid ? s.activeField + "  固体"
    : s.activeField + "  " + sample.value!.toPrecision(5) + (unit ? " " + unit : "");
  return {
    left: e.clientX + 14, top: e.clientY + 18,
    lines: ["X " + fmt(p.x), "Y " + fmt(p.y), "Z " + fmt(p.z), valueLine],
    solid: sample?.solid ?? false,
  };
}
