/** DragManager: industrial-style direct manipulation of gizmo handles.
 *  Pointer picking via raycaster; constraint solving per handle mode:
 *    axis   — translate along a fixed axis (closest point ray<->axis line)
 *    screen — move in the camera-parallel plane through the grab point
 *  OrbitControls is suspended while a handle is grabbed.
 *
 *  Two rules keep the camera usable (both were bugs before):
 *  1. A handle is only pickable when it and every ancestor is visible.
 *     three.js's raycaster ignores `.visible` entirely, so hidden gizmos
 *     from inactive tools would otherwise swallow every click and make the
 *     viewport feel frozen.
 *  2. Holding ORBIT_KEY suspends handle picking, so the camera can always
 *     be rotated even when a gizmo covers the whole screen. */
import * as THREE from "three";

/** Hold this to force camera orbit over any gizmo. */
export const ORBIT_KEY = "Alt";

export interface DragTarget {
  id: string;
  object: THREE.Object3D;
  mode: "axis" | "screen";
  axis?: () => THREE.Vector3;            // for axis mode
  onStart?: (hit: THREE.Vector3) => void;
  onDrag: (hit: THREE.Vector3, startHit: THREE.Vector3) => void;
  onEnd?: () => void;
  onHover?: (on: boolean) => void;
}

export class DragManager {
  private ray = new THREE.Raycaster();
  private ndc = new THREE.Vector2();
  private targets: DragTarget[] = [];
  private grabbed: DragTarget | null = null;
  private startHit = new THREE.Vector3();
  private axisOrigin = new THREE.Vector3();
  private axisDir = new THREE.Vector3();
  private plane = new THREE.Plane();
  private hovered: DragTarget | null = null;
  private suspended = false;

  constructor(private camera: THREE.Camera, private dom: HTMLElement,
              private controls: { enabled: boolean },
              private onChange: () => void) {
    dom.addEventListener("pointerdown", this.onDown);
    dom.addEventListener("pointermove", this.onMove);
    dom.addEventListener("pointerup", this.onUp);
    dom.addEventListener("pointercancel", this.onUp);
    dom.addEventListener("lostpointercapture", this.onUp);
    window.addEventListener("keydown", this.onKey);
    window.addEventListener("keyup", this.onKey);
    window.addEventListener("blur", this.onBlur);
  }

  setTargets(targets: DragTarget[]): void {
    this.targets = targets;
    this.clearHover();
  }
  get dragging(): boolean { return this.grabbed !== null; }

  dispose(): void {
    this.dom.removeEventListener("pointerdown", this.onDown);
    this.dom.removeEventListener("pointermove", this.onMove);
    this.dom.removeEventListener("pointerup", this.onUp);
    this.dom.removeEventListener("pointercancel", this.onUp);
    this.dom.removeEventListener("lostpointercapture", this.onUp);
    window.removeEventListener("keydown", this.onKey);
    window.removeEventListener("keyup", this.onKey);
    window.removeEventListener("blur", this.onBlur);
  }

  /** Alt held -> gizmos step aside so the camera can always be orbited. */
  private onKey = (e: KeyboardEvent): void => {
    const next = e.type === "keydown" && e.altKey;
    if (next === this.suspended) return;
    this.suspended = next;
    if (next) this.clearHover();
  };

  private onBlur = (): void => { this.suspended = false; this.clearHover(); };

  private clearHover(): void {
    if (!this.hovered) return;
    this.hovered.onHover?.(false);
    this.hovered = null;
    this.dom.style.cursor = "";
    this.onChange();
  }

  /** three.js raycasting ignores `.visible`, so check it (and the whole
   *  ancestor chain) ourselves — otherwise a hidden gizmo still blocks. */
  private static isVisible(o: THREE.Object3D): boolean {
    for (let n: THREE.Object3D | null = o; n; n = n.parent) {
      if (!n.visible) return false;
    }
    return true;
  }

  private castAt(e: PointerEvent): void {
    const r = this.dom.getBoundingClientRect();
    this.ndc.set(((e.clientX - r.left) / r.width) * 2 - 1,
                 -((e.clientY - r.top) / r.height) * 2 + 1);
    this.ray.setFromCamera(this.ndc, this.camera);
  }

  private pick(e: PointerEvent): { t: DragTarget; point: THREE.Vector3 } | null {
    if (this.suspended || e.altKey) return null;
    this.castAt(e);
    let best: { t: DragTarget; point: THREE.Vector3; d: number } | null = null;
    for (const t of this.targets) {
      if (!DragManager.isVisible(t.object)) continue;
      const hits = this.ray.intersectObject(t.object, true);
      if (hits.length && (!best || hits[0].distance < best.d)) {
        best = { t, point: hits[0].point.clone(), d: hits[0].distance };
      }
    }
    return best && { t: best.t, point: best.point };
  }

  private solve(e: PointerEvent, out: THREE.Vector3): boolean {
    this.castAt(e);
    if (this.grabbed!.mode === "axis") {
      // closest point on the axis line to the mouse ray
      const ro = this.ray.ray.origin, rd = this.ray.ray.direction;
      const w0 = new THREE.Vector3().subVectors(this.axisOrigin, ro);
      const a = rd.dot(rd), b = rd.dot(this.axisDir), c = this.axisDir.dot(this.axisDir);
      const d = rd.dot(w0), ee = this.axisDir.dot(w0);
      const den = a * c - b * b;
      if (Math.abs(den) < 1e-10) return false;      // ray ~parallel to axis
      const s = (a * ee - b * d) / den;             // parameter along the axis
      out.copy(this.axisOrigin).addScaledVector(this.axisDir, s);
      return true;
    }
    return this.ray.ray.intersectPlane(this.plane, out) !== null;
  }

  private onDown = (e: PointerEvent): void => {
    if (e.button !== 0) return;
    const hit = this.pick(e);
    if (!hit) return;
    this.grabbed = hit.t;
    this.startHit.copy(hit.point);
    if (hit.t.mode === "axis") {
      this.axisDir.copy(hit.t.axis!()).normalize();
      this.axisOrigin.copy(hit.point);
    } else {
      const n = new THREE.Vector3();
      this.camera.getWorldDirection(n);
      this.plane.setFromNormalAndCoplanarPoint(n, hit.point);
    }
    this.controls.enabled = false;
    this.dom.setPointerCapture(e.pointerId);
    hit.t.onStart?.(hit.point);
    e.preventDefault();
  };

  private onMove = (e: PointerEvent): void => {
    if (this.grabbed) {
      const p = new THREE.Vector3();
      if (this.solve(e, p)) {
        this.grabbed.onDrag(p, this.startHit);
        this.onChange();
      }
      return;
    }
    const hit = this.pick(e);
    const t = hit?.t ?? null;
    if (t !== this.hovered) {
      this.hovered?.onHover?.(false);
      t?.onHover?.(true);
      this.hovered = t;
      this.dom.style.cursor = t ? "grab" : "";
      this.onChange();
    }
  };

  private onUp = (e: PointerEvent): void => {
    // always re-enable, even if nothing was grabbed: a cancelled or lost
    // pointer must never be able to leave the camera switched off
    if (this.grabbed) {
      this.grabbed.onEnd?.();
      this.grabbed = null;
    }
    this.controls.enabled = true;
    try { this.dom.releasePointerCapture(e.pointerId); } catch { /* ignore */ }
  };

  /** Drop any grab and hand the camera back — called when leaving edit mode. */
  releaseAll(): void {
    if (this.grabbed) { this.grabbed.onEnd?.(); this.grabbed = null; }
    this.controls.enabled = true;
    this.clearHover();
  }
}
