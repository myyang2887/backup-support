/** Axis-aligned slice extraction from the Fortran-ordered preview grid.
 *  i = ix + nx*(iy + ny*iz). NaN -> null so Plotly treats it as missing. */
import type { PreviewGrid } from "./types";

export interface SliceForPlot {
  x: number[]; y: number[]; z: (number | null)[][];
  xLabel: string; yLabel: string; position: number;
}

const axisCoords = (g: PreviewGrid, a: number): number[] =>
  Array.from({ length: g.dims[a] }, (_, i) => g.origin[a] + g.spacing[a] * i);

export function extractSlice(
  g: PreviewGrid, axis: "x" | "y" | "z", k: number,
): SliceForPlot {
  const [nx, ny] = [g.dims[0], g.dims[1]];
  const d = g.data;
  const val = (ix: number, iy: number, iz: number): number | null => {
    const v = d[ix + nx * (iy + ny * iz)];
    return Number.isNaN(v) ? null : v;
  };
  if (axis === "z") {
    const x = axisCoords(g, 0), y = axisCoords(g, 1);
    const z = y.map((_, iy) => x.map((_, ix) => val(ix, iy, k)));
    return { x, y, z, xLabel: "X [m]", yLabel: "Y [m]",
             position: g.origin[2] + g.spacing[2] * k };
  }
  if (axis === "y") {
    const x = axisCoords(g, 0), yz = axisCoords(g, 2);
    const z = yz.map((_, iz) => x.map((_, ix) => val(ix, k, iz)));
    return { x, y: yz, z, xLabel: "X [m]", yLabel: "Z [m]",
             position: g.origin[1] + g.spacing[1] * k };
  }
  const xy = axisCoords(g, 1), yz = axisCoords(g, 2);
  const z = yz.map((_, iz) => xy.map((_, iy) => val(k, iy, iz)));
  return { x: xy, y: yz, z, xLabel: "Y [m]", yLabel: "Z [m]",
           position: g.origin[0] + g.spacing[0] * k };
}

/** Nearest-voxel lookup at a world point (cursor readout: honest to the
 *  preview resolution, no NaN bleed). Returns null outside the grid. */
export function sampleNearest(
  g: PreviewGrid, x: number, y: number, z: number,
): { value: number | null; solid: boolean } | null {
  const [nx, ny, nz] = g.dims;
  const ix = Math.round((x - g.origin[0]) / g.spacing[0]);
  const iy = Math.round((y - g.origin[1]) / g.spacing[1]);
  const iz = Math.round((z - g.origin[2]) / g.spacing[2]);
  if (ix < 0 || iy < 0 || iz < 0 || ix >= nx || iy >= ny || iz >= nz) return null;
  const v = g.data[ix + nx * (iy + ny * iz)];
  return Number.isNaN(v) ? { value: null, solid: true }
                         : { value: v, solid: false };
}
