/** Adaptive velocity-glyph sizing, shared by the 2D quiver overlay and the
 *  3D arrow field so both read the same way.
 *
 *  Rule: length grows with speed but is clamped into
 *  [minFrac, maxFrac] x pitch — fast arrows never swamp the view and slow
 *  ones never vanish. The sqrt mapping lifts the low end so a field with a
 *  few very fast cells still shows structure in the slow majority.
 */
export interface ArrowScale {
  pitch: number;      // lattice spacing in world units (the natural arrow size)
  speedMax: number;   // upper end of the speed range being mapped
  minFrac: number;    // shortest arrow, as a fraction of pitch
  maxFrac: number;    // longest arrow, as a fraction of pitch
  scale: number;      // user multiplier
}

export function arrowLength(speed: number, s: ArrowScale): number {
  const t = s.speedMax > 0
    ? Math.sqrt(Math.min(1, Math.max(0, speed / s.speedMax)))
    : 0;
  const frac = s.minFrac + (s.maxFrac - s.minFrac) * t;
  return s.pitch * frac * s.scale;
}

/** Thickness/head size follows length, but compressed — otherwise fast
 *  arrows turn into blobs. */
export function arrowGirth(length: number, pitch: number): number {
  return Math.min(length * 0.34, pitch * 0.22);
}

/** Robust upper bound for the speed scale: the 98th percentile rather than
 *  the raw max, so one outlier cell cannot flatten every other arrow. */
export function speedQuantile(speeds: ArrayLike<number>, q = 0.98): number {
  const v: number[] = [];
  for (let i = 0; i < speeds.length; i++) {
    const s = speeds[i];
    if (Number.isFinite(s)) v.push(s);
  }
  if (!v.length) return 0;
  v.sort((a, b) => a - b);
  return v[Math.min(v.length - 1, Math.floor(q * (v.length - 1)))];
}
