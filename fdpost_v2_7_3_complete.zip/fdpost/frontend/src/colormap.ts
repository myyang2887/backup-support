/** Jet colormap lookup shared by the 3D point cloud and 2D heatmaps. */
export function jet(t: number): [number, number, number] {
  const x = Math.min(1, Math.max(0, t));
  const r = Math.min(1, Math.max(0, 1.5 - Math.abs(4 * x - 3)));
  const g = Math.min(1, Math.max(0, 1.5 - Math.abs(4 * x - 2)));
  const b = Math.min(1, Math.max(0, 1.5 - Math.abs(4 * x - 1)));
  return [r, g, b];
}
export function normalize(v: number, clim: [number, number]): number {
  const [lo, hi] = clim;
  return hi > lo ? (v - lo) / (hi - lo) : 0.5;
}
