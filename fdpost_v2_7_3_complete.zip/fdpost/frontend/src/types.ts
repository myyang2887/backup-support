export interface DatasetOut {
  id: string; source_path: string; status: string; error: string | null;
  fields: string[]; units: Record<string, string>;
  bounds: number[][] | null; dims: number[] | null; spacing: number[] | null;
  meta: Record<string, any>; config: Record<string, any>;
  /** Disk footprint; absent on older servers. */
  storage?: {
    source_bytes: number; cache_bytes: number;
    source_owned: boolean; reclaimable_bytes: number;
  };
}
export interface PreviewMetaOut {
  dims: [number, number, number]; origin: number[]; spacing: number[];
  bounds: number[][]; fields: string[]; units: Record<string, string>;
  full_dims: number[];
}
export interface JobOut {
  id: string; kind: string; status: string; progress: number;
  message: string; result: Record<string, any> | null; error: string | null;
}
export interface PreviewGrid {
  dims: [number, number, number];
  origin: [number, number, number];
  spacing: [number, number, number];
  data: Float32Array; // Fortran order: i = ix + nx*(iy + ny*iz)
}
export interface PointCloud { coords: Float32Array; values: Float32Array; }
export type VizMode = "guide" | "full3d";
export type Tool = "data" | "slice" | "probe" | "stream" | "iso" | "region"
                 | "display" | "jobs" | "settings";

/** Mirrors backend FIELD_ROLE for sorting / default field choice. */
export function fieldRole(name: string): string {
  if (["velocity_magnitude", "pressure", "temperature", "density"].includes(name))
    return "scalar_field";
  if (["velocity_x", "velocity_y", "velocity_z"].includes(name))
    return "vector_component";
  if (["volume", "surface"].includes(name)) return "metadata";
  return "unknown";
}

export interface StreamData {
  counts: Uint32Array; points: Float32Array; speeds: Float32Array;
  speedRange: [number, number];
}
export interface IsoMesh {
  verts: Float32Array; normals: Float32Array; faces: Uint32Array;
  level: number; field: string;
}
export interface SessionRow {
  id: string; name: string; dataset_id: string; updated_at: string;
}

/** Full-resolution axis slice fetched from the backend (drawer preview). */
export interface SliceField {
  dims: [number, number];        // [nu, nv]
  origin: [number, number];
  spacing: [number, number];
  labels: [string, string];
  axis: string; index: number; position: number;
  unit: string;
  values: Float32Array;          // row-major [iv * nu + iu], NaN = solid
  vecU: Float32Array | null;     // in-plane velocity components, same layout
  vecV: Float32Array | null;
}

/** Velocity glyph seeds on a regular lattice (3D arrow field). */
export interface VectorField {
  coords: Float32Array;          // (M,3)
  vectors: Float32Array;         // (M,3)
  speedMax: number;
}
