/** ジョブ: batch progress + what those jobs left on the server's disk.
 *
 *  Batch results have to persist — they are collected after the job ends —
 *  so the output folder grows with every run. On a shared host that is both
 *  a storage problem and a privacy one: the files are the user's data
 *  sitting on someone else's machine.
 *
 *  Deletion is manual, never automatic. A timed sweep would eventually
 *  remove a result somebody still needed, and there is no way to ask them
 *  after the fact.
 */
import { useCallback, useEffect, useState } from "react";
import { deleteAllOutputs, deleteOutput, getJob, listOutputs,
         type OutputEntry } from "../api";
import { useStore } from "../store";
import { toast } from "../toast";
import type { JobOut } from "../types";
import ExportBar from "./ExportBar";

const KIND_LABEL: Record<string, string> = {
  preprocess: "前処理", axis_slice_batch: "断面バッチ",
  plane_slice_batch: "斜め断面バッチ",
};

function resultFiles(j: JobOut): string[] {
  const r = j.result ?? {};
  const urls: string[] = [];
  if (typeof r.zip_url === "string") urls.push(r.zip_url);
  if (typeof r.csv_url === "string") urls.push(r.csv_url);
  if (Array.isArray(r.file_urls)) urls.push(...r.file_urls.slice(0, 2));
  return urls.map((u) => u.replace("/api/files/", ""));
}

const fmtBytes = (b: number): string =>
  b >= 1 << 30 ? `${(b / (1 << 30)).toFixed(2)} GB`
  : b >= 1 << 20 ? `${(b / (1 << 20)).toFixed(1)} MB`
  : b >= 1 << 10 ? `${(b / (1 << 10)).toFixed(0)} KB` : `${b} B`;

const fmtTime = (epoch: number): string => {
  const d = new Date(epoch * 1000);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
};

/** Progress + result links for one background job. */
function JobRow({ job, id }: { job?: JobOut; id: string }) {
  if (!job) {
    return <div className="mono" style={{ fontSize: 11 }}>{id.slice(0, 8)}…</div>;
  }
  return (
    <div style={{ marginBottom: 12 }}>
      <div className="row" style={{ fontSize: 12, marginBottom: 4 }}>
        <b>{KIND_LABEL[job.kind] ?? job.kind}</b>
        <span className="mono" style={{ fontSize: 10, marginLeft: "auto",
          color: job.status === "error" ? "var(--err)"
               : job.status === "done" ? "var(--ok)" : "var(--warn)" }}>
          {job.status}
        </span>
      </div>
      <div style={{ background: "var(--bg-viewport)", borderRadius: 3,
                    height: 6, overflow: "hidden" }}>
        <div style={{ width: `${job.progress * 100}%`, height: 6,
                      background: job.status === "error" ? "var(--err)"
                                                         : "var(--accent)",
                      transition: "width .3s" }} />
      </div>
      {job.status === "running" && job.message && (
        <div className="mono" style={{ fontSize: 10, color: "var(--text-faint)",
             marginTop: 2 }}>{job.message}</div>
      )}
      {job.error && <div className="err">{job.error}</div>}
      {job.status === "done" && <ExportBar files={resultFiles(job)} />}
    </div>
  );
}

/** One stored export folder: download it, then remove it from the server. */
function OutputRow({ entry, onDeleted }:
                   { entry: OutputEntry; onDeleted: () => void }) {
  const [armed, setArmed] = useState(false);
  const [busy, setBusy] = useState(false);

  const remove = async () => {
    if (!armed) { setArmed(true); return; }
    setBusy(true);
    try {
      const r = await deleteOutput(entry.name);
      toast(`${entry.name} を削除しました (${fmtBytes(r.freed_bytes)} 解放)`);
      onDeleted();
    } catch (e: any) { toast(e.message, "err"); }
    setBusy(false);
    setArmed(false);
  };

  return (
    <div style={{ borderTop: "1px solid var(--line)", padding: "7px 0" }}>
      <div className="row" style={{ gap: 6 }}>
        <span className="mono" style={{ fontSize: 11, overflow: "hidden",
              textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {entry.name}
        </span>
        <span className="mono" style={{ fontSize: 10, marginLeft: "auto",
              color: "var(--text-faint)" }}>
          {entry.n_files}件 · {fmtBytes(entry.bytes)} · {fmtTime(entry.modified)}
        </span>
        <button className="quiet" disabled={busy}
                title={armed ? "もう一度クリックで削除" : "サーバから削除"}
                style={{ padding: "1px 6px",
                         color: armed ? "var(--err)" : "var(--text-faint)" }}
                onClick={remove}>
          {armed ? "削除?" : "✕"}
        </button>
      </div>
      <ExportBar files={entry.files} />
    </div>
  );
}

export default function JobsPanel() {
  const jobs = useStore((s) => s.jobs);
  const [state, setState] = useState<Record<string, JobOut>>({});
  const [outputs, setOutputs] = useState<
    { root: string; total_bytes: number; entries: OutputEntry[] } | null>(null);
  const [clearArmed, setClearArmed] = useState(false);

  const refresh = useCallback(async () => {
    try { setOutputs(await listOutputs()); }
    catch { setOutputs(null); }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  // poll only while something is still running
  useEffect(() => {
    if (!jobs.length) return;
    const t = setInterval(async () => {
      const pending = jobs.filter(
        (id) => !state[id] || !["done", "error"].includes(state[id].status));
      if (!pending.length) return;
      const updates: Record<string, JobOut> = {};
      await Promise.all(pending.map(async (id) => {
        try { updates[id] = await getJob(id); } catch { /* ignore */ }
      }));
      if (Object.keys(updates).length) {
        setState((s) => ({ ...s, ...updates }));
        refresh();                     // a finished job just wrote to disk
      }
    }, 1000);
    return () => clearInterval(t);
  }, [jobs, state, refresh]);

  const clearAll = async () => {
    if (!clearArmed) { setClearArmed(true); return; }
    setClearArmed(false);
    try {
      const r = await deleteAllOutputs();
      toast(`${r.deleted} 件を削除しました (${fmtBytes(r.freed_bytes)} 解放)`);
      refresh();
    } catch (e: any) { toast(e.message, "err"); }
  };

  return (
    <>
      <div className="panel" style={{ borderLeft: "3px solid var(--warn)" }}>
        <div style={{ fontSize: 12, lineHeight: 1.6 }}>
          サーバの保存容量には限りがあります。<br />
          <b>必要なファイルを手元にダウンロードしたら、
          サーバ上のファイルは削除してください。</b>
        </div>
        <div className="hint" style={{ marginTop: 6 }}>
          出力はサーバ側で生成されるため、ここに残ります。
          放置すると容量を圧迫し、他の利用者からも見えたままになります。
        </div>
      </div>

      <div className="panel">
        <div className="row">
          <h3 style={{ margin: 0 }}>ジョブ</h3>
          <span className="mono" style={{ marginLeft: "auto", fontSize: 10,
                color: "var(--text-faint)" }}>
            {jobs.length ? `${jobs.length} 件` : ""}
          </span>
        </div>
        {jobs.length ? (
          jobs.map((id) => <JobRow key={id} id={id} job={state[id]} />)
        ) : (
          <div className="hint">
            バッチ出力を実行するとここに進捗が表示されます。
          </div>
        )}
      </div>

      <div className="panel">
        <div className="row" style={{ marginBottom: 4 }}>
          <h3 style={{ margin: 0 }}>サーバ上のファイル</h3>
          <button className="quiet" style={{ marginLeft: "auto", padding: "1px 8px" }}
                  title="一覧を更新" onClick={refresh}>更新</button>
        </div>

        {outputs === null ? (
          <div className="hint">一覧を取得できませんでした。</div>
        ) : outputs.entries.length === 0 ? (
          <div className="hint">サーバ上に出力ファイルはありません。</div>
        ) : (
          <>
            <div className="mono" style={{ fontSize: 11, color: "var(--text-dim)" }}>
              合計 {fmtBytes(outputs.total_bytes)} / {outputs.entries.length} 件
            </div>
            <div className="hint" style={{ fontSize: 10, marginTop: 2,
                 wordBreak: "break-all" }}>{outputs.root}</div>
            {outputs.entries.map((e) => (
              <OutputRow key={e.name} entry={e} onDeleted={refresh} />
            ))}
            <div className="row" style={{ marginTop: 10 }}>
              <button style={{ marginLeft: "auto",
                               color: clearArmed ? "var(--err)" : undefined }}
                      onClick={clearAll}
                      onBlur={() => setClearArmed(false)}>
                {clearArmed ? "本当にすべて削除しますか?" : "すべて削除"}
              </button>
            </div>
          </>
        )}
      </div>
    </>
  );
}
