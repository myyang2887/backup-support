/** 表示 (display) tool: how the 3D viewport draws the field.
 *
 *  Nothing here changes exported data — it only controls what you look at.
 *  Three groups, matching the three ways to read a flow field:
 *    - ポイントクラウド + 値フィルタ : where the field is, minus the clutter
 *    - 速度ベクトル                  : which way it goes
 *    - サーフェス                    : its shape
 */
import { useState } from "react";
import { loadSolidPoints, loadVectors } from "../actions";
import { Feature } from "../features";
import { DISPLAY_DEFAULTS, useStore } from "../store";
import NumberSlider from "../ui/NumberSlider";
import { toast } from "../toast";

/** Labelled slider with a live numeric readout. */
function Slider(props: {
  label: string; value: number; min: number; max: number; step: number;
  fmt?: (v: number) => string; onChange: (v: number) => void;
  onCommit?: () => void;
}) {
  return (
    <div style={{ marginTop: 8 }}>
      <div className="row" style={{ marginBottom: 2 }}>
        <label>{props.label}</label>
        <span className="mono" style={{ marginLeft: "auto", fontSize: 11 }}>
          {(props.fmt ?? ((v: number) => v.toFixed(2)))(props.value)}
        </span>
      </div>
      <input type="range" min={props.min} max={props.max} step={props.step}
             value={props.value}
             onInput={(e) => props.onChange(+(e.target as HTMLInputElement).value)}
             onPointerUp={props.onCommit} />
    </div>
  );
}

function Check(props: { label: string; checked: boolean; onChange: () => void }) {
  return (
    <label style={{ display: "flex", gap: 6, alignItems: "center",
                    fontSize: 12, cursor: "pointer" }}>
      <input type="checkbox" checked={props.checked} onChange={props.onChange} />
      {props.label}
    </label>
  );
}

export default function DisplayPanel() {
  const { meta, activeField, clim, display, setDisplay, vectors,
          solidPoints, set } = useStore();
  const [busy, setBusy] = useState("");
  if (!meta?.bounds) return <div className="hint">データセットを読み込んでください</div>;
  const unit = meta.units?.[activeField] ?? "";
  const span = clim[1] - clim[0] || 1;
  const fmtVal = (v: number) => v.toPrecision(4) + (unit ? ` ${unit}` : "");

  /** Drop the slowest `pct`% of the range — the one-click declutter. */
  const cutLow = (pct: number) => setDisplay({
    filterEnabled: true, filterMin: clim[0] + span * pct, filterMax: clim[1] });

  const withBusy = async (tag: string, fn: () => Promise<void>) => {
    setBusy(tag);
    try { await fn(); } catch (e: any) { toast(e.message, "err"); }
    setBusy("");
  };

  return (
    <>
      {/* ---------------- point cloud + value filter ---------------- */}
      <div className="panel">
        <h3>ポイントクラウド</h3>
        <Check label="表示" checked={display.pointsVisible}
               onChange={() => setDisplay({ pointsVisible: !display.pointsVisible })} />
        <div className="row" style={{ marginTop: 8 }}>
          <label>形状</label>
          {(["round", "square"] as const).map((st) => (
            <button key={st} className={display.pointStyle === st ? "primary" : ""}
                    style={{ padding: "3px 10px" }}
                    onClick={() => setDisplay({ pointStyle: st })}>
              {st === "round" ? "丸(推奨)" : "四角"}
            </button>
          ))}
        </div>
        <NumberSlider label="点の大きさ" value={display.pointSize} min={0.3} max={3} step={0.1}
                onChange={(v) => setDisplay({ pointSize: v })} />
        <NumberSlider label="不透明度" value={display.pointOpacity} min={0.1} max={1} step={0.05}
                onChange={(v) => setDisplay({ pointOpacity: v })} />
      </div>

      <div className="panel">
        <h3>値フィルタ</h3>
        <div className="hint" style={{ marginBottom: 6 }}>
          範囲外のボクセルを非表示にします。低速点が霞のように溜まって
          全体形状が見えないときに使ってください({activeField})。
        </div>
        <Check label="フィルタを有効にする" checked={display.filterEnabled}
               onChange={() => setDisplay({ filterEnabled: !display.filterEnabled })} />
        <NumberSlider label="下限" value={display.filterMin} min={clim[0]} max={clim[1]}
                step={span / 200} fmt={fmtVal}
                onChange={(v) => setDisplay({
                  filterEnabled: true,
                  filterMin: Math.min(v, display.filterMax) })} />
        <NumberSlider label="上限" value={display.filterMax} min={clim[0]} max={clim[1]}
                step={span / 200} fmt={fmtVal}
                onChange={(v) => setDisplay({
                  filterEnabled: true,
                  filterMax: Math.max(v, display.filterMin) })} />
        <div className="row" style={{ marginTop: 8, flexWrap: "wrap" }}>
          <span className="hint" style={{ marginRight: 2 }}>低い値を除外:</span>
          {[0.05, 0.1, 0.2, 0.35].map((p) => (
            <button key={p} style={{ padding: "3px 8px" }} onClick={() => cutLow(p)}>
              {Math.round(p * 100)}%
            </button>
          ))}
          <button className="quiet" style={{ marginLeft: "auto" }}
                  onClick={() => setDisplay({
                    filterEnabled: false,
                    filterMin: clim[0], filterMax: clim[1] })}>
            解除
          </button>
        </div>
      </div>

      {/* ---------------- 2D slice preview ---------------- */}
      <div className="panel">
        <h3>断面プレビュー</h3>
        <div className="hint" style={{ marginBottom: 6 }}>
          下部の結果ドロワー「断面(リアルタイム)」の描画解像度です。
          上限は前処理時の格子解像度で、それ以上には細かくなりません。
        </div>
        <div className="row">
          <label>解像度</label>
          <select value={display.sliceMaxDim} style={{ marginLeft: "auto" }}
                  onChange={(e) => setDisplay({ sliceMaxDim: +e.target.value })}>
            <option value={0}>最大(格子と同じ)</option>
            <option value={512}>512</option>
            <option value={256}>256</option>
            <option value={128}>128</option>
            <option value={64}>64 (軽量)</option>
          </select>
        </div>
        <div className="row" style={{ marginTop: 8 }}>
          <button onClick={() => set({ drawerOpen: true, drawerTab: "contour" })}>
            結果ドロワーを開く
          </button>
        </div>
        <div className="hint" style={{ marginTop: 6 }}>
          同じ設定はドロワー上部にもあります。断面への速度矢印の表示もそちらです。
        </div>
      </div>

      {/* ---------------- solid cells ---------------- */}
      <div className="panel">
        <h3>固体セル</h3>
        <div className="hint" style={{ marginBottom: 6 }}>
          固体部分の表示設定です。物理量を持たないため色は付けず、
          グレーの半透明シェルとして描きます。
        </div>

        <div className="row">
          <button className="primary" disabled={busy === "solid"}
                  onClick={() => withBusy("solid", async () => {
                    await loadSolidPoints();
                    setDisplay({ solidVisible: true });
                  })}>
            {busy === "solid" ? "取得中…"
              : solidPoints ? "再取得" : "3Dビューに表示"}
          </button>
          {solidPoints && (
            <button onClick={() => setDisplay({
                      solidVisible: !display.solidVisible })}>
              {display.solidVisible ? "非表示" : "表示"}
            </button>
          )}
        </div>
        <NumberSlider label="不透明度" value={display.solidOpacity}
                      min={0.05} max={1} step={0.05} decimals={2}
                      onChange={(v) => setDisplay({ solidOpacity: v })} />
        <NumberSlider label="点の大きさ" value={display.solidSize}
                      min={0.3} max={3} step={0.1} decimals={1}
                      onChange={(v) => setDisplay({ solidSize: v })} />
        {solidPoints && (
          <div className="hint" style={{ marginTop: 6 }}>
            固体セル {Math.floor(solidPoints.length / 3).toLocaleString()} 点
          </div>
        )}

        <div style={{ borderTop: "1px solid var(--line)", margin: "10px 0 0",
                      paddingTop: 8 }}>
          <Check label="2D断面図で固体を塗りつぶす" checked={display.solid2d}
                 onChange={() => setDisplay({ solid2d: !display.solid2d })} />
          <div className="row" style={{ marginTop: 6, gap: 6 }}>
            <label style={{ fontSize: 12 }}>塗り色</label>
            <input type="color" value={display.solidColor}
                   disabled={!display.solid2d}
                   style={{ width: 44, height: 22, padding: 0 }}
                   onChange={(e) => setDisplay({ solidColor: e.target.value })} />
            <span className="hint" style={{ marginLeft: 4 }}>
              この設定は出力画像にも反映されます
            </span>
          </div>
        </div>
      </div>

      {/* ---------------- velocity arrows ---------------- */}
      <Feature id="viewport.arrows">
      <div className="panel">
        <h3>速度ベクトル(矢印)</h3>
        <div className="hint" style={{ marginBottom: 6 }}>
          速い所ほど長く太く、遅い所ほど短く細く描きます。
          長さは上下ともクランプされるので、極端な矢印は出ません。
        </div>
        <div className="row">
          <button className="primary" disabled={busy === "vec"}
                  onClick={() => withBusy("vec", async () => {
                    await loadVectors();
                    setDisplay({ arrowsVisible: true });
                  })}>
            {busy === "vec" ? "生成中…" : vectors ? "再生成" : "矢印を表示"}
          </button>
          {vectors && (
            <button onClick={() => setDisplay({
                      arrowsVisible: !display.arrowsVisible })}>
              {display.arrowsVisible ? "非表示" : "表示"}
            </button>
          )}
        </div>
        <NumberSlider label="密度" value={display.arrowDensity} min={8} max={40} step={1}
                fmt={(v) => `${v} 分割`}
                onChange={(v) => setDisplay({ arrowDensity: v })}
                onCommit={() => { if (vectors) withBusy("vec", loadVectors); }} />
        <NumberSlider label="長さ倍率" value={display.arrowScale} min={0.3} max={2.5} step={0.1}
                onChange={(v) => setDisplay({ arrowScale: v })} />
        <NumberSlider label="最小長(格子間隔比)" value={display.arrowMinFrac}
                min={0.1} max={0.8} step={0.05}
                onChange={(v) => setDisplay({
                  arrowMinFrac: Math.min(v, display.arrowMaxFrac - 0.05) })} />
        <NumberSlider label="最大長(格子間隔比)" value={display.arrowMaxFrac}
                min={0.4} max={2} step={0.05}
                onChange={(v) => setDisplay({
                  arrowMaxFrac: Math.max(v, display.arrowMinFrac + 0.05) })} />
        {vectors && (
          <div className="hint" style={{ marginTop: 6 }}>
            シード {Math.floor(vectors.coords.length / 3).toLocaleString()} 点 /
            最大流速 {vectors.speedMax.toPrecision(4)} m/s
          </div>
        )}
      </div>
      </Feature>

      <div className="hint" style={{ padding: "0 2px", marginBottom: 8 }}>
        サーフェス表現(多重等値面)は「等値面」ツールに移動しました。
      </div>

      <div className="row" style={{ padding: "0 2px" }}>
        <button onClick={() => set({
                  display: { ...DISPLAY_DEFAULTS,
                             filterMin: clim[0], filterMax: clim[1] } })}>
          表示設定を初期値に戻す
        </button>
      </div>
    </>
  );
}
