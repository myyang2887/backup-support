/** Debug settings: per-feature visibility switches (grouped, persisted). */
import { FEATURE_DEFS, FeatureId, isOn, useFeatures } from "../features";

export default function SettingsPanel() {
  const { overrides, toggle, reset } = useFeatures();
  const groups = [...new Set(FEATURE_DEFS.map((d) => d.group))];
  const offCount = Object.keys(overrides).length;

  return (
    <>
      <div className="panel">
        <h3>機能の表示設定(デバッグ)</h3>
        <div className="hint">
          各機能のボタン・パネル・ギズモ・3Dレイヤーは連動してON/OFFされます。
          設定はこのブラウザに保存され、リロード後も維持されます。
        </div>
      </div>
      {groups.map((g) => (
        <div className="panel" key={g}>
          <h3>{g}</h3>
          {FEATURE_DEFS.filter((d) => d.group === g).map((d) => (
            <label key={d.id}
                   style={{ display: "flex", gap: 8, alignItems: "flex-start",
                            padding: "5px 2px", cursor: "pointer",
                            fontSize: 12, color: "var(--text)" }}>
              <input type="checkbox"
                     checked={isOn(d.id as FeatureId, overrides)}
                     onChange={() => toggle(d.id as FeatureId)}
                     style={{ marginTop: 2 }} />
              <span>
                {d.label}
                <span style={{ display: "block", fontSize: 11,
                               color: "var(--text-faint)" }}>{d.desc}</span>
              </span>
            </label>
          ))}
        </div>
      ))}
      <div className="row" style={{ padding: "0 2px" }}>
        <button onClick={reset} disabled={offCount === 0}>
          全て初期値(ON)に戻す
        </button>
        {offCount > 0 && (
          <span className="mono" style={{ fontSize: 11,
                color: "var(--warn)" }}>{offCount} 件OFF</span>
        )}
      </div>
    </>
  );
}
