/** Streamlines: a seed rake between two draggable endpoints, RK4-traced. */
import { useState } from "react";
import { postStreamlines } from "../api";
import { useStore } from "../store";
import { toast } from "../toast";
import { Vec3Field } from "./ProbePanel";

export default function StreamPanel() {
  const { meta, activeId, stream, setStream, streamData, set } = useStore();
  const [busy, setBusy] = useState(false);
  if (!meta?.bounds) return <div className="hint">データセットを読み込んでください</div>;
  const hasVel = ["velocity_x", "velocity_y", "velocity_z"]
    .every((f) => meta.fields.includes(f));

  const run = async () => {
    setBusy(true);
    try {
      const d = await postStreamlines(activeId!, {
        p0: stream.p0, p1: stream.p1, n_seeds: stream.n_seeds,
        max_steps: stream.max_steps, direction: stream.direction });
      set({ streamData: d });
      toast(`流線 ${d.counts.length} 本を生成しました`);
    } catch (e: any) { toast(e.message, "err"); }
    setBusy(false);
  };

  return (
    <div className="panel">
      <h3>流線(シード配置)</h3>
      {!hasVel && <div className="err">速度の3成分がないため、流線を計算できません</div>}
      <Vec3Field label="始点" v={stream.p0} onChange={(v) => setStream({ p0: v })} />
      <Vec3Field label="終点" v={stream.p1} onChange={(v) => setStream({ p1: v })} />
      <div className="field-grid" style={{ marginTop: 4 }}>
        <label>シード数</label>
        <input type="number" min={1} max={500} value={stream.n_seeds}
               onChange={(e) => setStream({ n_seeds: +e.target.value })} />
        <label style={{ gridColumn: "3" }}>最大ステップ</label>
        <input type="number" min={10} max={5000} value={stream.max_steps}
               onChange={(e) => setStream({ max_steps: +e.target.value })} />
        <label>積分方向</label>
        <select value={stream.direction} style={{ gridColumn: "2 / 5" }}
                onChange={(e) => setStream({ direction: e.target.value as any })}>
          <option value="both">両方向</option>
          <option value="forward">下流のみ</option>
          <option value="backward">上流のみ</option>
        </select>
      </div>
      <div className="row" style={{ marginTop: 10 }}>
        <button className="primary" onClick={run} disabled={busy || !hasVel}>
          {busy ? "計算中…" : "生成"}
        </button>
        {streamData && (
          <button onClick={() => set({ streamData: null })}>クリア</button>
        )}
        {streamData && (
          <span className="mono" style={{ fontSize: 11, marginLeft: "auto" }}>
            {streamData.counts.length} 本 ·
            |v| {streamData.speedRange[0].toPrecision(3)}
            –{streamData.speedRange[1].toPrecision(3)}
          </span>
        )}
      </div>
      <div className="hint" style={{ marginTop: 8 }}>
        2つの端点球の間にシードを等間隔に配置し、速度場を RK4 で積分します。
        線の色は流速(jet)。固体・停滞域・領域外で自動的に終端します。
      </div>
    </div>
  );
}
