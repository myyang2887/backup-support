/** Upload + preprocessing options + dataset list. */
import { useRef, useState } from "react";
import { activateDataset, refreshDatasets } from "../actions";
import { deleteDataset, getJob, uploadDataset } from "../api";
import { IconClose } from "../icons";
import { useStore } from "../store";
import { toast } from "../toast";

export default function DatasetPanel() {
  const fileRef = useRef<HTMLInputElement>(null);
  const [method, setMethod] = useState("idw");
  const [targetDims, setTargetDims] = useState(128);
  const [advanced, setAdvanced] = useState(false);
  const [fluidMode, setFluidMode] = useState("auto");
  const [fluidField, setFluidField] = useState("velocity_magnitude");
  const [busy, setBusy] = useState("");
  const [err, setErr] = useState("");
  const { datasets, activeId, set } = useStore();
  const fmtBytes = (b: number): string =>
    b >= 1 << 30 ? `${(b / (1 << 30)).toFixed(2)} GB`
    : b >= 1 << 20 ? `${(b / (1 << 20)).toFixed(1)} MB`
    : b >= 1 << 10 ? `${(b / (1 << 10)).toFixed(0)} KB` : `${b} B`;
  const totalBytes = datasets.reduce(
    (n, d) => n + (d.storage?.source_bytes ?? 0) + (d.storage?.cache_bytes ?? 0), 0);
  const [confirmId, setConfirmId] = useState("");

  /** Two-step delete: the X arms the row, a second click confirms. */
  const onDelete = async (id: string) => {
    if (confirmId !== id) { setConfirmId(id); return; }
    setConfirmId("");
    try {
      const r = await deleteDataset(id);        // removes the uploaded copy too
      await refreshDatasets();
      if (id === activeId) {
        // the active dataset just vanished: clear every derived layer
        set({ activeId: null, meta: null, previewMeta: null, previewGrid: null,
              points: null, vectors: null, shellMeshes: null, isoMesh: null,
              streamData: null, planePng: "", probePng: "", drawerOpen: false });
      }
      toast(`データセットを削除しました (${fmtBytes(r.freed_bytes ?? 0)} 解放)`);
    } catch (e: any) { toast(e.message, "err"); }
  };

  const onUpload = async () => {
    const f = fileRef.current?.files?.[0];
    if (!f) { setErr("ファイルを選択してください"); return; }
    setErr(""); setBusy("アップロード中…");
    try {
      const rule = fluidMode === "auto" ? undefined
        : JSON.stringify(fluidMode === "field_present"
            ? { mode: fluidMode, field: fluidField } : { mode: fluidMode });
      const { dataset_id, job_id } = await uploadDataset(f,
        { method, target_dims: targetDims, fluid_rule: rule });
      for (;;) {
        const j = await getJob(job_id);
        setBusy(`前処理中… ${Math.round(j.progress * 100)}%`);
        if (j.status === "done") break;
        if (j.status === "error") throw new Error(j.error || j.message);
        await new Promise((r) => setTimeout(r, 700));
      }
      setBusy("");
      await refreshDatasets();
      await activateDataset(dataset_id);
      toast(`${f.name} を読み込みました`);
    } catch (e: any) { setBusy(""); setErr(e.message); }
  };

  const baseName = (p: string) => p.split(/[\\/]/).pop() ?? p;

  return (
    <>
      <div className="panel">
        <h3>データ読み込み</h3>
        <input type="file" ref={fileRef} accept=".txt,.tsv,.csv"
               style={{ width: "100%", fontSize: 12 }} />
        <div className="row" style={{ marginTop: 8 }}>
          <label>補間法</label>
          <select value={method} onChange={(e) => setMethod(e.target.value)}>
            {["nearest", "idw", "linear", "rbf"].map((m) => <option key={m}>{m}</option>)}
          </select>
          <label>解像度</label>
          <input type="number" style={{ width: 64 }} value={targetDims}
                 min={16} max={512}
                 onChange={(e) => setTargetDims(+e.target.value)} />
        </div>
        <div style={{ marginTop: 8 }}>
          <a style={{ fontSize: 11, color: "var(--accent)", cursor: "pointer" }}
             onClick={() => setAdvanced(!advanced)}>
            {advanced ? "▾" : "▸"} 詳細設定(流体/固体判定)
          </a>
          {advanced && (
            <div className="row" style={{ marginTop: 6 }}>
              <select value={fluidMode} onChange={(e) => setFluidMode(e.target.value)}>
                <option value="auto">自動判定</option>
                <option value="field_present">指定フィールド有無</option>
                <option value="all_fluid">全て流体</option>
              </select>
              {fluidMode === "field_present" && (
                <input value={fluidField} style={{ width: 140 }}
                       onChange={(e) => setFluidField(e.target.value)} />
              )}
            </div>
          )}
        </div>
        <div className="row" style={{ marginTop: 10 }}>
          <button className="primary" onClick={onUpload} disabled={!!busy}>
            読み込み・前処理
          </button>
          {busy && <span className="mono" style={{ fontSize: 11 }}>{busy}</span>}
        </div>
        {err && <div className="err">{err}</div>}
      </div>
      <div className="panel">
        <div className="row">
          <h3 style={{ margin: 0 }}>データセット一覧</h3>
          {totalBytes > 0 && (
            <span className="mono" style={{ marginLeft: "auto", fontSize: 10,
                  color: "var(--text-faint)" }}
                  title="元ファイル + 前処理キャッシュの合計">
              サーバ使用量 {fmtBytes(totalBytes)}
            </span>
          )}
        </div>
        {datasets.length === 0 && (
          <div className="hint">まだデータがありません。上のフォームから
            FloEFD のエクスポートファイルを読み込んでください。</div>
        )}
        {datasets.map((d) => (
          <div key={d.id}
               style={{ padding: "6px 8px", borderRadius: 4, marginBottom: 2,
                        background: d.id === activeId ? "var(--bg-2)" : "transparent",
                        borderLeft: d.id === activeId
                          ? "2px solid var(--accent)" : "2px solid transparent",
                        cursor: "pointer", fontSize: 12 }}
               onClick={() => activateDataset(d.id).catch((e) => toast(e.message, "err"))}>
            <div className="row" style={{ justifyContent: "space-between" }}>
              <span style={{ overflow: "hidden", textOverflow: "ellipsis",
                             whiteSpace: "nowrap" }}>{baseName(d.source_path)}</span>
              <span className="mono" style={{ fontSize: 10, marginLeft: "auto",
                color: d.status === "ready" ? "var(--ok)"
                     : d.status === "error" ? "var(--err)" : "var(--warn)" }}>
                {d.status}
              </span>
              <button className="quiet"
                      title={confirmId === d.id
                        ? `もう一度クリックで削除 (${fmtBytes(
                            d.storage?.reclaimable_bytes ?? 0)} 解放)`
                        : "このデータセットを削除(元ファイルとキャッシュも消えます)"}
                      style={{ padding: "1px 5px", marginLeft: 4,
                               color: confirmId === d.id
                                 ? "var(--err)" : "var(--text-faint)" }}
                      onClick={(e) => { e.stopPropagation(); onDelete(d.id); }}>
                {confirmId === d.id ? "削除?" : <IconClose size={11} />}
              </button>
            </div>
            {d.storage && (
              <div className="mono" style={{ color: "var(--text-faint)",
                   fontSize: 10 }}>
                元ファイル {fmtBytes(d.storage.source_bytes)}
                {" + "}キャッシュ {fmtBytes(d.storage.cache_bytes)}
                {!d.storage.source_owned && d.storage.source_bytes > 0
                  && " (元ファイルは登録パスのため削除されません)"}
              </div>
            )}
            {d.meta?.fluid_rule_used && (
              <div style={{ color: "var(--text-faint)", fontSize: 11 }}>
                {d.meta.fluid_rule_used} · 流体 {d.meta.n_fluid} / 固体 {d.meta.n_solid}
              </div>
            )}
            {d.error && <div className="err">{d.error}</div>}
          </div>
        ))}
      </div>
    </>
  );
}
