/** Getting a generated file onto the user's machine.
 *
 *  Every export is rendered on the SERVER first — that is where matplotlib
 *  and the sampler run. So a browser on another PC must still pull the bytes
 *  over HTTP; the file appearing in the host's output/ folder is an
 *  intermediate step, not the delivery.
 *
 *  Two entry points, deliberately different:
 *  - exportFile()   : user clicked a download button. May open a save-as
 *                     dialog (needs a live user gesture + a secure context).
 *  - downloadFile() : fired automatically right after an export finishes.
 *                     Always the plain anchor path — after an awaited POST
 *                     the user gesture has expired, so a picker would be
 *                     blocked, and showSaveFilePicker does not exist at all
 *                     on a plain-http origin like http://10.20.30.40:8000.
 */
import { fileUrl } from "../api";
import { IconDown } from "../icons";
import { toast } from "../toast";

declare global {
  interface Window {
    pywebview?: { api: { choose_save_dir(): Promise<string | null>;
                         export_to(rel: string, dir: string): Promise<string> } };
    showSaveFilePicker?: (o: any) => Promise<any>;
  }
}

export async function exportFile(relPath: string): Promise<void> {
  const name = relPath.split("/").pop() || "result";
  if (window.pywebview?.api) {
    const dir = await window.pywebview.api.choose_save_dir();
    if (!dir) return;
    const dest = await window.pywebview.api.export_to(relPath, dir);
    toast(`保存しました: ${dest}`);
    return;
  }
  const resp = await fetch(fileUrl(relPath));
  const blob = await resp.blob();
  if (window.showSaveFilePicker) {
    try {
      const h = await window.showSaveFilePicker({ suggestedName: name });
      const w = await h.createWritable();
      await w.write(blob); await w.close();
      toast(`保存しました: ${name}`);
    } catch { /* user cancelled */ }
    return;
  }
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name;
  a.click(); URL.revokeObjectURL(a.href);
  toast("ダウンロードを開始しました");
}

export default function ExportBar(props: { files: string[] }) {
  if (!props.files.length) return null;
  return (
    <div className="row" style={{ marginTop: 8 }}>
      {props.files.map((f) => (
        <button key={f} className="quiet" style={{ fontSize: 11,
                display: "inline-flex", gap: 5, alignItems: "center" }}
                onClick={() => exportFile(f)}>
          <IconDown size={13} /> {f.split("/").pop()}
        </button>
      ))}
    </div>
  );
}

/** Pull a file straight into the browser's download folder. No dialog, no
 *  gesture required — safe to call after an awaited request. */
export function downloadFile(relPath: string): void {
  const a = document.createElement("a");
  a.href = fileUrl(relPath);
  a.download = relPath.split("/").pop() || "result";
  document.body.appendChild(a);
  a.click();
  a.remove();
}

/** Several files at once. Staggered: browsers throttle (and prompt about)
 *  bursts of programmatic downloads. */
export function downloadAll(relPaths: string[]): void {
  relPaths.forEach((p, i) => window.setTimeout(() => downloadFile(p), i * 350));
}
