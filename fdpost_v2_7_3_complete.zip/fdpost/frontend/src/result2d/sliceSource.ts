/** Slice data for the results drawer, with progressive refinement.
 *
 *  Scrubbing the slider must stay instant, but the picture must not stay
 *  coarse. So: paint the preview-grid slice immediately (client-side, zero
 *  latency), then fetch the same cut at *full grid resolution* and swap it in
 *  once the user pauses. `resolution` tells the UI which one it is showing.
 */
import { useEffect, useRef, useState } from "react";
import { getSliceField, getSliceFieldDirect } from "../api";
import { extractSlice } from "../gridSlice";
import { useStore } from "../store";
import type { SliceField } from "../types";

export interface SlicePlot {
  x: number[]; y: number[];
  z: (number | null)[][];              // [row = v][col = u]
  vecU: (number | null)[][] | null;    // in-plane velocity, same layout
  vecV: (number | null)[][] | null;
  xLabel: string; yLabel: string;
  position: number;
  dims: [number, number];
  resolution: "preview" | "full" | "direct";
}

const REFINE_DELAY_MS = 160;

/** Row-major [iv*nu+iu] Float32Array -> Plotly's z[row][col], NaN -> null. */
function toRows(a: Float32Array, nu: number, nv: number): (number | null)[][] {
  const out: (number | null)[][] = new Array(nv);
  for (let iv = 0; iv < nv; iv++) {
    const row: (number | null)[] = new Array(nu);
    const base = iv * nu;
    for (let iu = 0; iu < nu; iu++) {
      const v = a[base + iu];
      row[iu] = Number.isNaN(v) ? null : v;
    }
    out[iv] = row;
  }
  return out;
}

const coords = (o: number, d: number, n: number): number[] =>
  Array.from({ length: n }, (_, i) => o + d * i);

function fromField(f: SliceField,
                   kind: "full" | "direct" = "full"): SlicePlot {
  const [nu, nv] = f.dims;
  return {
    x: coords(f.origin[0], f.spacing[0], nu),
    y: coords(f.origin[1], f.spacing[1], nv),
    z: toRows(f.values, nu, nv),
    vecU: f.vecU ? toRows(f.vecU, nu, nv) : null,
    vecV: f.vecV ? toRows(f.vecV, nu, nv) : null,
    xLabel: f.labels[0], yLabel: f.labels[1],
    position: f.position, dims: [nu, nv], resolution: kind,
  };
}

/** Instant, coarse fallback straight out of the cached preview volume. */
function fromPreview(): SlicePlot | null {
  const s = useStore.getState();
  const g = s.previewGrid;
  if (!g) return null;
  const ai = { x: 0, y: 1, z: 2 }[s.slice.axis];
  const sl = extractSlice(g, s.slice.axis, Math.min(s.slice.k, g.dims[ai] - 1));
  return {
    x: sl.x, y: sl.y, z: sl.z, vecU: null, vecV: null,
    xLabel: sl.xLabel, yLabel: sl.yLabel, position: sl.position,
    dims: [sl.x.length, sl.y.length], resolution: "preview",
  };
}

export function useSliceData(withVectors: boolean): {
  plot: SlicePlot | null; refining: boolean;
} {
  const { activeId, activeField, previewGrid, slice, drawerOpen, drawerTab,
          display } = useStore();
  const maxDim = display.sliceMaxDim;
  const hiFi = display.sliceHiFi;
  const gridDims = useStore.getState().meta?.dims ?? undefined;
  const [plot, setPlot] = useState<SlicePlot | null>(null);
  const [refining, setRefining] = useState(false);
  const abort = useRef<AbortController | null>(null);

  const live = drawerOpen && drawerTab === "contour" && slice.submode === "axis";
  const ai = { x: 0, y: 1, z: 2 }[slice.axis];
  const position = previewGrid
    ? previewGrid.origin[ai]
      + previewGrid.spacing[ai] * Math.min(slice.k, previewGrid.dims[ai] - 1)
    : 0;

  useEffect(() => {
    if (!live || !activeId || !previewGrid) { setPlot(null); return; }
    setPlot(fromPreview());               // 1. instant coarse paint
    setRefining(true);
    abort.current?.abort();
    const ctl = new AbortController();
    abort.current = ctl;
    const timer = window.setTimeout(async () => {
      try {
        // 2. refine. Below the grid ceiling the grid path is exact and fast;
        //    above it, only the scattered source can supply more detail.
        // Two reasons to leave the grid: more pixels than it holds, or the
        // user asking for smooth scatter-sampled data at any size.
        const ceiling = Math.max(...(gridDims ?? [0]));
        const direct = hiFi || (ceiling > 0 && maxDim > ceiling);
        const f = direct
          ? await getSliceFieldDirect(activeId, activeField,
              { axis: slice.axis, position, withVectors,
                res: maxDim || Math.max(...(gridDims ?? [256])),
                mode: "hifi" },
              ctl.signal)
          : await getSliceField(activeId, activeField,
              { axis: slice.axis, position, withVectors, maxDim }, ctl.signal);
        if (!ctl.signal.aborted) setPlot(fromField(f, direct ? "direct" : "full"));
      } catch { /* aborted or offline: the preview paint stands */ }
      if (!ctl.signal.aborted) setRefining(false);
    }, REFINE_DELAY_MS);
    return () => { window.clearTimeout(timer); ctl.abort(); };
  }, [live, activeId, activeField, slice.axis, slice.k, position, withVectors,
      maxDim, hiFi, previewGrid]);

  return { plot, refining };
}
