/** Velocity arrows over a 2D slice, as one Plotly line trace.
 *
 *  Plotly has no quiver primitive, so every arrow is emitted as a polyline
 *  (shaft + two head strokes) into a single trace separated by NaNs — one
 *  trace keeps the plot fast even with a few thousand arrows.
 *
 *  Arrow length uses the shared adaptive rule (arrowScale.ts): longer where
 *  the flow is fast, clamped at both ends so nothing overwhelms or disappears.
 */
import { ArrowScale, arrowLength, speedQuantile } from "../arrowScale";

export interface QuiverOptions {
  targetCount: number;   // approximate number of arrows across the slice
  scale: number;         // user length multiplier
  minFrac: number;
  maxFrac: number;
  color: string;
}

export const QUIVER_DEFAULTS: QuiverOptions = {
  targetCount: 26, scale: 1, minFrac: 0.35, maxFrac: 1.2, color: "#e8ecf2",
};

export interface QuiverTrace {
  x: (number | null)[]; y: (number | null)[]; count: number;
}

/** Stride that lands close to `target` arrows along the longer axis. */
function strideFor(nu: number, nv: number, target: number): number {
  return Math.max(1, Math.round(Math.max(nu, nv) / Math.max(4, target)));
}

export function buildQuiver(
  x: number[], y: number[],
  vecU: (number | null)[][], vecV: (number | null)[][],
  opts: QuiverOptions = QUIVER_DEFAULTS,
): QuiverTrace | null {
  const nv = y.length, nu = x.length;
  if (!nu || !nv) return null;
  const step = strideFor(nu, nv, opts.targetCount);

  // pass 1: collect sampled vectors and their speeds
  const pts: { x: number; y: number; u: number; v: number; s: number }[] = [];
  for (let iv = Math.floor(step / 2); iv < nv; iv += step) {
    for (let iu = Math.floor(step / 2); iu < nu; iu += step) {
      const u = vecU[iv]?.[iu], v = vecV[iv]?.[iu];
      if (u == null || v == null) continue;        // solid / outside
      const s = Math.hypot(u, v);
      if (!(s > 0)) continue;
      pts.push({ x: x[iu], y: y[iv], u, v, s });
    }
  }
  if (!pts.length) return null;

  const pitch = Math.max(
    Math.abs((x[nu - 1] - x[0]) / Math.max(1, nu - 1)) * step,
    Math.abs((y[nv - 1] - y[0]) / Math.max(1, nv - 1)) * step);
  const sc: ArrowScale = {
    pitch, speedMax: speedQuantile(pts.map((p) => p.s)),
    minFrac: opts.minFrac, maxFrac: opts.maxFrac, scale: opts.scale,
  };

  // pass 2: emit shaft + head as one NaN-separated polyline
  const px: (number | null)[] = [], py: (number | null)[] = [];
  const HEAD = 0.32, SPREAD = 0.42;                // head length / half-angle
  for (const p of pts) {
    const len = arrowLength(p.s, sc);
    const ux = p.u / p.s, uy = p.v / p.s;
    const x0 = p.x - ux * len / 2, y0 = p.y - uy * len / 2;
    const x1 = p.x + ux * len / 2, y1 = p.y + uy * len / 2;
    const hl = len * HEAD;
    const cos = Math.cos(SPREAD), sin = Math.sin(SPREAD);
    // head strokes: shaft direction rotated by +/- SPREAD, pointing backwards
    const bx = -ux * hl, by = -uy * hl;
    px.push(x0, x1, null);
    py.push(y0, y1, null);
    px.push(x1, x1 + bx * cos - by * sin, null);
    py.push(y1, y1 + bx * sin + by * cos, null);
    px.push(x1, x1 + bx * cos + by * sin, null);
    py.push(y1, y1 - bx * sin + by * cos, null);
  }
  return { x: px, y: py, count: pts.length };
}
