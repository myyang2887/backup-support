/** Plotly 2D slice view: heatmap + optional adaptive velocity arrows.
 *  solid = null -> transparent -> black plot background. */
import Plotly from "plotly.js-dist-min";
import { useEffect, useRef } from "react";
import { QuiverOptions, buildQuiver } from "./quiver";
import type { SlicePlot } from "./sliceSource";

export default function Contour2D(props: {
  slice: SlicePlot | null; field: string; unit: string;
  clim: [number, number]; title: string; hover?: boolean;
  quiver?: QuiverOptions | null;
  /** false = draw raw cells (useful to see the true sample grid). */
  smooth?: boolean;
  /** Paint solid cells (they are null in z) instead of letting the plot
   *  background show through. null = leave them transparent. */
  solidColor?: string | null;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current || !props.slice) return;
    const s = props.slice;
    const traces: any[] = [];
    if (props.solidColor) {
      // Solid cells are null in z, so a mask trace drawn underneath is what
      // gives explicit control over them — relying on plot_bgcolor alone
      // would also colour everything outside the data.
      const mask = s.z.map((row) => row.map((v) => (v === null ? 1 : null)));
      traces.push({
        type: "heatmap", x: s.x, y: s.y, z: mask,
        colorscale: [[0, props.solidColor], [1, props.solidColor]],
        showscale: false, hoverinfo: "skip", zsmooth: false,
      });
    }
    traces.push({
      type: "heatmap", x: s.x, y: s.y, z: s.z,
      colorscale: "Jet", zmin: props.clim[0], zmax: props.clim[1],
      // Without zsmooth every cell is drawn as a flat rectangle, so even a
      // fine slice looks like hard colour blocks with no gradient between.
      zsmooth: props.smooth === false ? false : "best",
      colorbar: { title: { text: `${props.field} [${props.unit}]`, side: "right" },
                  tickfont: { size: 10 } },
      hovertemplate: props.hover
        ? "x %{x:.5f}<br>y %{y:.5f}<br>" + props.field + " %{z:.5g}<extra></extra>"
        : undefined,
      hoverinfo: props.hover ? undefined : "skip",
    });
    if (props.quiver && s.vecU && s.vecV) {
      const q = buildQuiver(s.x, s.y, s.vecU, s.vecV, props.quiver);
      if (q) traces.push({
        type: "scatter", mode: "lines", x: q.x, y: q.y,
        line: { color: props.quiver.color, width: 1 },
        hoverinfo: "skip", showlegend: false,
      });
    }
    Plotly.react(ref.current, traces, {
      title: { text: props.title, font: { color: "#dde1e8", size: 12 } },
      xaxis: { title: { text: s.xLabel }, scaleanchor: "y", color: "#8b93a1" },
      yaxis: { title: { text: s.yLabel }, color: "#8b93a1" },
      plot_bgcolor: "rgba(0,0,0,0)", paper_bgcolor: "#1c1f26",
      font: { color: "#dde1e8", size: 11 },
      hoverlabel: { bgcolor: "#0b0d10", bordercolor: "#2e6f85",
                    font: { family: "Consolas, monospace", size: 11,
                            color: "#dde1e8" } },
      margin: { t: 34, r: 8, b: 42, l: 52 },
      autosize: true,
    }, { responsive: true, displaylogo: false });
  }, [props.slice, props.clim, props.field, props.unit, props.title,
      props.hover, props.quiver, props.smooth, props.solidColor]);
  return <div ref={ref} style={{ width: "100%", height: "100%", minHeight: 220 }} />;
}
