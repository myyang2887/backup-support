import { useToasts } from "../toast";

export default function Toasts() {
  const { toasts } = useToasts();
  return (
    <div className="toast-wrap">
      {toasts.map((t) => (
        <div key={t.id} className={`toast ${t.kind === "err" ? "err" : ""}`}>
          {t.text}
        </div>
      ))}
    </div>
  );
}
