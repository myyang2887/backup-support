/** Slim icon rail: tool switching (industrial left-dock pattern). */
import { FeatureId, isOn, useFeatures } from "../features";
import { IconBox, IconData, IconDisplay, IconGear, IconIso, IconJobs,
         IconProbe, IconSlice, IconStream } from "../icons";
import { useStore } from "../store";
import type { Tool } from "../types";

const TOOLS: { id: Tool; label: string; icon: (p: { size?: number }) => JSX.Element }[] = [
  { id: "data", label: "データ", icon: IconData },
  { id: "slice", label: "断面", icon: IconSlice },
  { id: "probe", label: "ライン", icon: IconProbe },
  { id: "stream", label: "流線", icon: IconStream },
  { id: "iso", label: "等値面", icon: IconIso },
  { id: "region", label: "領域", icon: IconBox },
  { id: "display", label: "表示", icon: IconDisplay },
  { id: "jobs", label: "ジョブ", icon: IconJobs },
];

export default function ToolRail() {
  const { activeTool, jobs, set } = useStore();
  const overrides = useFeatures((s) => s.overrides);
  const visible = TOOLS.filter(
    (t) => t.id === "data" || isOn(("tool." + t.id) as FeatureId, overrides));
  return (
    <div style={{ width: 56, background: "var(--bg-1)",
                  borderRight: "1px solid var(--line)",
                  display: "flex", flexDirection: "column", paddingTop: 6 }}>
      {visible.map((t) => {
        const on = activeTool === t.id;
        return (
          <button key={t.id} className="quiet" title={t.label}
                  onClick={() => set({ activeTool: t.id })}
                  style={{ display: "flex", flexDirection: "column",
                           alignItems: "center", gap: 3, padding: "9px 0",
                           borderRadius: 0, position: "relative",
                           color: on ? "var(--accent)" : "var(--text-dim)",
                           background: on ? "var(--bg-2)" : "transparent",
                           borderLeft: on ? "2px solid var(--accent)"
                                          : "2px solid transparent" }}>
            <t.icon size={17} />
            <span style={{ fontSize: 9 }}>{t.label}</span>
            {t.id === "jobs" && jobs.length > 0 && (
              <span className="mono" style={{ position: "absolute", top: 4,
                    right: 8, fontSize: 9, background: "var(--accent-dim)",
                    borderRadius: 8, padding: "0 4px" }}>{jobs.length}</span>
            )}
          </button>
        );
      })}
      <div style={{ flex: 1 }} />
      <button className="quiet" title="設定"
              onClick={() => set({ activeTool: "settings" })}
              style={{ display: "flex", flexDirection: "column",
                       alignItems: "center", gap: 3, padding: "9px 0",
                       borderRadius: 0, marginBottom: 4,
                       color: activeTool === "settings"
                         ? "var(--accent)" : "var(--text-faint)",
                       background: activeTool === "settings"
                         ? "var(--bg-2)" : "transparent",
                       borderLeft: activeTool === "settings"
                         ? "2px solid var(--accent)" : "2px solid transparent" }}>
        <IconGear size={17} />
        <span style={{ fontSize: 9 }}>設定</span>
      </button>
    </div>
  );
}
