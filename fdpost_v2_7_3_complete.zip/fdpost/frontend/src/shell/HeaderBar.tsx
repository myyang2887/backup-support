/** Top bar: brand, dataset + field selectors, view toggles, sessions, share. */
import { useEffect, useRef, useState } from "react";
import { activateDataset, applyState, captureState, refreshField } from "../actions";
import { createSnapshot, deleteSession, getSession, listSessions,
         saveSession } from "../api";
import { Feature } from "../features";
import { IconCursor, IconDrawer, IconSave, IconShare } from "../icons";
import { useStore } from "../store";
import { toast } from "../toast";
import type { SessionRow } from "../types";

export default function HeaderBar() {
  const { drawerOpen } = useStore();
  const { datasets, activeId, meta, activeField, cursorReadout, vizMode,
          sharedBanner, set } = useStore();
  const [menu, setMenu] = useState(false);
  const [sessions, setSessions] = useState<SessionRow[]>([]);
  const [nameDraft, setNameDraft] = useState("");
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menu) return;
    listSessions().then(setSessions).catch(() => {});
    const close = (e: MouseEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) setMenu(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, [menu]);

  const doSave = async () => {
    if (!activeId || !nameDraft.trim()) return;
    await saveSession(nameDraft.trim(), activeId, captureState());
    const saved = nameDraft.trim();
    setNameDraft("");
    setSessions(await listSessions());
    toast(`セッション「${saved}」を保存しました`);
  };

  const doLoad = async (row: SessionRow) => {
    setMenu(false);
    try {
      const full = await getSession(row.id);
      await applyState(full.dataset_id, full.state);
      toast(`セッション「${row.name}」を復元しました`);
    } catch (e: any) { toast(`復元に失敗: ${e.message}`, "err"); }
  };

  const doShare = async () => {
    if (!activeId) return;
    try {
      const { token } = await createSnapshot(activeId, captureState());
      const url = `${location.origin}${location.pathname}#s=${token}`;
      await navigator.clipboard.writeText(url);
      toast("共有リンクをコピーしました");
    } catch (e: any) { toast(`共有に失敗: ${e.message}`, "err"); }
  };

  const ready = datasets.filter((d) => d.status === "ready");
  const baseName = (p: string) => p.split(/[\\/]/).pop() ?? p;

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10,
                  padding: "0 12px", height: 44, background: "var(--bg-1)",
                  borderBottom: "1px solid var(--line)" }}>
      <span style={{ fontWeight: 700, letterSpacing: ".02em" }}>FDPost</span>
      <span className="mono" style={{ fontSize: 10, color: "var(--text-faint)" }}>
        v2.1</span>
      {sharedBanner && (
        <span style={{ fontSize: 11, background: "var(--accent-dim)",
                       padding: "2px 8px", borderRadius: 10 }}>
          {sharedBanner}</span>
      )}
      <select value={activeId ?? ""} style={{ minWidth: 180 }}
              onChange={(e) => e.target.value &&
                activateDataset(e.target.value)
                  .catch((err) => toast(err.message, "err"))}>
        <option value="" disabled>データセットを選択…</option>
        {ready.map((d) => (
          <option key={d.id} value={d.id}>{baseName(d.source_path)}</option>
        ))}
      </select>
      {meta && (
        <select value={activeField}
                onChange={(e) => refreshField(e.target.value)
                  .catch((err) => toast(err.message, "err"))}>
          {meta.fields.map((f) => <option key={f}>{f}</option>)}
        </select>
      )}
      <div style={{ flex: 1 }} />
      <Feature id="shell.drawer">
        <button className={drawerOpen ? "primary" : ""}
                title="結果ドロワー(断面プレビュー / 斜め断面 / ライン結果)"
                disabled={!meta}
                onClick={() => set({ drawerOpen: !drawerOpen })}>
          <IconDrawer size={14} /> 結果
        </button>
      </Feature>
      <Feature id="viewport.cursorHud">
        <button className={cursorReadout ? "primary" : ""}
                title="カーソル座標の読み取り表示"
                style={{ display: "inline-flex", gap: 6, alignItems: "center" }}
                onClick={() => set({ cursorReadout: !cursorReadout })}>
          <IconCursor size={14} /> 座標
        </button>
      </Feature>
      <Feature id="viewport.modeSwitch">
        <select value={vizMode} title="3D表示モード"
                onChange={(e) => set({ vizMode: e.target.value as any })}>
          <option value="guide">ポイントクラウド</option>
          <option value="full3d">完全3D</option>
        </select>
      </Feature>
      <Feature id="persist.sessions">
      <div style={{ position: "relative" }} ref={menuRef}>
        <button onClick={() => setMenu(!menu)} disabled={!activeId}
                style={{ display: "inline-flex", gap: 6, alignItems: "center" }}>
          <IconSave size={14} /> セッション
        </button>
        {menu && (
          <div className="menu">
            <div className="row" style={{ marginBottom: 8 }}>
              <input placeholder="セッション名" value={nameDraft}
                     style={{ flex: 1 }}
                     onChange={(e) => setNameDraft(e.target.value)}
                     onKeyDown={(e) => e.key === "Enter" && doSave()} />
              <button className="primary" onClick={doSave}
                      disabled={!nameDraft.trim()}>保存</button>
            </div>
            {sessions.length === 0 && (
              <div className="hint" style={{ padding: "4px 8px" }}>
                保存されたセッションはまだありません</div>
            )}
            {sessions.map((s) => (
              <div key={s.id} className="menu-item" onClick={() => doLoad(s)}>
                <span style={{ overflow: "hidden", textOverflow: "ellipsis" }}>
                  {s.name}</span>
                <span className="row" style={{ gap: 4, flexShrink: 0 }}>
                  <span className="mono" style={{ fontSize: 10,
                        color: "var(--text-faint)" }}>
                    {s.updated_at.slice(5, 16).replace("T", " ")}</span>
                  <button className="quiet" style={{ padding: "0 4px" }}
                          onClick={async (e) => {
                            e.stopPropagation();
                            await deleteSession(s.id);
                            setSessions(await listSessions());
                          }}>✕</button>
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
      </Feature>
      <Feature id="persist.share">
        <button onClick={doShare} disabled={!activeId}
                style={{ display: "inline-flex", gap: 6, alignItems: "center" }}>
          <IconShare size={14} /> 共有
        </button>
      </Feature>
    </div>
  );
}
