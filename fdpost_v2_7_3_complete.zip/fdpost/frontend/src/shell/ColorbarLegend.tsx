/** On-viewport colorbar (jet), mono min/mid/max labels. */
import { jet } from "../colormap";
import { useFeature } from "../features";
import { useStore } from "../store";

export default function ColorbarLegend() {
  const { meta, activeField, clim } = useStore();
  const on = useFeature("viewport.colorbar");
  if (!on || !meta) return null;
  const stops = [0, 0.25, 0.5, 0.75, 1].map((t) => {
    const [r, g, b] = jet(t);
    return `rgb(${r * 255 | 0},${g * 255 | 0},${b * 255 | 0}) ${t * 100}%`;
  }).join(", ");
  const unit = meta.units?.[activeField] ?? "";
  const fmt = (v: number) => Math.abs(v) >= 1e4 || (Math.abs(v) < 1e-3 && v !== 0)
    ? v.toExponential(2) : v.toPrecision(4);
  return (
    <div style={{ position: "absolute", right: 14, top: "50%",
                  transform: "translateY(-50%)", display: "flex", gap: 7,
                  alignItems: "stretch", pointerEvents: "none" }}>
      <div className="mono" style={{ display: "flex", flexDirection: "column",
                    justifyContent: "space-between", fontSize: 10,
                    color: "var(--text-dim)", textAlign: "right" }}>
        <span>{fmt(clim[1])}</span>
        <span>{fmt((clim[0] + clim[1]) / 2)}</span>
        <span>{fmt(clim[0])}</span>
      </div>
      <div style={{ width: 12, height: 170, borderRadius: 3,
                    border: "1px solid var(--line-strong)",
                    background: `linear-gradient(to top, ${stops})` }} />
      <div className="mono" style={{ writingMode: "vertical-rl", fontSize: 10,
                    color: "var(--text-dim)" }}>
        {activeField}{unit ? ` [${unit}]` : ""}
      </div>
    </div>
  );
}
