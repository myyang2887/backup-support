/** Application shell: header / tool rail / properties / viewport / drawer /
 *  status bar. Hash #s=TOKEN opens a shared read-only snapshot. */
import { useEffect } from "react";
import { applyState } from "./actions";
import { refreshDatasets } from "./actions";
import { getSnapshot } from "./api";
import DatasetPanel from "./panels/DatasetPanel";
import DisplayPanel from "./panels/DisplayPanel";
import IsoPanel from "./panels/IsoPanel";
import JobsPanel from "./panels/JobsPanel";
import ProbePanel from "./panels/ProbePanel";
import RegionPanel from "./panels/RegionPanel";
import SettingsPanel from "./panels/SettingsPanel";
import SlicePanel from "./panels/SlicePanel";
import StreamPanel from "./panels/StreamPanel";
import { FeatureId, isOn, useFeatures } from "./features";
import BottomDrawer from "./shell/BottomDrawer";
import ColorbarLegend from "./shell/ColorbarLegend";
import HeaderBar from "./shell/HeaderBar";
import StatusBar from "./shell/StatusBar";
import Toasts from "./shell/Toasts";
import ToolRail from "./shell/ToolRail";
import { useStore } from "./store";
import { toast } from "./toast";
import Viewer3D from "./viz3d/Viewer3D";

const PANELS: Record<string, () => JSX.Element> = {
  data: DatasetPanel, slice: SlicePanel, probe: ProbePanel,
  stream: StreamPanel, iso: IsoPanel, region: RegionPanel,
  display: DisplayPanel, jobs: JobsPanel, settings: SettingsPanel,
};

export default function App() {
  const { activeTool, set } = useStore();
  const overrides = useFeatures((s) => s.overrides);
  const Panel = PANELS[activeTool] ?? DatasetPanel;

  // if the active tool gets switched off, fall back to the data tool
  useEffect(() => {
    if (activeTool !== "data" && activeTool !== "settings"
        && !isOn(("tool." + activeTool) as FeatureId, overrides)) {
      set({ activeTool: "data" });
    }
  }, [overrides, activeTool]);

  useEffect(() => {
    refreshDatasets().catch(() => {});
    const m = location.hash.match(/^#s=([0-9a-f]+)$/);
    if (m) {
      (async () => {
        try {
          const snap = await getSnapshot(m[1]);
          await applyState(snap.dataset_id, snap.state);
          set({ sharedBanner: "共有ビュー" });
          toast("共有されたビューを開きました");
        } catch (e: any) {
          toast(`共有ビューを開けませんでした: ${e.message}`, "err");
        }
      })();
    }
  }, []);

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <HeaderBar />
      <div style={{ flex: 1, display: "flex", minHeight: 0 }}>
        <ToolRail />
        <div style={{ width: 312, flexShrink: 0, overflowY: "auto",
                      padding: 10, background: "var(--bg-0)",
                      borderRight: "1px solid var(--line)" }}>
          <Panel />
        </div>
        <div style={{ flex: 1, display: "flex", flexDirection: "column",
                      minWidth: 0 }}>
          <div style={{ flex: 1, position: "relative", minHeight: 120,
                        background: "var(--bg-viewport)" }}>
            <Viewer3D />
            <ColorbarLegend />
          </div>
          <BottomDrawer />
        </div>
      </div>
      <StatusBar />
      <Toasts />
    </div>
  );
}
