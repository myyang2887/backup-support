/** Minimal inline icon set (stroke style, 16px). */
const P = { fill: "none", stroke: "currentColor", strokeWidth: 1.5,
            strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
const I = (d: React.ReactNode) => (props: { size?: number }) => (
  <svg width={props.size ?? 16} height={props.size ?? 16} viewBox="0 0 16 16" {...P}>{d}</svg>
);
export const IconData = I(<><ellipse cx="8" cy="3.5" rx="5.5" ry="2"/><path d="M2.5 3.5v9c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2v-9"/><path d="M2.5 8c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2"/></>);
export const IconSlice = I(<><rect x="2" y="2" width="12" height="12" rx="1"/><path d="M2 11 14 5" stroke="currentColor"/></>);
export const IconProbe = I(<><circle cx="3.5" cy="12.5" r="1.6"/><circle cx="12.5" cy="3.5" r="1.6"/><path d="M5 11 11 5"/></>);
export const IconStream = I(<><path d="M2 4.5c3 0 4-2 7-2s3.5 2 5 2"/><path d="M2 8c3 0 4-2 7-2s3.5 2 5 2"/><path d="M2 11.5c3 0 4-2 7-2s3.5 2 5 2"/></>);
export const IconIso = I(<><circle cx="8" cy="8" r="5.5"/><ellipse cx="8" cy="8" rx="5.5" ry="2.2"/></>);
export const IconBox = I(<><path d="M2.5 5 8 2l5.5 3v6L8 14l-5.5-3z"/><path d="M2.5 5 8 8l5.5-3M8 8v6"/></>);
export const IconJobs = I(<><path d="M3 4.5h10M3 8h10M3 11.5h6"/></>);
export const IconCursor = I(<><path d="M8 2v3M8 11v3M2 8h3M11 8h3"/><circle cx="8" cy="8" r="1.4"/></>);
export const IconSave = I(<><path d="M3 2.5h8L13 4.5v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-10a1 1 0 0 1 1-1z" strokeWidth="1.3"/><path d="M5 2.5V6h5V2.5M5.5 14v-4h5v4"/></>);
export const IconShare = I(<><circle cx="12" cy="3.5" r="1.8"/><circle cx="4" cy="8" r="1.8"/><circle cx="12" cy="12.5" r="1.8"/><path d="m5.7 7.2 4.6-2.8M5.7 8.8l4.6 2.8"/></>);
export const IconUpload = I(<><path d="M8 10.5v-8M5 5l3-2.8L11 5"/><path d="M2.5 10.5v2a1 1 0 0 0 1 1h9a1 1 0 0 0 1-1v-2"/></>);
export const IconDown = I(<path d="M8 3v8M5 8.5 8 11.5l3-3M3 13.5h10"/>);
export const IconClose = I(<path d="m4 4 8 8M12 4l-8 8"/>);
export const IconDisplay = I(<><circle cx="8" cy="8" r="2"/><path d="M1.5 8s2.4-4.2 6.5-4.2S14.5 8 14.5 8s-2.4 4.2-6.5 4.2S1.5 8 1.5 8z"/></>);
export const IconDrawer = I(<><rect x="1.5" y="2.5" width="13" height="11" rx="1.5"/><path d="M1.5 9.5h13"/></>);
export const IconGear = I(<><circle cx="8" cy="8" r="2.2"/><path d="M8 1.8v2M8 12.2v2M1.8 8h2M12.2 8h2M3.6 3.6l1.4 1.4M11 11l1.4 1.4M12.4 3.6 11 5M5 11l-1.4 1.4"/></>);
