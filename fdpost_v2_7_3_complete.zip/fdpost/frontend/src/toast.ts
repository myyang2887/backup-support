import { create } from "zustand";

interface Toast { id: number; text: string; kind: "info" | "err"; }
interface TS { toasts: Toast[]; push: (text: string, kind?: "info" | "err") => void;
               drop: (id: number) => void; }
let seq = 0;
export const useToasts = create<TS>((set) => ({
  toasts: [],
  push: (text, kind = "info") => {
    const id = ++seq;
    set((s) => ({ toasts: [...s.toasts, { id, text, kind }] }));
    setTimeout(() => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
               4200);
  },
  drop: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
}));
export const toast = (text: string, kind: "info" | "err" = "info") =>
  useToasts.getState().push(text, kind);
