/**
 * Regression guard for slice-plane orientation in the 3D view.
 *
 * The X-normal plane once rendered rotated 90 degrees because the code
 * oriented it with `setFromUnitVectors(+Z, normal)`. That gives the
 * shortest-arc rotation: it pins where +Z goes but not where the in-plane
 * axes land, so the two extents ended up on the wrong world axes.
 *
 * This imports the REAL gizmos.ts (transpiled on the fly with esbuild, which
 * ships with vite) so the check cannot drift from the shipped code.
 *
 *   node scripts/check-gizmo-orientation.mjs        # or: npm run check:gizmo
 */
import { execFileSync } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import * as THREE from "three";

// build inside the project so the bundle's `three` import resolves normally
const out = "node_modules/.cache/gizmo-check";
mkdirSync(out, { recursive: true });
const js = join(process.cwd(), out, "gizmos.mjs");
execFileSync("node_modules/.bin/esbuild", [
  "src/viz3d/gizmos.ts", "--bundle", "--format=esm", "--platform=neutral",
  "--external:three", `--outfile=${js}`,
]);
writeFileSync(join(out, "package.json"), '{"type":"module"}');
const { orientPlane, planeBasis } = await import(js);

const NAME = ["X", "Y", "Z"];
const IN_PLANE = { 0: [1, 2], 1: [0, 2], 2: [0, 1] };
const EXT = [0.30, 0.10, 0.05];        // unequal, so a swap is unmissable
let failed = 0;

const spanOf = (mesh) => {
  mesh.updateMatrixWorld(true);
  const box = new THREE.Box3();
  for (const c of [[-.5, -.5, 0], [.5, -.5, 0], [-.5, .5, 0], [.5, .5, 0]]) {
    box.expandByPoint(new THREE.Vector3(...c).applyMatrix4(mesh.matrixWorld));
  }
  const s = box.getSize(new THREE.Vector3());
  return [s.x, s.y, s.z];
};

console.log("axis-orthogonal slice planes:");
for (const [axis, ia] of [["x", 0], ["y", 1], ["z", 2]]) {
  const [i0, i1] = IN_PLANE[ia];
  const u = new THREE.Vector3(); u.setComponent(i0, 1);
  const v = new THREE.Vector3(); v.setComponent(i1, 1);
  const mesh = new THREE.Object3D();
  orientPlane(mesh, new THREE.Vector3(), u, v, EXT[i0], EXT[i1]);

  const got = spanOf(mesh);
  const want = [0, 0, 0]; want[i0] = EXT[i0]; want[i1] = EXT[i1];
  const spanOk = got.every((g, i) => Math.abs(g - want[i]) < 1e-9);
  // a mirrored basis is not a rotation and must never be produced
  const det = new THREE.Matrix4()
    .makeRotationFromQuaternion(mesh.quaternion).determinant();
  const detOk = Math.abs(det - 1) < 1e-9;

  if (!spanOk || !detOk) failed++;
  console.log(`  ${axis}: spans ${JSON.stringify(got.map((x) => +x.toFixed(4)))}`
    + ` expected ${JSON.stringify(want.map((x) => +x.toFixed(4)))}`
    + ` det ${det.toFixed(3)}  ${spanOk && detOk ? "OK" : "FAIL"}`);
}

console.log("free-plane basis (must match the backend's _plane_basis):");
for (const n of [[0, 0, 1], [1, 0, 0], [0.3, -0.5, 0.81]]) {
  const nn = new THREE.Vector3(...n).normalize();
  const [u, v] = planeBasis(nn);
  // right-handed and orthonormal: u x v == n
  const cross = u.clone().cross(v);
  const ok = cross.distanceTo(nn) < 1e-6
    && Math.abs(u.dot(v)) < 1e-9 && Math.abs(u.length() - 1) < 1e-9;
  if (!ok) failed++;
  console.log(`  n=${JSON.stringify(n)}  u x v == n: ${ok ? "OK" : "FAIL"}`);
}

if (failed) { console.error(`\n${failed} check(s) FAILED`); process.exit(1); }
console.log("\nall orientation checks passed");
