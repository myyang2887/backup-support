"""PyInstaller entry point: freeze this file.
pyinstaller packaging/entry.py --name fdpost --onedir --add-data "frontend/dist:frontend/dist"
"""
from fdpost.cli.main import app

if __name__ == "__main__":
    app()
