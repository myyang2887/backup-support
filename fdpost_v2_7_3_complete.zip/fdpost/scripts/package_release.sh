#!/usr/bin/env bash
# Build a distributable archive of the project.
#
# Excludes runtime state (data/ cache/ output/) and dependency trees, but
# KEEPS frontend/dist — the built UI is what `pip install` ships and what the
# server serves, so an archive without it is not runnable.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "building frontend..."
( cd frontend && npm ci --silent && npm run build )

out="${1:-../fdpost_release.zip}"
rm -f "$out"
zip -qr "$out" . \
  -x '*/node_modules/*' 'data/*' 'cache/*' 'output/*' \
     '*/__pycache__/*' '*.pyc' '.pytest_cache/*' '*.egg-info/*' \
     '.git/*' 'node_modules/.cache/*'
echo "wrote $out ($(du -h "$out" | cut -f1))"
