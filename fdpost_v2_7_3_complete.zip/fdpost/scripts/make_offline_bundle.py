#!/usr/bin/env python
"""Build a self-contained folder that installs fdpost on a machine with no
network access.

The idea: do all the downloading here, where the network works, and hand the
target machine one folder it can install from with `--no-index`.

    python scripts/make_offline_bundle.py                 # for THIS platform
    python scripts/make_offline_bundle.py --platform win_amd64 --python 3.12

    python scripts/make_offline_bundle.py --linux --python 3.12    # for a Linux server

Platform matters. Wheels for numpy/scipy/pandas/matplotlib/scikit-image are
compiled, so a Linux wheel will not install on Windows. By default this
targets the machine you are running on; --linux / --windows / --platform
cross-build (which also forces --only-binary, since a source archive cannot
be built offline).

The bundle contains no Python interpreter. The target still needs Python
installed; only the packages travel. If the server has no Python at all, use
PyInstaller instead (see packaging/entry.py).
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _preflight() -> str | None:
    """`build` and `pip` must live in the interpreter running this script.

    uv creates virtual environments without either one — `uv venv` omits pip
    by design — so the failure lands deep inside step 2 or 3 with a bare
    "No module named build". Check up front and say exactly what to run.
    """
    import importlib.util

    missing = [m for m in ("build", "pip") if importlib.util.find_spec(m) is None]
    if not missing:
        return None
    names = " ".join(missing)
    return (f"missing module(s) in this interpreter: {names}\n"
            f"  interpreter: {sys.executable}\n\n"
            f"  uv:  uv pip install {names}\n"
            f"  pip: {sys.executable} -m pip install {names}\n\n"
            "  (uv virtual environments ship without pip unless created with\n"
            "   `uv venv --seed`, so both are usually needed here.)")


def run(cmd: list[str], **kw) -> None:
    print("  $", " ".join(str(c) for c in cmd))
    subprocess.run(cmd, check=True, **kw)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default=str(ROOT.parent / "fdpost_offline"),
                    help="bundle directory to create")
    ap.add_argument("--platform", default=None,
                    help="target platform tag, e.g. win_amd64 / "
                         "manylinux2014_x86_64 (default: this machine)")
    ap.add_argument("--python", default=None,
                    help="target python version, e.g. 3.12 (with --platform)")
    ap.add_argument("--linux", action="store_true",
                    help="shorthand for --platform manylinux_2_17_x86_64")
    ap.add_argument("--windows", action="store_true",
                    help="shorthand for --platform win_amd64")
    ap.add_argument("--skip-frontend", action="store_true",
                    help="reuse the existing frontend/dist")
    args = ap.parse_args()
    if args.linux:
        args.platform = "manylinux_2_17_x86_64"
    if args.windows:
        args.platform = "win_amd64"

    problem = _preflight()
    if problem:
        print(problem)
        return 2

    out = Path(args.out).resolve()
    wheels = out / "wheels"
    if out.exists():
        shutil.rmtree(out)
    wheels.mkdir(parents=True)

    # 1. the UI must be built before the wheel, because the wheel embeds it
    if not args.skip_frontend:
        print("[1/4] building frontend")
        npm = shutil.which("npm")
        if npm is None:
            print("  npm not found — pass --skip-frontend to reuse frontend/dist")
            return 2
        run([npm, "install", "--no-audit", "--no-fund"], cwd=ROOT / "frontend")
        run([npm, "run", "build"], cwd=ROOT / "frontend")
    elif not (ROOT / "frontend/dist/index.html").is_file():
        print("  frontend/dist is missing; build it or drop --skip-frontend")
        return 2

    print("[2/4] building the fdpost wheel")
    run([sys.executable, "-m", "build", "--wheel", "-o", str(wheels)], cwd=ROOT)

    print("[3/4] downloading dependencies")
    # Resolve from the freshly built wheel, not from the source directory.
    # `pip download --platform` cannot resolve a local project: it would have
    # to build metadata, which --only-binary forbids.
    built = sorted(wheels.glob("fdpost-*.whl"))[-1]
    cmd = [sys.executable, "-m", "pip", "download",
           "--dest", str(wheels), str(built)]
    if args.platform:
        # cross-building: only binary wheels can be used without a compiler
        cmd += ["--platform", args.platform, "--only-binary=:all:"]
        if args.python:
            cmd += ["--python-version", args.python]
    run(cmd)

    print("[4/4] writing install scripts")
    _write_scripts(out)
    n = len(list(wheels.glob("*")))
    size = sum(p.stat().st_size for p in wheels.glob("*")) / (1 << 20)
    print(f"\ndone: {out}\n  {n} packages, {size:.0f} MB")
    print("  copy this whole folder to the server and run install.bat / install.sh")
    return 0


def _write_scripts(out: Path) -> None:
    def bat(name: str, body: str) -> None:
        (out / name).write_text(body.replace("\n", "\r\n"), encoding="utf-8")

    # One place defines the venv folder name and the port; every script
    # sources the same two lines, so renaming either is a one-line change.
    common = ("setlocal\n"
              "set VENV=venv\n"
              "set PORT=8000\n"
              "set FDPOST_OUTPUT_DIR=%~dp0output\n"
              "set FDPOST_DATA_DIR=%~dp0data\n"
              "set FDPOST_CACHE_DIR=%~dp0cache\n")

    bat("install.bat",
        "@echo off\n"
        "REM Installs fdpost from the bundled wheels. No network needed.\n"
        + common +
        "REM Which python will build the venv? Say so, then check that the\n"
        "REM bundled wheels were built for it -- otherwise pip fails with a\n"
        "REM message that never mentions the version mismatch.\n"
        'python -c "import sys;print(\'using python\', sys.version.split()[0], '
        "sys.executable)\" || (echo python not found on PATH. & pause & exit /b 1)\n"
        "for /f \"delims=\" %%v in ('python -c \"import sys;"
        "print(f'cp{sys.version_info.major}{sys.version_info.minor}')\"') "
        "do set PYTAG=%%v\n"
        'dir /b "%~dp0wheels\\numpy-*.whl" 2>nul | findstr /i "%PYTAG%" >nul || (\n'
        "  echo.\n"
        "  echo *** The bundled wheels do not match this Python ***\n"
        "  echo   this python is %PYTAG%, but the wheels are:\n"
        '  dir /b "%~dp0wheels\\numpy-*.whl"\n'
        "  echo   Use a matching Python, or rebuild the bundle with\n"
        "  echo     make_offline_bundle.py --platform win_amd64 --python X.Y\n"
        "  pause\n"
        "  exit /b 1\n"
        ")\n"
        'if not exist "%~dp0%VENV%" python -m venv "%~dp0%VENV%"\n'
        'call "%~dp0%VENV%\\Scripts\\activate.bat"\n'
        'python -m pip install --no-index --find-links "%~dp0wheels" '
        "--upgrade pip 1>nul 2>nul\n"
        'python -m pip install --no-index --find-links "%~dp0wheels" '
        "--force-reinstall fdpost\n"
        "if errorlevel 1 (echo INSTALL FAILED & pause & exit /b 1)\n"
        "echo.\n"
        "echo Installed. Run it with run.bat, or install_service.bat to keep\n"
        "echo it running after you log out.\n"
        "pause\n")

    bat("run.bat",
        "@echo off\n"
        "REM Foreground run: stops when this window closes or you log out.\n"
        "REM For a server that must stay up, use install_service.bat instead.\n"
        + common +
        'call "%~dp0%VENV%\\Scripts\\activate.bat"\n'
        "fdpost serve --host 0.0.0.0 --port %PORT%\n"
        "pause\n")

    # --- keeping it up -----------------------------------------------------
    bat("run_service.bat",
        "@echo off\n"
        "REM Started by Task Scheduler. No pause (nothing would answer it)\n"
        "REM and no console output (there is no console), so everything is\n"
        "REM logged to logs\\fdpost.log. The loop restarts the server if it\n"
        "REM ever exits, which Task Scheduler alone will not do.\n"
        + common +
        'if not exist "%~dp0logs" mkdir "%~dp0logs"\n'
        'call "%~dp0%VENV%\\Scripts\\activate.bat"\n'
        ":loop\n"
        'echo [%date% %time%] starting fdpost on port %PORT% >> "%~dp0logs\\fdpost.log"\n'
        'fdpost serve --host 0.0.0.0 --port %PORT% >> "%~dp0logs\\fdpost.log" 2>&1\n'
        'echo [%date% %time%] exited, restarting in 10s >> "%~dp0logs\\fdpost.log"\n'
        "timeout /t 10 /nobreak > nul\n"
        "goto loop\n")

    bat("install_service.bat",
        "@echo off\n"
        "REM Registers a scheduled task that starts fdpost at boot and keeps\n"
        "REM running after you log out of Remote Desktop.\n"
        "REM Runs as SYSTEM so no password has to be stored.\n"
        "REM Right-click this file and choose Run as administrator.\n"
        "setlocal\n"
        "set TASK=fdpost\n"
        "set PORT=8000\n"
        'net session >nul 2>&1 || (echo Run this as administrator. & pause & exit /b 1)\n'
        # single quotes inside the double-quoted /TR value: the documented
        # way to pass a path that may contain spaces to schtasks
        "schtasks /Create /TN %TASK% /TR \"'%~dp0run_service.bat'\" "
        "/SC ONSTART /RU SYSTEM /RL HIGHEST /F\n"
        "if errorlevel 1 (echo FAILED to register the task & pause & exit /b 1)\n"
        "schtasks /Run /TN %TASK%\n"
        "echo.\n"
        "echo Registered and started. It will come back after a reboot.\n"
        "echo   log     : %~dp0logs\\fdpost.log\n"
        "echo   stop    : schtasks /End /TN %TASK%\n"
        "echo   restart : schtasks /Run /TN %TASK%\n"
        "echo   remove  : uninstall_service.bat\n"
        "echo.\n"
        "echo If other machines cannot reach port %PORT%, run\n"
        "echo firewall_open.bat. Nothing here changes the firewall.\n"
        "pause\n")

    bat("uninstall_service.bat",
        "@echo off\n"
        "setlocal\n"
        "set TASK=fdpost\n"
        "set PORT=8000\n"
        'net session >nul 2>&1 || (echo Run this as administrator. & pause & exit /b 1)\n'
        "schtasks /End /TN %TASK% 2>nul\n"
        "schtasks /Delete /TN %TASK% /F\n"
        "echo Stopped and unregistered.\n"
        "echo (Any firewall rule stays; remove it with firewall_close.bat.)\n"
        "pause\n")

    # --- firewall: opt-in, separate, reversible -----------------------------
    bat("firewall_open.bat",
        "@echo off\n"
        "REM Optional. Opens the port so OTHER machines can reach the server.\n"
        "REM Not needed if your network already allows it -- try connecting\n"
        "REM first, and only run this if it fails.\n"
        "REM Right-click, Run as administrator. Undo with firewall_close.bat.\n"
        "setlocal\n"
        "set PORT=8000\n"
        'net session >nul 2>&1 || (echo Run this as administrator. & pause & exit /b 1)\n'
        'netsh advfirewall firewall show rule name="fdpost %PORT%" >nul 2>&1 && (\n'
        "  echo A rule for port %PORT% already exists. Nothing to do.\n"
        "  pause & exit /b 0\n"
        ")\n"
        'netsh advfirewall firewall add rule name="fdpost %PORT%" '
        "dir=in action=allow protocol=TCP localport=%PORT%\n"
        "if errorlevel 1 (echo FAILED & pause & exit /b 1)\n"
        "echo Port %PORT% opened for inbound TCP.\n"
        "pause\n")

    bat("firewall_close.bat",
        "@echo off\n"
        "REM Removes only the rule firewall_open.bat created.\n"
        "setlocal\n"
        "set PORT=8000\n"
        'net session >nul 2>&1 || (echo Run this as administrator. & pause & exit /b 1)\n'
        'netsh advfirewall firewall delete rule name="fdpost %PORT%"\n'
        "echo Rule removed.\n"
        "pause\n")

    # --- updating ----------------------------------------------------------
    bat("update.bat",
        "@echo off\n"
        "REM Applies a new fdpost wheel dropped into wheels\\.\n"
        "REM Stops the service first if one is registered, then restarts it.\n"
        "REM data, cache and output are outside the venv and are not touched.\n"
        + common +
        "set TASK=fdpost\n"
        'schtasks /Query /TN "%TASK%" >nul 2>&1 && (\n'
        "  echo Stopping the service...\n"
        '  schtasks /End /TN "%TASK%" >nul 2>&1\n'
        "  timeout /t 3 /nobreak > nul\n"
        ")\n"
        'call "%~dp0%VENV%\\Scripts\\activate.bat"\n'
        'python -m pip install --no-index --find-links "%~dp0wheels" '
        "--force-reinstall fdpost\n"
        "if errorlevel 1 (echo UPDATE FAILED & pause & exit /b 1)\n"
        "python -c \"from fdpost.api.app import __version__ as v; "
        "print('now running fdpost', v)\"\n"
        'schtasks /Query /TN "%TASK%" >nul 2>&1 && schtasks /Run /TN "%TASK%"\n'
        "echo.\n"
        "echo Done. Reload the browser with Ctrl+Shift+R and check the\n"
        "echo version stamp at the bottom right of the page.\n"
        "pause\n")

    # --- unattended operation ------------------------------------------
    (out / "install.sh").write_text(
        "#!/usr/bin/env bash\n"
        "# Installs fdpost from the bundled wheels. No network needed.\n"
        "set -euo pipefail\n"
        'cd "$(dirname "$0")"\n'
        '[ -d venv ] || python3 -m venv venv\n'
        './venv/bin/python -m pip install --no-index --find-links ./wheels '
        '--upgrade pip >/dev/null 2>&1 || true\n'
        './venv/bin/python -m pip install --no-index --find-links ./wheels '
        '--force-reinstall fdpost\n'
        'echo "Installed. Start it with ./run.sh"\n', encoding="utf-8")

    (out / "run.sh").write_text(
        "#!/usr/bin/env bash\n"
        "set -euo pipefail\n"
        'cd "$(dirname "$0")"\n'
        'export FDPOST_OUTPUT_DIR="$PWD/output"\n'
        'export FDPOST_DATA_DIR="$PWD/data"\n'
        'export FDPOST_CACHE_DIR="$PWD/cache"\n'
        './venv/bin/fdpost serve --host 0.0.0.0 --port 8000\n', encoding="utf-8")
    (out / "fdpost.service").write_text(
        "# Linux equivalent of the Windows scheduled task.\n"
        "#   sudo cp fdpost.service /etc/systemd/system/\n"
        "#   sudo systemctl enable --now fdpost\n"
        "[Unit]\n"
        "Description=fdpost CFD post-processing server\n"
        "After=network.target\n\n"
        "[Service]\n"
        "Type=simple\n"
        "WorkingDirectory=/opt/fdpost_offline\n"
        "Environment=FDPOST_DATA_DIR=/opt/fdpost_offline/data\n"
        "Environment=FDPOST_CACHE_DIR=/opt/fdpost_offline/cache\n"
        "Environment=FDPOST_OUTPUT_DIR=/opt/fdpost_offline/output\n"
        "ExecStart=/opt/fdpost_offline/venv/bin/fdpost serve "
        "--host 0.0.0.0 --port 8000\n"
        "Restart=on-failure\n"
        "RestartSec=10\n\n"
        "[Install]\n"
        "WantedBy=multi-user.target\n", encoding="utf-8")
    for f in ("install.sh", "run.sh"):
        (out / f).chmod(0o755)

    (out / "README.txt").write_text(
        "fdpost offline bundle\n"
        "=====================\n\n"
        "The target machine needs Python installed (3.11+). Everything else\n"
        "is in wheels/ — no network access is required.\n\n"
        "Windows:\n"
        "  1. copy this whole folder to the server\n"
        "  2. double-click install.bat   (creates venv\\ and installs)\n"
        "  3a. run.bat              -- foreground; stops when you log out\n"
        "  3b. install_service.bat  -- runs at boot, survives logout\n"
        "      firewall_open.bat    -- ONLY if other machines cannot connect\n"
        "      firewall_close.bat   -- undoes it\n"
        "      (right-click, Run as administrator)\n"
        "      uninstall_service.bat to remove it\n"
        "      log: logs\\fdpost.log\n\n"
        "Updating:\n"
        "  1. copy the new fdpost-*.whl into wheels\\ (delete the old one)\n"
        "  2. double-click update.bat\n"
        "  3. in the browser press Ctrl+Shift+R\n"
        "  Your data, cache and output are untouched.\n\n"
        "Renaming the venv or changing the port: edit the two `set` lines at\n"
        "the top of the .bat files. Do it before the first install -- an\n"
        "existing venv has absolute paths baked in and cannot be renamed.\n\n"
        "Linux / macOS:\n"
        "  1. copy this whole folder to the server\n"
        "  2. ./install.sh\n"
        "  3. ./run.sh\n\n"
        "Open http://<server-ip>:8000 from any machine on the network.\n"
        "Find the IP with `ipconfig` (Windows) or `ip addr` (Linux).\n\n"
        "Data, cache and output stay inside this folder, so the whole thing\n"
        "can be moved or deleted as one unit.\n\n"
        "NOTE: the wheels were downloaded for one platform and Python version.\n"
        "If install fails with 'no matching distribution', rebuild the bundle\n"
        "with --platform / --python matching the server.\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
