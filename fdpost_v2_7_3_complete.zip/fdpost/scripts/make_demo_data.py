"""Generate a realistic dirty-format demo TSV (60k points, solid sphere)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tests"))
from conftest import make_synthetic, write_floefd_tsv  # noqa: E402

out = Path(sys.argv[1] if len(sys.argv) > 1 else "demo_data.txt")
write_floefd_tsv(make_synthetic(), out)
print(f"wrote {out} ({out.stat().st_size/1e6:.1f} MB)")
