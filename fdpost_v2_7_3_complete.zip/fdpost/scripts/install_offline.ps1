<#
  install_offline.ps1 — install fdpost without reaching PyPI.

  Why this exists
  ---------------
  Behind a corporate proxy, `uv pip install -e .` can fail even though the
  project itself needs nothing from the network:

    * build isolation spins up a clean env and downloads `hatchling`;
    * dependency resolution re-checks every dependency against PyPI.

  Both are avoidable when the dependencies are already installed, which they
  are after any previous fdpost release (the dependency list has not changed
  since 2.3.1).

  Usage
  -----
    .\scripts\install_offline.ps1              # editable install from source
    .\scripts\install_offline.ps1 -Wheel a.whl # install a prebuilt wheel
    .\scripts\install_offline.ps1 -Check       # diagnose the proxy only
#>
param(
  [string]$Wheel = "",
  [switch]$Check
)

$ErrorActionPreference = "Stop"

function Show-ProxyDiagnosis {
  Write-Host "`n=== proxy environment ===" -ForegroundColor Cyan
  foreach ($n in @("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
                   "http_proxy", "https_proxy", "all_proxy", "no_proxy")) {
    $v = [Environment]::GetEnvironmentVariable($n)
    if ($v) { Write-Host ("  {0,-12} = [{1}]" -f $n, $v) }
  }

  # pip/uv use HTTPS_PROXY (or ALL_PROXY) for https://pypi.org — HTTP_PROXY
  # alone is not enough.
  $p = $env:HTTPS_PROXY; if (-not $p) { $p = $env:ALL_PROXY }
  if (-not $p) {
    Write-Host "`n  HTTPS_PROXY / ALL_PROXY is NOT set." -ForegroundColor Yellow
    Write-Host "  pypi.org is https, so HTTP_PROXY alone will not be used."
    return
  }

  # Square brackets above reveal stray quotes or trailing spaces, which are a
  # common cause of an unresolvable proxy host.
  try {
    $uri = [System.Uri]$p
    Write-Host ("`n  parsed -> scheme={0} host={1} port={2}" -f `
                $uri.Scheme, $uri.Host, $uri.Port)
  } catch {
    Write-Host "`n  Cannot parse as a URL. It must look like http://host:port" `
               -ForegroundColor Red
    return
  }

  Write-Host "`n=== can the proxy host be resolved? ===" -ForegroundColor Cyan
  try {
    Resolve-DnsName $uri.Host -ErrorAction Stop |
      Select-Object -First 2 Name, IPAddress | Format-Table | Out-String |
      Write-Host
  } catch {
    Write-Host "  DNS FAILED for '$($uri.Host)'." -ForegroundColor Red
    Write-Host "  This is the cause of: tunnel error -> dns error -> os error 11001."
    Write-Host "  The unresolvable name is the PROXY, not pypi.org."
    Write-Host "  Try the fully qualified name (proxy.example.co.jp), and check"
    Write-Host "  for stray quotes/spaces in the value printed above."
    return
  }

  Write-Host "=== can the proxy port be reached? ===" -ForegroundColor Cyan
  $t = Test-NetConnection -ComputerName $uri.Host -Port $uri.Port `
                          -WarningAction SilentlyContinue
  Write-Host ("  TCP {0}:{1} -> {2}" -f $uri.Host, $uri.Port, $t.TcpTestSucceeded)
}

Show-ProxyDiagnosis
if ($Check) { return }

Set-Location (Join-Path $PSScriptRoot "..")
$uv = (Get-Command uv -ErrorAction SilentlyContinue)
$pipCmd = if ($uv) { @("uv", "pip") } else { @("python", "-m", "pip") }

if ($Wheel) {
  Write-Host "`n=== installing wheel (no build, no resolution) ===" -ForegroundColor Cyan
  & $pipCmd[0] $pipCmd[1..($pipCmd.Length - 1)] install --no-deps --reinstall $Wheel
} else {
  # Editable installs still run the build backend, so hatchling must already
  # be present — otherwise build isolation would try to download it.
  $hasHatchling = $false
  try {
    & $pipCmd[0] $pipCmd[1..($pipCmd.Length - 1)] list 2>$null |
      Select-String -Quiet "hatchling" | Out-Null
    $hasHatchling = $?
  } catch { }

  Write-Host "`n=== editable install (no deps, no build isolation) ===" -ForegroundColor Cyan
  if (-not $hasHatchling) {
    Write-Host "  hatchling not found — an editable install cannot be built" `
               -ForegroundColor Yellow
    Write-Host "  offline. Either install hatchling once while online, or run"
    Write-Host "  this script with -Wheel <path to fdpost-*.whl> instead."
  }
  & $pipCmd[0] $pipCmd[1..($pipCmd.Length - 1)] install -e . --no-deps --no-build-isolation
}

Write-Host "`n=== verifying ===" -ForegroundColor Cyan
python -c @"
from fdpost.api.app import __version__
from fdpost.config import frontend_dist
d = frontend_dist()
print('  fdpost   :', __version__)
print('  frontend :', d)
print('  UI ready :', bool(d and (d / 'index.html').is_file()))
"@
