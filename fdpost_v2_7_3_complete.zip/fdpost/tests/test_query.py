import numpy as np
import pytest

from fdpost.core.query import (euler_to_point_normal, positions_from_range,
                               sample_box, sample_line, slice_axis, slice_plane)
from fdpost.domain.errors import GridBuildError, RegionTooLargeError
from tests.conftest import SOLID_CENTER, SOLID_R, analytic


def test_slice_axis_z(grid_idw):
    sl = slice_axis(grid_idw, "z", 0.5, "pressure")
    assert sl.values.shape == (grid_idw.dims[0], grid_idw.dims[1])
    # solid sphere cross-section is NaN
    gu, gv = np.meshgrid(sl.u, sl.v, indexing="ij")
    r = np.hypot(gu - 0.5, gv - 0.5)
    assert np.isnan(sl.values[r < SOLID_R * 0.6]).all()
    # fluid region matches analytic
    far = r > SOLID_R + 0.06
    pts = np.column_stack([gu[far], gv[far], np.full(far.sum(), 0.5)])
    want = analytic(pts)["pressure"]
    got = sl.values[far]
    ok = ~np.isnan(got)
    rmse = float(np.sqrt(np.mean((got[ok] - want[ok]) ** 2)))
    assert rmse < 0.05, rmse


def test_slice_axis_vectors(grid_idw):
    sl = slice_axis(grid_idw, "z", 0.5, "velocity_magnitude", with_vectors=True)
    assert sl.vec_u is not None and sl.vec_u.shape == sl.values.shape


def test_slice_axis_out_of_range(grid_idw):
    with pytest.raises(GridBuildError):
        slice_axis(grid_idw, "x", 5.0, "pressure")


def test_slice_plane_45deg(grid_idw):
    origin, normal = euler_to_point_normal(45.0, 45.0, 0.0, np.array([0.5, 0.5, 0.5]))
    sl = slice_plane(grid_idw, origin, normal, "pressure", resolution=(160, 160))
    assert sl.values.shape == (160, 160)
    finite = np.isfinite(sl.values)
    assert finite.mean() > 0.2                     # covers the domain
    # verify against analytic on the plane
    from fdpost.core.query import _plane_basis
    u_hat, v_hat = _plane_basis(normal)
    gu, gv = np.meshgrid(sl.u, sl.v, indexing="ij")
    pts = origin + gu[..., None] * u_hat + gv[..., None] * v_hat
    inner = np.all((pts > 0.06) & (pts < 0.94), axis=-1)
    far = np.linalg.norm(pts - SOLID_CENTER, axis=-1) > SOLID_R + 0.06
    m = inner & far & finite
    want = analytic(pts[m])["pressure"]
    rmse = float(np.sqrt(np.mean((sl.values[m] - want) ** 2)))
    assert rmse < 0.05, rmse


def test_euler_formula():
    o, n = euler_to_point_normal(0, 0, 0.2, np.zeros(3))
    assert np.allclose(n, [0, 0, 1]) and np.allclose(o, [0, 0, 0.2])
    _, n = euler_to_point_normal(90, 90, 0, np.zeros(3))
    assert np.allclose(n, [1, 0, 0], atol=1e-12)


def test_positions_from_range():
    p = positions_from_range(0.0, 1.0, 0.25)
    assert np.allclose(p, [0, 0.25, 0.5, 0.75, 1.0])


def test_sample_line(grid_idw):
    df = sample_line(grid_idw, (0.1, 0.5, 0.5), (0.9, 0.5, 0.5), 200, ["pressure"])
    assert list(df.columns) == ["distance_m", "x_m", "y_m", "z_m", "pressure", "is_solid"]
    assert len(df) == 200
    mid = df.iloc[95:105]
    assert (mid["is_solid"] == 1).all()            # crosses the sphere
    assert df["pressure"].loc[df["is_solid"] == 1].isna().all()


def test_sample_box(grid_idw):
    df = sample_box(grid_idw, (0.2, 0.2, 0.2), (0.4, 0.4, 0.4),
                    (10, 10, 10), ["pressure"], max_rows=10_000)
    assert len(df) == 1000
    assert df["pressure"].notna().mean() > 0.95
    with pytest.raises(RegionTooLargeError):
        sample_box(grid_idw, (0, 0, 0), (1, 1, 1), (300, 300, 300),
                   ["pressure"], max_rows=1000)
