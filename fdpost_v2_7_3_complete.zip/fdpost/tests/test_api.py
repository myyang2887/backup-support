"""End-to-end API test: upload -> poll job -> preview -> slice/probe/region."""
import time

import numpy as np
import pytest
from fastapi.testclient import TestClient

from fdpost.api.app import create_app
from fdpost.config import Settings


@pytest.fixture(scope="module")
def client(tmp_path_factory, synthetic_tsv):
    root = tmp_path_factory.mktemp("srv")
    settings = Settings(data_dir=root / "data", cache_dir=root / "cache",
                        output_dir=root / "out", job_workers=1)
    app = create_app(settings)
    with TestClient(app) as c:
        yield c, synthetic_tsv


def _wait_job(c, job_id, timeout=120):
    t0 = time.time()
    while time.time() - t0 < timeout:
        j = c.get(f"/api/jobs/{job_id}").json()
        if j["status"] in ("done", "error"):
            return j
        time.sleep(0.3)
    raise TimeoutError(job_id)


@pytest.fixture(scope="module")
def dataset(client):
    c, tsv = client
    with open(tsv, "rb") as f:
        r = c.post("/api/datasets/upload",
                   files={"file": ("demo.txt", f, "text/plain")},
                   data={"method": "idw", "target_dims": "48"})
    assert r.status_code == 200, r.text
    out = r.json()
    j = _wait_job(c, out["job_id"])
    assert j["status"] == "done", j
    return out["dataset_id"]


def test_health(client):
    c, _ = client
    assert c.get("/api/health").json()["status"] == "ok"


def test_dataset_ready(client, dataset):
    c, _ = client
    info = c.get(f"/api/datasets/{dataset}").json()
    assert info["status"] == "ready"
    assert "pressure" in info["fields"]
    assert info["meta"]["fluid_rule_used"] == "velocity_presence"


def test_preview(client, dataset):
    c, _ = client
    meta = c.get(f"/api/datasets/{dataset}/preview/meta").json()
    dims = meta["dims"]
    r = c.get(f"/api/datasets/{dataset}/preview/volume/pressure")
    vol = np.frombuffer(r.content, dtype=np.float32)
    assert vol.size == dims[0] * dims[1] * dims[2]
    assert np.isnan(vol).any()                       # solid voxels
    r = c.get(f"/api/datasets/{dataset}/preview/points/pressure?max_points=5000")
    m = len(r.content) // 16
    assert m > 100 and len(r.content) == m * 16


def test_plane_slice_sync(client, dataset):
    c, _ = client
    r = c.post(f"/api/datasets/{dataset}/slices/plane",
               json={"mode": "euler", "tilt_deg": 30, "azimuth_deg": 45,
                     "distance": 0.0, "field": "pressure",
                     "resolution": [120, 120]})
    assert r.status_code == 200, r.text
    rel = r.json()["file"]
    # download through /api/files
    import pathlib
    root = pathlib.Path(c.app.state.settings.output_dir).resolve()
    relp = pathlib.Path(rel).resolve().relative_to(root)
    fr = c.get(f"/api/files/{relp.as_posix()}")
    assert fr.status_code == 200 and len(fr.content) > 10_000


def test_axis_batch_job(client, dataset):
    c, _ = client
    r = c.post(f"/api/datasets/{dataset}/slices/axis-batch",
               json={"axis": "z", "start": 0.3, "stop": 0.7, "step": 0.2,
                     "field": "velocity_magnitude", "with_vectors": True})
    j = _wait_job(c, r.json()["id"])
    assert j["status"] == "done" and j["result"]["n_slices"] == 3
    assert j["result"]["zip"].endswith(".zip")


def test_probe_and_region(client, dataset):
    c, _ = client
    r = c.post(f"/api/datasets/{dataset}/probe",
               json={"p0": [0.1, 0.5, 0.5], "p1": [0.9, 0.5, 0.5],
                     "n_samples": 100, "fields": ["pressure"]})
    assert r.status_code == 200 and r.json()["n_rows"] == 100
    r = c.post(f"/api/datasets/{dataset}/region",
               json={"min_point": [0.2, 0.2, 0.2], "max_point": [0.4, 0.4, 0.4],
                     "resolution": [8, 8, 8]})
    assert r.status_code == 200 and r.json()["n_rows"] == 512
    r = c.post(f"/api/datasets/{dataset}/region",
               json={"min_point": [0, 0, 0], "max_point": [1, 1, 1],
                     "resolution": [400, 400, 400]})
    assert r.status_code == 413


def test_field_not_found(client, dataset):
    c, _ = client
    r = c.post(f"/api/datasets/{dataset}/probe",
               json={"p0": [0, 0, 0], "p1": [1, 1, 1], "fields": ["no_such"]})
    assert r.status_code == 404


def test_path_traversal_blocked(client):
    c, _ = client
    r = c.get("/api/files/../../etc/passwd")
    assert r.status_code == 404
