"""v2.1 API: isosurface/streamline binaries, sessions, snapshots, persistence."""
import struct
import time

import numpy as np
from fastapi.testclient import TestClient


def _make_app(tmp_path, monkeypatch):
    # Pass Settings explicitly. Patching the module-level singleton does not
    # work: create_app() builds a fresh Settings() when called with none, so
    # the patched values were ignored and the test wrote into the repo.
    from fdpost.api.app import create_app
    from fdpost.config import Settings

    return create_app(Settings(
        data_dir=tmp_path / "data", cache_dir=tmp_path / "cache",
        output_dir=tmp_path / "output", preview_res=24))


def _upload_ready(c, synthetic_tsv):
    with open(synthetic_tsv, "rb") as f:
        r = c.post("/api/datasets/upload",
                   files={"file": ("s.txt", f, "text/plain")},
                   data={"method": "nearest", "target_dims": "24"})
    assert r.status_code == 200, r.text
    ds, job = r.json()["dataset_id"], r.json()["job_id"]
    for _ in range(120):
        j = c.get(f"/api/jobs/{job}").json()
        if j["status"] in ("done", "error"):
            assert j["status"] == "done", j
            return ds
        time.sleep(0.25)
    raise TimeoutError


def test_viz3d_and_persistence(tmp_path, monkeypatch, synthetic_tsv):
    c = TestClient(_make_app(tmp_path, monkeypatch))
    ds = _upload_ready(c, synthetic_tsv)

    # isosurface range + binary mesh
    rng = c.get(f"/api/datasets/{ds}/isosurface/pressure/range").json()
    level = 0.5 * (rng["min"] + rng["max"])
    r = c.get(f"/api/datasets/{ds}/isosurface/pressure", params={"level": level})
    assert r.status_code == 200
    n_v, n_f = struct.unpack_from("<II", r.content, 0)
    assert n_v > 10 and n_f > 10
    assert len(r.content) == 8 + n_v * 12 + n_v * 12 + n_f * 12
    verts = np.frombuffer(r.content, np.float32, n_v * 3, 8).reshape(-1, 3)
    faces = np.frombuffer(r.content, np.uint32, n_f * 3, 8 + n_v * 24)
    assert faces.max() < n_v and np.isfinite(verts).all()

    # out-of-range level -> clean 400
    assert c.get(f"/api/datasets/{ds}/isosurface/pressure",
                 params={"level": 1e9}).status_code == 400

    # streamlines binary
    r = c.post(f"/api/datasets/{ds}/streamlines",
               json={"p0": [0.1, 0.1, 0.2], "p1": [0.1, 0.9, 0.2],
                     "n_seeds": 6, "max_steps": 150})
    assert r.status_code == 200
    (n_l,) = struct.unpack_from("<I", r.content, 0)
    assert n_l >= 1
    counts = np.frombuffer(r.content, np.uint32, n_l, 4)
    total = int(counts.sum())
    off = 4 + 4 * n_l
    assert len(r.content) == off + total * 12 + total * 4
    pts = np.frombuffer(r.content, np.float32, total * 3, off).reshape(-1, 3)
    assert np.isfinite(pts).all()

    # dataset persists across app recreation (SQLite registry)
    c2 = TestClient(_make_app(tmp_path, monkeypatch))
    listed = c2.get("/api/datasets").json()
    assert any(d["id"] == ds and d["status"] == "ready" for d in listed)
    # and the grid actually loads from cache in the new process
    r = c2.get(f"/api/datasets/{ds}/preview/meta")
    assert r.status_code == 200 and "dims" in r.json()


def test_sessions_and_snapshots(tmp_path, monkeypatch):
    c = TestClient(_make_app(tmp_path, monkeypatch))
    r = c.post("/api/sessions", json={"name": "断面検討", "dataset_id": "d1",
                                      "state": {"tool": "slice", "tilt": 30}})
    sid = r.json()["id"]
    assert any(s["id"] == sid for s in c.get("/api/sessions").json())
    got = c.get(f"/api/sessions/{sid}").json()
    assert got["state"]["tilt"] == 30 and got["name"] == "断面検討"
    tok = c.post("/api/snapshots",
                 json={"dataset_id": "d1", "state": {"view": [1, 2, 3]}}).json()["token"]
    snap = c.get(f"/api/snapshots/{tok}").json()
    assert snap["state"]["view"] == [1, 2, 3]
    assert c.get(f"/api/sessions/{tok}").status_code == 404   # kind separation
    assert c.get("/api/snapshots/zzz").status_code == 404
    c.delete(f"/api/sessions/{sid}")
    assert c.get(f"/api/sessions/{sid}").status_code == 404
