from fdpost.io.registry import Registry


def test_dataset_roundtrip_and_reopen(tmp_path):
    db = tmp_path / "r.db"
    r = Registry(db)
    r.upsert_dataset("abc", {"id": "abc", "status": "ready", "fields": ["p"]})
    r.upsert_dataset("abc", {"id": "abc", "status": "ready", "fields": ["p", "v"]})
    r.close()
    r2 = Registry(db)                        # persistence across reopen
    rows = r2.load_datasets()
    assert len(rows) == 1 and rows[0]["fields"] == ["p", "v"]
    r2.delete_dataset("abc")
    assert r2.load_datasets() == []
    r2.close()


def test_sessions_and_snapshots(tmp_path):
    r = Registry(tmp_path / "r.db")
    sid = r.save_session("session", "作業1", "ds1", {"tool": "slice", "k": 5})
    r.save_session("session", "作業1改", "ds1", {"tool": "probe"}, session_id=sid)
    tok = r.save_session("snapshot", "", "ds1", {"view": 1})
    listed = r.list_sessions("session")
    assert len(listed) == 1 and listed[0]["name"] == "作業1改"
    assert r.get_session(sid)["state"] == {"tool": "probe"}
    assert r.get_session(tok)["kind"] == "snapshot"
    assert r.get_session("nope") is None
    r.delete_session(sid)
    assert r.list_sessions("session") == []
    r.close()
