from pathlib import Path

import numpy as np

from fdpost.core.query import sample_line, slice_axis
from fdpost.render.contour import compute_global_clim, render_slice_png
from fdpost.render.lineplot import render_line_png


def test_render_slice(grid_idw, tmp_path):
    sl = slice_axis(grid_idw, "z", 0.5, "velocity_magnitude", with_vectors=True)
    p = render_slice_png(sl, tmp_path / "s.png", cmap="jet", dpi=110)
    assert Path(p).stat().st_size > 10_000


def test_global_clim():
    a = np.array([[1.0, np.nan], [3.0, 2.0]])
    b = np.array([[0.5, 5.0], [np.nan, np.nan]])
    assert compute_global_clim([a, b]) == (0.5, 5.0)


def test_render_line(grid_idw, tmp_path):
    df = sample_line(grid_idw, (0.1, 0.5, 0.5), (0.9, 0.5, 0.5), 150,
                     ["pressure", "velocity_magnitude"])
    p = render_line_png(df, ["pressure", "velocity_magnitude"],
                        tmp_path / "l.png", units={"pressure": "Pa"},
                        x_label="Distance [m]")
    assert Path(p).stat().st_size > 10_000
