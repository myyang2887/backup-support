"""Shared fixtures: analytic synthetic field with a solid sphere + real FloEFD sample."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from fdpost.domain.field_data import FieldData
from fdpost.domain.requests import PreprocessConfig

SOLID_CENTER = np.array([0.5, 0.5, 0.5])
SOLID_R = 0.15


def analytic(pts: np.ndarray) -> dict[str, np.ndarray]:
    """Smooth analytic fields on the unit cube."""
    x, y, z = pts[:, 0], pts[:, 1], pts[:, 2]
    return {
        "pressure": np.sin(2 * np.pi * x) * np.cos(2 * np.pi * y) + z,
        "velocity_x": x + y,
        "velocity_y": y - z,
        "velocity_z": np.cos(np.pi * z),
    }


def in_sphere(pts: np.ndarray) -> np.ndarray:
    return np.linalg.norm(pts - SOLID_CENTER, axis=1) < SOLID_R


def make_synthetic(n: int = 60_000, seed: int = 42) -> FieldData:
    rng = np.random.default_rng(seed)
    pts = rng.random((n, 3))
    f = analytic(pts)
    solid = in_sphere(pts)
    for k in ("velocity_x", "velocity_y", "velocity_z"):
        f[k] = f[k].copy()
        f[k][solid] = np.nan          # solid rows: velocity missing (real FloEFD behavior)
    f["velocity_magnitude"] = np.sqrt(
        np.nan_to_num(f["velocity_x"]) ** 2 + np.nan_to_num(f["velocity_y"]) ** 2
        + np.nan_to_num(f["velocity_z"]) ** 2)
    f["velocity_magnitude"][solid] = np.nan
    units = {k: ("Pa" if k == "pressure" else "m/s") for k in f}
    units.update({"x": "m", "y": "m", "z": "m"})
    return FieldData(points=pts, fields=f, is_fluid=~solid, units=units,
                     meta={"synthetic": True})


def write_floefd_tsv(fd: FieldData, path: Path) -> Path:
    """Write in the *dirty* real FloEFD format: BOM, CRLF, trailing tab,
    units in headers, empty cells for NaN."""
    headers = ["X (m)", "Y (m)", "Z (m)", "Pressure (Pa)",
               "Velocity (X) (m/s)", "Velocity (Y) (m/s)", "Velocity (Z) (m/s)"]
    cols = ["pressure", "velocity_x", "velocity_y", "velocity_z"]
    lines = ["\t".join(headers) + "\t"]
    for i in range(fd.n_points):
        row = [f"{fd.points[i, j]:.9g}" for j in range(3)]
        for c in cols:
            v = fd.fields[c][i]
            row.append("" if np.isnan(v) else f"{v:.9g}")
        lines.append("\t".join(row) + "\t")
    path.write_bytes(("\ufeff" + "\r\n".join(lines) + "\r\n").encode("utf-8"))
    return path


@pytest.fixture(scope="session")
def synthetic_fd() -> FieldData:
    return make_synthetic()


@pytest.fixture(scope="session")
def small_fd() -> FieldData:
    return make_synthetic(n=4000, seed=7)


@pytest.fixture(scope="session")
def synthetic_tsv(tmp_path_factory, synthetic_fd) -> Path:
    p = tmp_path_factory.mktemp("data") / "synthetic.txt"
    return write_floefd_tsv(synthetic_fd, p)


@pytest.fixture()
def real_tsv() -> Path:
    return Path(__file__).parent / "data" / "test_data.txt"


@pytest.fixture(scope="session")
def grid_idw(synthetic_fd):
    """64^3 grid via IDW: shared across query/render/api tests (expensive)."""
    from fdpost.core.resample import resample_to_grid
    cfg = PreprocessConfig(method="idw", target_dims=64)
    return resample_to_grid(synthetic_fd, cfg)


# --- shared API fixtures (used by the v2.2 export tests) --------------------

@pytest.fixture(scope="session")
def api_client(tmp_path_factory, synthetic_tsv):
    """A running app on a throwaway data/cache/output root."""
    from fastapi.testclient import TestClient

    from fdpost.api.app import create_app
    from fdpost.config import Settings

    root = tmp_path_factory.mktemp("api")
    settings = Settings(data_dir=root / "data", cache_dir=root / "cache",
                        output_dir=root / "out", job_workers=1, preview_res=32)
    with TestClient(create_app(settings)) as c:
        yield c, synthetic_tsv


@pytest.fixture(scope="session")
def api_dataset(api_client):
    """Dataset id of a preprocessed 48^3 grid."""
    import time

    c, tsv = api_client
    with open(tsv, "rb") as f:
        r = c.post("/api/datasets/upload",
                   files={"file": ("demo.txt", f, "text/plain")},
                   data={"method": "idw", "target_dims": "48"})
    assert r.status_code == 200, r.text
    ds, job = r.json()["dataset_id"], r.json()["job_id"]
    for _ in range(400):
        j = c.get(f"/api/jobs/{job}").json()
        if j["status"] in ("done", "error"):
            assert j["status"] == "done", j
            return ds
        time.sleep(0.25)
    raise TimeoutError("preprocess did not finish")
