"""RMSE gates vs analytic solution (spec 13 gate 2)."""
import numpy as np
import pytest

from fdpost.interp import available_methods, get_interpolator
from tests.conftest import analytic, in_sphere

THRESH = {"nearest": 0.08, "idw": 0.05, "linear": 0.02, "rbf": 0.02}


@pytest.fixture(scope="module")
def query_pts():
    rng = np.random.default_rng(1)
    q = 0.05 + 0.9 * rng.random((500, 3))     # stay inside hull
    return q[~in_sphere(q)][:400]


@pytest.mark.parametrize("method", ["nearest", "idw", "linear", "rbf"])
def test_rmse_gate(method, synthetic_fd, query_pts):
    valid = ~np.isnan(synthetic_fd.fields["pressure"])
    itp = get_interpolator(method).fit(synthetic_fd.points[valid])
    got = itp.interpolate(synthetic_fd.fields["pressure"][valid], query_pts)
    want = analytic(query_pts)["pressure"]
    ok = ~np.isnan(got)
    assert ok.mean() > 0.95
    rmse = float(np.sqrt(np.mean((got[ok] - want[ok]) ** 2)))
    assert rmse < THRESH[method], f"{method} RMSE {rmse:.4f}"


def test_multi_field_shape(small_fd):
    itp = get_interpolator("idw").fit(small_fd.points)
    vals = np.column_stack([small_fd.fields["pressure"],
                            small_fd.points[:, 0]])
    out = itp.interpolate(vals, small_fd.points[:10])
    assert out.shape == (10, 2)


def test_idw_exact_hit(small_fd):
    itp = get_interpolator("idw").fit(small_fd.points)
    out = itp.interpolate(small_fd.fields["pressure"], small_fd.points[:5])
    assert np.allclose(out, small_fd.fields["pressure"][:5], atol=1e-9)


def test_registry():
    assert set(available_methods()) == {"nearest", "idw", "linear", "rbf"}
    with pytest.raises(ValueError):
        get_interpolator("cubic")
