import numpy as np
import pytest

from fdpost.core import resample as rs
from fdpost.core.resample import resample_to_grid
from fdpost.domain.requests import PreprocessConfig
from tests.conftest import SOLID_CENTER, SOLID_R, analytic


def test_grid_matches_analytic(grid_idw):
    g = grid_idw
    assert max(g.dims) == 64
    # sample fluid voxels far from the sphere
    coords, _ = g.fluid_voxel_points(3000)
    far = np.linalg.norm(coords - SOLID_CENTER, axis=1) > SOLID_R + 3 * g.spacing[0]
    inner = np.all((coords > 0.05) & (coords < 0.95), axis=1)
    sel = coords[far & inner]
    got = g.sample("pressure", sel)
    want = analytic(sel)["pressure"]
    ok = ~np.isnan(got)
    rmse = float(np.sqrt(np.mean((got[ok] - want[ok]) ** 2)))
    assert rmse < 0.05, rmse


def test_solid_mask_covers_sphere(grid_idw):
    g = grid_idw
    center_solid = g.sample_solid(SOLID_CENTER[None, :])
    assert bool(center_solid[0])
    outside = np.array([[0.1, 0.1, 0.1], [0.9, 0.9, 0.9]])
    assert not g.sample_solid(outside).any()


def test_group_fit_reuse(small_fd, monkeypatch):
    """Fields sharing a validity mask must share ONE interpolator fit."""
    calls = {"n": 0}
    orig = rs.get_interpolator

    def counting(name, **kw):
        itp = orig(name, **kw)
        real_fit = itp.fit

        def fit(pts):
            calls["n"] += 1
            return real_fit(pts)
        itp.fit = fit
        return itp

    monkeypatch.setattr(rs, "get_interpolator", counting)
    cfg = PreprocessConfig(method="nearest", target_dims=16)
    resample_to_grid(small_fd, cfg)
    # groups: pressure (all valid) vs velocity_* (NaN in sphere) -> exactly 2 fits
    assert calls["n"] == 2, calls


def test_progress_callback(small_fd):
    seen = []
    cfg = PreprocessConfig(method="nearest", target_dims=16)
    resample_to_grid(small_fd, cfg, progress=lambda f, m: seen.append(f))
    assert seen and abs(seen[-1] - 1.0) < 1e-9


def test_degenerate_cloud():
    from fdpost.domain.field_data import FieldData
    pts = np.zeros((10, 3)); pts[:, 0] = np.arange(10)
    fd = FieldData(points=pts, fields={"p": np.ones(10)},
                   is_fluid=np.ones(10, bool), units={})
    with pytest.raises(Exception):
        resample_to_grid(fd, PreprocessConfig(method="nearest", target_dims=8))
