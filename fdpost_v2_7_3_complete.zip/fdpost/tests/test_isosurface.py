import numpy as np
import pytest

from fdpost.core.isosurface import compute_isosurface, field_range
from fdpost.domain.errors import GridBuildError


def test_basic_mesh(grid_idw):
    lo, hi = field_range(grid_idw, "pressure")
    level = 0.5 * (lo + hi)
    verts, faces, normals = compute_isosurface(grid_idw, "pressure", level)
    assert verts.shape[0] > 100 and faces.shape[0] > 100
    assert normals.shape == verts.shape
    assert faces.max() < verts.shape[0]
    b = grid_idw.bounds
    assert (verts >= b[0] - 1e-6).all() and (verts <= b[1] + 1e-6).all()
    # verify the surface actually sits at the level: sample field at verts
    sampled = grid_idw.sample("pressure", verts.astype(np.float64))
    ok = ~np.isnan(sampled)
    assert np.median(np.abs(sampled[ok] - level)) < 0.05


def test_level_out_of_range(grid_idw):
    with pytest.raises(GridBuildError, match="outside"):
        compute_isosurface(grid_idw, "pressure", 1e9)


def test_iso_excludes_solid(grid_idw):
    """No fabricated skin over the solid sphere: verts keep a distance from center."""
    lo, hi = field_range(grid_idw, "pressure")
    verts, _, _ = compute_isosurface(grid_idw, "pressure", 0.5 * (lo + hi))
    d = np.linalg.norm(verts - np.array([0.5, 0.5, 0.5], dtype=np.float32), axis=1)
    assert d.min() > 0.10   # sphere r=0.15 minus ~2 voxel margin
