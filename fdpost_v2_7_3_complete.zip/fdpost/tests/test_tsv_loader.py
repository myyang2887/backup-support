import numpy as np
import pytest

from fdpost.domain.errors import DataLoadError
from fdpost.io.tsv_loader import canonical_name, load_floefd_table, split_name_unit


def test_split_name_unit():
    assert split_name_unit("Pressure (Pa)") == ("Pressure", "Pa")
    assert split_name_unit("Velocity (X) (m/s)") == ("Velocity (X)", "m/s")
    assert split_name_unit("Volume [m^3]") == ("Volume", "m^3")
    assert split_name_unit("X (m)") == ("X", "m")


def test_canonical_name():
    assert canonical_name("Velocity (X)") == "velocity_x"
    assert canonical_name("Velocity") == "velocity_magnitude"
    assert canonical_name("圧力") == "pressure"
    assert canonical_name("X") == "x"
    assert canonical_name("Some Custom Field") == "some_custom_field"


def test_load_synthetic_dirty_format(synthetic_tsv, synthetic_fd):
    fd = load_floefd_table(synthetic_tsv)
    assert fd.n_points == synthetic_fd.n_points
    assert "pressure" in fd.fields and "velocity_x" in fd.fields
    assert "velocity_magnitude" in fd.fields          # auto-derived
    assert fd.units["pressure"] == "Pa"
    # solid classification: velocity presence
    assert fd.meta["fluid_rule_used"] == "velocity_presence"
    assert abs(fd.meta["n_solid"] - int((~synthetic_fd.is_fluid).sum())) == 0
    # no ghost column leaked
    assert not any(c.startswith("unnamed") for c in fd.fields)


def test_load_real_sample(real_tsv):
    fd = load_floefd_table(real_tsv)
    assert fd.meta["n_fluid"] == 14 and fd.meta["n_solid"] == 23
    assert fd.units["volume"] == "m^3"
    assert set(fd.fields) >= {"volume", "surface", "velocity_x",
                              "velocity_y", "velocity_z", "velocity_magnitude"}
    # solid rows keep volume values but lack velocity
    solid = ~fd.is_fluid
    assert np.isnan(fd.fields["velocity_x"][solid]).all()
    # each solid row carries Volume OR Surface metadata (real-format quirk)
    has_meta = np.isfinite(fd.fields["volume"][solid]) | np.isfinite(fd.fields["surface"][solid])
    assert has_meta.all()


def test_missing_file():
    with pytest.raises(DataLoadError):
        load_floefd_table("/no/such/file.txt")


def test_too_few_points(tmp_path):
    p = tmp_path / "tiny.txt"
    p.write_text("X (m)\tY (m)\tZ (m)\tPressure (Pa)\n0\t0\t0\t1\n")
    with pytest.raises(DataLoadError):
        load_floefd_table(p)
