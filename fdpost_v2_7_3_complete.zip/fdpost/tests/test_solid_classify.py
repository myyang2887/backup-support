import numpy as np
import pandas as pd
import pytest

from fdpost.core.solid_classify import classify_fluid
from fdpost.domain.requests import FluidRule


def _df(**cols):
    return pd.DataFrame(cols)


def test_explicit_label_wins():
    df = _df(velocity_x=[1.0, np.nan], solid=[1, 0])
    fl, name = classify_fluid(df, ["velocity_x", "solid"], {}, FluidRule())
    assert name == "explicit_label"
    assert fl.tolist() == [False, True]


def test_velocity_presence_default():
    df = _df(velocity_x=[1.0, np.nan], volume=[1.0, 1.0])
    fl, name = classify_fluid(df, ["velocity_x", "volume"], {}, FluidRule())
    assert name == "velocity_presence"
    assert fl.tolist() == [True, False]


def test_any_physical_when_no_velocity():
    df = _df(temperature=[300.0, np.nan], volume=[1.0, 1.0])
    fl, name = classify_fluid(df, ["temperature", "volume"], {}, FluidRule())
    assert name == "any_physical"
    assert fl.tolist() == [True, False]


def test_all_fluid_fallback_warns(caplog):
    df = _df(volume=[1.0, 1.0])
    with caplog.at_level("WARNING"):
        fl, name = classify_fluid(df, ["volume"], {}, FluidRule())
    assert name == "all_fluid" and fl.all()
    assert any("all points as fluid" in r.message for r in caplog.records)


def test_configured_threshold_rule():
    df = _df(temperature=[100.0, 400.0, np.nan])
    rule = FluidRule(mode="field_threshold", field="temperature",
                     threshold=273.0, comparison="gt")
    fl, name = classify_fluid(df, ["temperature"], {}, rule)
    assert name == "configured"
    assert fl.tolist() == [False, True, False]


def test_rule_validation():
    with pytest.raises(ValueError):
        FluidRule(mode="field_threshold", field="t")
