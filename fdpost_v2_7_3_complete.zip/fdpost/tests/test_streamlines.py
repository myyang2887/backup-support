import numpy as np

from fdpost.core.streamlines import line_seeds, trace_streamlines
from tests.conftest import SOLID_CENTER


def test_analytic_flow_structure(grid_idw):
    """v = (x+y, y-z, cos(pi z)): forward from (0.15,0.15,0.3) -> x monotonic
    (vx>0 along the path) and z drifts toward the stable plane z=0.5."""
    lines = trace_streamlines(grid_idw, np.array([[0.15, 0.15, 0.3]]),
                              direction="forward", max_steps=800)
    pts, spd = lines[0]
    assert pts.shape[0] > 20
    assert np.all(np.diff(pts[:, 0]) > -1e-9)
    assert abs(pts[-1, 2] - 0.5) <= abs(pts[0, 2] - 0.5) + 1e-6
    assert np.all(spd > 0)


def test_seed_in_solid_yields_empty(grid_idw):
    lines = trace_streamlines(grid_idw, np.array([SOLID_CENTER]), direction="both")
    assert lines[0][0].shape[0] == 0


def test_both_longer_than_forward(grid_idw):
    seed = np.array([[0.5, 0.2, 0.25]])
    fwd = trace_streamlines(grid_idw, seed, direction="forward")[0][0]
    both = trace_streamlines(grid_idw, seed, direction="both")[0][0]
    assert both.shape[0] > fwd.shape[0]


def test_stays_inside_bounds(grid_idw):
    seeds = line_seeds((0.1, 0.1, 0.2), (0.1, 0.9, 0.2), 8)
    lines = trace_streamlines(grid_idw, seeds, direction="both", max_steps=500)
    b = grid_idw.bounds
    for pts, _ in lines:
        if pts.shape[0]:
            assert (pts >= b[0] - 0.05).all() and (pts <= b[1] + 0.05).all()


def test_line_seeds():
    s = line_seeds((0, 0, 0), (1, 0, 0), 5)
    assert s.shape == (5, 3)
    assert np.allclose(s[:, 0], [0, 0.25, 0.5, 0.75, 1.0])
