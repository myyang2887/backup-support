import numpy as np
import pytest

from fdpost.domain.errors import CacheError
from fdpost.io.grid_cache import (CACHE_VERSION, cache_key, load_grid,
                                  save_grid, source_signature)


def test_roundtrip(grid_idw, tmp_path):
    p = tmp_path / "g.npz"
    save_grid(grid_idw, p)
    g2 = load_grid(p)
    assert g2.dims == grid_idw.dims
    assert np.allclose(g2.origin, grid_idw.origin)
    for k in grid_idw.arrays:
        assert np.array_equal(g2.arrays[k], grid_idw.arrays[k], equal_nan=True)
    assert np.array_equal(g2.solid_mask, grid_idw.solid_mask)
    assert g2.units == grid_idw.units


def test_corrupt_deleted(tmp_path):
    p = tmp_path / "bad.npz"
    p.write_bytes(b"not a zip")
    with pytest.raises(CacheError):
        load_grid(p)
    assert not p.exists()


def test_signature_changes(tmp_path):
    f = tmp_path / "d.txt"
    f.write_text("hello")
    s1 = source_signature(f)
    f.write_text("hello world")
    assert source_signature(f) != s1
    assert cache_key(s1, "a") != cache_key(s1, "b")
    assert str(CACHE_VERSION) in f"v{CACHE_VERSION}"
