"""Additive helper: insert '/api/files/...' URL keys next to absolute output
paths in service result dicts (keeps the original keys untouched)."""
from __future__ import annotations

from pathlib import Path
from typing import Any

_PATH_KEYS = ("file", "csv", "png", "zip")


def add_urls(result: Any, output_dir: Path | str) -> Any:
    if not isinstance(result, dict):
        return result
    root = Path(output_dir).resolve()

    def rel(p: str) -> str | None:
        try:
            return "/api/files/" + Path(p).resolve().relative_to(root).as_posix()
        except (ValueError, OSError):
            return None

    for k in _PATH_KEYS:
        v = result.get(k)
        if isinstance(v, str):
            u = rel(v)
            if u:
                result[f"{k}_url"] = u
    files = result.get("files")
    if isinstance(files, list):
        result["file_urls"] = [u for u in (rel(p) for p in files if isinstance(p, str)) if u]
    return result
