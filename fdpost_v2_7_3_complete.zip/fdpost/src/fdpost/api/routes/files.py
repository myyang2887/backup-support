"""Serve generated outputs (with path-traversal protection)."""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse

router = APIRouter(prefix="/api/files", tags=["files"])


@router.get("/{rel_path:path}")
def get_file(rel_path: str, request: Request):
    root = Path(request.app.state.settings.output_dir).resolve()
    target = (root / rel_path).resolve()
    if root not in target.parents and target != root:
        raise HTTPException(status_code=404, detail="not found")
    if not target.is_file():
        raise HTTPException(status_code=404, detail="not found")
    return FileResponse(target, filename=target.name)
