from __future__ import annotations

from fastapi import APIRouter, Request

from fdpost.api.urlize import add_urls
from fdpost.domain.requests import LineProbeRequest

router = APIRouter(prefix="/api/datasets/{ds_id}", tags=["probes"])


@router.post("/probe")
def probe(ds_id: str, req: LineProbeRequest, request: Request):
    res = request.app.state.probe_service.run(ds_id, req)
    return add_urls(res, request.app.state.settings.output_dir)
