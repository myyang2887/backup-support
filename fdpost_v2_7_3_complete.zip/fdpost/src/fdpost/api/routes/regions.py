"""Region CSV endpoints: 3D box and plane (断面) at a chosen resolution."""
from __future__ import annotations

from fastapi import APIRouter, Request

from fdpost.api.ephemeral import stream_export
from fdpost.api.urlize import add_urls
from fdpost.services.region_service import RegionService
from fdpost.domain.requests import BoxRegionRequest, PlaneRegionRequest

router = APIRouter(prefix="/api/datasets/{ds_id}", tags=["regions"])


@router.post("/region")
def region(ds_id: str, req: BoxRegionRequest, request: Request,
           deliver: str = "url"):
    svc = request.app.state.region_service
    settings = request.app.state.settings
    if deliver == "stream":
        return stream_export(
            settings, lambda s: RegionService(svc.store, s).run_box(ds_id, req),
            stem="region")
    return add_urls(svc.run_box(ds_id, req), settings.output_dir)


@router.post("/region/plane")
def region_plane(ds_id: str, req: PlaneRegionRequest, request: Request,
                 deliver: str = "url"):
    svc = request.app.state.region_service
    settings = request.app.state.settings
    if deliver == "stream":
        return stream_export(
            settings, lambda s: RegionService(svc.store, s).run_plane(ds_id, req),
            stem="plane_region")
    return add_urls(svc.run_plane(ds_id, req), settings.output_dir)
