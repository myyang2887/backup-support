from __future__ import annotations

import json
import shutil
import uuid
from pathlib import Path

from fastapi import APIRouter, File, Form, Request, UploadFile

from fdpost.api.schemas import DatasetOut, RegisterOut
from fdpost.domain.errors import DataLoadError
from fdpost.domain.requests import FluidRule, PreprocessConfig

router = APIRouter(prefix="/api/datasets", tags=["datasets"])

MAX_UPLOAD = 2 * 1024**3  # 2 GB


def _cfg(method: str, spacing: float | None, target_dims: int | None,
         fluid_rule: str | None) -> PreprocessConfig:
    rule = FluidRule(**json.loads(fluid_rule)) if fluid_rule else FluidRule()
    return PreprocessConfig(method=method, spacing=spacing,
                            target_dims=target_dims, fluid_rule=rule)


@router.get("", response_model=list[DatasetOut])
def list_datasets(request: Request):
    return request.app.state.store.list()


@router.get("/{ds_id}", response_model=DatasetOut)
def get_dataset(ds_id: str, request: Request):
    return request.app.state.store.info(ds_id).public()


@router.post("/register", response_model=RegisterOut)
def register_path(request: Request, path: str = Form(...),
                  method: str = Form("idw"), spacing: float | None = Form(None),
                  target_dims: int | None = Form(128),
                  fluid_rule: str | None = Form(None)):
    """Register a server-local file path (CLI / desktop mode)."""
    info, job = request.app.state.store.register(
        path, _cfg(method, spacing, target_dims, fluid_rule))
    return RegisterOut(dataset_id=info.id, job_id=job.id)


@router.post("/upload", response_model=RegisterOut)
async def upload(request: Request, file: UploadFile = File(...),
                 method: str = Form("idw"), spacing: float | None = Form(None),
                 target_dims: int | None = Form(128),
                 fluid_rule: str | None = Form(None)):
    """Browser upload -> save into data_dir -> register."""
    settings = request.app.state.settings
    dest_dir = Path(settings.data_dir) / "uploads"
    dest_dir.mkdir(parents=True, exist_ok=True)
    safe = Path(file.filename or "upload.txt").name
    dest = dest_dir / f"{uuid.uuid4().hex[:8]}_{safe}"
    size = 0
    with open(dest, "wb") as out:
        while chunk := await file.read(1 << 20):
            size += len(chunk)
            if size > MAX_UPLOAD:
                out.close(); dest.unlink(missing_ok=True)
                raise DataLoadError(f"upload exceeds {MAX_UPLOAD} bytes")
            out.write(chunk)
    if size == 0:
        dest.unlink(missing_ok=True)
        raise DataLoadError("empty upload")
    info, job = request.app.state.store.register(
        dest, _cfg(method, spacing, target_dims, fluid_rule))
    return RegisterOut(dataset_id=info.id, job_id=job.id)


@router.delete("/{ds_id}")
def delete_dataset(ds_id: str, request: Request, drop_source: bool = False):
    """Remove a dataset from the list (and its grid cache)."""
    return request.app.state.store.delete(ds_id, drop_source=drop_source)
