from __future__ import annotations

from fastapi import APIRouter, Request

from fdpost.api.schemas import JobOut
from fdpost.api.urlize import add_urls

router = APIRouter(prefix="/api/jobs", tags=["jobs"])


@router.get("/{job_id}", response_model=JobOut)
def get_job(job_id: str, request: Request):
    snap = request.app.state.jobs.get(job_id).snapshot()
    if snap.get("result"):
        snap["result"] = add_urls(snap["result"],
                                  request.app.state.settings.output_dir)
    return snap
