"""Browse and delete what the server has stored in its output directory.

Every export renders on the server before it can be downloaded, and batch
jobs must persist their results so they can be collected later. On a shared
machine that means someone else's disk fills with other people's results —
and those results are their data, sitting on a host they do not control.

So the output directory needs to be visible and clearable from the UI, not
just from a shell on the host. Deletion is manual on purpose: an automatic
sweep would eventually delete a result somebody still needed.

Every path is resolved against the output root and rejected if it escapes,
so a crafted name cannot reach the rest of the filesystem.
"""
from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request

log = logging.getLogger("fdpost.api.outputs")
router = APIRouter(prefix="/api/outputs", tags=["outputs"])


def _root(request: Request) -> Path:
    return Path(request.app.state.settings.output_dir).resolve()


def _safe(root: Path, name: str) -> Path:
    """Resolve `name` under `root`, refusing anything that escapes it."""
    target = (root / name).resolve()
    if target != root and root not in target.parents:
        raise HTTPException(status_code=400, detail="invalid path")
    if target == root:
        raise HTTPException(status_code=400, detail="refusing to remove the root")
    return target


def _describe(entry: Path, root: Path) -> dict[str, Any]:
    """One row: what it is, how big, when, and what can be downloaded."""
    files = ([entry] if entry.is_file()
             else sorted(p for p in entry.rglob("*") if p.is_file()))
    size = sum(p.stat().st_size for p in files)
    mtime = max((p.stat().st_mtime for p in files), default=entry.stat().st_mtime)
    return {
        "name": entry.name,
        "is_dir": entry.is_dir(),
        "bytes": int(size),
        "n_files": len(files),
        "modified": float(mtime),
        # relative paths the existing /api/files endpoint can serve
        "files": [str(p.relative_to(root)).replace("\\", "/") for p in files[:20]],
    }


@router.get("")
def list_outputs(request: Request) -> dict[str, Any]:
    """Everything currently stored, newest first, plus the total footprint."""
    root = _root(request)
    if not root.is_dir():
        return {"root": str(root), "total_bytes": 0, "entries": []}
    entries = [_describe(e, root) for e in root.iterdir()]
    entries.sort(key=lambda d: d["modified"], reverse=True)
    return {"root": str(root),
            "total_bytes": sum(e["bytes"] for e in entries),
            "entries": entries}


@router.delete("/{name}")
def delete_output(name: str, request: Request) -> dict[str, Any]:
    """Remove one entry (a file, or an export folder and its contents)."""
    root = _root(request)
    target = _safe(root, name)
    if not target.exists():
        raise HTTPException(status_code=404, detail="not found")
    freed = _describe(target, root)["bytes"]
    if target.is_dir():
        shutil.rmtree(target)
    else:
        target.unlink()
    log.info("deleted output %s (%d bytes)", name, freed)
    return {"name": name, "freed_bytes": freed}


@router.delete("")
def delete_all_outputs(request: Request, confirm: bool = False) -> dict[str, Any]:
    """Clear the whole output directory.

    `confirm=true` is required. Without it this is reachable by accident:
    Starlette normalises `DELETE /api/outputs/.` to `/api/outputs/`, which
    redirects here — so a URL that reads like "delete the entry named ."
    would otherwise wipe everything. The UI also asks twice.
    """
    if not confirm:
        raise HTTPException(
            status_code=400,
            detail="pass confirm=true to clear the whole output directory")
    root = _root(request)
    if not root.is_dir():
        return {"deleted": 0, "freed_bytes": 0}
    entries = list(root.iterdir())
    freed = sum(_describe(e, root)["bytes"] for e in entries)
    for e in entries:
        shutil.rmtree(e) if e.is_dir() else e.unlink()
    log.info("cleared output dir: %d entries, %d bytes", len(entries), freed)
    return {"deleted": len(entries), "freed_bytes": freed}
