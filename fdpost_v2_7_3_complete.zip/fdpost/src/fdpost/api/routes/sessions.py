"""Named work sessions (restorable UI state) and read-only share snapshots."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request

from fdpost.domain.requests import SessionIn, SnapshotIn

router = APIRouter(prefix="/api", tags=["sessions"])


@router.get("/sessions")
def list_sessions(request: Request):
    return request.app.state.registry.list_sessions("session")


@router.post("/sessions")
def save_session(request: Request, body: SessionIn,
                 session_id: str | None = None):
    sid = request.app.state.registry.save_session(
        "session", body.name, body.dataset_id, body.state, session_id)
    return {"id": sid}


@router.get("/sessions/{session_id}")
def get_session(request: Request, session_id: str):
    row = request.app.state.registry.get_session(session_id)
    if row is None or row["kind"] != "session":
        raise HTTPException(status_code=404, detail="session not found")
    return row


@router.delete("/sessions/{session_id}")
def delete_session(request: Request, session_id: str):
    request.app.state.registry.delete_session(session_id)
    return {"deleted": session_id}


@router.post("/snapshots")
def create_snapshot(request: Request, body: SnapshotIn):
    token = request.app.state.registry.save_session(
        "snapshot", "", body.dataset_id, body.state)
    return {"token": token}


@router.get("/snapshots/{token}")
def get_snapshot(request: Request, token: str):
    row = request.app.state.registry.get_session(token)
    if row is None or row["kind"] != "snapshot":
        raise HTTPException(status_code=404, detail="snapshot not found")
    return {"dataset_id": row["dataset_id"], "state": row["state"],
            "created_at": row["created_at"]}
