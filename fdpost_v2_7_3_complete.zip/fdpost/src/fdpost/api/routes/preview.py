"""3D preview endpoints for the browser front-end."""
from __future__ import annotations

import json

import numpy as np
from fastapi import APIRouter, Request, Response

from fdpost.core.query import AXIS_INDEX, IN_PLANE

router = APIRouter(prefix="/api/datasets/{ds_id}/preview", tags=["preview"])


@router.get("/meta")
def preview_meta(ds_id: str, request: Request, max_dim: int = 0):
    settings = request.app.state.settings
    grid = request.app.state.store.get_grid(ds_id)
    g = grid.downsample(max_dim or settings.preview_res)
    return {"dims": list(g.dims), "origin": g.origin.tolist(),
            "spacing": g.spacing.tolist(), "bounds": g.bounds.tolist(),
            "fields": sorted(g.arrays), "units": g.units,
            "full_dims": list(grid.dims)}


@router.get("/volume/{field}")
def preview_volume(ds_id: str, field: str, request: Request, max_dim: int = 0):
    """Binary float32 volume, Fortran (column-major) order, solid = NaN.
    Header-free: client knows dims from /meta."""
    settings = request.app.state.settings
    grid = request.app.state.store.get_grid(ds_id)
    g = grid.downsample(max_dim or settings.preview_res)
    arr = g.masked(field).astype(np.float32)
    return Response(content=arr.ravel(order="F").tobytes(),
                    media_type="application/octet-stream",
                    headers={"X-Dims": ",".join(map(str, g.dims))})


@router.get("/points/{field}")
def preview_points(ds_id: str, field: str, request: Request, max_points: int = 0):
    """Binary point cloud: coords (M,3) float32 then values (M,) float32
    concatenated. M = byteLength / 16."""
    settings = request.app.state.settings
    grid = request.app.state.store.get_grid(ds_id)
    coords, ii = grid.fluid_voxel_points(max_points or settings.point_cloud_cap)
    vals = grid.arrays[field][ii[:, 0], ii[:, 1], ii[:, 2]].astype(np.float32)
    finite = np.isfinite(vals)
    coords, vals = coords[finite], vals[finite]
    payload = coords.astype(np.float32).tobytes() + vals.tobytes()
    return Response(content=payload, media_type="application/octet-stream",
                    headers={"X-Count": str(int(vals.shape[0]))})


@router.get("/solid_points")
def preview_solid_points(ds_id: str, request: Request, max_points: int = 0):
    """Solid voxel centres: coords (M,3) float32, nothing else.

    Deliberately value-free — a solid cell has no field data, so colouring it
    from the colormap would be inventing numbers. The client draws these as a
    neutral grey shell.
    """
    settings = request.app.state.settings
    grid = request.app.state.store.get_grid(ds_id)
    coords, _ = grid.voxel_points(max_points or settings.point_cloud_cap,
                                  solid=True)
    return Response(content=coords.astype(np.float32).tobytes(),
                    media_type="application/octet-stream",
                    headers={"X-Count": str(int(coords.shape[0]))})


@router.get("/slice/{field}")
def preview_slice(ds_id: str, field: str, request: Request,
                  axis: str = "z", position: float = 0.0,
                  with_vectors: bool = False, max_dim: int = 0):
    """Axis-orthogonal slice at **full grid resolution** (the drawer preview
    used to be limited to the downsampled point-cloud grid).

    Body: f32 values, then — when vectors are available and requested —
    f32 vec_u and f32 vec_v. Every array is row-major [iv * nu + iu], i.e.
    rows = the plot's vertical axis, ready for a Plotly heatmap.
    Metadata (dims/origin/spacing/labels) rides in the X-Meta JSON header.
    """
    grid = request.app.state.store.get_grid(ds_id)
    if max_dim:                      # optional cap for very large grids
        grid = grid.downsample(max_dim)
    ai = AXIS_INDEX[axis]
    ua, va = IN_PLANE[axis]
    ui, vi = AXIS_INDEX[ua], AXIS_INDEX[va]
    k = int(np.clip(round((position - grid.origin[ai]) / grid.spacing[ai]),
                    0, grid.dims[ai] - 1))
    plane = [slice(None)] * 3
    plane[ai] = k
    tp = tuple(plane)

    def slab(name: str) -> np.ndarray:
        """(nu,nv) slab -> row-major [iv][iu] float32 for the plot."""
        return np.ascontiguousarray(
            grid.masked(name)[tp].T.astype(np.float32))

    values = slab(field)
    payload = values.tobytes()
    vec_names = (f"velocity_{ua}", f"velocity_{va}")
    has_vec = with_vectors and all(n in grid.arrays for n in vec_names)
    if has_vec:
        payload += slab(vec_names[0]).tobytes() + slab(vec_names[1]).tobytes()
    meta = {
        "axis": axis, "index": k,
        "position": float(grid.origin[ai] + grid.spacing[ai] * k),
        "dims": [int(grid.dims[ui]), int(grid.dims[vi])],
        "origin": [float(grid.origin[ui]), float(grid.origin[vi])],
        "spacing": [float(grid.spacing[ui]), float(grid.spacing[vi])],
        "labels": [f"{ua.upper()} [m]", f"{va.upper()} [m]"],
        "unit": grid.units.get(field, ""), "vectors": bool(has_vec),
        "full_dims": [int(d) for d in grid.dims],
    }
    return Response(content=payload, media_type="application/octet-stream",
                    headers={"X-Meta": json.dumps(meta)})


@router.get("/vectors")
def preview_vectors(ds_id: str, request: Request,
                    max_dim: int = 0, max_points: int = 0):
    """Velocity glyph seeds on a coarse regular lattice of fluid voxels.

    Body: f32 coords (M,3) then f32 vectors (M,3). A regular lattice (rather
    than the random point-cloud subsample) is what makes the arrow field read
    as a flow field instead of noise.
    """
    settings = request.app.state.settings
    grid = request.app.state.store.get_grid(ds_id)
    g = grid.downsample(max_dim or settings.vector_glyph_dim)
    names = ("velocity_x", "velocity_y", "velocity_z")
    if not all(n in g.arrays for n in names):
        return Response(content=b"", media_type="application/octet-stream",
                        headers={"X-Count": "0", "X-Speed-Max": "0"})
    coords, ii = g.fluid_voxel_points(max_points or settings.vector_glyph_cap)
    vec = np.column_stack([g.arrays[n][ii[:, 0], ii[:, 1], ii[:, 2]]
                           for n in names]).astype(np.float32)
    ok = np.isfinite(vec).all(axis=1)
    coords, vec = coords[ok].astype(np.float32), vec[ok]
    speed = np.linalg.norm(vec, axis=1) if len(vec) else np.zeros(0)
    return Response(content=coords.tobytes() + vec.tobytes(),
                    media_type="application/octet-stream",
                    headers={"X-Count": str(int(coords.shape[0])),
                             "X-Speed-Max": repr(float(speed.max()) if len(speed) else 0.0)})


def _plane_axes(grid, axis: str):
    ai = AXIS_INDEX[axis]
    ua, va = IN_PLANE[axis]
    return ai, AXIS_INDEX[ua], AXIS_INDEX[va], ua, va


@router.get("/slice_native/{field}")
def slice_native(ds_id: str, field: str, request: Request,
                 axis: str = "z", position: float = 0.0):
    """The resolution this slice can actually support.

    Point density near the plane sets a hard information limit; asking for
    more pixels than this yields a bigger but not a more informative picture.
    The UI marks this value on the resolution slider.
    """
    grid = request.app.state.store.get_grid(ds_id)
    sampler = request.app.state.store.get_sampler(ds_id)
    ai, ui, vi, _, _ = _plane_axes(grid, axis)
    lo, hi = grid.bounds
    origin = np.array(grid.bounds.mean(axis=0))
    origin[ai] = float(np.clip(position, lo[ai], hi[ai]))
    normal = np.zeros(3); normal[ai] = 1.0
    u_hat = np.zeros(3); u_hat[ui] = 1.0
    v_hat = np.zeros(3); v_hat[vi] = 1.0
    slab = sampler.plane_slab(origin, normal, u_hat, v_hat, fields=[field])
    native = slab.native_px(float(hi[ui] - lo[ui]), float(hi[vi] - lo[vi]))
    return {"native_px": native, "grid_px": int(max(grid.dims)),
            "slab_points": slab.n_points, "point_pitch": sampler.pitch,
            "n_source_points": sampler.n_points}


@router.get("/slice_direct/{field}")
def preview_slice_direct(ds_id: str, field: str, request: Request,
                         axis: str = "z", position: float = 0.0,
                         res: int = 512, with_vectors: bool = False,
                         mode: str = "hifi"):
    """Axis slice sampled straight from the scattered source file.

    Lifts the preprocessing grid's resolution ceiling: cost scales with the
    number of pixels, not the cube of a volume, so a coarse (fast)
    preprocessing run can still produce a fine slice.

    mode:
      hifi — gather the source points near the plane, triangulate them in 2D,
             interpolate linearly. Smooth gradients, and faster than 3D.
      idw  — 3D inverse-distance from the whole cloud. Kept as a fallback for
             pathological geometry; it plateaus around each data point, which
             is what makes a slice look blocky.
    Same wire format as /preview/slice/{field} so the client can swap freely.
    """
    settings = request.app.state.settings
    grid = request.app.state.store.get_grid(ds_id)
    sampler = request.app.state.store.get_sampler(ds_id)
    ai, ui, vi, ua, va = _plane_axes(grid, axis)

    lo, hi = grid.bounds
    n = int(np.clip(res, 16, settings.slice_direct_max_px))
    # keep pixels square: split the requested budget along the longer side
    span_u, span_v = float(hi[ui] - lo[ui]), float(hi[vi] - lo[vi])
    if span_u >= span_v:
        nu, nv = n, max(16, int(round(n * span_v / max(span_u, 1e-12))))
    else:
        nv, nu = n, max(16, int(round(n * span_u / max(span_v, 1e-12))))

    u = np.linspace(lo[ui], hi[ui], nu)
    v = np.linspace(lo[vi], hi[vi], nv)
    gv, gu = np.meshgrid(v, u, indexing="ij")          # rows = v, cols = u
    pts = np.empty((nu * nv, 3), dtype=np.float64)
    pts[:, ui] = gu.ravel()
    pts[:, vi] = gv.ravel()
    pts[:, ai] = float(np.clip(position, lo[ai], hi[ai]))

    vec_names = (f"velocity_{ua}", f"velocity_{va}")
    has_vec = with_vectors and all(n_ in sampler.fd.fields for n_ in vec_names)
    wanted = [field] + ([*vec_names] if has_vec else [])

    if mode == "hifi":
        origin = np.array(grid.bounds.mean(axis=0))
        origin[ai] = float(pts[0, ai])
        normal = np.zeros(3); normal[ai] = 1.0
        u_hat = np.zeros(3); u_hat[ui] = 1.0
        v_hat = np.zeros(3); v_hat[vi] = 1.0
        slab_data = sampler.plane_slab(origin, normal, u_hat, v_hat,
                                       fields=wanted)
        itp = sampler.plane_interpolator(slab_data)
        uv = np.column_stack([pts[:, ui] - origin[ui], pts[:, vi] - origin[vi]])
        solid = itp.solid(uv)
        native = slab_data.native_px(float(hi[ui] - lo[ui]),
                                     float(hi[vi] - lo[vi]))

        def slab(name: str) -> np.ndarray:
            vals = itp.sample(name, uv).astype(np.float32)
            vals[solid] = np.nan
            return np.ascontiguousarray(vals)
    else:
        solid = sampler.solid(pts)
        native = 0

        def slab(name: str) -> np.ndarray:
            vals = sampler.sample(name, pts).astype(np.float32)
            vals[solid] = np.nan                        # solid stays a hole
            return np.ascontiguousarray(vals)

    payload = slab(field).tobytes()
    if has_vec:
        payload += slab(vec_names[0]).tobytes() + slab(vec_names[1]).tobytes()
    meta = {
        "axis": axis, "index": -1, "position": float(pts[0, ai]),
        "dims": [nu, nv],
        "origin": [float(u[0]), float(v[0])],
        "spacing": [float(u[1] - u[0]) if nu > 1 else 0.0,
                    float(v[1] - v[0]) if nv > 1 else 0.0],
        "labels": [f"{ua.upper()} [m]", f"{va.upper()} [m]"],
        "unit": grid.units.get(field, ""), "vectors": bool(has_vec),
        "full_dims": [int(d) for d in grid.dims],
        "source": "scatter", "n_source_points": sampler.n_points,
        "mode": mode, "native_px": int(native),
    }
    return Response(content=payload, media_type="application/octet-stream",
                    headers={"X-Meta": json.dumps(meta)})
