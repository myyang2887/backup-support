"""SQLite persistence: dataset registry + sessions/share-snapshots.

Single-file DB (WAL) guarded by a lock: FastAPI's threadpool and the Job
workers may touch it concurrently, but traffic is tiny (metadata only)."""
from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_SCHEMA = """
CREATE TABLE IF NOT EXISTS datasets (
  id TEXT PRIMARY KEY,
  payload TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('session', 'snapshot')),
  name TEXT NOT NULL DEFAULT '',
  dataset_id TEXT NOT NULL,
  state TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Registry:
    def __init__(self, db_path: str | Path) -> None:
        db_path = Path(db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(_SCHEMA)
        self._conn.commit()
        self._lock = threading.Lock()

    # -- datasets ----------------------------------------------------------
    def upsert_dataset(self, ds_id: str, payload: dict[str, Any]) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT INTO datasets(id, payload, updated_at) VALUES(?,?,?) "
                "ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, "
                "updated_at=excluded.updated_at",
                (ds_id, json.dumps(payload, ensure_ascii=False), _now()))
            self._conn.commit()

    def load_datasets(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT payload FROM datasets ORDER BY updated_at").fetchall()
        return [json.loads(r[0]) for r in rows]

    def delete_dataset(self, ds_id: str) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM datasets WHERE id=?", (ds_id,))
            self._conn.commit()

    # -- sessions / snapshots ---------------------------------------------
    def save_session(self, kind: str, name: str, dataset_id: str,
                     state: dict[str, Any], session_id: str | None = None) -> str:
        sid = session_id or uuid.uuid4().hex[:16]
        now = _now()
        with self._lock:
            self._conn.execute(
                "INSERT INTO sessions(id, kind, name, dataset_id, state, "
                "created_at, updated_at) VALUES(?,?,?,?,?,?,?) "
                "ON CONFLICT(id) DO UPDATE SET name=excluded.name, "
                "dataset_id=excluded.dataset_id, state=excluded.state, "
                "updated_at=excluded.updated_at",
                (sid, kind, name, dataset_id,
                 json.dumps(state, ensure_ascii=False), now, now))
            self._conn.commit()
        return sid

    def list_sessions(self, kind: str) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, name, dataset_id, created_at, updated_at "
                "FROM sessions WHERE kind=? ORDER BY updated_at DESC",
                (kind,)).fetchall()
        return [dict(zip(("id", "name", "dataset_id", "created_at", "updated_at"), r))
                for r in rows]

    def get_session(self, session_id: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT id, kind, name, dataset_id, state, created_at, updated_at "
                "FROM sessions WHERE id=?", (session_id,)).fetchone()
        if row is None:
            return None
        d = dict(zip(("id", "kind", "name", "dataset_id", "state",
                      "created_at", "updated_at"), row))
        d["state"] = json.loads(d["state"])
        return d

    def delete_session(self, session_id: str) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM sessions WHERE id=?", (session_id,))
            self._conn.commit()

    def close(self) -> None:
        with self._lock:
            self._conn.close()
