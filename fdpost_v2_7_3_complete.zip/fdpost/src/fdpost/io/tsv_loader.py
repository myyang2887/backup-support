"""FloEFD table -> FieldData, robust to real export quirks:
UTF-8 BOM, CRLF, trailing tab per row (ghost 'Unnamed' column),
units in [..] with '^', missing values on solid rows, variable column set."""
from __future__ import annotations

import re
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd

from fdpost.core.solid_classify import classify_fluid
from fdpost.domain.errors import DataLoadError
from fdpost.domain.field_data import FieldData
from fdpost.domain.requests import FluidRule

COLUMN_ALIASES: dict[str, str] = {
    "x": "x", "y": "y", "z": "z",
    "pressure": "pressure", "圧力": "pressure",
    "temperature": "temperature", "温度": "temperature",
    "density": "density", "密度": "density",
    "velocity": "velocity_magnitude", "速度": "velocity_magnitude",
    "velocityx": "velocity_x", "velocity(x)": "velocity_x", "速度(x)": "velocity_x",
    "velocityy": "velocity_y", "velocity(y)": "velocity_y", "速度(y)": "velocity_y",
    "velocityz": "velocity_z", "velocity(z)": "velocity_z", "速度(z)": "velocity_z",
    "volume": "volume", "体積": "volume",
    "surface": "surface", "surfacearea": "surface", "表面積": "surface",
    "solid": "solid", "fluid": "fluid", "celltype": "cell_type", "phase": "phase",
}

_UNIT_RE = re.compile(r"^(.*?)\s*[\(\[]([^\(\)\[\]]*)[\)\]]\s*$")


def split_name_unit(header: str) -> tuple[str, str]:
    """'Velocity (X) (m/s)' -> ('Velocity (X)','m/s'); 'Volume [m^3]' -> ('Volume','m^3')."""
    m = _UNIT_RE.fullmatch(header.strip())
    if m:
        return m.group(1).strip(), m.group(2).strip()
    return header.strip(), ""


def canonical_name(raw_name: str) -> str:
    lowered = unicodedata.normalize("NFKC", raw_name).lower()
    s = re.sub(r"\s+", "", lowered)
    if s in COLUMN_ALIASES:
        return COLUMN_ALIASES[s]
    s2 = re.sub(r"[\(\)\[\]]", "", s)
    if s2 in COLUMN_ALIASES:
        return COLUMN_ALIASES[s2]
    slug = re.sub(r"[^a-z0-9]+", "_", lowered).strip("_")  # keep word boundaries
    return slug or "col"


def detect_delimiter(first_line: str) -> str:
    if "\t" in first_line:
        return "\t"
    if "," in first_line:
        return ","
    raise DataLoadError("cannot detect delimiter (no tab or comma in header)")


def load_floefd_table(path: str | Path,
                      alias_overrides: dict[str, str] | None = None,
                      fluid_rule: FluidRule | None = None) -> FieldData:
    path = Path(path)
    if not path.exists():
        raise DataLoadError(f"file not found: {path}")
    with open(path, encoding="utf-8-sig") as f:
        first = f.readline().rstrip("\r\n")
    delim = detect_delimiter(first)
    try:
        df = pd.read_csv(path, sep=delim, encoding="utf-8-sig")
    except Exception as e:
        raise DataLoadError(f"failed to parse {path.name}: {e}") from e

    # drop ghost columns from trailing separators + fully empty columns
    df = df.loc[:, ~df.columns.astype(str).str.match(r"^Unnamed")]
    df = df.dropna(axis=1, how="all")

    n_raw = len(df)
    units: dict[str, str] = {}
    rename: dict[str, str] = {}
    seen: set[str] = set()
    overrides = alias_overrides or {}
    for col in df.columns:
        name, unit = split_name_unit(str(col))
        cn = overrides.get(name, canonical_name(name))
        while cn in seen:
            cn += "_2"
        seen.add(cn)
        rename[col] = cn
        units[cn] = unit
    df = df.rename(columns=rename)

    missing = [c for c in ("x", "y", "z") if c not in df.columns]
    if missing:
        raise DataLoadError(
            f"missing coordinate column(s) {missing}; parsed columns: {list(df.columns)}"
        )

    for c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    coord_ok = df[["x", "y", "z"]].notna().all(axis=1)
    n_dropped = int((~coord_ok).sum())
    df = df.loc[coord_ok].reset_index(drop=True)

    pts = df[["x", "y", "z"]].to_numpy(dtype=np.float64)
    _, first_idx = np.unique(pts.round(12), axis=0, return_index=True)
    keep = np.sort(first_idx)
    n_duplicates = len(df) - len(keep)
    df = df.iloc[keep].reset_index(drop=True)
    pts = pts[keep]

    if len(df) < 4:
        raise DataLoadError(f"too few valid points ({len(df)}) after cleaning")

    field_cols = [c for c in df.columns if c not in ("x", "y", "z")]
    rule = fluid_rule or FluidRule()
    is_fluid, rule_used = classify_fluid(df, field_cols, units, rule)

    if {"velocity_x", "velocity_y", "velocity_z"} <= set(field_cols) \
            and "velocity_magnitude" not in field_cols:
        vx = df["velocity_x"].to_numpy(); vy = df["velocity_y"].to_numpy()
        vz = df["velocity_z"].to_numpy()
        df["velocity_magnitude"] = np.sqrt(vx * vx + vy * vy + vz * vz)
        units["velocity_magnitude"] = units.get("velocity_x", "")
        field_cols.append("velocity_magnitude")

    units.setdefault("x", "m"); units.setdefault("y", "m"); units.setdefault("z", "m")
    fields = {c: df[c].to_numpy(dtype=np.float64) for c in field_cols}
    meta = {
        "source_path": str(path), "n_raw_rows": n_raw, "n_dropped": n_dropped,
        "n_duplicates": int(n_duplicates), "n_fluid": int(is_fluid.sum()),
        "n_solid": int((~is_fluid).sum()), "fluid_rule_used": rule_used,
    }
    return FieldData(points=pts, fields=fields, is_fluid=is_fluid,
                     units=units, meta=meta)
