"""UniformGrid <-> compressed npz cache with signature validation.

CACHE_VERSION bump invalidates all old caches. Corrupt/incompatible files are
deleted and rebuilt (CacheError is internal; callers treat it as cache miss)."""
from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path

import numpy as np

from fdpost.domain.errors import CacheError
from fdpost.domain.uniform_grid import UniformGrid

log = logging.getLogger("fdpost.io.grid_cache")

CACHE_VERSION = 2
_HEAD = 65536


def source_signature(path: str | Path) -> str:
    """Cheap file signature: size + mtime_ns + sha256(first/last 64KB)."""
    p = Path(path)
    st = p.stat()
    h = hashlib.sha256()
    with open(p, "rb") as f:
        h.update(f.read(_HEAD))
        if st.st_size > 2 * _HEAD:
            f.seek(-_HEAD, 2)
            h.update(f.read(_HEAD))
    return f"{st.st_size}-{st.st_mtime_ns}-{h.hexdigest()[:16]}"


def cache_key(signature: str, config_repr: str) -> str:
    return hashlib.sha256(f"v{CACHE_VERSION}|{signature}|{config_repr}".encode()).hexdigest()[:24]


def save_grid(grid: UniformGrid, path: str | Path) -> None:
    """Atomic write: tmp file then os.replace."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp.npz")
    payload = {
        "__version__": np.array([CACHE_VERSION], dtype=np.int64),
        "origin": grid.origin, "spacing": grid.spacing,
        "dims": np.array(grid.dims, dtype=np.int64),
        "solid_mask": grid.solid_mask,
        "units_json": np.frombuffer(json.dumps(grid.units).encode(), dtype=np.uint8),
        "meta_json": np.frombuffer(json.dumps(grid.meta, default=str).encode(), dtype=np.uint8),
        "field_names_json": np.frombuffer(
            json.dumps(list(grid.arrays)).encode(), dtype=np.uint8),
    }
    for name, arr in grid.arrays.items():
        payload[f"field__{name}"] = arr
    np.savez_compressed(tmp, **payload)
    tmp.replace(path)


def load_grid(path: str | Path) -> UniformGrid:
    """Load; on any corruption/version mismatch delete the file and raise CacheError."""
    path = Path(path)
    try:
        with np.load(path, allow_pickle=False) as z:
            ver = int(z["__version__"][0])
            if ver != CACHE_VERSION:
                raise CacheError(f"cache version {ver} != {CACHE_VERSION}")
            units = json.loads(bytes(z["units_json"]).decode())
            meta = json.loads(bytes(z["meta_json"]).decode())
            names = json.loads(bytes(z["field_names_json"]).decode())
            arrays = {n: z[f"field__{n}"] for n in names}
            return UniformGrid(
                origin=z["origin"], spacing=z["spacing"],
                dims=tuple(int(d) for d in z["dims"]),
                arrays=arrays, solid_mask=z["solid_mask"],
                units=units, meta=meta,
            )
    except CacheError:
        path.unlink(missing_ok=True)
        raise
    except Exception as e:
        log.warning("corrupt cache %s (%s); deleting for rebuild", path.name, e)
        path.unlink(missing_ok=True)
        raise CacheError(f"corrupt cache {path.name}: {e}") from e
