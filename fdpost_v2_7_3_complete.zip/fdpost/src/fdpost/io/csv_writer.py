"""CSV export (Excel-friendly utf-8-sig) + sidecar .meta.json with units."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


def write_csv(df: pd.DataFrame, path: str | Path,
              units: dict[str, str] | None = None) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8-sig")
    if units is not None:
        meta = {"columns": list(df.columns),
                "units": {c: units.get(c.removesuffix("_m"), units.get(c, ""))
                          for c in df.columns},
                "n_rows": int(len(df))}
        path.with_suffix(path.suffix + ".meta.json").write_text(
            json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return path
