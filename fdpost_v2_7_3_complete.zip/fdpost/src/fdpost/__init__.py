"""fdpost: FloEFD post-processing and visualization toolkit."""
__version__ = "2.1.0"
