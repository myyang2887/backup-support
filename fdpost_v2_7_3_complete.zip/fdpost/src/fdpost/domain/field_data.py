"""FieldData: immutable scattered-point domain object + field role classification."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from fdpost.domain.errors import DataLoadError, FieldNotFoundError

FIELD_ROLE: dict[str, set[str]] = {
    "scalar_field": {"velocity_magnitude", "pressure", "temperature", "density"},
    "vector_component": {"velocity_x", "velocity_y", "velocity_z"},
    "metadata": {"volume", "surface"},
}


def field_role(name: str) -> str:
    """Return 'scalar_field' | 'vector_component' | 'metadata' | 'unknown'."""
    for role, names in FIELD_ROLE.items():
        if name in names:
            return role
    return "unknown"


@dataclass(frozen=True)
class FieldData:
    """FloEFD scattered-point data (immutable).

    points   : (N,3) float64 world coordinates [m]
    fields   : {canonical_name: (N,) float64}
    is_fluid : (N,) bool, True = fluid point
    units    : {name: unit string}; coordinates are always "m"
    meta     : free dict (source path, counts, fluid_rule_used, ...)
    """

    points: np.ndarray
    fields: dict[str, np.ndarray]
    is_fluid: np.ndarray
    units: dict[str, str]
    meta: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        pts = np.asarray(self.points, dtype=np.float64)
        if pts.ndim != 2 or pts.shape[1] != 3:
            raise DataLoadError(f"points must be (N,3), got {pts.shape}")
        bad = ~np.isfinite(pts)
        if bad.any():
            rows = np.unique(np.where(bad)[0])[:5]
            raise DataLoadError(f"points contain NaN/Inf at rows {rows.tolist()}")
        object.__setattr__(self, "points", pts)
        n = pts.shape[0]
        fixed: dict[str, np.ndarray] = {}
        for name, arr in self.fields.items():
            a = np.asarray(arr, dtype=np.float64)
            if a.shape != (n,):
                raise DataLoadError(f"field '{name}' length {a.shape} != N={n}")
            fixed[name] = a
        object.__setattr__(self, "fields", fixed)
        fl = np.asarray(self.is_fluid, dtype=bool)
        if fl.shape != (n,):
            raise DataLoadError(f"is_fluid shape {fl.shape} != ({n},)")
        object.__setattr__(self, "is_fluid", fl)

    @property
    def n_points(self) -> int:
        return int(self.points.shape[0])

    @property
    def bounds(self) -> np.ndarray:
        """(2,3): [[xmin,ymin,zmin],[xmax,ymax,zmax]]."""
        return np.stack([self.points.min(axis=0), self.points.max(axis=0)])

    def field_names(self) -> list[str]:
        return list(self.fields.keys())

    def require(self, name: str) -> np.ndarray:
        if name not in self.fields:
            raise FieldNotFoundError(
                f"field '{name}' not found; available: {sorted(self.fields)}"
            )
        return self.fields[name]
