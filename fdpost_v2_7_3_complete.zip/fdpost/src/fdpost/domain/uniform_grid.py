"""UniformGrid: the cached uniform structured grid (core domain object)."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np
from scipy import ndimage

from fdpost.domain.errors import FieldNotFoundError, GridBuildError


@dataclass
class UniformGrid:
    """Uniform structured grid. `origin` is the center of voxel (0,0,0).

    arrays[name] has shape (nx,ny,nz) float32, indexed [ix,iy,iz] (x-axis first).
    """

    origin: np.ndarray            # (3,) float64
    spacing: np.ndarray           # (3,) float64, all > 0
    dims: tuple[int, int, int]    # (nx,ny,nz), each >= 2
    arrays: dict[str, np.ndarray]
    solid_mask: np.ndarray        # (nx,ny,nz) bool, True = solid
    units: dict[str, str]
    meta: dict[str, Any]

    def __post_init__(self) -> None:
        self.origin = np.asarray(self.origin, dtype=np.float64).reshape(3)
        self.spacing = np.asarray(self.spacing, dtype=np.float64).reshape(3)
        if not np.all(self.spacing > 0):
            raise GridBuildError(f"spacing must be > 0, got {self.spacing}")
        self.dims = tuple(int(d) for d in self.dims)  # type: ignore[assignment]
        if len(self.dims) != 3 or any(d < 2 for d in self.dims):
            raise GridBuildError(f"dims must be 3 values >= 2, got {self.dims}")
        for name, a in self.arrays.items():
            if a.shape != self.dims:
                raise GridBuildError(f"array '{name}' shape {a.shape} != dims {self.dims}")
            if a.dtype != np.float32:
                self.arrays[name] = a.astype(np.float32)
        if self.solid_mask.shape != self.dims:
            raise GridBuildError("solid_mask shape mismatch")
        self.solid_mask = self.solid_mask.astype(bool)

    @property
    def bounds(self) -> np.ndarray:
        """(2,3): voxel-center range [origin, origin + spacing*(dims-1)]."""
        hi = self.origin + self.spacing * (np.array(self.dims) - 1)
        return np.stack([self.origin, hi])

    def axis_coords(self, axis: int) -> np.ndarray:
        n = self.dims[axis]
        return self.origin[axis] + self.spacing[axis] * np.arange(n, dtype=np.float64)

    def world_to_index(self, pts: np.ndarray) -> np.ndarray:
        """(M,3) world coords -> (3,M) float64 fractional indices."""
        pts = np.asarray(pts, dtype=np.float64)
        return ((pts - self.origin) / self.spacing).T

    def masked(self, name: str) -> np.ndarray:
        """float64 copy with solid voxels set to NaN."""
        if name not in self.arrays:
            raise FieldNotFoundError(
                f"field '{name}' not in grid; available: {sorted(self.arrays)}"
            )
        arr = self.arrays[name].astype(np.float64)
        arr[self.solid_mask] = np.nan
        return arr

    def sample(self, name: str, pts: np.ndarray, mask_mode: str = "nan") -> np.ndarray:
        """Trilinear sampling at arbitrary world points. Out-of-bounds -> NaN."""
        arr = self.masked(name) if mask_mode == "nan" else self.arrays[name].astype(np.float64)
        idx = self.world_to_index(pts)
        return ndimage.map_coordinates(
            arr, idx, order=1, mode="constant", cval=np.nan, prefilter=False
        )

    def sample_solid(self, pts: np.ndarray) -> np.ndarray:
        """(M,) bool: nearest voxel is solid. Out-of-bounds points count as solid."""
        frac = self.world_to_index(pts)              # (3,M)
        dims = np.array(self.dims, dtype=np.float64).reshape(3, 1)
        out = np.any((frac < -0.5) | (frac > dims - 0.5), axis=0)
        idx = np.clip(np.round(frac).astype(np.int64), 0,
                      (dims - 1).astype(np.int64))
        solid = self.solid_mask[idx[0], idx[1], idx[2]]
        return solid | out

    def downsample(self, max_dim: int) -> UniformGrid:
        """Stride-slice downsample so the longest axis has <= max_dim voxels."""
        stride = max(1, math.ceil(max(self.dims) / max_dim))
        if stride == 1:
            return self
        arrays = {k: v[::stride, ::stride, ::stride].copy() for k, v in self.arrays.items()}
        solid = self.solid_mask[::stride, ::stride, ::stride].copy()
        dims = solid.shape
        return UniformGrid(
            origin=self.origin.copy(),
            spacing=self.spacing * stride,
            dims=dims,  # type: ignore[arg-type]
            arrays=arrays,
            solid_mask=solid,
            units=dict(self.units),
            meta={**self.meta, "downsampled_stride": stride},
        )

    def voxel_points(self, max_points: int, *, solid: bool = False
                     ) -> tuple[np.ndarray, np.ndarray]:
        """(coords (M,3) float64, voxel_index (M,3) int64) of fluid — or solid —
        voxel centers; uniformly subsampled with rng(seed=0) if M > max_points.
        The fixed seed means repeated calls return the same subset, so several
        per-voxel queries stay aligned."""
        ii = np.argwhere(self.solid_mask if solid else ~self.solid_mask)
        if ii.shape[0] > max_points:
            sel = np.random.default_rng(0).choice(ii.shape[0], max_points, replace=False)
            ii = ii[np.sort(sel)]
        coords = self.origin + ii * self.spacing
        return coords, ii

    def fluid_voxel_points(self, max_points: int) -> tuple[np.ndarray, np.ndarray]:
        """Fluid voxel centers. Kept as the name existing callers use."""
        return self.voxel_points(max_points)
