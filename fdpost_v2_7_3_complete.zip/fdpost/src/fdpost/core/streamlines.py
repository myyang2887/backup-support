"""Streamline tracing on the cached uniform grid.

Vectorized RK4 with unit-tangent (arc-length) stepping: every seed advances a
fixed spatial distance per step, which keeps line quality independent of local
speed. Solid regions carry NaN velocity, so lines terminate there naturally.
"""
from __future__ import annotations

import numpy as np

from fdpost.domain.errors import FieldNotFoundError
from fdpost.domain.uniform_grid import UniformGrid

VELOCITY_COMPONENTS = ("velocity_x", "velocity_y", "velocity_z")


def _unit_dir(grid: UniformGrid, pts: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """(M,3) points -> (unit direction (M,3), speed (M,)); NaN when undefined."""
    v = np.column_stack([grid.sample(c, pts) for c in VELOCITY_COMPONENTS])
    speed = np.linalg.norm(v, axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        u = v / speed[:, None]
    return u, speed


def _trace_one_way(grid: UniformGrid, seeds: np.ndarray, sign: float, h: float,
                   max_steps: int, min_speed: float
                   ) -> list[tuple[np.ndarray, np.ndarray]]:
    m = seeds.shape[0]
    pos = seeds.astype(np.float64).copy()
    _, s0 = _unit_dir(grid, pos)
    alive = np.isfinite(s0) & (s0 > min_speed)
    traj = [pos.copy()]
    spd = [np.where(alive, s0, np.nan)]
    for _ in range(max_steps):
        if not alive.any():
            break
        k1, _ = _unit_dir(grid, pos)
        k2, _ = _unit_dir(grid, pos + sign * (h / 2) * np.nan_to_num(k1))
        k3, _ = _unit_dir(grid, pos + sign * (h / 2) * np.nan_to_num(k2))
        k4, _ = _unit_dir(grid, pos + sign * h * np.nan_to_num(k3))
        d = (k1 + 2 * k2 + 2 * k3 + k4) / 6.0
        norm = np.linalg.norm(d, axis=1)
        new_pos = pos + sign * h * d / np.maximum(norm, 1e-12)[:, None]
        _, s_new = _unit_dir(grid, new_pos)
        step_ok = (alive & np.isfinite(norm) & (norm > 1e-12)
                   & np.isfinite(s_new) & (s_new > min_speed))
        pos = np.where(step_ok[:, None], new_pos, pos)
        traj.append(pos.copy())
        spd.append(np.where(step_ok, s_new, np.nan))
        alive = step_ok
    positions = np.stack(traj)          # (T, M, 3)
    speeds = np.stack(spd)              # (T, M)
    lines: list[tuple[np.ndarray, np.ndarray]] = []
    for i in range(m):
        invalid = ~np.isfinite(speeds[:, i])
        cut = int(np.argmax(invalid)) if invalid.any() else speeds.shape[0]
        if cut >= 2:
            lines.append((positions[:cut, i].copy(), speeds[:cut, i].copy()))
        else:
            lines.append((np.empty((0, 3)), np.empty(0)))
    return lines


def trace_streamlines(grid: UniformGrid, seeds: np.ndarray, *,
                      step: float | None = None, max_steps: int = 400,
                      direction: str = "both", min_speed: float = 1e-9
                      ) -> list[tuple[np.ndarray, np.ndarray]]:
    """Returns per-seed (points (n,3), speed (n,)); seeds inside solid or dead
    zones yield empty lines (filtered by the caller)."""
    for c in VELOCITY_COMPONENTS:
        if c not in grid.arrays:
            raise FieldNotFoundError(
                f"streamlines need {VELOCITY_COMPONENTS}; missing '{c}'")
    seeds = np.atleast_2d(np.asarray(seeds, dtype=np.float64))
    h = float(step) if step else 0.75 * float(grid.spacing.min())
    fwd = _trace_one_way(grid, seeds, +1.0, h, max_steps, min_speed) \
        if direction in ("forward", "both") else None
    bwd = _trace_one_way(grid, seeds, -1.0, h, max_steps, min_speed) \
        if direction in ("backward", "both") else None
    out: list[tuple[np.ndarray, np.ndarray]] = []
    for i in range(seeds.shape[0]):
        parts_p, parts_s = [], []
        if bwd is not None and bwd[i][0].shape[0] >= 2:
            parts_p.append(bwd[i][0][::-1])          # reversed: upstream first
            parts_s.append(bwd[i][1][::-1])
        if fwd is not None and fwd[i][0].shape[0] >= 1:
            skip = 1 if parts_p else 0               # avoid duplicated seed point
            parts_p.append(fwd[i][0][skip:])
            parts_s.append(fwd[i][1][skip:])
        if parts_p:
            pts = np.vstack(parts_p)
            if pts.shape[0] >= 2:
                out.append((pts, np.concatenate(parts_s)))
                continue
        out.append((np.empty((0, 3)), np.empty(0)))
    return out


def line_seeds(p0, p1, n: int) -> np.ndarray:
    """n seeds evenly spaced on the segment p0-p1 (a 'rake')."""
    t = np.linspace(0.0, 1.0, max(1, n))
    p0 = np.asarray(p0, dtype=np.float64)
    p1 = np.asarray(p1, dtype=np.float64)
    return p0[None, :] + t[:, None] * (p1 - p0)[None, :]
