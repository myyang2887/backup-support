"""Pluggable fluid/solid point-level classifier chain (see spec 5.4).

Safety direction: when in doubt, classify as FLUID (never blacken real flow)."""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import ClassVar

import numpy as np
import pandas as pd

from fdpost.domain.requests import FluidRule

log = logging.getLogger("fdpost.core.solid_classify")

METADATA_FIELDS = {"volume", "surface"}
_TRUTHY = {"1", "true", "yes", "fluid", "y", "t"}


class SolidClassifier(ABC):
    """Point-level classifier working on the loaded, numeric, canonical DataFrame.
    Returns (N,) bool, True = fluid."""

    name: ClassVar[str]
    priority: ClassVar[int]

    @abstractmethod
    def applicable(self, df: pd.DataFrame, field_cols: list[str],
                   units: dict[str, str]) -> bool: ...

    @abstractmethod
    def classify(self, df: pd.DataFrame, field_cols: list[str]) -> np.ndarray: ...


_REGISTRY: list[type[SolidClassifier]] = []


def register_classifier(cls: type[SolidClassifier]) -> type[SolidClassifier]:
    _REGISTRY.append(cls)
    return cls


def _ordered() -> list[type[SolidClassifier]]:
    return sorted(_REGISTRY, key=lambda c: c.priority)


def _truthy(series: pd.Series) -> np.ndarray:
    s = series.astype(str).str.strip().str.lower()
    numeric = pd.to_numeric(series, errors="coerce")
    return (s.isin(_TRUTHY) | (numeric.fillna(0) != 0)).to_numpy()


@register_classifier
class ExplicitLabelClassifier(SolidClassifier):
    """priority=0: dataset carries an explicit cell-type column."""

    name = "explicit_label"
    priority = 0
    _LABELS = ("fluid", "solid", "cell_type", "phase", "region_type", "material")

    def applicable(self, df, field_cols, units) -> bool:
        return any(c in df.columns for c in self._LABELS)

    def classify(self, df, field_cols) -> np.ndarray:
        if "fluid" in df.columns:
            return _truthy(df["fluid"])
        if "solid" in df.columns:
            return ~_truthy(df["solid"])
        for c in ("cell_type", "phase", "region_type", "material"):
            if c in df.columns:
                s = df[c].astype(str).str.strip().str.lower()
                return s.isin({"fluid", "liquid", "gas"}).to_numpy()
        raise RuntimeError("unreachable")


@register_classifier
class ConfiguredFieldClassifier(SolidClassifier):
    """priority=1: explicit user rule (escape hatch). Injected with the rule."""

    name = "configured"
    priority = 1

    def __init__(self, rule: FluidRule | None = None) -> None:
        self.rule = rule or FluidRule()

    def applicable(self, df, field_cols, units) -> bool:
        return self.rule.mode != "auto"

    def classify(self, df, field_cols) -> np.ndarray:
        r = self.rule
        if r.mode == "all_fluid":
            return np.ones(len(df), dtype=bool)
        if r.mode == "field_present":
            return df[r.field].notna().to_numpy()
        if r.mode == "field_threshold":
            col = df[r.field]
            ops = {"gt": col > r.threshold, "ge": col >= r.threshold,
                   "lt": col < r.threshold, "le": col <= r.threshold,
                   "ne": col != r.threshold}
            return (ops[r.comparison] & col.notna()).to_numpy()
        if r.mode == "label_column":
            s = df[r.label_column].astype(str).str.strip().str.lower()
            accept = {v.lower() for v in r.fluid_values} or {"fluid", "liquid", "gas"}
            return s.isin(accept).to_numpy()
        raise ValueError(f"unsupported fluid rule mode {r.mode}")


@register_classifier
class VelocityPresenceClassifier(SolidClassifier):
    """priority=2: default workhorse — any velocity_* value present -> fluid."""

    name = "velocity_presence"
    priority = 2

    def applicable(self, df, field_cols, units) -> bool:
        return any(c.startswith("velocity") for c in field_cols)

    def classify(self, df, field_cols) -> np.ndarray:
        vel = [c for c in field_cols if c.startswith("velocity")]
        return df[vel].notna().any(axis=1).to_numpy()


@register_classifier
class AnyPhysicalFieldClassifier(SolidClassifier):
    """priority=3: no velocity columns (pure scalar dataset) — any non-metadata
    physical value present -> fluid."""

    name = "any_physical"
    priority = 3

    def applicable(self, df, field_cols, units) -> bool:
        return bool(set(field_cols) - METADATA_FIELDS)

    def classify(self, df, field_cols) -> np.ndarray:
        phys = [c for c in field_cols if c not in METADATA_FIELDS]
        return df[phys].notna().any(axis=1).to_numpy()


@register_classifier
class AllFluidClassifier(SolidClassifier):
    """priority=99: last resort — everything fluid + warning (safe direction)."""

    name = "all_fluid"
    priority = 99

    def applicable(self, df, field_cols, units) -> bool:
        return True

    def classify(self, df, field_cols) -> np.ndarray:
        log.warning("no usable fluid/solid signal; classifying all points as fluid")
        return np.ones(len(df), dtype=bool)


def classify_fluid(df: pd.DataFrame, field_cols: list[str], units: dict[str, str],
                   fluid_rule: FluidRule) -> tuple[np.ndarray, str]:
    """Run the chain; returns (is_fluid, classifier_name). An explicit
    (non-auto) rule bypasses the chain entirely."""
    if fluid_rule.mode != "auto":
        clf = ConfiguredFieldClassifier(fluid_rule)
        return clf.classify(df, field_cols), clf.name
    for cls in _ordered():
        clf = cls()  # type: ignore[call-arg]
        if isinstance(clf, ConfiguredFieldClassifier):
            continue  # only used with an explicit rule
        if clf.applicable(df, field_cols, units):
            return clf.classify(df, field_cols), clf.name
    raise RuntimeError("unreachable: AllFluidClassifier is always applicable")
