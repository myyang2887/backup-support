"""Millisecond-grade queries on the cached UniformGrid:
axis slices, arbitrary plane slices, line probes, box regions."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from fdpost.domain.errors import GridBuildError, RegionTooLargeError
from fdpost.domain.requests import PlaneGeometry
from fdpost.domain.uniform_grid import UniformGrid

AXIS_INDEX = {"x": 0, "y": 1, "z": 2}
IN_PLANE = {"x": ("y", "z"), "y": ("x", "z"), "z": ("x", "y")}
_IN_PLANE = IN_PLANE  # backwards-compatible private alias


@dataclass
class Slice2D:
    """2D slice result. values[iu,iv]; NaN = solid or out-of-domain.
    u/v are world coordinates along the two in-plane axes."""
    u: np.ndarray
    v: np.ndarray
    values: np.ndarray
    u_label: str
    v_label: str
    field: str
    unit: str
    title: str
    vec_u: np.ndarray | None = None
    vec_v: np.ndarray | None = None
    solid: np.ndarray | None = None


def euler_to_point_normal(tilt_deg: float, azimuth_deg: float, distance: float,
                          center: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """要件書「XY平面回転角度+距離」: base normal +Z, apply Rx(tilt) then
    Rz(azimuth): n = Rz(azimuth) @ Rx(tilt) @ [0,0,1]; origin = center + n*distance."""
    t = np.deg2rad(tilt_deg); a = np.deg2rad(azimuth_deg)
    rx = np.array([[1, 0, 0],
                   [0, np.cos(t), -np.sin(t)],
                   [0, np.sin(t), np.cos(t)]])
    rz = np.array([[np.cos(a), -np.sin(a), 0],
                   [np.sin(a), np.cos(a), 0],
                   [0, 0, 1]])
    n = rz @ rx @ np.array([0.0, 0.0, 1.0])
    n /= np.linalg.norm(n)
    origin = np.asarray(center, dtype=np.float64) + n * float(distance)
    return origin, n


def resolve_plane(req: PlaneGeometry, grid: UniformGrid) -> tuple[np.ndarray, np.ndarray]:
    """PlaneGeometry -> (origin, unit normal). Euler angles are measured from
    the data centre, matching the 3D slice gizmo and the PNG renderer, so the
    same request draws a PNG and exports a CSV of exactly the same cut."""
    if req.mode == "euler":
        center = grid.bounds.mean(axis=0)
        return euler_to_point_normal(req.tilt_deg, req.azimuth_deg,
                                     req.distance, center)
    n = np.asarray(req.normal, dtype=np.float64)
    return np.asarray(req.origin, dtype=np.float64), n / np.linalg.norm(n)


def _plane_basis(normal: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Orthonormal (u_hat, v_hat) spanning the plane; stable for any normal."""
    n = np.asarray(normal, dtype=np.float64)
    n = n / np.linalg.norm(n)
    ref = np.array([0.0, 0.0, 1.0]) if abs(n[2]) < 0.9 else np.array([1.0, 0.0, 0.0])
    u = np.cross(ref, n); u /= np.linalg.norm(u)
    v = np.cross(n, u)
    return u, v


# --- export lattices -------------------------------------------------------
# One shared primitive for every "sample at a chosen resolution" use-case
# (box regions, plane regions). Keeping it in one place is what makes
# 「解像度」and「何mm間隔」behave identically everywhere.

def lattice_1d(lo: float, hi: float, *, count: int | None = None,
               spacing: float | None = None) -> np.ndarray:
    """Sample coordinates along one axis. Exactly one of count/spacing is used.

    count   -> `count` points, both endpoints inclusive (linspace).
    spacing -> exact steps of `spacing` starting at `lo`; the last point is
               the final one that still fits inside `hi`. The *interval* is
               exact (requirement書「何mm間隔」), so the upper endpoint is only
               reached when the span is a whole multiple of the spacing.
    """
    lo, hi = float(lo), float(hi)
    if spacing is not None:
        if spacing <= 0:
            raise GridBuildError(f"spacing must be > 0, got {spacing}")
        span = hi - lo
        if span <= 0:
            return np.array([lo], dtype=np.float64)
        n = int(np.floor(span / spacing + 1e-9)) + 1
        return lo + spacing * np.arange(n, dtype=np.float64)
    if count is None:
        raise GridBuildError("lattice_1d needs either count or spacing")
    n = max(1, int(count))
    return (np.array([lo], dtype=np.float64) if n == 1
            else np.linspace(lo, hi, n))


def lattice_len(lo: float, hi: float, *, count: int | None = None,
                spacing: float | None = None) -> int:
    """Row count of `lattice_1d` without building it (cheap pre-flight check)."""
    if spacing is not None:
        if spacing <= 0:
            raise GridBuildError(f"spacing must be > 0, got {spacing}")
        span = hi - lo
        return 1 if span <= 0 else int(np.floor(span / spacing + 1e-9)) + 1
    return max(1, int(count or 1))


@dataclass
class PlaneFrame:
    """A plane resolved against a grid: origin, unit normal, in-plane basis
    and the in-plane extents that cover the data bounding box."""
    origin: np.ndarray
    normal: np.ndarray
    u_hat: np.ndarray
    v_hat: np.ndarray
    extent_u: tuple[float, float]
    extent_v: tuple[float, float]

    def points(self, u: np.ndarray, v: np.ndarray) -> np.ndarray:
        """World coords of the (nu,nv) lattice, C-order rows=u, cols=v."""
        gu, gv = np.meshgrid(u, v, indexing="ij")
        return (self.origin + gu.ravel()[:, None] * self.u_hat
                + gv.ravel()[:, None] * self.v_hat)


def plane_frame(grid: UniformGrid, origin: np.ndarray, normal: np.ndarray,
                extent_u: tuple[float, float] | None = None,
                extent_v: tuple[float, float] | None = None) -> PlaneFrame:
    """Resolve a plane against the grid, auto-sizing extents from the data box."""
    origin = np.asarray(origin, dtype=np.float64)
    n = np.asarray(normal, dtype=np.float64)
    n = n / np.linalg.norm(n)
    u_hat, v_hat = _plane_basis(n)
    if extent_u is None or extent_v is None:
        lo, hi = grid.bounds
        corners = np.array([[x, y, z] for x in (lo[0], hi[0])
                            for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
        rel = corners - origin
        pu, pv = rel @ u_hat, rel @ v_hat
        extent_u = extent_u or (float(pu.min()), float(pu.max()))
        extent_v = extent_v or (float(pv.min()), float(pv.max()))
    return PlaneFrame(origin=origin, normal=n, u_hat=u_hat, v_hat=v_hat,
                      extent_u=extent_u, extent_v=extent_v)


def slice_axis(grid: UniformGrid, axis: str, position: float, field: str,
               with_vectors: bool = False, vector_stride: int = 8) -> Slice2D:
    ai = AXIS_INDEX[axis]
    lo, hi = grid.bounds[0][ai], grid.bounds[1][ai]
    half = 0.5 * grid.spacing[ai]
    if not (lo - half <= position <= hi + half):
        raise GridBuildError(
            f"{axis}={position:g} outside domain [{lo - half:g}, {hi + half:g}]")
    ua, va = _IN_PLANE[axis]
    ui, vi = AXIS_INDEX[ua], AXIS_INDEX[va]
    u = grid.axis_coords(ui); v = grid.axis_coords(vi)
    gu, gv = np.meshgrid(u, v, indexing="ij")
    pts = np.empty((gu.size, 3))
    pts[:, ui] = gu.ravel(); pts[:, vi] = gv.ravel(); pts[:, ai] = position
    values = grid.sample(field, pts).reshape(gu.shape)
    solid = grid.sample_solid(pts).reshape(gu.shape)
    vec_u = vec_v = None
    if with_vectors:
        cu, cv = f"velocity_{ua}", f"velocity_{va}"
        if cu in grid.arrays and cv in grid.arrays:
            vec_u = grid.sample(cu, pts).reshape(gu.shape)
            vec_v = grid.sample(cv, pts).reshape(gu.shape)
    return Slice2D(u=u, v=v, values=values,
                   u_label=f"{ua.upper()} [m]", v_label=f"{va.upper()} [m]",
                   field=field, unit=grid.units.get(field, ""),
                   title=f"{field} @ {axis}={position:.6g} m",
                   vec_u=vec_u, vec_v=vec_v, solid=solid)


def slice_plane(grid: UniformGrid, origin: np.ndarray, normal: np.ndarray,
                field: str, extent_u: tuple[float, float] | None = None,
                extent_v: tuple[float, float] | None = None,
                resolution: tuple[int, int] = (400, 400),
                with_vectors: bool = False, vector_stride: int = 8) -> Slice2D:
    fr = plane_frame(grid, origin, normal, extent_u, extent_v)
    origin, n, u_hat, v_hat = fr.origin, fr.normal, fr.u_hat, fr.v_hat
    extent_u, extent_v = fr.extent_u, fr.extent_v
    nu, nv = resolution
    u = np.linspace(extent_u[0], extent_u[1], nu)
    v = np.linspace(extent_v[0], extent_v[1], nv)
    pts = fr.points(u, v)
    values = grid.sample(field, pts).reshape(nu, nv)
    solid = grid.sample_solid(pts).reshape(nu, nv)
    vec_u = vec_v = None
    if with_vectors and {"velocity_x", "velocity_y", "velocity_z"} <= set(grid.arrays):
        vel = np.column_stack([grid.sample(f"velocity_{c}", pts)
                               for c in ("x", "y", "z")])
        vec_u = (vel @ u_hat).reshape(nu, nv)
        vec_v = (vel @ v_hat).reshape(nu, nv)
    return Slice2D(u=u, v=v, values=values, u_label="u [m]", v_label="v [m]",
                   field=field, unit=grid.units.get(field, ""),
                   title=(f"{field} plane n=({n[0]:.3g},{n[1]:.3g},{n[2]:.3g}) "
                          f"o=({origin[0]:.3g},{origin[1]:.3g},{origin[2]:.3g})"),
                   vec_u=vec_u, vec_v=vec_v, solid=solid)


def positions_from_range(start: float, stop: float, step: float) -> np.ndarray:
    n = int(np.floor((stop - start) / step + 1e-9)) + 1
    return start + step * np.arange(max(n, 1))


def sample_line(grid: UniformGrid, p0, p1, n_samples: int,
                fields: list[str]) -> pd.DataFrame:
    p0 = np.asarray(p0, dtype=np.float64); p1 = np.asarray(p1, dtype=np.float64)
    t = np.linspace(0.0, 1.0, n_samples)
    pts = p0 + t[:, None] * (p1 - p0)
    dist = t * np.linalg.norm(p1 - p0)
    data: dict[str, np.ndarray] = {
        "distance_m": dist, "x_m": pts[:, 0], "y_m": pts[:, 1], "z_m": pts[:, 2]}
    for f in fields:
        data[f] = grid.sample(f, pts)
    data["is_solid"] = grid.sample_solid(pts).astype(int)
    return pd.DataFrame(data)


def _sampled_frame(grid: UniformGrid, pts: np.ndarray, fields: list[str],
                   lead: dict[str, np.ndarray]) -> pd.DataFrame:
    """Shared tail of every CSV export: field columns + is_solid."""
    data = dict(lead)
    for f in fields:
        data[f] = grid.sample(f, pts)
    data["is_solid"] = grid.sample_solid(pts).astype(int)
    return pd.DataFrame(data)


def sample_box(grid: UniformGrid, min_point, max_point,
               resolution: tuple[int, int, int] | None, fields: list[str],
               max_rows: int,
               spacing: tuple[float, float, float] | None = None) -> pd.DataFrame:
    """Box region -> CSV frame. Resolution is given either as point counts
    per axis (`resolution`) or as physical steps per axis (`spacing`)."""
    counts = [lattice_len(min_point[i], max_point[i],
                          count=None if spacing else resolution[i],  # type: ignore[index]
                          spacing=spacing[i] if spacing else None)
              for i in range(3)]
    total = counts[0] * counts[1] * counts[2]
    if total > max_rows:
        raise RegionTooLargeError(
            f"requested {total:,} rows exceeds limit {max_rows:,}; "
            "reduce resolution or box size")
    axes = [lattice_1d(min_point[i], max_point[i],
                       count=None if spacing else resolution[i],  # type: ignore[index]
                       spacing=spacing[i] if spacing else None)
            for i in range(3)]
    gx, gy, gz = np.meshgrid(*axes, indexing="ij")
    pts = np.column_stack([gx.ravel(), gy.ravel(), gz.ravel()])
    return _sampled_frame(grid, pts, fields,
                          {"x_m": pts[:, 0], "y_m": pts[:, 1], "z_m": pts[:, 2]})


def sample_plane(grid: UniformGrid, origin, normal, fields: list[str],
                 max_rows: int,
                 extent_u: tuple[float, float] | None = None,
                 extent_v: tuple[float, float] | None = None,
                 resolution: tuple[int, int] | None = None,
                 spacing: tuple[float, float] | None = None) -> pd.DataFrame:
    """Plane (断面) region -> CSV frame at a chosen in-plane resolution.

    Columns: u_m, v_m (in-plane coords measured from the plane origin),
    x_m, y_m, z_m (world), the requested fields, then is_solid.
    """
    fr = plane_frame(grid, origin, normal, extent_u, extent_v)
    spec = [(fr.extent_u, 0), (fr.extent_v, 1)]
    counts = [lattice_len(ext[0], ext[1],
                          count=None if spacing else resolution[i],  # type: ignore[index]
                          spacing=spacing[i] if spacing else None)
              for ext, i in spec]
    total = counts[0] * counts[1]
    if total > max_rows:
        raise RegionTooLargeError(
            f"requested {total:,} rows exceeds limit {max_rows:,}; "
            "coarsen the resolution or shrink the extent")
    u, v = (lattice_1d(ext[0], ext[1],
                       count=None if spacing else resolution[i],  # type: ignore[index]
                       spacing=spacing[i] if spacing else None)
            for ext, i in spec)
    gu, gv = np.meshgrid(u, v, indexing="ij")
    pts = fr.points(u, v)
    return _sampled_frame(grid, pts, fields,
                          {"u_m": gu.ravel(), "v_m": gv.ravel(),
                           "x_m": pts[:, 0], "y_m": pts[:, 1], "z_m": pts[:, 2]})
