"""FieldData -> UniformGrid: the ONE expensive interpolation step.

Key optimizations (spec 5.3):
- z-slab chunking bounds peak memory;
- fields sharing the same NaN-validity mask share a single interpolator fit
  (fit is the expensive part: KDTree/Delaunay)."""
from __future__ import annotations

import logging
import math
from collections.abc import Callable

import numpy as np

from fdpost.core.solid_mask import build_solid_mask
from fdpost.domain.errors import GridBuildError
from fdpost.domain.field_data import FieldData
from fdpost.domain.requests import PreprocessConfig
from fdpost.domain.uniform_grid import UniformGrid
from fdpost.interp import get_interpolator

log = logging.getLogger("fdpost.core.resample")

_CHUNK_TARGET = 4_000_000  # grid points per z-slab chunk


def _grid_geometry(fd: FieldData, cfg: PreprocessConfig
                   ) -> tuple[np.ndarray, np.ndarray, tuple[int, int, int]]:
    lo, hi = fd.bounds
    extent = hi - lo
    if np.any(extent <= 0):
        raise GridBuildError(f"degenerate point cloud extent {extent}")
    if cfg.spacing is not None:
        sp = np.full(3, float(cfg.spacing))
    else:
        target = cfg.target_dims or 128
        sp = np.full(3, float(extent.max() / max(target - 1, 1)))
    dims = tuple(int(max(2, math.floor(extent[i] / sp[i]) + 1)) for i in range(3))
    if math.prod(dims) > 512**3:
        raise GridBuildError(f"grid too large {dims}; increase spacing")
    # center the grid inside the bounds
    origin = lo + (extent - sp * (np.array(dims) - 1)) / 2
    return origin, sp, dims  # type: ignore[return-value]


def resample_to_grid(fd: FieldData, cfg: PreprocessConfig,
                     progress: Callable[[float, str], None] | None = None
                     ) -> UniformGrid:
    origin, spacing, dims = _grid_geometry(fd, cfg)
    nx, ny, nz = dims
    names = cfg.fields or fd.field_names()
    for n in names:
        fd.require(n)

    # group fields by validity mask -> shared fit
    groups: dict[bytes, list[str]] = {}
    for n in names:
        key = np.isnan(fd.fields[n]).tobytes()
        groups.setdefault(key, []).append(n)
    log.info("resample: %d fields in %d validity group(s), dims=%s, method=%s",
             len(names), len(groups), dims, cfg.method)

    arrays = {n: np.empty(dims, dtype=np.float32) for n in names}
    axes = [origin[i] + spacing[i] * np.arange(dims[i]) for i in range(3)]
    z_chunk = max(1, _CHUNK_TARGET // max(nx * ny, 1))
    n_chunks = math.ceil(nz / z_chunk)
    total_steps = len(groups) * n_chunks
    step = 0

    for key, group_names in groups.items():
        valid = ~np.frombuffer(key, dtype=bool)
        if valid.sum() < 4:
            for n in group_names:
                arrays[n][:] = np.nan
            step += n_chunks
            continue
        itp = get_interpolator(cfg.method, **cfg.interp_params).fit(fd.points[valid])
        vals = np.column_stack([fd.fields[n][valid] for n in group_names])  # (Nv,F)
        for z0 in range(0, nz, z_chunk):
            z1 = min(z0 + z_chunk, nz)
            gx, gy, gz = np.meshgrid(axes[0], axes[1], axes[2][z0:z1], indexing="ij")
            q = np.column_stack([gx.ravel(), gy.ravel(), gz.ravel()])
            out = itp.interpolate(vals, q)                       # (M,F)
            out = out.reshape(nx, ny, z1 - z0, len(group_names))
            for fi, n in enumerate(group_names):
                arrays[n][:, :, z0:z1] = out[..., fi].astype(np.float32)
            step += 1
            if progress:
                progress(step / total_steps, f"interpolating {group_names}")

    solid = build_solid_mask(fd.points, fd.is_fluid, origin, spacing, dims)
    meta = {**fd.meta, "interp_method": cfg.method,
            "interp_params": dict(cfg.interp_params),
            "grid_dims": list(dims)}
    return UniformGrid(origin=origin, spacing=spacing, dims=dims,
                       arrays=arrays, solid_mask=solid,
                       units=dict(fd.units), meta=meta)
