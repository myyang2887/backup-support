"""Point-level is_fluid -> voxel-level solid mask via nearest-point projection."""
from __future__ import annotations

import numpy as np
from scipy.spatial import cKDTree


def build_solid_mask(points: np.ndarray, is_fluid: np.ndarray,
                     origin: np.ndarray, spacing: np.ndarray,
                     dims: tuple[int, int, int]) -> np.ndarray:
    """For every voxel center, adopt the fluid/solid state of the nearest
    scattered point. (nx,ny,nz) bool, True = solid."""
    tree = cKDTree(np.asarray(points, dtype=np.float64))
    axes = [np.asarray(origin)[i] + np.asarray(spacing)[i] * np.arange(dims[i])
            for i in range(3)]
    gx, gy, gz = np.meshgrid(*axes, indexing="ij")
    centers = np.column_stack([gx.ravel(), gy.ravel(), gz.ravel()])
    _, idx = tree.query(centers, k=1, workers=-1)
    solid = ~np.asarray(is_fluid, dtype=bool)[idx]
    return solid.reshape(dims)
