"""fdpost command-line interface (Typer)."""
from __future__ import annotations

import json
from pathlib import Path

import typer

from fdpost.config import Settings, ensure_dirs

app = typer.Typer(help="fdpost: FloEFD post-processing toolkit",
                  no_args_is_help=True, pretty_exceptions_show_locals=False)


def _grid(input_file: Path, method: str, target_dims: int,
          spacing: float | None, fluid_rule_json: str | None):
    """Load (cache-aware) and return (grid, settings)."""
    from fdpost.core.resample import resample_to_grid
    from fdpost.domain.requests import FluidRule, PreprocessConfig
    from fdpost.io.grid_cache import cache_key, load_grid, save_grid, source_signature
    from fdpost.io.tsv_loader import load_floefd_table

    settings = Settings()
    ensure_dirs()
    rule = FluidRule(**json.loads(fluid_rule_json)) if fluid_rule_json else FluidRule()
    cfg = PreprocessConfig(method=method, spacing=spacing,
                           target_dims=target_dims, fluid_rule=rule)
    key = cache_key(source_signature(input_file),
                    json.dumps(cfg.model_dump(), sort_keys=True))
    cache = Path(settings.cache_dir) / f"{key}.npz"
    if cache.exists():
        try:
            grid = load_grid(cache)
            typer.echo(f"[cache hit] {cache.name}")
            return grid, settings
        except Exception:
            pass
    fd = load_floefd_table(input_file, fluid_rule=rule)
    typer.echo(f"loaded {fd.n_points} pts | fluid {fd.meta['n_fluid']} / "
               f"solid {fd.meta['n_solid']} | rule={fd.meta['fluid_rule_used']}")
    grid = resample_to_grid(fd, cfg,
                            progress=lambda f, m: typer.echo(f"  {f*100:5.1f}% {m}"))
    save_grid(grid, cache)
    typer.echo(f"[cache saved] {cache.name} dims={grid.dims}")
    return grid, settings


_METHOD = typer.Option("idw", "--method", "-m", help="nearest|idw|linear|rbf")
_DIMS = typer.Option(128, "--target-dims", help="longest-axis voxel count")
_SPACING = typer.Option(None, "--spacing", help="explicit voxel size [m]")
_RULE = typer.Option(None, "--fluid-rule", help='JSON FluidRule, e.g. {"mode":"all_fluid"}')


@app.command()
def preprocess(input_file: Path, method: str = _METHOD, target_dims: int = _DIMS,
               spacing: float = _SPACING, fluid_rule: str = _RULE):
    """Parse + resample + cache a FloEFD table (idempotent)."""
    grid, _ = _grid(input_file, method, target_dims, spacing, fluid_rule)
    typer.echo(f"fields: {sorted(grid.arrays)}")
    typer.echo(f"bounds: {grid.bounds.tolist()}")


@app.command("slice")
def slice_cmd(input_file: Path,
              axis: str = typer.Option(..., "--axis", "-a"),
              start: float = typer.Option(..., "--start"),
              stop: float = typer.Option(..., "--stop"),
              step: float = typer.Option(..., "--step"),
              field: str = typer.Option("velocity_magnitude", "--field", "-f"),
              vectors: bool = typer.Option(False, "--vectors/--no-vectors"),
              cmap: str = typer.Option("jet", "--cmap"),
              dpi: int = typer.Option(150, "--dpi"),
              out: Path = typer.Option(None, "--out", "-o"),
              method: str = _METHOD, target_dims: int = _DIMS,
              spacing: float = _SPACING, fluid_rule: str = _RULE):
    """Batch axis-aligned slice PNGs with a shared colorbar."""
    from fdpost.core.query import positions_from_range, slice_axis
    from fdpost.render.contour import render_slice_batch

    grid, settings = _grid(input_file, method, target_dims, spacing, fluid_rule)
    positions = positions_from_range(start, stop, step)
    slices = [slice_axis(grid, axis, float(p), field, with_vectors=vectors)
              for p in positions]
    out_dir = out or Path(settings.output_dir) / "slices"
    paths = render_slice_batch(slices, out_dir, axis, positions,
                               cmap=cmap, dpi=dpi,
                               progress=lambda f, m: typer.echo(f"  {f*100:5.1f}% {m}"))
    typer.echo(f"wrote {len(paths)} PNGs -> {out_dir}")


@app.command("slice-plane")
def slice_plane_cmd(input_file: Path,
                    tilt: float = typer.Option(..., "--tilt", help="deg, Rx"),
                    azimuth: float = typer.Option(..., "--azimuth", help="deg, Rz"),
                    distance: float = typer.Option(0.0, "--distance", help="m along normal"),
                    field: str = typer.Option("velocity_magnitude", "--field", "-f"),
                    resolution: int = typer.Option(400, "--resolution"),
                    vectors: bool = typer.Option(False, "--vectors/--no-vectors"),
                    cmap: str = typer.Option("jet", "--cmap"),
                    dpi: int = typer.Option(150, "--dpi"),
                    out: Path = typer.Option(None, "--out", "-o"),
                    method: str = _METHOD, target_dims: int = _DIMS,
                    spacing: float = _SPACING, fluid_rule: str = _RULE):
    """Arbitrary plane slice via 要件書 euler spec (tilt/azimuth/distance)."""
    from fdpost.core.query import euler_to_point_normal, slice_plane
    from fdpost.render.contour import render_slice_png

    grid, settings = _grid(input_file, method, target_dims, spacing, fluid_rule)
    center = grid.bounds.mean(axis=0)
    origin, normal = euler_to_point_normal(tilt, azimuth, distance, center)
    sl = slice_plane(grid, origin, normal, field,
                     resolution=(resolution, resolution), with_vectors=vectors)
    out_path = out or Path(settings.output_dir) / "plane_slice.png"
    render_slice_png(sl, out_path, cmap=cmap, dpi=dpi)
    typer.echo(f"origin={origin.round(6).tolist()} normal={normal.round(6).tolist()}")
    typer.echo(f"wrote {out_path}")


@app.command()
def probe(input_file: Path,
          p0: str = typer.Option(..., "--p0", help="x,y,z"),
          p1: str = typer.Option(..., "--p1", help="x,y,z"),
          n: int = typer.Option(200, "--n-samples", "-n"),
          fields: str = typer.Option("velocity_magnitude", "--fields",
                                     help="comma-separated"),
          out: Path = typer.Option(None, "--out", "-o"),
          method: str = _METHOD, target_dims: int = _DIMS,
          spacing: float = _SPACING, fluid_rule: str = _RULE):
    """Two-point line probe -> CSV + curve PNG."""
    from fdpost.core.query import sample_line
    from fdpost.io.csv_writer import write_csv
    from fdpost.render.lineplot import render_line_png

    grid, settings = _grid(input_file, method, target_dims, spacing, fluid_rule)
    a = tuple(float(v) for v in p0.split(","))
    b = tuple(float(v) for v in p1.split(","))
    fl = [f.strip() for f in fields.split(",") if f.strip()]
    df = sample_line(grid, a, b, n, fl)
    out_dir = out or Path(settings.output_dir) / "probe"
    csv = write_csv(df, Path(out_dir) / "line.csv", units=grid.units)
    png = render_line_png(df, fl, Path(out_dir) / "line.png", units=grid.units)
    typer.echo(f"wrote {csv} and {png} ({len(df)} rows)")


def _triple(text: str, cast):
    return tuple(cast(v) for v in text.split(","))


@app.command()
def region(input_file: Path,
           min_point: str = typer.Option(..., "--min", help="x,y,z"),
           max_point: str = typer.Option(..., "--max", help="x,y,z"),
           res: str = typer.Option("", "--res", help="nx,ny,nz (point counts)"),
           step: str = typer.Option("", "--step",
                                    help="dx,dy,dz in metres (何mm間隔; instead of --res)"),
           fields: str = typer.Option("", "--fields", help="comma-separated (default all)"),
           out: Path = typer.Option(None, "--out", "-o"),
           method: str = _METHOD, target_dims: int = _DIMS,
           spacing: float = _SPACING, fluid_rule: str = _RULE):
    """Box region -> CSV at a chosen resolution (--res counts or --step metres)."""
    from fdpost.core.query import sample_box
    from fdpost.io.csv_writer import write_csv

    if bool(res) == bool(step):
        raise typer.BadParameter("give exactly one of --res / --step")
    grid, settings = _grid(input_file, method, target_dims, spacing, fluid_rule)
    fl = [f.strip() for f in fields.split(",") if f.strip()] or sorted(grid.arrays)
    df = sample_box(grid, _triple(min_point, float), _triple(max_point, float),
                    _triple(res, int) if res else None, fl,
                    max_rows=settings.max_export_rows,
                    spacing=_triple(step, float) if step else None)
    out_path = out or Path(settings.output_dir) / "region.csv"
    write_csv(df, out_path, units=grid.units)
    typer.echo(f"wrote {out_path} ({len(df)} rows)")


@app.command("region-plane")
def region_plane(input_file: Path,
                 tilt: float = typer.Option(0.0, "--tilt", help="回転角 [deg]"),
                 azimuth: float = typer.Option(0.0, "--azimuth", help="方位角 [deg]"),
                 distance: float = typer.Option(0.0, "--distance",
                                                help="signed distance from centre [m]"),
                 res: str = typer.Option("", "--res", help="nu,nv (point counts)"),
                 step: str = typer.Option("", "--step",
                                          help="du,dv in metres (何mm間隔)"),
                 fields: str = typer.Option("", "--fields", help="comma-separated"),
                 out: Path = typer.Option(None, "--out", "-o"),
                 method: str = _METHOD, target_dims: int = _DIMS,
                 spacing: float = _SPACING, fluid_rule: str = _RULE):
    """Plane (断面) region -> CSV at a chosen in-plane resolution."""
    from fdpost.core.query import resolve_plane, sample_plane
    from fdpost.domain.requests import PlaneRegionRequest
    from fdpost.io.csv_writer import write_csv

    if bool(res) == bool(step):
        raise typer.BadParameter("give exactly one of --res / --step")
    grid, settings = _grid(input_file, method, target_dims, spacing, fluid_rule)
    fl = [f.strip() for f in fields.split(",") if f.strip()] or sorted(grid.arrays)
    pair = (lambda t, c: tuple(c(v) for v in t.split(",")))
    req = PlaneRegionRequest(mode="euler", tilt_deg=tilt, azimuth_deg=azimuth,
                             distance=distance,
                             resolution=pair(res, int) if res else None,
                             spacing=pair(step, float) if step else None)
    origin, normal = resolve_plane(req, grid)
    df = sample_plane(grid, origin, normal, fl,
                      max_rows=settings.max_export_rows,
                      resolution=req.resolution, spacing=req.spacing)
    out_path = out or Path(settings.output_dir) / "plane_region.csv"
    write_csv(df, out_path, units=grid.units)
    typer.echo(f"wrote {out_path} ({len(df)} rows)")


@app.command()
def serve(host: str = typer.Option(None, "--host"),
          port: int = typer.Option(None, "--port", "-p")):
    """Start the web UI / REST API server."""
    import uvicorn

    from fdpost.api.app import create_app

    settings = Settings()
    uvicorn.run(create_app(settings), host=host or settings.host,
                port=port or settings.port, log_level="info")


@app.command()
def desktop():
    """Start the desktop (pywebview) shell. Requires: pip install fdpost[desktop]."""
    from fdpost.desktop.main import run_desktop
    run_desktop()


if __name__ == "__main__":
    app()
