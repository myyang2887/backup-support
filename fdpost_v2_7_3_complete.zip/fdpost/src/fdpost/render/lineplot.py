"""Line-probe curve PNG. Solid segments (is_solid==1) break the line (NaN gap)."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from fdpost.render.style import apply_style


def render_line_png(df: pd.DataFrame, fields: list[str], path: str | Path,
                    units: dict[str, str] | None = None,
                    x_label: str = "距離 [m]", dpi: int = 150) -> Path:
    apply_style()
    import matplotlib.pyplot as plt

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    units = units or {}
    fig, ax = plt.subplots(figsize=(9, 5))
    x = df["distance_m"].to_numpy()
    solid = df["is_solid"].to_numpy().astype(bool)
    for f in fields:
        y = df[f].to_numpy(dtype=float).copy()
        y[solid] = np.nan  # break the curve through solids
        u = units.get(f, "")
        ax.plot(x, y, label=f"{f}{f' [{u}]' if u else ''}", lw=1.6)
    ax.set_xlabel(x_label)
    ax.set_ylabel(" / ".join(fields))
    ax.legend(loc="best", fontsize=9)
    ax.grid(True, alpha=0.3)
    fig.savefig(path, dpi=dpi)
    plt.close(fig)
    return path
