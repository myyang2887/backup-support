"""Matplotlib global style. Agg backend MUST be selected before pyplot import."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")  # headless; must precede any pyplot import

import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import Colormap  # noqa: E402

FONT_FALLBACK = ["Noto Sans CJK JP", "Yu Gothic", "Meiryo", "MS Gothic", "DejaVu Sans"]

_applied = False


def apply_style() -> None:
    global _applied
    if _applied:
        return
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": FONT_FALLBACK,
        "axes.unicode_minus": False,
        "figure.dpi": 100,
        "savefig.bbox": "tight",
        "axes.grid": False,
    })
    _applied = True


def make_cmap(name: str = "jet") -> Colormap:
    """Colormap with NaN (solid / out-of-domain) rendered pure black (要件書)."""
    cmap = plt.get_cmap(name).copy()
    cmap.set_bad(color="black")
    return cmap
