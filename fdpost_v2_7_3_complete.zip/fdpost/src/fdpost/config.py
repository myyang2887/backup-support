"""Global configuration (env prefix FDPOST_) and resource path helpers."""
from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Global settings. Override via environment variables, e.g. FDPOST_CACHE_DIR."""

    data_dir: Path = Path("./data")
    cache_dir: Path = Path("./cache")
    output_dir: Path = Path("./output")
    preview_res: int = 128
    max_export_rows: int = 5_000_000
    default_interp: str = "idw"
    host: str = "127.0.0.1"
    port: int = 8000
    job_workers: int = 2
    grid_lru_size: int = 3
    point_cloud_cap: int = 80_000
    vector_glyph_dim: int = 22        # lattice max_dim for 3D arrows
    vector_glyph_cap: int = 24_000    # hard cap on arrow instances
    source_sampler_lru: int = 2       # datasets kept fitted for hi-res slices
    slice_direct_max_px: int = 1200   # per-axis cap on a direct slice

    model_config = {"env_prefix": "FDPOST_"}


log = logging.getLogger("fdpost.config")

settings = Settings()


def ensure_dirs() -> None:
    """Create data/cache/output directories (exist_ok)."""
    for d in (settings.data_dir, settings.cache_dir, settings.output_dir):
        Path(d).mkdir(parents=True, exist_ok=True)


def frontend_dist() -> Path | None:
    """Locate the built UI.

    Two copies can exist at once — the one inside an installed package
    (``fdpost/web``, shipped by the wheel) and the one in a source checkout
    (``frontend/dist``) — and either can be the stale one:

    * install fresh over an old checkout  -> the checkout is stale
    * rebuild the checkout without reinstalling -> the install is stale

    A fixed priority gets one of those wrong, so the newest ``index.html``
    wins. That is self-correcting in both directions: whichever you just
    built is the one you get. Set ``FDPOST_FRONTEND_DIR`` to pin it
    explicitly when a deterministic choice matters (packaging, CI).
    """
    override = os.environ.get("FDPOST_FRONTEND_DIR")
    if override:
        d = Path(override).expanduser().resolve()
        return d if (d / "index.html").is_file() else None

    if hasattr(sys, "_MEIPASS"):          # frozen build: nothing else applies
        d = Path(sys._MEIPASS) / "frontend/dist"  # type: ignore[attr-defined]
        return d if (d / "index.html").is_file() else None

    here = Path(__file__).resolve().parent
    candidates = [
        here / "web",                                       # pip install
        Path(sys.argv[0]).resolve().parent / "frontend/dist",  # onedir
        here.parents[1] / "frontend/dist",                  # source checkout
    ]
    found = [(c, (c / "index.html").stat().st_mtime)
             for c in candidates if (c / "index.html").is_file()]
    if not found:
        return None
    best = max(found, key=lambda t: t[1])
    if len(found) > 1:
        log.info("multiple frontend builds found; serving the newest: %s", best[0])
    return best[0]


def resource_path(rel: str) -> Path:
    """Locate bundled resources in dev and frozen (PyInstaller) environments."""
    if hasattr(sys, "_MEIPASS"):  # PyInstaller onefile
        return Path(sys._MEIPASS) / rel  # type: ignore[attr-defined]
    exe_dir = Path(sys.argv[0]).resolve().parent
    if (exe_dir / rel).exists():  # onedir: next to the executable
        return exe_dir / rel
    # dev: project root = three levels above this file (src/fdpost/config.py)
    return Path(__file__).resolve().parents[2] / rel
