"""Sampling the ORIGINAL scattered data at arbitrary points.

Why this exists
---------------
Preprocessing resamples the scatter onto a uniform grid, and every later
query reads that grid. That makes the grid resolution a hard ceiling on
*everything* — including a 2D slice, which is the one place people actually
want detail. Raising `target_dims` to lift the ceiling is a bad trade: cost
grows with the cube of the resolution, because a full 3D volume is built.

A slice does not need a volume. It needs one plane. Sampling a plane
straight from the source scatter costs O(pixels) — 512x512 is 262k queries,
against the ~134M voxels a 512^3 grid would demand. So the slice can be far
finer than the grid without touching preprocessing time at all.

The uniform grid stays the workhorse for 3D preview, isosurfaces, streamlines
and region export; this path is used only when a slice is asked for at a
resolution the grid cannot deliver.
"""
from __future__ import annotations

import logging
import threading
from collections import OrderedDict
from dataclasses import dataclass

import numpy as np
from scipy.interpolate import LinearNDInterpolator, NearestNDInterpolator
from scipy.spatial import cKDTree

from fdpost.interp import get_interpolator
from fdpost.domain.field_data import FieldData

log = logging.getLogger("fdpost.services.source_sampler")


class SourceSampler:
    """Interpolates source points at arbitrary query positions.

    Fits are per-field (the valid-point set differs between fields) and are
    memoised, so scrubbing a slice re-uses one fit.
    """

    def __init__(self, fd: FieldData, method: str = "idw",
                 params: dict | None = None) -> None:
        self.fd = fd
        self.method = method
        self.params = params or {}
        self._fits: dict[str, tuple] = {}
        self._solid_tree: cKDTree | None = None
        self._pitch: float | None = None
        self._lock = threading.RLock()

    @property
    def n_points(self) -> int:
        return int(self.fd.points.shape[0])

    def _fit_for(self, field: str):
        with self._lock:
            if field in self._fits:
                return self._fits[field]
            values = self.fd.fields[field]
            valid = ~np.isnan(values)
            if valid.sum() < 4:
                raise ValueError(f"field '{field}' has too few valid points")
            itp = get_interpolator(self.method, **self.params).fit(
                self.fd.points[valid])
            self._fits[field] = (itp, values[valid][:, None])
            log.info("fitted %s on %d points for '%s'",
                     self.method, int(valid.sum()), field)
            return self._fits[field]

    def sample(self, field: str, pts: np.ndarray) -> np.ndarray:
        itp, vals = self._fit_for(field)
        return itp.interpolate(vals, pts)[:, 0]

    @property
    def pitch(self) -> float:
        """Median nearest-neighbour distance — the data's own length scale."""
        with self._lock:
            if self._pitch is None:
                pts = self.fd.points
                sub = pts[:: max(1, pts.shape[0] // 4000)]
                tree = cKDTree(pts)
                d, _ = tree.query(sub, k=2, workers=-1)
                self._pitch = float(np.median(d[:, 1]))
            return self._pitch

    def plane_slab(self, origin: np.ndarray, normal: np.ndarray,
                   u_hat: np.ndarray, v_hat: np.ndarray,
                   half_width_pitch: float = 1.5,
                   fields: list[str] | None = None,
                   min_valid: int = 4,
                   max_width_pitch: float = 8.0) -> PlaneSlab:
        """Source points near the plane, projected into its (u, v) frame.

        The window widens until it holds enough points that actually carry a
        value for the requested fields. Counting raw points instead was a
        bug: a plane lying mostly inside solid gathers hundreds of points
        whose field value is NaN, so the window never grew, and interpolation
        then failed with "too few points near the plane" — on a slab that
        looked well populated.

        Widening stops at `max_width_pitch` * pitch. Past that the plane is
        genuinely inside solid (or outside the data), and reaching further to
        find fluid would invent a picture of flow where there is none. Such a
        slab is returned empty-handed on purpose; the interpolator then yields
        NaN everywhere, which renders as "all solid" — the truthful answer.
        """
        names = fields or list(self.fd.fields)
        rel = self.fd.points - origin
        dist = np.abs(rel @ normal)
        half = self.pitch * half_width_pitch

        def valid_count(mask: np.ndarray) -> int:
            if not mask.any():
                return 0
            return min(int(np.isfinite(self.fd.fields[n][mask]).sum())
                       for n in names)

        m = dist <= half
        limit = self.pitch * max_width_pitch
        while valid_count(m) < min_valid and half < limit:
            half = min(half * 2.0, limit)
            m = dist <= half

        sel = rel[m]
        return PlaneSlab(
            uv=np.column_stack([sel @ u_hat, sel @ v_hat]),
            values={n: self.fd.fields[n][m] for n in names},
            is_fluid=self.fd.is_fluid[m],
            n_points=int(m.sum()), half_width=half)

    def plane_interpolator(self, slab: PlaneSlab) -> "_SlabInterpolator":
        return _SlabInterpolator(slab)

    def solid(self, pts: np.ndarray) -> np.ndarray:
        """Nearest source point decides fluid/solid — the same rule the grid
        mask is built from, just evaluated per query instead of per voxel."""
        with self._lock:
            if self._solid_tree is None:
                self._solid_tree = cKDTree(self.fd.points)
        _, idx = self._solid_tree.query(pts, k=1, workers=-1)
        return ~self.fd.is_fluid[idx]


class SourceSamplerCache:
    """Small LRU of samplers; source reload + KD-tree fit is the expensive bit."""

    def __init__(self, size: int = 2) -> None:
        self.size = size
        self._items: OrderedDict[str, SourceSampler] = OrderedDict()
        self._lock = threading.RLock()

    def get(self, ds_id: str) -> SourceSampler | None:
        with self._lock:
            if ds_id in self._items:
                self._items.move_to_end(ds_id)
                return self._items[ds_id]
        return None

    def put(self, ds_id: str, sampler: SourceSampler) -> SourceSampler:
        with self._lock:
            self._items[ds_id] = sampler
            self._items.move_to_end(ds_id)
            while len(self._items) > self.size:
                self._items.popitem(last=False)
        return sampler

    def drop(self, ds_id: str) -> None:
        with self._lock:
            self._items.pop(ds_id, None)


# --- plane-native sampling ---------------------------------------------------
# A slice does not need 3D interpolation. Gathering the source points that lie
# near the plane and triangulating them *in 2D* is both smoother and much
# faster than querying a 3D structure:
#   3D IDW k=8 p=2   roughness 0.037   0.25 s     <- plateaus around each point
#   slab + 2D linear roughness 0.014   0.03 s     <- true linear gradients
# (roughness = 2nd-difference energy; lower is smoother. 256x256, 120k points.)

@dataclass
class PlaneSlab:
    """Source points near one plane, projected into its (u, v) frame."""
    uv: np.ndarray                      # (M,2) in-plane coords
    values: dict[str, np.ndarray]       # field -> (M,)
    is_fluid: np.ndarray                # (M,)
    n_points: int
    half_width: float

    def native_px(self, span_u: float, span_v: float) -> int:
        """Resolution actually justified by the data.

        Beyond this the picture gains pixels but no information — everything
        further is interpolation, which is why an over-large slice still looks
        flat and blocky no matter how many pixels it has.
        """
        if self.n_points < 4:
            return 16
        area = max(span_u * span_v, 1e-30)
        density = self.n_points / area           # points per m^2
        return int(np.clip(round(np.sqrt(density) * max(span_u, span_v)), 16, 4096))


class _SlabInterpolator:
    """Linear (Delaunay) interpolation inside the slab, nearest outside it.

    Delaunay gives the smooth gradients; the nearest-neighbour fallback keeps
    the border of the domain filled instead of NaN-fringed.
    """

    def __init__(self, slab: PlaneSlab) -> None:
        self.slab = slab
        self._lin: dict[str, LinearNDInterpolator] = {}
        self._near: dict[str, NearestNDInterpolator] = {}
        self._fluid_tree = cKDTree(slab.uv) if slab.n_points else None

    def _for(self, field: str):
        """Fitted interpolators, or (None, None) when the plane holds no fluid.

        A cut lying wholly inside solid is a normal thing to ask for — a
        sweep through a nozzle passes through plenty of them — so it does not
        raise. `sample` then returns NaN and the slice renders as solid,
        which is exactly what it is.
        """
        if field not in self._lin:
            v = self.slab.values[field]
            ok = np.isfinite(v)
            if ok.sum() < 4:
                self._lin[field] = None
                self._near[field] = None
            else:
                self._lin[field] = LinearNDInterpolator(self.slab.uv[ok], v[ok])
                self._near[field] = NearestNDInterpolator(self.slab.uv[ok], v[ok])
        return self._lin[field], self._near[field]

    @property
    def has_data(self) -> bool:
        """False when this plane holds no fluid at all."""
        return any(np.isfinite(v).sum() >= 4
                   for v in self.slab.values.values())

    def sample(self, field: str, uv: np.ndarray) -> np.ndarray:
        lin, near = self._for(field)
        if lin is None:
            return np.full(uv.shape[0], np.nan)
        out = lin(uv)
        gaps = np.isnan(out)                     # outside the convex hull
        if gaps.any():
            out[gaps] = near(uv[gaps])
        return out

    def solid(self, uv: np.ndarray) -> np.ndarray:
        """Nearest slab point decides fluid/solid — sharp, no blurred wall."""
        if self._fluid_tree is None:
            return np.zeros(uv.shape[0], dtype=bool)
        _, idx = self._fluid_tree.query(uv, k=1, workers=-1)
        return ~self.slab.is_fluid[idx]
