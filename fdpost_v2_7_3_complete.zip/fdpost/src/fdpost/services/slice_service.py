"""Slice use-cases: axis batches, arbitrary planes, plane batches, zip packing."""
from __future__ import annotations

import uuid
import zipfile
from pathlib import Path
from typing import Any

import numpy as np

from fdpost.config import Settings
from fdpost.core.query import (euler_to_point_normal, positions_from_range,
                               resolve_plane, slice_axis, slice_plane)
from fdpost.domain.requests import (AxisSliceBatch, PlaneSliceBatch,
                                    PlaneSliceRequest)
from fdpost.render.contour import (compute_global_clim, render_slice_batch,
                                   render_slice_png)
from fdpost.services.dataset_store import DatasetStore


class SliceService:
    def __init__(self, store: DatasetStore, settings: Settings) -> None:
        self.store = store
        self.settings = settings

    def _out_dir(self, tag: str) -> Path:
        d = Path(self.settings.output_dir) / f"{tag}_{uuid.uuid4().hex[:8]}"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @staticmethod
    def _zip(paths: list[Path], zip_path: Path) -> Path:
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            for p in paths:
                z.write(p, p.name)
        return zip_path

    def run_axis_batch(self, ds_id: str, req: AxisSliceBatch,
                       report=lambda f, m="": None) -> dict[str, Any]:
        grid = self.store.get_grid(ds_id)
        positions = positions_from_range(req.start, req.stop, req.step)
        hi_fi = req.fidelity == "scatter"
        res = req.sample_px or (self._native_px(ds_id, req.axis,
                                                 float(positions[0]))
                                 if hi_fi else 0)
        slices = []
        for i, pos in enumerate(positions):
            if hi_fi:
                slices.append(self._scatter_slice(ds_id, req.axis, float(pos),
                                                  req.field, res,
                                                  req.with_vectors))
            else:
                slices.append(slice_axis(grid, req.axis, float(pos), req.field,
                                         with_vectors=req.with_vectors,
                                         vector_stride=req.vector_stride))
            report(0.5 * (i + 1) / len(positions), f"sliced {req.axis}={pos:.4g}")
        out = self._out_dir("slices")
        clim = req.clim or compute_global_clim([s.values for s in slices])
        paths = render_slice_batch(
            slices, out, req.axis, positions, clim=clim, cmap=req.cmap,
            dpi=req.dpi, vector_stride=req.vector_stride, smooth=req.smooth,
            show_solid=req.show_solid, solid_color=req.solid_color,
            progress=lambda f, m: report(0.5 + 0.45 * f, m))
        zip_path = self._zip(paths, out / "slices.zip")
        return {"n_slices": len(paths), "dir": str(out),
                "files": [str(p) for p in paths], "zip": str(zip_path),
                "clim": list(clim)}

    # -- high-fidelity helpers ----------------------------------------------
    def _export_service(self):
        from fdpost.services.slice_export_service import SliceExportService
        return SliceExportService(self.store, self.settings)

    def _native_px(self, ds_id: str, axis: str, position: float) -> int:
        """Resolution the source density justifies, so a batch is neither
        needlessly coarse nor pointlessly oversampled."""
        from fdpost.core.query import AXIS_INDEX, IN_PLANE

        grid = self.store.get_grid(ds_id)
        sampler = self.store.get_sampler(ds_id)
        ai = AXIS_INDEX[axis]
        ua, va = IN_PLANE[axis]
        ui, vi = AXIS_INDEX[ua], AXIS_INDEX[va]
        lo, hi = grid.bounds
        origin = grid.bounds.mean(axis=0).copy()
        origin[ai] = float(np.clip(position, lo[ai], hi[ai]))
        n = np.zeros(3); n[ai] = 1.0
        u = np.zeros(3); u[ui] = 1.0
        v = np.zeros(3); v[vi] = 1.0
        slab = sampler.plane_slab(origin, n, u, v)
        return max(slab.native_px(float(hi[ui] - lo[ui]),
                                  float(hi[vi] - lo[vi])), int(max(grid.dims)))

    def _scatter_slice(self, ds_id: str, axis: str, position: float,
                       field: str, res: int, with_vectors: bool):
        from fdpost.domain.requests import SliceExportRequest

        req = SliceExportRequest(mode="axis", axis=axis, position=position,
                                 field=field, resolution=res,
                                 fidelity="scatter", with_vectors=with_vectors)
        grid = self.store.get_grid(ds_id)
        return self._export_service()._sample_scatter(ds_id, req, grid)

    def run_plane_slice(self, ds_id: str, req: PlaneSliceRequest) -> dict[str, Any]:
        grid = self.store.get_grid(ds_id)
        origin, normal = resolve_plane(req, grid)
        sl = slice_plane(grid, origin, normal, req.field,
                         extent_u=req.extent_u, extent_v=req.extent_v,
                         resolution=req.resolution,
                         with_vectors=req.with_vectors,
                         vector_stride=req.vector_stride)
        out = self._out_dir("plane")
        p = render_slice_png(sl, out / "plane_slice.png", clim=req.clim,
                             cmap=req.cmap, dpi=req.dpi,
                             vector_stride=req.vector_stride)
        return {"file": str(p), "origin": origin.tolist(),
                "normal": (normal / np.linalg.norm(normal)).tolist()}

    def run_plane_batch(self, ds_id: str, req: PlaneSliceBatch,
                        report=lambda f, m="": None) -> dict[str, Any]:
        grid = self.store.get_grid(ds_id)
        center = grid.bounds.mean(axis=0)
        distances = positions_from_range(req.distance_start, req.distance_stop,
                                         req.distance_step)
        slices, paths_meta = [], []
        for i, d in enumerate(distances):
            if req.mode == "euler":
                origin, normal = euler_to_point_normal(
                    req.tilt_deg, req.azimuth_deg, float(d), center)
            else:
                normal = np.asarray(req.normal, dtype=np.float64)
                normal = normal / np.linalg.norm(normal)
                origin = np.asarray(req.origin, dtype=np.float64) + normal * float(d)
            slices.append(slice_plane(grid, origin, normal, req.field,
                                      extent_u=req.extent_u, extent_v=req.extent_v,
                                      resolution=req.resolution,
                                      with_vectors=req.with_vectors,
                                      vector_stride=req.vector_stride))
            paths_meta.append(d)
            report(0.5 * (i + 1) / len(distances), f"plane d={d:.4g}")
        out = self._out_dir("planes")
        clim = req.clim or compute_global_clim([s.values for s in slices])
        paths = []
        for i, (sl, d) in enumerate(zip(slices, paths_meta)):
            p = out / f"plane_{i:04d}_{d:+.6f}m.png"
            render_slice_png(sl, p, clim=clim, cmap=req.cmap, dpi=req.dpi,
                             vector_stride=req.vector_stride)
            paths.append(p)
            report(0.5 + 0.45 * (i + 1) / len(slices), p.name)
        zip_path = self._zip(paths, out / "planes.zip")
        return {"n_slices": len(paths), "dir": str(out),
                "files": [str(p) for p in paths], "zip": str(zip_path),
                "clim": list(clim)}
