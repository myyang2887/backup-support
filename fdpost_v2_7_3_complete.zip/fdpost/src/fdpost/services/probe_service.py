"""Line probe use-case: CSV + curve PNG."""
from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any

from fdpost.config import Settings
from fdpost.core.query import sample_line
from fdpost.domain.requests import LineProbeRequest
from fdpost.io.csv_writer import write_csv
from fdpost.render.lineplot import render_line_png
from fdpost.services.dataset_store import DatasetStore


class ProbeService:
    def __init__(self, store: DatasetStore, settings: Settings) -> None:
        self.store = store
        self.settings = settings

    def run(self, ds_id: str, req: LineProbeRequest) -> dict[str, Any]:
        grid = self.store.get_grid(ds_id)
        for f in req.fields:
            grid.masked(f)  # raises FieldNotFoundError early
        df = sample_line(grid, req.p0, req.p1, req.n_samples, req.fields)
        out = Path(self.settings.output_dir) / f"probe_{uuid.uuid4().hex[:8]}"
        out.mkdir(parents=True, exist_ok=True)
        csv_path = write_csv(df, out / "line.csv", units=grid.units)
        png_path = render_line_png(df, req.fields, out / "line.png",
                                   units=grid.units)
        return {"csv": str(csv_path), "png": str(png_path), "n_rows": len(df)}
