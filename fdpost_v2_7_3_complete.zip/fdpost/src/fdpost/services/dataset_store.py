"""Dataset registry: source file -> FieldData -> cached UniformGrid (LRU)."""
from __future__ import annotations

import json
import logging
import threading
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from fdpost.config import Settings
from fdpost.core.resample import resample_to_grid
from fdpost.domain.errors import DataLoadError, JobNotFoundError
from fdpost.domain.requests import PreprocessConfig
from fdpost.domain.uniform_grid import UniformGrid
from fdpost.io.grid_cache import (cache_key, load_grid, save_grid,
                                  source_signature)
from fdpost.io.registry import Registry
from fdpost.io.tsv_loader import load_floefd_table
from fdpost.services.jobs import Job, JobManager
from fdpost.services.source_sampler import (SourceSampler,
                                            SourceSamplerCache)

log = logging.getLogger("fdpost.services.dataset_store")


@dataclass
class DatasetInfo:
    id: str
    source_path: str
    cache_path: str
    status: str = "processing"           # processing | ready | error
    error: str | None = None
    meta: dict[str, Any] = field(default_factory=dict)
    units: dict[str, str] = field(default_factory=dict)
    fields: list[str] = field(default_factory=list)
    bounds: list[list[float]] | None = None
    dims: list[int] | None = None
    spacing: list[float] | None = None
    config: dict[str, Any] = field(default_factory=dict)

    def public(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}


class DatasetStore:
    """Thread-safe registry with an LRU of in-memory grids."""

    def __init__(self, settings: Settings, jobs: JobManager,
                 registry: Registry | None = None) -> None:
        self.settings = settings
        self.jobs = jobs
        self.registry = registry
        self._infos: dict[str, DatasetInfo] = {}
        self._grids: OrderedDict[str, UniformGrid] = OrderedDict()
        self._lock = threading.RLock()
        self._samplers = SourceSamplerCache(settings.source_sampler_lru)
        if registry is not None:
            self._restore(registry)

    def _restore(self, registry: Registry) -> None:
        """Rehydrate the registry from SQLite; grids reload lazily from cache."""
        for payload in registry.load_datasets():
            try:
                info = DatasetInfo(**payload)
            except TypeError:
                log.warning("skipping incompatible dataset row: %s",
                            payload.get("id"))
                continue
            if info.status == "ready" and not Path(info.cache_path).exists():
                info.status = "error"
                info.error = "キャッシュファイルが見つかりません(再前処理してください)"
            elif info.status == "processing":     # crashed mid-run
                info.status = "error"
                info.error = "前処理が中断されました(再前処理してください)"
            self._infos[info.id] = info
        log.info("restored %d dataset(s) from registry", len(self._infos))

    def _persist(self, info: DatasetInfo) -> None:
        if self.registry is not None:
            self.registry.upsert_dataset(info.id, info.public())

    # -- registration ------------------------------------------------------
    def register(self, source: str | Path, cfg: PreprocessConfig) -> tuple[DatasetInfo, Job]:
        source = Path(source)
        if not source.exists():
            raise DataLoadError(f"file not found: {source}")
        sig = source_signature(source)
        key = cache_key(sig, json.dumps(cfg.model_dump(), sort_keys=True))
        cache_path = Path(self.settings.cache_dir) / f"{key}.npz"
        ds_id = uuid.uuid4().hex[:12]
        info = DatasetInfo(id=ds_id, source_path=str(source),
                           cache_path=str(cache_path),
                           config=cfg.model_dump())
        with self._lock:
            self._infos[ds_id] = info

        def work(report) -> dict[str, Any]:
            try:
                return self._work(info, source, cfg, cache_path, report)
            except Exception as e:
                with self._lock:
                    info.status = "error"
                    info.error = str(e)
                self._persist(info)
                raise

        job = self.jobs.submit("preprocess", work)
        return info, job

    def _work(self, info: DatasetInfo, source: Path, cfg: PreprocessConfig,
              cache_path: Path, report) -> dict[str, Any]:
            grid: UniformGrid | None = None
            if cache_path.exists():
                try:
                    report(0.05, "loading cached grid")
                    grid = load_grid(cache_path)
                    log.info("cache hit for %s", source.name)
                except Exception:
                    grid = None
            if grid is None:
                report(0.05, "loading table")
                fd = load_floefd_table(source, fluid_rule=cfg.fluid_rule)
                report(0.15, "resampling to uniform grid")
                grid = resample_to_grid(
                    fd, cfg,
                    progress=lambda f, m: report(0.15 + 0.75 * f, m))
                report(0.92, "writing grid cache")
                save_grid(grid, cache_path)
            self._finalize(info, grid)
            return {"dataset_id": info.id}

    def _finalize(self, info: DatasetInfo, grid: UniformGrid) -> None:
        with self._lock:
            info.status = "ready"
            info.meta = dict(grid.meta)
            info.units = dict(grid.units)
            info.fields = sorted(grid.arrays)
            info.bounds = grid.bounds.tolist()
            info.dims = list(grid.dims)
            info.spacing = grid.spacing.tolist()
            self._grids[info.id] = grid
            self._grids.move_to_end(info.id)
            while len(self._grids) > self.settings.grid_lru_size:
                evicted, _ = self._grids.popitem(last=False)
                log.info("LRU evicted grid %s", evicted)
        self._persist(info)

    # -- access -------------------------------------------------------------
    def info(self, ds_id: str) -> DatasetInfo:
        with self._lock:
            if ds_id not in self._infos:
                raise JobNotFoundError(f"dataset '{ds_id}' not found")
            return self._infos[ds_id]

    def storage(self, info: "DatasetInfo") -> dict[str, Any]:
        """Disk this dataset occupies, split by what deletion can free.

        `source_owned` is the distinction that matters: a file we received
        through upload lives in data_dir and is ours to remove, while a path
        the user registered in place belongs to them and is never touched —
        so its bytes are reported but not counted as reclaimable.
        """
        src = Path(info.source_path) if info.source_path else None
        cache = Path(info.cache_path) if info.cache_path else None
        src_bytes = src.stat().st_size if src and src.exists() else 0
        cache_bytes = cache.stat().st_size if cache and cache.exists() else 0
        owned = False
        if src and src.exists():
            data_dir = Path(self.settings.data_dir).resolve()
            owned = data_dir in src.resolve().parents
        return {"source_bytes": int(src_bytes),
                "cache_bytes": int(cache_bytes),
                "source_owned": owned,
                "reclaimable_bytes": int(cache_bytes + (src_bytes if owned else 0))}

    def list(self) -> list[dict[str, Any]]:
        with self._lock:
            infos = list(self._infos.values())
        return [{**i.public(), "storage": self.storage(i)} for i in infos]

    def get_sampler(self, ds_id: str) -> SourceSampler:
        """Sampler over the original scattered file, for queries that want more
        detail than the preprocessing grid holds. Reloads the source on first
        use and keeps a small LRU — the KD-tree fit is the expensive part."""
        cached = self._samplers.get(ds_id)
        if cached is not None:
            return cached
        info = self.info(ds_id)
        if info.status != "ready":
            raise DataLoadError(f"dataset '{ds_id}' not ready")
        cfg = PreprocessConfig(**info.config) if info.config else PreprocessConfig()
        fd = load_floefd_table(Path(info.source_path), fluid_rule=cfg.fluid_rule)
        log.info("source sampler for %s: %d points", ds_id, fd.points.shape[0])
        return self._samplers.put(
            ds_id, SourceSampler(fd, cfg.method, dict(cfg.interp_params)))

    def get_grid(self, ds_id: str) -> UniformGrid:
        info = self.info(ds_id)
        with self._lock:
            if ds_id in self._grids:
                self._grids.move_to_end(ds_id)
                return self._grids[ds_id]
        if info.status != "ready":
            raise DataLoadError(f"dataset '{ds_id}' not ready (status={info.status})")
        grid = load_grid(info.cache_path)          # reload after LRU eviction
        with self._lock:
            self._grids[ds_id] = grid
            self._grids.move_to_end(ds_id)
            while len(self._grids) > self.settings.grid_lru_size:
                self._grids.popitem(last=False)
        return grid

    # -- removal -------------------------------------------------------------
    def delete(self, ds_id: str, drop_source: bool = False) -> dict[str, Any]:
        """Forget a dataset: registry row, LRU entry and npz cache.

        The uploaded source file is only removed when `drop_source` is set and
        the file lives inside our own data_dir — a registered path belongs to
        the user and is never touched.
        """
        info = self.info(ds_id)
        freed = self.storage(info)["reclaimable_bytes"] if drop_source \
            else self.storage(info)["cache_bytes"]
        with self._lock:
            self._infos.pop(ds_id, None)
            self._grids.pop(ds_id, None)
        self._samplers.drop(ds_id)
        if self.registry is not None:
            self.registry.delete_dataset(ds_id)
        removed = []
        cache = Path(info.cache_path) if info.cache_path else None
        if cache and cache.exists():
            cache.unlink(missing_ok=True)
            removed.append(str(cache))
        if drop_source and info.source_path:
            src = Path(info.source_path).resolve()
            data_dir = Path(self.settings.data_dir).resolve()
            if src.exists() and data_dir in src.parents:   # our upload, not theirs
                src.unlink(missing_ok=True)
                removed.append(str(src))
        log.info("deleted dataset %s (%d files, %d bytes)",
                 ds_id, len(removed), freed)
        return {"id": ds_id, "removed_files": removed,
                "freed_bytes": int(freed)}
