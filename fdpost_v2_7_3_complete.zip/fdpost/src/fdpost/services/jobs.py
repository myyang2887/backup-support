"""Minimal background job manager (ThreadPoolExecutor)."""
from __future__ import annotations

import logging
import threading
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable

from fdpost.domain.errors import JobNotFoundError

log = logging.getLogger("fdpost.services.jobs")


@dataclass
class Job:
    id: str
    kind: str
    status: str = "pending"       # pending | running | done | error
    progress: float = 0.0
    message: str = ""
    result: dict[str, Any] | None = None
    error: str | None = None
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {"id": self.id, "kind": self.kind, "status": self.status,
                    "progress": round(self.progress, 4), "message": self.message,
                    "result": self.result, "error": self.error}


class JobManager:
    def __init__(self, workers: int = 2) -> None:
        self._pool = ThreadPoolExecutor(max_workers=workers,
                                        thread_name_prefix="fdpost-job")
        self._jobs: dict[str, Job] = {}
        self._lock = threading.Lock()

    def submit(self, kind: str,
               fn: Callable[[Callable[[float, str], None]], dict[str, Any]]) -> Job:
        job = Job(id=uuid.uuid4().hex[:12], kind=kind)
        with self._lock:
            self._jobs[job.id] = job

        def report(fraction: float, message: str = "") -> None:
            with job._lock:
                job.progress = float(fraction)
                if message:
                    job.message = message

        def run() -> None:
            with job._lock:
                job.status = "running"
            try:
                result = fn(report)
                with job._lock:
                    job.status, job.progress, job.result = "done", 1.0, result
            except Exception as e:  # noqa: BLE001
                log.error("job %s failed: %s\n%s", job.id, e, traceback.format_exc())
                with job._lock:
                    job.status, job.error = "error", f"{type(e).__name__}: {e}"

        self._pool.submit(run)
        return job

    def get(self, job_id: str) -> Job:
        with self._lock:
            if job_id not in self._jobs:
                raise JobNotFoundError(f"job '{job_id}' not found")
            return self._jobs[job_id]

    def shutdown(self) -> None:
        self._pool.shutdown(wait=False, cancel_futures=True)
