"""Desktop shell: pywebview window + embedded uvicorn server.
Adds native save dialogs (real free-path export, unlike the browser sandbox)."""
from __future__ import annotations

import shutil
import socket
import threading
from pathlib import Path


def _find_free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class DesktopBridge:
    """Exposed to JS as window.pywebview.api.*"""

    def __init__(self) -> None:
        self.window = None

    def choose_save_dir(self) -> str | None:
        import webview
        res = self.window.create_file_dialog(webview.FOLDER_DIALOG)
        return res[0] if res else None

    def export_to(self, src_path: str, dest_dir: str) -> str:
        src, dest = Path(src_path), Path(dest_dir)
        dest.mkdir(parents=True, exist_ok=True)
        out = dest / src.name
        shutil.copy2(src, out)
        return str(out)


def run_desktop() -> None:
    import uvicorn
    import webview

    from fdpost.api.app import create_app
    from fdpost.config import Settings

    port = _find_free_port()
    settings = Settings(port=port)
    config = uvicorn.Config(create_app(settings), host="127.0.0.1",
                            port=port, log_level="warning")
    server = uvicorn.Server(config)
    threading.Thread(target=server.run, daemon=True).start()

    bridge = DesktopBridge()
    window = webview.create_window("fdpost", f"http://127.0.0.1:{port}",
                                   js_api=bridge, width=1440, height=900)
    bridge.window = window
    webview.start()
    server.should_exit = True
