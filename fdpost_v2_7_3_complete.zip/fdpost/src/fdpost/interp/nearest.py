"""Nearest-neighbour interpolation (fastest; preview-grade)."""
from __future__ import annotations

import numpy as np
from scipy.spatial import cKDTree

from fdpost.interp.base import Interpolator
from fdpost.interp.registry import register


@register
class NearestInterpolator(Interpolator):
    name = "nearest"

    def fit(self, points: np.ndarray) -> "NearestInterpolator":
        self._tree = cKDTree(np.asarray(points, dtype=np.float64))
        return self

    def interpolate(self, values: np.ndarray, query: np.ndarray) -> np.ndarray:
        _, idx = self._tree.query(np.asarray(query, dtype=np.float64), k=1, workers=-1)
        return np.asarray(values, dtype=np.float64)[idx]
