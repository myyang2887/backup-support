"""Piecewise-linear (Delaunay) interpolation; NaN outside the convex hull."""
from __future__ import annotations

import numpy as np
from scipy.interpolate import LinearNDInterpolator
from scipy.spatial import Delaunay, QhullError

from fdpost.domain.errors import GridBuildError
from fdpost.interp.base import Interpolator
from fdpost.interp.registry import register


@register
class LinearInterpolator(Interpolator):
    name = "linear"

    def fit(self, points: np.ndarray) -> "LinearInterpolator":
        try:
            self._tri = Delaunay(np.asarray(points, dtype=np.float64))
        except QhullError as e:  # near-coplanar cloud
            raise GridBuildError(
                "Delaunay triangulation failed (near-coplanar points?); try method='idw'"
            ) from e
        return self

    def interpolate(self, values: np.ndarray, query: np.ndarray) -> np.ndarray:
        itp = LinearNDInterpolator(self._tri, np.asarray(values, dtype=np.float64))
        return itp(np.asarray(query, dtype=np.float64))
