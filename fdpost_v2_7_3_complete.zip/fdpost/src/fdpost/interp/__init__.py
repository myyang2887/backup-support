"""Import concrete implementations to trigger registration; re-export API."""
from fdpost.interp import idw, linear, nearest, rbf  # noqa: F401  (registration)
from fdpost.interp.base import Interpolator
from fdpost.interp.registry import available_methods, get_interpolator

__all__ = ["Interpolator", "get_interpolator", "available_methods"]
