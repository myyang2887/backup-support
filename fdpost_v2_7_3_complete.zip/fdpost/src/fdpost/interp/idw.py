"""Inverse-distance-weighted interpolation (k-NN; speed/quality compromise)."""
from __future__ import annotations

import numpy as np
from scipy.spatial import cKDTree

from fdpost.interp.base import Interpolator
from fdpost.interp.registry import register


@register
class IDWInterpolator(Interpolator):
    name = "idw"

    def __init__(self, k: int = 8, power: float = 2.0) -> None:
        self.k = int(k)
        self.power = float(power)

    def fit(self, points: np.ndarray) -> "IDWInterpolator":
        pts = np.asarray(points, dtype=np.float64)
        self._tree = cKDTree(pts)
        self._n = pts.shape[0]
        return self

    def interpolate(self, values: np.ndarray, query: np.ndarray) -> np.ndarray:
        vals = np.asarray(values, dtype=np.float64)
        squeeze = vals.ndim == 1
        v2 = vals.reshape(vals.shape[0], -1)                       # (N,F)
        k = min(self.k, self._n)
        dist, idx = self._tree.query(np.asarray(query, dtype=np.float64),
                                     k=k, workers=-1)
        dist = np.atleast_2d(dist); idx = np.atleast_2d(idx)
        exact = dist[:, 0] <= 1e-12
        d = np.maximum(dist, 1e-12)
        w = d ** (-self.power)
        w /= w.sum(axis=1, keepdims=True)
        out = np.einsum("mk,mkf->mf", w, v2[idx])
        if exact.any():
            out[exact] = v2[idx[exact, 0]]
        return out[:, 0] if squeeze else out
