"""Interpolator strategy interface (scattered -> arbitrary query points)."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import ClassVar

import numpy as np


class Interpolator(ABC):
    """fit() builds value-independent structure (KDTree/Delaunay);
    interpolate() supports multi-field values (N,) or (N,F) so all fields
    of one dataset share a single spatial query."""

    name: ClassVar[str]

    @abstractmethod
    def fit(self, points: np.ndarray) -> "Interpolator":
        """points: (N,3) float64. Returns self."""

    @abstractmethod
    def interpolate(self, values: np.ndarray, query: np.ndarray) -> np.ndarray:
        """values (N,) or (N,F); query (M,3). Returns (M,) or (M,F);
        NaN where the value cannot be computed (method-dependent)."""
