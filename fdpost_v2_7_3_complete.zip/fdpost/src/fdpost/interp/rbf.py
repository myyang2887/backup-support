"""Radial-basis-function interpolation (small data, high quality)."""
from __future__ import annotations

import logging

import numpy as np
from scipy.interpolate import RBFInterpolator as ScipyRBF

from fdpost.interp.base import Interpolator
from fdpost.interp.registry import register

log = logging.getLogger("fdpost.interp.rbf")


@register
class RBFInterpolator(Interpolator):
    name = "rbf"

    def __init__(self, kernel: str = "thin_plate_spline",
                 neighbors: int = 64, max_points: int = 200_000) -> None:
        self.kernel = kernel
        self.neighbors = int(neighbors)
        self.max_points = int(max_points)

    def fit(self, points: np.ndarray) -> "RBFInterpolator":
        pts = np.asarray(points, dtype=np.float64)
        n = pts.shape[0]
        if n > self.max_points:
            log.warning("RBF: subsampling %d -> %d points", n, self.max_points)
            self._sel = np.sort(
                np.random.default_rng(0).choice(n, self.max_points, replace=False)
            )
        else:
            self._sel = np.arange(n)
        self._points = pts[self._sel]
        return self

    def interpolate(self, values: np.ndarray, query: np.ndarray) -> np.ndarray:
        vals = np.asarray(values, dtype=np.float64)[self._sel]
        itp = ScipyRBF(self._points, vals, kernel=self.kernel,
                       neighbors=min(self.neighbors, self._points.shape[0]))
        return itp(np.asarray(query, dtype=np.float64))
