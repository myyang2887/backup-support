"""Interpolator registry (strategy pattern)."""
from __future__ import annotations

from fdpost.interp.base import Interpolator

_REGISTRY: dict[str, type[Interpolator]] = {}


def register(cls: type[Interpolator]) -> type[Interpolator]:
    if cls.name in _REGISTRY:
        raise ValueError(f"interpolator '{cls.name}' already registered")
    _REGISTRY[cls.name] = cls
    return cls


def get_interpolator(name: str, **params) -> Interpolator:
    if name not in _REGISTRY:
        raise ValueError(
            f"unknown interpolation method '{name}'; available: {available_methods()}"
        )
    return _REGISTRY[name](**params)


def available_methods() -> list[str]:
    return sorted(_REGISTRY)
