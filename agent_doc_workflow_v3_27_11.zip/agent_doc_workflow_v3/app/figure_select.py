"""
要約文への図版差し込み（v3.27）。

## なぜ「LLM に選ばせない」のか

「この 30 枚から、この文に一番合う 2〜3 枚を選べ」は弱いモデルには無理な
タスクで、必ずランダムに退化する。ここでは選定を**確定的なコード**が行い、
モデルには（任意で）最後に「この図はこの文を示しているか」の
Yes/No だけを聞く。順位付けは苦手でも二値判定なら弱いモデルでも当たる。

## 「多く挿す」より「間違えない」

既定の挙動は **挿さない**。以下を全部満たしたものだけが図版になる。

  1. 絶対スコアが閾値以上
  2. 同じ文に対する **2 位との差** が閾値以上（＝どちらとも取れる状況では挿さない）
  3. 1 文につき最大 1 枚、1 文書につき最大 N 枚（既定 3）
  4. 1 枚の画像は 1 か所にしか使わない

2 番目が肝。学術論文と同じで「間違った図が付いている」のは
「図が無い」よりはるかに悪い。

## スコアの内訳（重み順）

| 成分 | 既定重み | 根拠 |
|---|---|---|
| 数値・単位の一致 | 0.40 | 工学資料で唯一の高精度アンカー。「12.5 kPa」が本文と図の両方に出れば、ほぼ確定 |
| 語 n-gram の一致 | 0.28 | `key_facts` + `visual_summary` との重なり。日本語なので文字 n-gram（形態素解析器＝ライセンス依存を持ち込まない） |
| 同一ページ性 | 0.20 | 文の出所ページと図のページ。`Evidence.page` / `VisualEvidence.page` が既に持っている |
| 読み取りテキスト | 0.12 | 図中 OCR 相当。ノイズが多いので低め |

適用できない成分（本文に数値が無い等）は重みを他へ再配分する。
最後に画像自身の `confidence` で 0.7〜1.0 倍する（支配させない）。

## 既知の罠を回避している箇所

- `visual_contact/` の格子画像（密集ページの合成）は**候補から除外**。
  合成コンタクトシートを図版として貼ってはいけない。
- `visual_filtered/*_ds.jpg` は VLM 用の降采样版。掲載には
  `_resolve_original()` で元解像度ファイルへ戻す。
- 採用した図は `run_dir/figures/` へコピーする。後段の掃除や
  一括エクスポートで参照が切れないようにするため。
- 社外（脱敏）版は既定で図版なし。`redaction.py` は本文しか伏せず、
  画像内の社名・ロゴ・製品外観は素通りするため。
"""
from __future__ import annotations

import json
import re
import shutil
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

# ----------------------------------------------------------------------
# 既定値（config.yaml の figures: で上書きできる）
# ----------------------------------------------------------------------

DEFAULTS: Dict[str, Any] = {
    "enabled": True,
    "max_figures": 3,
    "min_score": 0.42,
    "min_margin": 0.10,
    # v3.27.2：既定 0.0。VLM の confidence は当てにならない（書式見本の 0.0 を
    # そのまま返すモデルが多く、0.35 の門で全滅していた）。読み取り量の
    # 有無は content gate（下）で見て、confidence は soft な係数としてだけ使う。
    "min_image_confidence": 0.0,
    "require_content": True,          # visual_summary/key_facts/readable_text が全て空なら除外
    "trust_has_useful_flag": False,   # has_useful_visual_info=false を門にするか（既定は使わない）
    "allow_page_render": False,      # 全面レンダリングは「図」ではない
    "external_tier": False,          # 社外版に図を入れるか（既定 false＝入れない）
    "verify_with_vlm": False,        # 最終候補にだけ Yes/No 確認を掛ける
    # ---- 要約側が [[V3]] で名指しした図 ----
    "use_citations": True,
    "cited_min_score": 0.15,         # 名指しでも最低限の裏取りは要る
    "worthiness_bonus": {"core": 0.10, "supporting": 0.03, "incidental": -0.05},
    "max_width_mm": 150.0,
    "max_height_mm": 95.0,
    "caption_max_chars": 28,     # 表示用の図注の長さ。説明は本文の仕事
    "allow_sections": [
        "判明した事実", "Findings", "対応効果", "Effects", "実施内容",
        "Implementation", "主要結果", "Key Results", "考察", "Discussion",
        "手法", "Methods", "解析・実験条件", "Conditions", "主な内容", "要点",
    ],
    "deny_sections": ["根拠情報", "収録案件", "メインタイトル"],
    "weights": {"numeric": 0.40, "ngram": 0.28, "page": 0.20, "readable": 0.12},
}

_DECOR_TYPES = {"logo", "icon", "decoration", "装飾", "アイコン", "ロゴ", "unknown_decoration"}
_PAGE_KINDS = {"page_render", "sheet_render"}

# ----------------------------------------------------------------------
# 正規化ユーティリティ（形態素解析器なし＝ライセンス依存を増やさない）
# ----------------------------------------------------------------------

_NUM_RE = re.compile(r"[-+]?\d{1,3}(?:,\d{3})+(?:\.\d+)?|[-+]?\d+(?:\.\d+)?")
_UNIT_RE = re.compile(
    r"(?:kpa|mpa|gpa|pa|bar|mm2|mm|cm|um|μm|nm|mpa|℃|°c|kelvin|hz|khz|mhz|rpm|"
    r"kn|mn|nm|kgf|kg|mg|g|m/s|km/h|l/min|ml|l|db|kv|v|ma|a|kw|w|%|％|"
    r"倍|割|件|回|時間|分|秒|日|人|円|万円)",
    re.IGNORECASE)
_PUNCT_RE = re.compile(r"[\s、。，．,.\u3000・:：;；()（）\[\]「」『』【】/／\\\-—–_=+*#|>＜＞<\"'`]+")


def _nfkc(s: str) -> str:
    return unicodedata.normalize("NFKC", str(s or "")).lower()


def _flatten(value: Any) -> str:
    """str / list / dict をまとめて 1 本の文字列に。証拠の形が揺れても壊れないように。"""
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple, set)):
        return " ".join(_flatten(v) for v in value)
    if isinstance(value, dict):
        return " ".join(_flatten(v) for v in value.values())
    return str(value)


def _canon_number(tok: str) -> str:
    """1,200 → 1200 / 12.50 → 12.5。表記ゆれで取り逃がさないため。"""
    try:
        return f"{float(tok.replace(',', '')):g}"
    except (TypeError, ValueError):
        return tok


def numeric_tokens(text: str) -> Dict[str, float]:
    """数値 → 重み。小数付き・3 桁以上は「強い」、1〜2 桁の整数は弱い。

    「図 1」「3 件」のような小さい整数は偶然一致しやすいので重みを落とす。
    年号（1900〜2100）も日付として頻出するため弱い扱いにする。
    """
    s = _nfkc(text)
    out: Dict[str, float] = {}
    for m in _NUM_RE.finditer(s):
        raw = m.group(0)
        canon = _canon_number(raw)
        strong = ("." in canon) or (len(canon.lstrip("-+").replace(".", "")) >= 3)
        try:
            v = float(canon)
            if 1900.0 <= v <= 2100.0 and v.is_integer():
                strong = False            # 年号らしい
        except ValueError:
            pass
        w = 1.0 if strong else 0.25
        out[canon] = max(out.get(canon, 0.0), w)
    return out


def unit_tokens(text: str) -> set:
    return {m.group(0).lower() for m in _UNIT_RE.finditer(_nfkc(text))}


def char_ngrams(text: str, n: int = 3) -> set:
    s = _PUNCT_RE.sub("", _nfkc(text))
    if len(s) < n:
        return {s} if s else set()
    return {s[i:i + n] for i in range(len(s) - n + 1)}


def _overlap(a: set, b: set) -> float:
    """重なり係数（Jaccard ではない）。

    本文 1 文（短い）と図の読み取り（長い）を比べるので、Jaccard だと
    長さ差で必ず 0 近くに潰れる。短い方を分母にする。
    """
    if not a or not b:
        return 0.0
    return len(a & b) / float(min(len(a), len(b)))


# ----------------------------------------------------------------------
# 候補（VisualEvidence 由来）
# ----------------------------------------------------------------------

@dataclass
class Candidate:
    evidence_id: str
    image_path: str                  # VLM が見た画像（降采样済みのことがある）
    display_path: str                # 掲載に使う画像（元解像度）
    page: Optional[int] = None
    sheet_name: str = ""
    visual_type: str = "unknown"
    asset_kind: str = "embedded"
    visual_summary: str = ""
    figure_caption: str = ""         # VLM の内容説明（要約モデル向け・長い）
    figure_title: str = ""           # VLM の見出し（表示向け・短い）
    worthiness: str = ""             # core | supporting | incidental
    key_facts: List[str] = field(default_factory=list)
    readable_text: List[str] = field(default_factory=list)
    confidence: float = 0.0
    # 事前計算（毎文ごとに作り直すと O(文 x 図) で無駄）
    _facts_ng: set = field(default_factory=set, repr=False)
    _read_ng: set = field(default_factory=set, repr=False)
    _nums: Dict[str, float] = field(default_factory=dict, repr=False)
    _units: set = field(default_factory=set, repr=False)

    @property
    def label(self) -> str:
        if self.sheet_name:
            return f"シート「{self.sheet_name}」"
        if self.page:
            return f"p.{self.page}"
        return Path(self.display_path).name


_RAW_ASSET_DIRS = ("visual_pdf", "visual_office", "visual_pages", "visual_excel", "visual_raw")


def _resolve_original(image_path: str, run_dir: Optional[Path]) -> str:
    """降采样版（`*_ds.jpg`）を元解像度ファイルへ戻す。

    prefilter_and_downscale_images() は長辺 1024px へ落とした JPEG を
    visual_filtered/ に置く。VLM に食わせるにはそれで良いが、
    そのまま PDF/Word に貼ると潰れる。
    """
    p = Path(image_path)
    if run_dir is None or not p.name.endswith("_ds.jpg"):
        return str(p)
    stem = p.name[:-len("_ds.jpg")]
    for d in _RAW_ASSET_DIRS:
        base = run_dir / d
        if not base.is_dir():
            continue
        for cand in sorted(base.glob(f"{stem}.*")):
            if cand.is_file():
                return str(cand)
    return str(p)


def _is_contact_sheet(image_path: str) -> bool:
    """密集ページの格子合成画像。図版として貼ってはいけない。"""
    parts = {q.lower() for q in Path(image_path).parts}
    return "visual_contact" in parts or Path(image_path).name.startswith("contact_")


def build_candidates(visual_evidence: Sequence[Dict[str, Any]],
                     run_dir: Optional[Path],
                     cfg: Dict[str, Any],
                     drops: Optional[Dict[str, int]] = None) -> List[Candidate]:
    """VisualEvidence（dict のまま）から掲載候補を作る。

    pydantic に依存しない：state / キャッシュ JSON / dry-run どこからでも
    同じ関数が使えるようにするため。

    `drops` を渡すと**どの門で何枚落ちたか**を数える。ここを黙って捨てると
    「候補 0 枚」としか分からず、閾値の問題なのか抽出の問題なのか
    切り分けられない（v3.27.1 で追加）。
    """
    out: List[Candidate] = []
    min_conf = float(cfg.get("min_image_confidence", 0.35))
    allow_page = bool(cfg.get("allow_page_render", False))
    d = drops if drops is not None else {}

    def _drop(reason: str) -> None:
        d[reason] = d.get(reason, 0) + 1

    for e in visual_evidence or []:
        path = str(e.get("image_path") or "")
        if not path:
            _drop("image_path が空")
            continue
        if _is_contact_sheet(path) or str(e.get("asset_kind") or "") == "contact_sheet":
            _drop("格子合成画像（密集ページのまとめ）")
            continue
        kind = str(e.get("asset_kind") or "embedded")
        if kind in _PAGE_KINDS and not allow_page:
            _drop("全面レンダリング（allow_page_render=false）")
            continue
        vtype = str(e.get("visual_type") or "unknown").lower()
        if vtype in _DECOR_TYPES:
            _drop(f"装飾扱いの visual_type（{vtype}）")
            continue
        # has_useful_visual_info は既定 False の契約フィールドで、VLM が
        # 明示しないと全件 false になる。門にするのは opt-in。
        if (cfg.get("trust_has_useful_flag", False)
                and not e.get("has_useful_visual_info", True)
                and kind not in _PAGE_KINDS):
            _drop("has_useful_visual_info=false（VLM が情報なしと判断）")
            continue
        try:
            conf = float(e.get("confidence") or 0.0)
        except (TypeError, ValueError):
            conf = 0.0
        if min_conf > 0.0 and conf < min_conf:
            _drop(f"confidence {conf:.2f} < min_image_confidence {min_conf}")
            continue

        facts = e.get("key_facts") or []
        read = e.get("readable_text") or []
        summary = _flatten(e.get("visual_summary"))
        caption = _flatten(e.get("figure_caption"))
        facts_text = (_flatten(facts) + " " + summary + " " + caption + " "
                      + _flatten(e.get("possible_relevance")))
        read_text = _flatten(read)
        # 読み取り結果が丸ごと空の図は、何と照合しても当たらない。
        # confidence ではなく**中身の有無**で切るのが正しい門。
        if cfg.get("require_content", True) and not _PUNCT_RE.sub(
                "", _nfkc(facts_text + read_text)):
            _drop("読み取り結果が空（visual_summary / key_facts / readable_text とも無し）")
            continue

        display = _resolve_original(path, run_dir)
        if not Path(display).exists():
            if not Path(path).exists():
                _drop("画像ファイルが見つからない")
                continue
            display = path

        c = Candidate(
            evidence_id=str(e.get("evidence_id") or ""),
            image_path=path,
            display_path=display,
            page=e.get("page") if isinstance(e.get("page"), int) else None,
            sheet_name=str(e.get("sheet_name") or ""),
            visual_type=vtype,
            asset_kind=kind,
            visual_summary=summary,
            figure_caption=caption,
            figure_title=_flatten(e.get("figure_title")),
            worthiness=str(e.get("figure_worthiness") or "").lower(),
            key_facts=[_flatten(f) for f in facts] if isinstance(facts, list) else [facts_text],
            readable_text=[_flatten(r) for r in read] if isinstance(read, list) else [read_text],
            confidence=conf,
        )
        c._facts_ng = char_ngrams(facts_text)
        c._read_ng = char_ngrams(read_text)
        c._nums = numeric_tokens(facts_text + " " + read_text)
        c._units = unit_tokens(facts_text + " " + read_text)
        out.append(c)
    return out


def apply_df_filter(cands: List[Candidate], min_docs: int = 5, df_ratio: float = 0.6) -> None:
    """全候補に共通して出る n-gram を落とす（定型ヘッダ・社名・単位記号など）。

    IDF を持ち込むほどでもないが、これが無いと「どの図もそこそこ似ている」
    状態になり、2 位との差が出ず結局 1 枚も挿さらない。
    """
    if len(cands) < min_docs:
        return
    df: Dict[str, int] = {}
    for c in cands:
        for g in (c._facts_ng | c._read_ng):
            df[g] = df.get(g, 0) + 1
    limit = max(2, int(len(cands) * df_ratio))
    common = {g for g, n in df.items() if n > limit}
    if not common:
        return
    for c in cands:
        c._facts_ng -= common
        c._read_ng -= common


# ----------------------------------------------------------------------
# 本文 → ページの橋渡し
# ----------------------------------------------------------------------

def bullet_page_hint(bullet: str, text_evidence: Sequence[Dict[str, Any]],
                     threshold: float = 0.22) -> Optional[int]:
    """その要約文の出所ページを、本文証拠との一致から推定する。

    要約 JSON は溯源を持たない（LLM に書かせていないので当然）。だが
    `Evidence` は page を持つ。文と証拠を突き合わせれば橋渡しできる。
    確信が無ければ None を返す＝ページ成分を使わない。
    """
    if not text_evidence:
        return None
    bng = char_ngrams(bullet)
    if not bng:
        return None
    best, best_page = 0.0, None
    for ev in text_evidence:
        page = ev.get("page")
        if not isinstance(page, int):
            continue
        s = _overlap(bng, char_ngrams(_flatten(ev.get("content"))))
        if s > best:
            best, best_page = s, page
    return best_page if best >= threshold else None


# ----------------------------------------------------------------------
# スコアリング
# ----------------------------------------------------------------------

def score_pair(bullet: str, cand: Candidate, page_hint: Optional[int],
               weights: Optional[Dict[str, float]] = None,
               worthiness_bonus: Optional[Dict[str, float]] = None,
               ) -> Tuple[float, Dict[str, Any]]:
    w = dict(DEFAULTS["weights"])
    if weights:
        w.update({k: float(v) for k, v in weights.items() if k in w})

    bng = char_ngrams(bullet)
    bnums = numeric_tokens(bullet)
    bunits = unit_tokens(bullet)

    parts: Dict[str, Optional[float]] = {}

    # --- 数値・単位 ---
    if bnums:
        total = sum(bnums.values())
        hit = sum(wt for tok, wt in bnums.items() if tok in cand._nums)
        num = hit / total if total else 0.0
        if bunits:
            # 単位が一致していると「12.5 kPa」対「12.5 mm」の取り違えを防げる
            u = len(bunits & cand._units) / float(len(bunits))
            num = min(1.0, num * (0.75 + 0.25 * u) + 0.10 * u)
        parts["numeric"] = num
    else:
        parts["numeric"] = None

    # --- 語 n-gram ---
    parts["ngram"] = _overlap(bng, cand._facts_ng)
    parts["readable"] = _overlap(bng, cand._read_ng)

    # --- ページ近接 ---
    if page_hint is not None and cand.page is not None:
        diff = abs(page_hint - cand.page)
        parts["page"] = 1.0 if diff == 0 else (0.5 if diff == 1 else 0.0)
    else:
        parts["page"] = None

    # 適用できない成分の重みは他へ再配分（スコアの比較可能性を保つ）
    usable = {k: v for k, v in parts.items() if v is not None}
    wsum = sum(w[k] for k in usable) or 1.0
    raw = sum(w[k] * usable[k] for k in usable) / wsum

    # 画像の読み取り信頼度で穏やかに補正（支配はさせない）。
    # confidence==0.0 は「0 と答えた」ではなく「答えていない」ことが多いので
    # 罰しない（VLM が書式見本の 0.0 をそのまま返す事故が実際に起きた）。
    conf_factor = 1.0 if cand.confidence <= 0.0 else (0.7 + 0.3 * min(1.0, cand.confidence))
    score = raw * conf_factor

    # 図を 1 枚ずつ見た時点の「この資料の中心かどうか」を加点する
    bonus_map = dict(DEFAULTS["worthiness_bonus"])
    if worthiness_bonus:
        bonus_map.update(worthiness_bonus)
    bonus = float(bonus_map.get(cand.worthiness, 0.0)) if cand.worthiness else 0.0
    score = max(0.0, min(1.0, score + bonus))

    return score, {
        "raw": round(raw, 4),
        "score": round(score, 4),
        "parts": {k: (None if v is None else round(v, 4)) for k, v in parts.items()},
        "worthiness": cand.worthiness or None,
        "worthiness_bonus": round(bonus, 4),
        "page_hint": page_hint,
        "cand_page": cand.page,
        "confidence": cand.confidence,
    }


# ----------------------------------------------------------------------
# Markdown の解析（見出し / 箇条書きの位置だけ判れば良い）
# ----------------------------------------------------------------------

@dataclass
class Anchor:
    line_index: int
    text: str                        # [[V3]] を除いた本文
    heading: str
    cited: List[str] = field(default_factory=list)   # 要約側が名指しした図の ID


_HEADING_RE = re.compile(r"^(#{1,4})\s+(.*)$")
_BULLET_RE = re.compile(r"^\s*[-*]\s+(.*)$")
_IMG_RE = re.compile(r"^!\[(.*?)\]\((.+?)\)\s*$")

#: 要約側が付ける図の名指し。[[visual_asset_0011]] / 全角 ［［…］］ も拾う。
#: v3.27.2 の正則は [A-Za-z]{1,3}\d{1,4}（プロンプトの例 "V3" をそのまま
#: 写した）で、実際の ID である visual_asset_0011（nodes.py の
#: f"visual_asset_{idx+1:04d}"）に一致しなかった。結果、名指しは一度も
#: 機能せず、しかもマーカーが本文に残って成果物を汚していた。
#: 弱いモデルは括弧の種類も揺らすので、こちらが広く受ける。
_CITE_RE = re.compile(r"[\[［]{2}\s*([A-Za-z][A-Za-z0-9_\-]{0,63})\s*[\]］]{2}")


def strip_citations(text: str) -> str:
    """本文から [[V3]] を取り除く（成果物に内部 ID を出さない）。"""
    return re.sub(r"\s*" + _CITE_RE.pattern, "", text).strip()


def strip_citations_deep(obj: Any) -> Any:
    """要約 JSON から再帰的に [[V3]] を除く。

    md だけ掃除して JSON を放置すると、RAG 出力・案件台帳・HITL 編集画面に
    内部 ID が漏れる。真源である JSON の側から消す。
    """
    if isinstance(obj, str):
        return strip_citations(obj)
    if isinstance(obj, list):
        return [strip_citations_deep(v) for v in obj]
    if isinstance(obj, dict):
        return {k: strip_citations_deep(v) for k, v in obj.items()}
    return obj


def _section_allowed(heading: str, cfg: Dict[str, Any]) -> bool:
    h = _nfkc(heading)
    for bad in cfg.get("deny_sections", DEFAULTS["deny_sections"]):
        if _nfkc(bad) in h:
            return False
    allows = cfg.get("allow_sections", DEFAULTS["allow_sections"])
    if not allows:
        return True
    return any(_nfkc(a) in h for a in allows)


def find_anchors(md: str, cfg: Dict[str, Any]) -> Tuple[List[str], List[Anchor]]:
    """見出しと箇条書きの位置を拾い、[[V3]] の名指しを回収して本文から除く。

    返す `lines` は既に [[V3]] を除いた状態。呼び出し側はこれを書き戻せば、
    成果物に内部 ID が残らない。
    """
    raw_lines = md.replace("\r\n", "\n").split("\n")
    lines: List[str] = []
    heading = ""
    anchors: List[Anchor] = []
    for i, line in enumerate(raw_lines):
        cited = [m.group(1) for m in _CITE_RE.finditer(line)]
        clean = strip_citations(line) if cited else line
        # 行頭の記号は strip_citations の strip() で消えるので組み直す
        if cited and line.lstrip() != line:
            clean = line[:len(line) - len(line.lstrip())] + clean
        lines.append(clean)

        m = _HEADING_RE.match(clean)
        if m:
            heading = m.group(2).strip()
            continue
        b = _BULLET_RE.match(clean)
        if not b:
            continue
        text = b.group(1).strip()
        if not text or text.startswith("資料内で確認できず") or text == "根拠情報なし":
            continue
        if len(_PUNCT_RE.sub("", text)) < 8:
            continue                       # 短すぎる項目は根拠にならない
        if not _section_allowed(heading, cfg):
            continue
        anchors.append(Anchor(line_index=i, text=text, heading=heading, cited=cited))
    return lines, anchors


# ----------------------------------------------------------------------
# 選定
# ----------------------------------------------------------------------

@dataclass
class Pick:
    anchor: Anchor
    cand: Candidate
    score: float
    runner_up: float
    breakdown: Dict[str, Any]
    figure_no: int = 0
    caption: str = ""


def select_figures(md: str,
                   visual_evidence: Sequence[Dict[str, Any]],
                   text_evidence: Sequence[Dict[str, Any]] = (),
                   run_dir: Optional[str | Path] = None,
                   cfg: Optional[Dict[str, Any]] = None,
                   verifier: Optional[Callable[[str, Candidate], bool]] = None,
                   ) -> Tuple[List[Pick], Dict[str, Any]]:
    """スコア上位から貪欲に採用する。既定の答えは「採用なし」。"""
    conf = dict(DEFAULTS)
    conf.update(cfg or {})
    rd = Path(run_dir) if run_dir else None

    drops: Dict[str, int] = {}
    cands = build_candidates(visual_evidence, rd, conf, drops=drops)
    apply_df_filter(cands)
    lines, anchors = find_anchors(md, conf)

    report: Dict[str, Any] = {
        "visual_evidence_in": len(visual_evidence or []),
        "candidates": len(cands),
        "dropped_by": drops,                 # どの門で何枚落ちたか
        "anchors": len(anchors),
        "bullets_in": md.count("\n- ") + (1 if md.startswith("- ") else 0),
        "thresholds": {"min_score": conf["min_score"], "min_margin": conf["min_margin"]},
        "rejected": [],
        "picked": [],
    }
    if not cands or not anchors:
        # ここを「理由なし」で返すと、機能が動いていないのか慎重にしているのか
        # 画面から区別できない。必ず言葉で返す。
        if not (visual_evidence or []):
            report["reason"] = ("視覚証拠が 1 件もありません（解析ルートがテキストのみ、"
                                "または資料に図が無い）")
        elif not cands:
            top = max(drops.items(), key=lambda kv: kv[1])[0] if drops else "不明"
            report["reason"] = (f"視覚証拠 {len(visual_evidence)} 件は全て候補から外れました。"
                                f"最多の理由：{top}")
        else:
            report["reason"] = ("図を入れてよい節に、対象となる箇条書きがありません"
                                "（figures.allow_sections を確認してください）")
        return [], report

    # 文ごとに全候補を採点し、1 位と 2 位（別画像）を取る
    by_id = {c.evidence_id: c for c in cands if c.evidence_id}
    cite_hits = cite_misses = 0
    scored: List[Tuple[float, float, Anchor, Candidate, Dict[str, Any]]] = []
    for a in anchors:
        hint = bullet_page_hint(a.text, text_evidence)
        ranked = []
        for c in cands:
            s, bd = score_pair(a.text, c, hint, conf.get("weights"),
                               conf.get("worthiness_bonus"))
            ranked.append((s, c, bd))
        ranked.sort(key=lambda x: -x[0])

        # ---- 要約側の名指しを優先する（ただし必ず裏を取る）----
        # 「どの図か」を当てるのは順位付けより遥かに易しく、しかもその文が
        # 図の言い換えになっている以上、結び付きは推測ではなく宣言。
        # ただし宣言を鵜呑みにはしない：確定的スコアで最低限の裏取りをする。
        cited_pick = None
        if conf.get("use_citations", True):
            for cid in a.cited:
                c = by_id.get(cid)
                if c is None:
                    cite_misses += 1
                    report["rejected"].append(
                        {"bullet": a.text[:40], "score": 0.0,
                         "why": f"要約が名指しした図 {cid} が候補にありません"})
                    continue
                s, bd = score_pair(a.text, c, hint, conf.get("weights"),
                                   conf.get("worthiness_bonus"))
                if s < float(conf.get("cited_min_score", 0.15)):
                    cite_misses += 1
                    report["rejected"].append(
                        {"bullet": a.text[:40], "score": round(s, 4),
                         "why": (f"要約は図 {cid} を名指ししましたが、裏取りスコア "
                                 f"{s:.3f} < {conf.get('cited_min_score')} のため却下")})
                    continue
                bd["cited"] = cid
                cite_hits += 1
                # 名指しは宣言なので 2 位との差は問わない（差の規則は推測用）
                cited_pick = (max(s, float(conf["min_score"])), 0.0, a, c, bd)
                break
        if cited_pick is not None:
            scored.append(cited_pick)
            continue

        top = ranked[0]
        second = ranked[1][0] if len(ranked) > 1 else 0.0
        scored.append((top[0], second, a, top[1], top[2]))

    report["citations"] = {"accepted": cite_hits, "rejected": cite_misses,
                           "seen": sum(len(a.cited) for a in anchors)}
    scored.sort(key=lambda x: -x[0])

    # 1 枚も採らなかったときに「どれくらい惜しかったか」が分からないと
    # 閾値を動かすべきか、抽出を直すべきかの判断ができない。最上位は必ず残す。
    if scored:
        s, second, a, c, bd = scored[0]
        report["best"] = {
            "score": round(s, 4), "runner_up": round(second, 4),
            "margin": round(s - second, 4), "bullet": a.text,
            "image": Path(c.display_path).name, "page": c.page,
            "breakdown": bd,
        }

    picks: List[Pick] = []
    used_images: set = set()
    used_lines: set = set()
    for s, second, a, c, bd in scored:
        if len(picks) >= int(conf["max_figures"]):
            break
        if a.line_index in used_lines or c.image_path in used_images:
            continue
        if s < float(conf["min_score"]):
            report["rejected"].append({"bullet": a.text[:40], "score": round(s, 4),
                                       "why": f"スコア {s:.3f} < 閾値 {conf['min_score']}"})
            continue
        if (s - second) < float(conf["min_margin"]) and not bd.get("cited"):
            report["rejected"].append({"bullet": a.text[:40], "score": round(s, 4),
                                       "why": (f"2 位との差 {s - second:.3f} < 閾値 "
                                               f"{conf['min_margin']}（どの図とも取れるため不採用）")})
            continue
        if verifier is not None:
            try:
                if not verifier(a.text, c):
                    report["rejected"].append({"bullet": a.text[:40], "score": round(s, 4),
                                               "why": "VLM 確認で否定された"})
                    continue
            except Exception as e:  # noqa: BLE001 確認器の失敗で本流を壊さない
                report.setdefault("verifier_errors", []).append(repr(e))
        picks.append(Pick(anchor=a, cand=c, score=s, runner_up=second, breakdown=bd))
        used_images.add(c.image_path)
        used_lines.add(a.line_index)

    # 本文に現れる順に採番（図 3 が図 1 より前に出るのを防ぐ）
    picks.sort(key=lambda p: p.anchor.line_index)
    if not picks and report.get("best"):
        b = report["best"]
        if b["score"] < float(conf["min_score"]):
            report["reason"] = (f"最高スコア {b['score']:.3f} が閾値 {conf['min_score']} に"
                                f"届きませんでした（本文と図の一致が弱い）")
        else:
            report["reason"] = (f"最高スコア {b['score']:.3f} は閾値を超えましたが、"
                                f"2 位との差 {b['margin']:.3f} が {conf['min_margin']} 未満でした"
                                f"（複数の図がどれも当てはまり、特定できない）")
    for i, p in enumerate(picks, 1):
        p.figure_no = i
        p.caption = build_caption(p, conf)
        report["picked"].append({
            "figure_no": i, "bullet": p.anchor.text, "heading": p.anchor.heading,
            "image": p.cand.display_path, "vlm_image": p.cand.image_path,
            "evidence_id": p.cand.evidence_id, "page": p.cand.page,
            "sheet_name": p.cand.sheet_name, "score": round(p.score, 4),
            "runner_up": round(p.runner_up, 4), "margin": round(p.score - p.runner_up, 4),
            "breakdown": p.breakdown, "caption": p.caption,
            "via": "要約の名指し" if p.breakdown.get("cited") else "スコア一致",
        })
    return picks, report


#: 切れ目の優先順。句点 > 読点 > その他。小数点は候補にしない
#: （「12.5 kPa」の「.」で切ると数字が壊れる）。
_BREAK_TIERS = ("。．", "、，", "；;：:,.")


def _shorten_at_break(text: str, limit: int) -> str:
    """limit 以内で、句読点など自然な切れ目で切る。無ければ文字数で切って「…」。

    途中で単語をちょん切った「…応力分布図（あるいは位相コントラスト像）。カ…」の
    ような図注は、読者に「壊れている」と思わせる。切るなら区切りで切る。
    """
    text = re.sub(r"\s+", " ", (text or "").strip())
    if len(text) <= limit:
        return text.rstrip("。．.")
    head = text[:limit]
    for tier_no, tier in enumerate(_BREAK_TIERS):
        # 句点は文の終わりなので短くても切ってよい。読点以下は半分より前で
        # 切ると意味が欠けるので下限を上げる
        floor = 6 if tier_no == 0 else max(6, limit // 2)
        best = -1
        for i, ch in enumerate(head):
            if ch not in tier:
                continue
            # 数字に挟まれた点は小数点。切れ目ではない
            if ch in ".．" and 0 < i < len(head) - 1 and head[i - 1].isdigit() and head[i + 1].isdigit():
                continue
            best = i
        if best >= floor:
            return head[:best].rstrip("。．.、，,")
    return head.rstrip("　 、，,") + "…"


def build_caption(pick: Pick, cfg: Dict[str, Any]) -> str:
    """成果物に出す図注。**短い**ことが第一。

    二軌制（v3.27.11）：
      figure_title   … 表示用。体言止め・20 字前後。ここで使う
      figure_caption … 要約モデル用。長くてよい。ここでは使わない（fallback のみ）

    以前は figure_caption（説明文）をそのまま 60 字で切っていたので、
    「…顕微鏡画像です。縦軸はμm単位の高さ（ま…」のような図注になっていた。
    説明は本文（要約）の仕事で、図注は「これは何の図か」だけ言えばよい。
    図番号と出典はモデルに書かせない。
    """
    limit = int(cfg.get("caption_max_chars", 28))
    c = pick.cand
    body = (c.figure_title or "").strip()
    if body:
        body = strip_citations(_shorten_at_break(body, limit))
    else:
        # 見出しが無い旧データ：説明文の先頭を切れ目で短くする
        body = strip_citations(_shorten_at_break(
            c.figure_caption or c.visual_summary
            or (str(c.key_facts[0]) if c.key_facts else ""), limit))
    src = c.label
    return f"図{pick.figure_no}　{body}".rstrip() + (f"（{src}）" if src else "")


# ----------------------------------------------------------------------
# Markdown への書き戻し
# ----------------------------------------------------------------------

def _copy_to_figures_dir(pick: Pick, run_dir: Path) -> str:
    """採用画像を run_dir/figures/ へ複製し、md からの相対パスを返す。

    元の visual_* を直接指すと、掃除・再実行・一括エクスポートで
    参照が切れる。図版は成果物なので成果物の場所に置く。
    """
    fig_dir = run_dir / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)
    src = Path(pick.cand.display_path)
    dst = fig_dir / f"fig{pick.figure_no:02d}{src.suffix.lower() or '.png'}"
    try:
        if src.resolve() != dst.resolve():
            shutil.copyfile(src, dst)
    except Exception:  # noqa: BLE001 コピー失敗なら元パスをそのまま使う
        return str(src)
    return f"figures/{dst.name}"


def inject_figures(md: str, picks: List[Pick], run_dir: str | Path) -> str:
    """箇条書きの直後に図版行を差し込み、本文には (図N) の参照を付ける。

    論文と同じ形：本文で図を参照し、図はその直後に置く。
    要約側が付けた [[V3]] は、採否にかかわらずここで必ず取り除く。
    """
    rd = Path(run_dir)
    raw = md.replace("\r\n", "\n").split("\n")
    lines: List[str] = []
    for line in raw:
        if _CITE_RE.search(line):
            indent = line[:len(line) - len(line.lstrip())]
            lines.append(indent + strip_citations(line))
        else:
            lines.append(line)
    if not picks:
        return "\n".join(lines)

    inserts: Dict[int, List[str]] = {}
    for p in picks:
        rel = _copy_to_figures_dir(p, rd)
        i = p.anchor.line_index
        if not lines[i].rstrip().endswith(f"（図{p.figure_no}）"):
            lines[i] = lines[i].rstrip() + f"（図{p.figure_no}）"
        alt = p.caption.replace("]", "］").replace("[", "［")
        inserts.setdefault(i, []).append("")
        inserts[i].append(f"![{alt}]({rel})")
        inserts[i].append("")
    out: List[str] = []
    for i, line in enumerate(lines):
        out.append(line)
        out.extend(inserts.get(i, []))
    return "\n".join(out)


# ----------------------------------------------------------------------
# 任意：VLM による最終確認（順位付けではなく Yes/No だけ聞く）
# ----------------------------------------------------------------------

_VERIFY_SYSTEM = ("あなたは技術資料の図版チェッカーです。JSON だけを返してください。"
                  "説明文や前置きは書かないでください。")
_VERIFY_SCHEMA = {
    "type": "object",
    "properties": {"matches": {"type": "boolean"}, "reason": {"type": "string"}},
    "required": ["matches"],
}


def make_vlm_verifier(vision_client, max_tokens: int = 256) -> Callable[[str, Candidate], bool]:
    """最終候補にだけ掛ける二値確認器。

    「N 枚から選べ」ではなく「この 1 枚は合っているか」。弱いモデルでも
    二値判定なら十分に当たる。呼び出し回数は最大 max_figures 回。
    """
    def _verify(bullet: str, cand: Candidate) -> bool:
        user = ("次の文の根拠として、この画像を報告書に載せます。\n"
                "画像がこの文の内容（対象・数値・グラフ）を実際に示している場合のみ "
                "matches を true にしてください。関係が薄い、判断できない場合は false。\n\n"
                f"文：{bullet}\n\n"
                '{"matches": true/false, "reason": "20 字以内"} の JSON だけを返してください。')
        res = vision_client.chat_vision_json(
            cand.display_path, _VERIFY_SYSTEM, user,
            max_tokens=max_tokens, json_schema=_VERIFY_SCHEMA, tag="figure_verify")
        return bool(res.get("matches"))
    return _verify


# ----------------------------------------------------------------------
# 入口：run ディレクトリ 1 件に図版を差し込む
# ----------------------------------------------------------------------

def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def attach_figures_to_run(run_dir: str | Path,
                          cfg: Optional[Dict[str, Any]] = None,
                          tier: str = "internal",
                          visual_evidence: Optional[Sequence[Dict[str, Any]]] = None,
                          text_evidence: Optional[Sequence[Dict[str, Any]]] = None,
                          verifier: Optional[Callable[[str, Candidate], bool]] = None,
                          ) -> Dict[str, Any]:
    """ディスクを真源として run 1 件に図版を差し込む（再実行しても冪等）。

    `case_summary.md` を書き換え、`figures_report.json` に採否の理由を残す。
    証拠を引数で渡さない場合はキャッシュ（evidence_visual.json / evidence_text.json）
    から読む＝パイプライン外からの再適用・dry-run にも使える。
    """
    conf = dict(DEFAULTS)
    conf.update(cfg or {})
    rd = Path(run_dir)
    md_name = "case_summary_external.md" if tier == "external" else "case_summary.md"
    md_path = rd / md_name

    result: Dict[str, Any] = {"ok": False, "tier": tier, "figures": 0, "md": str(md_path)}
    if not conf.get("enabled", True):
        result["reason"] = "図版差し込みは無効です"
        return result
    if tier == "external" and not conf.get("external_tier", False):
        result["reason"] = "社外版は既定で図版なし（画像内の固有情報は脱敏されないため）"
        return result
    if not md_path.exists():
        result["reason"] = f"{md_name} がありません"
        return result

    if visual_evidence is None:
        cached = _load_json(rd / "evidence_visual.json") or {}
        visual_evidence = cached.get("evidence", []) if isinstance(cached, dict) else []
    if text_evidence is None:
        cached = _load_json(rd / "evidence_text.json") or {}
        if isinstance(cached, dict):
            text_evidence = cached.get("evidence", []) or cached.get("aggregated", [])
        else:
            text_evidence = cached or []

    md = md_path.read_text(encoding="utf-8")
    if _IMG_RE.search(md) or "![" in md:
        result["reason"] = "既に図版が入っています（二重挿入を防止）"
        result["ok"] = True
        return result

    picks, report = select_figures(md, visual_evidence or [], text_evidence or [],
                                   run_dir=rd, cfg=conf, verifier=verifier)
    # 0 枚でも書き戻す：採否にかかわらず [[V3]] を本文に残してはいけない
    cleaned = inject_figures(md, picks, rd)
    if cleaned != md:
        md_path.write_text(cleaned, encoding="utf-8")

    report["tier"] = tier
    (rd / ("figures_report_external.json" if tier == "external" else "figures_report.json")
     ).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    result.update({"ok": True, "figures": len(picks), "report": report})
    return result
