"""
Web 交互层（FastAPI）。

设计原则：
- 公司内网、零外部依赖：前端是一个静态 index.html（无 CDN、无 npm 构建）
- 上传 -> 后台线程跑 LangGraph -> 前端轮询 status.json -> 展示/下载结果
- 运行记录持久化在 out/runs/{run_id}/，重启服务后历史仍可浏览

启动：
    uvicorn app.webapp:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import json
import shutil
import threading
import time
import traceback
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from contextlib import asynccontextmanager

from fastapi import Body, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import (FileResponse, HTMLResponse, JSONResponse,
                               PlainTextResponse, StreamingResponse)

from . import batch as B
from .config import DEFAULT_UI_FEATURES, PROJECT_ROOT, load_config
from .contract import CaseSummary
from .export_doc import DocSection, export_docx, export_pdf, section_from_run_dir
from .export_pptx import export_pptx
from .graph import run_workflow
from .ledger import Ledger, rebuild_from_disk, record_from_run_dir
from .llm_client import LLMJsonError, LocalLLMClient
from .observability import RunCancelled, RunStore
from .rag_export import build_records
from .redaction import NGDictionary
from .template_registry import get_registry
from . import feedback as fb
from .versions import list_versions, snapshot
from .site_builder import build_site
from .render import render_markdown, verify_template

from . import review as R
from . import upload_staging as U
from .figure_select import save_plan
config = load_config()

# v3.28：出力ファイルに根拠情報を含めるか（既定：含めない）
try:
    from . import export_doc as _export_doc
    _export_doc.EXPORT_OPTIONS["include_evidence"] = bool(config.export.include_evidence)
except Exception:  # noqa: BLE001
    pass

_warmup_state = {"docling": "disabled"}
_ledger = Ledger(config.paths.resolve(config.ledger.db_path))


def _jobs_conn():
    import sqlite3
    conn = sqlite3.connect(str(config.paths.resolve(config.ledger.db_path)),
                           check_same_thread=False, timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("""CREATE TABLE IF NOT EXISTS jobs (
        run_id TEXT PRIMARY KEY, input_path TEXT, input_name TEXT,
        template_id TEXT, status TEXT, ts REAL)""")
    return conn


def _job_set(run_id: str, status: str, input_path: str = "", input_name: str = "",
             template_id: str = "case") -> None:
    """排队任务落库：服务重启后 queued/running 的任务自动重入队（不再丢任务）。"""
    try:
        with _jobs_conn() as c:
            if status in ("done", "failed", "cancelled"):
                c.execute("UPDATE jobs SET status=?, ts=? WHERE run_id=?",
                          (status, time.time(), run_id))
            else:
                c.execute("INSERT OR REPLACE INTO jobs VALUES (?,?,?,?,?,?)",
                          (run_id, input_path, input_name, template_id, status, time.time()))
    except Exception:  # noqa: BLE001
        pass


def _requeue_pending() -> int:
    """重启恢复：把上次遗留的 queued/running 任务重新入队执行。"""
    n = 0
    try:
        with _jobs_conn() as c:
            rows = c.execute("SELECT run_id, input_path, input_name, template_id FROM jobs "
                             "WHERE status IN ('queued','running')").fetchall()
        for run_id, input_path, input_name, template_id in rows:
            if not Path(input_path).exists():
                _job_set(run_id, "failed")
                continue
            with _runs_lock:
                _runs[run_id] = {"run_id": run_id, "input_name": input_name,
                                 "input_path": input_path, "template_id": template_id,
                                 "state": "queued", "created": time.time(), "run_dir": None}
            threading.Thread(target=_worker, args=(run_id, input_path, template_id),
                             daemon=True).start()
            n += 1
    except Exception:  # noqa: BLE001
        pass
    return n


def _ledger_update(run_id: str, state: str) -> None:
    """完成/失败后把 run 写入台账（磁盘为真源，DB 只是索引）。"""
    try:
        with _runs_lock:
            run = _runs.get(run_id, {})
        run_dir = _resolve_run_dir(run) if run else None
        if run_dir:
            rec = record_from_run_dir(run_dir, state=state)
            if rec:
                rec["input_name"] = run.get("input_name") or rec["input_name"]
                _ledger.upsert(rec)
    except Exception:  # noqa: BLE001 台账故障绝不影响主流程
        pass


ALLOWED = None  # forward decl silence


def _watch_scan_once() -> list:
    """监视文件夹单次扫描（独立函数便于测试）。
    两次扫描间大小不变才视为拷贝完成，防止处理半截文件。"""
    wf_cfg = config.watch_folder
    watch = config.paths.resolve(wf_cfg.path)
    watch.mkdir(parents=True, exist_ok=True)
    processed = watch / "processed"
    processed.mkdir(exist_ok=True)
    state_file = watch / ".sizes.json"
    try:
        prev = json.loads(state_file.read_text(encoding="utf-8")) if state_file.exists() else {}
    except Exception:
        prev = {}
    sizes, launched = {}, []
    for f in sorted(watch.iterdir()):
        if not f.is_file() or f.name.startswith("."):
            continue
        if f.suffix.lower() not in ALLOWED_SUFFIXES:
            continue
        size = f.stat().st_size
        sizes[f.name] = size
        if prev.get(f.name) == size:  # 大小稳定 → 入队
            inbox = config.paths.resolve(config.paths.inbox_dir)
            inbox.mkdir(parents=True, exist_ok=True)
            dest = inbox / f"{f.stem}_{uuid.uuid4().hex[:8]}{f.suffix}"
            shutil.move(str(f), str(dest))
            run_id = dest.stem
            with _runs_lock:
                _runs[run_id] = {"run_id": run_id, "input_name": f.name,
                                 "input_path": str(dest), "state": "queued",
                                 "created": time.time(), "run_dir": None}
            _job_set(run_id, "queued", str(dest), f.name, "case")
            threading.Thread(target=_worker, args=(run_id, str(dest), "case"),
                             daemon=True).start()
            launched.append(run_id)
            sizes.pop(f.name, None)
    state_file.write_text(json.dumps(sizes), encoding="utf-8")
    return launched


def _watch_loop() -> None:
    while True:
        try:
            _watch_scan_once()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(max(2, config.watch_folder.interval_seconds))


def _warmup_docling() -> None:
    """后台预热：Docling 首次实例化要加载布局/表格/OCR 模型（可能触发下载 +
    Windows Defender 对大 onnx 文件的实时扫描），冷启动可达数十分钟。
    服务启动时在后台线程完成这一次性成本，用户的首个请求不再中招。"""
    _warmup_state["docling"] = "warming"
    try:
        from docling.document_converter import DocumentConverter
        DocumentConverter()  # 实例化即触发模型加载
        _warmup_state["docling"] = "ready"
    except Exception as e:  # noqa: BLE001
        _warmup_state["docling"] = f"failed: {e!r}"[:200]


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """启动时静态校验模板 <-> 契约，字段漂移直接拒绝启动（v1 教训）。"""
    template = config.paths.resolve(config.paths.template_markdown)
    bad = verify_template(str(template))
    if bad:
        raise RuntimeError(
            f"模板 {template} 引用了契约中不存在的变量: {bad}。请修正模板或 app/contract.py。")
    _load_runs_from_disk()
    _restore_batch_links()
    if config.workflow.warmup_on_start and not config.llm.mock:
        threading.Thread(target=_warmup_docling, daemon=True).start()
    try:  # 台账索引冷启动重建（DB 丢了也能从磁盘找回全部案件）
        rebuild_from_disk(_ledger, _runs_root())
    except Exception:  # noqa: BLE001
        pass
    if config.watch_folder.enabled:
        threading.Thread(target=_watch_loop, daemon=True).start()
    _requeue_pending()
    yield


app = FastAPI(title="依頼対応事例 要約パイプライン", version="3.7", lifespan=lifespan)

# GPU 单卡保护：同时只跑 N 个 run，其余排队（state=queued）
_run_slots = threading.Semaphore(getattr(config.workflow, "max_concurrent_runs", 1))

# v3.27.6：.md / .txt は一時停止中（2026-09）。戻すときはこの集合を空にする。
# 直接消さずに差集合で書くのは、これが恒久的な非対応ではなく
# 一時措置だと後から読んで分かるようにするため。
SUSPENDED_SUFFIXES = {".md", ".txt"}
ALLOWED_SUFFIXES = {".pdf", ".docx", ".pptx", ".xlsx", ".xlsm", ".xls",
                    ".md", ".txt", ".html"} - SUSPENDED_SUFFIXES

# 内存中的运行注册表（重启后从磁盘懒加载）
_runs_lock = threading.Lock()
_runs: Dict[str, Dict[str, Any]] = {}


def _runs_root() -> Path:
    return config.paths.resolve(config.paths.out_dir) / "runs"


def _load_runs_from_disk() -> None:
    root = _runs_root()
    if not root.exists():
        return
    with _runs_lock:
        # 已被本进程登记的 run（其 run_dir 指向同一目录）不再重复登记，
        # 否则同一次运行会在履歴里出现两条（上传 ID + 目录名 ID）
        known_dirs = {str(r.get("run_dir")) for r in _runs.values() if r.get("run_dir")}
        for d in sorted(root.iterdir()):
            if not d.is_dir():
                continue
            manifest = d / "manifest.json"
            if not manifest.exists():
                continue
            run_id = d.name
            if run_id in _runs or str(d) in known_dirs:
                continue
            done = (d / "case_summary.md").exists()
            _runs[run_id] = {
                "run_id": run_id,
                "run_dir": str(d),
                "input_name": Path(json.loads(manifest.read_text(encoding="utf-8")).get("input_path", "?")).name,
                "state": "done" if done else "unknown",
                "created": d.stat().st_mtime,
            }


def _finish(run_id: str, state: str) -> None:
    """終了処理の一本化：台帳・ジョブ表・バッチ台帳に同じ結末を書く。"""
    _job_set(run_id, state)
    with _runs_lock:
        batch_id = _runs.get(run_id, {}).get("batch_id")
    if batch_id:
        try:
            B.set_item_state(config.paths.resolve(config.paths.out_dir), batch_id, run_id, state)
        except Exception:  # noqa: BLE001 バッチ台帳の故障で本流を止めない
            pass


def _worker(run_id: str, input_path: str, template_id: str = "case",
            input_mode: str = "", deep_read: Optional[bool] = None,
            batch_id: str = "", reference_paths: Optional[List[str]] = None,
            source_name: str = "", source_rel_path: str = "") -> None:
    with _run_slots:  # 排队直到有空槽（GPU 保护）
        with _runs_lock:
            if _runs[run_id].get("state") == "cancelled":
                _finish(run_id, "cancelled")
                return  # 排队期间被取消
        # v3.12：枠を取った**直後**にバッチの中止フラグを見る。
        # ここで抜ければ LLM を 1 回も呼ばないので待ち時間ゼロで終わる。
        # これが無いと、1 件止めるたびに空いた枠へ次が入って走り出し、
        # しかも協調中止が進行中の応答を待つため毎回数秒固まっていた。
        if batch_id and B.is_cancelled(_out_dir(), batch_id):
            with _runs_lock:
                _runs[run_id]["state"] = "cancelled"
            _finish(run_id, "cancelled")
            return
        with _runs_lock:
            _runs[run_id]["state"] = "running"
        _job_set(run_id, "running", input_path,
                 _runs[run_id].get("input_name", ""), template_id)
        try:
            final = run_workflow(input_path, config, template_id=template_id,
                                 input_mode=input_mode or None,
                                 deep_read=deep_read,
                                 reference_paths=reference_paths,
                                 source_name=source_name,
                                 source_rel_path=source_rel_path)
            with _runs_lock:
                _runs[run_id]["state"] = "done"
                _runs[run_id]["run_dir"] = final.get("run_dir", _runs[run_id].get("run_dir"))
            _ledger_update(run_id, "done")
            _finish(run_id, "done")
        except RunCancelled:
            with _runs_lock:
                _runs[run_id]["state"] = "cancelled"
            _finish(run_id, "cancelled")
        except Exception:  # noqa: BLE001
            err = traceback.format_exc()
            with _runs_lock:
                _runs[run_id]["state"] = "failed"
                _runs[run_id]["error"] = err[-4000:]
            _finish(run_id, "failed")
            run_dir = _runs[run_id].get("run_dir")
            if run_dir:
                (Path(run_dir) / "fatal_error.txt").write_text(err, encoding="utf-8")


# ----------------------------------------------------------------------
# API
# ----------------------------------------------------------------------

@app.post("/api/runs")
async def create_runs(files: List[UploadFile] = File(...),
                      template_id: str = Form("case"),
                      input_mode: str = Form(""),
                      deep_read: str = Form(""),
                      # v3.21：フォルダごと投げた場合にブラウザが送ってくる相対パス。
                      # 台帳照合でフォルダ名を鍵に使うために要る。
                      relative_paths: List[str] = Form(default=[])):
    try:
        if template_id != "auto":   # v3.11: "auto" は route_template が決める
            get_registry().get(template_id)
    except KeyError as e:
        raise HTTPException(400, str(e))
    """批量上传：每个文件一个 run，进同一队列（max_concurrent_runs 保护 GPU）。"""
    run_ids, rejected = [], []
    inbox = config.paths.resolve(config.paths.inbox_dir)
    inbox.mkdir(parents=True, exist_ok=True)
    # ファイルと同じ順で送られてくる前提（送られてこなければ空）
    rel_paths = {f.filename: (relative_paths[i] if i < len(relative_paths) else "")
                 for i, f in enumerate(files)}
    for file in files:
        suffix = Path(file.filename or "").suffix.lower()
        if suffix not in ALLOWED_SUFFIXES:
            rejected.append({"name": file.filename, "reason": f"未対応の形式 {suffix}"})
            continue
        stem = Path(file.filename).stem
        saved = inbox / f"{stem}_{uuid.uuid4().hex[:8]}{suffix}"
        with saved.open("wb") as f:
            shutil.copyfileobj(file.file, f)
        run_id = saved.stem
        # v3.21：inbox に移すと元の名前も置き場所も失われる。台帳照合には
        # そちらが要る（ID 付きの名前では一致度が落ち、親フォルダは inbox になる）。
        # ブラウザが webkitRelativePath を送ってくればフォルダ階層も拾える。
        orig_name = Path(file.filename or "").name
        orig_rel = rel_paths.get(file.filename) or ""
        with _runs_lock:
            _runs[run_id] = {"run_id": run_id, "input_name": file.filename,
                             "input_path": str(saved), "template_id": template_id,
                             "state": "queued", "created": time.time(), "run_dir": None}
        _job_set(run_id, "queued", str(saved), file.filename or "", template_id)
        _deep = None if deep_read == "" else deep_read.lower() in ("1", "true", "on", "yes")
        threading.Thread(target=_worker,
                         args=(run_id, str(saved), template_id, input_mode, _deep,
                               "", None, orig_name, orig_rel),
                         daemon=True).start()
        run_ids.append(run_id)
    if not run_ids and rejected:
        raise HTTPException(400, f"全ファイル未対応: {rejected}")
    return {"run_ids": run_ids, "run_id": run_ids[0] if run_ids else None,
            "rejected": rejected}


@app.get("/api/runs")
def list_runs(scope: str = "single"):
    """scope=single（既定）: フォルダ一括処理の run を除いた実行履歴。
    一括処理は専用カードで見るので、単発の履歴に混ぜない（v3.6 の要望）。
    scope=all で全件、scope=batch でバッチ由来のみ。"""
    with _runs_lock:
        items = sorted(_runs.values(), key=lambda r: r.get("created", 0), reverse=True)
    if scope == "single":
        items = [r for r in items if not r.get("batch_id")]
    elif scope == "batch":
        items = [r for r in items if r.get("batch_id")]
    return [{k: v for k, v in r.items() if k != "error"} | {"has_error": "error" in r}
            for r in items]


def _find_run(run_id: str) -> Dict[str, Any]:
    with _runs_lock:
        run = _runs.get(run_id)
    if run is None:
        # 也许是磁盘上的历史 run
        d = _runs_root() / run_id
        if d.exists():
            _load_runs_from_disk()
            with _runs_lock:
                run = _runs.get(run_id)
    if run is None:
        raise HTTPException(404, "run 不存在")
    return run


def _resolve_run_dir(run: Dict[str, Any]) -> Optional[Path]:
    if run.get("run_dir"):
        return Path(run["run_dir"])
    # worker 里 run_dir 由 create_run_dir 节点生成；running 中先从磁盘匹配
    input_path = run.get("input_path")
    if input_path:
        stem = Path(input_path).stem
        root = _runs_root()
        if root.exists():
            candidates = sorted(root.glob(f"{stem}_*"), key=lambda p: p.stat().st_mtime, reverse=True)
            if candidates:
                return candidates[0]
    return None


@app.get("/api/runs/{run_id}")
def run_status(run_id: str):
    run = _find_run(run_id)
    payload: Dict[str, Any] = {k: run.get(k) for k in ("run_id", "input_name", "state")}
    payload["error"] = run.get("error")
    payload["batch_id"] = run.get("batch_id")
    # v3.6: 前端はこの時刻を基準に経過秒を出す。クライアント時計とのズレで
    # 秒表が飛んだりマイナスになったりするのを根本から断つ。
    payload["server_time"] = time.time()
    run_dir = _resolve_run_dir(run)
    if run_dir:
        route = run_dir / "route.json"
        if route.exists():
            try:
                payload["route"] = json.loads(route.read_text(encoding="utf-8"))
            except Exception:
                pass
        status_path = run_dir / "status.json"
        if status_path.exists():
            try:
                payload["progress"] = json.loads(status_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        qr = run_dir / "quality_report.json"
        if qr.exists():
            try:
                payload["quality_report"] = json.loads(qr.read_text(encoding="utf-8"))
            except Exception:
                pass
        metrics = run_dir / RunStore.METRICS
        if metrics.exists():
            try:
                payload["metrics"] = json.loads(metrics.read_text(encoding="utf-8"))
            except Exception:
                pass
    return payload


def _attachment(filename: str) -> Dict[str, str]:
    """
    Content-Disposition を安全に組み立てる。

    HTTP ヘッダは latin-1 しか載らないので、日本語ファイル名を素で入れると
    送信時に UnicodeEncodeError（'latin-1' codec can't encode characters）で
    500 になる。run_id は入力ファイル名の stem 由来なので日本語が普通に混ざる
    ——RAG ダウンロードが落ちていたのはこれ。RFC 6266 / 5987 の作法に従い、
    ASCII 版を filename= に、原名を filename*=UTF-8'' に percent-encode で入れる。
    （FileResponse は Starlette が同じ処理をしてくれるので、手組みのここだけ問題だった）
    """
    from urllib.parse import quote
    ascii_name = filename.encode("ascii", "ignore").decode("ascii").strip() or "download"
    return {"Content-Disposition":
            f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(filename)}"}


def _artifact(run_id: str, filename: str, media_type: str):
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir:
        raise HTTPException(404, "run 目录尚未生成")
    path = run_dir / filename
    if not path.exists():
        raise HTTPException(404, f"{filename} 尚未生成")
    return FileResponse(str(path), media_type=media_type, filename=f"{run_id}_{filename}")


@app.get("/api/runs/{run_id}/markdown")
def run_markdown(run_id: str):
    return _artifact(run_id, "case_summary.md", "text/markdown")


@app.get("/api/runs/{run_id}/json")
def run_json(run_id: str):
    return _artifact(run_id, "case_summary.json", "application/json")


@app.get("/api/runs/{run_id}/markdown_text")
def run_markdown_text(run_id: str, tier: str = "internal"):
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    name = "case_summary_external.md" if tier == "external" else "case_summary.md"
    if not run_dir or not (run_dir / name).exists():
        raise HTTPException(404, "尚未生成")
    return JSONResponse({"markdown": (run_dir / name).read_text(encoding="utf-8"),
                         "tier": tier})


@app.get("/api/runs/{run_id}/markdown_external")
def run_markdown_external(run_id: str):
    return _artifact(run_id, "case_summary_external.md", "text/markdown")


@app.get("/api/runs/{run_id}/json_external")
def run_json_external(run_id: str):
    return _artifact(run_id, "case_summary_external.json", "application/json")


@app.get("/api/runs/{run_id}/redaction_report")
def run_redaction_report(run_id: str):
    return _artifact(run_id, "redaction_report.json", "application/json")


@app.get("/api/runs/{run_id}/figures_report")
def run_figures_report(run_id: str, tier: str = "internal"):
    """v3.27：図版の採否レポート（何を何点で採り、何をなぜ落としたか）。

    採用結果だけでなく**不採用の理由**を返す。閾値の当たりは資料の性格で
    変わるので、画面から理由が見えないと調整のしようがない。
    """
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir:
        raise HTTPException(404, "run 目录尚未生成")
    name = "figures_report_external.json" if tier == "external" else "figures_report.json"
    path = run_dir / name
    if not path.exists():
        return JSONResponse({
            "visual_evidence_in": 0, "candidates": 0, "anchors": 0,
            "picked": [], "rejected": [], "dropped_by": {},
            "reason": ("この run では図版差し込みが実行されていません。"
                       "v3.27 より前に実行した run か、figures.enabled が false か、"
                       "render ノードで例外が出た可能性があります"
                       "（実行トレースのエラーを確認してください）"),
        })
    return JSONResponse(json.loads(path.read_text(encoding="utf-8")))


@app.get("/api/runs/{run_id}/figures/{name}")
def run_figure_image(run_id: str, name: str):
    """要約プレビューに図を出すための画像配信。

    パスは run_dir/figures/ の直下に限定する（`..` や絶対パスを弾く）。
    ここを緩めると run ディレクトリの外を読み出せてしまう。
    """
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir:
        raise HTTPException(404, "run 目录尚未生成")
    safe = Path(name).name                       # ディレクトリ成分を落とす
    path = (run_dir / "figures" / safe).resolve()
    try:
        path.relative_to((run_dir / "figures").resolve())
    except ValueError:
        raise HTTPException(400, "不正なパス")
    if not path.exists() or not path.is_file():
        raise HTTPException(404, "図版がありません")
    media = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
             ".gif": "image/gif", ".webp": "image/webp"}.get(path.suffix.lower(),
                                                             "application/octet-stream")
    return FileResponse(str(path), media_type=media)


@app.get("/api/runs/{run_id}/rag.jsonl")
def run_rag(run_id: str, tier: str = "internal"):
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir:
        raise HTTPException(404, "run 目录尚未生成")
    records = build_records(run_dir, tier)
    if not records:
        raise HTTPException(404, f"{tier} 层无可导出记录")
    body = "\n".join(json.dumps(r, ensure_ascii=False) for r in records) + "\n"
    return PlainTextResponse(body, media_type="application/x-ndjson",
                             headers=_attachment(f"{run_id}_rag_{tier}.jsonl"))


# ----------------------------------------------------------------------
# 案件台账 / NG 词典
# ----------------------------------------------------------------------

@app.get("/api/ledger")
def ledger_search(query: str = "", state: str = "", limit: int = 50, offset: int = 0):
    rows, total = _ledger.search(query=query, state=state,
                                 limit=min(limit, 200), offset=max(offset, 0))
    return {"total": total, "rows": rows}


@app.get("/api/ledger/export.xlsx")
def ledger_export_xlsx():
    out = config.paths.resolve(config.paths.out_dir) / "案件台帳.xlsx"
    _ledger.export_xlsx(out)
    return FileResponse(str(out),
                        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        filename="案件台帳.xlsx")


@app.get("/api/ledger/export.rag.jsonl")
def ledger_export_rag(tier: str = "internal"):
    """全案件 RAG 语料一键导出（部门 RAG 备料）。"""
    lines: List[str] = []
    for row in _ledger.all_rows():
        if row.get("state") != "done" or not row.get("run_dir"):
            continue
        for rec in build_records(row["run_dir"], tier):
            lines.append(json.dumps(rec, ensure_ascii=False))
    if not lines:
        raise HTTPException(404, "导出内容为空")
    return PlainTextResponse("\n".join(lines) + "\n", media_type="application/x-ndjson",
                             headers=_attachment(f"rag_corpus_{tier}.jsonl"))


@app.get("/api/redaction/dictionary")
def get_dictionary():
    p = config.paths.resolve(config.redaction.dictionary_path)
    text = p.read_text(encoding="utf-8") if p.exists() else ""
    return {"yaml": text, "path": str(p)}


@app.put("/api/redaction/dictionary")
def put_dictionary(payload: dict = Body(...)):
    """保存前用 Pydantic 校验 YAML 结构，坏词典 422 拒绝——脱敏配置错误零容忍。"""
    text = payload.get("yaml", "")
    try:
        import yaml as _yaml
        NGDictionary.model_validate(_yaml.safe_load(text) or {})
    except Exception as e:  # noqa: BLE001
        raise HTTPException(422, f"辞書の形式エラー: {e}")
    p = config.paths.resolve(config.redaction.dictionary_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
    return {"ok": True}




@app.post("/api/runs/{run_id}/cancel")
def cancel_run(run_id: str):
    """协作式取消：置标记文件，节点循环在下一个检查点退出。
    正在进行中的单次 LLM 调用无法中断（HTTP 已发出），会在返回后停止。"""
    run = _find_run(run_id)
    if run.get("state") in ("done", "failed", "cancelled"):
        return {"ok": False, "state": run["state"]}
    with _runs_lock:
        if run.get("state") == "queued":
            _runs[run_id]["state"] = "cancelled"
            return {"ok": True, "state": "cancelled"}
    run_dir = _resolve_run_dir(run)
    if run_dir:
        RunStore(run_dir).request_cancel()
    return {"ok": True, "state": "cancelling"}



@app.middleware("http")
async def _api_no_cache(request, call_next):
    """v3.29.1：/api/ の応答は毎回サーバーに確かめさせる。

    図版は fig01.png のように名前を使い回すので、編集で図番号が振り直されると
    ブラウザのキャッシュが古い図を出していた。no-cache は「使う前に確認」で、
    ファイル応答には ETag が付くため、変わっていなければ 304 で済む。
    """
    resp = await call_next(request)
    if request.url.path.startswith("/api/") and "cache-control" not in resp.headers:
        resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.get("/api/ui")
def ui_config(request: Request):
    """前端功能开关：默认值 <- config.yaml 覆盖 <- site.enabled。
    前端只消费 features 字典；顶层旧字段保留以兼容。"""
    features = dict(DEFAULT_UI_FEATURES)
    features["robot_animation"] = config.ui.robot_animation
    for k, v in (config.ui.features or {}).items():
        if k in features:
            features[k] = bool(v)
    features["site"] = config.site.enabled
    return {"robot_animation": features["robot_animation"],
            "site_enabled": config.site.enabled,
            "features": features,
            # v3.30：「サーバー上のフォルダを指定」を出してよいか（開いた場所で決まる）と、
            # アップロードの上限・対応拡張子（画面側の事前チェック用）
            "server_path": _server_path_allowed(request),
            "batch_upload": _upload_limits()}


def _vision_endpoint() -> str:
    vc = config.llm.vision
    return vc.base_url if (vc and vc.base_url) else config.llm.base_url


def _vision_client(timeout_seconds: float = 60) -> LocalLLMClient:
    """
    視覚用クライアントの生成はここ 1 か所だけ。

    【修正した不具合】旧実装は
        LocalLLMClient(**config.llm.model_dump(exclude={"vision"}), timeout_seconds=60)
    と書いていたが、model_dump には timeout_seconds が既に含まれる。
    結果 TypeError: got multiple values for keyword argument 'timeout_seconds' が
    必ず送出され、しかも except で握り潰されて
    「視覚エンドポイント未応答」という誤ったヒントが表示されていた。
    llm.vision を別途立てている場合だけ動き、既定構成（主端点を共用）では
    VLM テストが 100% 失敗する——という分かりにくい壊れ方をしていた。
    """
    vc = config.llm.vision
    if vc and vc.base_url:
        return LocalLLMClient(base_url=vc.base_url, api_key=vc.api_key, model=vc.model,
                              temperature=config.llm.temperature,
                              structured_output=config.llm.structured_output,
                              max_retries=config.llm.max_retries,
                              mock=config.llm.mock,
                              timeout_seconds=timeout_seconds)
    params = config.llm.model_dump(exclude={"vision"})
    params["timeout_seconds"] = timeout_seconds      # 上書きであって重複ではない
    return LocalLLMClient(**params)


_RED_WORDS = ("red", "赤", "紅", "あか", "レッド", "crimson", "scarlet", "#f00",
              "#ff0000", "#e00", "rgb(2", "rgb(25")


def _looks_red(answer) -> bool:
    """モデルの答え方は割れる（"red" / "赤色" / "#c8281e" / 文章）。
    JSON でも生テキストでも拾えるよう、全体を文字列にして緩く判定する。"""
    text = (json.dumps(answer, ensure_ascii=False) if isinstance(answer, (dict, list))
            else str(answer)).lower()
    return any(w in text for w in _RED_WORDS)


@app.get("/api/health/vision")
def health_vision():
    """VLM 实测探针：现场生成一张小图发给视觉端点，验证 mmproj 真的挂上了。
    （Ollama/llama-server 静默丢弃 mmproj 时，文本 API 正常但视觉能力悄悄失效
    ——连通性检查发现不了，只有实拍一张图才能确认。）"""
    if config.llm.mock:
        return {"vision": "mock"}
    import shutil as _sh
    import tempfile
    import time as _t

    from PIL import Image, ImageDraw

    # NamedTemporaryFile(delete=False) はハンドルを開いたまま同じパスへ save するため
    # Windows で PermissionError になりうる。一時ディレクトリを掘る方式に変更し、
    # 後始末も確実に行う（旧実装はプローブのたびに temp ファイルを残していた）。
    tmp_dir = tempfile.mkdtemp(prefix="vlm_probe_")
    probe_path = str(Path(tmp_dir) / "probe.png")
    img = Image.new("RGB", (160, 160), (255, 255, 255))
    d = ImageDraw.Draw(img)
    d.rectangle([24, 24, 136, 136], fill=(210, 30, 30))
    img.save(probe_path, "PNG")

    t0 = _t.time()
    try:
        client = _vision_client(timeout_seconds=60)
        out = client.chat_vision_json(
            image_path=probe_path,
            system="画像を見て JSON のみで答えてください。",
            user_text='画像の中の図形の色を {"color": "..."} の形式で答えてください。',
            max_tokens=64, tag="probe:vision")
        latency = round(_t.time() - t0, 1)
        ok = _looks_red(out)
        return {"vision": "ok" if ok else "responded_but_wrong",
                "answer": out, "latency_s": latency,
                "endpoint": _vision_endpoint(),
                "hint": None if ok else
                "モデルは応答しましたが画像の色を正しく答えていません。"
                "mmproj（視覚投影）の読み込みを確認してください。"}
    except LLMJsonError as e:
        # JSON にならなかっただけで視覚自体は動いている場合がある。
        # 旧実装はこれを「エンドポイント未応答」と報告していて誤診のもとだった。
        raw = getattr(e, "raw", "") or ""
        if _looks_red(raw):
            return {"vision": "ok", "answer": raw[:200], "endpoint": _vision_endpoint(),
                    "latency_s": round(_t.time() - t0, 1),
                    "hint": "視覚は動作していますが JSON 形式では返っていません（実用上は問題ありません）。"}
        return {"vision": "responded_but_wrong", "answer": raw[:200],
                "endpoint": _vision_endpoint(), "latency_s": round(_t.time() - t0, 1),
                "hint": "応答はありましたが色を判別できていません。mmproj の読み込みを確認してください。"}
    except Exception as e:  # noqa: BLE001
        return {"vision": "failed", "error": repr(e)[:300],
                "endpoint": _vision_endpoint(), "latency_s": round(_t.time() - t0, 1),
                "hint": "視覚エンドポイントへの呼び出しに失敗しました。llama-server の "
                        "--mmproj 指定、または config.yaml の llm.vision を確認してください。"}
    finally:
        _sh.rmtree(tmp_dir, ignore_errors=True)


@app.get("/api/health")
def health():
    """llama.cpp server 连通性。生产事故里"服务器根本没起来"占比惊人，
    在 UI 上常驻显示，别让用户等一小时才发现。"""
    if config.llm.mock:
        return {"llm": "mock"}
    import urllib.request
    root = config.llm.base_url.rstrip("/")
    if root.endswith("/v1"):
        root = root[: -len("/v1")]
    for probe in (f"{root}/health", f"{config.llm.base_url.rstrip('/')}/models"):
        try:
            with urllib.request.urlopen(probe, timeout=2) as resp:
                if resp.status == 200:
                    return {"llm": "ok", "endpoint": config.llm.base_url,
                            "docling": _warmup_state["docling"]}
        except Exception:
            continue
    return {"llm": "unreachable", "endpoint": config.llm.base_url,
            "docling": _warmup_state["docling"],
            "hint": "llama-server が起動しているか、config.yaml の base_url を確認してください"}


# ----------------------------------------------------------------------
# v3 新增：证据浏览 / 人工修订（HITL）/ 对话
# ----------------------------------------------------------------------

@app.get("/api/runs/{run_id}/evidence")
def run_evidence(run_id: str):
    """聚合后的文本证据 + 视觉证据，供 UI 表格展示与人工核对。"""
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir:
        raise HTTPException(404, "run 目录尚未生成")
    out: Dict[str, Any] = {"text": [], "visual": []}
    agg = run_dir / "evidence_aggregated.json"
    if agg.exists():
        out["text"] = json.loads(agg.read_text(encoding="utf-8")).get("evidence", [])
    vis = run_dir / "evidence_visual.json"
    if vis.exists():
        out["visual"] = json.loads(vis.read_text(encoding="utf-8")).get("evidence", [])
    # v3.18：台帳照合の結果を UI へ。当たった／当たらなかった／台帳が無いを
    # 区別できないと、利用者は原因の切り分けができない。
    ref = run_dir / "reference_match.json"
    if ref.exists():
        try:
            out["reference"] = json.loads(ref.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            out["reference"] = {}
    return out


@app.get("/api/runs/{run_id}/summary")
def get_summary(run_id: str):
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir or not (run_dir / "case_summary.json").exists():
        raise HTTPException(404, "尚未生成")
    return json.loads((run_dir / "case_summary.json").read_text(encoding="utf-8"))


def _spec_of_run(run_dir: Path):
    tpl = "case"
    mp = run_dir / "manifest.json"
    if mp.exists():
        try:
            tpl = json.loads(mp.read_text(encoding="utf-8")).get("template_id", "case")
        except Exception:
            pass
    return get_registry().get(tpl)


@app.post("/api/runs/{run_id}/summary")
def edit_summary(run_id: str, payload: dict = Body(...)):
    """人工修订（HITL）：模板感知校验 -> 版本快照 -> 飞轮 diff 记录 ->
    覆盖保存 -> 重渲染。坏数据 422 拒绝。"""
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir:
        raise HTTPException(404, "run 目录尚未生成")
    spec = _spec_of_run(run_dir)
    try:
        summary = spec.model.model_validate(payload)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(422, f"契约校验失败：{e}")

    before = {}
    sj = run_dir / "case_summary.json"
    if sj.exists():
        try:
            before = json.loads(sj.read_text(encoding="utf-8"))
        except Exception:
            pass
    snapshot(run_dir, note="hitl")              # 修订前快照
    after = summary.model_dump(mode="json")
    n_changes = 0
    try:
        n_changes = fb.record_edit(config, run_id, spec.id, before, after)  # 飞轮
    except Exception:  # noqa: BLE001
        pass

    sj.write_text(json.dumps(after, ensure_ascii=False, indent=2), encoding="utf-8")
    # v3.29：テンプレートで描き直すだけだと、差し込んだ図が全部消えていた。
    # 図版配置（figure_plan.json）を通す唯一の描画経路を使う。
    md, _rep = R.rerender(run_dir, summary, spec, trust_index=True)
    if (run_dir / "case_summary_external.md").exists():
        R.write_state(run_dir, external_stale=True)
    return {"ok": True, "markdown": md, "recorded_changes": n_changes}


@app.delete("/api/runs/{run_id}")
def delete_run(run_id: str):
    """删除一次运行：run 目录 + 台账记录 + 任务记录 + 上传的输入文件。
    磁盘是真源，因此必须删目录——否则重启时会从磁盘复活。"""
    run = _find_run(run_id)          # 不存在 -> 404
    with _runs_lock:
        state = _runs.get(run_id, {}).get("state")
    if state in ("running", "queued"):
        raise HTTPException(409, "実行中/待機中の run は削除できません（先に中断してください）")

    run_dir = _resolve_run_dir(run)
    removed = {"run_dir": False, "input_file": False}
    if run_dir and run_dir.exists():
        root = _runs_root().resolve()
        if str(run_dir.resolve()).startswith(str(root)):   # 越界保护
            shutil.rmtree(run_dir, ignore_errors=True)
            removed["run_dir"] = True

    input_path = run.get("input_path")
    if input_path:
        inbox = config.paths.resolve(config.paths.inbox_dir).resolve()
        p = Path(input_path)
        if p.exists() and str(p.resolve()).startswith(str(inbox)):
            try:
                p.unlink()
                removed["input_file"] = True
            except OSError:
                pass

    try:
        _ledger.delete(run_id=run_id, run_dir=str(run_dir) if run_dir else "")
    except Exception:  # noqa: BLE001
        pass
    try:
        with _jobs_conn() as c:
            c.execute("DELETE FROM jobs WHERE run_id=?", (run_id,))
    except Exception:  # noqa: BLE001
        pass
    with _runs_lock:
        _runs.pop(run_id, None)
    return {"ok": True, "removed": removed}


# ---------------------------------------------------------------------------
# v3.8：台帳・一括実行履歴の削除
# ---------------------------------------------------------------------------
#
# 単発 run の削除（上）と単一バッチの削除は既にあったが、
#   - 台帳から複数選択してまとめて消す
#   - 成果物は残して一覧だけ整理する（台帳行のみ削除）
#   - 一括実行の履歴をまとめて消す
# が無く、溜まった履歴を手作業で 1 件ずつ消すしかなかった。
#
# 企業内で使う以上「誰が何をいつ消したか」は残す必要があるので、
# 削除操作は必ず監査ログへ追記する。ログは追記専用の JSONL。


def _audit_log(action: str, detail: Dict[str, Any]) -> None:
    """削除操作の監査証跡。追記専用・失敗しても本流を止めない。"""
    try:
        path = _out_dir() / "audit_log.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"ts": time.time(), "at": time.strftime("%Y-%m-%d %H:%M:%S"),
                                "action": action, **detail}, ensure_ascii=False) + "\n")
    except Exception:  # noqa: BLE001
        pass


@app.post("/api/runs/delete-many")
def delete_runs_many(payload: dict = Body(...)):
    """複数 run をまとめて削除する。

    payload: {"run_ids": [...], "with_artifacts": false}
      with_artifacts=false … 台帳行だけ消す（成果物は残す）
      with_artifacts=true  … run ディレクトリ・入力ファイルごと消す

    実行中/待機中の run は飛ばして報告する（止めずに消すと成果物が壊れる）。
    """
    with_artifacts = bool(payload.get("with_artifacts", False))
    ids = [x for x in (payload.get("run_ids") or []) if x]
    if not ids:
        raise HTTPException(400, "run_ids が空です")

    deleted: List[str] = []
    skipped: List[Dict[str, str]] = []
    for rid in ids:
        with _runs_lock:
            st = _runs.get(rid, {}).get("state")
        if st in ("running", "queued"):
            skipped.append({"run_id": rid, "reason": "実行中/待機中"})
            continue
        try:
            if with_artifacts:
                delete_run(rid)          # 成果物・入力ファイル・台帳・ジョブを全部
            else:
                _ledger.delete(run_id=rid)   # 台帳行だけ
                with _runs_lock:
                    _runs.pop(rid, None)
            deleted.append(rid)
        except HTTPException as e:
            skipped.append({"run_id": rid, "reason": str(e.detail)})
        except Exception as e:  # noqa: BLE001
            skipped.append({"run_id": rid, "reason": repr(e)[:120]})

    _audit_log("runs.delete_many", {"requested": len(ids), "deleted": deleted,
                                    "skipped": skipped,
                                    "with_artifacts": with_artifacts})
    return {"ok": True, "deleted": deleted, "deleted_count": len(deleted),
            "skipped": skipped}


@app.post("/api/ledger/clear")
def ledger_clear(confirm: str = ""):
    """台帳を空にする（成果物ディレクトリは残す）。

    取り返しが付かないので confirm=DELETE を必須にする。
    成果物が残っているので、必要なら台帳は再構築できる（/api/ledger/rebuild）。
    """
    if confirm != "DELETE":
        raise HTTPException(400, "confirm=DELETE を付けてください（台帳を全消去します）")
    n = _ledger.clear()
    _audit_log("ledger.clear", {"rows_deleted": n})
    return {"ok": True, "rows_deleted": n,
            "note": "成果物は残っています。/api/ledger/rebuild で再構築できます。"}


@app.post("/api/batches/delete-many")
def batches_delete_many(payload: dict = Body(...)):
    """一括実行の履歴をまとめて削除する。

    payload: {"batch_ids": [...], "with_runs": false}
    """
    with_runs = bool(payload.get("with_runs", False))
    ids = [x for x in (payload.get("batch_ids") or []) if x]
    if not ids:
        raise HTTPException(400, "batch_ids が空です")
    deleted: List[str] = []
    failed: List[Dict[str, str]] = []
    for bid in ids:
        try:
            batch_delete(bid, with_runs=with_runs)
            deleted.append(bid)
        except HTTPException as e:
            failed.append({"batch_id": bid, "reason": str(e.detail)})
        except Exception as e:  # noqa: BLE001
            failed.append({"batch_id": bid, "reason": repr(e)[:120]})
    _audit_log("batches.delete_many", {"requested": len(ids), "deleted": deleted,
                                       "failed": failed, "with_runs": with_runs})
    return {"ok": True, "deleted": deleted, "deleted_count": len(deleted), "failed": failed}


def _restore_batch_links() -> None:
    """再起動後、ディスク上の batch.json から run -> batch の対応を復元する。
    これが無いと、バッチで処理した run が単発の実行履歴に混ざって出てくる。"""
    try:
        mapping = B.run_to_batch_map(config.paths.resolve(config.paths.out_dir))
    except Exception:  # noqa: BLE001
        return
    with _runs_lock:
        for run_id, batch_id in mapping.items():
            if run_id in _runs:
                _runs[run_id]["batch_id"] = batch_id


# ----------------------------------------------------------------------
# フォルダ一括処理（v3.6）
# ----------------------------------------------------------------------

def _out_dir() -> Path:
    return config.paths.resolve(config.paths.out_dir)


# ----------------------------------------------------------------------
# v3.30：「サーバー上のフォルダを指定」は、既定ではサーバー PC 自身からだけ
# ----------------------------------------------------------------------
#
# 投入はブラウザからのアップロードに一本化した（どの PC からでも同じ操作）。
# パスを指定してサーバーのディスクをその場で読む入口は、コピーを作らずに
# 済むので運用者には便利だが、別の PC の人に使わせるとサーバーのどこでも
# 覗けてしまう。そこで出す範囲を batch.server_path で決める。

def _is_server_side(request: Request) -> bool:
    """この要求はサーバー PC 自身から来たか。

    - ループバック（http://localhost:8000 で開いた場合）
    - 接続の「相手のアドレス」と「こちら側のアドレス」が同じ
      （サーバー PC で自分の LAN 上の IP http://192.168.x.x:8000 を開いた場合）
    別の PC から来た接続では必ず食い違う。
    """
    import ipaddress

    peer = (request.client.host if request.client else "") or ""
    peer = peer.split("%")[0]                       # IPv6 のゾーン ID
    if peer.startswith("::ffff:"):                  # IPv4 射影アドレス
        peer = peer[7:]
    try:
        if ipaddress.ip_address(peer).is_loopback:
            return True
    except ValueError:
        return False                                # IP でない名前は外部扱い
    local = (request.scope.get("server") or ("", 0))[0] or ""
    if local.startswith("::ffff:"):
        local = local[7:]
    return peer == local


def _server_path_allowed(request: Request) -> bool:
    if not config.batch.enabled:
        return False
    mode = config.batch.server_path
    if mode == "all":
        return True
    if mode == "local_only":
        return _is_server_side(request)
    return False


def _require_path_input(request: Request) -> None:
    """画面で隠すだけでは API を直接叩かれると素通りになるので、ここでも拒否する。"""
    if not _server_path_allowed(request):
        raise HTTPException(403, "サーバー上のフォルダ指定は、この PC からは使えません"
                                 "（ファイル／フォルダを選んでアップロードしてください）")


@app.post("/api/batches/scan")
def batch_scan(request: Request, payload: dict = Body(...)):
    """投入前の下見：何件対象になるかを返すだけ（副作用なし）。"""
    _require_path_input(request)
    folder = (payload.get("folder") or "").strip()
    if not folder:
        raise HTTPException(400, "folder を指定してください")
    denied = B.check_allowed(folder, config.batch.allowed_roots)
    if denied:
        raise HTTPException(403, denied)
    result = B.scan_folder(folder, recursive=bool(payload.get("recursive", True)),
                           suffixes=ALLOWED_SUFFIXES, max_files=config.batch.max_files)
    if not result.get("ok"):
        raise HTTPException(400, result.get("error", "走査に失敗しました"))
    result["files"] = result["files"][:50]      # 一覧はプレビュー用に頭だけ
    return result


@app.post("/api/batches")
def batch_create(request: Request, payload: dict = Body(...)):
    """フォルダ配下を丸ごとキューへ。原本はコピーせず、その場で読む。"""
    if not config.batch.enabled:
        raise HTTPException(403, "一括処理は無効です（config.yaml の batch.enabled）")
    _require_path_input(request)
    folder = (payload.get("folder") or "").strip()
    template_id = payload.get("template_id") or "case"
    input_mode = payload.get("input_mode") or ""
    recursive = bool(payload.get("recursive", config.batch.recursive))
    if not folder:
        raise HTTPException(400, "folder を指定してください")
    denied = B.check_allowed(folder, config.batch.allowed_roots)
    if denied:
        raise HTTPException(403, denied)
    try:
        if template_id != "auto":   # v3.11: "auto" は route_template が決める
            get_registry().get(template_id)
    except KeyError as e:
        raise HTTPException(400, str(e))

    scan = B.scan_folder(folder, recursive=recursive, suffixes=ALLOWED_SUFFIXES,
                         max_files=config.batch.max_files)
    if not scan.get("ok"):
        raise HTTPException(400, scan.get("error", "走査に失敗しました"))
    if not scan["files"]:
        raise HTTPException(400, "対象ファイルが見つかりませんでした")

    record = _launch_batch(scan["folder"], scan["files"], template_id=template_id,
                           input_mode=input_mode, recursive=recursive,
                           deep_read=_parse_deep(payload.get("deep_read", None)))
    return B.summarize(record, {})


def _parse_deep(raw: Any) -> Optional[bool]:
    # v3.12：UI は以前から deep_read を送っていたが API 側が読み捨てていた。
    return None if raw in (None, "") else str(raw).lower() in ("1", "true", "on", "yes")


def _launch_batch(folder: str, files: List[Dict[str, Any]], *, template_id: str,
                  input_mode: str, recursive: bool, deep_read: Optional[bool],
                  source: str = "folder",
                  extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """バッチを作ってキューへ入れる（パス指定とアップロードで共用）。

    files の各要素: {"name", "rel", "path"[, "source_rel"]}
      rel        … 画面に出す相対パス
      source_rel … 参照台帳の照合に渡す元の相対パス（無ければ rel）
    """
    from .nodes import file_hash

    items: List[Dict[str, Any]] = []
    seen: set = set()
    for f in files:
        path = f["path"]
        try:
            # run_id をディスクの run ディレクトリ名と同一にする（内容ハッシュ）。
            # 再起動しても履歴が二重にならず、進捗も引き継げる。
            run_id = f"{Path(path).stem}_{file_hash(path)}"
        except OSError:
            continue
        if run_id in seen:      # 同一内容のファイルが複数あっても run は 1 つ
            continue
        seen.add(run_id)
        item = {"name": f["name"], "rel": f["rel"], "path": path,
                "run_id": run_id, "state": "queued"}
        if f.get("source_rel"):
            item["source_rel"] = f["source_rel"]
        items.append(item)
    if not items:
        raise HTTPException(400, "対象ファイルが見つかりませんでした")

    record = B.create_batch(_out_dir(), folder, items,
                            template_id=template_id, input_mode=input_mode,
                            recursive=recursive, deep_read=deep_read,
                            source=source, extra=extra)
    run_dir_root = _runs_root()
    for item in items:
        rid = item["run_id"]
        with _runs_lock:
            _runs[rid] = {"run_id": rid, "input_name": item["rel"],
                          "input_path": item["path"], "template_id": template_id,
                          "batch_id": record["batch_id"], "state": "queued",
                          "created": time.time(), "run_dir": str(run_dir_root / rid)}
        _job_set(rid, "queued", item["path"], item["rel"], template_id)
        threading.Thread(target=_worker,
                         args=(rid, item["path"], template_id, input_mode,
                               deep_read, record["batch_id"], None,
                               item.get("name", ""),
                               item.get("source_rel") or item.get("rel", "")),
                         daemon=True).start()
    return record


# ----------------------------------------------------------------------
# v3.30 ブラウザからの一括アップロード（どの PC からでも同じ）
# ----------------------------------------------------------------------
#
# 複数ファイル・フォルダ・複数フォルダを選ぶと、中身を
# inbox/uploads/<upload_id>/ に一時保存してから通常のバッチにする。
#   POST   /api/uploads                 置き場を作る（放置された置き場の掃除も）
#   POST   /api/uploads/{id}/files      数件ずつ送る（進捗表示・途中失敗の再送のため）
#   POST   /api/uploads/{id}/start      バッチとしてキューへ
#   DELETE /api/uploads/{id}            失敗時の後始末
# 安全面の詳細は upload_staging.py。

def _inbox_dir() -> Path:
    p = config.paths.resolve(config.paths.inbox_dir)
    p.mkdir(parents=True, exist_ok=True)
    return p


def _upload_limits() -> Dict[str, Any]:
    b = config.batch
    return {"enabled": bool(b.enabled),
            "max_files": b.max_files, "max_upload_mb": b.max_upload_mb,
            "max_file_mb": b.max_file_mb,
            "suffixes": sorted(ALLOWED_SUFFIXES)}


def _require_upload_enabled() -> None:
    if not config.batch.enabled:
        raise HTTPException(403, "一括処理は無効です（config.yaml の batch.enabled）")


def _load_upload(upload_id: str) -> Dict[str, Any]:
    m = U.load(_inbox_dir(), upload_id)
    if not m:
        raise HTTPException(404, "アップロードが見つかりません（期限切れの可能性があります）")
    return m


@app.post("/api/uploads")
def upload_init(request: Request):
    """置き場を作る。ついでに放置された置き場を掃除する。"""
    _require_upload_enabled()
    try:
        U.cleanup(_inbox_dir(), config.batch.upload_ttl_hours)
    except Exception:  # noqa: BLE001 掃除の失敗で受付を止めない
        pass
    client = request.client.host if request.client else ""
    m = U.create(_inbox_dir(), client=client)
    return {"upload_id": m["upload_id"], "limits": _upload_limits()}


@app.post("/api/uploads/{upload_id}/files")
async def upload_files(upload_id: str,
                       files: List[UploadFile] = File(...),
                       relative_paths: List[str] = Form(default=[])):
    """数件ずつ受け取る。何度呼んでもよい（同じ相対パスは上書き）。"""
    _require_upload_enabled()
    m = _load_upload(upload_id)
    if m.get("committed"):
        raise HTTPException(409, "このアップロードは投入済みです")
    base = U.upload_dir(_inbox_dir(), upload_id) / U.FILES_DIR
    max_file = config.batch.max_file_mb * 1024 * 1024
    max_total = config.batch.max_upload_mb * 1024 * 1024
    by_rel = {f["rel"]: f for f in m["files"]}
    accepted, rejected = [], []

    for i, uf in enumerate(files):
        rel_raw = relative_paths[i] if i < len(relative_paths) else ""
        parts = U.split_rel(rel_raw, uf.filename or "")
        shown = (rel_raw or uf.filename or "?").replace("\\", "/")
        if parts is None:
            rejected.append({"rel": shown, "reason": "不正なパス"})
            continue
        why = U.ignore_reason(parts, ALLOWED_SUFFIXES)
        if why:
            rejected.append({"rel": shown, "reason": why})
            continue
        rel = "/".join(parts)
        if rel not in by_rel and len(by_rel) >= config.batch.max_files:
            rejected.append({"rel": rel, "reason": f"件数の上限（{config.batch.max_files} 件）"})
            continue
        dest = U.resolve_inside(base, U.storage_parts(parts))
        if dest is None:
            rejected.append({"rel": rel, "reason": "不正なパス"})
            continue
        prev_size = by_rel[rel]["size"] if rel in by_rel else 0
        budget = max_total - (m["total_bytes"] - prev_size)
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_name(dest.name + ".part")
        size, over = 0, ""
        with tmp.open("wb") as out:
            while True:
                chunk = await uf.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > max_file:
                    over = f"1 ファイルの上限（{config.batch.max_file_mb} MB）を超えています"
                    break
                if size > budget:
                    over = f"合計の上限（{config.batch.max_upload_mb} MB）を超えます"
                    break
                out.write(chunk)
        if over:
            tmp.unlink(missing_ok=True)
            rejected.append({"rel": rel, "reason": over})
            continue
        tmp.replace(dest)
        entry = {"rel": rel, "name": parts[-1], "path": str(dest), "size": size}
        m["total_bytes"] += size - prev_size
        by_rel[rel] = entry
        accepted.append(rel)

    m["files"] = list(by_rel.values())
    m["rejected"] = (m.get("rejected") or []) + rejected
    U.save(_inbox_dir(), m)
    return {"ok": True, "accepted": accepted, "rejected": rejected,
            "count": len(m["files"]), "total_bytes": m["total_bytes"]}


@app.post("/api/uploads/{upload_id}/start")
def upload_start(upload_id: str, payload: dict = Body(default={})):
    """置き場の中身でバッチを作り、キューへ入れる。"""
    _require_upload_enabled()
    m = _load_upload(upload_id)
    if m.get("committed"):
        raise HTTPException(409, "このアップロードは投入済みです")
    if not m["files"]:
        raise HTTPException(400, "対象ファイルがありません")
    template_id = payload.get("template_id") or "case"
    try:
        if template_id != "auto":
            get_registry().get(template_id)
    except KeyError as e:
        raise HTTPException(400, str(e))

    entries = sorted(m["files"], key=lambda f: f["rel"])
    top, shown = U.common_top([f["rel"] for f in entries])
    label = (payload.get("label") or "").strip()[:80]
    folder = top or label or f"アップロード（{len(entries)} 件）"
    files = [{"name": f["name"], "rel": s, "path": f["path"], "source_rel": f["rel"]}
             for f, s in zip(entries, shown)]
    record = _launch_batch(folder, files, template_id=template_id,
                           input_mode=payload.get("input_mode") or "",
                           recursive=bool(payload.get("recursive", True)),
                           deep_read=_parse_deep(payload.get("deep_read", None)),
                           source="upload",
                           extra={"upload_id": upload_id, "client": m.get("client", ""),
                                  "uploaded_bytes": m["total_bytes"]})
    m["committed"] = True
    m["batch_id"] = record["batch_id"]
    U.save(_inbox_dir(), m)
    _audit_log("batch.upload", {"batch_id": record["batch_id"], "upload_id": upload_id,
                                "client": m.get("client", ""), "files": len(files),
                                "bytes": m["total_bytes"]})
    out = B.summarize(record, {})
    out["rejected"] = m.get("rejected", [])
    return out


@app.delete("/api/uploads/{upload_id}")
def upload_discard(upload_id: str):
    """途中で失敗・中止した場合の後始末。投入済みの置き場は消さない（run が読む）。"""
    m = _load_upload(upload_id)
    if m.get("committed"):
        raise HTTPException(409, "投入済みのアップロードは削除できません（一括処理の履歴から削除してください）")
    U.discard(_inbox_dir(), upload_id)
    return {"ok": True}


def _live_states() -> Dict[str, str]:
    with _runs_lock:
        return {rid: r.get("state", "unknown") for rid, r in _runs.items()}



# =====================================================================
# v3.14 参照台帳ライブラリ
# =====================================================================
#
# 台帳は「年度に数冊」の参照データで、run のたびに上げ直す物ではない。
# 常駐ライブラリに置いて全 run で共用し、必要なら run 単位で追加指定する。

def _reference_dir() -> Path:
    raw = getattr(config.workflow, "reference_library_dir", "data/references")
    p = Path(raw)
    if not p.is_absolute():
        p = PROJECT_ROOT / p
    p.mkdir(parents=True, exist_ok=True)
    return p


@app.get("/api/references")
def reference_list():
    """登録済みの台帳と、そこから作った索引の状態を返す。"""
    from .reference_index import build_index, load_reference_specs

    d = _reference_dir()
    files = [{"name": f.name, "size": f.stat().st_size,
              "modified": f.stat().st_mtime}
             for f in sorted(d.glob("*.xls*")) if not f.name.startswith("~$")]
    stats = {}
    if files:
        try:
            spec = load_reference_specs().get(
                getattr(config.workflow, "reference_spec_id", "default"))
            stats = build_index([str(d)], spec=spec).stats()
        except Exception as e:  # noqa: BLE001 一覧表示で落とさない
            stats = {"error": f"{type(e).__name__}: {e}"}
    return {"enabled": getattr(config.workflow, "reference_enabled", False),
            "dir": str(d), "files": files, "index": stats,
            "specs": [{"id": k, "name": v.name, "description": v.description}
                      for k, v in load_reference_specs().items()]}
    # 注：v3.15 以降、列名の設定は不要。表頭の行と照合鍵の列は値の形から
    # 自動検出し、その他の列は生の表頭のままモデルへ渡す。


@app.post("/api/references")
async def reference_upload(files: List[UploadFile] = File(...)):
    """台帳 Excel をライブラリへ追加する。"""
    from .reference_index import clear_cache

    d = _reference_dir()
    saved = []
    for f in files:
        name = Path(f.filename or "").name
        if not name or Path(name).suffix.lower() not in (".xlsx", ".xlsm"):
            raise HTTPException(400, f"Excel ファイルのみ登録できます: {name}")
        dest = d / name
        dest.write_bytes(await f.read())
        saved.append(name)
    clear_cache()   # ファイルが変わったので索引を作り直させる
    _audit_log("reference.upload", {"files": saved})
    return {"ok": True, "saved": saved}


@app.delete("/api/references/{name}")
def reference_delete(name: str):
    from .reference_index import clear_cache

    safe = Path(name).name
    target = _reference_dir() / safe
    if not target.exists():
        raise HTTPException(404, "見つかりません")
    target.unlink()
    clear_cache()
    _audit_log("reference.delete", {"file": safe})
    return {"ok": True}


@app.get("/api/references/probe")
def reference_probe(filename: str):
    """パスを投げると、どの行に当たるかを試せる（設定確認用）。

    本番の run を回す前に「うちの命名規則で当たるのか」を確かめられるように
    しておく。照合の当たり外れは後からでは調べにくい。

    v3.26：ファイル名だけでなく **フォルダを含む完全パス** を受け付ける。
    照合はファイル名で当たらなければ親フォルダ名で引き直すので、
    ファイル名だけで試すと本番と条件が食い違い、テストの意味が薄れていた。
    区切りは円記号でもスラッシュでもよい（サーバが Linux でも Windows の
    パスを解釈できるよう、照合側で区切りを揃える）。
    """
    from .reference_index import build_index, load_reference_specs

    d = _reference_dir()
    try:
        spec = load_reference_specs().get(
            getattr(config.workflow, "reference_spec_id", "default"))
        idx = build_index([str(d)], spec=spec)
        res = idx.match(filename,
                        allow_partial=getattr(config.workflow, "reference_allow_partial", True))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(500, f"{type(e).__name__}: {e}")
    return {"query": filename, **res.to_dict()}


@app.post("/api/batches/{batch_id}/cancel")
def batch_cancel(batch_id: str):
    """バッチ全体を中止する（v3.12）。

    未着手の run はワーカーが枠を取った瞬間にフラグを見て即終了するので、
    利用者が待たされるのは「今まさに実行中の 1 件」だけになる。
    """
    record = B.load_batch(_out_dir(), batch_id)
    if not record:
        raise HTTPException(404, "バッチが見つかりません")
    res = B.cancel_batch(_out_dir(), batch_id)

    running: List[str] = []
    with _runs_lock:
        for item in record.get("items", []):
            rid = item.get("run_id")
            run = _runs.get(rid) if rid else None
            if not run or run.get("state") in ("done", "failed", "cancelled"):
                continue
            if run.get("state") == "running":
                running.append(rid)
            else:
                run["state"] = "cancelled"
    # 実行中のものには協調中止を要求する（進行中の LLM 応答の後で止まる）
    for rid in running:
        try:
            run_dir = _resolve_run_dir(_runs.get(rid, {}))
            if run_dir:
                RunStore(run_dir).request_cancel()
        except Exception:  # noqa: BLE001 1 件の失敗で全体を止めない
            continue
    _audit_log("batch.cancel", {"batch_id": batch_id, "stopped": res.get("stopped", 0),
                                "running": len(running)})
    return {"ok": True, "batch_id": batch_id,
            "stopped": res.get("stopped", 0), "running_cancelling": len(running)}


@app.get("/api/batches")
def batch_list():
    live = _live_states()
    return [B.summarize(r, live) for r in B.all_batches(_out_dir())]


@app.get("/api/batches/{batch_id}")
def batch_detail(batch_id: str):
    record = B.load_batch(_out_dir(), batch_id)
    if not record:
        raise HTTPException(404, "バッチが見つかりません")
    live = _live_states()
    items = []
    for it in record.get("items", []):
        rid = it.get("run_id", "")
        rd = _runs_root() / rid
        reviewed = bool(R.read_state(rd).get("reviewed")) if rd.exists() else False
        items.append({**it, "state": live.get(rid, it.get("state", "unknown")),
                      "reviewed": reviewed})
    return {**B.summarize(record, live), "items": items,
            "reviewed_count": sum(1 for x in items if x["reviewed"])}


@app.delete("/api/batches/{batch_id}")
def batch_delete(batch_id: str, with_runs: bool = False):
    """既定はバッチ台帳のみ削除（run と成果物は残す）。
    with_runs=true なら各 run も個別削除 API と同じ規則で消す。"""
    record = B.load_batch(_out_dir(), batch_id)
    if not record:
        raise HTTPException(404, "バッチが見つかりません")
    live = _live_states()
    busy = [it for it in record.get("items", [])
            if live.get(it.get("run_id", "")) in ("running", "queued")]
    if busy:
        raise HTTPException(409, f"実行中/待機中の run が {len(busy)} 件あります（先に中断してください）")
    removed_runs = 0
    if with_runs:
        for it in record.get("items", []):
            try:
                delete_run(it["run_id"])
                removed_runs += 1
            except HTTPException:
                continue
    else:
        with _runs_lock:
            for it in record.get("items", []):
                if it["run_id"] in _runs:
                    _runs[it["run_id"]].pop("batch_id", None)
    B.delete_batch(_out_dir(), batch_id)
    # v3.30：アップロード由来なら置き場も片付ける。原本は利用者の PC にあり、
    # ここにあるのは写しなので消してよい。run を残す場合は run が読むので残す。
    if with_runs and record.get("source") == "upload" and record.get("upload_id"):
        U.discard(_inbox_dir(), record["upload_id"])
    return {"ok": True, "removed_runs": removed_runs}


# ----------------------------------------------------------------------
# 書面エクスポート（PDF / Word）— v3.6
# ----------------------------------------------------------------------

def _export_response(sections: List[DocSection], fmt: str, filename: str,
                     doc_title: str, subtitle: str = ""):
    if not sections:
        raise HTTPException(404, "エクスポートできる要約がまだありません")
    tmp_dir = _out_dir() / "exports"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    out = tmp_dir / filename
    try:
        if fmt == "pdf":
            export_pdf(sections, out, doc_title=doc_title, subtitle=subtitle)
            media = "application/pdf"
        elif fmt == "pptx":
            # v3.9：社内テンプレート（.potx/.pptx）が置いてあれば書式を引き継ぐ。
            # 無ければ既定の 16:9 白地で組む。
            tpl = _pptx_template_path()
            export_pptx(sections, out, deck_title=doc_title, subtitle=subtitle,
                        template_path=tpl)
            media = ("application/vnd.openxmlformats-officedocument"
                     ".presentationml.presentation")
        else:
            export_docx(sections, out, doc_title=doc_title, subtitle=subtitle)
            media = ("application/vnd.openxmlformats-officedocument"
                     ".wordprocessingml.document")
    except ImportError as e:      # reportlab / python-docx / python-pptx 未導入
        raise HTTPException(501, f"エクスポート用ライブラリが未導入です: {e}")
    return FileResponse(str(out), media_type=media, filename=filename)


def _pptx_template_path() -> Optional[str]:
    """社内 PPT テンプレートの置き場所。

    `templates/deck_template.potx`（または .pptx）が有ればそれを土台にする。
    python-pptx は既存ファイルを開いて使えるので、会社のマスタースライドを
    そのまま活かせる（pptxgenjs 系ではこれが出来ない）。
    """
    for name in ("deck_template.potx", "deck_template.pptx"):
        p = PROJECT_ROOT / "templates" / name
        if p.exists():
            return str(p)
    return None


def _safe_name(text: str, fallback: str) -> str:
    cleaned = "".join(ch for ch in (text or "") if ch not in '\\/:*?"<>|\n\r\t').strip()
    return (cleaned or fallback)[:80]


@app.get("/api/runs/{run_id}/export.{fmt}")
def run_export(run_id: str, fmt: str, tier: str = "internal"):
    """1 件分の要約を体裁付き PDF / Word で出力（処理完了後に UI へ出るボタン）。"""
    if fmt not in ("pdf", "docx", "pptx"):
        raise HTTPException(400, "fmt は pdf / docx / pptx のいずれか")
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir:
        raise HTTPException(404, "run 目录尚未生成")
    section = section_from_run_dir(run_dir, tier)
    if section is None:
        raise HTTPException(404, "社外版が未生成です" if tier == "external" else "要約が未生成です")
    if not section.source_name:
        section.source_name = run.get("input_name", "")
    label = "社外版" if tier == "external" else "社内版"
    name = _safe_name(section.title, run_id)
    return _export_response([section], fmt, f"{name}_{tier}.{fmt}",
                            doc_title=section.title, subtitle=f"{label}　／　{section.source_name}")


@app.get("/api/batches/{batch_id}/export.{fmt}")
def batch_export(batch_id: str, fmt: str, tier: str = "internal", mode: str = "combined",
                 only_reviewed: bool = False):
    """フォルダ一括処理の出力。

    mode=combined：全件を 1 冊（索引ページ + 案件ごとに改ページ）
    mode=separate：案件ごとに 1 ファイル、ZIP にまとめる（v3.29）
    only_reviewed：確認済みの案件だけ（v3.29）
    """
    if fmt not in ("pdf", "docx", "pptx"):
        raise HTTPException(400, "fmt は pdf / docx / pptx のいずれか")
    record = B.load_batch(_out_dir(), batch_id)
    if not record:
        raise HTTPException(404, "バッチが見つかりません")
    sections: List[DocSection] = []
    for it in record.get("items", []):
        run_dir = _runs_root() / it["run_id"]
        if not run_dir.exists():
            continue
        if only_reviewed and not R.read_state(run_dir).get("reviewed"):
            continue
        sec = section_from_run_dir(run_dir, tier)
        if sec is not None:
            sec.source_name = sec.source_name or it.get("rel", "")
            sections.append(sec)
    label = "社外版" if tier == "external" else "社内版"
    if mode == "separate":
        folder = Path(record.get("folder", "")).name or "batch"
        return _export_separate(sections, fmt, f"{_safe_name(folder, batch_id)}_{tier}_個別.zip")
    folder = Path(record.get("folder", "")).name or "batch"
    return _export_response(
        sections, fmt, f"{_safe_name(folder, batch_id)}_{tier}.{fmt}",
        doc_title=f"要約レポート：{folder}",
        subtitle=f"{label}　／　{len(sections)} 件　／　{record.get('folder', '')}")


def _export_separate(sections: List[DocSection], fmt: str, zip_name: str):
    """案件ごとに 1 ファイルずつ出力し、ZIP にまとめる（v3.29）。

    ブラウザに複数ファイルを一度に保存させるのは確実でないので ZIP にする。
    名前は「001_案件名.pdf」。バッチの並び順を保ち、同名は _2, _3 を付ける。
    合冊版の索引ページの代わりに 一覧.csv を同梱する。
    """
    import csv
    import io
    import uuid
    import zipfile

    if not sections:
        raise HTTPException(404, "エクスポートできる要約がまだありません")
    work = _out_dir() / "exports" / f"sep_{uuid.uuid4().hex[:8]}"
    work.mkdir(parents=True, exist_ok=True)
    rows = [["番号", "案件名", "元ファイル", "出力ファイル"]]
    used: set = set()
    files = []
    for i, sec in enumerate(sections, 1):
        base = f"{i:03d}_{_safe_name(sec.title or '', f'case{i}')}"[:90]
        name, n = base, 2
        while name in used:
            name, n = f"{base}_{n}", n + 1
        used.add(name)
        out = work / f"{name}.{fmt}"
        try:
            if fmt == "pdf":
                export_pdf([sec], out, doc_title=sec.title or name, subtitle=sec.source_name or "")
            elif fmt == "pptx":
                export_pptx([sec], out, deck_title=sec.title or name,
                            subtitle=sec.source_name or "", template_path=_pptx_template_path())
            else:
                export_docx([sec], out, doc_title=sec.title or name, subtitle=sec.source_name or "")
        except ImportError as e:
            raise HTTPException(501, f"エクスポート用ライブラリが未導入です: {e}")
        files.append(out)
        rows.append([i, sec.title or "", sec.source_name or "", out.name])
    buf = io.StringIO()
    csv.writer(buf).writerows(rows)
    zpath = work.parent / zip_name
    with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("一覧.csv", "\ufeff" + buf.getvalue())
        for f in files:
            zf.write(f, f.name)
    return FileResponse(str(zpath), media_type="application/zip", filename=zip_name)


# ======================================================================
# v3.29 確認・編集画面
# ======================================================================

@app.get("/review/{run_id}")
def review_page(run_id: str):
    """確認・編集画面（別タブでも、?embed=1 でポップアップ内でも同じページ）。"""
    _find_run(run_id)
    html = (PROJECT_ROOT / "static" / "review.html").read_text(encoding="utf-8")
    return HTMLResponse(html)


def _review_run_dir(run_id: str) -> Path:
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir or not (run_dir / "case_summary.json").exists():
        raise HTTPException(404, "この案件はまだ要約が完成していません")
    return run_dir


def _batch_neighbors(run_id: str, batch_id: str) -> Dict[str, Any]:
    if not batch_id:
        with _runs_lock:
            batch_id = (_runs.get(run_id) or {}).get("batch_id") or ""
    if not batch_id:
        return {}
    record = B.load_batch(_out_dir(), batch_id) or {}
    ids = [it.get("run_id") for it in record.get("items", [])
           if (_runs_root() / str(it.get("run_id"))).joinpath("case_summary.json").exists()]
    if run_id not in ids:
        return {}
    i = ids.index(run_id)
    return {"batch_id": batch_id, "position": i + 1, "total": len(ids),
            "prev": ids[i - 1] if i > 0 else None,
            "next": ids[i + 1] if i + 1 < len(ids) else None}


@app.get("/api/runs/{run_id}/review")
def review_bundle(run_id: str, batch: str = ""):
    run_dir = _review_run_dir(run_id)
    summary = json.loads((run_dir / "case_summary.json").read_text(encoding="utf-8"))
    plan = R.ensure_plan(run_dir, summary)
    md_path = run_dir / "case_summary.md"
    md = md_path.read_text(encoding="utf-8") if md_path.exists() else ""
    st = R.read_state(run_dir)
    return {
        "run_id": run_id, "summary": summary, "sections": R.review_sections(summary),
        "plan": plan, "images": R.build_images(run_dir, md, plan),
        "evidence": R.build_evidence(run_dir), "pages": R.list_pages(run_dir),
        "version": R.version_token(run_dir), "reviewed": bool(st.get("reviewed")),
        "reviewed_at": st.get("reviewed_at", ""),
        "external_stale": bool(st.get("external_stale")),
        "batch": _batch_neighbors(run_id, batch),
    }


@app.get("/api/runs/{run_id}/asset")
def review_asset(run_id: str, p: str):
    run_dir = _review_run_dir(run_id)
    try:
        path = R.safe_asset(run_dir, p)
    except ValueError as e:
        raise HTTPException(404, str(e))
    media = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
             ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp"}[path.suffix.lower()]
    return FileResponse(str(path), media_type=media)


@app.post("/api/runs/{run_id}/review")
def review_save(run_id: str, payload: dict = Body(...)):
    """保存：版の確認 → 契約検証 → 版の保存 → 書き込み → 描画（図版配置を通す）。"""
    run_dir = _review_run_dir(run_id)
    if payload.get("version") != R.version_token(run_dir):
        raise HTTPException(409, "別の画面でこの案件が更新されています。再読み込みしてから編集してください")
    spec = _spec_of_run(run_dir)
    try:
        summary = spec.model.model_validate(payload.get("summary") or {})
    except Exception as e:  # noqa: BLE001
        raise HTTPException(422, f"内容の形式が正しくありません：{e}")
    sj = run_dir / "case_summary.json"
    before = json.loads(sj.read_text(encoding="utf-8")) if sj.exists() else {}
    snapshot(run_dir, note="review")
    after = summary.model_dump(mode="json")
    try:
        fb.record_edit(config, run_id, spec.id, before, after)
    except Exception:  # noqa: BLE001
        pass
    sj.write_text(json.dumps(after, ensure_ascii=False, indent=2), encoding="utf-8")
    items = R.clean_plan_items(payload.get("plan") or [], run_dir)
    save_plan(run_dir, {"version": 1, "source": "user", "items": items})
    md, rep = R.rerender(run_dir, summary, spec, trust_index=True)
    kw: Dict[str, Any] = {}
    if (run_dir / "case_summary_external.md").exists():
        kw["external_stale"] = True
    if "reviewed" in payload:
        kw["reviewed"] = bool(payload["reviewed"])
    st = R.write_state(run_dir, **kw) if kw else R.read_state(run_dir)
    return {"ok": True, "version": R.version_token(run_dir), "figures": rep["placed"],
            "unplaced": rep["missing"], "reviewed": bool(st.get("reviewed")),
            "external_stale": bool(st.get("external_stale"))}


@app.post("/api/runs/{run_id}/reviewed")
def review_mark(run_id: str, payload: dict = Body(...)):
    run_dir = _review_run_dir(run_id)
    st = R.write_state(run_dir, reviewed=bool(payload.get("reviewed")))
    return {"ok": True, "reviewed": bool(st.get("reviewed")), "reviewed_at": st.get("reviewed_at", "")}


@app.post("/api/runs/{run_id}/figures/analyze")
def review_analyze(run_id: str, payload: dict = Body(...)):
    """1 枚だけ視覚モデルで読む（確認画面から、未解析の画像に図題を付けたいとき）。"""
    run_dir = _review_run_dir(run_id)
    rel = str(payload.get("p") or "")
    try:
        path = R.safe_asset(run_dir, rel)
    except ValueError as e:
        raise HTTPException(404, str(e))
    from .nodes import VISION_SYSTEM, build_vision_client
    ctx = str(payload.get("context") or "")[:800]
    user = ("資料から取り出した画像です。指定の形式の JSON だけを返してください。"
            + (f"\n\n参考（元の資料で画像の近くにあった文）：\n{ctx}" if ctx else ""))
    try:
        raw = build_vision_client(config).chat_vision_json(
            str(path), VISION_SYSTEM, user, max_tokens=1500, tag="review:analyze")
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, f"画像の解析に失敗しました：{str(e)[:200]}")
    keys = ("figure_title", "figure_caption", "figure_worthiness", "visual_summary",
            "visual_type", "key_facts", "readable_text", "confidence")
    result = {k: raw.get(k) for k in keys if k in raw}
    R.save_analysis(run_dir, rel, result)
    return result


@app.get("/api/templates")
def list_templates():
    return get_registry().list()


@app.get("/api/runs/{run_id}/versions")
def run_versions(run_id: str):
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir:
        raise HTTPException(404, "run 目录尚未生成")
    return list_versions(run_dir)


@app.get("/api/runs/{run_id}/versions/{version_id}/{filename}")
def run_version_file(run_id: str, version_id: str, filename: str):
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    path = (run_dir / "versions" / version_id / filename) if run_dir else None
    if not path or ".." in version_id or ".." in filename or not path.exists():
        raise HTTPException(404, "版本文件不存在")
    return FileResponse(str(path), filename=f"{version_id}_{filename}")


@app.post("/api/runs/{run_id}/register_example")
def register_example(run_id: str):
    """反馈飞轮：把当前摘要收进优质示例库（few-shot 注入源）。"""
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir or not (run_dir / "case_summary.json").exists():
        raise HTTPException(404, "尚未生成")
    spec = _spec_of_run(run_dir)
    summary = json.loads((run_dir / "case_summary.json").read_text(encoding="utf-8"))
    fb.register_example(config, run_id, spec.id, summary)
    return {"ok": True}


@app.get("/api/feedback/stats")
def feedback_stats(template_id: str = ""):
    return fb.stats(config, template_id)


@app.post("/api/site/build")
def site_build():
    """构建对外介绍站（社外层数据 + 出口泄漏闸；纯静态产物）。"""
    if not config.site.enabled:
        raise HTTPException(403, "サイト機能は無効です（config.yaml の site.enabled を true に）")
    llm = None
    if not config.llm.mock:
        try:
            llm = _get_chat_llm()
        except Exception:
            llm = None
    elif config.llm.mock:
        llm = None  # mock 下用朴素文案，构建流程完整可测
    report = build_site(config, _ledger, llm)
    return report


@app.get("/api/site/preview/{path:path}")
def site_preview(path: str = "index.html"):
    if not config.site.enabled:
        raise HTTPException(403, "サイト機能は無効です")
    root = config.paths.resolve(config.paths.out_dir) / "site"
    p = (root / (path or "index.html")).resolve()
    if ".." in path or not str(p).startswith(str(root.resolve())) or not p.exists():
        raise HTTPException(404, "サイト未生成またはパス不正")
    media = "text/css" if p.suffix == ".css" else "text/html"
    return FileResponse(str(p), media_type=media)


@app.post("/api/runs/{run_id}/chat/stream")
def chat_stream(run_id: str, payload: dict = Body(...)):
    """流式对话：SSE 逐 token 推送（本地模型生成慢，流式体验差异巨大）。"""
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir:
        raise HTTPException(404, "run 目录尚未生成")
    messages = payload.get("messages", [])
    if not messages or messages[-1].get("role") != "user":
        raise HTTPException(400, "messages 末尾必须是 user 消息")

    context_parts = []
    sj = run_dir / "case_summary.json"
    if sj.exists():
        context_parts.append("【要約 JSON】\n" + sj.read_text(encoding="utf-8"))
    agg = run_dir / "evidence_aggregated.json"
    if agg.exists():
        context_parts.append("【証拠】\n" + agg.read_text(encoding="utf-8")[:16000])
    context = "\n\n".join(context_parts) or "（処理結果なし）"
    history = "\n".join(
        f"{'ユーザー' if m['role'] == 'user' else 'アシスタント'}: {m['content']}"
        for m in messages[:-1][-8:])
    user_text = (f"処理結果：\n\n{context}\n\nこれまでの会話：\n{history or '（なし）'}\n\n"
                 f"ユーザーの質問：{messages[-1]['content']}")

    def gen():
        if config.llm.mock:
            for tok in ["（モック", "ストリーミング", "応答）"]:
                yield f"data: {json.dumps({'delta': tok}, ensure_ascii=False)}\n\n"
                time.sleep(0.05)
        else:
            try:
                for delta in _get_chat_llm().chat_text_stream(
                        system=CHAT_SYSTEM, user=user_text, max_tokens=2048):
                    yield f"data: {json.dumps({'delta': delta}, ensure_ascii=False)}\n\n"
            except Exception as e:  # noqa: BLE001
                yield f"data: {json.dumps({'error': repr(e)[:200]}, ensure_ascii=False)}\n\n"
        yield "data: {\"done\": true}\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream")


_chat_llm: Optional[LocalLLMClient] = None


def _get_chat_llm() -> LocalLLMClient:
    global _chat_llm
    if _chat_llm is None:
        _chat_llm = LocalLLMClient(**config.llm.model_dump(exclude={"vision"}))
    return _chat_llm


CHAT_SYSTEM = """あなたは社内文書要約パイプラインのアシスタントです。
以下に、あるドキュメントの処理結果（構造化要約と抽出された証拠）を示します。
ユーザーの質問には、この情報に基づいて日本語（またはユーザーの言語）で答えてください。
資料で確認できない内容は「資料内で確認できず」と正直に答え、推測で断定しないでください。
"""


@app.post("/api/runs/{run_id}/chat")
def chat_about_run(run_id: str, payload: dict = Body(...)):
    """
    针对某次运行结果的问答：把该 run 的摘要 + 证据装入上下文，
    历史消息由前端维护并整体提交（本地 LLM 无状态）。
    """
    run = _find_run(run_id)
    run_dir = _resolve_run_dir(run)
    if not run_dir:
        raise HTTPException(404, "run 目录尚未生成")

    messages = payload.get("messages", [])
    if not messages or messages[-1].get("role") != "user":
        raise HTTPException(400, "messages 末尾必须是 user 消息")

    context_parts = []
    sj = run_dir / "case_summary.json"
    if sj.exists():
        context_parts.append("【要約 JSON】\n" + sj.read_text(encoding="utf-8"))
    agg = run_dir / "evidence_aggregated.json"
    if agg.exists():
        context_parts.append("【証拠】\n" + agg.read_text(encoding="utf-8")[:16000])
    context = "\n\n".join(context_parts) or "（処理結果なし）"

    if config.llm.mock:
        return {"reply": "（モックモード）ご質問を受け付けました。実環境ではローカル LLM が要約と証拠に基づいて回答します。"}

    history = "\n".join(
        f"{'ユーザー' if m['role'] == 'user' else 'アシスタント'}: {m['content']}"
        for m in messages[:-1][-8:]
    )
    user_text = f"""処理結果：

{context}

これまでの会話：
{history or "（なし）"}

ユーザーの質問：{messages[-1]["content"]}
"""
    reply = _get_chat_llm().chat_text(system=CHAT_SYSTEM, user=user_text, max_tokens=2048)
    return {"reply": reply}


@app.get("/", response_class=HTMLResponse)
def index():
    html = (PROJECT_ROOT / "static" / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(html)
