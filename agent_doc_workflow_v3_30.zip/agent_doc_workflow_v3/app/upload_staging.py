"""
ブラウザからの一括アップロード（v3.30）。

フォルダ一括処理はこれまで「サーバーから見えるパス」しか受け付けなかった。
別の PC から画面を開いた利用者が自分の D:\\ を入れても、サーバーは
**サーバー自身の** D:\\ を探しに行くので、他人の資料は投入できなかった。

そこで、ブラウザでフォルダ（またはファイル群）を選ばせ、
いったん inbox/uploads/<upload_id>/ に**置き場**として受け取り、
揃ったところで通常のバッチとして投入する。流れは 3 段：

    init   … 置き場を作る（upload_id を払い出す）
    files  … 数件ずつ送る（何度でも。進捗表示と途中失敗からの再送のため）
    start  … 置き場の中身でバッチを作り、キューへ入れる

1 回の POST で数百件を送らないのは、
  - Starlette の multipart は既定で 1 リクエスト 1000 パートまで
  - 1 本の巨大リクエストは途中で切れたら全部やり直し
  - 進捗バーが出せない
の 3 点のため。

安全面の要点：
  - 相対パスはブラウザが送ってくる**信用できない文字列**。
    「..」・ドライブ名・絶対パス・Windows で使えない文字・予約名を落とし、
    最終的な保存先が置き場の内側にあることを resolve() で確かめる。
  - 拡張子・ロックファイル・隠しファイルの除外はサーバー側でもやる
    （画面側の事前除外は親切であって防御ではない）。
  - 件数・1 ファイルの大きさ・合計の大きさに上限を設ける。
  - 投入されないまま放置された置き場は一定時間後に掃除する。

照合に使う「元の相対パス」は短縮前のものを別に控えて run に渡す
（参照台帳はフォルダ名を手がかりにするため。保存先のパスは Windows の
長さ制限で中間フォルダを詰めることがある）。
"""
from __future__ import annotations

import json
import re
import shutil
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

_lock = threading.Lock()

UPLOAD_ID_RE = re.compile(r"^up_\d{8}_\d{6}_[0-9a-f]{8}$")
MANIFEST = "upload.json"
FILES_DIR = "files"

# Windows で使えない文字と制御文字
_BAD_CHARS = re.compile(r'[<>:"|?*\x00-\x1f]')
_DRIVE = re.compile(r"^[A-Za-z]:$")
_RESERVED = {"CON", "PRN", "AUX", "NUL",
             *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}

# 1 要素の最大文字数（日本語は UTF-8 で 3 バイト。Linux の 255 バイト制限を超えない）
_MAX_PART = 80
# 置き場の下に作る相対パスの最大文字数（Windows の 260 文字制限への備え）
_MAX_REL = 160


def uploads_root(inbox: str | Path) -> Path:
    return Path(inbox) / "uploads"


def upload_dir(inbox: str | Path, upload_id: str) -> Optional[Path]:
    if not UPLOAD_ID_RE.match(upload_id or ""):
        return None
    return uploads_root(inbox) / upload_id


# ----------------------------------------------------------------------
# パスの無害化
# ----------------------------------------------------------------------

def _clean_part(part: str, is_file: bool) -> str:
    s = _BAD_CHARS.sub("_", part).strip().rstrip(". ")
    if not s:
        s = "_"
    stem, dot, suf = s.rpartition(".") if is_file and "." in s else (s, "", "")
    if stem.upper() in _RESERVED or s.upper() in _RESERVED:
        s = "_" + s
        stem = "_" + stem
    if len(s) > _MAX_PART:
        if is_file and dot and len(suf) <= 10:
            s = stem[: _MAX_PART - len(suf) - 1] + "." + suf
        else:
            s = s[:_MAX_PART]
    return s


def split_rel(rel: str, fallback_name: str = "") -> Optional[List[str]]:
    """ブラウザが送ってきた相対パスを、安全な要素の列にする。

    「..」を含むものは**拒否**する（黙って落とすと別の場所へ書いてしまう
    可能性を残すため、None を返して呼び出し側で弾かせる）。
    空なら fallback_name（UploadFile.filename）を使う。
    """
    raw = (rel or "").replace("\\", "/")
    parts = [p for p in raw.split("/") if p not in ("", ".")]
    if not parts and fallback_name:
        parts = [p for p in fallback_name.replace("\\", "/").split("/") if p not in ("", ".")][-1:]
    if not parts:
        return None
    if any(p == ".." for p in parts):
        return None
    if _DRIVE.match(parts[0]):
        parts = parts[1:]
        if not parts:
            return None
    return parts


def ignore_reason(parts: List[str], suffixes: set) -> Optional[str]:
    """処理対象外の理由（対象なら None）。scan_folder と同じ規則に揃える。"""
    name = parts[-1]
    if any(p.startswith(".") for p in parts[:-1]):
        return "隠しフォルダ"
    if name.startswith("~$"):
        return "Office の一時ファイル"
    if name.startswith("."):
        return "隠しファイル"
    suf = Path(name).suffix.lower()
    if suf not in suffixes:
        return f"未対応の形式 {suf or '(拡張子なし)'}"
    return None


def storage_parts(parts: List[str]) -> List[str]:
    """保存先に使う要素列。長すぎる場合は**中間のフォルダ**から詰める
    （先頭＝選んだフォルダ名と、直近の親フォルダ・ファイル名は残す）。"""
    out = [_clean_part(p, i == len(parts) - 1) for i, p in enumerate(parts)]
    while len("/".join(out)) > _MAX_REL and len(out) > 3:
        out.pop(1)
    if len("/".join(out)) > _MAX_REL:
        out = out[-1:]
    return out


def resolve_inside(base: Path, parts: List[str]) -> Optional[Path]:
    dest = base.joinpath(*parts)
    try:
        dest.resolve().relative_to(base.resolve())
    except ValueError:
        return None
    return dest


# ----------------------------------------------------------------------
# 置き場（manifest）
# ----------------------------------------------------------------------

def _write(path: Path, data: Dict[str, Any]) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def load(inbox: str | Path, upload_id: str) -> Optional[Dict[str, Any]]:
    d = upload_dir(inbox, upload_id)
    if not d or not (d / MANIFEST).exists():
        return None
    try:
        return json.loads((d / MANIFEST).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def save(inbox: str | Path, manifest: Dict[str, Any]) -> None:
    d = upload_dir(inbox, manifest["upload_id"])
    with _lock:
        _write(d / MANIFEST, manifest)


def create(inbox: str | Path, client: str = "") -> Dict[str, Any]:
    upload_id = f"up_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
    d = uploads_root(inbox) / upload_id
    (d / FILES_DIR).mkdir(parents=True, exist_ok=True)
    manifest = {"upload_id": upload_id, "created": time.time(), "client": client,
                "committed": False, "batch_id": "", "total_bytes": 0,
                "files": [], "rejected": []}
    with _lock:
        _write(d / MANIFEST, manifest)
    return manifest


def discard(inbox: str | Path, upload_id: str) -> bool:
    d = upload_dir(inbox, upload_id)
    if not d or not d.exists():
        return False
    shutil.rmtree(d, ignore_errors=True)
    return True


def _has_files(d: Path) -> bool:
    return any(p.is_file() for p in (d / FILES_DIR).rglob("*")) if (d / FILES_DIR).exists() else False


def cleanup(inbox: str | Path, ttl_hours: float = 24) -> List[str]:
    """片付け：
      - 投入されずに ttl_hours 以上放置された置き場
      - 投入済みだが、run の削除で中身が 1 件も残っていない置き場
    """
    root = uploads_root(inbox)
    removed: List[str] = []
    if not root.exists():
        return removed
    now = time.time()
    for d in root.iterdir():
        if not d.is_dir() or not UPLOAD_ID_RE.match(d.name):
            continue
        m = load(inbox, d.name) or {}
        created = m.get("created") or d.stat().st_mtime
        if not m.get("committed"):
            if now - created > ttl_hours * 3600:
                shutil.rmtree(d, ignore_errors=True)
                removed.append(d.name)
        elif not _has_files(d):
            shutil.rmtree(d, ignore_errors=True)
            removed.append(d.name)
    return removed


def common_top(rels: List[str]) -> Tuple[str, List[str]]:
    """全ファイルが同じ先頭フォルダの下にあれば (そのフォルダ名, 残りの相対パス)。
    フォルダ選択なら先頭は選んだフォルダ名になる。揃わなければ ("", 元のまま)。"""
    split = [r.split("/") for r in rels]
    if split and all(len(s) > 1 for s in split) and len({s[0] for s in split}) == 1:
        return split[0][0], ["/".join(s[1:]) for s in split]
    return "", rels
