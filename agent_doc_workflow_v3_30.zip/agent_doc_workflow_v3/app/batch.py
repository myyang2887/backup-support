"""
フォルダ一括処理（v3.6 新增）。

これまでの投入口はブラウザのファイル選択／ドロップだけで、
「このフォルダの中身を全部やっておいて」ができなかった。数百件の存量資料を
消化する導線としては致命的なので、**パスを渡して配下を丸ごと処理する**入口を足す。

設計方針は既存部分と揃える：

- **ディスクが真源**：バッチの実体は `out/batches/<batch_id>/batch.json`。
  DB は使わない。サービスを再起動しても JSON を読み直せば復元できる。
- **原本には触らない**：inbox へコピーせず、フォルダ内のファイルを直接読む。
  したがって run を削除しても利用者の原本は消えない（削除は inbox 配下限定）。
- **run_id はディスクの run ディレクトリ名と一致させる**
  （`<stem>_<内容ハッシュ>`）。アップロード経路が抱えていた
  「API の run_id とディスクの run ディレクトリ名が別物」問題を、
  こちらでは最初から作らない。再起動後も履歴が二重に出ない。
- **履歴は分離**：単発投入の実行履歴とは別カードに出す（利用者の要望）。
  run 側には batch_id を持たせ、単発履歴からは除外する。
"""
from __future__ import annotations

import json
import shutil
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

_lock = threading.Lock()

# 一括処理の対象拡張子（webapp の ALLOWED_SUFFIXES と揃える）
#
# v3.27.6：.md / .txt は一時停止中。webapp は scan_folder に suffixes を
# 必ず明示で渡すのでここは既定値でしかないが、両者がずれていると
# CLI や将来の呼び出し側だけ挙動が違う、という追いにくい形で表面化する。
SUSPENDED_SUFFIXES = {".md", ".txt"}
DEFAULT_SUFFIXES = {".pdf", ".docx", ".pptx", ".xlsx", ".xlsm", ".xls",
                    ".md", ".txt", ".html"} - SUSPENDED_SUFFIXES

# 走査時に無視するフォルダ（自分の出力を食べに行かないための最低限の防御）
_SKIP_DIRS = {"out", "__pycache__", ".git", "node_modules", "versions",
              "processed", "runs", "batches"}


def batches_root(out_dir: str | Path) -> Path:
    return Path(out_dir) / "batches"


# ----------------------------------------------------------------------
# 走査
# ----------------------------------------------------------------------

def scan_folder(folder: str | Path, recursive: bool = True,
                suffixes: Optional[set] = None, max_files: int = 500,
                max_skipped_listed: int = 50) -> Dict[str, Any]:
    """対象ファイルを列挙するだけ（副作用なし）。UI の事前確認にも使う。

    v3.27.5：除外したファイルの**名前**も返す。件数だけ出しても
    「4 件除外」が .doc の取りこぼしなのか単なる画像なのか判らず、
    利用者が確認する手段が無かった。
    件数が多いフォルダで応答を膨らませないよう、名前は
    max_skipped_listed 件まで。拡張子ごとの内訳は全件を数える。
    """
    suffixes = suffixes or DEFAULT_SUFFIXES
    root = Path(folder).expanduser()
    if not root.exists():
        return {"ok": False, "error": f"パスが存在しません: {root}", "files": []}
    if not root.is_dir():
        return {"ok": False, "error": f"フォルダではありません: {root}", "files": []}

    files: List[Path] = []
    skipped_unsupported = 0
    skipped_files: List[Dict[str, str]] = []
    skipped_by_suffix: Dict[str, int] = {}
    it = root.rglob("*") if recursive else root.glob("*")
    for p in sorted(it):
        if p.is_dir():
            continue
        if any(part in _SKIP_DIRS or part.startswith(".") for part in p.relative_to(root).parts[:-1]):
            continue
        if p.name.startswith((".", "~$")):        # Office のロックファイル対策
            continue
        if p.suffix.lower() not in suffixes:
            skipped_unsupported += 1
            suf = p.suffix.lower() or "(拡張子なし)"
            skipped_by_suffix[suf] = skipped_by_suffix.get(suf, 0) + 1
            if len(skipped_files) < max_skipped_listed:
                skipped_files.append({"name": p.name, "rel": str(p.relative_to(root)),
                                      "suffix": suf})
            continue
        files.append(p)
        if len(files) >= max_files:
            break

    return {"ok": True, "folder": str(root), "recursive": recursive,
            "count": len(files), "skipped_unsupported": skipped_unsupported,
            "skipped_files": skipped_files,
            "skipped_listed_truncated": skipped_unsupported > len(skipped_files),
            "skipped_by_suffix": dict(sorted(skipped_by_suffix.items(),
                                             key=lambda kv: -kv[1])),
            # v3.27.6：対応拡張子は画面で案内するので**実際に使った集合**を返す。
            # 画面側に一覧を書き写すと、ここを変えたときに案内だけ古くなる。
            "supported_suffixes": sorted(suffixes),
            "truncated": len(files) >= max_files,
            "files": [{"name": f.name, "rel": str(f.relative_to(root)), "path": str(f)}
                      for f in files]}


def check_allowed(folder: str | Path, allowed_roots: List[str]) -> Optional[str]:
    """allowed_roots が設定されている場合のみ、その配下かを検査する。"""
    if not allowed_roots:
        return None
    target = Path(folder).expanduser().resolve()
    for root in allowed_roots:
        try:
            if str(target).startswith(str(Path(root).expanduser().resolve())):
                return None
        except OSError:
            continue
    return f"許可されていないパスです（config.yaml の batch.allowed_roots を確認）: {target}"


# ----------------------------------------------------------------------
# バッチの生成・読み書き
# ----------------------------------------------------------------------

def create_batch(out_dir: str | Path, folder: str, items: List[Dict[str, Any]],
                 template_id: str = "case", input_mode: str = "auto",
                 recursive: bool = True,
                 deep_read: Optional[bool] = None,
                 source: str = "folder",
                 extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    root = batches_root(out_dir)
    batch_id = f"batch_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    record = {
        "batch_id": batch_id,
        # v3.30：投入元。"folder" = サーバー上のパスを走査 / "upload" = 利用者の
        # パソコンからブラウザでアップロード。後者は原本が inbox/uploads 配下の
        # 写しなので、削除時に一緒に片付けてよい。
        "source": source,
        **(extra or {}),
        "folder": str(folder),
        "recursive": recursive,
        "template_id": template_id,
        "input_mode": input_mode,
        # v3.12：一括処理でも精読モードを指定できるようにした。
        # UI は以前から送っていたのに API 側が読み捨てていた（＝実質選べなかった）。
        # None は「config の既定に従う」。
        "deep_read": deep_read,
        # v3.12：バッチ単位の中止フラグ。個々の run を 1 件ずつ止めても
        # 次が自動で始まってしまい事実上止められなかったので、
        # 「このバッチはもう始めない」を 1 箇所で表現する。
        "cancelled": False,
        "created": time.time(),
        "items": items,
    }
    d = root / batch_id
    d.mkdir(parents=True, exist_ok=True)
    _write(d / "batch.json", record)
    return record


def _write(path: Path, data: Dict[str, Any]) -> None:
    with _lock:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)          # 途中で落ちても壊れた JSON を残さない


def load_batch(out_dir: str | Path, batch_id: str) -> Optional[Dict[str, Any]]:
    if ".." in batch_id or "/" in batch_id or "\\" in batch_id:
        return None
    p = batches_root(out_dir) / batch_id / "batch.json"
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def all_batches(out_dir: str | Path) -> List[Dict[str, Any]]:
    root = batches_root(out_dir)
    if not root.exists():
        return []
    out = []
    for d in sorted(root.iterdir(), reverse=True):
        p = d / "batch.json"
        if d.is_dir() and p.exists():
            try:
                out.append(json.loads(p.read_text(encoding="utf-8")))
            except Exception:  # noqa: BLE001 壊れた 1 件で一覧全体を壊さない
                continue
    return out


def set_item_state(out_dir: str | Path, batch_id: str, run_id: str, state: str) -> None:
    """run 完了時に呼ぶ。ディスク側にも状態を残すので再起動後も進捗が読める。"""
    record = load_batch(out_dir, batch_id)
    if not record:
        return
    changed = False
    for item in record.get("items", []):
        if item.get("run_id") == run_id and item.get("state") != state:
            item["state"] = state
            item["updated"] = time.time()
            changed = True
    if changed:
        _write(batches_root(out_dir) / batch_id / "batch.json", record)


def cancel_batch(out_dir: str | Path, batch_id: str) -> Dict[str, Any]:
    """バッチ全体を中止する。

    v3.12：これが無かったのが「一括処理を止められない」の正体。
    実行待ちの run はスレッドとして既に起動済みでセマフォ待ちをしているため、
    実行中の 1 件を止めると**空いた枠に次が入って走り出す**。1 件ずつ止めても
    追い付かないうえ、協調中止は進行中の LLM 応答を待つので毎回数秒固まる。

    ここでフラグを立てておけば、ワーカーは枠を取った直後にそれを見て
    **LLM を 1 回も呼ばずに** 即座に cancelled で終わる。待たされるのは
    「今まさに実行中の 1 件」だけになる。
    """
    record = load_batch(out_dir, batch_id)
    if not record:
        return {"ok": False, "error": "バッチが見つかりません"}
    record["cancelled"] = True
    record["cancelled_at"] = time.time()
    stopped = 0
    for item in record.get("items", []):
        if item.get("state") in ("queued", "running", None):
            item["state"] = "cancelled"
            item["updated"] = time.time()
            stopped += 1
    _write(batches_root(out_dir) / batch_id / "batch.json", record)
    return {"ok": True, "batch_id": batch_id, "stopped": stopped}


def is_cancelled(out_dir: str | Path, batch_id: str) -> bool:
    """ワーカーが実行直前に見る。ディスクが真源なので再起動後も効く。"""
    if not batch_id:
        return False
    record = load_batch(out_dir, batch_id)
    return bool(record and record.get("cancelled"))


def delete_batch(out_dir: str | Path, batch_id: str) -> bool:
    d = batches_root(out_dir) / batch_id
    root = batches_root(out_dir).resolve()
    if not d.exists() or not str(d.resolve()).startswith(str(root)):
        return False
    shutil.rmtree(d, ignore_errors=True)
    return True


def run_to_batch_map(out_dir: str | Path) -> Dict[str, str]:
    """起動時の復元用：run_id -> batch_id。単発履歴からバッチ分を外すのに使う。"""
    mapping: Dict[str, str] = {}
    for record in all_batches(out_dir):
        for item in record.get("items", []):
            rid = item.get("run_id")
            if rid:
                mapping[rid] = record["batch_id"]
    return mapping


def summarize(record: Dict[str, Any], live_states: Dict[str, str]) -> Dict[str, Any]:
    """一覧表示用の集計。live_states（メモリ上の run 状態）を優先する。"""
    items = record.get("items", [])
    states = [live_states.get(it.get("run_id", ""), it.get("state", "unknown")) for it in items]
    counts: Dict[str, int] = {}
    for s in states:
        counts[s] = counts.get(s, 0) + 1
    total = len(items)
    finished = sum(counts.get(s, 0) for s in ("done", "failed", "cancelled"))
    cancelled = counts.get("cancelled", 0)
    return {
        "batch_id": record["batch_id"],
        "folder": record.get("folder", ""),
        "source": record.get("source", "folder"),
        "template_id": record.get("template_id", "case"),
        "input_mode": record.get("input_mode", "auto"),
        "deep_read": record.get("deep_read"),
        "cancelled": bool(record.get("cancelled")),
        "created": record.get("created", 0),
        "total": total,
        "done": counts.get("done", 0),
        "failed": counts.get("failed", 0),
        "cancelled_count": cancelled,
        "finished": finished,
        "complete": total > 0 and finished >= total,
        "counts": counts,
    }
