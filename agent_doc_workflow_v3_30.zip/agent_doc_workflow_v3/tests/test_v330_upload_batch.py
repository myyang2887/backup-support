"""v3.30：利用者のパソコンからブラウザでアップロードして一括処理する。"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from app import upload_staging as U


# ----------------------------------------------------------------------
# パスの無害化
# ----------------------------------------------------------------------

@pytest.mark.parametrize("rel", ["../evil.pdf", "a/../../evil.pdf", "..\\x\\y.pdf",
                                 "a/b/../c.pdf"])
def test_split_rel_rejects_parent_refs(rel):
    assert U.split_rel(rel) is None


def test_split_rel_normalizes_separators_and_drive():
    assert U.split_rel("C:\\資料\\2026\\報告.pdf") == ["資料", "2026", "報告.pdf"]
    assert U.split_rel("/abs/path/x.pdf") == ["abs", "path", "x.pdf"]
    assert U.split_rel("./a//b/./c.pdf") == ["a", "b", "c.pdf"]
    assert U.split_rel("", "only.pdf") == ["only.pdf"]
    assert U.split_rel("", "") is None


def test_storage_parts_cleans_windows_names_and_shortens():
    parts = U.storage_parts(["案件:A", "CON", "x?.pdf"])
    assert parts == ["案件_A", "_CON", "x_.pdf"]
    long = ["top"] + [f"中間フォルダ{i:02d}" * 3 for i in range(10)] + ["親", "報告書.pdf"]
    out = U.storage_parts(long)
    assert len("/".join(out)) <= 160
    assert out[0] == "top" and out[-2:] == ["親", "報告書.pdf"]   # 先頭と直近は残す


def test_ignore_reason_matches_scan_rules():
    suf = {".pdf", ".xlsx"}
    assert U.ignore_reason(["a", "~$x.xlsx"], suf)
    assert U.ignore_reason(["a", ".DS_Store"], suf)
    assert U.ignore_reason([".git", "x.pdf"], suf)
    assert "未対応" in U.ignore_reason(["a", "memo.png"], suf)
    assert U.ignore_reason(["a", "X.PDF"], suf) is None


def test_common_top():
    assert U.common_top(["F/a.pdf", "F/s/b.pdf"]) == ("F", ["a.pdf", "s/b.pdf"])
    assert U.common_top(["a.pdf", "b.pdf"]) == ("", ["a.pdf", "b.pdf"])
    assert U.common_top(["F/a.pdf", "G/b.pdf"])[0] == ""


def test_cleanup_removes_stale_and_emptied(tmp_path):
    stale = U.create(tmp_path)
    m = U.load(tmp_path, stale["upload_id"])
    m["created"] -= 48 * 3600
    U.save(tmp_path, m)
    fresh = U.create(tmp_path)
    done = U.create(tmp_path)
    m = U.load(tmp_path, done["upload_id"]); m["committed"] = True; U.save(tmp_path, m)
    removed = U.cleanup(tmp_path, ttl_hours=24)
    assert stale["upload_id"] in removed and done["upload_id"] in removed
    assert fresh["upload_id"] not in removed
    assert (U.uploads_root(tmp_path) / fresh["upload_id"]).exists()


def test_upload_dir_rejects_bad_ids(tmp_path):
    assert U.upload_dir(tmp_path, "../x") is None
    assert U.upload_dir(tmp_path, "up_20260101_000000_zzzzzzzz") is None


# ----------------------------------------------------------------------
# API
# ----------------------------------------------------------------------

@pytest.fixture()
def client(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient

    import app.webapp as W
    monkeypatch.setattr(W.config.paths, "out_dir", str(tmp_path / "out"))
    monkeypatch.setattr(W.config.paths, "inbox_dir", str(tmp_path / "inbox"))
    monkeypatch.setattr(W.config.llm, "mock", True)
    started = []

    def fake_worker(*args, **kwargs):     # LLM は回さない。何で起動されたかだけ記録
        started.append(args)

    monkeypatch.setattr(W, "_worker", fake_worker)
    c = TestClient(W.app)
    c.started = started
    c.W = W
    c.tmp = tmp_path
    yield c
    for a in started:                      # 他のテストに run を持ち越さない
        W._runs.pop(a[0], None)


def _send(client, uid, files):
    multipart = [("files", (Path(rel).name, data, "application/octet-stream"))
                 for rel, data in files]
    form = {"relative_paths": [rel for rel, _ in files]}
    return client.post(f"/api/uploads/{uid}/files", files=multipart, data=form)


def test_ui_exposes_upload_limits(client):
    up = client.get("/api/ui").json()["batch_upload"]
    assert up["enabled"] is True and ".pdf" in up["suffixes"]
    assert up["max_files"] > 0 and up["max_file_mb"] > 0


def test_upload_flow_creates_upload_batch(client):
    uid = client.post("/api/uploads").json()["upload_id"]
    r1 = _send(client, uid, [("案件A/報告.pdf", b"%PDF-1 a"),
                             ("案件A/sub/速報2.xlsx", b"PK xlsx"),
                             ("案件A/~$速報2.xlsx", b"lock"),
                             ("案件A/photo.png", b"png")]).json()
    assert sorted(r1["accepted"]) == sorted(["案件A/報告.pdf", "案件A/sub/速報2.xlsx"])
    assert {x["rel"] for x in r1["rejected"]} == {"案件A/~$速報2.xlsx", "案件A/photo.png"}
    r2 = _send(client, uid, [("案件A/sub/別.pdf", b"%PDF-1 b")]).json()
    assert r2["count"] == 3

    body = client.post(f"/api/uploads/{uid}/start",
                       json={"template_id": "case", "input_mode": "hybrid",
                             "deep_read": True}).json()
    assert body["total"] == 3 and body["source"] == "upload"
    assert body["folder"] == "案件A" and body["input_mode"] == "hybrid"
    assert len(client.started) == 3

    # 台帳照合には「選んだフォルダ名から始まる元の相対パス」を渡す
    src_rels = sorted(a[8] for a in client.started)
    assert src_rels == ["案件A/sub/別.pdf", "案件A/sub/速報2.xlsx", "案件A/報告.pdf"]
    # 実体は inbox 配下（run 削除で一緒に消える範囲）
    inbox = (client.tmp / "inbox").resolve()
    for a in client.started:
        assert Path(a[1]).resolve().is_relative_to(inbox)
        assert a[5] == body["batch_id"] and a[4] is True

    detail = client.get(f"/api/batches/{body['batch_id']}").json()
    assert sorted(it["rel"] for it in detail["items"]) == ["sub/別.pdf", "sub/速報2.xlsx", "報告.pdf"]

    # 二重投入はできない
    assert client.post(f"/api/uploads/{uid}/start", json={}).status_code == 409
    assert _send(client, uid, [("案件A/x.pdf", b"%PDF")]).status_code == 409


def test_upload_rejects_traversal_and_stays_inside(client):
    uid = client.post("/api/uploads").json()["upload_id"]
    r = _send(client, uid, [("../../evil.pdf", b"%PDF"), ("ok/fine.pdf", b"%PDF")]).json()
    assert r["accepted"] == ["ok/fine.pdf"]
    assert r["rejected"][0]["reason"] == "不正なパス"
    assert not (client.tmp / "evil.pdf").exists()
    assert not (client.tmp / "inbox" / "evil.pdf").exists()


def test_upload_limits_file_size_and_count(client, monkeypatch):
    W = client.W
    monkeypatch.setattr(W.config.batch, "max_file_mb", 1)
    monkeypatch.setattr(W.config.batch, "max_files", 2)
    uid = client.post("/api/uploads").json()["upload_id"]
    big = b"0" * (1024 * 1024 + 10)
    r = _send(client, uid, [("F/big.pdf", big), ("F/a.pdf", b"a"),
                            ("F/b.pdf", b"b"), ("F/c.pdf", b"c")]).json()
    assert r["accepted"] == ["F/a.pdf", "F/b.pdf"]
    reasons = {x["rel"]: x["reason"] for x in r["rejected"]}
    assert "1 ファイルの上限" in reasons["F/big.pdf"]
    assert "件数の上限" in reasons["F/c.pdf"]
    # 途中まで書いた一時ファイルを残さない
    left = list((client.tmp / "inbox" / "uploads" / uid).rglob("*.part"))
    assert left == []


def test_upload_total_limit(client, monkeypatch):
    monkeypatch.setattr(client.W.config.batch, "max_upload_mb", 1)
    uid = client.post("/api/uploads").json()["upload_id"]
    half = b"0" * (600 * 1024)
    r = _send(client, uid, [("F/a.pdf", half), ("F/b.pdf", half)]).json()
    assert r["accepted"] == ["F/a.pdf"]
    assert "合計の上限" in r["rejected"][0]["reason"]
    # 同じパスの再送は上書き扱い（合計を二重に数えない）
    r = _send(client, uid, [("F/a.pdf", half)]).json()
    assert r["accepted"] == ["F/a.pdf"] and r["total_bytes"] == len(half)


def test_upload_multiple_files_without_folder(client):
    uid = client.post("/api/uploads").json()["upload_id"]
    _send(client, uid, [("a.pdf", b"%PDF a"), ("b.pdf", b"%PDF b")])
    body = client.post(f"/api/uploads/{uid}/start", json={}).json()
    assert body["folder"].startswith("アップロード") and body["total"] == 2


def test_upload_discard_and_disabled(client, monkeypatch):
    uid = client.post("/api/uploads").json()["upload_id"]
    _send(client, uid, [("F/a.pdf", b"%PDF")])
    assert client.delete(f"/api/uploads/{uid}").json()["ok"] is True
    assert not (client.tmp / "inbox" / "uploads" / uid).exists()
    assert client.post(f"/api/uploads/{uid}/start", json={}).status_code == 404

    monkeypatch.setattr(client.W.config.batch, "upload_enabled", False)
    assert client.post("/api/uploads").status_code == 403
    assert client.get("/api/ui").json()["batch_upload"]["enabled"] is False


def test_upload_start_without_files_is_400(client):
    uid = client.post("/api/uploads").json()["upload_id"]
    assert client.post(f"/api/uploads/{uid}/start", json={}).status_code == 400


def test_batch_delete_with_runs_removes_staging(client):
    uid = client.post("/api/uploads").json()["upload_id"]
    _send(client, uid, [("F/a.pdf", b"%PDF a")])
    bid = client.post(f"/api/uploads/{uid}/start", json={}).json()["batch_id"]
    W = client.W
    for a in client.started:                      # 実行が終わったことにする
        W._runs[a[0]]["state"] = "done"
    r = client.delete(f"/api/batches/{bid}?with_runs=true")
    assert r.status_code == 200
    assert not (client.tmp / "inbox" / "uploads" / uid).exists()


def test_path_batch_still_works_and_is_marked_folder(client, tmp_path):
    d = tmp_path / "srv"
    (d / "s").mkdir(parents=True)
    (d / "a.pdf").write_bytes(b"%PDF a")
    (d / "s" / "b.pdf").write_bytes(b"%PDF b")
    body = client.post("/api/batches", json={"folder": str(d)}).json()
    assert body["total"] == 2 and body["source"] == "folder"
    assert sorted(a[8] for a in client.started) == ["a.pdf", str(Path("s") / "b.pdf")]


def test_frontend_has_upload_ui():
    html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
    for needle in ("batch-up-dir", "/api/uploads", "batchUploadStart", "batch-src"):
        assert needle in html
