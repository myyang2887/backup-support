"""v3.30：投入口の一本化。

- ファイル・フォルダ・複数フォルダは、どの PC からでもブラウザでアップロードして処理
  （複数なら inbox/uploads に一時保存してから一括処理）
- 「サーバー上のフォルダを指定」は batch.server_path で出す範囲を決める
  （既定 local_only：サーバー PC 自身から開いたときだけ）
"""
from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from app import upload_staging as U
from app.webapp import _is_server_side as _REAL_IS_SERVER_SIDE


# ----------------------------------------------------------------------
# サーバー PC 自身からのアクセスか
# ----------------------------------------------------------------------

def _req(peer, local="192.168.1.10"):
    return SimpleNamespace(client=SimpleNamespace(host=peer) if peer is not None else None,
                           scope={"server": (local, 8000)})


@pytest.mark.parametrize("peer,local,expected", [
    ("127.0.0.1", "127.0.0.1", True),          # http://localhost:8000
    ("::1", "::1", True),
    ("::ffff:127.0.0.1", "0.0.0.0", True),
    ("192.168.1.10", "192.168.1.10", True),    # サーバー PC が自分の LAN の IP で開いた
    ("192.168.1.23", "192.168.1.10", False),   # 別の PC
    ("10.0.0.5", "192.168.1.10", False),
    ("testclient", "testserver", False),       # IP でない名前は外部扱い
    ("", "192.168.1.10", False),
    (None, "192.168.1.10", False),
])
def test_is_server_side(peer, local, expected):
    # conftest はテスト実行中だけ差し替えるので、収集時に取った本物を使う
    assert _REAL_IS_SERVER_SIDE(_req(peer, local)) is expected


# ----------------------------------------------------------------------
# パスの無害化
# ----------------------------------------------------------------------

@pytest.mark.parametrize("rel", ["../evil.pdf", "a/../../evil.pdf", "..\\x\\y.pdf",
                                 "a/b/../c.pdf"])
def test_split_rel_rejects_parent_refs(rel):
    assert U.split_rel(rel) is None


def test_split_rel_normalizes_separators_and_drive():
    assert U.split_rel("C:\\資料\\2026\\報告.pdf") == ["資料", "2026", "報告.pdf"]
    assert U.split_rel("/abs/path/x.pdf") == ["abs", "path", "x.pdf"]
    assert U.split_rel("./a//b/./c.pdf") == ["a", "b", "c.pdf"]
    assert U.split_rel("", "only.pdf") == ["only.pdf"]
    assert U.split_rel("", "") is None


def test_storage_parts_cleans_windows_names_and_shortens():
    assert U.storage_parts(["案件:A", "CON", "x?.pdf"]) == ["案件_A", "_CON", "x_.pdf"]
    long = ["top"] + [f"中間フォルダ{i:02d}" * 3 for i in range(10)] + ["親", "報告書.pdf"]
    out = U.storage_parts(long)
    assert len("/".join(out)) <= 160
    assert out[0] == "top" and out[-2:] == ["親", "報告書.pdf"]   # 先頭と直近は残す


def test_ignore_reason_matches_scan_rules():
    suf = {".pdf", ".xlsx"}
    assert U.ignore_reason(["a", "~$x.xlsx"], suf)
    assert U.ignore_reason(["a", ".DS_Store"], suf)
    assert U.ignore_reason([".git", "x.pdf"], suf)
    assert "未対応" in U.ignore_reason(["a", "memo.png"], suf)
    assert U.ignore_reason(["a", "X.PDF"], suf) is None


def test_common_top():
    assert U.common_top(["F/a.pdf", "F/s/b.pdf"]) == ("F", ["a.pdf", "s/b.pdf"])
    assert U.common_top(["a.pdf", "b.pdf"]) == ("", ["a.pdf", "b.pdf"])
    assert U.common_top(["F/a.pdf", "G/b.pdf"])[0] == ""


def test_cleanup_removes_stale_and_emptied(tmp_path):
    stale = U.create(tmp_path)
    m = U.load(tmp_path, stale["upload_id"]); m["created"] -= 48 * 3600; U.save(tmp_path, m)
    fresh = U.create(tmp_path)
    done = U.create(tmp_path)
    m = U.load(tmp_path, done["upload_id"]); m["committed"] = True; U.save(tmp_path, m)
    removed = U.cleanup(tmp_path, ttl_hours=24)
    assert stale["upload_id"] in removed and done["upload_id"] in removed
    assert fresh["upload_id"] not in removed


def test_upload_dir_rejects_bad_ids(tmp_path):
    assert U.upload_dir(tmp_path, "../x") is None
    assert U.upload_dir(tmp_path, "up_20260101_000000_zzzzzzzz") is None


# ----------------------------------------------------------------------
# API
# ----------------------------------------------------------------------

@pytest.fixture()
def client(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient

    import app.webapp as W
    monkeypatch.setattr(W.config.paths, "out_dir", str(tmp_path / "out"))
    monkeypatch.setattr(W.config.paths, "inbox_dir", str(tmp_path / "inbox"))
    # ジョブ表（_job_set）は台帳 DB に書く。ここを逃がさないと、テストのたびに
    # プロジェクト本体の out/ledger.sqlite3 に偽の run が溜まり、画面の履歴に出てくる
    monkeypatch.setattr(W.config.ledger, "db_path", str(tmp_path / "out" / "ledger.sqlite3"))
    monkeypatch.setattr(W.config.llm, "mock", True)
    started = []
    monkeypatch.setattr(W, "_worker", lambda *a, **k: started.append(a))  # LLM は回さない
    c = TestClient(W.app)
    c.started, c.W, c.tmp = started, W, tmp_path
    yield c
    for a in started:
        W._runs.pop(a[0], None)


@pytest.fixture()
def remote(client, monkeypatch):
    """別の PC から開いた状態。"""
    monkeypatch.setattr(client.W, "_is_server_side", lambda request: False)
    return client


def _send(client, uid, files):
    multipart = [("files", (Path(rel).name, data, "application/octet-stream"))
                 for rel, data in files]
    return client.post(f"/api/uploads/{uid}/files", files=multipart,
                       data={"relative_paths": [rel for rel, _ in files]})


def _folder(tmp_path):
    d = tmp_path / "srv"
    (d / "s").mkdir(parents=True)
    (d / "a.pdf").write_bytes(b"%PDF a")
    (d / "s" / "b.pdf").write_bytes(b"%PDF b")
    return d


def test_ui_server_side_can_use_server_path(client):
    ui = client.get("/api/ui").json()
    assert ui["server_path"] is True
    assert ui["batch_upload"]["enabled"] is True and ".pdf" in ui["batch_upload"]["suffixes"]


def test_remote_cannot_use_server_path_but_can_upload(remote, tmp_path):
    ui = remote.get("/api/ui").json()
    assert ui["server_path"] is False and ui["batch_upload"]["enabled"] is True
    d = _folder(tmp_path)
    # 画面で隠すだけでなく、API を直接叩いてもサーバーのディスクは読めない
    assert remote.post("/api/batches/scan", json={"folder": str(d)}).status_code == 403
    assert remote.post("/api/batches", json={"folder": str(d)}).status_code == 403
    assert remote.started == []
    assert remote.post("/api/uploads").status_code == 200


def test_server_path_all_and_off(remote, client, tmp_path, monkeypatch):
    d = str(_folder(tmp_path))
    monkeypatch.setattr(remote.W.config.batch, "server_path", "all")
    assert remote.get("/api/ui").json()["server_path"] is True
    assert remote.post("/api/batches/scan", json={"folder": d}).status_code == 200
    monkeypatch.setattr(remote.W.config.batch, "server_path", "off")
    monkeypatch.setattr(remote.W, "_is_server_side", lambda request: True)   # 本機でも出さない
    assert remote.get("/api/ui").json()["server_path"] is False
    assert remote.post("/api/batches/scan", json={"folder": d}).status_code == 403


def test_batch_disabled_turns_everything_off(remote, monkeypatch):
    monkeypatch.setattr(remote.W.config.batch, "enabled", False)
    ui = remote.get("/api/ui").json()
    assert ui["server_path"] is False and ui["batch_upload"]["enabled"] is False
    assert remote.post("/api/uploads").status_code == 403


def test_server_side_can_also_upload(client):
    """サーバー PC 自身でも、ブラウザで選んだフォルダをアップロードできる。"""
    uid = client.post("/api/uploads").json()["upload_id"]
    _send(client, uid, [("F/a.pdf", b"%PDF a")])
    assert client.post(f"/api/uploads/{uid}/start", json={}).json()["source"] == "upload"


def test_multiple_folders_in_one_batch(remote):
    """複数フォルダを 1 回で：先頭フォルダが揃わないので画面からの名前を使い、
    各ファイルの表示パスには元のフォルダ名が残る。"""
    uid = remote.post("/api/uploads").json()["upload_id"]
    _send(remote, uid, [("案件A/報告.pdf", b"%PDF a"), ("案件A/sub/表.xlsx", b"PK a"),
                        ("案件B/まとめ.pptx", b"PK b"), ("単体.pdf", b"%PDF c")])
    body = remote.post(f"/api/uploads/{uid}/start", json={"label": "案件A ほか 2 件"}).json()
    assert body["folder"] == "案件A ほか 2 件" and body["total"] == 4
    detail = remote.get(f"/api/batches/{body['batch_id']}").json()
    assert sorted(it["rel"] for it in detail["items"]) == sorted(
        ["案件A/報告.pdf", "案件A/sub/表.xlsx", "案件B/まとめ.pptx", "単体.pdf"])
    # 台帳照合にはフォルダ名込みの相対パスが渡る
    assert "案件B/まとめ.pptx" in {a[8] for a in remote.started}


def test_server_side_path_batch_unchanged(client, tmp_path):
    body = client.post("/api/batches", json={"folder": str(_folder(tmp_path))}).json()
    assert body["total"] == 2 and body["source"] == "folder"
    assert sorted(a[8] for a in client.started) == ["a.pdf", str(Path("s") / "b.pdf")]


def test_upload_flow_creates_upload_batch(remote):
    uid = remote.post("/api/uploads").json()["upload_id"]
    r1 = _send(remote, uid, [("案件A/報告.pdf", b"%PDF-1 a"),
                             ("案件A/sub/速報2.xlsx", b"PK xlsx"),
                             ("案件A/~$速報2.xlsx", b"lock"),
                             ("案件A/photo.png", b"png")]).json()
    assert sorted(r1["accepted"]) == sorted(["案件A/報告.pdf", "案件A/sub/速報2.xlsx"])
    assert {x["rel"] for x in r1["rejected"]} == {"案件A/~$速報2.xlsx", "案件A/photo.png"}
    assert _send(remote, uid, [("案件A/sub/別.pdf", b"%PDF-1 b")]).json()["count"] == 3

    body = remote.post(f"/api/uploads/{uid}/start",
                       json={"template_id": "case", "input_mode": "hybrid",
                             "deep_read": True}).json()
    assert body["total"] == 3 and body["source"] == "upload"
    assert body["folder"] == "案件A" and body["input_mode"] == "hybrid"
    assert len(remote.started) == 3
    # 台帳照合には「選んだフォルダ名から始まる元の相対パス」を渡す
    assert sorted(a[8] for a in remote.started) == sorted(
        ["案件A/sub/別.pdf", "案件A/sub/速報2.xlsx", "案件A/報告.pdf"])
    inbox = (remote.tmp / "inbox").resolve()
    for a in remote.started:          # 実体は inbox 配下（run 削除で一緒に消える範囲）
        assert Path(a[1]).resolve().is_relative_to(inbox)
        assert a[5] == body["batch_id"] and a[4] is True
    detail = remote.get(f"/api/batches/{body['batch_id']}").json()
    assert sorted(it["rel"] for it in detail["items"]) == sorted(["sub/別.pdf", "sub/速報2.xlsx", "報告.pdf"])
    # 二重投入はできない
    assert remote.post(f"/api/uploads/{uid}/start", json={}).status_code == 409
    assert _send(remote, uid, [("案件A/x.pdf", b"%PDF")]).status_code == 409


def test_upload_rejects_traversal(remote):
    uid = remote.post("/api/uploads").json()["upload_id"]
    r = _send(remote, uid, [("../../evil.pdf", b"%PDF"), ("ok/fine.pdf", b"%PDF")]).json()
    assert r["accepted"] == ["ok/fine.pdf"]
    assert r["rejected"][0]["reason"] == "不正なパス"
    assert not (remote.tmp / "evil.pdf").exists()
    assert not (remote.tmp / "inbox" / "evil.pdf").exists()


def test_upload_limits_file_size_and_count(remote, monkeypatch):
    monkeypatch.setattr(remote.W.config.batch, "max_file_mb", 1)
    monkeypatch.setattr(remote.W.config.batch, "max_files", 2)
    uid = remote.post("/api/uploads").json()["upload_id"]
    r = _send(remote, uid, [("F/big.pdf", b"0" * (1024 * 1024 + 10)), ("F/a.pdf", b"a"),
                            ("F/b.pdf", b"b"), ("F/c.pdf", b"c")]).json()
    assert r["accepted"] == ["F/a.pdf", "F/b.pdf"]
    reasons = {x["rel"]: x["reason"] for x in r["rejected"]}
    assert "1 ファイルの上限" in reasons["F/big.pdf"]
    assert "件数の上限" in reasons["F/c.pdf"]
    assert list((remote.tmp / "inbox" / "uploads" / uid).rglob("*.part")) == []


def test_upload_total_limit_and_overwrite(remote, monkeypatch):
    monkeypatch.setattr(remote.W.config.batch, "max_upload_mb", 1)
    uid = remote.post("/api/uploads").json()["upload_id"]
    half = b"0" * (600 * 1024)
    r = _send(remote, uid, [("F/a.pdf", half), ("F/b.pdf", half)]).json()
    assert r["accepted"] == ["F/a.pdf"] and "合計の上限" in r["rejected"][0]["reason"]
    r = _send(remote, uid, [("F/a.pdf", half)]).json()      # 再送は上書き（二重に数えない）
    assert r["accepted"] == ["F/a.pdf"] and r["total_bytes"] == len(half)


def test_upload_discard(remote):
    uid = remote.post("/api/uploads").json()["upload_id"]
    _send(remote, uid, [("F/a.pdf", b"%PDF")])
    assert remote.delete(f"/api/uploads/{uid}").json()["ok"] is True
    assert not (remote.tmp / "inbox" / "uploads" / uid).exists()
    assert remote.post(f"/api/uploads/{uid}/start", json={}).status_code == 404


def test_upload_start_without_files_is_400(remote):
    uid = remote.post("/api/uploads").json()["upload_id"]
    assert remote.post(f"/api/uploads/{uid}/start", json={}).status_code == 400


def test_batch_delete_with_runs_removes_staging(remote):
    uid = remote.post("/api/uploads").json()["upload_id"]
    _send(remote, uid, [("F/a.pdf", b"%PDF a")])
    bid = remote.post(f"/api/uploads/{uid}/start", json={}).json()["batch_id"]
    for a in remote.started:
        remote.W._runs[a[0]]["state"] = "done"
    assert remote.delete(f"/api/batches/{bid}?with_runs=true").status_code == 200
    assert not (remote.tmp / "inbox" / "uploads" / uid).exists()


def test_frontend_single_intake_card():
    html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
    # 一括処理カードは無くなり、投入カードに集約
    assert 'data-feature="batch_card"' not in html
    assert 'id="batch-path"' not in html and "batchScan" not in html
    for needle in ('id="pick-tray"', 'id="pick-bar"', 'id="srv-link"', "/api/uploads",
                   "/api/batches/scan", "server_path", "addPicked", "refreshHistory"):
        assert needle in html
    # フォルダ選択は何度でも（押すたびに足す）：選択後に input をリセットしている
    assert 'dirInput.value = ""' in html
    # display を持つクラスでも hidden が効くこと（.srv-link が別 PC に見えていた）
    assert "[hidden] { display: none !important; }" in html
