"""v3.30：対応期間に具体的な日付（依頼日〜完了日）も書かせる。"""
from __future__ import annotations

import re
from pathlib import Path

from app.nodes import _period_placeholder_leak

ROOT = Path(__file__).resolve().parents[1]


def _summary_system() -> str:
    src = (ROOT / "app" / "nodes.py").read_text(encoding="utf-8")
    i = src.index("7. **period と effects の書き分け**")
    return src[i:src.index("8. `action_results.effects`", i)]


def test_period_rule_asks_for_dates_and_days():
    rule = _summary_system()
    assert "〈依頼日〉〜〈完了日〉（依頼から完了まで 〈N〉 日）" in rule
    assert "日付の正規化" in rule          # 台帳の正規化済み日付を使わせる
    assert "計算し直さない" in rule        # 日数はコードの確定値を使わせる
    assert "曖昧" in rule                  # 曖昧な日付は推測で補わない


def test_period_examples_use_placeholders_not_real_numbers():
    """見本に実在しそうな数字を置くと弱いモデルがそのまま写す（v3.27.7 で実際に起きた）。"""
    rule = _summary_system()
    assert not re.search(r"\d+\s*日", rule), "見本の日数は〈N〉で伏せること"
    assert not re.search(r"\d{4}[-/年]\d", rule), "見本の日付は〈依頼日〉で伏せること"


def test_placeholder_leak_detected_in_period():
    leak = {"action_results": {"period": "〈依頼日〉〜2026/04/28（依頼から完了まで 27 日）"}}
    assert _period_placeholder_leak(leak)
    ok = {"action_results": {"period": "2026/04/01〜2026/04/28（依頼から完了まで 27 日）"}}
    assert _period_placeholder_leak(ok) is None
    assert _period_placeholder_leak({}) is None
    assert _period_placeholder_leak({"action_results": "壊れた"}) is None


def test_case_template_instruction_mentions_dates():
    y = (ROOT / "templates" / "case_summary_v1.yaml").read_text(encoding="utf-8")
    assert "具体的な日付" in y
