"""CLI 入口（批处理/调试用）。Web 交互请用: uvicorn app.webapp:app --port 8000"""
import sys
from pathlib import Path

from app.config import load_config
from app.graph import run_workflow


def main():
    if len(sys.argv) < 2:
        print("用法: python run_cli.py <文档路径> [config.yaml 路径]")
        sys.exit(1)

    input_path = str(Path(sys.argv[1]).resolve())
    config = load_config(sys.argv[2] if len(sys.argv) > 2 else None)

    final = run_workflow(input_path, config)

    print("\n处理完成。")
    print("输出 JSON:    ", final.get("output_json"))
    print("输出 Markdown:", final.get("output_markdown"))
    print("质量检查:     ", final.get("validation"))
    errors = final.get("errors", [])
    if errors:
        print(f"\n非致命错误 {len(errors)} 条（详见 run_dir/status.json）:")
        for e in errors:
            print(f"  [{e['node']}] {e['message']}")


if __name__ == "__main__":
    main()
