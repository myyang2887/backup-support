# 自作テンプレート追加ガイド（模板自学教程）

新模板 = `templates/registry/<你的模板id>/` 下的两个文件，**零 Python 代码**。

## 第一步：template.yaml

```yaml
id: my_template            # 文件夹名一致，英数下划线
name: 会議議事録            # UI 下拉里显示的名字
description: 会議の決定事項とアクションを構造化
# Agent 1 提取证据时使用的类别表（自由定义，建议 5-10 个）
evidence_categories: [attendee, decision, action_item, deadline, topic, other]
# 这些类别一条证据都没有时，gap_fill 会回文档重找
key_categories: [decision, action_item]
# 台账"案件名"列取哪个字段
title_field: meeting_title
# 给 Agent 1 的补充提示（可选）
extraction_hint: |
  決定事項と担当者付きアクションを重点的に抽出する。
# 给 Agent 3 的模板专属指示（可选）
summary_instructions: |
  決定事項→アクション→期限の順で整理。担当者名は原文どおり。
# 字段定义：type 只有三种
fields:
  meeting_title: {type: str,  label: "会議名"}
  decisions:     {type: list, label: "決定事項"}
  action_items:                       # records = 结构化记录列表
    type: records
    label: "アクション"
    item_fields: {owner: str, task: str, deadline: str}
# RAG 导出的章节分组（可选；未列字段自动归入 general）
rag_sections:
  overview: [meeting_title, decisions]
```

三种字段类型：
- `str` —— 单值，缺省自动填「資料内で確認できず」
- `list` —— 字符串列表，缺省 [「資料内で確認できず」]
- `records` —— 结构化记录列表（如 bulk_requests 的依頼一览），
  `item_fields` 里每项是 `名字: str` 或 `名字: list`

## 第二步：output.md.j2

Jinja2 模板，变量名 = fields 里的字段名：

```jinja
# {{ meeting_title }}

## 決定事項
{% for item in decisions %}
- {{ item }}
{% endfor %}

## アクション
{% for a in action_items %}
- {{ a.owner }}: {{ a.task }}（期限 {{ a.deadline }}）
{% endfor %}
```

## 第三步：重启服务，完成

启动时系统自动做两件事：
1. YAML 结构校验（写错 type、缺文件 → 启动即报错并指出位置）
2. j2 变量校验（模板引用了 fields 里不存在的字段 → 拒绝启动）

之后上传界面的下拉里就会出现你的模板。校验/JSON Schema/skeleton/
RAG 导出/台账标题/脱敏 全部自动跟随字段定义，无需改任何其他文件。

## 常见问题

- **改了 yaml 不生效** → 需重启服务（注册表启动时加载一次）
- **想看系统怎么用你的定义** → 跑一次后看 run 目录里的
  llm_metrics.jsonl 与 events.jsonl
- **Excel 多案件类资料** → 参考 bulk_requests：用 records 字段 +
  extraction_hint 里明确"每行一条 request_row 证据、不许合并"
