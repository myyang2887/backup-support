"""
两级输出：社内完整版 / 社外脱敏版（v3.3）。

生产级设计原则：
1. **规则层是权威**：NG 词典（客户名/内部代号/自定义词 + 金额等正则）做确定性
   替换。同一客户在整份文档中映射到同一别名（A社/B社…），保持可读性。
2. **LLM 改写层是辅助且可回退**：规则层漏掉的识别性信息（未登录的公司名等）
   交给 LLM 泛化改写；改写结果必须通过 (a) 契约校验 (b) NG 词复扫——
   任何原词重新出现（LLM 幻觉/复述）立即**回退到纯规则版**并在报告中记录。
   脱敏宁可保守，绝不因 LLM 的不确定性泄漏。
3. **全程留痕**：redaction_report.json 记录替换明细、别名映射、LLM 层是否
   采用/回退原因，可审计。
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml
from pydantic import BaseModel, Field, ValidationError

from .contract import CaseSummary

_ALIAS_SEQ = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


class NGCategory(BaseModel):
    """一类 NG 词。replacement_template 含 {alias} 时按出现顺序分配 A/B/C…；
    否则所有词替换为固定 replacement。"""
    terms: List[str] = Field(default_factory=list)
    replacement_template: Optional[str] = None   # 例: "{alias}社"
    replacement: str = "（非開示）"


class NGPattern(BaseModel):
    """正则类 NG（金额、电话号码等）。"""
    regex: str
    replacement: str = "（非開示）"


class NGDictionary(BaseModel):
    categories: Dict[str, NGCategory] = Field(default_factory=dict)
    patterns: Dict[str, NGPattern] = Field(default_factory=dict)

    @classmethod
    def load(cls, path: str | Path) -> "NGDictionary":
        p = Path(path)
        if not p.exists():
            return cls()
        raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        return cls.model_validate(raw)

    def all_terms(self) -> List[str]:
        out: List[str] = []
        for cat in self.categories.values():
            out.extend(t for t in cat.terms if t.strip())
        return out


# ----------------------------------------------------------------------
# 规则层
# ----------------------------------------------------------------------

def _walk_strings(obj: Any, fn) -> Any:
    if isinstance(obj, str):
        return fn(obj)
    if isinstance(obj, list):
        return [_walk_strings(x, fn) for x in obj]
    if isinstance(obj, dict):
        return {k: _walk_strings(v, fn) for k, v in obj.items()}
    return obj


def apply_rules(summary: dict, dictionary: NGDictionary) -> Tuple[dict, dict]:
    """确定性替换。返回 (脱敏后 dict, 报告片段)。"""
    alias_map: Dict[str, str] = {}          # 原词 -> 替换词（跨字段一致）
    counts: Dict[str, int] = {}
    seq_state: Dict[str, int] = {}          # 类别 -> 已分配别名数

    # 词表：长词优先，避免"○○株式会社"先被"○○"部分命中
    term_plan: List[Tuple[str, str]] = []   # (原词, 替换词)
    for cat_name, cat in dictionary.categories.items():
        for term in sorted({t for t in cat.terms if t.strip()}, key=len, reverse=True):
            if cat.replacement_template and "{alias}" in cat.replacement_template:
                idx = seq_state.get(cat_name, 0)
                alias = _ALIAS_SEQ[idx % len(_ALIAS_SEQ)]
                seq_state[cat_name] = idx + 1
                repl = cat.replacement_template.format(alias=alias)
            else:
                repl = cat.replacement
            term_plan.append((term, repl))
    term_plan.sort(key=lambda x: len(x[0]), reverse=True)

    compiled = [(name, re.compile(pat.regex), pat.replacement)
                for name, pat in dictionary.patterns.items()]

    def redact_text(text: str) -> str:
        for term, repl in term_plan:
            if term in text:
                text = text.replace(term, repl)
                alias_map[term] = repl
                counts[term] = counts.get(term, 0) + 1
        for name, rx, repl in compiled:
            text, n = rx.subn(repl, text)
            if n:
                counts[f"pattern:{name}"] = counts.get(f"pattern:{name}", 0) + n
        return text

    redacted = _walk_strings(summary, redact_text)
    return redacted, {"alias_map": alias_map, "replacement_counts": counts}


def scan_leaks(summary: dict, dictionary: NGDictionary) -> List[str]:
    """复扫：返回文本中仍存在的 NG 原词（LLM 改写后的安全闸）。"""
    text = json.dumps(summary, ensure_ascii=False)
    return [t for t in dictionary.all_terms() if t and t in text]


# ----------------------------------------------------------------------
# LLM 改写层（可回退）
# ----------------------------------------------------------------------

REDACT_SYSTEM = """あなたは社外公開用文書の匿名化エージェントです。
入力 JSON は既に既知の NG ワードが置換済みです。あなたの仕事は、
まだ残っている可能性のある識別情報（未登録の企業名・人名・製品固有名など）を
一般的な表現（「大手電機メーカー」「担当者」「対象製品」等）に置き換えることです。

厳守事項：
1. 事実・数値関係・文の意味は一切変えない。識別情報の一般化のみ行う。
2. 既に「（非開示）」「A社」等に置換済みの箇所はそのまま維持する。
3. 入力とまったく同じ JSON 構造・キーで出力する。JSON のみを出力。
"""


def redact_summary(
    summary: dict,
    dictionary: NGDictionary,
    llm=None,
    llm_rewrite: bool = True,
    model=CaseSummary,
) -> Tuple[Any, dict]:
    """完整脱敏流程。返回 (社外版 CaseSummary, redaction_report)。"""
    rule_redacted, report = apply_rules(summary, dictionary)
    report["llm_rewrite"] = {"enabled": bool(llm_rewrite and llm is not None),
                             "applied": False, "fallback_reason": None}

    final = rule_redacted
    if llm_rewrite and llm is not None:
        try:
            rewritten = llm.chat_json(
                system=REDACT_SYSTEM,
                user=json.dumps(rule_redacted, ensure_ascii=False),
                max_tokens=8192,
                json_schema=model.model_json_schema(),
                tag="redact:llm",
            )
            model.model_validate(rewritten)                # (a) 契约校验
            leaks = scan_leaks(rewritten, dictionary)      # (b) NG 词复扫
            if leaks:
                report["llm_rewrite"]["fallback_reason"] = f"NG 词在改写后重现: {leaks}"
            else:
                final = rewritten
                report["llm_rewrite"]["applied"] = True
        except (ValidationError, Exception) as e:  # noqa: BLE001
            report["llm_rewrite"]["fallback_reason"] = f"改写失败，回退规则版: {type(e).__name__}"

    # 最终安全闸：无论走哪条路，输出前再复扫一次
    residual = scan_leaks(final, dictionary)
    if residual:
        final, extra = apply_rules(final, dictionary)
        report["final_rescan_replacements"] = extra["replacement_counts"]

    external = model.model_validate(final)
    report["leaks_after_all"] = scan_leaks(external.model_dump(mode="json"), dictionary)
    return external, report


DEFAULT_DICTIONARY_YAML = """\
# 社外脱敏 NG 词典。terms 按实际情况填写；空词典 = 仅正则模式生效。
# 保存后立即生效（下一次运行/重新生成社外版时应用）。
categories:
  client_names:
    # {alias} 会按出现顺序分配 A/B/C…，同一客户全文一致
    replacement_template: "{alias}社"
    terms: []
    #  - "○○株式会社"
    #  - "△△電機"
  internal_codes:
    replacement: "（開発コード非開示）"
    terms: []
    #  - "Project-X"
  person_names:
    replacement: "（担当者）"
    terms: []
patterns:
  amounts:
    # 金额：1,234万円 / ５億円 / 300円 等
    regex: "[0-9０-９][0-9０-９,，.]*\\\\s*(?:億|万|千)?\\\\s*円"
    replacement: "（金額非開示）"
"""
