"""
精読モード（deep read）— ページ単位で本文と図を突き合わせる層。

## 何をする物か

人が資料を読むとき、1 ページの中で「本文」「図表」「ページ全体の見た目」を
同時に見て辻褄を確認してから次へ進む。v3.8 までのこのシステムは本文チェーンと
視覚チェーンが最後まで一度も出会わず、`write_summary` で初めて並べられていた。
本文が「3.2 秒」、図が「3.5 秒」と言っていても誰も気付けない。

精読モードはその隙間を埋める。ただし**逐次 refine にはしない**：

- refine（1 ページ目の要約に 2 ページ目を溶かし込む…）は前段の誤りが最後まで
  伝播し、位置バイアスが出て、直列なので O(n) で遅い。弱いモデルでは特に悪い。
- ここでは **ページ単位の突き合わせは並列**に行い、集約は従来どおり
  map-reduce のまま残す。「ページ内は精読、全体は map-reduce」の折衷。

## 判定はモデルに任せない

食い違いの裁定を弱いモデルの自由記述に任せると、もっともらしい嘘が増えるだけ。
ここでの突き合わせは**確定的な規則**で行う：

1. 数値の一致検査 — 同じページの本文と図から数値（単位付き）を拾い、
   同じ量を指していそうなのに値が違う組を「要確認」として挙げる
2. 被覆の対帳 — そのページに図が N 枚あるのに視覚証拠が M 件しか無い、等
3. 片側しか無いページの検出 — 本文だけ／図だけのページを可視化

LLM は「食い違いが実際に問題か」の判断には使わない。人と後段のプロンプトに
**事実として渡す**だけ。
"""
from __future__ import annotations

import re
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

# 単位の並び順は**長い物から**でなければならない。正規表現の選択肢は
# 左から順に試されるので、`m` を先に置くと "0.8 m3/min" が "0.8 m" として
# 拾われ、単位違いで突き合わせが成立しなくなる（実際にそのバグを踏んだ）。
_UNITS = [
    "m3/min", "万円", "ヶ月", "か月", "kWh", "MPa", "kPa", "MHz", "kHz",
    "degC", "時間", "bar", "sec", "deg", "mm", "cm", "km", "kg", "mg",
    "mL", "mA", "m3", "m2", "kW", "Pa", "Hz", "°C", "℃", "％",
    "秒", "分", "時", "日", "週", "年", "件", "個", "人", "台", "回", "円",
    "%", "m", "g", "t", "s", "h", "W", "V", "A", "L",
]

#: 数値＋単位。日本語資料で実際に出る書き方に寄せてある
#: （カンマ区切り・指数表記・単位なしの裸の数も拾う）
_NUM_RE = re.compile(
    r"(?<![\w.])"
    r"([+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?|[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)"
    r"\s*"
    r"(" + "|".join(re.escape(u) for u in _UNITS) + r")?"
)

#: 相対差がこれ以下なら「同じ値」とみなす。
#: 丸め表記の揺れ（68.30 と 68.3）だけを吸収したいので厳しめに取る。
#: 0.5% にすると 68.3 と 68.5 のような**実在する食い違い**を見逃す。
_REL_TOL = 0.001


def _extract_numbers(text: str) -> List[Tuple[float, str, str]]:
    """(値, 単位, 原文表記) の一覧。単位なしは "" で返す。"""
    out: List[Tuple[float, str, str]] = []
    if not text:
        return out
    for m in _NUM_RE.finditer(text):
        raw = m.group(1)
        try:
            val = float(raw.replace(",", ""))
        except ValueError:
            continue
        unit = (m.group(2) or "").strip()
        unit = {"℃": "degC", "°C": "degC", "％": "%"}.get(unit, unit)
        out.append((val, unit, m.group(0).strip()))
    return out


def _close(a: float, b: float) -> bool:
    if a == b:
        return True
    scale = max(abs(a), abs(b))
    return scale > 0 and abs(a - b) / scale <= _REL_TOL


def cross_check_page(page: Optional[int],
                     text_items: List[Dict[str, Any]],
                     visual_items: List[Dict[str, Any]]) -> Dict[str, Any]:
    """1 ページ分の突き合わせ。全て確定的な規則で判定する。"""
    text_blob = " ".join(str(d.get("content", "")) for d in text_items)
    vis_blob_parts: List[str] = []
    for v in visual_items:
        vis_blob_parts.append(str(v.get("visual_summary", "")))
        vis_blob_parts.extend(str(x) for x in (v.get("key_facts") or []))
        vis_blob_parts.extend(str(x) for x in (v.get("readable_text") or []))
    vis_blob = " ".join(vis_blob_parts)

    t_nums = _extract_numbers(text_blob)
    v_nums = _extract_numbers(vis_blob)

    # 同じ単位で近い値が両方にあれば「裏が取れた」、
    # 同じ単位なのに一致する相手が居ない値は「片側だけ」として挙げる。
    corroborated: List[str] = []
    text_only: List[str] = []
    visual_only: List[str] = []

    v_by_unit: Dict[str, List[float]] = defaultdict(list)
    for val, unit, _ in v_nums:
        v_by_unit[unit].append(val)
    t_by_unit: Dict[str, List[float]] = defaultdict(list)
    for val, unit, _ in t_nums:
        t_by_unit[unit].append(val)

    seen_t = set()
    for val, unit, raw in t_nums:
        if raw in seen_t:
            continue
        seen_t.add(raw)
        if not unit:
            continue                      # 単位なしの裸の数は誤検出が多いので対象外
        if any(_close(val, o) for o in v_by_unit.get(unit, [])):
            corroborated.append(raw)
        elif v_by_unit.get(unit):
            # 同じ単位の値が図側にもあるのに一致しない ＝ 食い違いの疑い
            text_only.append(raw)

    seen_v = set()
    for val, unit, raw in v_nums:
        if raw in seen_v:
            continue
        seen_v.add(raw)
        if not unit:
            continue
        if not any(_close(val, o) for o in t_by_unit.get(unit, [])) and t_by_unit.get(unit):
            visual_only.append(raw)

    conflicts: List[Dict[str, Any]] = []
    for unit in set(t_by_unit) & set(v_by_unit):
        if not unit:
            continue
        tv, vv = sorted(set(t_by_unit[unit])), sorted(set(v_by_unit[unit]))
        if tv and vv and not any(_close(a, b) for a in tv for b in vv):
            conflicts.append({"unit": unit,
                              "text_values": tv[:6], "visual_values": vv[:6]})

    if text_items and visual_items:
        coverage = "both"
    elif text_items:
        coverage = "text_only"
    elif visual_items:
        coverage = "visual_only"
    else:
        coverage = "empty"

    return {
        "page": page,
        "coverage": coverage,
        "text_evidence_count": len(text_items),
        "visual_evidence_count": len(visual_items),
        "numbers_corroborated": corroborated[:12],
        "numbers_text_only": text_only[:12],
        "numbers_visual_only": visual_only[:12],
        "conflicts": conflicts[:6],
        "needs_review": bool(conflicts),
    }


def build_page_report(text_evidence: List[Dict[str, Any]],
                      visual_evidence: List[Dict[str, Any]]) -> Dict[str, Any]:
    """全ページ分の突き合わせ結果を作る。

    ページ番号を持たない証拠は `unpaged` にまとめる（捨てない）。
    """
    by_page_t: Dict[Any, List[Dict[str, Any]]] = defaultdict(list)
    by_page_v: Dict[Any, List[Dict[str, Any]]] = defaultdict(list)
    for d in text_evidence or []:
        by_page_t[d.get("page")].append(d)
    for d in visual_evidence or []:
        by_page_v[d.get("page")].append(d)

    pages = sorted({p for p in list(by_page_t) + list(by_page_v) if p is not None})
    results = [cross_check_page(p, by_page_t.get(p, []), by_page_v.get(p, []))
               for p in pages]

    unpaged_t, unpaged_v = by_page_t.get(None, []), by_page_v.get(None, [])
    unpaged = None
    if unpaged_t or unpaged_v:
        unpaged = cross_check_page(None, unpaged_t, unpaged_v)

    conflicts = [r for r in results if r["needs_review"]]
    return {
        "pages": results,
        "unpaged": unpaged,
        "page_count": len(results),
        "pages_with_both": sum(1 for r in results if r["coverage"] == "both"),
        "pages_text_only": sum(1 for r in results if r["coverage"] == "text_only"),
        "pages_visual_only": sum(1 for r in results if r["coverage"] == "visual_only"),
        "conflict_pages": [r["page"] for r in conflicts],
        "conflict_count": len(conflicts),
    }


def report_to_prompt_block(report: Dict[str, Any], max_pages: int = 40) -> str:
    """突き合わせ結果を Agent 3 のプロンプトに載る短い日本語ブロックへ。

    長くすると証拠パックを圧迫するので、**要確認の頁と片側しか無い頁**に絞る。
    問題の無い頁はわざわざ書かない。
    """
    if not report or not report.get("pages"):
        return ""
    lines: List[str] = []
    for r in report["pages"][:max_pages]:
        if r["conflicts"]:
            for c in r["conflicts"]:
                lines.append(
                    f"- {r['page']}ページ：本文と図で {c['unit']} の値が食い違っています"
                    f"（本文 {c['text_values']} / 図 {c['visual_values']}）。"
                    f"どちらか一方だけを断定せず、資料で確認できる方を採用すること。")
        elif r["coverage"] == "visual_only":
            lines.append(f"- {r['page']}ページ：本文側の証拠が無く、図の読み取りのみです。")
    if not lines:
        return ""
    head = (f"ページ突き合わせ（精読モード・{report['page_count']} ページ中 "
            f"{report['conflict_count']} ページで要確認）：")
    return head + "\n" + "\n".join(lines[:20])


def summary_lines(report: Dict[str, Any]) -> List[str]:
    """UI / ログ用の日本語 1 行要約。"""
    if not report or not report.get("pages"):
        return []
    out = [f"精読：{report['page_count']} ページを突き合わせ"
           f"（本文と図の両方があるページ {report['pages_with_both']}）"]
    if report["pages_text_only"]:
        out.append(f"　本文のみのページ {report['pages_text_only']}")
    if report["pages_visual_only"]:
        out.append(f"　図のみのページ {report['pages_visual_only']}")
    if report["conflict_count"]:
        out.append(f"　⚠ 数値が食い違うページ {report['conflict_count']}："
                   f"{report['conflict_pages'][:10]}")
    return out


# ---------------------------------------------------------------------------
# 数値の裏取り — 作話に対する確定的な歯止め
# ---------------------------------------------------------------------------
#
# 「詳しく書け」と指示された弱いモデルの典型的な失敗は、字数を満たすために
# **もっともらしい数値を作ること**。プロンプトで禁じても完全には止まらない。
#
# そこで規則で潰す：出力に現れた数値が証拠のどこにも無ければ、それは
# モデルが作った物と断定してよい。要約は抽出であって創造ではないので、
# 「証拠に無い数値が出てくる」こと自体が異常である。
#
# 判定はモデルを介さないので、モデルの巧拙に左右されない。


def unsupported_numbers(produced_text: str, evidence_text: str,
                        allow_ordinals: bool = True) -> List[Dict[str, Any]]:
    """出力にあって証拠に無い数値を挙げる。

    - 単位付きの値は「値＋単位」で照合する（68.3 degC と 68.3 % は別物）
    - 単位なしの裸の数は誤検出が多いので、既定では見逃す
      （箇条書きの番号や「3 件」の語形違いを拾ってしまうため）
    - 丸め表記の揺れ（68.30 と 68.3）は一致とみなす
    """
    ev = _extract_numbers(evidence_text)
    ev_by_unit: Dict[str, List[float]] = defaultdict(list)
    for val, unit, _ in ev:
        ev_by_unit[unit].append(val)
    # 単位が落ちた書き方（証拠「68.3 degC」→ 出力「68.3」）も裏取り済みとみなす
    ev_any = [val for val, _, _ in ev]

    bad: List[Dict[str, Any]] = []
    seen = set()
    for val, unit, raw in _extract_numbers(produced_text):
        if raw in seen:
            continue
        seen.add(raw)
        if not unit:
            if allow_ordinals:
                continue
            if any(_close(val, o) for o in ev_any):
                continue
            bad.append({"value": val, "unit": "", "text": raw})
            continue
        if any(_close(val, o) for o in ev_by_unit.get(unit, [])):
            continue
        # 単位付きで一致が無い。単位を無視しても一致しないなら作話とみなす
        if any(_close(val, o) for o in ev_any):
            continue
        bad.append({"value": val, "unit": unit, "text": raw})
    return bad


def verify_items(items: List[str], evidence_text: str) -> Dict[str, Any]:
    """加筆結果を証拠と突き合わせて採否を決める。

    1 つでも裏の取れない数値があれば **その回の加筆を丸ごと捨てる**。
    部分採用にすると、捨てた文と残した文の整合が崩れて余計に危ない。
    """
    joined = "\n".join(items or [])
    bad = unsupported_numbers(joined, evidence_text)
    return {"ok": not bad, "unsupported": bad,
            "reason": ("" if not bad else
                       "証拠に無い数値が含まれています: "
                       + ", ".join(b["text"] for b in bad[:5]))}
