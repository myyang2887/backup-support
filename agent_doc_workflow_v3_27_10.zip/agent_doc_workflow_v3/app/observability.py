"""
可观测性与运行存储层（v3.1 新增）。

工程动机：v3 之前，run 目录的文件布局（status.json / evidence_*.json / ...）
以字符串字面量散落在各节点里，进度上报是各节点手写 json 读写，LLM 调用
耗时完全不可见——"为什么慢"只能靠猜。

RunStore 把这些收拢为一个对象：
- 文件布局的唯一定义（改布局只动这里）
- 事件流：status.json（UI 轮询用，保持向后兼容的形状）+ events.jsonl（完整审计流）
- LLM 指标：每次调用的 耗时/模式/prompt与输出字符数/重试次数 落 llm_metrics.jsonl，
  并聚合到 metrics.json（按调用类别统计），Web UI 直接展示"时间花在哪"
- 协作式取消：cancel 标记文件，长循环节点定期检查
- 每 run 独立日志文件 run.log

线程安全说明：JSONL 追加为单行小写入（< PIPE_BUF），POSIX 下原子；
status/metrics 的读改写用进程内锁保护（本应用为单进程多线程模型）。
"""
from __future__ import annotations

import json
import logging
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional


class RunCancelled(RuntimeError):
    """用户主动取消运行。由节点循环抛出，webapp 捕获后标记 cancelled 状态。"""


_locks: Dict[str, threading.Lock] = {}
_locks_guard = threading.Lock()


def _lock_for(path: Path) -> threading.Lock:
    key = str(path)
    with _locks_guard:
        if key not in _locks:
            _locks[key] = threading.Lock()
        return _locks[key]


class RunStore:
    """一次运行（run）的所有磁盘产物与观测数据的唯一入口。"""

    # ---- 文件布局（唯一定义处）----
    STATUS = "status.json"
    EVENTS = "events.jsonl"
    LLM_METRICS = "llm_metrics.jsonl"
    METRICS = "metrics.json"
    MANIFEST = "manifest.json"
    CANCEL_FLAG = "cancel.flag"
    LOG = "run.log"
    QUALITY_REPORT = "quality_report.json"
    SUMMARY_JSON = "case_summary.json"
    SUMMARY_MD = "case_summary.md"
    EVIDENCE_TEXT = "evidence_text.json"
    EVIDENCE_AGGREGATED = "evidence_aggregated.json"
    EVIDENCE_VISUAL = "evidence_visual.json"
    VISUAL_MANIFEST = "visual_assets_manifest.json"
    PARSED_DIR = "parsed"
    CHUNKS_DIR = "chunks"
    VISUAL_FILTERED_DIR = "visual_filtered"

    def __init__(self, run_dir: str | Path):
        self.run_dir = Path(run_dir)
        self.run_dir.mkdir(parents=True, exist_ok=True)

    def path(self, name: str) -> Path:
        return self.run_dir / name

    # ------------------------------------------------------------------
    # 通用 JSON 读写
    # ------------------------------------------------------------------
    def save_json(self, name: str, data: Any) -> Path:
        p = self.path(name)
        p.parent.mkdir(parents=True, exist_ok=True)
        with _lock_for(p):
            p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return p

    def load_json(self, name: str, default: Any = None) -> Any:
        p = self.path(name)
        if not p.exists():
            return default
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001 损坏文件按缺失处理
            return default

    def exists(self, name: str) -> bool:
        return self.path(name).exists()

    def _append_jsonl(self, name: str, record: dict) -> None:
        p = self.path(name)
        line = json.dumps(record, ensure_ascii=False) + "\n"
        with _lock_for(p), p.open("a", encoding="utf-8") as f:
            f.write(line)

    # ------------------------------------------------------------------
    # 事件与进度（status.json 形状与 v3 兼容，UI 无需改协议）
    # ------------------------------------------------------------------
    def reset_status(self) -> None:
        self.save_json(self.STATUS, {"history": []})
        # 新一轮运行清掉旧的取消标记与指标
        for f in (self.CANCEL_FLAG, self.LLM_METRICS, self.METRICS):
            p = self.path(f)
            if p.exists():
                p.unlink()

    def event(self, node: str, phase: str = "running", detail: str = "",
              errors: Optional[list] = None, peek: Optional[str] = None) -> None:
        """
        进度事件。

        v3.6 计时修复（两个 bug，都会让 UI 的秒表上下跳动）：

        1. **节点内 i/N 更新会重写开始时刻**。旧实现把 history 末尾的 running
           记录整条替换（`hist[-1] = record`），`time` 一并被换成"现在"，
           前端的实时秒表以该 time 为起点 → 每来一次 `7/12` 进度，秒表就归零重数。
           现在保留最初的 `time`，把最新时刻另记为 `updated`。
        2. **并行分支下 current_node 在两条链之间来回跳**。status 只有一个
           current_node 字段，文本分支和视觉分支交替上报，前端把"实时耗时"
           加到当次看到的那个节点上，累计值随之来回摆动。
           现在维护 `running_nodes` 集合（多个节点可同时在跑），
           current_node 保留仅为向后兼容。

        另外按节点保留最新 peek（`peeks`），多 agent UI 才能各自显示气泡。
        """
        now = time.time()
        record = {"node": node, "phase": phase, "detail": detail, "time": now}
        if peek:
            record["peek"] = peek[:120]
        self._append_jsonl(self.EVENTS, record)   # 审计流保留原始时刻，不做任何合并

        status_path = self.path(self.STATUS)
        with _lock_for(status_path):
            status: Dict[str, Any] = {}
            if status_path.exists():
                try:
                    status = json.loads(status_path.read_text(encoding="utf-8"))
                except Exception:
                    status = {}
            status["current_node"] = node          # 兼容旧前端
            status["phase"] = phase
            status["detail"] = detail
            status["server_time"] = now            # 前端据此消除客户端/服务端时钟偏差
            if peek:
                status["peek"] = record["peek"]
                status.setdefault("peeks", {})[node] = record["peek"]

            running = [n for n in status.get("running_nodes", []) if n != node]
            if phase == "running":
                running.append(node)
            status["running_nodes"] = running

            hist = status.setdefault("history", [])
            entry = dict(record)
            if phase == "running" and hist and hist[-1].get("node") == node \
                    and hist[-1].get("phase") == "running":
                # 节点内 i/N 计数只保留最新一条，避免刷爆 history；
                # 但**开始时刻必须保留**，否则前端秒表会被不断重置（v3.6 修复）
                entry["time"] = hist[-1].get("time", now)
                entry["updated"] = now
                hist[-1] = entry
            else:
                hist.append(entry)
            if errors is not None:
                status["errors"] = errors
            status_path.write_text(json.dumps(status, ensure_ascii=False, indent=2),
                                   encoding="utf-8")

    # ------------------------------------------------------------------
    # LLM 调用指标
    # ------------------------------------------------------------------
    def llm_metric(self, record: dict) -> None:
        """record: {tag, duration_s, prompt_chars, completion_chars, mode, attempts, grammar_used}"""
        record = {"time": time.time(), **record}
        self._append_jsonl(self.LLM_METRICS, record)

        # 聚合：tag 取冒号前缀作为类别（extract:chunk_0001 -> extract）
        metrics_path = self.path(self.METRICS)
        with _lock_for(metrics_path):
            agg: Dict[str, Any] = {}
            if metrics_path.exists():
                try:
                    agg = json.loads(metrics_path.read_text(encoding="utf-8"))
                except Exception:
                    agg = {}
            group = record.get("tag", "other").split(":")[0]
            g = agg.setdefault(group, {"calls": 0, "total_s": 0.0, "grammar_calls": 0,
                                       "prompt_chars": 0, "completion_chars": 0})
            g["calls"] += 1
            g["total_s"] = round(g["total_s"] + record.get("duration_s", 0.0), 2)
            g["grammar_calls"] += 1 if record.get("grammar_used") else 0
            g["prompt_chars"] += record.get("prompt_chars", 0)
            g["completion_chars"] += record.get("completion_chars", 0)
            metrics_path.write_text(json.dumps(agg, ensure_ascii=False, indent=2),
                                    encoding="utf-8")

    # ------------------------------------------------------------------
    # 协作式取消
    # ------------------------------------------------------------------
    def request_cancel(self) -> None:
        self.path(self.CANCEL_FLAG).write_text(str(time.time()), encoding="utf-8")

    @property
    def cancelled(self) -> bool:
        return self.path(self.CANCEL_FLAG).exists()

    def raise_if_cancelled(self) -> None:
        if self.cancelled:
            raise RunCancelled("ユーザーにより中断されました")

    # ------------------------------------------------------------------
    # 日志
    # ------------------------------------------------------------------
    def logger(self) -> logging.Logger:
        name = f"run.{self.run_dir.name}"
        logger = logging.getLogger(name)
        if not logger.handlers:
            handler = logging.FileHandler(self.path(self.LOG), encoding="utf-8")
            handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
            logger.propagate = False
        return logger
