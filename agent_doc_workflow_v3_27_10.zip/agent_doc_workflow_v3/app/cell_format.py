"""
Excel セル値の文字列化（v3.24）— 特に日付。

## なぜ要るのか

Excel の日付は、画面に `2023/12/15` と表示されていても、ファイルの中身は
**1900-01-01 からの通算日数**（シリアル値）でしかない。日付らしく見えるのは
セルの表示書式が変換しているだけ。

openpyxl は書式が日付と分かる場合だけ datetime に直してくれるが、
書式が「標準」のまま数値として入っている列（他システムからの取り込みや
コピー貼り付けでよく起きる）は **`45275` という生の数値のまま返る**。

それをそのまま要約の証拠に載せると、モデルは意味の分からない数字を
「完了日」として書き写すか、あるいは近くにある見た目のきれいな日付
（アンケートの回答日時など）に乗り換えてしまう。実際その両方が起きた。

## 方針

- **書式（number_format）を見て日付かどうかを判断する。** 数値の範囲から
  推測しない——`45275` は日数にも見えるが、単なる金額や個数かもしれない。
  推測で日付に変えると、今度は数値を壊す。
- 時刻が 00:00:00 のものは日付だけにする。「2023-12-15 00:00:00」の
  ゼロ並びは情報ではなく雑音で、他の列との見栄えの差にもなる。
- 判断が付かないものは**触らない**。壊さないことを優先する。
"""
from __future__ import annotations

import datetime as _dt
import re
from typing import Any, Optional

#: 表示書式が日付・時刻を表しているか。
#: yyyy / mm / dd / h / s、和暦の ge、日本語の年月日 などを拾う。
_DATE_FORMAT_RE = re.compile(r"(yy|mm?|dd|hh?|ss|ge?|年|月|日|時|分)", re.I)

#: 逆に、これらが主役の書式は日付ではない（通貨・パーセント・指数）。
_NON_DATE_FORMAT_RE = re.compile(r"[¥$€%]|0\.00E|##0\.0")

#: ロケール指定子 [$-ja-JP] や [$-409]。中に $ を含むので通貨と誤認されるが、
#: これは書式の言語指定であって通貨ではない。和暦（[$-ja-JP]ge.m.d）は
#: 日本企業の台帳でごく普通に使われるので、取り違えると日付が全滅する。
_LOCALE_TAG_RE = re.compile(r"\[\$-[0-9A-Za-z\-]+\]")

#: Excel のシリアル値として現実的な範囲。
#: 下限 1（1900-01-01）だと 1〜100 のような普通の数値まで拾ってしまうので、
#: 書式が日付だと分かっている場合にのみ使う補助的な下限を置く。
_SERIAL_MIN = 1
_SERIAL_MAX = 2958465          # 9999-12-31

#: Excel の 1900 年うるう年バグに合わせた基準日
_EXCEL_EPOCH = _dt.datetime(1899, 12, 30)


def is_date_format(number_format: Optional[str]) -> bool:
    """セルの表示書式が日付・時刻を表しているか。"""
    if not number_format:
        return False
    fmt = str(number_format)
    if fmt in ("General", "@", "標準"):
        return False
    # ロケール指定子を先に外す。[$-ja-JP] の $ を通貨記号と読むと、
    # 和暦書式が丸ごと日付ではないと判定されてしまう。
    fmt = _LOCALE_TAG_RE.sub("", fmt)
    if _NON_DATE_FORMAT_RE.search(fmt):
        return False
    return bool(_DATE_FORMAT_RE.search(fmt))


def serial_to_datetime(serial: float) -> Optional[_dt.datetime]:
    """Excel のシリアル値を datetime に直す。範囲外なら None。"""
    try:
        n = float(serial)
    except (TypeError, ValueError):
        return None
    if not (_SERIAL_MIN <= n <= _SERIAL_MAX):
        return None
    try:
        return _EXCEL_EPOCH + _dt.timedelta(days=n)
    except (OverflowError, ValueError):
        return None


def format_datetime(value: _dt.datetime | _dt.date | _dt.time) -> str:
    """日付を人にもモデルにも読める形にする。

    時刻が 00:00:00 なら日付だけ。ゼロ並びは情報量ゼロなうえ、
    他の列（アンケートの回答日時など）との見栄えの差を作ってしまう。
    """
    if isinstance(value, _dt.datetime):
        if value.hour == 0 and value.minute == 0 and value.second == 0:
            return value.strftime("%Y-%m-%d")
        return value.strftime("%Y-%m-%d %H:%M")
    if isinstance(value, _dt.date):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, _dt.time):
        return value.strftime("%H:%M")
    return str(value)


def cell_to_text(value: Any, number_format: Optional[str] = None) -> str:
    """セルの値を文字列にする。日付は正規化する。

    `number_format` を渡せる場合は必ず渡すこと。これが無いと、
    書式だけが日付でデータが数値のセル（シリアル値）を救えない。
    """
    if value is None:
        return ""

    # 1) 既に日付型：書式を見るまでもない
    if isinstance(value, (_dt.datetime, _dt.date, _dt.time)):
        return format_datetime(value)

    # 2) 数値だが書式が日付：シリアル値なので直す
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if is_date_format(number_format):
            dt = serial_to_datetime(value)
            if dt is not None:
                return format_datetime(dt)
        # 日付でない数値。1.0 のような整数値の float は整数として出す
        if isinstance(value, float) and value == int(value):
            return str(int(value))
        return str(value)

    # 3) それ以外は素通し（改行と表の区切り文字だけ整える）
    return str(value).replace("\n", " ").replace("|", "／").strip()


# =====================================================================
# v3.25：列単位の推論
# =====================================================================
#
# 現場の台帳を調べたら、1 つの列（456 件）の中で
#   日付型 362 件 ／ 生のシリアル値 90 件 ／ その他の数値 4 件
# という状態だった。複数のファイルを結合した台帳では、行によって
# 保存され方が違うのが普通に起きる（値貼り付け・別システムからの取り込み）。
#
# セル単体では「45275 が日付か金額か」は判断できない。だが **同じ列に
# 明らかな日付が 362 件もある** なら、残りの数値も日付と見てよい。
# これは当てずっぽうではなく、列内の証拠にもとづく推論。
#
# 逆に、日付が 2 件しかない金額列（誰かが誤って 2 セルだけ日付書式にした）
# では比率が低くなるので変換しない。比率で見るのはそのため。

#: 日付シリアル値としてありえる範囲。1995-05-28 〜 2035-01-01 あたり。
#: 業務台帳の「完了日」がこの外に出ることはまず無い。
_PLAUSIBLE_SERIAL_MIN = 34_800
_PLAUSIBLE_SERIAL_MAX = 49_500

#: 列を日付列と認めるのに必要な、明確な日付の最小件数。
#: 少数の偶然で列全体を書き換えないための下限。
#:
#: 2 にしてあるのは、件数の絶対値ではなく **比率** で守る設計だから。
#: 「日付 2 件・数値 400 件」の金額列は比率 0.5% で弾かれるので、
#: ここを小さくしても金額列を壊す心配は無い。逆に大きくすると、
#: 行数の少ない台帳や、日付が入っている行が少ない列を取りこぼす。
_COLUMN_DATE_MIN_COUNT = 2

#: 「明確な日付」が「明確な日付＋疑わしい数値」に占める割合の下限。
_COLUMN_DATE_MIN_RATIO = 0.5

#: 文字列として入っている日付の形。結合台帳では米国式が紛れ込みやすい。
_STR_DATE_YMD = re.compile(r"^\s*(\d{4})[/\-年](\d{1,2})[/\-月](\d{1,2})日?")
_STR_DATE_SLASH = re.compile(r"^\s*(\d{1,2})[/\-](\d{1,2})[/\-](\d{4})")


def parse_date_string(text: Any, prefer_mdy: Optional[bool] = None) -> Optional[_dt.datetime]:
    """文字列の日付を datetime にする。判別できなければ None。

    `05/28/2020` は 28 > 12 なので月日の順序が確定する。
    `05/06/2020` は確定しないので、`prefer_mdy` に列全体から得た
    傾向を渡してもらう（同じ列に順序の確定するデータがあれば、
    それを根拠に列全体を同じ順序として読む）。
    """
    if not isinstance(text, str):
        return None
    s = text.strip()
    if not s:
        return None

    m = _STR_DATE_YMD.match(s)
    if m:
        y, mo, d = (int(x) for x in m.groups())
        try:
            return _dt.datetime(y, mo, d)
        except ValueError:
            return None

    m = _STR_DATE_SLASH.match(s)
    if m:
        a, b, y = (int(x) for x in m.groups())
        # 片方が 12 を超えていれば順序は確定する
        if a > 12 and b <= 12:
            mo, d = b, a
        elif b > 12 and a <= 12:
            mo, d = a, b
        elif prefer_mdy is False:
            mo, d = b, a
        else:
            mo, d = a, b       # 既定は月/日（結合台帳で多い米国式）
        try:
            return _dt.datetime(y, mo, d)
        except ValueError:
            return None
    return None


def _is_plausible_serial(value: Any) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    return _PLAUSIBLE_SERIAL_MIN <= float(value) <= _PLAUSIBLE_SERIAL_MAX


def analyze_column(values: List[Any], formats: List[Optional[str]]) -> Dict[str, Any]:
    """列を丸ごと見て、日付列かどうかと、月日の順序を決める。

    返り値::

        {"is_date_column": True, "prefer_mdy": True,
         "clear": 362, "suspect": 90}
    """
    clear = 0            # 明確に日付だと分かるもの
    suspect = 0          # 日付かもしれない裸の数値
    mdy_votes = 0        # 月/日 順だと確定した文字列の数
    dmy_votes = 0

    for v, fmt in zip(values, formats):
        if v is None or (isinstance(v, str) and not v.strip()):
            continue
        if isinstance(v, (_dt.datetime, _dt.date)):
            clear += 1
            continue
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            if is_date_format(fmt):
                clear += 1
            elif _is_plausible_serial(v):
                suspect += 1
            continue
        if isinstance(v, str):
            m = _STR_DATE_SLASH.match(v.strip())
            if m:
                a, b, _ = (int(x) for x in m.groups())
                if a > 12 and b <= 12:
                    dmy_votes += 1
                elif b > 12 and a <= 12:
                    mdy_votes += 1
                clear += 1
            elif _STR_DATE_YMD.match(v.strip()):
                clear += 1

    total_relevant = clear + suspect
    is_date_column = (
        clear >= _COLUMN_DATE_MIN_COUNT
        and total_relevant > 0
        and clear / total_relevant >= _COLUMN_DATE_MIN_RATIO
    )
    return {"is_date_column": is_date_column, "prefer_mdy": mdy_votes >= dmy_votes,
            "clear": clear, "suspect": suspect}


def cell_to_text_in_column(value: Any, number_format: Optional[str],
                           column_info: Optional[Dict[str, Any]] = None) -> str:
    """列の性質を踏まえてセルを文字列にする。

    列が日付列だと分かっている場合に限り、生のシリアル値と
    文字列の日付も日付として揃える。そうでなければ従来どおり。
    """
    info = column_info or {}
    if info.get("is_date_column"):
        if _is_plausible_serial(value) and not is_date_format(number_format):
            dt = serial_to_datetime(value)
            if dt is not None:
                return format_datetime(dt)
        if isinstance(value, str):
            dt = parse_date_string(value, prefer_mdy=info.get("prefer_mdy", True))
            if dt is not None:
                return format_datetime(dt)
    return cell_to_text(value, number_format)
