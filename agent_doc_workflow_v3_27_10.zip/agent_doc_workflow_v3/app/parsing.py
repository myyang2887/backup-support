"""
解析层（v3 新增）。

v2 的性能问题之一在这里：docling_convert 被调用两次（markdown + json），
每次都完整跑一遍布局分析/OCR/表格结构模型——对 CPU 环境这是分钟级的浪费。
v3 只转换一次，从同一个 document 对象导出两种格式，解析时间直接减半。

同时提供：
- OCR 开关（数字原生 PDF 关掉 OCR 能省大量时间；扫描件再打开）
- 视觉资产预过滤：尺寸/字节数过滤掉图标装饰图，SHA1 去重，
  超大图降采样到 max_edge 像素——base64 后的视觉 prompt 体积经常是
  VLM 调用耗时的主因，降采样是最直接的提速手段
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .config import PROJECT_ROOT


def convert_document_once(
    input_path: str,
    output_dir: str,
    do_ocr: bool = True,
) -> Dict[str, Any]:
    """一次转换，同时导出 markdown + json。替代 v1/v2 的两次 docling_convert。"""
    src = Path(input_path).expanduser().resolve()
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if not src.exists():
        return {"ok": False, "error": f"input_path 不存在: {src}"}

    try:
        converter = _build_converter(do_ocr)
        result = converter.convert(str(src))
        doc = result.document
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"Docling 转换失败: {e!r}"}

    md_path = out_dir / f"{src.stem}.md"
    md_path.write_text(doc.export_to_markdown(), encoding="utf-8")

    json_path = out_dir / f"{src.stem}.json"
    try:
        json_path.write_text(
            json.dumps(doc.export_to_dict(), ensure_ascii=False), encoding="utf-8"
        )
    except Exception:  # noqa: BLE001 JSON 导出失败不致命
        json_path = None

    return {
        "ok": True,
        "markdown_path": str(md_path),
        "json_path": str(json_path) if json_path else None,
    }


def _build_converter(do_ocr: bool):
    """构建 DocumentConverter；能配置 PDF pipeline 就配置，不能就用默认。"""
    from docling.document_converter import DocumentConverter

    if do_ocr:
        return DocumentConverter()
    try:
        from docling.datamodel.base_models import InputFormat
        from docling.datamodel.pipeline_options import PdfPipelineOptions
        from docling.document_converter import PdfFormatOption

        opts = PdfPipelineOptions()
        opts.do_ocr = False
        return DocumentConverter(
            format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=opts)}
        )
    except Exception:  # noqa: BLE001 Docling 版本差异，退回默认
        return DocumentConverter()


# ----------------------------------------------------------------------
# 视觉资产预过滤 + 降采样
# ----------------------------------------------------------------------

def prefilter_and_downscale_images(
    image_paths: List[str],
    work_dir: str,
    min_edge_px: int = 100,
    min_bytes: int = 5 * 1024,
    max_edge_px: int = 1024,
    max_assets: int = 30,
) -> Dict[str, Any]:
    """
    过滤规则（都是廉价操作，不花一个 LLM token）：
    1. 文件 < min_bytes 或短边 < min_edge_px -> 视为图标/装饰，丢弃
    2. 内容 SHA1 去重（PPT 母版 logo 在每页重复出现是常态）
    3. 长边 > max_edge_px -> 降采样（VLM prompt 体积主要来自图片）
    返回 {"kept": [...], "dropped": n, "deduped": n, "downscaled": n,
          "dropped_detail": [{"name":..., "reason":...}], ...}

    v3.12：件数だけでは「どの図が落ちたのか」が分からず現物に辿り着けない。
    1 件ずつ理由付きで残す（ファイル名には頁や出所が畳み込まれている）。
    """
    out_dir = Path(work_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    try:
        from PIL import Image
        pil_ok = True
    except ImportError:
        pil_ok = False

    seen_hashes: set = set()
    kept: List[str] = []
    dropped = deduped = downscaled = 0
    detail: List[Dict[str, Any]] = []
    first_of_hash: Dict[str, str] = {}

    def _note(path: Path, reason: str) -> None:
        # 詳細は増え過ぎても読めないので上限を掛ける（件数は別途集計済み）
        if len(detail) < 200:
            detail.append({"name": path.name, "path": str(path), "reason": reason})

    for p in image_paths:
        path = Path(p)
        if not path.exists():
            dropped += 1
            _note(path, "ファイルが存在しません")
            continue

        data = path.read_bytes()
        if len(data) < min_bytes:
            dropped += 1
            _note(path, f"ファイルサイズ {len(data):,}B < 下限 {min_bytes:,}B（装飾画像とみなした）")
            continue

        digest = hashlib.sha1(data).hexdigest()
        if digest in seen_hashes:
            deduped += 1
            _note(path, f"内容が同一（SHA1 重複）：先に採用した「{first_of_hash.get(digest, '?')}」と同じ")
            continue
        seen_hashes.add(digest)
        first_of_hash[digest] = path.name

        if not pil_ok:
            kept.append(str(path))
            if len(kept) >= max_assets:
                break
            continue

        try:
            with Image.open(path) as im:
                w, h = im.size
                if min(w, h) < min_edge_px:
                    dropped += 1
                    _note(path, f"短辺 {min(w, h)}px < 下限 {min_edge_px}px（{w}x{h}）")
                    continue
                if max(w, h) > max_edge_px:
                    scale = max_edge_px / max(w, h)
                    im = im.convert("RGB")
                    im = im.resize((max(1, int(w * scale)), max(1, int(h * scale))))
                    out_path = out_dir / f"{path.stem}_ds.jpg"
                    im.save(out_path, "JPEG", quality=85)
                    kept.append(str(out_path))
                    downscaled += 1
                else:
                    kept.append(str(path))
        except Exception as e:  # noqa: BLE001 解不开的图片直接丢
            dropped += 1
            _note(path, f"画像として開けません（EMF/WMF 等の可能性）: {type(e).__name__}")
            continue

        if len(kept) >= max_assets:
            break

    return {"kept": kept, "dropped": dropped, "deduped": deduped,
            "downscaled": downscaled, "dropped_detail": detail}


# ----------------------------------------------------------------------
# 结构感知切块
# ----------------------------------------------------------------------

def structural_chunks(
    markdown_text: str,
    chunk_chars: int = 6000,
    overlap: int = 500,
    min_informative_chars: int = 80,
) -> List[str]:
    """
    v2 的固定 6000 字符滑窗会把标题和正文腰斩、把不相关章节缝在一起。
    v3 按 Markdown 标题（Docling 对 PPT 输出的每页、对 Word/PDF 的每章节
    都是标题分隔的）切成语义段落，再：
    - 相邻小段落合并到 chunk_chars 上限（减少 LLM 调用次数）
    - 超长段落内部滑窗切分（带 overlap）
    - 信息量过低的块（页码/页眉/空表格残渣）直接丢弃，不浪费调用
    """
    lines = markdown_text.split("\n")
    sections: List[str] = []
    current: List[str] = []
    for line in lines:
        if line.startswith("#") and current:
            sections.append("\n".join(current))
            current = [line]
        else:
            current.append(line)
    if current:
        sections.append("\n".join(current))

    # 合并小节
    merged: List[str] = []
    buf = ""
    for sec in sections:
        if not buf:
            buf = sec
        elif len(buf) + len(sec) + 1 <= chunk_chars:
            buf = buf + "\n" + sec
        else:
            merged.append(buf)
            buf = sec
    if buf:
        merged.append(buf)

    # 超长块滑窗
    chunks: List[str] = []
    for block in merged:
        if len(block) <= chunk_chars:
            chunks.append(block)
            continue
        start = 0
        while start < len(block):
            end = min(start + chunk_chars, len(block))
            chunks.append(block[start:end])
            if end >= len(block):
                break
            start = max(0, end - overlap)

    # 信息量过滤：字母/数字/CJK 计数
    def informative(text: str) -> int:
        return sum(1 for ch in text if ch.isalnum() or "\u3040" <= ch <= "\u9fff" or "\uff66" <= ch <= "\uff9d")

    return [c for c in chunks if informative(c) >= min_informative_chars]


# ----------------------------------------------------------------------
# v3.8：溯源付き・情報欠落を作らない切块
# ----------------------------------------------------------------------
#
# 上の structural_chunks には 3 つの実害があった：
#
# 1. **チャンクが出所を持たない** — 返り値がただの文字列なので、後段の証拠は
#    `text_chunk_0007` としか言えない。人が「根拠情報」欄を見ても検証できず、
#    HITL の修正コストが跳ね上がり、フィードバック飛車が回らない。
# 2. **長い表が腰斬りされる** — 文字数スライドウィンドウなので、表の途中で
#    切れると後半に見出し行が無い。モデルは列名の無い数字の羅列を見ることに
#    なり、「数値の取り違え」の温床になっていた。
# 3. **情報量フィルタが黙って捨てる** — 「タイトル＋重要な数値ひとつ」だけの
#    ページが min_informative_chars に届かず消える。
#
# ここでは挙動を変えつつ**捨てた物を必ず記録**する。精度優先＝既定では
# 何も落とさない（drop_low_info=False）。

_TABLE_SEP_RE = re.compile(r"^\s*\|?[\s:\-|]+\|[\s:\-|]*$")
_PAGE_HEADING_RE = re.compile(
    r"^#+\s*(?:ページ|ペエジ|page|Page|スライド|Slide|シート|Sheet)\s*[:：]?\s*(\d+)", re.I)


def _heading_of(section: str) -> str:
    for line in section.split("\n"):
        if line.startswith("#"):
            return line.lstrip("#").strip()
        if line.strip():
            break
    return ""


def _page_of(section: str) -> Optional[int]:
    """Docling / pdf_text_fallback が出す「# ページ N」等から頁番号を拾う。"""
    for line in section.split("\n")[:3]:
        m = _PAGE_HEADING_RE.match(line.strip())
        if m:
            try:
                return int(m.group(1))
            except ValueError:
                return None
    return None


def _table_header_before(block: str, pos: int) -> str:
    """`pos` が表の内部なら、その表の見出し行＋区切り行を返す。

    Markdown 表は「| a | b |」の次行が「|---|---|」という形。pos より前を
    遡って直近の区切り行を探し、そこから表が途切れずに pos まで続いていれば
    「pos は表の中」と判定する。
    """
    head = block[:pos]
    lines = head.split("\n")
    sep_idx = None
    for i in range(len(lines) - 1, -1, -1):
        ln = lines[i]
        if "|" in ln and _TABLE_SEP_RE.match(ln):
            sep_idx = i
            break
        # 表以外の本文に当たったら、pos は表の中ではない
        if ln.strip() and "|" not in ln:
            return ""
    if sep_idx is None or sep_idx == 0:
        return ""
    # 区切り行の直前が見出し行
    header = lines[sep_idx - 1]
    if "|" not in header:
        return ""
    return f"{header}\n{lines[sep_idx]}\n"


def structural_chunks_traced(
    markdown_text: str,
    chunk_chars: int = 6000,
    overlap: int = 500,
    min_informative_chars: int = 80,
    *,
    drop_low_info: bool = False,
    repeat_table_header: bool = True,
    source_label: str = "",
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """溯源付きチャンク列と、切り捨て報告を返す。

    返り値 chunk の形：
        {text, heading, page, section_index, slice_index, char_start, char_end,
         has_table, table_header_repeated, informative, source_label}
    """
    lines = markdown_text.split("\n")
    sections: List[Tuple[int, str]] = []   # (開始文字オフセット, 本文)
    current: List[str] = []
    cur_start = 0
    offset = 0
    for line in lines:
        if line.startswith("#") and current:
            sections.append((cur_start, "\n".join(current)))
            current = [line]
            cur_start = offset
        else:
            current.append(line)
        offset += len(line) + 1
    if current:
        sections.append((cur_start, "\n".join(current)))

    # 見出し／頁番号は「合併しても最初の節の物を引き継ぐ」
    merged: List[Dict[str, Any]] = []
    buf = ""
    buf_start = 0
    buf_head = ""
    buf_page: Optional[int] = None
    for start, sec in sections:
        if not buf:
            buf, buf_start = sec, start
            buf_head, buf_page = _heading_of(sec), _page_of(sec)
        elif len(buf) + len(sec) + 1 <= chunk_chars:
            buf = buf + "\n" + sec
            if buf_page is None:
                buf_page = _page_of(sec)
        else:
            merged.append({"text": buf, "start": buf_start,
                           "heading": buf_head, "page": buf_page})
            buf, buf_start = sec, start
            buf_head, buf_page = _heading_of(sec), _page_of(sec)
    if buf:
        merged.append({"text": buf, "start": buf_start,
                       "heading": buf_head, "page": buf_page})

    def informative(text: str) -> int:
        return sum(1 for ch in text
                   if ch.isalnum() or "\u3040" <= ch <= "\u9fff" or "\uff66" <= ch <= "\uff9d")

    out: List[Dict[str, Any]] = []
    dropped: List[Dict[str, Any]] = []
    header_repeats = 0

    for si, block in enumerate(merged):
        body = block["text"]
        slices: List[Tuple[int, str, bool]] = []   # (slice_index, text, header_added)
        if len(body) <= chunk_chars:
            slices.append((0, body, False))
        else:
            start = 0
            k = 0
            while start < len(body):
                end = min(start + chunk_chars, len(body))
                piece = body[start:end]
                added = False
                if repeat_table_header and start > 0:
                    hdr = _table_header_before(body, start)
                    if hdr and not piece.lstrip().startswith(hdr.split("\n")[0]):
                        piece = hdr + piece
                        added = True
                        header_repeats += 1
                slices.append((k, piece, added))
                k += 1
                if end >= len(body):
                    break
                start = max(0, end - overlap)

        for k, piece, added in slices:
            info = informative(piece)
            rec = {
                "text": piece,
                "heading": block["heading"],
                "page": block["page"],
                "section_index": si,
                "slice_index": k,
                "char_start": block["start"],
                "char_end": block["start"] + len(block["text"]),
                "has_table": "|" in piece and bool(_find_table_sep(piece)),
                "table_header_repeated": added,
                "informative": info,
                "source_label": source_label,
            }
            if drop_low_info and info < min_informative_chars:
                dropped.append({"heading": block["heading"], "page": block["page"],
                                "informative": info, "preview": piece.strip()[:60]})
                continue
            rec["low_info"] = info < min_informative_chars
            out.append(rec)

    report = {
        "sections": len(sections),
        "merged_blocks": len(merged),
        "produced": len(out) + len(dropped),
        "kept": len(out),
        "dropped_low_info": len(dropped),
        "dropped_detail": dropped[:20],
        "table_header_repeats": header_repeats,
        "low_info_kept": sum(1 for c in out if c.get("low_info")),
    }
    return out, report


def _find_table_sep(text: str) -> bool:
    return any(_TABLE_SEP_RE.match(ln) for ln in text.split("\n") if "|" in ln)


# ----------------------------------------------------------------------
# PDF 视觉提取（v3.2 新增）
# ----------------------------------------------------------------------

def extract_pdf_visuals(
    pdf_path: str,
    out_dir: str,
    max_assets: int = 60,
    extract_embedded: bool = True,
    render_fallback: bool = True,
    render_min_text_chars: int = 120,
    render_scale: float = 2.0,
) -> Dict[str, Any]:
    """
    修复「PDF 输入时 visual asset 为 0」：旧的 LibreOffice→HTML 抽图链路
    对 PDF 基本产不出内容（LibreOffice 不是 PDF 渲染器）。本函数用
    pypdfium2（BSD/Apache 双许可）直接处理：

    1. 内嵌图片对象提取：遍历每页的 IMAGE 对象，还原为 PNG
       （仿真报告里贴的云图/照片/截图都是这类）
    2. 整页渲染兜底：文本字符数 < render_min_text_chars 的页面视为
       "图像型页面"（扫描页/整页图表），整页渲染成图交给 VLM
       ——即使内嵌对象提取失败也不会漏掉视觉信息

    文件名携带页码（pdf_p003_img01.png），天然具备页级溯源。
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    saved: List[str] = []
    pages_rendered = 0
    embedded_found = 0

    try:
        import pypdfium2 as pdfium
        import pypdfium2.raw as pdfium_c
    except ImportError:
        return {"ok": False, "error": "pypdfium2 未安装", "visual_asset_paths": []}

    try:
        pdf = pdfium.PdfDocument(str(pdf_path))
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"PDF 打开失败: {e!r}", "visual_asset_paths": []}

    try:
        n_pages = len(pdf)
        # ---- 路线 1：内嵌图片对象 ----
        if extract_embedded:
            for pno in range(n_pages):
                if len(saved) >= max_assets:
                    break
                try:
                    page = pdf[pno]
                    objs = list(page.get_objects(
                        filter=(pdfium_c.FPDF_PAGEOBJ_IMAGE,), max_depth=2))
                except Exception:  # noqa: BLE001
                    continue
                for i, obj in enumerate(objs):
                    if len(saved) >= max_assets:
                        break
                    try:
                        pil = obj.get_bitmap(render=False).to_pil()
                        p = out / f"pdf_p{pno + 1:03d}_img{i + 1:02d}.png"
                        pil.save(p, "PNG")
                        saved.append(str(p))
                        embedded_found += 1
                    except Exception:  # noqa: BLE001 单个对象坏了不影响其他
                        continue

        # ---- 路线 2：图像型页面整页渲染兜底 ----
        if render_fallback and not saved:
            for pno in range(n_pages):
                if pages_rendered >= max_assets:
                    break
                try:
                    page = pdf[pno]
                    n_chars = page.get_textpage().count_chars()
                    if n_chars >= render_min_text_chars:
                        continue  # 文本充足的页面走文字通道即可
                    pil = page.render(scale=render_scale).to_pil()
                    p = out / f"pdf_p{pno + 1:03d}_page.png"
                    pil.save(p, "PNG")
                    saved.append(str(p))
                    pages_rendered += 1
                except Exception:  # noqa: BLE001
                    continue
    finally:
        pdf.close()

    return {"ok": True, "visual_asset_paths": saved,
            "embedded": embedded_found, "pages_rendered": pages_rendered}


def render_pdf_pages(pdf_path: str, out_dir: str, max_pages: int = 40,
                     scale: float = 2.0) -> Dict[str, Any]:
    """
    v3.6：視覚モデル直読ルート用。**全ページ**を画像化する
    （extract_pdf_visuals の「文字が少ないページだけ」とは意図が違う）。

    Docling を通さないぶん解析時間はほぼゼロになり、代わりに VLM が
    ページそのものを読む。ページ数が多い資料では割高になるので、
    ルート判定側（route_decision）でページ数上限を掛けている。
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    try:
        import pypdfium2 as pdfium
    except ImportError:
        return {"ok": False, "error": "pypdfium2 未安装", "visual_asset_paths": []}
    try:
        pdf = pdfium.PdfDocument(str(pdf_path))
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"PDF 打开失败: {e!r}", "visual_asset_paths": []}

    saved: List[str] = []
    try:
        n_pages = len(pdf)
        for pno in range(min(n_pages, max_pages)):
            try:
                pil = pdf[pno].render(scale=scale).to_pil()
                p = out / f"page_{pno + 1:03d}.png"
                pil.save(p, "PNG")
                saved.append(str(p))
            except Exception:  # noqa: BLE001 1 ページ失敗しても続行
                continue
    finally:
        pdf.close()
    return {"ok": True, "visual_asset_paths": saved,
            "pages_rendered": len(saved), "pages_total": n_pages}


def find_office2pdf(explicit_path: str = "") -> str:
    """office2pdf 実行ファイルを探す。見つからなければ空文字。

    office2pdf は Rust 製の単一バイナリ（Apache-2.0）で、DOCX/XLSX/PPTX を
    Typst 経由で PDF 化する。LibreOffice も Chromium も JRE も要らないので、
    ライセンス上 LibreOffice が使えず Office COM も不安定な環境における
    唯一の現実的な「頁画像化」手段になる。

    探索順（先に見つかった物を使う）：
      1. config の workflow.office2pdf_path（明示指定）
      2. 環境変数 OFFICE2PDF_PATH
      3. 同梱先 tools/bin/office2pdf[.exe]（配布時はここに置く想定）
      4. PATH 上の office2pdf
    """
    import os
    import shutil

    for cand in (explicit_path, os.environ.get("OFFICE2PDF_PATH", "")):
        if cand and Path(cand).is_file():
            return str(Path(cand).resolve())

    exe = "office2pdf.exe" if os.name == "nt" else "office2pdf"
    bundled = PROJECT_ROOT / "tools" / "bin" / exe
    if bundled.is_file():
        return str(bundled.resolve())

    found = shutil.which("office2pdf")
    return found or ""


def _office2pdf_convert(input_path: str, out_dir: str, exe: str,
                        font_path: str = "", timeout: int = 300) -> Dict[str, Any]:
    """office2pdf バイナリを叩いて PDF を作る。"""
    import subprocess

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    src = Path(input_path).resolve()
    pdf_path = out / f"{src.stem}.pdf"

    cmd = [exe, str(src), "-o", str(pdf_path)]
    # 日本語フォントを明示できる。埋め込みフォントは office2pdf 側が
    # 自動抽出するが、埋め込みが無い資料では OS のフォントに頼るしかない。
    if font_path and Path(font_path).is_dir():
        cmd += ["--font-path", str(Path(font_path).resolve())]

    try:
        proc = subprocess.run(cmd, capture_output=True, timeout=timeout)
    except FileNotFoundError:
        return {"ok": False, "engine": "office2pdf",
                "error": f"office2pdf が実行できません: {exe}"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "engine": "office2pdf",
                "error": f"office2pdf 実行失敗: {e!r}"}

    if not pdf_path.exists() or pdf_path.stat().st_size == 0:
        detail = (proc.stderr or b"").decode("utf-8", "ignore").strip()[:300]
        return {"ok": False, "engine": "office2pdf",
                "error": f"PDF 出力なし (rc={proc.returncode}) {detail}"}
    return {"ok": True, "pdf_path": str(pdf_path), "engine": "office2pdf"}


def office_to_pdf(input_path: str, out_dir: str, timeout: int = 300,
                  office2pdf_path: str = "", office2pdf_font_path: str = "",
                  use_office2pdf: bool = True) -> Dict[str, Any]:
    """
    Office → PDF。視覚直読ルートで「スライド１枚＝画像１枚」を得るための前段。

    v3.10：**Office COM を第一手段にした**。v3.9 までは LibreOffice 一択で、
    LibreOffice が入っていない Windows 機では必ず失敗し、視覚ルートが
    埋め込み画像だけを見る状態に静かに落ちていた（エラーにならないので
    気付きにくい）。Excel は既に COM で処理しているのに PowerPoint と Word
    だけ外部アプリ依存というのは筋が通らない。

    v3.11：**office2pdf（Rust 単一バイナリ・Apache-2.0）を第二手段に挿した**。
    現場の制約が「PowerPoint/Word COM は不安定で使えない・LibreOffice は
    ライセンス上不可・商用ライブラリ不可・クラウド変換不可」と確定したため、
    COM と LibreOffice の間に純粋なローカル変換器が要る。これが無いと
    PPTX/DOCX は頁画像化を諦めて埋め込み画像だけを見る縮退状態から
    永久に抜けられない。

    優先順：
      1. PowerPoint / Word COM（Office が入っていれば最も忠実。旧 .ppt/.doc も可）
      2. office2pdf（外部アプリ不要。COM が死んでいる環境の主戦力）
      3. LibreOffice headless（従来の後方互換。入っていれば使う）

    全部駄目なら ok=False を返し、呼び出し側は埋め込み画像の抽出
    （extract_office_visuals）へフォールバックする。
    """
    import subprocess

    from tools.visual_asset_tools import find_soffice

    # ---- 1) Office COM ----
    try:
        from tools.office_com import office_com_available_for, office_to_pdf_com
        if office_com_available_for(Path(input_path).suffix):
            res = office_to_pdf_com(input_path, out_dir, timeout_seconds=float(timeout))
            if res.get("ok"):
                res["engine"] = "office_com"
                return res
            com_error = res.get("error", "")
        else:
            com_error = "Office COM が利用できません"
    except Exception as e:  # noqa: BLE001 COM 側の想定外で後続手段を諦めない
        com_error = f"{type(e).__name__}: {e}"

    # ---- 2) office2pdf（Rust 単一バイナリ）----
    o2p_error = "office2pdf は無効化されています"
    if use_office2pdf:
        exe = find_office2pdf(office2pdf_path)
        if exe:
            res = _office2pdf_convert(input_path, out_dir, exe,
                                      font_path=office2pdf_font_path, timeout=timeout)
            if res.get("ok"):
                return res
            o2p_error = str(res.get("error", ""))
        else:
            o2p_error = "office2pdf バイナリが見つかりません"

    # ---- 3) LibreOffice headless ----
    soffice = find_soffice()
    if not soffice:
        return {"ok": False, "engine": "",
                "error": f"PDF 変換手段がありません（COM: {com_error} / "
                         f"office2pdf: {o2p_error} / "
                         f"LibreOffice(soffice) も見つかりません）"}
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    src = Path(input_path).resolve()
    try:
        proc = subprocess.run(
            [soffice, "--headless", "--norestore", "--convert-to", "pdf",
             "--outdir", str(out), str(src)],
            capture_output=True, timeout=timeout,
        )
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "engine": "libreoffice",
                "error": f"LibreOffice 実行失敗: {e!r}"}
    pdf_path = out / f"{src.stem}.pdf"
    if not pdf_path.exists():
        return {"ok": False, "engine": "libreoffice",
                "error": f"PDF 出力なし (rc={proc.returncode})"}
    return {"ok": True, "pdf_path": str(pdf_path), "engine": "libreoffice"}


def pdf_text_fallback(pdf_path: str) -> str:
    """降级路径：Docling 不可用/崩溃时，用 pypdfium2 文本层直接抽取。
    没有布局分析和表格结构（质量下降），但保证流水线不因解析层单点故障而死。
    每页前加页标记，保留最低限度的结构与页级溯源。"""
    try:
        import pypdfium2 as pdfium
    except ImportError:
        return ""
    try:
        pdf = pdfium.PdfDocument(str(pdf_path))
    except Exception:  # noqa: BLE001
        return ""
    parts: List[str] = []
    try:
        for pno in range(len(pdf)):
            try:
                tp = pdf[pno].get_textpage()
                text = tp.get_text_range()
                if text.strip():
                    parts.append(f"# ページ {pno + 1}\n\n{text.strip()}")
            except Exception:  # noqa: BLE001
                continue
    finally:
        pdf.close()
    return "\n\n".join(parts)


# ----------------------------------------------------------------------
# Office 视觉提取（v3.5 修复：不再依赖 LibreOffice→HTML）
# ----------------------------------------------------------------------

_OFFICE_MEDIA_DIRS = ("ppt/media/", "word/media/", "xl/media/")
_IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tiff", ".emf", ".wmf")


_R_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
_REL_NS = "{http://schemas.openxmlformats.org/package/2006/relationships}"


def _ooxml_media_page_map(zf) -> Dict[str, int]:
    """media/ の画像ファイル名 → 何ページ目に置かれているか、の対応表を作る。

    v3.9 まで OOXML 由来の画像は頁番号を一切持っていなかった。ファイル名は
    `office_image3.png` で、これがどのスライドの図なのか誰にも分からない。
    そのせいで、
      - 精読モードが PPTX に対して事実上効かない（本文と図を同じ頁で
        突き合わせられない）
      - 枚数上限で切り捨てるとき「文書の後半」ではなく「辞書順で後ろ」が
        消える（image1, image10, image11, image2… の順で並ぶため）
    という実害が出ていた。

    OOXML は関係（relationship）を辿れば復元できる：

        ppt/slides/slide3.xml          … <a:blip r:embed="rId2"/>
        ppt/slides/_rels/slide3.xml.rels … rId2 -> ../media/image7.png

    つまり「スライド N が参照している rId」→「その rId が指す media」を
    合成すれば media → N が得られる。同じ画像が複数頁で使い回されている
    場合は**最初に現れた頁**を採る（切り捨て順を文書順に近づけるのが目的
    なので、最初の出現で十分）。

    Word には頁の概念が無いので、document.xml 内の出現順を 1 始まりの
    連番として返す（絶対的な頁ではないが、順序が保てるだけで価値がある）。
    """
    import re as _re
    import xml.etree.ElementTree as ET

    names = set(zf.namelist())
    mapping: Dict[str, int] = {}

    def _rels_for(part: str) -> Dict[str, str]:
        """part（例 ppt/slides/slide3.xml）の .rels を rId -> media 名で返す。"""
        rel_path = f"{Path(part).parent.as_posix()}/_rels/{Path(part).name}.rels"
        if rel_path not in names:
            return {}
        out: Dict[str, str] = {}
        try:
            root = ET.fromstring(zf.read(rel_path))
        except Exception:  # noqa: BLE001 壊れた rels は諦める
            return {}
        for rel in root:
            rid = rel.get("Id") or ""
            target = (rel.get("Target") or "").replace("\\", "/")
            if rid and "media/" in target:
                out[rid] = target.rsplit("/", 1)[-1]
        return out

    # ---- PowerPoint：スライド番号がそのまま頁 ----
    slide_parts = sorted(
        (n for n in names if _re.fullmatch(r"ppt/slides/slide(\d+)\.xml", n)),
        key=lambda n: int(_re.search(r"slide(\d+)\.xml", n).group(1)))
    for part in slide_parts:
        page = int(_re.search(r"slide(\d+)\.xml", part).group(1))
        rels = _rels_for(part)
        if not rels:
            continue
        try:
            body = zf.read(part).decode("utf-8", errors="ignore")
        except Exception:  # noqa: BLE001
            continue
        # r:embed / r:link どちらの参照形式も拾う
        for rid in set(_re.findall(r'r:(?:embed|link)="([^"]+)"', body)):
            media = rels.get(rid)
            if media and media not in mapping:
                mapping[media] = page

    # ---- Word：頁が無いので出現順を連番にする ----
    if "word/document.xml" in names:
        rels = _rels_for("word/document.xml")
        if rels:
            try:
                body = zf.read("word/document.xml").decode("utf-8", errors="ignore")
                seq = 0
                for m in _re.finditer(r'r:(?:embed|link)="([^"]+)"', body):
                    media = rels.get(m.group(1))
                    if media and media not in mapping:
                        seq += 1
                        mapping[media] = seq
            except Exception:  # noqa: BLE001
                pass

    return mapping


def extract_office_visuals(input_path: str, out_dir: str,
                           max_assets: int = 60) -> Dict[str, Any]:
    """
    PPTX/DOCX/XLSX 本质是 ZIP，嵌入图片原封不动躺在 media/ 目录里。
    直接解包提取 = 拿到**原始分辨率原图**，零 LibreOffice 依赖、零转换损耗。
    （旧链路 LibreOffice→HTML 在新版 LO 上会把图片内联成 data: URI，
    v1 的解析代码将其当作文件路径而崩溃，v3 的 try/except 又把崩溃吞成
    "0 资产"——这就是 Office 输入图片静默丢失的根因。）
    EMF/WMF 矢量图会尽力用 Pillow 转 PNG，转不动则跳过。
    旧格式 .ppt/.doc/.xls 不是 ZIP，返回 ok=False 由调用方走 LibreOffice 兜底。
    """
    import zipfile

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    src = Path(input_path)
    if not zipfile.is_zipfile(src):
        return {"ok": False, "error": "非 OOXML（旧二进制格式？）", "visual_asset_paths": []}

    saved: List[str] = []
    skipped_vector = 0
    page_map: Dict[str, int] = {}
    try:
        with zipfile.ZipFile(src) as zf:
            page_map = _ooxml_media_page_map(zf)
            names = [n for n in zf.namelist()
                     if any(n.startswith(d) for d in _OFFICE_MEDIA_DIRS)
                     and n.lower().endswith(_IMAGE_SUFFIXES)]

            # v3.10：**文書順**に並べる。以前は sorted() の辞書順だったため
            # image1, image10, image11, image2… となり、枚数上限で切り捨てる
            # 際に「文書の後半」ではなく「辞書順で後ろ」が消えていた。
            # 頁が分かる物を頁順に、分からない物はその後ろに置く。
            def _order(n: str):
                base = Path(n).name
                page = page_map.get(base)
                # 頁不明は末尾へ。同じ頁の中はファイル名内の数値で安定させる
                num = int("".join(ch for ch in Path(base).stem if ch.isdigit()) or 0)
                return (page if page is not None else 10 ** 6, num, base)

            for name in sorted(names, key=_order):
                if len(saved) >= max_assets:
                    break
                data = zf.read(name)
                stem = Path(name).name
                suffix = Path(name).suffix.lower()
                # 頁が判っていればファイル名に埋める（_asset_provenance が復元する）
                page = page_map.get(stem)
                prefix = f"office_p{page:03d}_" if page is not None else "office_"
                if suffix in (".emf", ".wmf", ".tiff", ".bmp", ".gif"):
                    # 统一转 PNG（VLM 端点普遍只吃 png/jpg/webp）
                    try:
                        import io
                        from PIL import Image
                        with Image.open(io.BytesIO(data)) as im:
                            p = out / f"{prefix}{Path(stem).stem}.png"
                            im.convert("RGB").save(p, "PNG")
                            saved.append(str(p))
                    except Exception:  # noqa: BLE001 EMF/WMF Pillow 多半打不开
                        skipped_vector += 1
                    continue
                p = out / f"{prefix}{stem}"
                p.write_bytes(data)
                saved.append(str(p))
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"ZIP 解析失败: {e!r}", "visual_asset_paths": saved}

    return {"ok": True, "visual_asset_paths": saved,
            "embedded": len(saved), "skipped_vector": skipped_vector,
            # 頁が辿れた枚数。0 なら関係の解決に失敗している（精読モードが効かない）
            "pages_mapped": sum(1 for x in saved
                                if Path(x).name.startswith("office_p"))}


# =====================================================================
# v3.12：画像が密集した頁の圧縮 ＆ 埋め込み画像への本文文脈付与
# =====================================================================

def build_page_text_index(markdown_path: str, per_page_chars: int = 500) -> Dict[int, str]:
    """Markdown を頁番号 -> 冒頭テキストの辞書にする。

    埋め込み画像を VLM に送るとき、従来は asset_index しか添えていなかった。
    「12.3」と曲線だけの図を単位も対象も分からないまま読ませていたわけで、
    同じ頁の本文を少し渡すだけで取り違えが目に見えて減る。

    **本文チェーンの chunks は使えない**ことに注意。chunk_text と
    collect_visuals は並行分岐なので、視覚側が読む時点で chunks が
    出来ている保証が無い。両分岐の上流にある Markdown を直接読む。
    """
    index: Dict[int, str] = {}
    try:
        text = Path(markdown_path).read_text(encoding="utf-8", errors="ignore")
    except Exception:  # noqa: BLE001 本文が無くても視覚側は動く
        return index

    cur_page: Optional[int] = None
    buf: List[str] = []

    def _flush() -> None:
        if cur_page is None:
            return
        body = "\n".join(buf).strip()
        if not body:
            return
        prev = index.get(cur_page, "")
        if len(prev) < per_page_chars:
            index[cur_page] = (prev + "\n" + body).strip()[:per_page_chars]

    for line in text.split("\n"):
        m = _PAGE_HEADING_RE.match(line.strip())
        if m:
            _flush()
            buf = []
            try:
                cur_page = int(m.group(1))
            except ValueError:
                cur_page = None
            continue
        buf.append(line)
    _flush()
    return index


def make_contact_sheets(image_paths: List[str], out_dir: str, page: Optional[int],
                        cols: int = 3, max_edge_px: int = 2048,
                        max_cells: int = 12) -> List[Dict[str, Any]]:
    """複数の画像を連番ラベル付きの格子画像に合成する。

    密集頁を 1 枚ずつ読ませると、文脈の無い所見が量産されるだけで時間が
    枚数に比例して増える。1 枚に束ねれば VLM 呼び出しは 1 回で済み、
    しかもモデルは並んだ画像同士を見比べられる（系列データの羅列や
    実験画像の並列では、むしろこちらの方が正しく読める）。

    返り値は [{"path": 合成画像, "members": [元パス...]}, ...]。
    max_cells を超える分は次のシートへ回す（切り捨てない）。
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return []

    sheets: List[Dict[str, Any]] = []
    groups = [image_paths[i:i + max_cells] for i in range(0, len(image_paths), max_cells)]

    for gi, group in enumerate(groups):
        loaded = []
        for p in group:
            try:
                im = Image.open(p)
                im.load()
                loaded.append((p, im.convert("RGB")))
            except Exception:  # noqa: BLE001 開けない画像は飛ばす
                continue
        if not loaded:
            continue

        n = len(loaded)
        ncols = max(1, min(cols, n))
        nrows = (n + ncols - 1) // ncols
        # セル寸法は長辺上限から逆算する（合成後に縮小すると文字が潰れるため、
        # 最初から収まる大きさで貼る）
        label_h = 22
        cell_w = max(120, max_edge_px // ncols)
        cell_h = max(120, cell_w * 3 // 4)

        sheet = Image.new("RGB", (cell_w * ncols, (cell_h + label_h) * nrows), "white")
        draw = ImageDraw.Draw(sheet)
        members: List[str] = []

        for i, (src, im) in enumerate(loaded):
            r, c = divmod(i, ncols)
            box_x, box_y = c * cell_w, r * (cell_h + label_h)
            draw.text((box_x + 4, box_y + 4), f"[{i + 1}] {Path(src).name[:34]}",
                      fill="black")
            im.thumbnail((cell_w - 8, cell_h - 8))
            sheet.paste(im, (box_x + 4 + (cell_w - 8 - im.width) // 2,
                             box_y + label_h + (cell_h - im.height) // 2))
            members.append(src)

        if max(sheet.size) > max_edge_px:
            sc = max_edge_px / max(sheet.size)
            sheet = sheet.resize((int(sheet.width * sc), int(sheet.height * sc)))

        tag = f"p{page:03d}" if page else f"g{gi + 1:02d}"
        path = out / f"contact_{tag}_{gi + 1:02d}.png"
        sheet.save(path, "PNG")
        sheets.append({"path": str(path), "members": members, "count": len(members),
                       "page": page})
    return sheets
