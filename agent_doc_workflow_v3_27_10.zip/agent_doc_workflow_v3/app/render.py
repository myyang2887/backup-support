"""
Markdown 渲染。

v1 的 bug 来源就在这层：template.render(**data) 只暴露顶层 key，
模板却引用扁平变量名 -> 全部 fallback 到 default("明記なし")。

v2 的防御：
1. 模板输入直接来自 CaseSummary（契约对象），字段名不可能错。
2. StrictUndefined：模板引用不存在的变量时立刻抛异常，而不是静默渲染空值。
   （v1 如果用了 StrictUndefined，这个 bug 在第一次运行就会炸出来）
3. verify_template()：用 jinja2.meta 静态解析模板引用的顶层变量，
   和契约字段比对，启动时/测试里就能发现漂移。
"""
from __future__ import annotations

from pathlib import Path
from typing import Set

from jinja2 import Environment, StrictUndefined, meta

from .contract import CaseSummary

_env = Environment(undefined=StrictUndefined, trim_blocks=True, lstrip_blocks=True)


def render_markdown(summary: CaseSummary, template_path: str, output_path: str) -> str:
    template_text = Path(template_path).read_text(encoding="utf-8")
    template = _env.from_string(template_text)
    rendered = template.render(**summary.model_dump(mode="json"))
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(rendered, encoding="utf-8")
    return rendered


def verify_template_for_model(template_path: str, model) -> Set[str]:
    """注册表版：模板引用的顶层变量必须是给定契约模型的字段。"""
    template_text = Path(template_path).read_text(encoding="utf-8")
    ast = _env.parse(template_text)
    used = meta.find_undeclared_variables(ast)
    return used - set(model.model_fields.keys())


def verify_template(template_path: str) -> Set[str]:
    """
    静态校验：模板引用的所有顶层变量必须是 CaseSummary 的字段。
    返回非法变量集合（空集合 = 通过）。在 webapp 启动和单元测试里都会调用。
    """
    template_text = Path(template_path).read_text(encoding="utf-8")
    ast = _env.parse(template_text)
    used = meta.find_undeclared_variables(ast)
    allowed = set(CaseSummary.model_fields.keys())
    return used - allowed
