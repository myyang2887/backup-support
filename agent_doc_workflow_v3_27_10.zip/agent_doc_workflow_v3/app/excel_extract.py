"""
Excel 抽出（v3.7 新增）。

## なぜ専用モジュールが要るのか

Excel は「セルの升目」だけ読んでも中身が取れない、という点で PDF/PPT と根本的に違う：

| 中身 | どこに在るか | openpyxl で見えるか |
|---|---|---|
| 通常のセル | worksheet XML | ○ |
| **数式の計算結果** | worksheet XML の `<v>`（Excel が保存時にキャッシュ） | `data_only=True` のときだけ。未計算なら `None` |
| **グラフ** | `xl/charts/chartN.xml`（ベクタ定義） | 画像ではない。**`xl/media/` には無い** |
| **ピボットテーブル** | 表示セルは worksheet に、定義は `xl/pivotTables/` | 値は見えるが「何の集計か」は見えない |
| **外部データ接続** | `xl/externalLinks/`、Power Pivot はデータモデル | キャッシュ分のみ。モデル内のデータは見えない |
| VBA マクロ | `xl/vbaProject.bin` | 中身は無関係（が、開くと動く危険がある） |

つまり v3.6 までの「`xl/media/` から画像を拾う」経路では、**グラフだけの
ワークシートは視覚資産ゼロ**になり、Agent 2 に渡す物が何も無かった。
これが「大型 xlsm が処理できない」の主因のひとつ。

## この モジュールの方針

Excel 無し（Linux／Excel 未インストール）でも動く純 Python 経路を本命に据える：

1. セル値は `data_only=True` で読む（数式そのものではなく**計算結果**）
2. **グラフは `numCache` から実データを復元**してテキスト表にする。
   ——ローカルの弱いモデル（Gemma 4 級）に「画像を見て軸を読め」と要求するより、
   数値表を直接渡す方が桁違いに確実。これが設計上の肝。
3. ピボット／外部リンク／マクロの存在は**明示的に注記**する
   （見えていない物があると分かるだけで、人の確認コストが下がる）

Windows + Excel がある環境では `tools/excel_com.py` が PDF とグラフ画像を
追加で作り、v3.6 の視覚ルートに載せる。こちらは"上乗せ"であって前提ではない。
"""
from __future__ import annotations

import re
import zipfile
from pathlib import Path

from .cell_format import analyze_column, cell_to_text, cell_to_text_in_column
from typing import Any, Dict, List, Optional, Tuple
from xml.etree import ElementTree as ET

_NS_C = "{http://schemas.openxmlformats.org/drawingml/2006/chart}"
_NS_A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"

# 1 シートあたりの取り込み上限（巨大ブック対策）
MAX_ROWS_PER_SHEET = 400
MAX_COLS_PER_SHEET = 40
MAX_CHART_POINTS = 60


# ----------------------------------------------------------------------
# グラフ：chartN.xml のキャッシュから実データを復元する
# ----------------------------------------------------------------------

def _cache_values(node) -> List[str]:
    """`c:strCache` / `c:numCache` の `c:pt` を idx 順に並べて返す。"""
    if node is None:
        return []
    pts: List[Tuple[int, str]] = []
    for cache in (node.find(f".//{_NS_C}strCache"), node.find(f".//{_NS_C}numCache")):
        if cache is None:
            continue
        for pt in cache.findall(f"{_NS_C}pt"):
            v = pt.find(f"{_NS_C}v")
            try:
                idx = int(pt.get("idx", "0"))
            except ValueError:
                idx = 0
            pts.append((idx, (v.text or "").strip() if v is not None else ""))
    pts.sort(key=lambda x: x[0])
    return [v for _, v in pts][:MAX_CHART_POINTS]


def _ref_formula(node) -> str:
    """キャッシュが無いとき用：参照範囲（`解析結果!$B$2:$B$4`）だけでも残す。
    openpyxl 等が生成したブックはキャッシュを持たないことがある一方、
    Excel が保存したブックは必ず持つ。両方に耐えるための保険。"""
    if node is None:
        return ""
    f = node.find(f".//{_NS_C}f")
    return (f.text or "").strip() if f is not None else ""


def _text_of(node) -> str:
    if node is None:
        return ""
    return "".join(t.text or "" for t in node.iter(f"{_NS_A}t")).strip()


def parse_chart_xml(xml_bytes: bytes) -> Dict[str, Any]:
    """1 つのグラフ定義から タイトル / 系列名 / カテゴリ / 値 を取り出す。"""
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError:
        return {}
    title = _text_of(root.find(f".//{_NS_C}title"))
    kinds = sorted({el.tag.replace(_NS_C, "").replace("Chart", "")
                    for el in root.iter() if el.tag.endswith("Chart")})
    series: List[Dict[str, Any]] = []
    categories: List[str] = []
    for ser in root.iter(f"{_NS_C}ser"):
        tx, cat, val = (ser.find(f"{_NS_C}tx"), ser.find(f"{_NS_C}cat"),
                        ser.find(f"{_NS_C}val"))
        name = _cache_values(tx)
        cats = _cache_values(cat)
        vals = _cache_values(val)
        if cats and not categories:
            categories = cats
        series.append({
            "name": (name[0] if name else (_ref_formula(tx) or f"系列{len(series) + 1}")),
            "values": vals,
            # キャッシュが無い場合は参照範囲を控える（後段で「どの範囲の図か」を示す）
            "ref": "" if vals else _ref_formula(val),
        })
    if not categories:
        cat_ref = next((_ref_formula(s.find(f"{_NS_C}cat"))
                        for s in root.iter(f"{_NS_C}ser")), "")
        if cat_ref:
            categories = []
    return {"title": title, "types": kinds, "categories": categories, "series": series}


def chart_to_markdown(chart: Dict[str, Any], index: int) -> str:
    """復元したグラフデータを、そのまま証拠抽出に食わせられる表にする。"""
    if not chart:
        return ""
    head = chart.get("title") or f"グラフ {index}"
    kind = "・".join(chart.get("types") or []) or "unknown"
    lines = [f"### グラフ: {head}", "", f"（種類: {kind}）", ""]
    series = chart.get("series") or []
    cats = chart.get("categories") or []
    if not series:
        return "\n".join(lines) + "\n"
    if cats:
        header = ["項目"] + [s["name"] for s in series]
        lines.append("| " + " | ".join(header) + " |")
        lines.append("|" + "---|" * len(header))
        for i, cat in enumerate(cats):
            row = [cat] + [(s["values"][i] if i < len(s["values"]) else "") for s in series]
            lines.append("| " + " | ".join(row) + " |")
    else:
        for s in series:
            if s.get("values"):
                lines.append(f"- {s['name']}: " + ", ".join(s["values"]))
            elif s.get("ref"):
                # 数値キャッシュが無いブック：どの範囲を描いた図かだけでも伝える
                lines.append(f"- {s['name']}: 参照範囲 {s['ref']}（数値キャッシュなし）")
            else:
                lines.append(f"- {s['name']}")
    return "\n".join(lines) + "\n"


def extract_charts(path: str | Path) -> List[Dict[str, Any]]:
    """ブック内の全グラフ定義（`xl/charts/chartN.xml`）を読む。"""
    src = Path(path)
    if not zipfile.is_zipfile(src):
        return []
    out: List[Dict[str, Any]] = []
    try:
        with zipfile.ZipFile(src) as zf:
            names = sorted(n for n in zf.namelist()
                           if re.match(r"xl/charts/chart\d+\.xml$", n))
            for n in names:
                chart = parse_chart_xml(zf.read(n))
                if chart and (chart.get("series") or chart.get("title")):
                    out.append(chart)
    except Exception:  # noqa: BLE001 壊れたブックでも他の経路を生かす
        return out
    return out


# ----------------------------------------------------------------------
# ブックの構造検査（何が「見えていない」かを利用者に伝える）
# ----------------------------------------------------------------------

def inspect_workbook(path: str | Path) -> Dict[str, Any]:
    src = Path(path)
    info: Dict[str, Any] = {"charts": 0, "pivot_tables": 0, "external_links": 0,
                            "has_vba": False, "media_images": 0, "data_model": False,
                            "sheets": 0, "size_mb": 0.0}
    try:
        info["size_mb"] = round(src.stat().st_size / (1024 * 1024), 2)
    except OSError:
        pass
    if not zipfile.is_zipfile(src):
        return info
    try:
        with zipfile.ZipFile(src) as zf:
            names = zf.namelist()
    except Exception:  # noqa: BLE001
        return info
    info["charts"] = sum(1 for n in names if re.match(r"xl/charts/chart\d+\.xml$", n))
    info["pivot_tables"] = sum(1 for n in names if n.startswith("xl/pivotTables/pivotTable"))
    info["external_links"] = sum(1 for n in names if n.startswith("xl/externalLinks/externalLink"))
    info["has_vba"] = any(n == "xl/vbaProject.bin" for n in names)
    info["media_images"] = sum(1 for n in names if n.startswith("xl/media/"))
    info["data_model"] = any("model" in n.lower() and n.startswith("xl/") for n in names)
    info["sheets"] = sum(1 for n in names if re.match(r"xl/worksheets/sheet\d+\.xml$", n))
    return info


def notes_for(info: Dict[str, Any]) -> List[str]:
    """人向けの注記。「取れなかった物」を黙って捨てないための可視化。"""
    notes: List[str] = []
    if info.get("pivot_tables"):
        notes.append(f"ピボットテーブル {info['pivot_tables']} 個：シート上の表示値は読めますが、"
                     "集計の定義（行/列/値フィールド）までは復元していません")
    if info.get("external_links"):
        notes.append(f"外部データリンク {info['external_links']} 件：最後に保存された"
                     "キャッシュ値のみ読めます（最新化には Excel での再取得が必要）")
    if info.get("data_model"):
        notes.append("データモデル（Power Pivot）を検出：モデル内のデータはシートに"
                     "現れないため取得できません")
    if info.get("has_vba"):
        notes.append("VBA マクロを含むブックです（マクロは実行せず内容のみ読み取ります）")
    if info.get("size_mb", 0) >= 20:
        notes.append(f"大型ブック（{info['size_mb']} MB）：シートごとに "
                     f"{MAX_ROWS_PER_SHEET} 行 × {MAX_COLS_PER_SHEET} 列までを取り込みます")
    return notes


# ----------------------------------------------------------------------
# 本体：ブック → Markdown
# ----------------------------------------------------------------------

def _cell_text(value: Any, number_format: Optional[str] = None) -> str:
    """セル値を文字列にする。

    v3.24：日付の正規化を app/cell_format.py に集約した。台帳側と本文側で
    別々の変換をしていると、同じ列が経路によって違う形で要約に出てしまう。
    `number_format` を渡せる呼び出し元は必ず渡すこと——書式だけが日付で
    データは数値（シリアル値）のセルは、これが無いと救えない。
    """
    return cell_to_text(value, number_format)


def workbook_to_markdown(path: str | Path,
                         max_rows: int = MAX_ROWS_PER_SHEET,
                         max_cols: int = MAX_COLS_PER_SHEET) -> Dict[str, Any]:
    """
    .xlsx/.xlsm を Markdown 化する。

    ポイントは `data_only=True`：既定の openpyxl は数式セルに対して
    `'=SUM(B2:B4)'` という**文字列**を返す。要約に必要なのは計算結果の方なので、
    キャッシュ値を読む。Excel が計算結果を保存していない場合は None になるため、
    その場合だけ数式そのものを添えて「何を計算した欄か」を残す。
    """
    src = Path(path)
    info = inspect_workbook(src)
    parts: List[str] = [f"# {src.stem}", ""]
    errors: List[str] = []

    try:
        import openpyxl
    except ImportError:
        return {"ok": False, "error": "openpyxl 未安装", "markdown": "", "info": info}

    try:
        wb_values = openpyxl.load_workbook(src, data_only=True, read_only=True)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"openpyxl で開けません: {e!r}",
                "markdown": "", "info": info}

    wb_formulas = None
    try:                                   # 数式は補助情報。開けなくても致命ではない
        wb_formulas = openpyxl.load_workbook(src, data_only=False, read_only=True)
    except Exception:  # noqa: BLE001
        pass

    try:
        for ws in wb_values.worksheets:
            if ws.sheet_state != "visible":
                continue
            rows_md: List[str] = []
            n_cols = 0
            # v3.24：values_only を外して表示書式も読む。書式が分からないと、
            # 書式だけが日付でデータは数値（シリアル値）のセルを救えない。
            # v3.25：さらに列単位で日付列かどうかを判定する。結合台帳では
            # 同じ列でも行によって保存され方が違い、書式が落ちた行が混ざる。
            _grid = list(ws.iter_rows(max_row=max_rows, max_col=max_cols))
            _ncol = max((len(r) for r in _grid), default=0)
            _col_infos = []
            for ci in range(_ncol):
                _col_infos.append(analyze_column(
                    [r[ci].value if ci < len(r) else None for r in _grid],
                    [getattr(r[ci], "number_format", None) if ci < len(r) else None
                     for r in _grid]))
            for r, row in enumerate(_grid):
                cells = [cell_to_text_in_column(
                             c.value, getattr(c, "number_format", None),
                             _col_infos[ci] if ci < len(_col_infos) else None)
                         for ci, c in enumerate(row)]
                while cells and not cells[-1]:
                    cells.pop()
                if not cells:
                    continue
                n_cols = max(n_cols, len(cells))
                rows_md.append(cells)
            if not rows_md:
                continue
            parts.append(f"## シート: {ws.title}")
            parts.append("")
            width = min(n_cols, max_cols)
            header = rows_md[0] + [""] * (width - len(rows_md[0]))
            parts.append("| " + " | ".join(header[:width]) + " |")
            parts.append("|" + "---|" * width)
            for cells in rows_md[1:]:
                padded = cells + [""] * (width - len(cells))
                parts.append("| " + " | ".join(padded[:width]) + " |")
            parts.append("")
    except Exception as e:  # noqa: BLE001
        errors.append(f"シート読み取りで中断: {e!r}")
    finally:
        try:
            wb_values.close()
        except Exception:  # noqa: BLE001
            pass

    # 数式は「何を計算しているか」の手掛かりとして少量だけ添える
    if wb_formulas is not None:
        try:
            formulas: List[str] = []
            for ws in wb_formulas.worksheets:
                if ws.sheet_state != "visible":
                    continue
                for row in ws.iter_rows(max_row=max_rows, max_col=max_cols):
                    for cell in row:
                        v = cell.value
                        if isinstance(v, str) and v.startswith("=") and len(formulas) < 30:
                            formulas.append(f"- {ws.title}!{cell.coordinate}: `{v[:120]}`")
            if formulas:
                parts += ["## 主な数式", ""] + formulas + [""]
        except Exception:  # noqa: BLE001
            pass
        finally:
            try:
                wb_formulas.close()
            except Exception:  # noqa: BLE001
                pass

    charts = extract_charts(src)
    if charts:
        parts.append("## グラフ（定義から復元した数値）")
        parts.append("")
        for i, ch in enumerate(charts, 1):
            parts.append(chart_to_markdown(ch, i))

    notes = notes_for(info)
    if notes:
        parts += ["## 取り込みに関する注記", ""] + [f"- {n}" for n in notes] + [""]

    return {"ok": True, "markdown": "\n".join(parts), "info": info,
            "charts": len(charts), "notes": notes, "errors": errors}
