"""
对外介绍网站构建 agent（v3.4）。

安全架构（刻意的保守选择）：
- **数据源只有社外层**：台账中已完成且存在 case_summary_external.json 的 run。
  社内层数据物理上不进入本模块。
- **产出是纯静态 HTML**：公开站点上没有任何运行时 LLM——LLM 只在构建时
  写介绍文案与案例导语，产物可整体人工审阅后再发布，攻击面为零。
- **出口泄漏闸**：所有生成的 HTML 在落盘前用 NG 词典整体复扫，
  命中任何原词立即中止构建（宁可不发布，绝不带敏感词上线）。
- **可追加**：构建幂等——每次从台账全量重建，新案件跑完后重按一次
  「サイト生成」即为追加。build_report.json 留痕。

产出目录 out/site/ ：index.html + cases/<run_id>.html + style.css。
发布 = 人工确认预览后，把该目录拷到任意静态托管（部门 Web 服务器等）。
"""
from __future__ import annotations

import html
import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from .redaction import NGDictionary, scan_leaks

_CSS = """
:root{--ink:#1e2430;--muted:#6b7280;--accent:#0f6b5c;--bg:#f6f5f1;--line:#e4e1d8}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);
font-family:"Hiragino Sans","Yu Gothic UI","Noto Sans JP",sans-serif;line-height:1.8}
header{background:#fff;border-bottom:3px solid var(--accent);padding:28px 8vw}
header h1{margin:0;font-size:26px}header p{color:var(--muted);margin:8px 0 0}
main{max-width:960px;margin:32px auto;padding:0 20px}
.card{background:#fff;border:1px solid var(--line);border-radius:10px;
padding:20px 24px;margin-bottom:18px}
.card h2{margin:0 0 6px;font-size:17px}.card h2 a{color:var(--accent);text-decoration:none}
.meta{color:var(--muted);font-size:13px}
.tag{display:inline-block;background:#e3f0ed;color:var(--accent);border-radius:4px;
padding:1px 9px;font-size:12px;margin-right:6px}
article h2{color:var(--accent);font-size:17px;margin-top:26px}
article ul{padding-left:22px}
footer{color:var(--muted);text-align:center;font-size:12px;padding:30px}
a.back{color:var(--accent);font-size:13px;text-decoration:none}
"""

INTRO_SYSTEM = """あなたは技術部門の対外紹介サイトの編集者です。
与えられた事例一覧（すべて機密情報削除済み）に基づき、部門の解析・シミュレーション
支援サービスを紹介する文章を書きます。JSON のみで出力：
{"intro": "サイト冒頭の紹介文（3〜5文）", "teasers": {"<run_id>": "その事例の一行紹介", ...}}
ルール：一覧にない事実・数値・固有名を書かない。誇張しない。日本語。"""


def _page(title: str, body: str, root: str = ".") -> str:
    return f"""<!DOCTYPE html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title><link rel="stylesheet" href="{root}/style.css"></head>
<body><header><h1>解析・シミュレーション支援 事例紹介</h1>
<p>技術開発部門による解析支援の実績（公開版）</p></header>
<main>{body}</main>
<footer>本ページの事例は機密情報を除いた公開版です ・ 生成日 {time.strftime("%Y-%m-%d")}</footer>
</body></html>"""


def _case_body(summary: dict, labels_note: str = "") -> str:
    """社外版 summary（任意模板）→ 案例详情 HTML，通用扁平渲染。"""
    parts: List[str] = [f'<a class="back" href="../index.html">← 事例一覧へ</a>']
    for key, value in summary.items():
        if key == "evidence" or value in (None, "", []):
            continue
        title = html.escape(str(key))
        if isinstance(value, str):
            parts.append(f"<article><h2>{title}</h2><p>{html.escape(value)}</p></article>")
        elif isinstance(value, list) and value and isinstance(value[0], dict):
            for rec in value:
                items = "".join(f"<li><b>{html.escape(str(k))}:</b> {html.escape(str(v))}</li>"
                                for k, v in rec.items() if v)
                parts.append(f"<article><ul>{items}</ul></article>")
        elif isinstance(value, list):
            items = "".join(f"<li>{html.escape(str(v))}</li>" for v in value if v)
            parts.append(f"<article><h2>{title}</h2><ul>{items}</ul></article>")
    return "\n".join(parts)


def build_site(config, ledger, llm=None) -> Dict[str, Any]:
    """从台账社外层全量构建静态站。返回 build_report。"""
    out_dir = config.paths.resolve(config.paths.out_dir) / "site"
    dictionary = NGDictionary.load(config.paths.resolve(config.redaction.dictionary_path))

    # 1) 收集社外层数据（社内数据物理隔离）
    cases: List[Dict[str, Any]] = []
    for row in ledger.all_rows():
        if row.get("state") != "done" or not row.get("run_dir"):
            continue
        ext = Path(row["run_dir"]) / "case_summary_external.json"
        if not ext.exists():
            continue
        try:
            summary = json.loads(ext.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            continue
        cases.append({"run_id": row["run_id"], "title": row.get("case_name") or row["run_id"],
                      "template_id": row.get("template_id", "case"), "summary": summary})

    report: Dict[str, Any] = {"built_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                              "cases": len(cases), "llm_used": False, "aborted": None}
    if not cases:
        report["aborted"] = "公開可能な事例（社外版）がまだありません"
        return report

    # 2) LLM 写介绍与导语（失败/未配置则用朴素模板文案）
    intro = "当部門はローカル解析・シミュレーション技術により、設計課題の解決を支援しています。以下は支援事例の公開版です。"
    teasers: Dict[str, str] = {}
    if llm is not None:
        try:
            digest = [{"run_id": c["run_id"], "title": c["title"],
                       "summary": c["summary"]} for c in cases[:30]]
            out = llm.chat_json(system=INTRO_SYSTEM,
                                user=json.dumps(digest, ensure_ascii=False),
                                max_tokens=2048, tag="site:intro")
            if isinstance(out.get("intro"), str) and out["intro"].strip():
                intro = out["intro"].strip()
            teasers = {k: v for k, v in (out.get("teasers") or {}).items()
                       if isinstance(v, str)}
            report["llm_used"] = True
        except Exception as e:  # noqa: BLE001
            report["llm_error"] = repr(e)[:200]

    # 3) 生成页面（先在内存组装，泄漏闸通过后才落盘）
    pages: Dict[str, str] = {"style.css": _CSS}
    items = []
    for c in cases:
        teaser = teasers.get(c["run_id"], "")
        items.append(
            f'<div class="card"><h2><a href="cases/{c["run_id"]}.html">'
            f'{html.escape(c["title"])}</a></h2>'
            f'<span class="tag">{html.escape(c["template_id"])}</span>'
            + (f'<p class="meta">{html.escape(teaser)}</p>' if teaser else "")
            + "</div>")
        pages[f'cases/{c["run_id"]}.html'] = _page(c["title"], _case_body(c["summary"]),
                                                   root="..")
    pages["index.html"] = _page("事例紹介",
                                f'<div class="card"><p>{html.escape(intro)}</p></div>'
                                + "\n".join(items))

    # 4) 出口泄漏闸：任何 NG 原词出现在任何页面 -> 中止构建
    leaked: Dict[str, List[str]] = {}
    for name, content in pages.items():
        hits = [t for t in dictionary.all_terms() if t and t in content]
        if hits:
            leaked[name] = hits
    if leaked:
        report["aborted"] = "泄漏闸触发：生成页面中检出 NG 词，构建已中止"
        report["leaks"] = leaked
        return report

    # 5) 落盘
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "cases").mkdir(exist_ok=True)
    for name, content in pages.items():
        p = out_dir / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    (out_dir / "build_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    report["out_dir"] = str(out_dir)
    return report
