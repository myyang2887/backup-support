"""
反馈飞轮（v3.4）——商业 agent 产品与玩具的分水岭。

三个闭环组件：
1. **修订记录**：每次 HITL 保存时，自动 diff 机器稿 vs 人工稿，按字段路径
   记入 SQLite（edits 表）。哪个字段总被人改，就是 prompt 该修哪里——
   /api/feedback/stats 直接给出高频修正字段排行。
2. **优质示例库**：用户在 UI 点「良い例に登録」把一份满意的摘要收进
   examples 表（按模板分库）。
3. **few-shot 注入**：Agent 3 生成时自动携带同模板最近 N 份优质示例
   （get_fewshot_block），模型输出风格随人工偏好逐步收敛——数据够多后
   再谈自动化 prompt 调优，这是正确的演进顺序。
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

_SCHEMA = """
CREATE TABLE IF NOT EXISTS edits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT, template_id TEXT, field_path TEXT,
    before TEXT, after TEXT, ts REAL
);
CREATE TABLE IF NOT EXISTS examples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    template_id TEXT, run_id TEXT, summary_json TEXT, ts REAL
);
CREATE INDEX IF NOT EXISTS idx_edits_tpl ON edits(template_id, field_path);
"""

_lock = threading.Lock()


def _db(config) -> sqlite3.Connection:
    path = config.paths.resolve(config.paths.out_dir) / "feedback.sqlite3"
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), check_same_thread=False, timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(_SCHEMA)
    return conn


# ----------------------------------------------------------------------
def diff_paths(before: Any, after: Any, prefix: str = "") -> List[Tuple[str, Any, Any]]:
    """递归 diff，返回 [(字段路径, 旧值, 新值)]。列表整体比较（元素级太噪）。"""
    out: List[Tuple[str, Any, Any]] = []
    if isinstance(before, dict) and isinstance(after, dict):
        for k in sorted(set(before) | set(after)):
            out.extend(diff_paths(before.get(k), after.get(k),
                                  f"{prefix}.{k}" if prefix else k))
    elif before != after:
        out.append((prefix or "(root)", before, after))
    return out


def record_edit(config, run_id: str, template_id: str,
                before: dict, after: dict) -> int:
    changes = diff_paths(before, after)
    if not changes:
        return 0
    with _lock, _db(config) as c:
        c.executemany(
            "INSERT INTO edits (run_id, template_id, field_path, before, after, ts) "
            "VALUES (?,?,?,?,?,?)",
            [(run_id, template_id, path,
              json.dumps(b, ensure_ascii=False), json.dumps(a, ensure_ascii=False),
              time.time()) for path, b, a in changes])
    return len(changes)


def register_example(config, run_id: str, template_id: str, summary: dict) -> None:
    with _lock, _db(config) as c:
        # 同 run 只保留最新一份
        c.execute("DELETE FROM examples WHERE run_id=?", (run_id,))
        c.execute("INSERT INTO examples (template_id, run_id, summary_json, ts) "
                  "VALUES (?,?,?,?)",
                  (template_id, run_id, json.dumps(summary, ensure_ascii=False), time.time()))


def get_fewshot_block(config, template_id: str, n: int = 2,
                      max_chars: int = 6000) -> str:
    """给 Agent 3 的优质示例块。空库返回空串（零成本）。"""
    with _lock, _db(config) as c:
        rows = c.execute(
            "SELECT summary_json FROM examples WHERE template_id=? "
            "ORDER BY ts DESC LIMIT ?", (template_id, n)).fetchall()
    if not rows:
        return ""
    parts, used = [], 0
    for i, (sj,) in enumerate(rows):
        if used + len(sj) > max_chars:
            break
        parts.append(f"良い例 {i + 1}:\n{sj}")
        used += len(sj)
    if not parts:
        return ""
    return ("\n過去に承認された良い要約の例（構造・粒度・言い回しの参考。"
            "内容はコピーしない）：\n\n" + "\n\n".join(parts) + "\n")


def stats(config, template_id: str = "") -> Dict[str, Any]:
    where, params = ("WHERE template_id=?", [template_id]) if template_id else ("", [])
    with _lock, _db(config) as c:
        top = c.execute(
            f"SELECT field_path, COUNT(*) n FROM edits {where} "
            f"GROUP BY field_path ORDER BY n DESC LIMIT 15", params).fetchall()
        totals = c.execute(f"SELECT COUNT(*), COUNT(DISTINCT run_id) FROM edits {where}",
                           params).fetchone()
        n_examples = c.execute(
            "SELECT COUNT(*) FROM examples" + (" WHERE template_id=?" if template_id else ""),
            params).fetchone()[0]
    return {"top_edited_fields": [{"field": f, "count": n} for f, n in top],
            "total_edits": totals[0], "edited_runs": totals[1],
            "registered_examples": n_examples}
