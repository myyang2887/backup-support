"""运行版本历史（v3.4）：每次成功渲染 / 每次 HITL 修订前，把当前产物快照进
run_dir/versions/<时间戳>_<note>/。重跑、误改永不丢历史，可回看可下载。"""
from __future__ import annotations

import shutil
import time
from pathlib import Path
from typing import List, Dict

_SNAPSHOT_FILES = ["case_summary.json", "case_summary.md",
                   "case_summary_external.json", "case_summary_external.md",
                   "quality_report.json", "redaction_report.json"]


def snapshot(run_dir: str | Path, note: str = "") -> Path | None:
    run_dir = Path(run_dir)
    if not (run_dir / "case_summary.json").exists():
        return None
    ts = time.strftime("%Y%m%d_%H%M%S")
    dest = run_dir / "versions" / (f"{ts}_{note}" if note else ts)
    dest.mkdir(parents=True, exist_ok=True)
    for name in _SNAPSHOT_FILES:
        src = run_dir / name
        if src.exists():
            shutil.copy2(src, dest / name)
    return dest


def list_versions(run_dir: str | Path) -> List[Dict[str, str]]:
    vdir = Path(run_dir) / "versions"
    if not vdir.exists():
        return []
    out = []
    for d in sorted(vdir.iterdir(), reverse=True):
        if d.is_dir():
            parts = d.name.split("_", 2)
            out.append({"id": d.name,
                        "time": f"{parts[0]}_{parts[1]}" if len(parts) >= 2 else d.name,
                        "note": parts[2] if len(parts) >= 3 else "",
                        "files": [f.name for f in d.iterdir()]})
    return out
