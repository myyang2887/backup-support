"""
参照台帳（v3.14）— 年度別の依頼一覧 Excel から、報告書ファイル名に対応する
行を引き当てるための索引。

## なぜ要るのか

要約に出てくる「資料内で確認できず」の多くは、**モデルの読み取り不足ではなく、
アップロードされた報告書そのものにその情報が書かれていない**ことが原因。
依頼番号・依頼日・依頼者・依頼目的といったメタ情報は、報告書ではなく
年度別の管理台帳の側に記録されている。

その台帳には報告書ファイルの保存パスが載っているので、
**ファイル名を鍵にすれば残りの列を引ける**。

## なぜ LLM に読ませないのか

台帳は数千行になりうる。丸ごと文脈に載せるのは高価だが、理由はそれだけではない。
**この照合には判断の余地が無い**——ファイル名で行を引くのは決定論的な join であって、
賢さを必要としない。同じ入力からは常に同じ行が返るべきで、モデルを挟むと
その保証が消える（同じ run を二度回して違う行が出るようでは追跡できない）。

なのでここは純粋なコード。モデルは引いてきた行を「証拠」として受け取るだけで、
検索そのものには関与しない。

## 何を返すか

`match()` は「どの行か」だけでなく **「どうやって当てたか」と「どれくらい確からしいか」**
を返す。照合を誤ると他人の依頼者や依頼日を自信満々に要約へ書き込むことになり、
「確認できず」よりよほど悪い。だから根拠を必ず持ち回る。
"""
from __future__ import annotations

import difflib
import hashlib
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

from .cell_format import analyze_column, cell_to_text, cell_to_text_in_column
from .config import PROJECT_ROOT

# ---------------------------------------------------------------------------
# 照合の段階と確からしさ
# ---------------------------------------------------------------------------
#
# 数値そのものより「どの段で当たったか」が重要なので、段ごとに名前を付けておく。
# UI とレポートにはこの名前を出す。
MATCH_EXACT_NAME = "exact_filename"        # ファイル名が完全一致
MATCH_NORMALIZED = "normalized_filename"   # 正規化して一致（全角/版番号/連番を吸収）
MATCH_REQUEST_NO = "request_number"        # ファイル名から依頼番号を抽出して一致
MATCH_PATH_SUFFIX = "path_suffix"          # 台帳のパスが入力の相対パスで終わる
MATCH_PARTIAL = "partial"                  # どこかのセルと部分一致（採点して最良を採る）

_CONFIDENCE = {
    MATCH_EXACT_NAME:  1.00,
    MATCH_NORMALIZED:  0.95,
    MATCH_REQUEST_NO:  0.95,
    MATCH_PATH_SUFFIX: 0.88,
    MATCH_PARTIAL:     0.65,   # 実際は一致度に応じて 0.45〜0.80 に上書きされる
}

#: 部分一致で採用する下限。これ未満は「当たっていない」とみなす。
_PARTIAL_MIN_SCORE = 0.45

#: 部分一致に使うセルの最小長。短い語は偶然一致しやすい。
_PARTIAL_MIN_CELL = 4

#: 連続一致として認める最小文字数。
#: 「硬さ試験」(4 文字) のような一般語だけで当たってしまうのを防ぐ。
_PARTIAL_MIN_LCS = 6

#: 連続一致がセルのどれだけを覆っているべきか。
#: 一部しか重ならないのは別案件の可能性が高い。
_PARTIAL_MIN_COVER = 0.6

#: 報告に残す候補の最大数
_MAX_CANDIDATES = 8

#: これ以上なら「確定」として扱い、注記を付けない
CONFIRMED_THRESHOLD = 0.95

#: ファイル名に紛れ込む版番号・連番・コピー痕。正規化時に落とす。
_NOISE_PATTERNS = [
    r"[_\-\s]*(?:ver?|version|rev)[_\-\.\s]*\d+(?:[_\-\.]\d+)*",
    r"[_\-\s]*v\d+(?:[_\-\.]\d+)*",
    r"[_\-\s]*\(\d+\)",
    r"[_\-\s]*(?:コピー|copy|最終|最新|完成|確定|修正済?|旧|新)",
    r"[_\-\s]*\d{8}",          # 末尾の日付
    r"[_\-\s]*(?:提出用|社内用|配布用|案)",
]

#: 依頼番号らしき並び。年度＋連番、または連番のみ。
#
# \b は使えない：アンダースコアも単語文字なので "2026-0034_別名.pptx" の
# "0034" と "_" の間には境界が立たず、最も普通の命名規則を取り逃がす。
# 前後を明示的な否定先読み／後読みで囲む。
_REQUEST_NO_PATTERNS = [
    re.compile(r"(?<![0-9A-Za-z])(\d{4}[-_]\d{3,6})(?![0-9])"),
    re.compile(r"(?<![0-9A-Za-z])(R\d{1,2}[-_]\d{3,6})(?![0-9])", re.I),  # 令和年度表記
    re.compile(r"(?<![0-9A-Za-z])([A-Z]{1,4}[-_]?\d{4,8})(?![0-9])", re.I),
]


def normalize_text(value: Any) -> str:
    """全角/半角・大小文字・空白の揺れを吸収する。

    日本語のファイル名と台帳のセルは、同じ物を指していても
    全角英数と半角、スペースとアンダースコアが平気で混ざる。
    """
    if value is None:
        return ""
    text = unicodedata.normalize("NFKC", str(value)).strip().lower()
    return re.sub(r"[\s　]+", " ", text)


def normalize_filename(name: str) -> str:
    """ファイル名から拡張子・版番号・連番などの雑音を落として比較用の形にする。"""
    stem = Path(str(name)).stem
    text = normalize_text(stem)
    for pat in _NOISE_PATTERNS:
        text = re.sub(pat, "", text, flags=re.I)
    return re.sub(r"[_\-\s]+", "", text).strip()


def extract_request_no(text: str) -> str:
    """ファイル名や表題から依頼番号らしき並びを取り出す。"""
    raw = unicodedata.normalize("NFKC", str(text or ""))
    for pat in _REQUEST_NO_PATTERNS:
        m = pat.search(raw)
        if m:
            return m.group(1).replace("_", "-").upper()
    return ""


# ---------------------------------------------------------------------------
# 列マッピング（YAML で拡張する）
# ---------------------------------------------------------------------------

@dataclass
class ReferenceSpec:
    """台帳の読み取りに対する **任意の** 微調整（v3.15 で縮小）。

    v3.14 では列名の語彙表を持ち、そこに載っている列だけを拾っていた。
    これは二重に誤りだった：

      1. 載っていない列（「使用ソフト」「特記事項」など）が黙って消える。
         人が手で埋めた情報を、こちらの都合で無かったことにしていた。
      2. 「起案部門」が依頼者を指すかどうかは **語彙ではなく意味の問題**。
         コードが表で決めることではなく、モデルが判断すべきこと。

    今は構造（表頭の行・照合鍵の列）を **値の形** から検出し、
    列の意味付けは一切しない。ここに残っているのは、自動検出が外れたときに
    人が上書きするための逃げ道だけ。**普通は何も書かなくてよい。**
    """
    id: str = "default"
    name: str = "自動検出"
    description: str = ""
    #: 表頭の行を固定したい場合のみ（0 始まり）。None なら自動検出。
    header_row: Optional[int] = None


_DEFAULT_SPEC = ReferenceSpec(
    id="default",
    name="自動検出（表頭の語彙に依存しない）",
    description="表頭の行と照合鍵の列を値の形から検出し、全列を生の表頭のまま保持します",
)


def load_reference_specs(root: Optional[Path] = None) -> Dict[str, ReferenceSpec]:
    """`references/registry/<id>/reference.yaml` を読む。

    v3.15 以降、ここに置けるのは header_row の上書きくらいで、
    列名の語彙は不要になった。ファイルが 1 つも無いのが普通の状態。
    """
    specs = {"default": _DEFAULT_SPEC}
    base = Path(root) if root else (PROJECT_ROOT / "references" / "registry")
    if not base.is_dir():
        return specs
    for entry in sorted(base.iterdir()):
        cfg = entry / "reference.yaml"
        if not (entry.is_dir() and cfg.is_file()):
            continue
        try:
            data = yaml.safe_load(cfg.read_text(encoding="utf-8")) or {}
            spec = ReferenceSpec(
                id=str(data.get("id") or entry.name),
                name=str(data.get("name") or entry.name),
                description=str(data.get("description") or ""),
                header_row=data.get("header_row"),
            )
            specs[spec.id] = spec
        except Exception:  # noqa: BLE001 壊れた 1 件で全体を止めない
            continue
    return specs


# ---------------------------------------------------------------------------
# 索引
# ---------------------------------------------------------------------------

@dataclass
class ReferenceRow:
    """台帳の 1 行。**全列を生の表頭のまま持つ。**

    v3.15 で「論理名に翻訳して持つ」のを止めた。語彙表に載っている列だけを
    拾う作りだと、「使用ソフト」「特記事項」「予算コード」のような
    載っていない列が黙って消える——人が手で埋めた情報を、こちらの都合で
    無かったことにしていた。

    表頭が何を意味するか（「起案部門」は依頼者か？）は語彙の問題ではなく
    意味の問題なので、コードでは決めない。生の表頭ごとモデルへ渡す。
    """
    source_file: str
    sheet_name: str
    row_number: int                                  # 1 始まり（Excel の行番号）
    cells: List[Tuple[str, str]] = field(default_factory=list)  # (表頭, 値) を列順で

    @property
    def values(self) -> Dict[str, str]:
        """表頭 -> 値。表頭が重複していれば後ろに #2 を付けて区別する。"""
        out: Dict[str, str] = {}
        for head, val in self.cells:
            key = head or "(無題列)"
            if key in out:
                i = 2
                while f"{key}#{i}" in out:
                    i += 1
                key = f"{key}#{i}"
            out[key] = val
        return out

    def nonempty(self) -> List[Tuple[str, str]]:
        return [(h, v) for h, v in self.cells if str(v).strip()]

    def to_dict(self) -> Dict[str, Any]:
        return {"source_file": self.source_file, "sheet_name": self.sheet_name,
                "row_number": self.row_number, "values": self.values}


@dataclass
class MatchResult:
    ok: bool = False
    row: Optional[ReferenceRow] = None
    method: str = ""
    confidence: float = 0.0
    #: 照合が当たった列の表頭。証拠から除く（＝検索の鍵そのものなので要約に不要）
    matched_header: str = ""
    #: 同じ段で複数当たった場合の候補（採用はしない）
    candidates: List[ReferenceRow] = field(default_factory=list)
    reason: str = ""

    @property
    def confirmed(self) -> bool:
        """注記なしで確定扱いしてよいか。"""
        return self.ok and self.confidence >= CONFIRMED_THRESHOLD

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok, "method": self.method, "confidence": round(self.confidence, 3),
            "matched_header": self.matched_header,
            "confirmed": self.confirmed, "reason": self.reason,
            "row": self.row.to_dict() if self.row else None,
            "candidates": [c.to_dict() for c in self.candidates],
        }


#: 日付そのもの。番号判定から除外する。
_LOOKS_LIKE_DATE = re.compile(r"^\d{4}[/\-年]\d{1,2}[/\-月]\d{1,2}日?$")

#: 索引に入れる値の最小長。短すぎる値（部署コード「QA」等）は誤爆の元。
_MIN_KEY_LEN = 6

#: 構造検出のために読む最大行数
_STRUCTURE_SCAN_ROWS = 60


def _detect_header_row(rows: List[List[Any]], scan_rows: int = 12) -> int:
    """表頭の行番号（0 始まり）を推定する。表頭の語彙は使わない。

    台帳の 1 行目はタイトル行であることが多い。
    「短い文字列が、隙間なく、横に並んでいる」行を表頭とみなす。
    """
    best_idx, best_score = 0, -1.0
    for i, row in enumerate(rows[:scan_rows]):
        if not row:
            continue
        cells = [c for c in row if c is not None and str(c).strip()]
        if len(cells) < 2:
            continue
        texts = [str(c).strip() for c in cells]
        short = sum(1 for t in texts if len(t) <= 24) / len(texts)
        nonnum = sum(1 for t in texts
                     if not re.fullmatch(r"[-+]?\d[\d,\.]*", t)
                     and not _LOOKS_LIKE_DATE.match(unicodedata.normalize("NFKC", t))) / len(texts)
        density = len(cells) / max(1, len(row))
        score = short * 0.3 + nonnum * 0.4 + density * 0.3
        if score > best_score + 1e-9:
            best_idx, best_score = i, score
    return best_idx


@dataclass
class ReferenceRow:
    """台帳の 1 行。**全列を生の表頭のまま持つ。**

    v3.15 で「論理名に翻訳して持つ」のを止めた。語彙表に載っている列だけを
    拾う作りだと、「使用ソフト」「特記事項」「予算コード」のような
    載っていない列が黙って消える——人が手で埋めた情報を、こちらの都合で
    無かったことにしていた。

    表頭が何を意味するか（「起案部門」は依頼者か？）は語彙の問題ではなく
    意味の問題なので、コードでは決めない。生の表頭ごとモデルへ渡す。
    """
    source_file: str
    sheet_name: str
    row_number: int                                  # 1 始まり（Excel の行番号）
    cells: List[Tuple[str, str]] = field(default_factory=list)  # (表頭, 値) を列順で

    @property
    def values(self) -> Dict[str, str]:
        """表頭 -> 値。表頭が重複していれば後ろに #2 を付けて区別する。"""
        out: Dict[str, str] = {}
        for head, val in self.cells:
            key = head or "(無題列)"
            if key in out:
                i = 2
                while f"{key}#{i}" in out:
                    i += 1
                key = f"{key}#{i}"
            out[key] = val
        return out

    def nonempty(self) -> List[Tuple[str, str]]:
        return [(h, v) for h, v in self.cells if str(v).strip()]

    def to_dict(self) -> Dict[str, Any]:
        return {"source_file": self.source_file, "sheet_name": self.sheet_name,
                "row_number": self.row_number, "values": self.values}


@dataclass
class MatchResult:
    ok: bool = False
    row: Optional[ReferenceRow] = None
    method: str = ""
    confidence: float = 0.0
    #: 照合が当たった列の表頭。証拠から除く（＝検索の鍵そのものなので要約に不要）
    matched_header: str = ""
    #: 同じ段で複数当たった場合の候補（採用はしない）
    candidates: List[ReferenceRow] = field(default_factory=list)
    reason: str = ""

    @property
    def confirmed(self) -> bool:
        """注記なしで確定扱いしてよいか。"""
        return self.ok and self.confidence >= CONFIRMED_THRESHOLD

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok, "method": self.method, "confidence": round(self.confidence, 3),
            "matched_header": self.matched_header,
            "confirmed": self.confirmed, "reason": self.reason,
            "row": self.row.to_dict() if self.row else None,
            "candidates": [c.to_dict() for c in self.candidates],
        }


# v3.16：拡張子の**列挙**を止めた。
#
# v3.15 は .pptx/.docx/.xlsx/.pdf… と並べていたが、それは表頭の語彙表を
# 拡張子の語彙表に置き換えただけで、脆さの質は同じだった。実際 .xlsm
#（マクロ有 Excel）や .pptm、拡張子を持たないフォルダパスを取り逃がしていた。
#
# 形だけを見る：
#   - 「点 + 英字始まりの 2〜5 文字」で終わる → 何であれ拡張子
#   - 区切り記号を含む → パス
# 日付（2026/06/30）は区切り記号を持つので明示的に除く。

def _similarity(query_norm: str, cell_norm: str) -> float:
    """ファイル名とセルの値の一致度を 0.0〜1.0 で返す（v3.20 で作り直し）。

    v3.19 は difflib の ratio（散らばった共通部分も数える）を使っていたが、
    日本語ではこれが効かない。「アルミ外材硬さ試験結果」と「樹脂部材硬さ試験」は
    別案件なのに「材」「硬さ試験」が散在するだけで 0.4〜0.5 の点が付く。
    「硬さ試験」のような一般語はどの行にも出るので、これでは選別にならない。

    v3.20：**連続した共通部分の長さ** だけを見る。飛び飛びの一致は数えない。

      - 連続一致が短ければ（既定 6 文字未満）不採用。
        「硬さ試験」(4) のような一般語だけの一致はここで落ちる。
      - 連続一致がセルの大半を覆っていなければ（既定 6 割未満）不採用。
        セルの一部としか重ならないのは別案件の可能性が高い。

    どちらも満たしたときだけ、覆っている割合を点数にする。
    """
    if not query_norm or not cell_norm:
        return 0.0
    if len(cell_norm) < _PARTIAL_MIN_CELL:
        return 0.0

    sm = difflib.SequenceMatcher(None, query_norm, cell_norm, autojunk=False)
    block = sm.find_longest_match(0, len(query_norm), 0, len(cell_norm))
    lcs = block.size
    if lcs < _PARTIAL_MIN_LCS:
        return 0.0

    cover = lcs / len(cell_norm)
    if cover < _PARTIAL_MIN_COVER:
        return 0.0

    # 0.55〜1.00。セルを丸ごと覆っているほど高い。
    return 0.55 + 0.45 * cover


def _score_row(row: "ReferenceRow", query_norm: str) -> Tuple[float, str, str]:
    """行の全セルを見て、最も一致したセルの (点数, 表頭, 値) を返す。

    同じ行の複数のセルが当たることは普通にある（件名と備考の両方に
    同じ語が入っている等）。それは曖昧さではないので、最良のセルを
    その行の代表点として使う。
    """
    best = (0.0, "", "")
    for head, val in row.nonempty():
        sc = _similarity(query_norm, normalize_filename(val))
        if sc > best[0]:
            best = (sc, head, val)
    return best


class ReferenceIndex:
    """複数の台帳 Excel をまとめた検索索引。

    索引は「正規化キー -> 行のリスト」の辞書がいくつか。数千行でも一瞬で引ける。
    行の実体は 1 度しか持たない（各索引は参照を指すだけ）。
    """

    def __init__(self, spec: Optional[ReferenceSpec] = None):
        self.spec = spec or _DEFAULT_SPEC
        self.rows: List[ReferenceRow] = []
        self.by_exact: Dict[str, List[ReferenceRow]] = {}
        self.by_normalized: Dict[str, List[ReferenceRow]] = {}
        self.by_request_no: Dict[str, List[ReferenceRow]] = {}
        self.by_path_tail: Dict[str, List[ReferenceRow]] = {}
        self.sources: List[Dict[str, Any]] = []
        self.errors: List[Dict[str, str]] = []

    # -- 構築 ------------------------------------------------------------
    def add_workbook(self, xlsx_path: str) -> Dict[str, Any]:
        """台帳 Excel を 1 冊読み込む。**表頭の語彙には依存しない。**"""
        try:
            import openpyxl
        except ImportError:
            self.errors.append({"file": xlsx_path, "error": "openpyxl が導入されていません"})
            return {"ok": False, "rows": 0}

        path = Path(xlsx_path)
        info: Dict[str, Any] = {"file": str(path), "name": path.name,
                                "sheets": [], "rows": 0}
        try:
            wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
        except Exception as e:  # noqa: BLE001 1 冊壊れても他は使う
            self.errors.append({"file": str(path), "error": f"{type(e).__name__}: {e}"})
            return {"ok": False, "rows": 0}

        added = 0
        for ws in wb.worksheets:
            if getattr(ws, "sheet_state", "visible") != "visible":
                continue

            # v3.24：値だけでなく表示書式も読む。
            #
            # Excel の日付は、画面に 2023/12/15 と出ていても中身は
            # 1900-01-01 からの通算日数（45275 のような数値）でしかない。
            # openpyxl が datetime に直してくれるのは書式が日付だと
            # 判別できた場合だけで、書式が「標準」のままの列は生の数値で返る。
            # それを証拠に載せると、モデルは意味不明な数字を完了日として
            # 書き写すか、近くの見た目のきれいな日付（アンケート回答日時など）
            # に乗り換えてしまう。実際その両方が起きた。
            all_rows: List[List[Any]] = []
            all_fmts: List[List[Optional[str]]] = []
            for row in ws.iter_rows():
                all_rows.append([c.value for c in row])
                all_fmts.append([getattr(c, "number_format", None) for c in row])
            if not all_rows:
                continue

            hdr_idx = (self.spec.header_row if self.spec and self.spec.header_row is not None
                       else _detect_header_row(all_rows))
            header_cells = all_rows[hdr_idx] if hdr_idx < len(all_rows) else []
            headers = [("" if c is None else str(c).strip()) for c in header_cells]
            _pairs = [(r, f) for r, f in zip(all_rows[hdr_idx + 1:], all_fmts[hdr_idx + 1:])
                      if r and any(c is not None and str(c).strip() for c in r)]
            data_rows = [r for r, _ in _pairs]
            data_fmts = [f for _, f in _pairs]
            if not headers or not data_rows:
                info["sheets"].append({"name": ws.title, "rows": 0,
                                       "note": "データ行が見つかりませんでした"})
                continue

            # v3.25：列ごとに「日付列かどうか」を先に判定する。
            #
            # 実物の台帳では 1 列 456 件のうち 362 件が日付型、90 件が生の
            # シリアル値だった。複数ファイルを結合した台帳では、行によって
            # 保存され方が違うのが普通に起きる（値貼り付け・別システムからの
            # 取り込み）。セル単体では 46378 が日付か金額か判断できないが、
            # 同じ列に明らかな日付が 362 件あるなら日付と見てよい。
            col_infos: List[Dict[str, Any]] = []
            for c in range(len(headers)):
                col_vals = [r[c] if c < len(r) else None for r in data_rows]
                col_fmts = [f[c] if c < len(f) else None for f in data_fmts]
                col_infos.append(analyze_column(col_vals, col_fmts))

            sheet_rows = 0
            for offset, (row, fmts) in enumerate(zip(data_rows, data_fmts)):
                cells: List[Tuple[str, str]] = []
                for c, head in enumerate(headers):
                    v = row[c] if c < len(row) else None
                    fmt = fmts[c] if c < len(fmts) else None
                    # 変数名を info にしない：外側の戻り値辞書と衝突する
                    cinfo = col_infos[c] if c < len(col_infos) else None
                    cells.append((head, cell_to_text_in_column(v, fmt, cinfo).strip()))
                if not any(v for _, v in cells):
                    continue
                rr = ReferenceRow(source_file=str(path), sheet_name=ws.title,
                                  row_number=hdr_idx + 2 + offset, cells=cells)
                self._index_row(rr)
                sheet_rows += 1
                added += 1

            info["sheets"].append({
                "name": ws.title, "rows": sheet_rows, "header_row": hdr_idx + 1,
                "headers": headers,
                # どの列を日付列と判定したか。要約がおかしい時の切り分け用。
                "date_columns": [headers[i] for i, ci in enumerate(col_infos)
                                 if ci.get("is_date_column") and i < len(headers)],
            })
        try:
            wb.close()
        except Exception:  # noqa: BLE001
            pass

        info["rows"] = added
        info["ok"] = added > 0
        self.sources.append(info)
        return info

    def _index_row(self, rr: ReferenceRow) -> None:
        """行の **全セル** を索引に入れる。

        v3.17：列の役割判定をやめた。Excel で Ctrl+F するとき、
        人は「どの列を探すか」を決めてから探したりしない——全体を探して
        当たったセルの行を読む。それと同じにする。

        ファイル名は拡張子付きで十分に独特なので、どの列に入っていようと
        当たれば同じ行を指す。役割を先に決める必要がそもそも無かった。
        部署名や状態の列も索引に入るが、ファイル名の問い合わせとは
        一致しないので無害。
        """
        self.rows.append(rr)

        for _, raw in rr.cells:
            if not raw:
                continue
            val = str(raw).replace("\\", "/")

            # セルの値そのもの／その末尾のファイル名で引けるようにする
            name = Path(val).name if ("/" in val) else val
            for key in {normalize_text(val), normalize_text(name)}:
                if key and len(key) >= _MIN_KEY_LEN:
                    self.by_exact.setdefault(key, []).append(rr)
            for key in {normalize_filename(val), normalize_filename(name)}:
                if key and len(key) >= _MIN_KEY_LEN:
                    self.by_normalized.setdefault(key, []).append(rr)

            # パス全体（末尾一致の照合用）
            if "/" in val:
                tail = normalize_text(val)
                if tail:
                    self.by_path_tail.setdefault(tail, []).append(rr)

            # 依頼番号らしき並びはどの列にあっても拾う
            no = extract_request_no(val)
            if no and not _LOOKS_LIKE_DATE.match(val.strip()):
                self.by_request_no.setdefault(
                    normalize_text(no).replace("_", "-"), []).append(rr)

    # -- 照合 ------------------------------------------------------------
    def match(self, input_path: str, *, allow_partial: bool = True) -> MatchResult:
        """入力ファイルに対応する行を引く。**Excel の Ctrl+F と同じ考え方。**

        v3.17：列の役割を先に決めるのをやめた。人が台帳から報告書を探すとき、
        「どの列が保存パス列か」を判定してから探すことはない。全体を検索して、
        当たったセルの行を読む。ファイル名は拡張子付きで十分に独特なので、
        それで足りる。

        段は「どこを探すか」ではなく「どこまで崩して探すか」で分ける：

          1. ファイル名そのもの
          2. 版番号・連番・全角を落としたファイル名
          3. ファイル名から抽出した依頼番号
          4. パスの末尾一致
          5. 部分一致（採点して最良を採る。台帳にファイル名が無い場合の本命）

        最初に当たった段で打ち切る。同じ段で 2 行以上当たったら採用しない
        ——これは確度が低いのではなく「どちらか分からない」状態で、
        一方を選ぶのはコイン投げでしかない。
        """
        # v3.26：Windows の区切り（円記号）をスラッシュに揃えてから解釈する。
        # サーバが Linux の場合 Path() は円記号を区切りと見ないため、
        # 「\\srv\\解析\\案件\\速報2.xlsx」が丸ごと 1 つのファイル名として
        # 扱われ、ファイル名照合にもフォルダ名照合にも失敗していた。
        p = Path(str(input_path).replace("\\", "/"))
        fname = p.name

        # 段 1：ファイル名そのもの
        r = self._decide(self.by_exact.get(normalize_text(fname), []),
                         MATCH_EXACT_NAME, f"ファイル名『{fname}』が一致", fname)
        if r.ok or r.candidates:
            return r

        # 段 2：版番号・連番・全角の揺れを落として一致
        nk = normalize_filename(fname)
        if nk and len(nk) >= _MIN_KEY_LEN:
            r = self._decide(self.by_normalized.get(nk, []), MATCH_NORMALIZED,
                             f"版番号等を除いた『{nk}』が一致", fname)
            if r.ok or r.candidates:
                return r

        # 段 3：ファイル名から依頼番号を抽出
        no = extract_request_no(fname)
        if no:
            r = self._decide(
                self.by_request_no.get(normalize_text(no).replace("_", "-"), []),
                MATCH_REQUEST_NO, f"ファイル名の依頼番号『{no}』が一致", fname)
            if r.ok or r.candidates:
                return r

        # 段 4：台帳のパスが入力の相対パスで終わる（フォルダ一括処理向け）
        tail_key = normalize_text(str(p).replace("\\", "/"))
        hits = [rr for key, rows in self.by_path_tail.items()
                if key and (tail_key.endswith(key) or key.endswith(tail_key))
                for rr in rows]
        if hits:
            r = self._decide(hits, MATCH_PATH_SUFFIX, "保存パスの末尾が一致", fname)
            if r.ok or r.candidates:
                return r

        # 段 5：部分一致。台帳にファイル名が載っていない現場ではここが本命。
        #
        # v3.19：以前は「該当が複数なら採用しない」で通していたが、
        # 部分一致では複数当たるのが普通で、それを全部捨てると
        # 台帳があっても永久に何も引けない。**採点して最良を採る**。
        #
        # v3.20：**親フォルダ名も鍵にする。** 一つの解析依頼に対して
        # 成果物が複数ファイルに分かれ、しかも個々のファイル名が
        # 台帳のどの欄とも十分に重ならないことがある
        #（「外材コート層硬さ試験 速報2.xlsx」など）。
        # そういうファイルでも、置かれているフォルダ名は案件名に近いことが多い。
        # ファイル名で当たらなければフォルダ名で引き直す。
        if allow_partial:
            keys: List[Tuple[str, str]] = []
            if nk and len(nk) >= _MIN_KEY_LEN:
                keys.append(("ファイル名", nk))
            # 直近 2 階層の親フォルダ（それ以上は年度や共有名で無意味なことが多い）
            for depth, parent in enumerate(list(p.parents)[:2]):
                pk = normalize_filename(parent.name)
                if pk and len(pk) >= _MIN_KEY_LEN:
                    keys.append((f"フォルダ名{'' if depth == 0 else '（上位）'}", pk))

            best_overall = None
            for key_kind, key in keys:
                scored = []
                for rr in self.rows:
                    sc, head, val = _score_row(rr, key)
                    if sc >= _PARTIAL_MIN_SCORE:
                        scored.append((sc, rr, head, val))
                if not scored:
                    continue
                scored.sort(key=lambda x: (-x[0], x[1].row_number))
                if best_overall is None or scored[0][0] > best_overall[0][0][0]:
                    best_overall = (scored, key_kind, key)

            if best_overall:
                scored, key_kind, key = best_overall
                top_sc, top_row, top_head, top_val = scored[0]
                runner = scored[1][0] if len(scored) > 1 else 0.0

                # 一致度をそのまま確度に写す。完全一致の段（1.00）と
                # 混同させないため 0.80 で頭打ちにする。
                conf = min(0.80, round(top_sc, 3))
                reason = (f"{key_kind}『{key}』が「{top_head}」欄の"
                          f"『{top_val}』と部分一致（一致度 {top_sc:.2f}）")
                if key_kind.startswith("フォルダ名"):
                    reason += "／ファイル名では該当せず、フォルダ名で照合"
                if runner and (top_sc - runner) < 0.05:
                    reason += f"／次点 {runner:.2f} と僅差のため要確認"
                    conf = min(conf, 0.55)
                return MatchResult(
                    ok=True, row=top_row, method=MATCH_PARTIAL,
                    matched_header=top_head, confidence=conf, reason=reason,
                    candidates=[r for _, r, _, _ in scored[1:_MAX_CANDIDATES]])

        return MatchResult(ok=False, reason="台帳に該当する行が見つかりませんでした")

    @staticmethod
    def _decide(hits: List[ReferenceRow], method: str, reason: str,
                query: str = "") -> MatchResult:
        if not hits:
            return MatchResult(ok=False)
        uniq: List[ReferenceRow] = []
        seen = set()
        for rr in hits:
            key = (rr.source_file, rr.sheet_name, rr.row_number)
            if key not in seen:
                seen.add(key)
                uniq.append(rr)
        if len(uniq) == 1:
            row = uniq[0]
            # どの列で当たったかを控えておく。その列の値は検索の鍵そのものなので
            # 要約の証拠には要らない（保存パスを要約に書いても仕方がない）。
            head = ""
            qn = normalize_filename(query)
            for h, v in row.nonempty():
                vn = normalize_filename(Path(str(v).replace("\\", "/")).name)
                if qn and vn and (vn == qn or qn in normalize_text(v)):
                    head = h
                    break
            return MatchResult(ok=True, row=row, method=method, matched_header=head,
                               confidence=_CONFIDENCE.get(method, 0.5), reason=reason)
        # 同じ段で複数 = どちらか分からない。採用しない。
        return MatchResult(
            ok=False, method=method, confidence=0.0, candidates=uniq[:8],
            reason=(f"{reason} が {len(uniq)} 行に該当したため確定できません"
                    f"（どれか一つを選べる根拠が無いため採用しません）"))

    # -- 補助 ------------------------------------------------------------
    def stats(self) -> Dict[str, Any]:
        return {"rows": len(self.rows), "files": len(self.sources),
                "sources": self.sources, "errors": self.errors,
                "spec_id": self.spec.id}


# ---------------------------------------------------------------------------
# 索引のキャッシュ
# ---------------------------------------------------------------------------
#
# 一括処理で 100 件回すたびに数千行の Excel を読み直すのは無駄なので、
# ファイルの mtime+size を鍵にして使い回す。台帳が差し替わればキーが変わる。

_CACHE: Dict[str, ReferenceIndex] = {}


def _cache_key(paths: List[str], spec_id: str) -> str:
    parts = [spec_id]
    for p in sorted(paths):
        try:
            st = Path(p).stat()
            parts.append(f"{p}:{st.st_mtime_ns}:{st.st_size}")
        except OSError:
            parts.append(f"{p}:missing")
    return hashlib.sha1("|".join(parts).encode("utf-8")).hexdigest()


def collect_reference_files(paths: List[str]) -> List[str]:
    """ファイルとフォルダの混在を、Excel ファイルの一覧に均す。"""
    out: List[str] = []
    for raw in paths:
        if not raw:
            continue
        p = Path(raw)
        if p.is_dir():
            for ext in ("*.xlsx", "*.xlsm"):
                out.extend(str(x) for x in sorted(p.rglob(ext))
                           if not x.name.startswith("~$"))
        elif p.is_file() and p.suffix.lower() in (".xlsx", ".xlsm"):
            out.append(str(p))
    # 重複除去（順序は保つ）
    seen, uniq = set(), []
    for p in out:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    return uniq


def build_index(paths: List[str], spec: Optional[ReferenceSpec] = None,
                use_cache: bool = True) -> ReferenceIndex:
    """台帳ファイル群から索引を作る（キャッシュあり）。"""
    spec = spec or _DEFAULT_SPEC
    files = collect_reference_files(paths)
    key = _cache_key(files, spec.id)
    if use_cache and key in _CACHE:
        return _CACHE[key]

    idx = ReferenceIndex(spec)
    for f in files:
        idx.add_workbook(f)
    if use_cache:
        _CACHE[key] = idx
    return idx


def clear_cache() -> None:
    _CACHE.clear()
