"""
解析ルート判定（v3.6 新增）。

動機：Docling は版面解析・表構造・OCR まで面倒を見てくれる代わりに重い
（初回のモデルロードだけで数十分というケースも報告済み）。一方、図版主体の
資料やスキャン PDF では **Docling を通さずページをそのまま視覚モデルへ
渡した方が速くて精度も良い**ことが多い。

そこで入力ごとに二つのルートを用意し、手動でも自動でも選べるようにした：

    text   … 従来どおり Docling で解析 → テキスト分岐が主役（図は補助）
    vision … Docling を完全に飛ばし、全ページを画像化して VLM が主役
             （PDF テキスト層は pypdfium2 で無料で拾えるので補助として使う）

判定は **LLM を一切使わない安価なプローブ**だけで行う：
ページ数・1 ページあたりの文字数・埋め込み画像数。判定理由は run に残り、
UI にも表示されるので「なぜこのルートになったか」が後から追える。
"""
from __future__ import annotations

import zipfile
from pathlib import Path
from typing import Any, Dict, Tuple

# vision ルートでページ画像化が可能な拡張子（OOXML は LibreOffice があれば可）
_PDF = {".pdf"}
_OOXML = {".pptx", ".docx", ".xlsx", ".xlsm"}
_TEXTONLY = {".md", ".txt", ".markdown", ".html", ".htm"}

_PROBE_MAX_PAGES = 40      # プローブ自体が重くならないようサンプルするページ数上限


def probe_document(input_path: str) -> Dict[str, Any]:
    """安価なプローブ。失敗しても例外は投げず kind='unknown' を返す。"""
    src = Path(input_path)
    suffix = src.suffix.lower()
    info: Dict[str, Any] = {"kind": "unknown", "suffix": suffix, "pages": 0,
                            "text_chars": 0, "images": 0,
                            "chars_per_page": 0.0, "images_per_page": 0.0,
                            "renderable": False}
    if suffix in _TEXTONLY:
        info["kind"] = "text"
        try:
            info["text_chars"] = len(src.read_text(encoding="utf-8", errors="ignore"))
        except OSError:
            pass
        return info

    if suffix in _PDF:
        return _probe_pdf(src, info)
    if suffix in _OOXML:
        return _probe_ooxml(src, info)
    return info


def _probe_pdf(src: Path, info: Dict[str, Any]) -> Dict[str, Any]:
    try:
        import pypdfium2 as pdfium
        import pypdfium2.raw as pdfium_c
    except ImportError:
        return info
    try:
        pdf = pdfium.PdfDocument(str(src))
    except Exception:  # noqa: BLE001 壊れた PDF はプローブ対象外
        return info
    info["kind"] = "pdf"
    info["renderable"] = True
    try:
        n_pages = len(pdf)
        info["pages"] = n_pages
        sample = min(n_pages, _PROBE_MAX_PAGES)
        chars = images = 0
        for pno in range(sample):
            try:
                page = pdf[pno]
                chars += page.get_textpage().count_chars()
                images += sum(1 for _ in page.get_objects(
                    filter=(pdfium_c.FPDF_PAGEOBJ_IMAGE,), max_depth=2))
            except Exception:  # noqa: BLE001 1 ページ壊れても続行
                continue
        if sample:
            info["chars_per_page"] = round(chars / sample, 1)
            info["images_per_page"] = round(images / sample, 2)
        # サンプル外は平均で外挿（判定に使うのは比率なので十分）
        info["text_chars"] = int(info["chars_per_page"] * n_pages)
        info["images"] = int(info["images_per_page"] * n_pages)
    finally:
        pdf.close()
    return info


_MEDIA_DIRS = ("ppt/media/", "word/media/", "xl/media/")
_IMG_SUFFIXES = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tiff", ".emf", ".wmf")


def _probe_ooxml(src: Path, info: Dict[str, Any]) -> Dict[str, Any]:
    if not zipfile.is_zipfile(src):
        return info                      # 旧バイナリ形式（.ppt/.doc/.xls）
    info["kind"] = "ooxml"
    try:
        with zipfile.ZipFile(src) as zf:
            names = zf.namelist()
            info["images"] = sum(
                1 for n in names
                if any(n.startswith(d) for d in _MEDIA_DIRS) and n.lower().endswith(_IMG_SUFFIXES))
            slides = [n for n in names if n.startswith("ppt/slides/slide") and n.endswith(".xml")]
            if slides:
                info["pages"] = len(slides)
                info["text_chars"] = sum(len(zf.read(n)) for n in slides[:_PROBE_MAX_PAGES]) // 12
            else:
                # Word/Excel はページという概念が無いので本文サイズで代用
                main = next((n for n in ("word/document.xml", "xl/sharedStrings.xml")
                             if n in names), None)
                body = len(zf.read(main)) if main else 0
                info["text_chars"] = body // 8      # XML タグ分をざっくり割り引く
                info["pages"] = max(1, body // 3000)
    except Exception:  # noqa: BLE001
        return info
    if info["pages"]:
        info["chars_per_page"] = round(info["text_chars"] / info["pages"], 1)
        info["images_per_page"] = round(info["images"] / info["pages"], 2)
    # OOXML のページ画像化は LibreOffice 依存。無ければ埋め込み画像だけで vision 可能
    from tools.visual_asset_tools import find_soffice
    info["renderable"] = bool(find_soffice())
    return info


def decide_route(input_path: str, wf) -> Tuple[str, str, Dict[str, Any]]:
    """
    戻り値 (route, reason, probe)。route は "text" | "vision"。

    wf は WorkflowConfig（input_mode と vision_route_* のしきい値を参照）。
    手動指定（text/vision）のときはプローブすら走らせない＝ゼロコスト。
    """
    mode = getattr(wf, "input_mode", "auto") or "auto"
    if mode == "text":
        return "text", "手動指定：テキスト優先（Docling）", {}
    if mode == "vision":
        return "vision", "手動指定：視覚モデル直読", {}

    probe = probe_document(input_path)
    kind = probe.get("kind")
    if kind in ("text", "unknown"):
        return "text", "テキスト系ファイルのため Docling 経路", probe

    # Excel はページ画像化しない。セル値・数式の計算結果・グラフ定義の数値を
    # 直接読む方が確実で速く、ローカルの小さいモデルにも扱いやすい
    # （表を画像で見せて数字を読ませるのは失敗しやすい）。
    # ※ 手動で "vision" を選んだ場合は上の分岐で既に返しているので尊重される。
    if probe.get("suffix") in (".xlsx", ".xlsm", ".xls"):
        return "text", "Excel はセル値とグラフ定義を直接読む経路が確実", probe

    pages = probe.get("pages", 0)
    cpp = probe.get("chars_per_page", 0.0)
    ipp = probe.get("images_per_page", 0.0)

    if pages > wf.vision_route_max_pages:
        return "text", (f"{pages} ページ（上限 {wf.vision_route_max_pages}）— "
                        f"ページ数が多く画像処理は割高"), probe
    if cpp < wf.vision_route_text_chars_per_page:
        return "vision", (f"1 ページあたり約 {cpp:.0f} 文字（しきい値 "
                          f"{wf.vision_route_text_chars_per_page}）— テキスト層が薄い"), probe
    if ipp >= wf.vision_route_images_per_page:
        return "vision", (f"1 ページあたり約 {ipp:.1f} 枚の画像（しきい値 "
                          f"{wf.vision_route_images_per_page}）— 図版主体"), probe
    return "text", (f"テキスト {cpp:.0f} 文字/頁・画像 {ipp:.1f} 枚/頁 — "
                    f"文章主体のため Docling 経路"), probe
