"""
パイプライン実行トレース — 「今、何が、何で処理されたか」を残す。

## なぜ要るのか

このシステムは同じ入力でも通る道が何通りもある：

    PDF   → Docling 全套 / pypdfium2 だけ（Docling 失敗時）/ 全頁描画（視覚ルート）
    PPTX  → Docling / LibreOffice→PDF→描画
    Excel → openpyxl+zipfile（純 Python）/ Excel COM（win32com）/ LibreOffice
    描画  → pypdfium2

どれを通ったかで結果の質は大きく変わるのに、v3.8 まではログに
「どのルートか」しか出ず、**どの依存で処理されたかが分からなかった**。
「Excel COM が入っていない環境なのに気付かず数値表だけで動いていた」
「LibreOffice が無くて埋込画像しか見ていなかった」——こういう事故は
エラーにならないので、後から結果だけ見ても原因に辿り着けない。

このトレースは各段で**実際に使われた実装**を記録する。フォールバックが
起きたときは「何から何へ落ちたか」も残す。

## 使い方

    trace = PipelineTrace()
    trace.use("parse", ENGINE_DOCLING, "PDF を Markdown 化", ok=True)
    trace.fallback("parse", ENGINE_DOCLING, ENGINE_PYPDFIUM,
                   "Docling が失敗したためテキスト層のみ抽出")
    trace.to_dict()        # pipeline_trace.json へ
    trace.summary_lines()  # UI / run.log 用の日本語 1 行要約
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# --- エンジン識別子（表記ゆれを防ぐため定数化）-----------------------------
ENGINE_DOCLING = "docling"
ENGINE_PYPDFIUM = "pypdfium2"
ENGINE_OPENPYXL = "openpyxl+zipfile"
ENGINE_LIBREOFFICE = "libreoffice"
ENGINE_OFFICE2PDF = "office2pdf"
ENGINE_WIN32COM = "win32com(Excel)"
ENGINE_OFFICE_COM = "win32com(PowerPoint/Word)"
ENGINE_PYTHON_PPTX = "python-pptx"
ENGINE_PYTHON_DOCX = "python-docx"
ENGINE_REPORTLAB = "reportlab"
ENGINE_PILLOW = "pillow"
ENGINE_NONE = "-"

#: エンジン -> (日本語表示名, 依存区分)
#: 依存区分は「この処理は外部アプリを必要とするか」を一目で分かるようにする物。
ENGINE_INFO: Dict[str, tuple] = {
    ENGINE_DOCLING:      ("Docling（レイアウト解析＋表構造）", "純Python"),
    ENGINE_PYPDFIUM:     ("pypdfium2（PDF 描画・テキスト層）", "純Python"),
    ENGINE_OPENPYXL:     ("openpyxl + zipfile（セル値・グラフ numCache）", "純Python"),
    ENGINE_LIBREOFFICE:  ("LibreOffice（headless 変換）", "外部アプリ"),
    ENGINE_OFFICE2PDF:   ("office2pdf（Office → PDF・Rust 単一バイナリ）", "同梱バイナリ"),
    ENGINE_WIN32COM:     ("Excel COM（win32com）", "Excel 実機"),
    ENGINE_OFFICE_COM:   ("PowerPoint / Word COM（win32com）", "Office 実機"),
    ENGINE_PYTHON_PPTX:  ("python-pptx", "純Python"),
    ENGINE_PYTHON_DOCX:  ("python-docx", "純Python"),
    ENGINE_REPORTLAB:    ("reportlab", "純Python"),
    ENGINE_PILLOW:       ("Pillow（画像前処理）", "純Python"),
    ENGINE_NONE:         ("（なし）", "-"),
}

#: 段階 -> 日本語表示名
STAGE_LABELS: Dict[str, str] = {
    "route": "ルート判定",
    "parse": "本文解析",
    "visual": "視覚資産の収集",
    "excel": "Excel 読み取り",
    "chunk": "切块",
    "deep_read": "精読",
    "render": "書面レンダリング",
    "export": "エクスポート",
}


def engine_label(engine: str) -> str:
    return ENGINE_INFO.get(engine, (engine, "不明"))[0]


def engine_kind(engine: str) -> str:
    return ENGINE_INFO.get(engine, (engine, "不明"))[1]


def engine_version(engine: str) -> str:
    """入っているなら版を拾う。無ければ空文字（未導入の判定にも使える）。

    `__version__` を持たないパッケージ（pypdfium2 など）があるので、
    importlib.metadata を優先し、そちらで取れなければ属性を見る。
    """
    dist, mod = {
        ENGINE_DOCLING: ("docling", "docling"),
        ENGINE_PYPDFIUM: ("pypdfium2", "pypdfium2"),
        ENGINE_OPENPYXL: ("openpyxl", "openpyxl"),
        ENGINE_PYTHON_PPTX: ("python-pptx", "pptx"),
        ENGINE_PYTHON_DOCX: ("python-docx", "docx"),
        ENGINE_REPORTLAB: ("reportlab", "reportlab"),
        ENGINE_PILLOW: ("pillow", "PIL"),
    }.get(engine, (None, None))
    if not dist:
        return ""
    try:
        import importlib.metadata as _md
        return _md.version(dist)
    except Exception:  # noqa: BLE001 パッケージ名が違う/未導入
        pass
    try:
        m = __import__(mod)
        return str(getattr(m, "__version__", "") or "")
    except Exception:  # noqa: BLE001 未導入なら空
        return ""


@dataclass
class EngineUse:
    stage: str
    engine: str
    role: str = ""
    ok: bool = True
    detail: str = ""
    fallback_from: str = ""
    at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "stage": self.stage,
            "stage_label": STAGE_LABELS.get(self.stage, self.stage),
            "engine": self.engine,
            "engine_label": engine_label(self.engine),
            "engine_kind": engine_kind(self.engine),
            "version": engine_version(self.engine),
            "role": self.role,
            "ok": self.ok,
        }
        if self.detail:
            d["detail"] = self.detail
        if self.fallback_from:
            d["fallback_from"] = self.fallback_from
            d["fallback_from_label"] = engine_label(self.fallback_from)
        return d


@dataclass
class PipelineTrace:
    """1 回の run で通った道と使った実装の記録。"""
    route: str = ""
    route_reason: str = ""
    route_manual: bool = False
    template_id: str = ""
    deep_read: bool = False
    uses: List[EngineUse] = field(default_factory=list)

    # -- 記録 -----------------------------------------------------------
    def set_route(self, route: str, reason: str = "", manual: bool = False) -> None:
        self.route, self.route_reason, self.route_manual = route, reason, manual

    def use(self, stage: str, engine: str, role: str = "", ok: bool = True,
            detail: str = "") -> None:
        self.uses.append(EngineUse(stage=stage, engine=engine, role=role,
                                   ok=ok, detail=detail))

    def fallback(self, stage: str, frm: str, to: str, reason: str = "") -> None:
        """フォールバックを記録。事故の原因究明はここが命綱になる。"""
        self.uses.append(EngineUse(stage=stage, engine=to, role="フォールバック",
                                   ok=True, detail=reason, fallback_from=frm))

    def unavailable(self, stage: str, engine: str, reason: str = "") -> None:
        """使えなかった実装も残す（「入っていない」ことが分かるのが重要）。"""
        self.uses.append(EngineUse(stage=stage, engine=engine, role="利用不可",
                                   ok=False, detail=reason))

    # -- 往復（並行分岐をまたぐ）-----------------------------------------
    def raw(self) -> Dict[str, Any]:
        return {
            "route": self.route, "route_reason": self.route_reason,
            "route_manual": self.route_manual, "template_id": self.template_id,
            "deep_read": self.deep_read,
            "uses": [{"stage": u.stage, "engine": u.engine, "role": u.role,
                      "ok": u.ok, "detail": u.detail,
                      "fallback_from": u.fallback_from, "at": u.at}
                     for u in self.uses],
        }

    @classmethod
    def from_raw(cls, data: Optional[Dict[str, Any]]) -> "PipelineTrace":
        t = cls()
        if not data:
            return t
        t.route = data.get("route", "")
        t.route_reason = data.get("route_reason", "")
        t.route_manual = bool(data.get("route_manual", False))
        t.template_id = data.get("template_id", "")
        t.deep_read = bool(data.get("deep_read", False))
        for u in data.get("uses") or []:
            t.uses.append(EngineUse(
                stage=u.get("stage", ""), engine=u.get("engine", ""),
                role=u.get("role", ""), ok=bool(u.get("ok", True)),
                detail=u.get("detail", ""), fallback_from=u.get("fallback_from", ""),
                at=float(u.get("at") or 0.0)))
        return t

    def merge(self, other: "PipelineTrace") -> None:
        if not other:
            return
        if other.route and not self.route:
            self.route, self.route_reason = other.route, other.route_reason
        self.uses.extend(other.uses)
        self.uses.sort(key=lambda u: u.at)

    # -- 出力 -----------------------------------------------------------
    def engines_used(self) -> List[str]:
        seen, out = set(), []
        for u in self.uses:
            if u.ok and u.engine not in seen:
                seen.add(u.engine)
                out.append(u.engine)
        return out

    def to_dict(self) -> Dict[str, Any]:
        return {
            "route": self.route,
            "route_label": {"text": "テキスト（Docling 経路）",
                            "vision": "視覚直読（全頁描画）"}.get(self.route, self.route),
            "route_reason": self.route_reason,
            "route_decided_by": "手動指定" if self.route_manual else "自動判定",
            "template_id": self.template_id,
            "deep_read": self.deep_read,
            "engines_used": [{"engine": e, "label": engine_label(e),
                              "kind": engine_kind(e), "version": engine_version(e)}
                             for e in self.engines_used()],
            "fallbacks": [u.to_dict() for u in self.uses if u.fallback_from],
            "unavailable": [u.to_dict() for u in self.uses if not u.ok],
            "timeline": [u.to_dict() for u in self.uses],
        }

    def summary_lines(self) -> List[str]:
        """run.log と UI に出す日本語 1 行要約。"""
        out: List[str] = []
        if self.route:
            how = "手動指定" if self.route_manual else "自動判定"
            label = {"text": "テキスト（Docling 経路）",
                     "vision": "視覚直読（全頁描画）"}.get(self.route, self.route)
            reason = f" — {self.route_reason}" if self.route_reason else ""
            out.append(f"ルート：{label}（{how}）{reason}")
        if self.deep_read:
            out.append("精読モード：有効（ページ単位で本文・図・全頁画像を突き合わせ）")
        for u in self.uses:
            if not u.ok:
                out.append(f"{STAGE_LABELS.get(u.stage, u.stage)}：{engine_label(u.engine)} は利用不可"
                           + (f"（{u.detail}）" if u.detail else ""))
            elif u.fallback_from:
                out.append(f"{STAGE_LABELS.get(u.stage, u.stage)}："
                           f"{engine_label(u.fallback_from)} → {engine_label(u.engine)} へ後退"
                           + (f"（{u.detail}）" if u.detail else ""))
            else:
                ver = engine_version(u.engine)
                vtxt = f" v{ver}" if ver else ""
                out.append(f"{STAGE_LABELS.get(u.stage, u.stage)}："
                           f"{engine_label(u.engine)}{vtxt}"
                           + (f" — {u.role}" if u.role else ""))
        return out


def environment_report() -> Dict[str, Any]:
    """起動時に 1 回出す環境レポート。

    「この機械では何が使えるのか」を最初に確定させておくと、
    後から結果だけ見て悩む時間が消える。
    """
    import os
    import shutil

    rows: List[Dict[str, Any]] = []
    for eng in (ENGINE_DOCLING, ENGINE_PYPDFIUM, ENGINE_OPENPYXL,
                ENGINE_PYTHON_PPTX, ENGINE_PYTHON_DOCX, ENGINE_REPORTLAB, ENGINE_PILLOW):
        ver = engine_version(eng)
        rows.append({"engine": eng, "label": engine_label(eng),
                     "kind": engine_kind(eng), "available": bool(ver),
                     "version": ver})

    # LibreOffice は実行ファイルの有無で判定
    lo = shutil.which("soffice") or shutil.which("libreoffice")
    rows.append({"engine": ENGINE_LIBREOFFICE, "label": engine_label(ENGINE_LIBREOFFICE),
                 "kind": engine_kind(ENGINE_LIBREOFFICE),
                 "available": bool(lo), "version": "", "path": lo or ""})

    # Excel COM は Windows かつ pywin32 が入っているか
    com_ok = False
    com_note = ""
    if os.name != "nt":
        com_note = "Windows 以外のため利用不可"
    else:
        try:
            import pythoncom  # noqa: F401
            import win32com.client  # noqa: F401
            com_ok = True
        except Exception as e:  # noqa: BLE001
            com_note = f"pywin32 未導入: {type(e).__name__}"
    rows.append({"engine": ENGINE_WIN32COM, "label": engine_label(ENGINE_WIN32COM),
                 "kind": engine_kind(ENGINE_WIN32COM),
                 "available": com_ok, "version": "", "note": com_note})

    # PowerPoint / Word COM（LibreOffice の代わりに PDF 変換を担う）
    ppt_ok = word_ok = False
    if com_ok:
        try:
            from tools.office_com import powerpoint_available, word_available
            ppt_ok, word_ok = powerpoint_available(), word_available()
        except Exception:  # noqa: BLE001
            pass
    rows.append({"engine": ENGINE_OFFICE_COM, "label": engine_label(ENGINE_OFFICE_COM),
                 "kind": engine_kind(ENGINE_OFFICE_COM),
                 "available": bool(ppt_ok or word_ok), "version": "",
                 "note": (f"PowerPoint {'可' if ppt_ok else '不可'} / "
                          f"Word {'可' if word_ok else '不可'}") if com_ok else com_note})

    missing = [r["label"] for r in rows if not r["available"]]
    return {"engines": rows, "missing": missing,
            "note": ("未導入の実装があります。該当する処理は自動的に代替経路へ後退します"
                     if missing else "全ての実装が利用可能です")}
