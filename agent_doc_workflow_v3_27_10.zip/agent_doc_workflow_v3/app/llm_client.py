"""
本地 LLM 客户端（llama.cpp OpenAI 兼容 server）— v3.1 重写。

★ 性能修正的核心：structured_output 模式重新设计。

v2/v3 的教训：每次调用都带 response_format=json_schema，llama.cpp 要
为每个请求编译 schema -> GBNF 语法，解码时逐 token 做 logit 掩码，
且语法约束下模型不产出完整 JSON 结构不能停——生成速度大幅下降，
这是"v1 几分钟 / v2 一小时"性能回归的主因。

v3.1 模式：
- "adaptive"（默认）：先走普通文本模式（v1 的速度），JSON 解析或上层
  校验失败时，才用 grammar 约束**重试这一次调用**。绝大多数调用
  （Gemma 对简单 JSON 任务的合格率很高）零 grammar 开销，
  少数坏输出由 grammar 兜底——速度与健壮性兼得。
- "always"：每次都 grammar（v2 行为，调试/极不听话的模型用）
- "never"：纯文本 + 容错提取（v1 行为）
兼容旧配置值：auto -> adaptive, json_schema -> always, none -> never。

其他工程化改进：
- 每次调用的 指标（耗时/模式/重试/prompt与输出规模）通过 metrics_hook 上报
- 送给 grammar 的 schema 先瘦身（去 title/description/default），减小语法编译体积
"""
from __future__ import annotations

import base64
import copy
import json
import re
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from openai import OpenAI

_MODE_ALIASES = {"auto": "adaptive", "json_schema": "always", "none": "never"}


class LLMJsonError(RuntimeError):
    def __init__(self, message: str, raw: str = ""):
        super().__init__(message)
        self.raw = raw


def _temp_kw(temperature: Optional[float]) -> Dict[str, Any]:
    """温度指定があるときだけキーワード引数を作る。

    既定（None）では `_create` の呼び出し形を v3.8 のまま保つ。こうしないと
    `_create` を差し替えているテストダブルが軒並み引数不一致で落ちる。
    """
    return {} if temperature is None else {"temperature": float(temperature)}


class LocalLLMClient:
    def __init__(
        self,
        base_url: str,
        api_key: str,
        model: str = "local-model",
        temperature: float = 0.0,
        structured_output: str = "adaptive",
        max_retries: int = 2,
        timeout_seconds: float = 300.0,
        mock: bool = False,
        mock_handler: Optional[Callable[[str, str], Dict[str, Any]]] = None,
        metrics_hook: Optional[Callable[[dict], None]] = None,
        **_ignored,
    ):
        self.model = model
        self.temperature = temperature
        self.structured_output = _MODE_ALIASES.get(structured_output, structured_output)
        self.max_retries = max_retries
        self.mock = mock
        self.mock_handler = mock_handler
        self.metrics_hook = metrics_hook
        self._grammar_supported: Optional[bool] = None
        if not mock:
            self.client = OpenAI(base_url=base_url, api_key=api_key, timeout=timeout_seconds)

    # ------------------------------------------------------------------
    def _emit(self, record: dict) -> None:
        if self.metrics_hook:
            try:
                self.metrics_hook(record)
            except Exception:  # noqa: BLE001 指标上报绝不影响主流程
                pass

    def _create(self, messages: List[dict], max_tokens: int,
                response_format: Optional[dict],
                temperature: Optional[float] = None) -> str:
        """temperature=None なら全体設定を使う。

        v3.9：段階ごとに温度を変えられるようにした。抽出・構造化は 0（貪欲）で
        良いが、要約の書き足しまで 0 だと短く定型的な文しか出ない。
        用途の違う工程に同じ温度を強いる必要は無い。
        """
        last_err: Optional[Exception] = None
        temp = self.temperature if temperature is None else float(temperature)
        for attempt in range(self.max_retries + 1):
            try:
                kwargs: Dict[str, Any] = dict(
                    model=self.model, messages=messages,
                    temperature=temp, max_tokens=max_tokens,
                )
                if response_format is not None:
                    kwargs["response_format"] = response_format
                resp = self.client.chat.completions.create(**kwargs)
                return resp.choices[0].message.content or ""
            except Exception as e:  # noqa: BLE001
                last_err = e
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)
        raise RuntimeError(f"LLM 请求失败（已重试 {self.max_retries} 次）: {last_err!r}")

    def _grammar_format(self, json_schema: dict) -> dict:
        return {"type": "json_schema",
                "json_schema": {"name": "output", "schema": compact_schema(json_schema),
                                "strict": True}}

    # ------------------------------------------------------------------
    def chat_text(self, system: str, user: str, max_tokens: int = 4096,
                  tag: str = "chat") -> str:
        if self.mock:
            return "（モック応答）"
        messages = [{"role": "system", "content": system},
                    {"role": "user", "content": user}]
        t0 = time.time()
        text = self._create(messages, max_tokens, None)
        self._emit({"tag": tag, "duration_s": round(time.time() - t0, 2),
                    "prompt_chars": len(system) + len(user),
                    "completion_chars": len(text), "mode": "text",
                    "attempts": 1, "grammar_used": False})
        return text

    def chat_text_stream(self, system: str, user: str, max_tokens: int = 2048,
                         tag: str = "chat_stream"):
        """流式文本生成：逐 delta yield。"""
        if self.mock:
            yield "（モック応答）"
            return
        t0 = time.time()
        total = 0
        stream = self.client.chat.completions.create(
            model=self.model, temperature=self.temperature, max_tokens=max_tokens,
            messages=[{"role": "system", "content": system},
                      {"role": "user", "content": user}],
            stream=True)
        for chunk in stream:
            delta = chunk.choices[0].delta.content if chunk.choices else None
            if delta:
                total += len(delta)
                yield delta
        self._emit({"tag": tag, "duration_s": round(time.time() - t0, 2),
                    "prompt_chars": len(system) + len(user), "completion_chars": total,
                    "mode": "stream", "attempts": 1, "grammar_used": False})

    def chat_json(self, system: str, user: str, max_tokens: int = 4096,
                  json_schema: Optional[dict] = None, tag: str = "json",
                  temperature: Optional[float] = None) -> Dict[str, Any]:
        """输出 JSON object。adaptive：文本优先，解析失败才 grammar 重试。"""
        if self.mock:
            handler = self.mock_handler or _default_mock
            return handler(system, user)

        messages = [{"role": "system", "content": system},
                    {"role": "user", "content": user}]
        prompt_chars = len(system) + len(user)
        t0 = time.time()
        attempts = 0
        grammar_used = False

        def emit(text_len: int, mode: str):
            self._emit({"tag": tag, "duration_s": round(time.time() - t0, 2),
                        "prompt_chars": prompt_chars, "completion_chars": text_len,
                        "mode": mode, "attempts": attempts, "grammar_used": grammar_used})

        mode = self.structured_output
        use_grammar_first = (mode == "always" and json_schema is not None
                             and self._grammar_supported is not False)

        # 第 1 次：always 模式走 grammar，其余走快速文本
        attempts += 1
        if use_grammar_first:
            try:
                text = self._create(messages, max_tokens,
                                    self._grammar_format(json_schema), **_temp_kw(temperature))
                self._grammar_supported = True
                grammar_used = True
                result = _extract_json_object(text)
                emit(len(text), "grammar")
                return result
            except Exception:
                self._grammar_supported = False  # server 不支持，降级为文本
        try:
            text = self._create(messages, max_tokens, None, **_temp_kw(temperature))
            result = _extract_json_object(text)
            emit(len(text), "text")
            return result
        except LLMJsonError as first_error:
            # 第 2 次：adaptive 兜底——仅在文本模式产出坏 JSON 时才付 grammar 的代价
            if mode == "never" or json_schema is None or self._grammar_supported is False:
                emit(len(first_error.raw), "text_failed")
                raise
            attempts += 1
            try:
                text = self._create(messages, max_tokens, self._grammar_format(json_schema), **_temp_kw(temperature))
                self._grammar_supported = True
                grammar_used = True
                result = _extract_json_object(text)
                emit(len(text), "grammar_repair")
                return result
            except LLMJsonError:
                emit(0, "grammar_repair_failed")
                raise
            except Exception:
                self._grammar_supported = False
                emit(len(first_error.raw), "text_failed")
                raise first_error

    def chat_vision_json(self, image_path: str, system: str, user_text: str,
                         max_tokens: int = 2048, json_schema: Optional[dict] = None,
                         tag: str = "vision") -> Dict[str, Any]:
        if self.mock:
            handler = self.mock_handler or _default_mock
            return handler(system, user_text)

        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": [
                {"type": "text", "text": user_text},
                {"type": "image_url", "image_url": {"url": _image_to_data_url(image_path)}},
            ]},
        ]
        t0 = time.time()
        attempts = 1
        grammar_used = False
        try:
            text = self._create(messages, max_tokens, None)
            result = _extract_json_object(text)
        except LLMJsonError:
            if self.structured_output == "never" or json_schema is None \
                    or self._grammar_supported is False:
                raise
            attempts += 1
            grammar_used = True
            text = self._create(messages, max_tokens, self._grammar_format(json_schema))
            result = _extract_json_object(text)
        self._emit({"tag": tag, "duration_s": round(time.time() - t0, 2),
                    "prompt_chars": len(user_text), "completion_chars": len(text),
                    "mode": "vision", "attempts": attempts, "grammar_used": grammar_used})
        return result


# ----------------------------------------------------------------------
def compact_schema(schema: dict) -> dict:
    """瘦身 schema：递归去掉 title/description/default——它们对语法约束无意义，
    却会放大 GBNF 编译体积。结构性键（properties/required/$defs 等）全部保留。"""
    def strip(obj):
        if isinstance(obj, dict):
            return {k: strip(v) for k, v in obj.items()
                    if k not in ("title", "description", "default", "examples")}
        if isinstance(obj, list):
            return [strip(x) for x in obj]
        return obj
    return strip(copy.deepcopy(schema))


def _image_to_data_url(image_path: str) -> str:
    path = Path(image_path)
    suffix = path.suffix.lower()
    mime = ("image/jpeg" if suffix in (".jpg", ".jpeg")
            else "image/webp" if suffix == ".webp" else "image/png")
    b64 = base64.b64encode(path.read_bytes()).decode("utf-8")
    return f"data:{mime};base64,{b64}"


def _extract_json_object(text: str) -> Dict[str, Any]:
    text = text.strip()
    fenced = re.match(r"^```(?:json)?\s*([\s\S]*?)\s*```$", text)
    if fenced:
        text = fenced.group(1).strip()
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    match = re.search(r"\{[\s\S]*\}", text)
    if not match:
        raise LLMJsonError("模型输出中未找到 JSON object", raw=text)
    try:
        obj = json.loads(match.group(0))
        if not isinstance(obj, dict):
            raise LLMJsonError("模型输出的 JSON 不是 object", raw=text)
        return obj
    except LLMJsonError:
        raise
    except Exception as e:
        raise LLMJsonError(f"JSON 解析失败: {e!r}", raw=text) from e


def _default_mock(system: str, user: str) -> Dict[str, Any]:
    if "文書整理エージェント" in system or "证据信息" in system:
        return {"evidence": [
            {"category": "background", "content": "モック背景証拠", "confidence": 0.9},
            {"category": "tool", "content": "FloEFD / COMSOL（モック）", "confidence": 0.8},
        ]}
    if "視覚" in system or "视觉" in system:
        return {"has_useful_visual_info": False, "visual_type": "unknown",
                "readable_text": [], "visual_summary": "モック視覚分析",
                "key_facts": [], "possible_relevance": [], "confidence": 0.1}
    return {
        "case_name": "モック案件",
        "request_details": {"requester": "モック部門", "target_product_or_system": "モックシステム",
                            "background": ["モック背景1"], "client_issues": ["モック課題1"],
                            "scope_of_request": ["モック依頼内容1"]},
        "action_results": {"support_type": "モック対応", "tools_environment": ["FloEFD（モック）"],
                           "period": "2026年1月", "findings": ["モック判明事実"],
                           "effects": ["モック効果"]},
        "evidence": ["mock_ev_001"],
    }
