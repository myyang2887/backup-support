"""
案件台账（v3.3）：跨 run 的 SQLite 索引。

生产级要点：
- SQLite（Python 标准库，零许可证问题）+ WAL 模式 + 进程内锁，多线程安全
- **磁盘是真源，DB 是索引**：run 目录里的 case_summary.json 永远权威，
  DB 损坏/丢失时 rebuild_from_disk() 全量重建——台账永不成为单点
- 一键导出 Excel（openpyxl，MIT 许可）：日文表头、冻结首行、自适应列宽，
  可直接作为部门案件台账提交
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

_SCHEMA = """
CREATE TABLE IF NOT EXISTS cases (
    run_id       TEXT PRIMARY KEY,
    template_id  TEXT DEFAULT 'case',
    input_name   TEXT,
    case_name    TEXT,
    requester    TEXT,
    target       TEXT,
    support_type TEXT,
    period       TEXT,
    effects      TEXT,
    state        TEXT,
    warnings     TEXT,
    has_external INTEGER DEFAULT 0,
    run_dir      TEXT,
    created_at   REAL,
    updated_at   REAL
);
CREATE INDEX IF NOT EXISTS idx_cases_updated ON cases(updated_at DESC);
"""

_COLUMNS = ["run_id", "input_name", "case_name", "requester", "target", "support_type",
            "period", "effects", "state", "warnings", "has_external", "run_dir",
            "created_at", "updated_at", "template_id"]

_JP_HEADERS = ["Run ID", "入力ファイル", "案件名", "依頼元", "対象製品・システム",
               "対応種別", "対応期間", "効果", "状態", "警告", "社外版", "保存先",
               "作成日時", "更新日時", "テンプレート"]


class Ledger:
    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        with self._conn() as c:
            c.executescript(_SCHEMA)
            # 老库平滑迁移：补 template_id 列
            cols = [r[1] for r in c.execute("PRAGMA table_info(cases)").fetchall()]
            if "template_id" not in cols:
                c.execute("ALTER TABLE cases ADD COLUMN template_id TEXT DEFAULT 'case'")

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False, timeout=10)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row
        return conn

    # ------------------------------------------------------------------
    def upsert(self, record: Dict[str, Any]) -> None:
        record = {k: record.get(k) for k in _COLUMNS}
        record["updated_at"] = time.time()
        if record.get("created_at") is None:
            record["created_at"] = record["updated_at"]
        with self._lock, self._conn() as c:
            existing = c.execute("SELECT created_at FROM cases WHERE run_id=?",
                                 (record["run_id"],)).fetchone()
            if existing:
                record["created_at"] = existing["created_at"]
            placeholders = ",".join("?" * len(_COLUMNS))
            c.execute(f"INSERT OR REPLACE INTO cases ({','.join(_COLUMNS)}) "
                      f"VALUES ({placeholders})",
                      [record[k] for k in _COLUMNS])

    def delete(self, run_id: str = "", run_dir: str = "") -> int:
        """删除台账记录。API 的 run_id（上传 stem）与磁盘 run 目录名（含内容哈希）
        是两套 ID，两个都匹配一次，避免漏删。"""
        if not run_id and not run_dir:
            return 0
        with self._lock, self._conn() as c:
            cur = c.execute("DELETE FROM cases WHERE run_id=? OR run_dir=?",
                            (run_id or "\x00", run_dir or "\x00"))
            return cur.rowcount

    def delete_many(self, run_ids: List[str]) -> int:
        """複数の台帳行をまとめて削除（run_id / run_dir の両方で照合）。

        v3.8：台帳画面から複数選択して消せるようにするため。1 件ずつ
        API を叩かせると件数分のラウンドトリップが要る上、途中で失敗した
        ときの状態が分かりにくい。
        """
        ids = [x for x in (run_ids or []) if x]
        if not ids:
            return 0
        marks = ",".join("?" * len(ids))
        with self._lock, self._conn() as c:
            cur = c.execute(
                f"DELETE FROM cases WHERE run_id IN ({marks}) OR run_dir IN ({marks})",
                ids + ids)
            return cur.rowcount

    def clear(self) -> int:
        """台帳を空にする（run ディレクトリには触らない）。

        「一覧だけ整理したい。成果物は残す」用途。破壊的なので API 側で
        明示的な確認を要求すること。
        """
        with self._lock, self._conn() as c:
            cur = c.execute("DELETE FROM cases")
            return cur.rowcount

    def search(self, query: str = "", state: str = "", limit: int = 50,
               offset: int = 0) -> Tuple[List[Dict[str, Any]], int]:
        where, params = [], []
        if query.strip():
            like = f"%{query.strip()}%"
            fields = ["input_name", "case_name", "requester", "target",
                      "support_type", "period", "effects"]
            where.append("(" + " OR ".join(f"{f} LIKE ?" for f in fields) + ")")
            params.extend([like] * len(fields))
        if state.strip():
            where.append("state = ?")
            params.append(state.strip())
        clause = ("WHERE " + " AND ".join(where)) if where else ""
        with self._lock, self._conn() as c:
            total = c.execute(f"SELECT COUNT(*) FROM cases {clause}", params).fetchone()[0]
            rows = c.execute(
                f"SELECT * FROM cases {clause} ORDER BY updated_at DESC LIMIT ? OFFSET ?",
                params + [limit, offset]).fetchall()
        return [dict(r) for r in rows], total

    def all_rows(self) -> List[Dict[str, Any]]:
        with self._lock, self._conn() as c:
            rows = c.execute("SELECT * FROM cases ORDER BY updated_at DESC").fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------
    def export_xlsx(self, out_path: str | Path) -> Path:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill
        from openpyxl.utils import get_column_letter

        rows = self.all_rows()
        wb = Workbook()
        ws = wb.active
        ws.title = "案件台帳"
        ws.append(_JP_HEADERS)
        header_fill = PatternFill("solid", fgColor="0F6B5C")
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = header_fill
        for r in rows:
            ws.append([
                r["run_id"], r["input_name"], r["case_name"], r["requester"],
                r["target"], r["support_type"], r["period"], r["effects"],
                r["state"], r["warnings"], "あり" if r["has_external"] else "",
                r["run_dir"],
                time.strftime("%Y-%m-%d %H:%M", time.localtime(r["created_at"] or 0)),
                time.strftime("%Y-%m-%d %H:%M", time.localtime(r["updated_at"] or 0)),
                r.get("template_id", "case"),
            ])
        for i, header in enumerate(_JP_HEADERS, 1):
            width = max([len(str(header)) * 2] +
                        [min(len(str(row[i - 1].value or "")), 40)
                         for row in ws.iter_rows(min_row=2)] or [10])
            ws.column_dimensions[get_column_letter(i)].width = min(width + 2, 44)
        ws.freeze_panes = "A2"
        out = Path(out_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        wb.save(out)
        return out


# ----------------------------------------------------------------------
def record_from_run_dir(run_dir: Path, state: str = "done") -> Optional[Dict[str, Any]]:
    """从 run 目录构建台账记录（磁盘为真源）。"""
    summary_path = run_dir / "case_summary.json"
    manifest_path = run_dir / "manifest.json"
    if not summary_path.exists():
        return None
    try:
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        manifest = (json.loads(manifest_path.read_text(encoding="utf-8"))
                    if manifest_path.exists() else {})
        quality = {}
        qp = run_dir / "quality_report.json"
        if qp.exists():
            quality = json.loads(qp.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None
    template_id = manifest.get("template_id", "case")
    from .template_registry import get_registry
    try:
        title = get_registry().get(template_id).title_of(summary)
    except Exception:  # noqa: BLE001
        title = summary.get("case_name", "")
    rd = summary.get("request_details", {})
    ar = summary.get("action_results", {})
    return {
        "run_id": run_dir.name,
        "template_id": template_id,
        "input_name": Path(manifest.get("input_path", run_dir.name)).name,
        "case_name": title,
        "requester": rd.get("requester", ""),
        "target": rd.get("target_product_or_system", ""),
        "support_type": ar.get("support_type", ""),
        "period": ar.get("period", ""),
        "effects": " / ".join(ar.get("effects", [])),
        "state": state,
        "warnings": " / ".join(quality.get("warnings", [])),
        "has_external": 1 if (run_dir / "case_summary_external.json").exists() else 0,
        "run_dir": str(run_dir),
        "created_at": run_dir.stat().st_mtime,
    }


def rebuild_from_disk(ledger: Ledger, runs_root: Path) -> int:
    """DB 损坏/首次启动时从磁盘全量重建索引。"""
    n = 0
    if not runs_root.exists():
        return 0
    for d in runs_root.iterdir():
        if not d.is_dir():
            continue
        rec = record_from_run_dir(d)
        if rec:
            ledger.upsert(rec)
            n += 1
    return n
