"""
損失台帳（Loss Ledger）— v3.8 Phase 0 の中核。

## なぜ要るのか

v3.7 までのパイプラインには「黙って捨てる」箇所が 6 つあった：

| 箇所 | 切り捨て | 報告 |
|---|---|---|
| chunk_text | `texts[:40]` | なし |
| collect_visual_assets | 画像 30 枚で `break` | 総数のみ |
| visual_to_pack | `readable_text[:10]` | なし |
| visual_to_pack | 32768 文字で `break` | なし |
| excel_extract | 1 シート 400 行 | なし |
| analyze_visual | max_tokens 溢れ → JSON 崩れ → ページ丸ごと skip | errors に 1 行 |

結果として「要約が不正確」という症状だけが見え、**どこで何割落ちたのかが
一切分からない**状態だった。品質レポートは JSON schema 検証しか見ておらず、
「形式は正しいが中身が半分欠けている」を検出できない。

この台帳は **挙動を変えずに損失を可視化する**ためのもの。改造の前に
まずこれを入れて基準線を取る、という順番に意味がある。

## 使い方

    ledger = LossLedger()
    ledger.observe("text_chunk", produced=137)          # 生成された総数
    ledger.drop("text_chunk", 97, "max_text_chunks 上限",
                severity="high", detail="138〜234 番目")
    ...
    ledger.to_dict()      # quality_report.json に載せる
    ledger.summary_lines() # UI / ログ用の日本語 1 行要約

`observe` は「本来いくつ有ったか」、`drop` は「そのうちいくつ落としたか」。
両方入れて初めて `retention_rate`（保持率）が出る。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# 保持率がこれを下回ったら「要注意」として UI に赤字で出す
RETENTION_WARN_THRESHOLD = 0.85
RETENTION_CRITICAL_THRESHOLD = 0.60

# ステージ名 → 日本語表示名（UI とレポート用）
STAGE_LABELS: Dict[str, str] = {
    "text_chunk": "本文チャンク",
    "text_evidence": "本文証拠",
    "visual_asset": "視覚資産（画像）",
    "visual_evidence": "視覚証拠",
    "visual_readable_text": "ページ内読み取りテキスト行",
    "excel_row": "Excel 行",
    "excel_sheet": "Excel シート",
    "pdf_page": "PDF ページ",
    "evidence_pack": "証拠パック",
}


@dataclass
class DropRecord:
    """1 件の切り捨て記録。"""
    stage: str
    count: int
    reason: str
    severity: str = "medium"       # low | medium | high
    detail: str = ""

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "stage": self.stage,
            "stage_label": STAGE_LABELS.get(self.stage, self.stage),
            "count": self.count,
            "reason": self.reason,
            "severity": self.severity,
        }
        if self.detail:
            d["detail"] = self.detail
        return d


@dataclass
class LossLedger:
    """パイプライン全体の「入った数 / 捨てた数」を追う台帳。

    スレッドセーフではない。並行分岐（本文/視覚）でそれぞれ別インスタンスを
    使い、最後に `merge()` で合流させる想定。
    """
    observed: Dict[str, int] = field(default_factory=dict)
    drops: List[DropRecord] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    # -- 記録 ------------------------------------------------------------
    def observe(self, stage: str, produced: int) -> None:
        """このステージで本来いくつ有ったかを記録（加算）。"""
        if produced <= 0:
            return
        self.observed[stage] = self.observed.get(stage, 0) + int(produced)

    def drop(self, stage: str, count: int, reason: str,
             severity: str = "medium", detail: str = "") -> None:
        """切り捨てを記録。count<=0 は無視（無駄な 0 件記録を残さない）。"""
        if count is None or count <= 0:
            return
        self.drops.append(DropRecord(stage=stage, count=int(count), reason=reason,
                                     severity=severity, detail=detail))

    def note(self, text: str) -> None:
        """数値化できない注意事項（COM 不在でフォールバック等）。"""
        if text:
            self.notes.append(text)

    def merge(self, other: "LossLedger") -> None:
        """並行分岐の台帳を取り込む。"""
        if not other:
            return
        for stage, n in other.observed.items():
            self.observed[stage] = self.observed.get(stage, 0) + n
        self.drops.extend(other.drops)
        self.notes.extend(other.notes)

    # -- 往復（LangGraph の並行分岐をまたぐため）----------------------------
    # 本文分岐と視覚分岐は並行に走るので、同じキーに書くと衝突する。
    # 各分岐は自分の台帳を raw dict として別キーに載せ、合流点で復元して
    # merge する。to_dict() は「読む用の集計ビュー」なので往復には使えない。
    def raw(self) -> Dict[str, Any]:
        return {
            "observed": dict(self.observed),
            "drops": [{"stage": d.stage, "count": d.count, "reason": d.reason,
                       "severity": d.severity, "detail": d.detail} for d in self.drops],
            "notes": list(self.notes),
        }

    @classmethod
    def from_raw(cls, data: Optional[Dict[str, Any]]) -> "LossLedger":
        led = cls()
        if not data:
            return led
        led.observed = dict(data.get("observed") or {})
        for d in data.get("drops") or []:
            led.drops.append(DropRecord(
                stage=d.get("stage", "?"), count=int(d.get("count", 0) or 0),
                reason=d.get("reason", ""), severity=d.get("severity", "medium"),
                detail=d.get("detail", "")))
        led.notes = list(data.get("notes") or [])
        return led

    # -- 集計 ------------------------------------------------------------
    def dropped_total(self, stage: str) -> int:
        return sum(d.count for d in self.drops if d.stage == stage)

    def retention(self, stage: str) -> Optional[float]:
        """保持率 = (観測数 - 切り捨て数) / 観測数。観測が無ければ None。"""
        total = self.observed.get(stage, 0)
        if total <= 0:
            return None
        kept = max(0, total - self.dropped_total(stage))
        return round(kept / total, 4)

    def worst_retention(self) -> Optional[float]:
        rates = [r for r in (self.retention(s) for s in self.observed) if r is not None]
        return min(rates) if rates else None

    def has_critical_loss(self) -> bool:
        worst = self.worst_retention()
        if worst is not None and worst < RETENTION_CRITICAL_THRESHOLD:
            return True
        return any(d.severity == "high" for d in self.drops)

    # -- 出力 ------------------------------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        stages: List[Dict[str, Any]] = []
        for stage in sorted(set(self.observed) | {d.stage for d in self.drops}):
            total = self.observed.get(stage, 0)
            dropped = self.dropped_total(stage)
            rate = self.retention(stage)
            stages.append({
                "stage": stage,
                "stage_label": STAGE_LABELS.get(stage, stage),
                "observed": total,
                "dropped": dropped,
                "kept": max(0, total - dropped) if total else None,
                "retention_rate": rate,
                "status": _status_of(rate),
            })
        worst = self.worst_retention()
        return {
            "stages": stages,
            "drops": [d.to_dict() for d in self.drops],
            "notes": list(self.notes),
            "worst_retention_rate": worst,
            "status": _status_of(worst),
            "has_critical_loss": self.has_critical_loss(),
        }

    def summary_lines(self) -> List[str]:
        """UI / ログ用の日本語 1 行要約群。損失が無ければ空リスト。"""
        out: List[str] = []
        for s in self.to_dict()["stages"]:
            if not s["dropped"]:
                continue
            rate = s["retention_rate"]
            pct = f"{rate * 100:.0f}%" if rate is not None else "—"
            out.append(f"{s['stage_label']}：{s['observed']} 件中 {s['dropped']} 件を除外"
                       f"（保持 {pct}）")
        out.extend(self.notes)
        return out


def _status_of(rate: Optional[float]) -> str:
    if rate is None:
        return "unknown"
    if rate < RETENTION_CRITICAL_THRESHOLD:
        return "critical"
    if rate < RETENTION_WARN_THRESHOLD:
        return "warn"
    return "ok"


# ---------------------------------------------------------------------------
# 要素保存則チェック（Phase 1 の受け入れ基準に使う）
# ---------------------------------------------------------------------------

def conservation_check(ledger: LossLedger, stage: str) -> Dict[str, Any]:
    """「解析で出た要素数 == パイプラインに入った要素数 + 明示的除外数」を検算。

    差分が 0 でなければ、どこかにまだ黙って落としている箇所が残っている。
    """
    total = ledger.observed.get(stage, 0)
    dropped = ledger.dropped_total(stage)
    return {
        "stage": stage,
        "observed": total,
        "explicitly_dropped": dropped,
        "accounted": total - dropped,
        "balanced": total >= dropped,
    }


# ---------------------------------------------------------------------------
# 覆盖率（fill_rate）— テンプレート不一致の検知
# ---------------------------------------------------------------------------
#
# 「ファイルに名前もタイトルも有るのに、ほぼ全項目が『資料内で確認できず』」
# という症状の正体は、多くの場合**テンプレートが文書種別に合っていない**こと。
# 技術報告書に「依頼対応事例」テンプレートを当てれば、依頼元・課題・依頼内容・
# 効果は当然すべて空になる。これはモデルの失敗ではなくルーティングの失敗。
#
# ところが v3.7 の品質レポートには「何項目埋まったか」という概念すら無く、
# 人手で気付くしかなかった。ここで数値化して自動で切り替えを促す。


def compute_fill_rate(summary: Dict[str, Any],
                      field_applicability: Dict[str, str],
                      blank_predicate) -> Dict[str, Any]:
    """テンプレート項目の充足率を測る。

    - applicability が n_a の項目は分母から外す（無くて当然なので）
    - optional は分母に入れるが、不足しても警告にしない
    - required の欠落だけが「テンプレート不一致」の証拠になる

    `blank_predicate` は contract.is_blank を渡す（循環 import を避けるため注入）。
    """
    required_total = required_filled = 0
    optional_total = optional_filled = 0
    na_count = 0
    missing_required: List[str] = []

    flat = _flatten(summary)
    for fname, mode in (field_applicability or {}).items():
        if fname == "evidence":
            continue
        if mode == "n_a":
            na_count += 1
            continue
        present = fname in flat and not blank_predicate(flat[fname])
        if mode == "optional":
            optional_total += 1
            optional_filled += int(present)
        else:
            required_total += 1
            required_filled += int(present)
            if not present:
                missing_required.append(fname)

    denom = required_total + optional_total
    filled = required_filled + optional_filled
    rate = round(filled / denom, 4) if denom else None
    req_rate = round(required_filled / required_total, 4) if required_total else None
    return {
        "fill_rate": rate,
        "required_fill_rate": req_rate,
        "required_total": required_total,
        "required_filled": required_filled,
        "optional_total": optional_total,
        "optional_filled": optional_filled,
        "not_applicable": na_count,
        "missing_required": missing_required,
    }


def _flatten(obj: Any, prefix: str = "") -> Dict[str, Any]:
    """入れ子の要約 dict を「末端フィールド名 -> 値」に潰す。

    テンプレートは request_details.requester のように section で入れ子になるが、
    applicability は末端のフィールド名で宣言されるので突き合わせやすくする。
    """
    out: Dict[str, Any] = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, dict):
                out.update(_flatten(v, prefix))
            else:
                out[k] = v
    return out


def template_mismatch_verdict(fill: Dict[str, Any], min_fill_rate: float = 0.4,
                              template_name: str = "") -> Dict[str, Any]:
    """充足率から「テンプレートを変えるべきか」を判定する。"""
    rate = fill.get("required_fill_rate")
    if rate is None:
        return {"mismatch": False, "reason": "必須項目が宣言されていません"}
    if rate >= min_fill_rate:
        return {"mismatch": False, "required_fill_rate": rate}
    miss = fill.get("missing_required") or []
    return {
        "mismatch": True,
        "required_fill_rate": rate,
        "threshold": min_fill_rate,
        "message": (f"テンプレート{'「' + template_name + '」' if template_name else ''}の"
                    f"必須項目のうち {rate * 100:.0f}% しか埋まりませんでした"
                    f"（しきい値 {min_fill_rate * 100:.0f}%）。"
                    f"この文書種別には別のテンプレートの方が適している可能性があります。"),
        "missing_required": miss[:12],
    }
