"""
RAG 出口（v3.3）：把一次运行的产物导出为 embedding-ready JSONL。

每行一条可嵌入记录：
  {"id", "text",                       # text 即送 embedding 的内容
   "metadata": {run_id, case_name, doc, type, section/category,
                confidence, page, tier, created_at}}

设计要点：
- 三类记录：摘要章节（依頼内容/対応結果 各拼成一段自然文）、文本证据（逐条）、
  视觉证据（摘要+关键事实拼段，从文件名 pdf_pNNN 解析页码溯源）
- tier=internal/external：社外版从脱敏后的 summary 生成，证据仅 internal
  （证据是原文摘录，无法保证脱敏，社外包永不携带）
- 磁盘产物 rag_{tier}.jsonl 在流水线末尾落盘，API 亦可按需重新生成
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List

_PAGE_RX = re.compile(r"pdf_p(\d{3})")


def _page_from_path(path: str) -> int | None:
    m = _PAGE_RX.search(path or "")
    return int(m.group(1)) if m else None


def _fmt_value(v, labels: dict, indent: str = "") -> str:
    if isinstance(v, str):
        return v
    if isinstance(v, list):
        return " / ".join(_fmt_value(x, labels) for x in v if x)
    if isinstance(v, dict):
        return "、".join(f"{labels.get(k, k)}: {_fmt_value(x, labels)}"
                          for k, x in v.items() if x)
    return str(v)


def _summary_sections(summary: dict, template_id: str = "case") -> List[Dict[str, str]]:
    """模板无关的章节拼装：spec.rag_sections 定义分组，未分组字段合并为 general。
    records 型字段（如 bulk_requests 的 cases）每条记录单独成一个可嵌入块。"""
    from .template_registry import get_registry
    try:
        spec = get_registry().get(template_id)
    except Exception:  # noqa: BLE001
        spec = get_registry().get("case")
    labels = spec.field_labels
    sections: List[Dict[str, str]] = []
    grouped = set()

    for sec_name, fields in (spec.rag_sections or {}).items():
        lines = []
        for f in fields:
            v = summary.get(f)
            grouped.add(f)
            if v in (None, "", []):
                continue
            lines.append(f"{labels.get(f, f)}: {_fmt_value(v, labels)}")
        if lines:
            sections.append({"section": sec_name, "text": "\n".join(lines)})

    rest_lines = []
    for f, v in summary.items():
        if f in grouped or f == "evidence" or v in (None, "", []):
            continue
        if isinstance(v, list) and v and isinstance(v[0], dict):  # records 型
            for i, rec in enumerate(v):
                sections.append({"section": f"{f}[{i}]",
                                 "text": _fmt_value(rec, labels)})
            grouped.add(f)
            continue
        rest_lines.append(f"{labels.get(f, f)}: {_fmt_value(v, labels)}")
    if rest_lines:
        sections.append({"section": "general", "text": "\n".join(rest_lines)})
    return sections


def build_records(run_dir: str | Path, tier: str = "internal") -> List[Dict[str, Any]]:
    run_dir = Path(run_dir)
    run_id = run_dir.name
    now = time.strftime("%Y-%m-%dT%H:%M:%S")

    summary_file = ("case_summary_external.json" if tier == "external"
                    else "case_summary.json")
    sp = run_dir / summary_file
    if not sp.exists():
        return []
    summary = json.loads(sp.read_text(encoding="utf-8"))
    manifest_tpl = "case"

    manifest = {}
    mp = run_dir / "manifest.json"
    if mp.exists():
        try:
            manifest = json.loads(mp.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            pass
    doc_name = Path(manifest.get("input_path", "")).name
    manifest_tpl = manifest.get("template_id", "case")
    from .template_registry import get_registry
    try:
        case_name = get_registry().get(manifest_tpl).title_of(summary)
    except Exception:  # noqa: BLE001
        case_name = summary.get("case_name", "")

    def meta(**kw) -> Dict[str, Any]:
        return {"run_id": run_id, "case_name": case_name, "doc": doc_name,
                "template_id": manifest_tpl, "tier": tier, "created_at": now, **kw}

    records: List[Dict[str, Any]] = []
    for i, sec in enumerate(_summary_sections(summary, manifest_tpl)):
        records.append({"id": f"{run_id}:{tier}:summary:{i}", "text": sec["text"],
                        "metadata": meta(type="summary_section", section=sec["section"])})

    if tier == "internal":  # 证据为原文摘录，社外包不携带
        agg = run_dir / "evidence_aggregated.json"
        if agg.exists():
            for i, ev in enumerate(json.loads(agg.read_text(encoding="utf-8")).get("evidence", [])):
                if not ev.get("content", "").strip():
                    continue
                records.append({
                    "id": f"{run_id}:internal:evidence:{i}",
                    "text": ev["content"],
                    "metadata": meta(type="text_evidence", category=ev.get("category"),
                                     confidence=ev.get("confidence"),
                                     source=ev.get("source", "")),
                })
        vis = run_dir / "evidence_visual.json"
        if vis.exists():
            for i, ve in enumerate(json.loads(vis.read_text(encoding="utf-8")).get("evidence", [])):
                if not ve.get("has_useful_visual_info"):
                    continue
                text = "\n".join(filter(None, [ve.get("visual_summary", ""),
                                               " / ".join(ve.get("key_facts", []))]))
                if not text.strip():
                    continue
                records.append({
                    "id": f"{run_id}:internal:visual:{i}",
                    "text": text,
                    "metadata": meta(type="visual_evidence",
                                     visual_type=ve.get("visual_type"),
                                     confidence=ve.get("confidence"),
                                     page=_page_from_path(ve.get("image_path", ""))),
                })
    return records


def write_jsonl(run_dir: str | Path, tier: str = "internal") -> Path | None:
    records = build_records(run_dir, tier)
    if not records:
        return None
    out = Path(run_dir) / f"rag_{tier}.jsonl"
    out.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in records) + "\n",
                   encoding="utf-8")
    return out
