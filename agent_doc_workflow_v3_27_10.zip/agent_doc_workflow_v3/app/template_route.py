"""
テンプレート自動判定（v3.11）— LLM を一切使わない安価なルータ。

動機：
    v3.8 で `template_mismatch_verdict` を入れたが、あれは **検証段階** の判定
    だった。「この資料はこのテンプレートに合っていません、generic_doc に
    変えてください」と言われる頃には、証拠抽出も要約も加筆も全部走り終えて
    いる。数十回の LLM 呼出を使い切った後で「やり直し」を告げるのは、
    情報としては正しくても運用としては遅すぎる。

    `template.yaml` には最初から `filename_hints` という枠があったのに、
    どこからも参照されていなかった。ここを実際に効かせて、**解析直後・
    最初の LLM 呼出の前** にテンプレートを選ぶ。

置き場所：
    `parse_document` の直後。`create_run_dir` の直後ではない——その時点では
    まだ文書を解析しておらず「本文の冒頭」が存在しないため。最初の LLM 呼出
    （extract_text_evidence）はさらに後なので、費用の節約効果は変わらない。

判定材料（どちらも既に手元にある。追加コストはほぼゼロ）：
    - ファイル名           … 重み 3.0（人が付けた名前は種別を強く示す）
    - 本文の冒頭 2000 字   … 重み 1.0（表題・目次・書き出しが入る範囲）

確信が持てない時は「決め打ちしない」：
    最高点がしきい値未満、または 2 位との差が僅少（＝どちらとも取れる）なら
    汎用テンプレートに落とす。generic_doc の説明文そのものが
    「文書種別が特定できない資料のための受け皿」なので、これが正しい降伏点。

検証段階の fill_rate 判定は廃止しない。前段で外した時の**最後の網**として
そのまま残す（二重の守り）。
"""
from __future__ import annotations

import unicodedata
from pathlib import Path
from typing import Any, Dict, List, Tuple

#: ファイル名でヒットした時の重み。人が付けた名前は種別を強く示すので厚めに。
WEIGHT_FILENAME = 3.0
#: 本文冒頭でヒットした時の重み（語ごとに 1 回だけ数える。連呼で勝たせない）。
WEIGHT_CONTENT = 1.0
#: 本文のどこまでを見るか。表題・目次・書き出しが入れば十分。
HEAD_CHARS = 2000
#: これ未満なら「判定材料が足りない」とみなす。
MIN_SCORE = 3.0
#: 1 位が 2 位のこの倍率に届かないなら「どちらとも取れる」とみなす。
#: 絶対差ではなく比率にしてある——絶対差だと「8 対 5」と「20 対 17」を
#: 同じ僅差と判定してしまい、得点が大きい領域では 1 語の当たり外れで
#: 結論がひっくり返る。比率なら尺度が変わっても意味が変わらない。
MIN_MARGIN_RATIO = 1.5
#: 確信が持てない時の落とし先。
FALLBACK_ID = "generic_doc"


def _norm(text: str) -> str:
    """全角/半角・大文字小文字の揺れを吸収する。

    日本語資料はファイル名も本文も全角英数と半角が混在するので、
    NFKC で正規化しないと「ＰＰＴ」と「PPT」が別物になる。
    """
    return unicodedata.normalize("NFKC", text or "").lower()


def _score_one(spec, file_norm: str, head_norm: str) -> Tuple[float, List[str]]:
    """1 テンプレート分の得点と、根拠になった語を返す。"""
    score = 0.0
    hits: List[str] = []

    for hint in getattr(spec, "filename_hints", []) or []:
        h = _norm(hint)
        if h and h in file_norm:
            score += WEIGHT_FILENAME
            hits.append(f"ファイル名『{hint}』")

    for hint in getattr(spec, "content_hints", []) or []:
        h = _norm(hint)
        if h and h in head_norm:
            score += WEIGHT_CONTENT
            hits.append(f"本文『{hint}』")

    return score, hits


def decide_template(
    input_path: str,
    head_text: str,
    registry,
    fallback_id: str = FALLBACK_ID,
) -> Dict[str, Any]:
    """テンプレートを選ぶ。LLM は呼ばない。

    返り値::

        {"template_id": "tech_report",
         "reason": "ファイル名『報告書』/ 本文『目的』…",
         "scores": {"tech_report": 6.0, "case": 1.0, ...},
         "hits":   {"tech_report": ["ファイル名『報告書』", ...]},
         "confident": True}

    `confident=False` は「決め手が無いので汎用に落とした」の意味。呼び出し側は
    この値をトレースに残し、後段の fill_rate 判定と突き合わせられる。
    """
    file_norm = _norm(Path(input_path).stem)
    head_norm = _norm((head_text or "")[:HEAD_CHARS])

    scores: Dict[str, float] = {}
    hits: Dict[str, List[str]] = {}
    for entry in registry.list():
        tid = entry["id"]
        if tid == fallback_id:
            continue  # 受け皿自身は競争に参加しない（ヒントを持たない前提）
        try:
            spec = registry.get(tid)
        except KeyError:
            continue
        s, h = _score_one(spec, file_norm, head_norm)
        scores[tid] = s
        if h:
            hits[tid] = h

    if not scores:
        return {"template_id": fallback_id, "reason": "候補テンプレートがありません",
                "scores": {}, "hits": {}, "confident": False}

    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    top_id, top_score = ranked[0]
    second_score = ranked[1][1] if len(ranked) > 1 else 0.0

    if top_score < MIN_SCORE:
        return {"template_id": fallback_id,
                "reason": (f"決め手となる語が見つからないため汎用テンプレート"
                           f"（最高点 {top_score:.1f} < {MIN_SCORE}）"),
                "scores": scores, "hits": hits, "confident": False}

    if top_score < second_score * MIN_MARGIN_RATIO:
        return {"template_id": fallback_id,
                "reason": (f"複数のテンプレートに同程度に該当するため汎用テンプレート"
                           f"（{top_id} {top_score:.1f} 対 {ranked[1][0]} {second_score:.1f}）"),
                "scores": scores, "hits": hits, "confident": False}

    return {"template_id": top_id,
            "reason": "・".join(hits.get(top_id, [])[:4]) or f"得点 {top_score:.1f}",
            "scores": scores, "hits": hits, "confident": True}
