"""
PowerPoint / Word の COM 経由 PDF 変換（v3.10）。

## なぜ要るのか

視覚直読ルートで「スライド 1 枚 ＝ 画像 1 枚」を得るには、まず PDF に
しなければならない。v3.9 までこれは **LibreOffice headless 一択**だった。

しかし LibreOffice が入っていない Windows 機では `office_to_pdf` が
必ず `ok=False` を返し、視覚ルートは埋め込み画像だけを見る状態に
落ちていた。エラーにはならないので、気付かないまま「PPT の視覚分析が
効いていない」状態で動き続ける。

Excel は既に COM 経由（`excel_com.py`）で処理しているのに、PowerPoint と
Word だけ外部アプリに依存しているのは筋が通らない。Office が入っている
機械なら PowerPoint も Word も同じやり方で PDF を出せる。

## 旧バイナリ形式（.ppt / .doc / .xls）にも効く

OOXML ではないので ZIP 解体は使えず、Docling も苦手。しかし COM は
アプリ本体に開かせるので**旧形式こそ最も確実に扱える**。
LibreOffice 兜底しか無かった経路が、ここで正攻法になる。

## COM の癖（実装上の注意）

- **PowerPoint は `Visible = False` を受け付けない**（多くのバージョンで
  例外になる）。代わりに `Open(..., WithWindow=False)` で画面を出さずに開く。
- 定数はアプリごとに値が違う。`ppAlertsNone = 1` なのに `wdAlertsNone = 0`
  という罠があるので、名前ではなく直値で持つ。
- マクロは `AutomationSecurity = 3`（ForceDisable）で必ず殺す。業務資料には
  マクロ付きが混ざるため、開いた瞬間に実行されると事故になる。
- 固まったときにサーバ本体を巻き込まないよう、別スレッド＋ハードタイムアウト
  で隔離し、自分が起こしたプロセスだけを PID 指定で落とす。
"""
from __future__ import annotations

import os
import queue
import threading
from pathlib import Path
from typing import Any, Dict, Optional

# --- 定数（COM の定数解決に頼らず直値で持つ）-------------------------------
_MSO_SECURITY_FORCE_DISABLE = 3     # マクロを一切実行しない
_MSO_FALSE = 0

# PowerPoint
_PP_ALERTS_NONE = 1                 # ppAlertsNone（※ ppAlertsAll = 2）
_PP_SAVE_AS_PDF = 32                # ppSaveAsPDF

# Word
_WD_ALERTS_NONE = 0                 # wdAlertsNone（PowerPoint と値が違う）
_WD_EXPORT_PDF = 17                 # wdExportFormatPDF / wdFormatPDF

#: 拡張子 → どのアプリに開かせるか
_APP_FOR_SUFFIX = {
    ".pptx": "powerpoint", ".pptm": "powerpoint", ".ppt": "powerpoint",
    ".docx": "word", ".docm": "word", ".doc": "word", ".rtf": "word",
}


def _com_importable() -> bool:
    if os.name != "nt":
        return False
    try:
        import pythoncom  # noqa: F401
        import win32com.client  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def _app_available(prog_id: str) -> bool:
    """アプリ本体が入っているかを軽く確かめる（起動はしない）。"""
    if not _com_importable():
        return False
    try:
        import win32com.client
        # CLSID 解決だけ行う。実体を起動しないので速い。
        win32com.client.gencache.EnsureDispatch  # noqa: B018 属性の存在確認
        from win32com.client import dynamic  # noqa: F401
        import pythoncom
        pythoncom.CoInitialize()
        try:
            pythoncom.ProgIDFromCLSID(pythoncom.CLSIDFromProgID(prog_id))
            return True
        finally:
            pythoncom.CoUninitialize()
    except Exception:  # noqa: BLE001
        return False


def powerpoint_available() -> bool:
    return _app_available("PowerPoint.Application")


def word_available() -> bool:
    return _app_available("Word.Application")


def office_com_available_for(suffix: str) -> bool:
    """この拡張子を COM で扱えるか。"""
    app = _APP_FOR_SUFFIX.get(suffix.lower())
    if app == "powerpoint":
        return powerpoint_available()
    if app == "word":
        return word_available()
    return False


def _run_with_timeout(fn, timeout: float, app_name: str) -> Dict[str, Any]:
    """COM 操作を別スレッドに隔離してハードタイムアウトを掛ける。

    固まった Office にサーバ本体まで巻き込まれないための隔壁。
    """
    box: "queue.Queue[Dict[str, Any]]" = queue.Queue(maxsize=1)

    def _target():
        try:
            box.put(fn())
        except Exception as e:  # noqa: BLE001
            box.put({"ok": False, "error": f"{type(e).__name__}: {e}"})

    t = threading.Thread(target=_target, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        return {"ok": False, "timeout": True,
                "error": f"{app_name} の操作がタイムアウトしました（{timeout:.0f} 秒）"}
    try:
        return box.get_nowait()
    except queue.Empty:
        return {"ok": False, "error": f"{app_name} が結果を返しませんでした"}


def _kill_pid(pid: Optional[int]) -> None:
    """自分が起こしたプロセスだけを落とす。

    taskkill /IM で名前指定すると、利用者が開いている資料まで巻き添えにする。
    """
    if not pid:
        return
    try:
        import subprocess
        subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                       capture_output=True, timeout=15)
    except Exception:  # noqa: BLE001
        pass


# ---------------------------------------------------------------------------
# PowerPoint
# ---------------------------------------------------------------------------

def pptx_to_pdf(input_path: str, out_dir: str,
                timeout_seconds: float = 600) -> Dict[str, Any]:
    """PowerPoint（.pptx/.pptm/.ppt）を PDF へ。"""
    if not powerpoint_available():
        return {"ok": False, "error": "PowerPoint COM が利用できません"}

    src = Path(input_path).expanduser().resolve()
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    pdf_path = out / f"{src.stem}.pdf"

    def _work() -> Dict[str, Any]:
        import pythoncom
        import win32com.client

        pythoncom.CoInitialize()
        app = None
        pres = None
        pid = None
        try:
            app = win32com.client.DispatchEx("PowerPoint.Application")
            # PowerPoint は Visible=False を拒否するバージョンが多い。
            # 画面を出さないためには Open(WithWindow=False) を使う。
            try:
                app.DisplayAlerts = _PP_ALERTS_NONE
            except Exception:  # noqa: BLE001
                pass
            try:
                app.AutomationSecurity = _MSO_SECURITY_FORCE_DISABLE
            except Exception:  # noqa: BLE001
                pass
            try:
                import win32process
                _, pid = win32process.GetWindowThreadProcessId(app.HWND)
            except Exception:  # noqa: BLE001 HWND が取れない構成もある
                pid = None

            pres = app.Presentations.Open(
                str(src), ReadOnly=True, Untitled=False, WithWindow=_MSO_FALSE)
            pres.SaveAs(str(pdf_path), _PP_SAVE_AS_PDF)

            if pdf_path.exists() and pdf_path.stat().st_size > 0:
                slides = 0
                try:
                    slides = int(pres.Slides.Count)
                except Exception:  # noqa: BLE001
                    pass
                return {"ok": True, "pdf_path": str(pdf_path), "slides": slides}
            return {"ok": False, "error": "PDF が生成されませんでした"}
        finally:
            for closer in (lambda: pres.Close() if pres else None,
                           lambda: app.Quit() if app else None):
                try:
                    closer()
                except Exception:  # noqa: BLE001
                    pass
            pres = app = None
            try:
                pythoncom.CoUninitialize()
            except Exception:  # noqa: BLE001
                pass
            _kill_pid(pid)

    return _run_with_timeout(_work, timeout_seconds, "PowerPoint")


# ---------------------------------------------------------------------------
# Word
# ---------------------------------------------------------------------------

def docx_to_pdf(input_path: str, out_dir: str,
                timeout_seconds: float = 600) -> Dict[str, Any]:
    """Word（.docx/.docm/.doc/.rtf）を PDF へ。"""
    if not word_available():
        return {"ok": False, "error": "Word COM が利用できません"}

    src = Path(input_path).expanduser().resolve()
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    pdf_path = out / f"{src.stem}.pdf"

    def _work() -> Dict[str, Any]:
        import pythoncom
        import win32com.client

        pythoncom.CoInitialize()
        app = None
        doc = None
        pid = None
        try:
            app = win32com.client.DispatchEx("Word.Application")
            # Word は Visible を受け付ける（PowerPoint と違う点）
            for setter in (
                lambda: setattr(app, "Visible", False),
                lambda: setattr(app, "DisplayAlerts", _WD_ALERTS_NONE),
                lambda: setattr(app, "AutomationSecurity", _MSO_SECURITY_FORCE_DISABLE),
                lambda: setattr(app, "ScreenUpdating", False),
            ):
                try:
                    setter()
                except Exception:  # noqa: BLE001
                    pass
            try:
                import win32process
                _, pid = win32process.GetWindowThreadProcessId(app.Hwnd)
            except Exception:  # noqa: BLE001
                pid = None

            # パスワード付きで止まらないようダミーを渡す（Excel 側と同じ手）
            doc = app.Documents.Open(
                str(src), ConfirmConversions=False, ReadOnly=True,
                AddToRecentFiles=False, PasswordDocument="_no_pw_",
                Visible=False)
            doc.ExportAsFixedFormat(OutputFileName=str(pdf_path),
                                    ExportFormat=_WD_EXPORT_PDF)

            if pdf_path.exists() and pdf_path.stat().st_size > 0:
                pages = 0
                try:
                    # wdStatisticPages = 2
                    pages = int(doc.ComputeStatistics(2))
                except Exception:  # noqa: BLE001
                    pass
                return {"ok": True, "pdf_path": str(pdf_path), "pages": pages}
            return {"ok": False, "error": "PDF が生成されませんでした"}
        finally:
            for closer in (lambda: doc.Close(SaveChanges=False) if doc else None,
                           lambda: app.Quit(SaveChanges=False) if app else None):
                try:
                    closer()
                except Exception:  # noqa: BLE001
                    pass
            doc = app = None
            try:
                pythoncom.CoUninitialize()
            except Exception:  # noqa: BLE001
                pass
            _kill_pid(pid)

    return _run_with_timeout(_work, timeout_seconds, "Word")


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------

def office_to_pdf_com(input_path: str, out_dir: str,
                      timeout_seconds: float = 600) -> Dict[str, Any]:
    """拡張子を見て適切なアプリで PDF 化する。

    .xlsx/.xlsm/.xls は Excel 側（excel_com.excel_sheet_pdfs）が
    シート単位・横 1 ページ設定で処理する方が良いので、ここでは扱わない。
    """
    suffix = Path(input_path).suffix.lower()
    app = _APP_FOR_SUFFIX.get(suffix)
    if app == "powerpoint":
        return pptx_to_pdf(input_path, out_dir, timeout_seconds)
    if app == "word":
        return docx_to_pdf(input_path, out_dir, timeout_seconds)
    return {"ok": False, "error": f"COM 変換の対象外の形式です: {suffix}"}
