"""
Excel COM 経路（Windows + Microsoft Excel がある環境のみ）。

## 位置づけ：あくまで"上乗せ"

純 Python 経路（`app/excel_extract.py`）だけでも要約は成立する。COM はそこに
**Excel にしか出せない物**を足すためだけに使う：

1. **ブック全体の PDF**（`ExportAsFixedFormat`）
   → v3.6 の視覚ルートに載せれば、ピボットの見た目・条件付き書式・図形・
     グラフが「印刷したとおり」VLM に届く。人が見ている物と同じ物を渡せる。
2. **グラフ画像**（`Chart.Export`）→ Agent 2 の資産に直接追加
3. **計算済みの値**（`UsedRange.Value2`）→ 数式ではなく結果が取れる

## COM を使うときに必ず要る安全弁（旧実装に無くて事故のもとだった物）

サーバプロセスから Excel を叩くのは、放っておくと確実に事故る：

- **マクロが勝手に走る**：`.xlsm` を開くと `Workbook_Open` / `Auto_Open` が発火する。
  `AutomationSecurity = 3`（msoAutomationSecurityForceDisable）で完全に無効化する。
  ——旧 `_xlsx_to_html_with_excel` はこれを設定していなかった。
- **モーダルダイアログで永久に固まる**：外部リンクの「更新しますか？」、
  読み取り推奨、破損ファイルの修復確認。`UpdateLinks=0` / `AskToUpdateLinks=False`
  / `IgnoreReadOnlyRecommended=True` / ダミーパスワードで塞ぐ。
  （パスワード付きブックは入力待ちで固まるので、ダミーを渡して即失敗させる）
- **EXCEL.EXE が残留する**：例外時に必ず Quit + Release、それでも残るなら
  起動した PID だけを狙って落とす（他人の Excel は絶対に殺さない）。
- **止まらない**：全体を別スレッドに載せてハードタイムアウトを掛ける。

これらが無い COM 連携は、いずれ必ず「サーバが無反応」になる。
"""
from __future__ import annotations

import os
import queue
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

# Excel の定数（win32com の定数解決に頼らず直値で持つ）
_XL_TYPE_PDF = 0                     # xlTypePDF
_MSO_SECURITY_FORCE_DISABLE = 3      # マクロを一切実行しない
_XL_FILTER_PNG = "PNG"


def excel_available() -> bool:
    """Windows で Excel COM が使えるか（import できるか＋起動できるか）。"""
    if os.name != "nt":
        return False
    try:
        import pythoncom  # noqa: F401
        import win32com.client  # noqa: F401
    except Exception:  # noqa: BLE001
        return False
    return True


def _run_with_timeout(fn, timeout: float) -> Dict[str, Any]:
    """COM 操作を別スレッドに隔離してハードタイムアウトを掛ける。
    固まった Excel にサーバ本体まで巻き込まれないための隔壁。"""
    box: "queue.Queue[Dict[str, Any]]" = queue.Queue(maxsize=1)

    def _target():
        try:
            box.put(fn())
        except Exception as e:  # noqa: BLE001
            box.put({"ok": False, "error": f"{type(e).__name__}: {e}"})

    t = threading.Thread(target=_target, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        return {"ok": False, "error": f"Excel 操作がタイムアウトしました（{timeout:.0f} 秒）",
                "timeout": True}
    try:
        return box.get_nowait()
    except queue.Empty:
        return {"ok": False, "error": "Excel 操作が結果を返しませんでした"}


def _kill_pid(pid: Optional[int]) -> None:
    """自分が起動した EXCEL.EXE だけを落とす（利用者が開いている Excel は触らない）。"""
    if not pid:
        return
    try:
        import subprocess
        subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                       capture_output=True, timeout=15)
    except Exception:  # noqa: BLE001
        pass


def excel_extract(input_path: str, out_dir: str, *,
                  export_pdf: bool = True,
                  export_charts: bool = True,
                  max_charts: int = 30,
                  timeout_seconds: float = 300) -> Dict[str, Any]:
    """
    ブックから PDF とグラフ画像を書き出す。

    戻り値: {ok, pdf_path, chart_images[], sheets, error}
    失敗しても例外は投げない（呼び出し側は純 Python 経路へ落ちるだけ）。
    """
    if not excel_available():
        return {"ok": False, "error": "Excel COM が利用できません（Windows + Excel が必要）",
                "chart_images": []}

    src = Path(input_path).expanduser().resolve()
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    def _work() -> Dict[str, Any]:
        import pythoncom
        import win32com.client

        pythoncom.CoInitialize()
        excel = None
        wb = None
        pid = None
        result: Dict[str, Any] = {"ok": False, "chart_images": [], "sheets": []}
        try:
            excel = win32com.client.DispatchEx("Excel.Application")
            # ---- 安全弁（順番に意味がある：Open の前に全部立てる）----
            excel.Visible = False
            excel.DisplayAlerts = False           # 各種確認ダイアログを出さない
            excel.AskToUpdateLinks = False        # 「リンクを更新しますか？」を抑止
            excel.EnableEvents = False            # シートイベントを走らせない
            excel.ScreenUpdating = False
            try:
                excel.AutomationSecurity = _MSO_SECURITY_FORCE_DISABLE   # マクロ完全無効
            except Exception:  # noqa: BLE001 古い Excel には無い
                pass
            try:
                import win32process
                _, pid = win32process.GetWindowThreadProcessId(excel.Hwnd)
            except Exception:  # noqa: BLE001 PID が取れなくても続行
                pid = None

            wb = excel.Workbooks.Open(
                str(src),
                UpdateLinks=0,                    # 外部リンクを更新しない（固まる元）
                ReadOnly=True,
                IgnoreReadOnlyRecommended=True,
                Password="_no_pw_",               # 保護ブックは入力待ちにせず即失敗させる
                WriteResPassword="_no_pw_",
                Notify=False,
            )

            result["sheets"] = [str(ws.Name) for ws in wb.Worksheets]

            if export_pdf:
                pdf_path = out / f"{src.stem}.pdf"
                try:
                    wb.ExportAsFixedFormat(_XL_TYPE_PDF, str(pdf_path))
                    if pdf_path.exists():
                        result["pdf_path"] = str(pdf_path)
                except Exception as e:  # noqa: BLE001 印刷範囲未設定などで落ちうる
                    result["pdf_error"] = repr(e)[:200]

            if export_charts:
                images: List[str] = []
                try:
                    for ws in wb.Worksheets:
                        for i in range(1, ws.ChartObjects().Count + 1):
                            if len(images) >= max_charts:
                                break
                            p = out / f"chart_{ws.Index:02d}_{i:02d}.png"
                            try:
                                ws.ChartObjects(i).Chart.Export(str(p), _XL_FILTER_PNG)
                                if p.exists():
                                    images.append(str(p))
                            except Exception:  # noqa: BLE001 1 個失敗しても続行
                                continue
                    for i in range(1, wb.Charts.Count + 1):      # グラフシート
                        if len(images) >= max_charts:
                            break
                        p = out / f"chartsheet_{i:02d}.png"
                        try:
                            wb.Charts(i).Export(str(p), _XL_FILTER_PNG)
                            if p.exists():
                                images.append(str(p))
                        except Exception:  # noqa: BLE001
                            continue
                except Exception as e:  # noqa: BLE001
                    result["chart_error"] = repr(e)[:200]
                result["chart_images"] = images

            result["ok"] = bool(result.get("pdf_path") or result["chart_images"])
            if not result["ok"]:
                result["error"] = "PDF もグラフ画像も生成できませんでした"
            return result
        finally:
            for closer in (lambda: wb.Close(SaveChanges=False) if wb else None,
                           lambda: excel.Quit() if excel else None):
                try:
                    closer()
                except Exception:  # noqa: BLE001
                    pass
            wb = excel = None
            try:
                pythoncom.CoUninitialize()
            except Exception:  # noqa: BLE001
                pass
            _kill_pid(pid)      # Quit しても残ることがあるので最後に念押し

    outcome = _run_with_timeout(_work, timeout_seconds)
    outcome.setdefault("chart_images", [])
    return outcome


# ---------------------------------------------------------------------------
# v3.8：シート単位のページ画像化（視覚ルート用）
# ---------------------------------------------------------------------------
#
# ブック丸ごとの ExportAsFixedFormat には致命的な弱点がある：
# **横に広い表が数十ページの断片に飛び散る**。人が見て読めない物を VLM に
# 渡しても意味が無い。LibreOffice の SinglePageSheets も同じ問題を抱える上、
# 約 1022 行でデータが欠ける既知の不具合がある。
#
# Excel COM ならこれを正攻法で潰せる：エクスポート前に PageSetup で
# **「横 1 ページに収める・縦は流す」**を設定する。横幅だけ 1 ページに圧縮し、
# 縦は自然に複数ページへ流すのが、可読性と情報量の最良の折衷点。
# （縦も 1 ページに押し込むと、長い台帳が豆粒になって読めなくなる）
#
# ただし PageSetup はプロパティを 1 つ触るたびにプリンタドライバと往復する
# ため**異常に遅い**。`Application.PrintCommunication = False` で往復を止め、
# まとめて設定してから True に戻す（Excel 2010+）。これが無いとシート数が
# 多いブックで数分単位の待ちが発生する。

_XL_PORTRAIT = 1
_XL_LANDSCAPE = 2
_XL_SHEET_VISIBLE = -1


def excel_sheet_pdfs(input_path: str, out_dir: str, *,
                     max_sheets: int = 20,
                     fit_to_width: bool = True,
                     landscape: bool = True,
                     include_hidden: bool = False,
                     timeout_seconds: float = 600) -> Dict[str, Any]:
    """各ワークシートを個別の PDF に書き出す（視覚ルート用）。

    戻り値: {ok, sheets:[{name, index, pdf_path, used_range, skipped, reason}],
             exported, skipped, error}

    失敗しても例外は投げない。呼び出し側は純 Python 経路（numCache 数値表）へ
    落ちるだけで、要約自体は成立する。
    """
    if not excel_available():
        return {"ok": False, "error": "Excel COM が利用できません（Windows + Excel が必要）",
                "sheets": [], "exported": 0, "skipped": 0}

    src = Path(input_path).expanduser().resolve()
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    def _work() -> Dict[str, Any]:
        import pythoncom
        import win32com.client

        pythoncom.CoInitialize()
        excel = None
        wb = None
        pid = None
        sheets_meta: List[Dict[str, Any]] = []
        try:
            excel = win32com.client.DispatchEx("Excel.Application")
            # ---- 安全弁（excel_extract と同一。Open の前に全部立てる）----
            excel.Visible = False
            excel.DisplayAlerts = False
            excel.AskToUpdateLinks = False
            excel.EnableEvents = False
            excel.ScreenUpdating = False
            try:
                excel.AutomationSecurity = _MSO_SECURITY_FORCE_DISABLE
            except Exception:  # noqa: BLE001
                pass
            try:
                import win32process
                _, pid = win32process.GetWindowThreadProcessId(excel.Hwnd)
            except Exception:  # noqa: BLE001
                pid = None

            wb = excel.Workbooks.Open(
                str(src), UpdateLinks=0, ReadOnly=True,
                IgnoreReadOnlyRecommended=True,
                Password="_no_pw_", WriteResPassword="_no_pw_", Notify=False,
            )

            exported = 0
            skipped = 0
            for ws in wb.Worksheets:
                name = str(ws.Name)
                idx = int(ws.Index)
                if len(sheets_meta) >= max_sheets:
                    sheets_meta.append({"name": name, "index": idx, "skipped": True,
                                        "reason": f"max_sheets={max_sheets} 上限"})
                    skipped += 1
                    continue
                # 非表示シートは既定で対象外（作業用の隠しシートが多いため）
                try:
                    if not include_hidden and int(ws.Visible) != _XL_SHEET_VISIBLE:
                        sheets_meta.append({"name": name, "index": idx, "skipped": True,
                                            "reason": "非表示シート"})
                        skipped += 1
                        continue
                except Exception:  # noqa: BLE001
                    pass
                # 空シートを PDF 化しても白紙が増えるだけ
                used = ""
                try:
                    used = str(ws.UsedRange.Address)
                    if ws.UsedRange.Count <= 1 and not str(ws.UsedRange.Value2 or ""):
                        sheets_meta.append({"name": name, "index": idx, "skipped": True,
                                            "reason": "空シート", "used_range": used})
                        skipped += 1
                        continue
                except Exception:  # noqa: BLE001
                    pass

                # ---- ページ設定（PrintCommunication で往復を止めてから）----
                if fit_to_width:
                    try:
                        excel.PrintCommunication = False   # Excel 2010+
                    except Exception:  # noqa: BLE001
                        pass
                    try:
                        ps = ws.PageSetup
                        ps.Orientation = _XL_LANDSCAPE if landscape else _XL_PORTRAIT
                        ps.Zoom = False                 # FitToPages より先に必ず False
                        ps.FitToPagesWide = 1           # 横は 1 ページに圧縮
                        ps.FitToPagesTall = False       # 縦は自然に流す（潰すと読めない）
                        ps.PrintTitleRows = "$1:$1"     # 各ページに見出し行を反復
                    except Exception:  # noqa: BLE001 印刷範囲未設定などで落ちうる
                        pass
                    try:
                        excel.PrintCommunication = True
                    except Exception:  # noqa: BLE001
                        pass

                safe = _safe_name(name)
                pdf_path = out / f"sheet_{idx:02d}_{safe}.pdf"
                try:
                    ws.ExportAsFixedFormat(_XL_TYPE_PDF, str(pdf_path))
                    if pdf_path.exists() and pdf_path.stat().st_size > 0:
                        sheets_meta.append({"name": name, "index": idx,
                                            "pdf_path": str(pdf_path),
                                            "used_range": used, "skipped": False})
                        exported += 1
                    else:
                        sheets_meta.append({"name": name, "index": idx, "skipped": True,
                                            "reason": "PDF が生成されなかった"})
                        skipped += 1
                except Exception as e:  # noqa: BLE001 1 シート失敗しても続行
                    sheets_meta.append({"name": name, "index": idx, "skipped": True,
                                        "reason": f"書き出し失敗: {repr(e)[:120]}"})
                    skipped += 1

            return {"ok": exported > 0, "sheets": sheets_meta,
                    "exported": exported, "skipped": skipped,
                    "error": "" if exported else "PDF を 1 枚も生成できませんでした"}
        finally:
            for closer in (lambda: wb.Close(SaveChanges=False) if wb else None,
                           lambda: excel.Quit() if excel else None):
                try:
                    closer()
                except Exception:  # noqa: BLE001
                    pass
            wb = excel = None
            try:
                pythoncom.CoUninitialize()
            except Exception:  # noqa: BLE001
                pass
            _kill_pid(pid)

    outcome = _run_with_timeout(_work, timeout_seconds)
    outcome.setdefault("sheets", [])
    outcome.setdefault("exported", 0)
    outcome.setdefault("skipped", 0)
    return outcome


def _safe_name(name: str) -> str:
    """シート名をファイル名に使える形へ（日本語はそのまま残す）。"""
    bad = '\\/:*?"<>|'
    cleaned = "".join("_" if ch in bad else ch for ch in name).strip(" .")
    return (cleaned or "sheet")[:40]
