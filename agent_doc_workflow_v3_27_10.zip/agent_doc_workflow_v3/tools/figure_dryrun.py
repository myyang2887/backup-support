"""
図版差し込みの dry-run（v3.27）。

閾値（min_score / min_margin）は資料の性格で当たりが変わる。本番の
要約を書き換えずに、既存の run ディレクトリに対して「何が何点で、
なぜ落ちたか」だけを見るための道具。

    # 1 件を採点だけする（md は書き換えない）
    python -m tools.figure_dryrun out/20260910_120000_xxxx

    # 閾値を振って歩留まりを見る
    python -m tools.figure_dryrun out/*/ --sweep

    # 実際に差し込む（確認できたら）
    python -m tools.figure_dryrun out/20260910_120000_xxxx --apply

出力の見方：
  score   総合点（0-1）
  margin  2 位との差。ここが小さい＝「どの図とも取れる」＝不採用が正しい
  parts   成分ごとの寄与。numeric が None なら本文に数値が無かった
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.figure_select import (DEFAULTS, attach_figures_to_run,  # noqa: E402
                               select_figures)


def _load(run_dir: Path) -> Dict[str, Any]:
    def _j(name: str) -> Any:
        p = run_dir / name
        if not p.exists():
            return {}
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return {}
    vis = _j("evidence_visual.json")
    txt = _j("evidence_text.json")
    md = run_dir / "case_summary.md"
    return {
        "md": md.read_text(encoding="utf-8") if md.exists() else "",
        "visual": vis.get("evidence", []) if isinstance(vis, dict) else [],
        "text": (txt.get("evidence", []) or txt.get("aggregated", []))
                if isinstance(txt, dict) else (txt or []),
    }


def discover_runs(args: List[str]) -> List[Path]:
    """run ディレクトリを見つける。

    実際の配置は `out/runs/<案件名>_<日時>/` で、`out/` 直下ではない。
    利用者に正確なパスを打たせるのは筋が悪いので、渡されたパスの下から
    `case_summary.md` を持つディレクトリを再帰的に拾う。引数なしなら
    `out/runs` → `out` の順に探す。
    """
    roots = [Path(a) for a in args] if args else [Path("out/runs"), Path("out")]
    found: List[Path] = []
    seen: set = set()

    def _add(p: Path) -> None:
        rp = p.resolve()
        if rp not in seen:
            seen.add(rp)
            found.append(p)

    for root in roots:
        if not root.exists():
            continue
        if (root / "case_summary.md").exists():
            _add(root)
            continue
        # 深すぎる探索は避ける（out/ 配下は versions/ などを含む）
        for md in sorted(root.glob("*/case_summary.md")) + \
                sorted(root.glob("*/*/case_summary.md")):
            _add(md.parent)
    return found


def _report_one(run_dir: Path, cfg: Dict[str, Any], show_all: bool) -> Dict[str, Any]:
    data = _load(run_dir)
    if not data["md"]:
        print(f"  [skip] case_summary.md がありません: {run_dir}")
        return {}
    picks, report = select_figures(data["md"], data["visual"], data["text"],
                                   run_dir=run_dir, cfg=cfg)
    print(f"\n=== {run_dir.name} ===")
    print(f"  視覚証拠 {report.get('visual_evidence_in', 0)} 件 → "
          f"候補 {report['candidates']} 枚 / 対象文 {report['anchors']} 件 "
          f"→ 採用 {len(picks)} 枚")
    if report.get("reason"):
        print(f"  理由: {report['reason']}")

    # 候補 0 枚のとき、どの門で落ちたかが分からないと切り分けできない
    for k, v in (report.get("dropped_by") or {}).items():
        print(f"    - 除外 {v:>3} 枚: {k}")

    for p in report["picked"]:
        print(f"  [採用] 図{p['figure_no']}  score={p['score']:.3f} "
              f"margin={p['margin']:.3f}  {p['sheet_name'] or ('p.' + str(p['page']))}")
        print(f"         文: {p['bullet'][:56]}")
        print(f"         図: {Path(p['image']).name}  {p['breakdown']['parts']}")

    if not picks and report.get("best"):
        b = report["best"]
        print(f"  [惜しい] score={b['score']:.3f} margin={b['margin']:.3f}")
        print(f"           文: {b['bullet'][:56]}")
        print(f"           図: {b['image']}  {b['breakdown']['parts']}")
        print("           → 数値が None なら本文に数値が無い（語 n-gram 頼み）。"
              "頁が None なら本文と証拠のページが紐付いていない。")

    if show_all:
        for r in report["rejected"][:12]:
            print(f"  [不採用] {r['score']:.3f}  {r['why']}  ← {r['bullet']}")
    return report


def main() -> None:
    ap = argparse.ArgumentParser(description="図版差し込みの dry-run / チューニング")
    ap.add_argument("run_dirs", nargs="*",
                    help="run ディレクトリ、またはその親（省略時は out/runs を自動探索）")
    ap.add_argument("--min-score", type=float, default=DEFAULTS["min_score"])
    ap.add_argument("--min-margin", type=float, default=DEFAULTS["min_margin"])
    ap.add_argument("--max-figures", type=int, default=DEFAULTS["max_figures"])
    ap.add_argument("--all", action="store_true", help="不採用の理由も出す")
    ap.add_argument("--sweep", action="store_true", help="閾値を振って歩留まりだけ見る")
    ap.add_argument("--apply", action="store_true", help="実際に md を書き換える")
    args = ap.parse_args()

    runs = discover_runs(args.run_dirs)
    if not runs:
        looked = args.run_dirs or ["out/runs", "out"]
        print("run ディレクトリが見つかりませんでした。")
        print(f"  探した場所: {', '.join(str(x) for x in looked)}")
        print("  run は out/runs/<案件名>_<日時>/ に作られます。"
              "case_summary.md を含むディレクトリか、その親を渡してください。")
        print("  例: python -m tools.figure_dryrun out/runs")
        return
    print(f"run {len(runs)} 件を対象にします")

    cfg = dict(DEFAULTS)
    cfg.update({"min_score": args.min_score, "min_margin": args.min_margin,
                "max_figures": args.max_figures})

    if args.sweep:
        print("min_score  min_margin  採用枚数  （全 run 合計）")
        for s in (0.30, 0.36, 0.42, 0.48, 0.55):
            for m in (0.05, 0.10, 0.15):
                c = dict(cfg, min_score=s, min_margin=m)
                total = 0
                for rd in runs:
                    d = _load(rd)
                    if not d["md"]:
                        continue
                    picks, _ = select_figures(d["md"], d["visual"], d["text"],
                                              run_dir=rd, cfg=c)
                    total += len(picks)
                print(f"  {s:.2f}      {m:.2f}       {total}")
        return

    if args.apply:
        for rd in runs:
            res = attach_figures_to_run(rd, cfg=cfg, tier="internal")
            print(f"{rd.name}: {res.get('figures', 0)} 枚 "
                  f"{res.get('reason', '')}")
        return

    totals: List[int] = []
    for rd in runs:
        rep = _report_one(rd, cfg, args.all)
        if rep:
            totals.append(len(rep.get("picked", [])))
    if totals:
        print(f"\n合計 {sum(totals)} 枚 / {len(totals)} 件 "
              f"（平均 {sum(totals) / len(totals):.2f} 枚）")


if __name__ == "__main__":
    main()
