import json
import shutil
import subprocess
from pathlib import Path
from typing import Optional, Literal, Dict, Any


def _ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def _safe_suffix(path: Path, new_suffix: str) -> Path:
    return path.with_suffix(new_suffix)


def docling_convert(
    input_path: str,
    output_format: Literal["markdown", "json", "html", "text"] = "markdown",
    output_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """
    使用 Docling 把文档转成 markdown / json / html / text。
    Doclingを使用してドキュメントをmarkdown / json / html / textに変換します。

    支持输入通常包括： / サポートされている入力には通常以下が含まれます：
    PDF, DOCX, PPTX, XLSX, HTML, 图片等 / 画像など。
    """
    
    import logging
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


    from docling.document_converter import DocumentConverter

    src = Path(input_path).expanduser().resolve()

    if not src.exists():
        return {
            "ok": False,
            "error": f"input_path 不存在 / input_path が存在しません: {str(src)}",
        }

    out_dir = Path(output_dir).expanduser().resolve() if output_dir else Path.cwd() / "out"
    _ensure_dir(out_dir)

    converter = DocumentConverter()
    result = converter.convert(str(src))
    doc = result.document

    src_stem = src.stem

    if output_format == "markdown":
        out_path = out_dir / f"{src_stem}.md"
        text = doc.export_to_markdown()
        out_path.write_text(text, encoding="utf-8")
        return {
            "ok": True,
            "tool": "docling_convert",
            "input": str(src),
            "output_format": output_format,
            "output_path": str(out_path),
            "preview": text[:1000],
        }

    elif output_format == "json":
        out_path = out_dir / f"{src_stem}.docling.json"

        # DoclingDocument 通常支持 save_as_json / DoclingDocumentは通常save_as_jsonをサポートしています
        if hasattr(doc, "save_as_json"):
            doc.save_as_json(out_path)
        else:
            data = doc.export_to_dict()
            out_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

        return {
            "ok": True,
            "tool": "docling_convert",
            "input": str(src),
            "output_format": output_format,
            "output_path": str(out_path),
        }

    elif output_format == "html":
        out_path = out_dir / f"{src_stem}.html"

        if hasattr(doc, "export_to_html"):
            html = doc.export_to_html()
            out_path.write_text(html, encoding="utf-8")
            preview = html[:1000]
        elif hasattr(doc, "save_as_html"):
            doc.save_as_html(out_path)
            preview = out_path.read_text(encoding="utf-8", errors="ignore")[:1000]
        else:
            return {
                "ok": False,
                "error": "当前 DoclingDocument 没有 export_to_html/save_as_html 方法。 / 現在のDoclingDocumentにはexport_to_html/save_as_htmlメソッドがありません。",
            }

        return {
            "ok": True,
            "tool": "docling_convert",
            "input": str(src),
            "output_format": output_format,
            "output_path": str(out_path),
            "preview": preview,
        }

    elif output_format == "text":
        out_path = out_dir / f"{src_stem}.txt"

        if hasattr(doc, "export_to_text"):
            text = doc.export_to_text()
        else:
            text = doc.export_to_markdown()

        out_path.write_text(text, encoding="utf-8")

        return {
            "ok": True,
            "tool": "docling_convert",
            "input": str(src),
            "output_format": output_format,
            "output_path": str(out_path),
            "preview": text[:1000],
        }

    else:
        return {
            "ok": False,
            "error": f"不支持的 output_format / サポートされていない output_format: {output_format}",
        }


def xlsx_to_html(
    input_path: str,
    output_path: Optional[str] = None,
    engine: Literal["auto", "excel", "libreoffice"] = "auto",
) -> Dict[str, Any]:
    """
    把 Excel 转成 HTML。 / ExcelをHTMLに转换します。

    对于复杂 Excel： / 複雑なExcelの場合：
    - 如果 Windows 上安装了 Microsoft Excel，优先使用 Excel COM，保真度通常最高。
      WindowsにMicrosoft Excelがインストールされている場合は、Excel COMを優先して使用し、通常は再現性が最も高くなります。
    - 如果没有 Excel，则尝试 LibreOffice headless。
      Excelがない場合は、LibreOfficeのheadlessモードを試します。
    """
    src = Path(input_path).expanduser().resolve()
    if not src.exists():
        return {
            "ok": False,
            "error": f"input_path 不存在 / input_path が存在しません: {str(src)}",
        }

    if output_path:
        out_path = Path(output_path).expanduser().resolve()
    else:
        out_dir = Path.cwd() / "out"
        _ensure_dir(out_dir)
        out_path = out_dir / f"{src.stem}.html"

    _ensure_dir(out_path.parent)

    if engine in ["auto", "excel"]:
        excel_result = _xlsx_to_html_with_excel(src, out_path)
        if excel_result["ok"]:
            return excel_result

        if engine == "excel":
            return excel_result

    if engine in ["auto", "libreoffice"]:
        lo_result = _xlsx_to_html_with_libreoffice(src, out_path)
        return lo_result

    return {
        "ok": False,
        "error": f"未知 engine / 未知の engine: {engine}",
    }


def _xlsx_to_html_with_excel(src: Path, out_path: Path) -> Dict[str, Any]:
    """
    使用 Windows Excel COM 转 HTML。 / Windows Excel COMを使用してHTMLに変換します。
    需要本机安装 Microsoft Excel。 / ローカルにMicrosoft Excelがインストールされている必要があります。
    """
    try:
        import pythoncom
        import win32com.client
    except Exception as e:
        return {
            "ok": False,
            "engine": "excel",
            "error": f"无法导入 pywin32/win32com / pywin32/win32comをインポートできません: {repr(e)}",
        }

    excel = None
    wb = None

    try:
        pythoncom.CoInitialize()

        excel = win32com.client.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False

        wb = excel.Workbooks.Open(str(src), ReadOnly=True)

        # Excel FileFormat:
        # 44 = xlHtml
        wb.SaveAs(str(out_path), FileFormat=44)

        wb.Close(SaveChanges=False)
        excel.Quit()

        return {
            "ok": True,
            "tool": "xlsx_to_html",
            "engine": "excel",
            "input": str(src),
            "output_path": str(out_path),
            "note": (
                "使用 Microsoft Excel COM SaveAs HTML 完成。复杂图表/图片/格式通常比纯解析方式保真。\n"
                "Microsoft Excel COMのSaveAs HTMLを使用して完了しました。複雑なグラフ/画像/書式は、通常、純粋な解析方式よりも再現性が高くなります。"
            ),
        }

    except Exception as e:
        try:
            if wb is not None:
                wb.Close(SaveChanges=False)
        except Exception:
            pass

        try:
            if excel is not None:
                excel.Quit()
        except Exception:
            pass

        return {
            "ok": False,
            "engine": "excel",
            "error": repr(e),
        }

    finally:
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass


def _find_soffice() -> Optional[str]:
    candidates = [
        "soffice",
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    ]

    for c in candidates:
        found = shutil.which(c)
        if found:
            return found

        p = Path(c)
        if p.exists():
            return str(p)

    return None


def _xlsx_to_html_with_libreoffice(src: Path, out_path: Path) -> Dict[str, Any]:
    """
    使用 LibreOffice headless 转 HTML。 / LibreOffice headlessを使用してHTMLに変換します。
    需要安装 LibreOffice。 / LibreOfficeがインストールされている必要があります。
    """
    soffice = _find_soffice()
    if not soffice:
        return {
            "ok": False,
            "engine": "libreoffice",
            "error": (
                "未找到 LibreOffice soffice。请安装 LibreOffice，或使用 engine='excel'。\n"
                "LibreOffice sofficeが見つかりません。LibreOfficeをインストールするか、engine='excel'を使用してください。"
            ),
        }

    out_dir = out_path.parent
    _ensure_dir(out_dir)

    try:
        cmd = [
            soffice,
            "--headless",
            "--convert-to",
            "html",
            "--outdir",
            str(out_dir),
            str(src),
        ]

        completed = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=180,
        )

        if completed.returncode != 0:
            return {
                "ok": False,
                "engine": "libreoffice",
                "error": completed.stderr or completed.stdout,
            }

        # LibreOffice 默认输出名可能是 原文件名.html / LibreOfficeのデフォルト出力名は 元ファイル名.html の可能性があります
        produced = out_dir / f"{src.stem}.html"
        if produced.exists() and produced.resolve() != out_path.resolve():
            produced.replace(out_path)

        if not out_path.exists():
            return {
                "ok": False,
                "engine": "libreoffice",
                "error": (
                    "LibreOffice 执行完成，但未找到预期 HTML 输出文件。\n"
                    "LibreOfficeの実行は完了しましたが、期待されるHTML出力ファイルが見つかりません。"
                ),
                "stdout": completed.stdout,
                "stderr": completed.stderr,
            }

        return {
            "ok": True,
            "tool": "xlsx_to_html",
            "engine": "libreoffice",
            "input": str(src),
            "output_path": str(out_path),
            "stdout": completed.stdout,
        }

    except Exception as e:
        return {
            "ok": False,
            "engine": "libreoffice",
            "error": repr(e),
        }