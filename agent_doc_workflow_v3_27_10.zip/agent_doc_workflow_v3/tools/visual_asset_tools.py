import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Dict, Any, List, Optional
from urllib.parse import unquote

from bs4 import BeautifulSoup


SUPPORTED_IMAGE_SUFFIXES = {
    ".png",
    ".jpg",
    ".jpeg",
    ".webp",
    ".bmp",
    ".gif",
    ".tif",
    ".tiff",
    ".svg"
}


OFFICE_SUFFIXES = {
    ".doc",
    ".docx",
    ".ppt",
    ".pptx",
    ".xls",
    ".xlsx",
    ".xlsm",
}


def find_soffice() -> Optional[str]:
    candidates = [
        "soffice",
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    ]

    for c in candidates:
        found = shutil.which(c)
        if found:
            return found

        p = Path(c)
        if p.exists():
            return str(p)

    return None


def libreoffice_to_html(
    input_path: str,
    output_dir: str,
) -> Dict[str, Any]:
    """
    使用 LibreOffice headless 将 Office 文档转换为 HTML。

    主要用途：
    - DOCX/PPTX/XLSX 转 HTML
    - 从 HTML 及其资源目录中提取图片
    - 作为 Excel/PPT/Word 的补充视觉资产来源

    注意：
    - 对复杂 Excel，优先仍然建议使用 Excel COM SaveAs HTML。
    - LibreOffice 转换结果用于补充，不一定百分百还原。
    """
    src = Path(input_path).expanduser().resolve()
    out_dir = Path(output_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    if not src.exists():
        return {
            "ok": False,
            "error": f"文件不存在: {src}",
        }

    soffice = find_soffice()
    if not soffice:
        return {
            "ok": False,
            "error": "未找到 LibreOffice soffice。请确认 LibreOffice 已安装。",
        }

    cmd = [
        soffice,
        "--headless",
        "--convert-to",
        "html",
        "--outdir",
        str(out_dir),
        str(src),
    ]

    try:
        completed = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300,
        )

        if completed.returncode != 0:
            return {
                "ok": False,
                "error": completed.stderr or completed.stdout,
            }

        html_candidates = list(out_dir.glob(f"{src.stem}*.html")) + list(out_dir.glob(f"{src.stem}*.htm"))

        if not html_candidates:
            html_candidates = list(out_dir.glob("*.html")) + list(out_dir.glob("*.htm"))

        if not html_candidates:
            return {
                "ok": False,
                "error": "LibreOffice 执行完成，但没有找到 HTML 输出。",
                "stdout": completed.stdout,
                "stderr": completed.stderr,
            }

        html_path = html_candidates[0]

        return {
            "ok": True,
            "tool": "libreoffice_to_html",
            "input": str(src),
            "html_path": str(html_path),
            "output_dir": str(out_dir),
            "stdout": completed.stdout,
        }

    except Exception as e:
        return {
            "ok": False,
            "error": repr(e),
        }


def extract_text_from_html(
    html_path: str,
    max_chars: int = 200000,
) -> Dict[str, Any]:
    """
    从 HTML 中提取正文文本。
    用途：
    - 特别适合 Excel 转 HTML 后，把单元格文字、标题、图表附近文字交给 LLM。
    """
    p = Path(html_path).expanduser().resolve()

    if not p.exists():
        return {
            "ok": False,
            "error": f"HTML 文件不存在: {p}",
        }

    html = p.read_text(encoding="utf-8", errors="ignore")
    soup = BeautifulSoup(html, "lxml")

    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()

    text = soup.get_text("\n")
    lines = []

    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        lines.append(line)

    cleaned = "\n".join(lines)

    if len(cleaned) > max_chars:
        cleaned = cleaned[:max_chars]

    return {
        "ok": True,
        "html_path": str(p),
        "text": cleaned,
    }


def extract_images_from_html(
    html_path: str,
    output_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """
    从 HTML 文件及其邻近资源目录中提取图片路径。

    注意：
    - LibreOffice / Excel 导出的 HTML 通常会在旁边生成 xxx_files 目录。
    - HTML 里面也可能直接引用相对路径图片。
    """
    html = Path(html_path).expanduser().resolve()

    if not html.exists():
        return {
            "ok": False,
            "error": f"HTML 文件不存在: {html}",
        }

    base_dir = html.parent
    found = []

    html_text = html.read_text(encoding="utf-8", errors="ignore")
    soup = BeautifulSoup(html_text, "lxml")

    # 1. 从 <img src="..."> 里找
    for img in soup.find_all("img"):
        src = img.get("src")
        if not src:
            continue

        src = unquote(src)

        # v3.5 防崩补丁：新版 LibreOffice 会把图片内联为 data: URI，
        # 旧代码将其当文件路径检查 -> OSError(名字超长) -> 整个提取崩溃。
        # 位图型 data: URI 解码落盘，其余(VCLMTF 矢量等)跳过。
        if src.startswith("data:"):
            import base64 as _b64
            import re as _re
            m = _re.match(r"data:image/(png|jpeg|jpg|gif|webp);base64,(.+)", src, _re.S)
            if m:
                try:
                    ext = "jpg" if m.group(1) in ("jpeg", "jpg") else m.group(1)
                    dest = base_dir / f"inline_{len(found):03d}.{ext}"
                    dest.write_bytes(_b64.b64decode(m.group(2)))
                    found.append(dest.resolve())
                except Exception:
                    pass
            continue

        src = src.replace("file:///", "")
        src = src.replace("file://", "")

        candidate = Path(src)
        if not candidate.is_absolute():
            candidate = base_dir / candidate

        try:
            _exists = candidate.exists()
        except OSError:  # 超长伪路径残片
            continue
        if _exists and candidate.suffix.lower() in SUPPORTED_IMAGE_SUFFIXES:
            found.append(candidate.resolve())

    # 2. 从 HTML 周边资源目录里找
    possible_dirs = []

    for child in base_dir.iterdir():
        if child.is_dir():
            name_lower = child.name.lower()
            if (
                html.stem.lower() in name_lower
                or "files" in name_lower
                or "image" in name_lower
                or "img" in name_lower
            ):
                possible_dirs.append(child)

    for d in possible_dirs:
        for p in d.rglob("*"):
            if p.is_file() and p.suffix.lower() in SUPPORTED_IMAGE_SUFFIXES:
                found.append(p.resolve())

    # 3. 去重
    unique = []
    seen = set()

    for p in found:
        key = str(p).lower()
        if key not in seen:
            seen.add(key)
            unique.append(p)

    # 4. 如果指定 output_dir，则复制一份到统一 visual_assets 目录
    copied_paths = []

    if output_dir:
        out = Path(output_dir).expanduser().resolve()
        out.mkdir(parents=True, exist_ok=True)

        for idx, src in enumerate(unique):
            suffix = src.suffix.lower()
            dst = out / f"asset_{idx + 1:04d}{suffix}"

            try:
                shutil.copy2(src, dst)
                copied_paths.append(str(dst))
            except Exception:
                copied_paths.append(str(src))
    else:
        copied_paths = [str(p) for p in unique]

    return {
        "ok": True,
        "html_path": str(html),
        "image_count": len(copied_paths),
        "image_paths": copied_paths,
    }


def collect_visual_assets(
    input_path: str,
    run_dir: str,
    preferred_html_path: Optional[str] = None,
    max_assets: int = 30,
) -> Dict[str, Any]:
    """
    收集可给视觉模型分析的图片资源。

    优先级：
    1. 如果已有 preferred_html_path，比如 Excel COM 转出的 HTML，则从这个 HTML 提取图片。
    2. 如果没有 HTML，且输入是 Office 文件，则用 LibreOffice 转 HTML 后提取图片。
    3. 如果是 PDF，则优先从 Docling 导出的 HTML 中提取图片。
       如果没有，则返回空，不强制做 PDF 页面渲染。
    """
    src = Path(input_path).expanduser().resolve()
    run = Path(run_dir).expanduser().resolve()

    html_dir = run / "html_for_assets"
    asset_dir = run / "visual_assets"

    html_dir.mkdir(parents=True, exist_ok=True)
    asset_dir.mkdir(parents=True, exist_ok=True)

    collected_images = []
    html_sources = []

    # 1. 优先使用已有 HTML，例如 Excel COM SaveAs HTML
    if preferred_html_path:
        html_p = Path(preferred_html_path).expanduser().resolve()
        if html_p.exists():
            html_sources.append(str(html_p))

    # 2. 对 Office 文件，用 LibreOffice 额外转 HTML
    if src.suffix.lower() in OFFICE_SUFFIXES:
        lo_result = libreoffice_to_html(str(src), str(html_dir))
        if lo_result.get("ok"):
            html_sources.append(lo_result["html_path"])

    # 3. 从所有 HTML 源抽取图片
    for html_path in html_sources:
        result = extract_images_from_html(
            html_path=html_path,
            output_dir=str(asset_dir),
        )

        if result.get("ok"):
            collected_images.extend(result.get("image_paths", []))

    # 4. 去重
    unique = []
    seen = set()

    for p in collected_images:
        key = str(Path(p).resolve()).lower()
        if key not in seen:
            seen.add(key)
            unique.append(p)

    unique = unique[:max_assets]

    return {
        "ok": True,
        "input": str(src),
        "html_sources": html_sources,
        "visual_asset_count": len(unique),
        "visual_asset_paths": unique,
    }


def collect_html_text_sources(
    html_paths: List[str],
    max_chars_each: int = 100000,
) -> List[Dict[str, Any]]:
    """
    把多个 HTML 文件转成文本来源。
    用于 Excel HTML / LibreOffice HTML 的正文证据抽取。
    """
    results = []

    for html_path in html_paths:
        if not html_path:
            continue

        p = Path(html_path)
        if not p.exists():
            continue

        result = extract_text_from_html(
            html_path=str(p),
            max_chars=max_chars_each,
        )

        if result.get("ok") and result.get("text"):
            results.append(
                {
                    "source_type": "html_text",
                    "source": str(p.resolve()),
                    "text": result["text"],
                }
            )

    return results
