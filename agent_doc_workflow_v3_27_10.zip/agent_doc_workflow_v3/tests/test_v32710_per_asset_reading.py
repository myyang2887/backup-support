"""v3.27.10：読ませ方は「ルート」ではなく「資産の種別」で決まる。

## 何が起きていたか

要件はもともと二本立てだった：

  頁の全面レンダリング → VLM に読ませて**要約本文**を作る
  埋込画像の抽出       → **図版として要約に差し込む**

v3.27.3 で後者の収集を足したが、下流はどこも
`page_mode = (route == "vision")` という**実行単位**のフラグで動いていた。
視覚ルートの資産が頁画像しか無かった頃の前提がそのまま残っていた結果：

  - 埋込図まで PAGE_SYSTEM（頁の書き起こし）で読まれ、
    figure_caption / figure_worthiness が付かない
  - _asset_provenance が埋込図を page_render と判定し、
    allow_page_render=false で候補から落ちる

「収集は直したが、読ませ方と種別判定は直していなかった」という形。
同じ前提が複数の層に散っていたので、一層だけ直しても症状が残った。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.nodes import _asset_provenance  # noqa: E402

_PAGE = ("page_render", "sheet_render")


def _kind(path: str, route_vision: bool) -> str:
    return _asset_provenance(path, 0, route_vision)["asset_kind"]


# ---- ルート × 形式の総当たり ----

#: 各経路が実際に吐くファイル名（app/nodes.py の out_dir と
#: app/parsing.py・tools/excel_com.py の命名規則より）
ROUTE_MATRIX = [
    ("vision", ".pdf",       "visual_pages/page_003.png",           "visual_pdf/pdf_p003_img01.png"),
    ("vision", ".pptx",      "visual_pages/page_006.png",           "visual_office/office_p006_image11.png"),
    ("vision", ".docx",      "visual_pages/page_002.png",           "visual_office/office_p002_image3.png"),
    ("vision", ".xlsx-com",  "visual_excel_sheets/sheet_02_売上.png", "visual_office/office_image1.png"),
    ("vision", ".xlsx-lo",   "visual_pages/page_001.png",           "visual_office/office_image1.png"),
    ("text",   ".pdf",       "visual_pdf/pdf_p005_page.png",        "visual_pdf/pdf_p003_img01.png"),
    ("text",   ".xlsx",      "visual_excel_sheets/sheet_02_売上.png", "visual_office/office_image1.png"),
]


@pytest.mark.parametrize("route,fmt,page_asset,figure_asset", ROUTE_MATRIX)
def test_page_and_figure_assets_stay_distinct(route, fmt, page_asset, figure_asset):
    """どのルート・形式でも、頁資産と図版資産が入れ替わらないこと。"""
    rv = route == "vision"
    assert _kind(page_asset, rv) in _PAGE, f"{fmt}: 頁資産が図扱い"
    assert _kind(figure_asset, rv) not in _PAGE, f"{fmt}: 図版資産が頁扱い"


@pytest.mark.parametrize("route,fmt,page_asset,figure_asset", ROUTE_MATRIX)
def test_kind_does_not_depend_on_route(route, fmt, page_asset, figure_asset):
    """種別がルートで変わると、同じ資料でも経路次第で図が出なくなる。"""
    for p in (page_asset, figure_asset):
        assert _kind(p, True) == _kind(p, False), p


def test_excel_is_the_case_that_regressed():
    """Excel の埋込は頁番号が付かず、以前は最終段で page_render にされていた。"""
    assert _kind("visual_office/office_image1.png", True) == "embedded"


# ---- 読ませ方（プロンプト選択）が資産ごとであること ----

class _SpyVision:
    """どの system プロンプトで呼ばれたかを記録する桩。"""

    def __init__(self):
        self.calls = []

    def chat_vision_json(self, image_path, system, user_text, **kw):
        self.calls.append({"image": Path(image_path).name, "system": system,
                           "max_tokens": kw.get("max_tokens")})
        return {"has_useful_visual_info": True, "visual_type": "chart",
                "readable_text": ["12.5 kPa"], "visual_summary": "圧力損失グラフ",
                "key_facts": ["12.5 kPa"], "possible_relevance": [],
                "figure_caption": "圧力損失の比較", "figure_worthiness": "core",
                "confidence": 0.8}


def _png(p: Path, size=(800, 600)):
    from PIL import Image
    p.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", size, "white").save(p)
    return str(p)


def test_vision_route_reads_embedded_as_figure_not_page(tmp_path):
    """視覚ルートでも、埋込図には VISION_SYSTEM（挿絵の分析）を使うこと。

    ここが PAGE_SYSTEM のままだと figure_caption / figure_worthiness が
    返らず、図版差し込みが成立しない。
    """
    from app.config import AppConfig
    from app.nodes import make_nodes

    run = tmp_path / "run"
    page = _png(run / "visual_pages" / "page_001.png")
    fig = _png(run / "visual_office" / "office_image1.png")

    spy = _SpyVision()
    nodes = make_nodes(AppConfig(), llm=None, vision_llm=spy)
    state = {"run_dir": str(run), "route": "vision",
             "visual_asset_paths": [page, fig], "errors": [], "errors_visual": []}
    nodes["analyze_visual"](state)

    by_img = {c["image"]: c for c in spy.calls}
    assert "ページ全体の読み取り" in by_img["page_001.png"]["system"]
    assert "ページ全体の読み取り" not in by_img["office_image1.png"]["system"]
    assert "figure_worthiness" in by_img["office_image1.png"]["system"]


def test_embedded_keeps_figure_fields_in_vision_route(tmp_path):
    from app.config import AppConfig
    from app.nodes import make_nodes

    run = tmp_path / "run"
    fig = _png(run / "visual_office" / "office_image1.png")
    nodes = make_nodes(AppConfig(), llm=None, vision_llm=_SpyVision())
    state = {"run_dir": str(run), "route": "vision",
             "visual_asset_paths": [fig], "errors": [], "errors_visual": []}
    out = nodes["analyze_visual"](state)
    ve = (out.get("visual_evidence") or state.get("visual_evidence"))[0]
    assert ve["asset_kind"] == "embedded"
    assert ve["figure_worthiness"] == "core"
    assert ve["figure_caption"]


def test_page_asset_gets_the_larger_token_budget(tmp_path):
    """頁の全文書き起こしは長い。埋込図と同じ枠だと途中で切れて頁ごと落ちる
    （v3.8 で踏んだ事故）。資産ごとに枠が変わること。"""
    from app.config import AppConfig
    from app.nodes import make_nodes

    run = tmp_path / "run"
    page = _png(run / "visual_pages" / "page_001.png")
    fig = _png(run / "visual_office" / "office_image1.png")
    spy = _SpyVision()
    nodes = make_nodes(AppConfig(), llm=None, vision_llm=spy)
    state = {"run_dir": str(run), "route": "vision",
             "visual_asset_paths": [page, fig], "errors": [], "errors_visual": []}
    nodes["analyze_visual"](state)
    by_img = {c["image"]: c for c in spy.calls}
    assert by_img["page_001.png"]["max_tokens"] > by_img["office_image1.png"]["max_tokens"]
