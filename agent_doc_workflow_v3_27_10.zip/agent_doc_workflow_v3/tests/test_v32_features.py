"""v3.2 新特性测试：PDF 视觉提取 / peek 事件 / VLM 探针 / UI 配置。"""
import json
import sys
import time
from pathlib import Path

import pytest
from PIL import Image, ImageDraw

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.parsing import extract_pdf_visuals


def _make_image_pdf(path: Path, pages: int = 2) -> None:
    """PIL 生成含内嵌图片对象、零文本层的 PDF（模拟仿真报告里的贴图页/扫描页）。"""
    imgs = []
    for i in range(pages):
        img = Image.new("RGB", (800, 500), (245, 245, 250))
        d = ImageDraw.Draw(img)
        d.rectangle([40, 40, 760, 460], outline=(200, 40, 40), width=6)
        d.ellipse([300 + i * 20, 150, 500 + i * 20, 350], fill=(40, 120, 200))
        imgs.append(img)
    imgs[0].save(path, "PDF", save_all=True, append_images=imgs[1:])


# ----------------------------------------------------------------------
# 1. PDF 视觉提取（修复"图像资产为 0"）
# ----------------------------------------------------------------------

def test_pdf_embedded_image_extraction(tmp_path):
    pdf = tmp_path / "report.pdf"
    _make_image_pdf(pdf, pages=2)
    result = extract_pdf_visuals(str(pdf), str(tmp_path / "vis"))
    assert result["ok"]
    assert result["embedded"] >= 2, "每页的内嵌图片对象都应被提取"
    assert all(Path(p).exists() for p in result["visual_asset_paths"])
    # 文件名携带页码（页级溯源）
    assert any("p001" in p for p in result["visual_asset_paths"])
    assert any("p002" in p for p in result["visual_asset_paths"])


def test_pdf_render_fallback_for_imageonly_pages(tmp_path):
    pdf = tmp_path / "scan.pdf"
    _make_image_pdf(pdf, pages=2)
    # 关掉内嵌提取，验证兜底路径：零文本页应被整页渲染
    result = extract_pdf_visuals(str(pdf), str(tmp_path / "vis"),
                                 extract_embedded=False, render_fallback=True,
                                 render_min_text_chars=120)
    assert result["ok"]
    assert result["pages_rendered"] == 2
    assert all(p.endswith("_page.png") for p in result["visual_asset_paths"])


def test_pdf_visuals_respect_max_assets(tmp_path):
    pdf = tmp_path / "many.pdf"
    _make_image_pdf(pdf, pages=5)
    result = extract_pdf_visuals(str(pdf), str(tmp_path / "vis"), max_assets=3)
    assert len(result["visual_asset_paths"]) == 3


def test_pdf_visuals_broken_file(tmp_path):
    bad = tmp_path / "broken.pdf"
    bad.write_bytes(b"not a pdf at all")
    result = extract_pdf_visuals(str(bad), str(tmp_path / "vis"))
    assert result["ok"] is False and result["visual_asset_paths"] == []


# ----------------------------------------------------------------------
# 2. E2E：PDF 输入走 pypdfium2 通道，视觉资产不再为 0，Agent 2 开工
# ----------------------------------------------------------------------

def test_e2e_pdf_input_visuals_reach_agent2(tmp_path):
    from app.config import AppConfig
    from app.graph import run_workflow
    from app.llm_client import LocalLLMClient

    vision_calls = {"n": 0}

    def mock(system: str, user: str):
        if "視覚" in system:
            vision_calls["n"] += 1
            return {"has_useful_visual_info": True, "visual_type": "simulation_result",
                    "readable_text": [], "visual_summary": "解析結果の図（モック）",
                    "key_facts": ["圧力分布に偏り"], "possible_relevance": ["finding"],
                    "confidence": 0.8}
        if "文書整理エージェント" in system:
            return {"evidence": [
                {"category": "requester", "content": "設計部", "confidence": 0.9},
                {"category": "target", "content": "装置A", "confidence": 0.9},
                {"category": "issue", "content": "課題X", "confidence": 0.9},
                {"category": "request_scope", "content": "解析代行", "confidence": 0.9},
                {"category": "tool", "content": "FloEFD", "confidence": 0.9},
                {"category": "period", "content": "2026年", "confidence": 0.9},
                {"category": "finding", "content": "事実Y", "confidence": 0.9},
                {"category": "effect", "content": "効果Z", "confidence": 0.9},
            ]}
        return {"case_name": "PDF案件",
                "request_details": {"requester": "設計部", "target_product_or_system": "装置A",
                                    "background": ["b"], "client_issues": ["課題X"],
                                    "scope_of_request": ["解析代行"]},
                "action_results": {"support_type": "解析代行", "tools_environment": ["FloEFD"],
                                   "period": "2026年", "findings": ["事実Y"], "effects": ["効果Z"]},
                "evidence": ["visual_asset_0001"]}

    pdf = tmp_path / "sim_report.pdf"
    _make_image_pdf(pdf, pages=2)

    config = AppConfig()
    config.paths.out_dir = str(tmp_path / "out")
    config.llm.mock = True
    llm = LocalLLMClient(base_url="", api_key="", mock=True, mock_handler=mock)
    final = run_workflow(str(pdf), config, llm)

    assert len(final["visual_asset_paths"]) >= 1, "PDF 视觉资产不应再为 0"
    assert vision_calls["n"] >= 1, "Agent 2 应被调用"
    assert any(v["has_useful_visual_info"] for v in final["visual_evidence"])


# ----------------------------------------------------------------------
# 3. peek 事件（机器人气泡数据源）
# ----------------------------------------------------------------------

def test_peek_events_emitted(tmp_path):
    from app.config import AppConfig
    from app.graph import run_workflow
    from app.llm_client import LocalLLMClient
    from app.observability import RunStore

    doc = tmp_path / "case.md"
    doc.write_text("# 光学解析支援\n光学設計部より、レンズユニットの流体解析代行の依頼を受けた。"
                   "背景として試作段階での歩留まり低下があり、原因が特定できていなかった。"
                   "使用ツールは FloEFD 2024。対応期間は2026年1月。効果は工数30%削減。",
                   encoding="utf-8")
    config = AppConfig()
    config.paths.out_dir = str(tmp_path / "out")
    config.llm.mock = True
    llm = LocalLLMClient(base_url="", api_key="", mock=True)
    final = run_workflow(str(doc), config, llm)

    events = [json.loads(l) for l in
              (Path(final["run_dir"]) / RunStore.EVENTS).read_text(encoding="utf-8").strip().split("\n")]
    peeks = [e["peek"] for e in events if e.get("peek")]
    assert peeks, "应有 peek 事件供气泡显示"
    assert any("読み" in p or "読んで" in p for p in peeks), "提取阶段应冒出'读到了…'气泡"
    assert any("完成" in p for p in peeks)
    # peek 有长度上限（隐私与 UI 双重考虑）
    assert all(len(p) <= 120 for p in peeks)


# ----------------------------------------------------------------------
# 4. Web：UI 配置 / VLM 探针（mock）
# ----------------------------------------------------------------------

@pytest.fixture()
def web_client(tmp_path, monkeypatch):
    import app.webapp as W
    from fastapi.testclient import TestClient
    monkeypatch.setattr(W.config.llm, "mock", True)
    monkeypatch.setattr(W.config.paths, "out_dir", str(tmp_path / "out"))
    monkeypatch.setattr(W.config.paths, "inbox_dir", str(tmp_path / "inbox"))
    W._runs.clear()
    return TestClient(W.app)


def test_ui_endpoint(web_client):
    r = web_client.get("/api/ui").json()
    assert "robot_animation" in r


def test_vision_probe_mock(web_client):
    assert web_client.get("/api/health/vision").json()["vision"] == "mock"


def test_health_includes_docling_state(web_client):
    r = web_client.get("/api/health").json()
    assert r["llm"] == "mock"  # mock 模式下不含 docling 字段也合法，仅验证不报错


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))


# ----------------------------------------------------------------------
# v3.5 追加：Office ZIP 直取图片 + 旧链路防崩
# ----------------------------------------------------------------------

def test_office_zip_visual_extraction(tmp_path):
    from PIL import Image, ImageDraw
    from pptx import Presentation
    from pptx.util import Inches
    from app.parsing import extract_office_visuals

    img = Image.new("RGB", (640, 400), (250, 245, 235))
    ImageDraw.Draw(img).ellipse([100, 50, 540, 350], fill=(30, 110, 190))
    ip = tmp_path / "c.png"
    img.save(ip)
    prs = Presentation()
    s1 = prs.slides.add_slide(prs.slide_layouts[5])
    s1.shapes.title.text = "結果"
    s1.shapes.add_picture(str(ip), Inches(1), Inches(2), Inches(5))
    pp = tmp_path / "deck.pptx"
    prs.save(pp)

    r = extract_office_visuals(str(pp), str(tmp_path / "out"))
    assert r["ok"] and len(r["visual_asset_paths"]) == 1
    assert Path(r["visual_asset_paths"][0]).name.startswith("office_")

    # 旧二进制格式 -> ok=False（调用方回落 LibreOffice）
    old = tmp_path / "old.ppt"
    old.write_bytes(b"\xd0\xcf\x11\xe0 not a zip")
    assert extract_office_visuals(str(old), str(tmp_path / "o2"))["ok"] is False


def test_legacy_html_path_survives_data_uris(tmp_path):
    """新版 LibreOffice 的 data: 内联不再让旧链路崩溃；位图可解码。"""
    import base64, io
    from PIL import Image
    from tools.visual_asset_tools import extract_images_from_html

    buf = io.BytesIO()
    Image.new("RGB", (200, 120), (200, 40, 40)).save(buf, "PNG")
    b64 = base64.b64encode(buf.getvalue()).decode()
    html = tmp_path / "page.html"
    html.write_text(
        f'<html><body>'
        f'<img src="data:image/png;base64,{b64}">'          # 可解码位图
        f'<img src="data:;base64,VkNMTVRG{"A" * 3000}">'    # 超长矢量残片（曾致 OSError）
        f'</body></html>', encoding="utf-8")
    r = extract_images_from_html(html_path=str(html), output_dir=str(tmp_path / "imgs"))
    assert r.get("ok")
    imgs = r.get("image_paths", [])
    assert len(imgs) == 1  # 位图收下，矢量残片安全跳过
