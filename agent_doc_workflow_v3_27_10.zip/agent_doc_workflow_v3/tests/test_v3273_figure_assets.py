"""v3.27.3：図版用資産の収集と枠取り。

守りたいこと：
- 実際の evidence_id 形式（visual_asset_0011）で名指しが効くこと
- 並び順の先着で埋込画像が枯れないこと
- 密集頁で「頁画像があるから埋込は全部捨てる」をしないこと
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.figure_select import _CITE_RE, strip_citations  # noqa: E402


# ---- 名指しの正則（v3.27.2 のバグ）----

def test_real_evidence_id_is_matched():
    """nodes.py は f"visual_asset_{idx+1:04d}" を発行する。
    プロンプトの例 "V3" に合わせた正則では一度も一致しなかった。"""
    s = "約0.7 GPa付近にピークを持つ結果が得られた [[visual_asset_0011]]"
    assert _CITE_RE.findall(s) == ["visual_asset_0011"]
    assert strip_citations(s) == "約0.7 GPa付近にピークを持つ結果が得られた"


def test_fullwidth_and_spaced_forms():
    assert _CITE_RE.findall("低下した ［［visual_asset_0007］］") == ["visual_asset_0007"]
    assert _CITE_RE.findall("削減 [[ visual_asset_0002 ]]") == ["visual_asset_0002"]


def test_short_legacy_form_still_matched():
    assert _CITE_RE.findall("旧形式 [[V3]]") == ["V3"]


def test_japanese_double_brackets_are_not_citations():
    """[[日本語]] を ID と誤認して本文を削らないこと。"""
    s = "資料[[参考]]には記載がある"
    assert _CITE_RE.findall(s) == []
    assert strip_citations(s) == s


# ---- 枠取り（Excel の埋込が枯れる問題）----

def _quota(paths, reserve):
    from app.nodes import _allocate_visual_quota
    return _allocate_visual_quota(paths, reserve)


def test_embedded_survives_sheet_render_flood():
    """_excel_visuals は グラフ→シート画像→埋込 の順に積む。
    先着順で 30 枚に切ると埋込が 1 枚も残らなかった。"""
    paths = ([f"visual_excel_sheets/sheet_{i:02d}_売上.png" for i in range(40)]
             + [f"visual_office/office_image{i}.png" for i in range(5)])
    out = _quota(paths, reserve=12)
    top30 = out[:30]
    embedded = [p for p in top30 if "office_image" in p]
    assert len(embedded) == 5              # 5 枚とも枠内に入る
    assert out[:5] == paths[-5:]           # 図版候補が先頭に確保される
    assert len(out) == len(paths)          # 切り捨てはしない（上限は後段）


def test_quota_preserves_everything_when_one_kind_only():
    pages = [f"visual_pages/page_{i:03d}.png" for i in range(10)]
    assert _quota(pages, reserve=12) == pages
    figs = [f"visual_office/office_image{i}.png" for i in range(4)]
    assert _quota(figs, reserve=12) == figs


def test_quota_reserve_is_bounded():
    """reserve より多い図版候補があっても、残りは元の順で後ろに付く。"""
    figs = [f"visual_office/office_image{i}.png" for i in range(10)]
    pages = [f"visual_pages/page_{i:03d}.png" for i in range(10)]
    out = _quota(figs + pages, reserve=3)
    assert out[:3] == figs[:3]
    assert set(out) == set(figs + pages) and len(out) == 20


def test_charts_count_as_figure_grade():
    paths = ["visual_pages/page_001.png", "visual_excel/chart_1.png"]
    assert _quota(paths, reserve=5)[0] == "visual_excel/chart_1.png"


# ---- 密集頁で図版候補を全滅させない ----

def _png(path: Path, size):
    from PIL import Image
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", size, "white").save(path)
    return str(path)


def test_dense_page_keeps_largest_embedded_for_figures(tmp_path):
    """頁画像がある密集頁でも、面積の大きい埋込は図版用に残す。

    v3.27.2 まではこの条件で埋込を全部捨てていたので、視覚ルートで
    埋込を集めるようにしても、この関数が直後に消してしまっていた。
    """
    from types import SimpleNamespace

    from app.nodes import _compress_dense_pages

    rd = tmp_path / "run"
    paths = [_png(rd / "visual_pages" / "page_003.png", (1600, 1200))]
    # 同じ頁に 8 枚（dense_page_threshold=6 を超える）。大小を混ぜる
    for i in range(8):
        sz = (1000, 800) if i < 2 else (120, 90)
        paths.append(_png(rd / "visual_office" / f"office_p003_image{i}.png", sz))

    wf = SimpleNamespace(dense_page_threshold=6, contact_sheet_enabled=True,
                         dense_page_keep_for_figures=2, contact_sheet_cols=3,
                         contact_sheet_max_edge_px=1400, contact_sheet_max_cells=9)
    kept, report = _compress_dense_pages(paths, str(rd), wf)

    survivors = [p for p in kept if "office_p003" in p]
    assert len(survivors) == 2                     # 大きい 2 枚だけ残る
    assert all("image0" in p or "image1" in p for p in survivors)
    assert any(r.get("kept_for_figures") == 2 for r in report.get("pages", []))


def test_dense_page_keep_zero_restores_old_behaviour(tmp_path):
    from types import SimpleNamespace

    from app.nodes import _compress_dense_pages

    rd = tmp_path / "run2"
    paths = [_png(rd / "visual_pages" / "page_003.png", (1600, 1200))]
    for i in range(8):
        paths.append(_png(rd / "visual_office" / f"office_p003_image{i}.png", (400, 300)))
    wf = SimpleNamespace(dense_page_threshold=6, contact_sheet_enabled=True,
                         dense_page_keep_for_figures=0, contact_sheet_cols=3,
                         contact_sheet_max_edge_px=1400, contact_sheet_max_cells=9)
    kept, _ = _compress_dense_pages(paths, str(rd), wf)
    assert not [p for p in kept if "office_p003" in p]


# ---- config.yaml の健全性（v3.27 で重複キーを作り込んだ）----

def test_config_yaml_has_no_duplicate_top_level_keys():
    """YAML の重複キーは後勝ちで静かに前を捨てる。

    v3.27 で ui: を追記した際、既存の ui: ブロック（v3.26 から在った）を
    見落として 2 つになっていた。パースは通るので気付けない類のバグ。
    """
    import yaml
    src = (Path(__file__).resolve().parents[1] / "config.yaml").read_text(encoding="utf-8")
    tops = [ln.split(":")[0] for ln in src.split("\n")
            if ln and not ln.startswith((" ", "#", "-")) and ":" in ln]
    dup = {k for k in tops if tops.count(k) > 1}
    assert not dup, f"config.yaml に重複した最上位キー: {dup}"
    yaml.safe_load(src)


def test_config_features_cover_the_default_table():
    """config.yaml の ui.features が DEFAULT_UI_FEATURES を網羅していること。

    webapp は存在しないキーを黙って無視するので、綴り間違いや
    書き漏らしはトグルが効かない形で現れる。
    """
    import yaml

    from app.config import DEFAULT_UI_FEATURES
    src = (Path(__file__).resolve().parents[1] / "config.yaml").read_text(encoding="utf-8")
    cfg = yaml.safe_load(src)["ui"]["features"]
    missing = set(DEFAULT_UI_FEATURES) - set(cfg)
    unknown = set(cfg) - set(DEFAULT_UI_FEATURES)
    assert not missing, f"config.yaml に書かれていないトグル: {missing}"
    assert not unknown, f"DEFAULT_UI_FEATURES に無いキー（無視される）: {unknown}"
