"""テスト共通の下ごしらえ。

## なぜこれが要るのか（v3.27.6）

テスト群は `.md` を**汎用の書類ひな形**として使っている。中身を書くのが
一番安く、管線の挙動を見るのに十分だったから。

そこへ運用上の判断として `.md` / `.txt` の受付を一時停止したところ、
形式方針とは無関係な 14 本のテストが一斉に赤くなった。これは
`ALLOWED_SUFFIXES` が 2 つの別々の意味を兼ねていたせい：

  1. **このコードが読める形式**（＝管線の能力）
  2. **この運用が受け付ける形式**（＝方針）

テストが見たいのはほとんど 1 で、止めたのは 2。両者が同じ定数だったので、
方針を変えるたびに能力のテストが落ちる、という誤った結合になっていた。

ここでは各テストの実行中だけ、停止中の拡張子を受付集合へ戻す。
**方針そのものを試すテストは、この集合ではなく `SUSPENDED_SUFFIXES` を
見ること**（そちらは触らない）。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


@pytest.fixture(autouse=True)
def allow_suspended_suffixes_in_tests():
    """一時停止中の拡張子を、テスト実行中だけ受付集合に戻す。

    webapp 側の各エンドポイントは呼び出し時にモジュール変数を参照するので、
    差し替えるだけで単発アップロード・一括・監視フォルダの全経路に効く。
    """
    try:
        from app import webapp as W
    except Exception:  # noqa: BLE001 web 依存が無い環境ではそのまま流す
        yield
        return

    original = W.ALLOWED_SUFFIXES
    suspended = getattr(W, "SUSPENDED_SUFFIXES", set())
    W.ALLOWED_SUFFIXES = original | suspended
    try:
        yield
    finally:
        W.ALLOWED_SUFFIXES = original
