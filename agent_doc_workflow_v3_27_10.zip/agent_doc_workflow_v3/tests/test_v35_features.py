"""v3.5 测试：分支并行拓扑 / run 删除 / 履歴开关。"""
import json
import sys
import time
from pathlib import Path

import pytest
from PIL import Image, ImageDraw

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.config import AppConfig
from app.graph import run_workflow
from app.llm_client import LocalLLMClient
from app import nodes as N
from tests.test_v34_features import _mock_for

LONG_DOC = "\n\n".join(
    f"## 章 {i}\n解析対象は装置{i}。目的は冷却効率の改善であり、FloEFD を用いて熱流体解析を実施した。"
    f"条件は流量 {i}L/min、外気温 25℃。結果として圧力損失が {i * 3}% 低減した。"
    for i in range(1, 5))


def _make_images(d: Path, n: int = 3):
    d.mkdir(parents=True, exist_ok=True)
    out = []
    for i, c in enumerate([(200, 40, 40), (40, 160, 80), (60, 80, 200)][:n]):
        im = Image.new("RGB", (600, 400), (245, 245, 250))
        ImageDraw.Draw(im).ellipse([80 + i * 10, 60, 480 + i * 10, 330], fill=c)
        p = d / f"img{i}.png"
        im.save(p)
        out.append(str(p))
    return out


def _timed_mock(text_delay=0.25, vision_delay=0.4):
    base = _mock_for("case")

    def handler(system, user):
        time.sleep(vision_delay if "視覚" in system else text_delay)
        if "視覚" in system:
            return {"has_useful_visual_info": True, "visual_type": "chart",
                    "readable_text": [], "visual_summary": "図", "key_facts": ["f"],
                    "possible_relevance": [], "confidence": 0.8}
        return base(system, user)
    return handler


def _run_with_timeline(tmp_path: Path, parallel: bool):
    """跑一次流水线，记录每个节点的 [start, end] 区间。"""
    imgs = _make_images(tmp_path)
    timeline = {}
    orig_collect = N.collect_visual_assets
    orig_make = N.make_nodes

    N.collect_visual_assets = lambda **kw: {"ok": True, "visual_asset_paths": imgs}

    def traced_make(config, llm=None, vision_llm=None, template_id="case"):
        d = orig_make(config, llm, vision_llm, template_id)

        def wrap(name, fn):
            def inner(state):
                t0 = time.time()
                try:
                    return fn(state)
                finally:
                    timeline[name] = (t0, time.time())
            return inner
        return {k: wrap(k, v) for k, v in d.items()}

    import app.graph as G
    orig_g_make = G.make_nodes
    G.make_nodes = traced_make
    try:
        doc = tmp_path / "case.md"
        doc.write_text(LONG_DOC, encoding="utf-8")
        cfg = AppConfig()
        cfg.paths.out_dir = str(tmp_path / f"out_{parallel}")
        cfg.llm.mock = True
        cfg.workflow.parallel_branches = parallel
        cfg.workflow.vision_workers = 1
        cfg.workflow.extract_workers = 1
        cfg.workflow.chunk_chars = 200
        cfg.workflow.image_min_bytes = 100
        llm = LocalLLMClient(base_url="", api_key="", mock=True, mock_handler=_timed_mock())
        t0 = time.time()
        final = run_workflow(str(doc), cfg, llm)
        return final, timeline, time.time() - t0
    finally:
        N.collect_visual_assets = orig_collect
        G.make_nodes = orig_g_make


def _overlaps(a, b) -> bool:
    return a[0] < b[1] and b[0] < a[1]


# ----------------------------------------------------------------------
# 1. 分支并行拓扑
# ----------------------------------------------------------------------

def test_parallel_branches_actually_overlap(tmp_path):
    final, tl, _ = _run_with_timeline(tmp_path, parallel=True)
    assert _overlaps(tl["collect_visual_assets"], tl["extract_text_evidence"]) \
        or _overlaps(tl["analyze_visual"], tl["extract_text_evidence"]), \
        "并行模式下视觉分支应与文本分支时间重叠"
    # 汇合正确性：write_summary 必须在两分支之后
    assert tl["write_summary"][0] >= tl["gap_fill"][1] - 0.01
    assert tl["write_summary"][0] >= tl["analyze_visual"][1] - 0.01
    assert len(final["visual_evidence"]) == 3 and len(final["chunks"]) >= 2


def test_sequential_mode_has_no_overlap(tmp_path):
    _, tl, _ = _run_with_timeline(tmp_path, parallel=False)
    assert not _overlaps(tl["collect_visual_assets"], tl["extract_text_evidence"])
    assert tl["collect_visual_assets"][0] >= tl["gap_fill"][1] - 0.01


def test_both_modes_produce_identical_output(tmp_path):
    """并行不能改变结果——只改变时间。"""
    f_par, _, t_par = _run_with_timeline(tmp_path / "p", parallel=True)
    f_seq, _, t_seq = _run_with_timeline(tmp_path / "s", parallel=False)
    assert f_par["summary"] == f_seq["summary"]
    assert len(f_par["visual_evidence"]) == len(f_seq["visual_evidence"])
    assert len(f_par["aggregated_evidence"]) == len(f_seq["aggregated_evidence"])
    assert t_par < t_seq, "两分支都有负载时并行应更快"


def test_visual_errors_merged_at_join(tmp_path):
    """视觉分支的错误写在独立 key，汇合后必须合并回 errors 供 UI 显示。"""
    imgs = _make_images(tmp_path)
    orig = N.collect_visual_assets
    N.collect_visual_assets = lambda **kw: {"ok": True, "visual_asset_paths": imgs}

    def failing(system, user):
        if "視覚" in system:
            raise RuntimeError("VLM ダウン（テスト）")
        return _mock_for("case")(system, user)
    try:
        doc = tmp_path / "d.md"
        doc.write_text(LONG_DOC, encoding="utf-8")
        cfg = AppConfig()
        cfg.paths.out_dir = str(tmp_path / "out")
        cfg.llm.mock = True
        cfg.workflow.image_min_bytes = 100
        llm = LocalLLMClient(base_url="", api_key="", mock=True, mock_handler=failing)
        final = run_workflow(str(doc), cfg, llm)
    finally:
        N.collect_visual_assets = orig
    assert not final.get("errors_visual"), "汇合后视觉错误应已并入 errors"
    assert any(e["node"] == "analyze_visual" for e in final["errors"])
    assert Path(final["output_markdown"]).exists()   # 视觉失败不影响出稿


# ----------------------------------------------------------------------
# 2. run 删除 / 履歴开关
# ----------------------------------------------------------------------

@pytest.fixture()
def web_client(tmp_path, monkeypatch):
    import app.webapp as W
    from app.ledger import Ledger
    from fastapi.testclient import TestClient
    monkeypatch.setattr(W.config.llm, "mock", True)
    monkeypatch.setattr(W.config.paths, "out_dir", str(tmp_path / "out"))
    monkeypatch.setattr(W.config.paths, "inbox_dir", str(tmp_path / "inbox"))
    monkeypatch.setattr(W.config.ledger, "db_path", str(tmp_path / "ledger.sqlite3"))
    monkeypatch.setattr(W, "_ledger", Ledger(tmp_path / "ledger.sqlite3"))
    W._runs.clear()
    return TestClient(W.app)


DOC = ("# 光学解析支援\n光学設計部より、レンズユニットの流体解析代行の依頼を受けた。"
       "使用ツールは FloEFD 2024。対応期間は2026年1月。効果は工数30%削減。")


def _wait(client, rid):
    for _ in range(80):
        st = client.get(f"/api/runs/{rid}").json()["state"]
        if st in ("done", "failed"):
            return st
        time.sleep(0.25)
    return "timeout"


def test_delete_run_removes_everything(web_client, tmp_path):
    import app.webapp as W
    r = web_client.post("/api/runs", files=[("files", ("del.md", DOC.encode(), "text/markdown"))])
    rid = r.json()["run_id"]
    assert _wait(web_client, rid) == "done"

    run_dir = Path(web_client.get(f"/api/runs/{rid}").json()["run_dir"]
                   if "run_dir" in web_client.get(f"/api/runs/{rid}").json()
                   else W._resolve_run_dir(W._runs[rid]))
    assert run_dir.exists()
    assert web_client.get("/api/ledger").json()["total"] == 1

    resp = web_client.delete(f"/api/runs/{rid}")
    assert resp.status_code == 200 and resp.json()["ok"]

    assert not run_dir.exists(), "run 目录应被删除"
    assert web_client.get("/api/ledger").json()["total"] == 0, "台账记录应被删除"
    assert not any(x["run_id"] == rid for x in web_client.get("/api/runs").json())
    assert web_client.get(f"/api/runs/{rid}").status_code == 404
    # 删除已不存在的 run
    assert web_client.delete(f"/api/runs/{rid}").status_code == 404


def test_delete_run_does_not_resurrect_after_reload(web_client):
    import app.webapp as W
    r = web_client.post("/api/runs", files=[("files", ("del2.md", DOC.encode(), "text/markdown"))])
    rid = r.json()["run_id"]
    assert _wait(web_client, rid) == "done"
    web_client.delete(f"/api/runs/{rid}")
    W._runs.clear()
    W._load_runs_from_disk()          # 模拟重启后的磁盘扫描
    assert rid not in W._runs, "删除后不应从磁盘复活"


def test_history_card_feature_flag(web_client, monkeypatch):
    import app.webapp as W
    assert web_client.get("/api/ui").json()["features"]["history_card"] is True
    monkeypatch.setattr(W.config.ui, "features", {"history_card": False})
    assert web_client.get("/api/ui").json()["features"]["history_card"] is False


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
