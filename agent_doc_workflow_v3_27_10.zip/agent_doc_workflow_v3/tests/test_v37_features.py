"""v3.7 测试：VLM テスト修復 / Content-Disposition 修復 / Excel 抽出。"""
import json
import sys
import time
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.config import load_config
from app.excel_extract import (chart_to_markdown, extract_charts, inspect_workbook,
                               notes_for, parse_chart_xml, workbook_to_markdown)
from app.route_decision import decide_route

# Excel が実際に保存するグラフ XML（キャッシュ付き）。openpyxl が作るブックは
# キャッシュを持たないため、パーサの検証にはこの形が要る。
CHART_XML = """<?xml version="1.0"?>
<c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart"
 xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
<c:chart><c:title><c:tx><c:rich><a:p><a:r><a:t>ケース別 圧力損失</a:t></a:r></a:p></c:rich></c:tx></c:title>
<c:plotArea><c:barChart>
<c:ser>
 <c:tx><c:strRef><c:f>Sheet1!$B$1</c:f><c:strCache><c:pt idx="0"><c:v>圧力損失</c:v></c:pt></c:strCache></c:strRef></c:tx>
 <c:cat><c:strRef><c:strCache>
  <c:pt idx="0"><c:v>Case1</c:v></c:pt><c:pt idx="2"><c:v>Case3</c:v></c:pt>
  <c:pt idx="1"><c:v>Case2</c:v></c:pt></c:strCache></c:strRef></c:cat>
 <c:val><c:numRef><c:numCache>
  <c:pt idx="0"><c:v>120</c:v></c:pt><c:pt idx="1"><c:v>96</c:v></c:pt>
  <c:pt idx="2"><c:v>81</c:v></c:pt></c:numCache></c:numRef></c:val>
</c:ser>
</c:barChart></c:plotArea></c:chart></c:chartSpace>""".encode("utf-8")


# ----------------------------------------------------------------------
# 1. VLM テストが既定構成で必ず落ちていた件
# ----------------------------------------------------------------------

def test_vision_client_builds_without_separate_endpoint():
    """旧実装は model_dump に含まれる timeout_seconds を再指定していて
    TypeError（multiple values）。llm.vision 未設定＝既定構成で 100% 失敗していた。"""
    import app.webapp as W

    assert W.config.llm.vision is None, "既定では視覚専用エンドポイントは無い"
    client = W._vision_client(timeout_seconds=60)      # ここで TypeError が出ないこと
    assert client.model == W.config.llm.model


def test_vision_client_prefers_dedicated_endpoint(monkeypatch):
    import app.webapp as W
    from app.config import VisionLLMConfig

    monkeypatch.setattr(W.config.llm, "vision",
                        VisionLLMConfig(base_url="http://127.0.0.1:8081/v1",
                                        model="qwen3-vl"))
    assert W._vision_endpoint() == "http://127.0.0.1:8081/v1"
    assert W._vision_client().model == "qwen3-vl"


@pytest.mark.parametrize("answer,expected", [
    ({"color": "red"}, True),
    ({"color": "赤"}, True),
    ({"color": "レッド"}, True),
    ("The square in the image is RED.", True),          # JSON で返らなくても拾う
    ({"color": "#FF0000"}, True),
    ({"color": "blue"}, False),
    ({"color": ""}, False),
])
def test_red_detection_is_tolerant(answer, expected):
    import app.webapp as W
    assert W._looks_red(answer) is expected


def test_vision_probe_reports_mock_mode():
    import app.webapp as W
    from fastapi.testclient import TestClient

    original = W.config.llm.mock
    W.config.llm.mock = True
    try:
        assert TestClient(W.app).get("/api/health/vision").json() == {"vision": "mock"}
    finally:
        W.config.llm.mock = original


# ----------------------------------------------------------------------
# 2. RAG ダウンロードの latin-1 エラー
# ----------------------------------------------------------------------

def test_attachment_header_is_latin1_safe():
    """run_id は入力ファイル名 stem 由来なので日本語が普通に混ざる。
    HTTP ヘッダは latin-1 しか載らず、素で入れると送信時に 500 になっていた。"""
    import app.webapp as W

    header = W._attachment("冷却ファン解析_a1b2_rag_internal.jsonl")["Content-Disposition"]
    header.encode("latin-1")                       # ここで例外が出ないことが本題
    assert "filename*=UTF-8''" in header
    assert "%E5%86%B7" in header                   # 原名は percent-encode で保持


def test_attachment_header_keeps_ascii_names_readable():
    import app.webapp as W

    header = W._attachment("rag_corpus_internal.jsonl")["Content-Disposition"]
    assert 'filename="rag_corpus_internal.jsonl"' in header


def test_rag_download_with_japanese_run_id(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient

    import app.webapp as W

    run_id = "冷却ファン解析_a1b2c3d4"
    run_dir = tmp_path / "runs" / run_id
    run_dir.mkdir(parents=True)
    (run_dir / "case_summary.json").write_text(
        json.dumps({"case_name": "冷却ファン解析",
                    "request_details": {"requester": "生産技術部"}},
                   ensure_ascii=False), encoding="utf-8")
    (run_dir / "manifest.json").write_text(
        json.dumps({"input_path": "冷却ファン解析.xlsx"}, ensure_ascii=False), encoding="utf-8")
    W._runs[run_id] = {"run_id": run_id, "input_name": "冷却ファン解析.xlsx",
                       "state": "done", "run_dir": str(run_dir), "created": time.time()}
    try:
        res = TestClient(W.app).get(f"/api/runs/{run_id}/rag.jsonl?tier=internal")
        assert res.status_code in (200, 404)       # 中身の有無は問わない
        if res.status_code == 200:
            res.headers["content-disposition"].encode("latin-1")
    finally:
        W._runs.pop(run_id, None)


# ----------------------------------------------------------------------
# 3. Excel：グラフ / 数式 / 構造検査
# ----------------------------------------------------------------------

def test_chart_data_recovered_from_cache():
    """グラフは xl/media に無い（ベクタ定義）。numCache から数値を復元できること。
    弱いローカルモデルに図を読ませるより、この表を渡す方が確実という設計判断の要。"""
    chart = parse_chart_xml(CHART_XML)
    assert chart["title"] == "ケース別 圧力損失"
    assert chart["types"] == ["bar"]
    assert chart["categories"] == ["Case1", "Case2", "Case3"], "idx 順に並べ直す"
    assert chart["series"][0]["name"] == "圧力損失"
    assert chart["series"][0]["values"] == ["120", "96", "81"]

    md = chart_to_markdown(chart, 1)
    assert "| Case1 | 120 |" in md and "ケース別 圧力損失" in md


def test_chart_without_cache_keeps_reference():
    xml = CHART_XML.replace(b"<c:numCache>", b"<c:noCache>").replace(
        b"</c:numCache>", b"</c:noCache>")
    chart = parse_chart_xml(xml)
    md = chart_to_markdown(chart, 1)
    assert "参照範囲" in md or chart["series"], "数値が無くても範囲だけは残す"


def test_broken_chart_xml_is_survivable():
    assert parse_chart_xml(b"<not-xml") == {}


def _make_workbook(path: Path, with_chart: bool = True):
    import openpyxl
    from openpyxl.chart import BarChart, Reference

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "解析結果"
    ws.append(["条件", "圧力損失", "温度"])
    for row in [("Case1", 120, 58), ("Case2", 96, 54), ("Case3", 81, 51)]:
        ws.append(row)
    ws["E1"] = "合計"
    ws["E2"] = "=SUM(B2:B4)"
    if with_chart:
        chart = BarChart()
        chart.title = "圧力損失"
        chart.add_data(Reference(ws, min_col=2, min_row=1, max_row=4), titles_from_data=True)
        ws.add_chart(chart, "G2")
    hidden = wb.create_sheet("非表示")
    hidden["A1"] = "隠しシートの内容"
    hidden.sheet_state = "hidden"
    wb.save(path)
    return path


def test_workbook_to_markdown_reads_values_not_formulas(tmp_path):
    """既定の openpyxl は数式セルに '=SUM(B2:B4)' という文字列を返す。
    要約に必要なのは計算結果なので data_only で読み、数式は別枠で添える。"""
    xl = _make_workbook(tmp_path / "book.xlsx")
    result = workbook_to_markdown(xl)
    md = result["markdown"]

    assert result["ok"]
    assert "| Case1 | 120 | 58 |" in md
    assert "=SUM(B2:B4)" not in md.split("## 主な数式")[0], "本文の表に数式文字列は出さない"
    assert "## 主な数式" in md and "`=SUM(B2:B4)`" in md
    assert "隠しシートの内容" not in md, "非表示シートは取り込まない"


def test_workbook_markdown_includes_chart_section(tmp_path):
    xl = _make_workbook(tmp_path / "chart.xlsx")
    assert "## グラフ" in workbook_to_markdown(xl)["markdown"]
    assert len(extract_charts(xl)) == 1


def test_inspect_workbook_flags_hidden_content(tmp_path):
    xl = _make_workbook(tmp_path / "i.xlsx")
    info = inspect_workbook(xl)
    assert info["charts"] == 1 and info["sheets"] == 2
    assert info["media_images"] == 0, "グラフは画像ではないので media は空"

    notes = notes_for({"pivot_tables": 2, "external_links": 1, "data_model": True,
                       "has_vba": True, "size_mb": 30})
    joined = "\n".join(notes)
    for token in ("ピボット", "外部データリンク", "データモデル", "マクロ", "大型"):
        assert token in joined, f"{token} の注記が無い"


def test_workbook_to_markdown_rejects_junk(tmp_path):
    bad = tmp_path / "bad.xlsx"
    bad.write_bytes(b"definitely not a workbook")
    result = workbook_to_markdown(bad)
    assert not result["ok"] and result["markdown"] == ""


def test_excel_always_takes_the_direct_read_route(tmp_path):
    """表を画像化して読ませるのは弱いモデルに酷。Excel は常にテキスト経路。"""
    xl = _make_workbook(tmp_path / "route.xlsx")
    wf = load_config().workflow
    wf.input_mode = "auto"
    route, reason, _ = decide_route(str(xl), wf)
    assert route == "text" and "Excel" in reason

    wf.input_mode = "vision"       # 手動指定は尊重する（ページ画像も欲しい場合）
    assert decide_route(str(xl), wf)[0] == "vision"


def test_excel_com_degrades_without_windows():
    """Excel が無い環境では例外ではなく ok=False を返し、純 Python 経路へ落ちる。"""
    from tools.excel_com import excel_available, excel_extract

    if excel_available():
        pytest.skip("Excel COM が使える環境ではこの検査は不要")
    result = excel_extract("dummy.xlsx", "/tmp/x")
    assert result["ok"] is False and result["chart_images"] == []


def test_excel_pipeline_end_to_end(tmp_path):
    from app.graph import run_workflow

    xl = _make_workbook(tmp_path / "台帳.xlsx")
    cfg = load_config()
    cfg.llm.mock = True
    cfg.paths.out_dir = str(tmp_path / "out")
    final = run_workflow(str(xl), cfg, template_id="case")

    run_dir = Path(final["run_dir"])
    info = json.loads((run_dir / "excel_info.json").read_text(encoding="utf-8"))
    assert info["info"]["charts"] == 1
    md = (run_dir / "parsed" / "台帳.md").read_text(encoding="utf-8")
    assert "| Case1 |" in md and "## グラフ" in md
    assert (run_dir / "case_summary.md").exists()
