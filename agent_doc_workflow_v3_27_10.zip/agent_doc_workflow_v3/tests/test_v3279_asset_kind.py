"""v3.27.9：資産種別の判定が解析ルートで変わってしまう不具合。

症状：PPTX では図が入るのに **Excel では入らない**。除外理由の最多は
「全面レンダリング（allow_page_render=false）」。

原因：`_asset_provenance` の最終段が「視覚ルートなら名前が分からない資産は
全部 page_render」だった。この前提は視覚ルートの資産が頁画像しか無かった
頃は正しかったが、v3.27.3 で図版用の埋込画像を意図的に足したので崩れていた。

Excel が直撃したのは命名の非対称：
  PPTX  office_p006_image11.png  … スライド番号が付く → 既存規則で embedded
  Excel office_image3.png        … 表に「頁」が無く番号が付かない → 最終段へ落ちる
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.nodes import _asset_provenance  # noqa: E402


def kind(path: str, page_mode: bool) -> str:
    return _asset_provenance(path, 0, page_mode)["asset_kind"]


# ---- 回帰の本体 ----

def test_excel_embedded_is_embedded_in_both_routes():
    p = "visual_office/office_image3.png"
    assert kind(p, False) == "embedded"
    assert kind(p, True) == "embedded"      # ここが page_render になっていた


def test_pptx_and_excel_embedded_agree():
    """スライド番号の有無で種別が変わってはいけない。"""
    assert kind("visual_office/office_p006_image11.png", True) == "embedded"
    assert kind("visual_office/office_image3.png", True) == "embedded"


def test_route_does_not_change_kind_for_known_assets():
    for p in ("visual_office/office_image3.png",
              "visual_office/office_p006_image11.png",
              "visual_pdf/pdf_p003_img01.png",
              "visual_pages/page_003.png",
              "visual_excel_sheets/sheet_02_売上.png",
              "visual_excel/chart_1.png"):
        assert kind(p, False) == kind(p, True), p


# ---- 出所ディレクトリによる判定 ----

def test_directory_is_used_when_the_name_is_unfamiliar():
    """命名規則が増えるたびに取りこぼすより、収集経路で判断する。"""
    assert kind("visual_office/xl_media_7.png", True) == "embedded"
    assert kind("visual_pdf/extracted_9.png", True) == "embedded"
    assert kind("visual_excel/売上推移.png", True) == "chart"
    assert kind("visual_excel_sheets/売上_1.png", True) == "sheet_render"
    assert kind("visual_pages/rendered_12.png", True) == "page_render"


def test_contact_sheet_dir_is_page_render():
    assert kind("visual_contact/contact_p003_01.png", True) == "page_render"


def test_truly_unknown_still_falls_back_in_vision_route():
    """出所も名前も分からない物は、従来どおり頁画像とみなす。"""
    assert kind("somewhere/unknown.png", True) == "page_render"
    assert kind("somewhere/unknown.png", False) == "embedded"


# ---- 通し番号は頁画像のときだけ ----

def test_page_index_is_only_assigned_to_page_renders():
    """埋込画像に通し番号を頁として与えると、密集頁の判定や
    本文との頁照合が架空の頁番号で動いてしまう。"""
    assert _asset_provenance("visual_office/office_image3.png", 4, True)["page"] is None
    assert _asset_provenance("somewhere/unknown.png", 4, True)["page"] == 5


# ---- 実ファイルでの通し確認 ----

def test_real_xlsx_embedded_image_survives_to_candidate(tmp_path):
    import json

    import openpyxl
    from openpyxl.drawing.image import Image as XLImage
    from PIL import Image

    from app.figure_select import DEFAULTS, build_candidates
    from app.parsing import extract_office_visuals

    src = tmp_path / "graph.png"
    Image.new("RGB", (900, 600), "white").save(src)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws["A1"] = "四半期"
    ws.add_image(XLImage(str(src)), "D2")
    xlsx = tmp_path / "売上.xlsx"
    wb.save(xlsx)

    res = extract_office_visuals(str(xlsx), out_dir=str(tmp_path / "visual_office"),
                                 max_assets=12)
    paths = res["visual_asset_paths"]
    assert paths and Path(paths[0]).name.startswith("office_image")

    # 視覚ルートの判定で embedded のままであること
    assert kind(paths[0], True) == "embedded"

    ve = [{"evidence_id": "visual_asset_0001", "image_path": paths[0],
           "asset_kind": kind(paths[0], True), "visual_type": "chart",
           "visual_summary": "四半期売上の比較グラフ",
           "key_facts": ["Q2 売上 18.4 % 増"], "readable_text": ["18.4", "%"],
           "confidence": 0.0, "has_useful_visual_info": False}]
    drops = {}
    cands = build_candidates(ve, tmp_path, DEFAULTS, drops=drops)
    assert len(cands) == 1, drops
    json.dumps(drops)      # 落ちていない
