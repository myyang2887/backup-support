"""v3.27.5：一括処理の事前確認で、除外されたファイルを名前で示す。

「未対応 4 件は除外」だけでは、.doc の取りこぼしなのか単なる画像なのか
判らず、利用者は結局フォルダを自分で見に行くしかなかった。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.batch import scan_folder  # noqa: E402


def _tree(root: Path, names):
    for n in names:
        p = root / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("x", encoding="utf-8")
    return root


def test_skipped_files_are_named(tmp_path):
    _tree(tmp_path, ["a.pdf", "b.pptx", "old.doc", "slide.ppt",
                     "photo.png", "data.csv"])
    r = scan_folder(tmp_path)
    assert r["count"] == 2
    assert r["skipped_unsupported"] == 4
    names = {f["name"] for f in r["skipped_files"]}
    assert names == {"old.doc", "slide.ppt", "photo.png", "data.csv"}
    assert not r["skipped_listed_truncated"]


def test_suffix_breakdown_is_sorted_by_count(tmp_path):
    _tree(tmp_path, ["a.pdf"] + [f"p{i}.png" for i in range(3)] + ["x.doc"])
    r = scan_folder(tmp_path)
    assert list(r["skipped_by_suffix"]) == [".png", ".doc"]
    assert r["skipped_by_suffix"][".png"] == 3


def test_relative_path_is_kept_for_nested_files(tmp_path):
    _tree(tmp_path, ["a.pdf", "2023/古い資料/old.doc"])
    r = scan_folder(tmp_path, recursive=True)
    rels = {f["rel"] for f in r["skipped_files"]}
    assert rels == {str(Path("2023/古い資料/old.doc"))}


def test_listing_is_capped_but_count_is_complete(tmp_path):
    _tree(tmp_path, ["a.pdf"] + [f"n{i:03d}.png" for i in range(80)])
    r = scan_folder(tmp_path, max_skipped_listed=50)
    assert r["skipped_unsupported"] == 80        # 件数は全部数える
    assert len(r["skipped_files"]) == 50         # 名前は上限まで
    assert r["skipped_listed_truncated"]
    assert r["skipped_by_suffix"][".png"] == 80  # 内訳も全件


def test_extensionless_files_are_labelled(tmp_path):
    _tree(tmp_path, ["a.pdf", "README"])
    r = scan_folder(tmp_path)
    assert r["skipped_files"][0]["suffix"] == "(拡張子なし)"


def test_hidden_and_lock_files_are_not_counted_as_skipped(tmp_path):
    """除外件数に出てはいけない物。これらは「未対応」ではなく走査対象外。"""
    _tree(tmp_path, ["a.pdf", ".DS_Store", "~$報告書.pptx"])
    r = scan_folder(tmp_path)
    assert r["count"] == 1
    assert r["skipped_unsupported"] == 0
    assert r["skipped_files"] == []


def test_output_dirs_are_not_counted_as_skipped(tmp_path):
    _tree(tmp_path, ["a.pdf", "out/runs/x/case_summary.md", "out/ledger.sqlite3"])
    r = scan_folder(tmp_path, recursive=True)
    assert r["count"] == 1
    assert r["skipped_unsupported"] == 0


def test_no_skips_returns_empty_list(tmp_path):
    _tree(tmp_path, ["a.pdf", "b.docx"])
    r = scan_folder(tmp_path)
    assert r["skipped_unsupported"] == 0 and r["skipped_files"] == []


# ---- v3.27.6：.md / .txt の一時停止 ----

def test_md_and_txt_are_suspended(tmp_path):
    _tree(tmp_path, ["a.pdf", "note.md", "memo.txt", "b.pptx"])
    r = scan_folder(tmp_path)
    assert r["count"] == 2
    assert {f["name"] for f in r["skipped_files"]} == {"note.md", "memo.txt"}


def test_allowlists_agree_between_webapp_and_batch():
    """webapp と batch で対象拡張子がずれると、CLI や将来の呼び出し側だけ
    挙動が違う、という追いにくい形で表面化する。

    conftest が試験中だけ ALLOWED_SUFFIXES を緩めるので、ここで比べるのは
    **方針そのもの**（停止集合）と、それを差し引く前の土台。
    """
    import app.batch as B
    import app.webapp as W
    assert B.SUSPENDED_SUFFIXES == W.SUSPENDED_SUFFIXES
    assert B.DEFAULT_SUFFIXES == (W.ALLOWED_SUFFIXES | W.SUSPENDED_SUFFIXES) - W.SUSPENDED_SUFFIXES


def test_suspension_is_reversible():
    """差集合で書いてあるので、停止集合を空にすれば戻ること。"""
    from app.batch import SUSPENDED_SUFFIXES
    assert SUSPENDED_SUFFIXES == {".md", ".txt"}
    base = {".pdf", ".docx", ".pptx", ".xlsx", ".xlsm", ".xls",
            ".md", ".txt", ".html"}
    from app.batch import DEFAULT_SUFFIXES
    assert DEFAULT_SUFFIXES == base - SUSPENDED_SUFFIXES
    assert base - set() == base           # 空にすれば全部戻る


def test_scan_returns_the_supported_list_it_used(tmp_path):
    """画面の案内はこの値から作る。書き写すと変更時に案内だけ古くなる。"""
    _tree(tmp_path, ["a.pdf"])
    r = scan_folder(tmp_path, suffixes={".pdf", ".docx"})
    assert r["supported_suffixes"] == [".docx", ".pdf"]


def test_frontend_does_not_hardcode_the_suffix_list():
    html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(encoding="utf-8")
    assert "supported_suffixes" in html
    # 一覧を画面に書き写していないこと
    assert ".pdf .docx .pptx" not in html
    # ファイル選択のフィルタからも外れていること
    assert 'accept=".pdf,.docx,.pptx,.xlsx,.xlsm,.xls,.html"' in html
