"""v3.10 の回帰テスト：OOXML 頁マッピングと Office COM 経由の PDF 変換。

この版で潰したのは 2 点：
1. OOXML 由来の画像が頁番号を持たず、精読モードが PPTX に効かなかった
2. PDF 変換が LibreOffice 一択で、未導入の Windows 機では視覚ルートが
   静かに機能しなくなっていた
"""
from __future__ import annotations

import io
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.nodes import _asset_provenance
from app.parsing import _ooxml_media_page_map, extract_office_visuals


def _deck(tmp_path: Path, image_slides=(2, 4, 5), total=5) -> Path:
    """画像を特定のスライドにだけ置いた PPTX を作る。"""
    from pptx import Presentation
    from pptx.util import Inches
    from PIL import Image

    prs = Presentation()
    for i in range(1, total + 1):
        s = prs.slides.add_slide(prs.slide_layouts[5])
        s.shapes.title.text = f"スライド {i}"
        if i in image_slides:
            buf = io.BytesIO()
            # 頁ごとに色を変える。同一バイトだと ZIP 側で共有されて頁が曖昧になる
            Image.new("RGB", (240, 160), (30 * i % 255, 90, 200 - 20 * i)).save(buf, "PNG")
            buf.seek(0)
            s.shapes.add_picture(buf, Inches(1), Inches(2), Inches(3))
    out = tmp_path / "deck.pptx"
    prs.save(str(out))
    return out


# ----------------------------------------------------------------------
# OOXML 頁マッピング
# ----------------------------------------------------------------------

def test_media_is_mapped_to_slide_number(tmp_path):
    src = _deck(tmp_path, image_slides=(2, 4, 5))
    with zipfile.ZipFile(src) as zf:
        mapping = _ooxml_media_page_map(zf)
    assert sorted(mapping.values()) == [2, 4, 5], f"頁の対応が取れていない: {mapping}"


def test_extracted_filenames_carry_page(tmp_path):
    src = _deck(tmp_path, image_slides=(2, 4, 5))
    res = extract_office_visuals(str(src), str(tmp_path / "out"))
    names = [Path(p).name for p in res["visual_asset_paths"]]
    assert res["pages_mapped"] == 3
    assert all(n.startswith("office_p") for n in names), names


def test_provenance_round_trips_from_filename(tmp_path):
    """ファイル名 → 頁番号 が復元できること（精読モードの前提）。"""
    src = _deck(tmp_path, image_slides=(2, 4, 5))
    res = extract_office_visuals(str(src), str(tmp_path / "out"))
    pages = [_asset_provenance(p, i, False)["page"]
             for i, p in enumerate(res["visual_asset_paths"])]
    assert pages == [2, 4, 5]


def test_assets_are_ordered_by_document_not_lexicographically(tmp_path):
    """image1, image10, image11, image2… の辞書順で並べないこと。

    枚数上限で切り捨てるとき、辞書順だと「文書の後半」ではなく
    「辞書順で後ろ」が消える。12 枚以上で初めて差が出る。
    """
    src = _deck(tmp_path, image_slides=tuple(range(1, 13)), total=12)
    res = extract_office_visuals(str(src), str(tmp_path / "out"))
    pages = [_asset_provenance(p, i, False)["page"]
             for i, p in enumerate(res["visual_asset_paths"])]
    assert pages == sorted(pages), f"文書順になっていない: {pages}"
    assert pages[:3] == [1, 2, 3]


def test_asset_cap_keeps_the_beginning_of_the_document(tmp_path):
    src = _deck(tmp_path, image_slides=tuple(range(1, 13)), total=12)
    res = extract_office_visuals(str(src), str(tmp_path / "out"), max_assets=4)
    pages = [_asset_provenance(p, i, False)["page"]
             for i, p in enumerate(res["visual_asset_paths"])]
    assert pages == [1, 2, 3, 4], f"切り捨てが文書順になっていない: {pages}"


def test_docx_images_get_sequence_numbers(tmp_path):
    """Word には頁の概念が無いので出現順の連番を振る（順序だけでも価値がある）。"""
    from docx import Document
    from docx.shared import Inches
    from PIL import Image

    doc = Document()
    for i in range(3):
        doc.add_paragraph(f"段落 {i}")
        buf = io.BytesIO()
        Image.new("RGB", (200, 120), (60 * i % 255, 100, 150)).save(buf, "PNG")
        buf.seek(0)
        doc.add_picture(buf, width=Inches(2))
    src = tmp_path / "d.docx"
    doc.save(str(src))

    res = extract_office_visuals(str(src), str(tmp_path / "out"))
    pages = [_asset_provenance(p, i, False)["page"]
             for i, p in enumerate(res["visual_asset_paths"])]
    assert pages == [1, 2, 3], pages


def test_unmapped_images_still_extracted(tmp_path):
    """関係を辿れなかった画像も捨てず、頁なしとして残すこと。"""
    src = _deck(tmp_path, image_slides=(2,))
    # media に無関係な画像を後付けで放り込む（どのスライドからも参照されない）
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (150, 150), (10, 20, 30)).save(buf, "PNG")
    with zipfile.ZipFile(src, "a") as zf:
        zf.writestr("ppt/media/orphan.png", buf.getvalue())

    res = extract_office_visuals(str(src), str(tmp_path / "out"))
    names = [Path(p).name for p in res["visual_asset_paths"]]
    assert any(n.startswith("office_p") for n in names), "頁付きが無い"
    assert any(not n.startswith("office_p") for n in names), "孤児画像が捨てられている"


# ----------------------------------------------------------------------
# Office COM 経由の PDF 変換
# ----------------------------------------------------------------------

def test_office_com_unavailable_off_windows():
    import os
    from tools.office_com import powerpoint_available, word_available
    if os.name != "nt":
        assert powerpoint_available() is False
        assert word_available() is False


def test_office_to_pdf_reports_which_engine_failed(tmp_path):
    """変換手段が無いときは、COM と LibreOffice の両方の理由を返すこと。

    「なぜ頁画像が出ないのか」が分からないのが v3.9 までの問題だった。
    """
    from app.parsing import office_to_pdf
    from tools.visual_asset_tools import find_soffice

    src = tmp_path / "x.pptx"
    src.write_bytes(b"dummy")
    res = office_to_pdf(str(src), str(tmp_path / "out"))
    if find_soffice() is None:
        assert res["ok"] is False
        assert "COM" in res["error"] and "LibreOffice" in res["error"]


def test_office_to_pdf_prefers_com(monkeypatch, tmp_path):
    """COM が使えるなら LibreOffice を呼ばないこと。"""
    import app.parsing as P
    import tools.office_com as OC

    called = {"com": 0}
    pdf = tmp_path / "converted.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")

    def fake_com(path, out_dir, timeout_seconds=600):
        called["com"] += 1
        return {"ok": True, "pdf_path": str(pdf)}

    monkeypatch.setattr(OC, "office_com_available_for", lambda s: True)
    monkeypatch.setattr(OC, "office_to_pdf_com", fake_com)
    monkeypatch.setattr(P, "find_soffice", lambda: "/never/used", raising=False)

    src = tmp_path / "a.pptx"
    src.write_bytes(b"x")
    res = P.office_to_pdf(str(src), str(tmp_path / "o"))
    assert res["ok"] is True
    assert res["engine"] == "office_com"
    assert called["com"] == 1


def test_com_handles_legacy_binary_formats():
    """.ppt / .doc は OOXML ではないので ZIP 経路が使えない。

    COM はアプリ本体に開かせるので旧形式こそ確実に扱える。
    """
    from tools.office_com import _APP_FOR_SUFFIX
    assert _APP_FOR_SUFFIX[".ppt"] == "powerpoint"
    assert _APP_FOR_SUFFIX[".doc"] == "word"


def test_trace_knows_office_com_engine():
    from app.trace import ENGINE_OFFICE_COM, engine_kind, engine_label
    assert "PowerPoint" in engine_label(ENGINE_OFFICE_COM)
    assert engine_kind(ENGINE_OFFICE_COM) == "Office 実機"


def test_environment_report_includes_office_com():
    from app.trace import ENGINE_OFFICE_COM, environment_report
    env = environment_report()
    assert any(r["engine"] == ENGINE_OFFICE_COM for r in env["engines"])
