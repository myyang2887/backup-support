"""v3.8 の回帰テスト。

このバージョンで直したのは「黙って情報を捨てる」系の不具合なので、
テストも「捨てていないこと」と「捨てたなら記録が残ること」を見る。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.accounting import (LossLedger, compute_fill_rate,
                            template_mismatch_verdict)
from app.contract import (BLANK_SENTINELS, EXTRACTION_FAILED, NOT_APPLICABLE,
                          UNKNOWN, Evidence, EvidenceList, VisualEvidence,
                          is_blank, schema_skeleton)
from app.evidence import visual_to_pack
from app.parsing import structural_chunks_traced


# ----------------------------------------------------------------------
# 損失台帳
# ----------------------------------------------------------------------

def test_ledger_tracks_retention_and_round_trips():
    led = LossLedger()
    led.observe("text_chunk", 100)
    led.drop("text_chunk", 40, "上限", severity="high")
    assert led.retention("text_chunk") == 0.6
    assert led.has_critical_loss() is True

    # 並行分岐をまたぐので raw <-> from_raw が壊れないこと
    back = LossLedger.from_raw(led.raw())
    assert back.retention("text_chunk") == 0.6
    assert back.dropped_total("text_chunk") == 40


def test_ledger_merge_combines_branches():
    a, b = LossLedger(), LossLedger()
    a.observe("text_chunk", 10)
    b.observe("visual_asset", 20)
    b.drop("visual_asset", 5, "重複")
    a.merge(b)
    assert a.observed["visual_asset"] == 20
    assert a.retention("visual_asset") == 0.75


# ----------------------------------------------------------------------
# 溯源が LLM スキーマへ漏れないこと（v3.8 で一度やらかした所）
# ----------------------------------------------------------------------

def test_provenance_does_not_leak_into_llm_schema():
    """LLM に見せる EvidenceList には溯源フィールドを出してはいけない。

    出すと grammar 制約でモデルに「知りようのない頁番号を書け」と要求
    することになり、抽出そのものが壊れる。
    """
    sk = schema_skeleton(EvidenceList.model_json_schema())
    assert set(sk["evidence"][0]) == {
        "evidence_id", "category", "content", "confidence", "source"}


def test_internal_evidence_carries_provenance():
    ev = Evidence(content="x", page=3, heading="第2章", chunk_id="text_chunk_0007")
    assert ev.page == 3 and ev.heading == "第2章"


# ----------------------------------------------------------------------
# 切块：表頭の復元と、捨てないこと
# ----------------------------------------------------------------------

def test_table_header_is_repeated_on_every_slice():
    rows = "\n".join(f"| 行{i} | {i * 2} | mm |" for i in range(1, 300))
    md = "# ページ 1\n| 項目 | 値 | 単位 |\n|---|---|---|\n" + rows
    chunks, rep = structural_chunks_traced(md, chunk_chars=800, overlap=80)
    assert len(chunks) > 2
    assert rep["table_header_repeats"] >= len(chunks) - 1
    for c in chunks[1:]:
        assert "| 項目 | 値 | 単位 |" in c["text"], "分片に見出し行が無い"


def test_low_info_chunks_are_kept_by_default():
    """精度優先：情報量が少なくても既定では捨てない（印だけ付ける）。"""
    md = "# ページ 1\n7\n\n# ページ 2\nこれは十分に長い本文です。" * 3
    chunks, rep = structural_chunks_traced(md, min_informative_chars=80)
    assert rep["dropped_low_info"] == 0
    assert any(c.get("low_info") for c in chunks)


def test_low_info_drop_is_recorded_when_enabled():
    # chunk_chars を小さくして小節の合併を起こさせない。合併されると
    # 低情報量の節が隣の本文に吸収されて、そもそも捨てる対象にならない
    # （これは意図した挙動なので、単独で残る条件を作って検証する）。
    md = "# ページ 1\n7\n\n# ページ 2\n" + "十分に長い本文。" * 30
    chunks, rep = structural_chunks_traced(md, chunk_chars=100, overlap=10,
                                           min_informative_chars=80,
                                           drop_low_info=True)
    assert rep["dropped_low_info"] >= 1
    assert rep["dropped_detail"], "何を捨てたかの記録が無い"


def test_chunk_carries_page_and_heading():
    md = "# ページ 3\n本文がここにあります。十分な長さの日本語テキストです。"
    chunks, _ = structural_chunks_traced(md)
    assert chunks[0]["page"] == 3
    assert chunks[0]["heading"] == "ページ 3"


# ----------------------------------------------------------------------
# 視覚証拠のパッキング（PPTX 情報欠落の主犯だった所）
# ----------------------------------------------------------------------

def _page(i: int, useful: bool, lines: int = 30) -> VisualEvidence:
    return VisualEvidence(evidence_id=f"visual_asset_{i:04d}", page=i,
                          asset_kind="page_render", has_useful_visual_info=useful,
                          readable_text=[f"{i}頁{j}行目" for j in range(lines)],
                          confidence=0.5)


def test_page_renders_survive_useless_flag():
    """ページ画像は has_useful_visual_info=false でも捨ててはいけない。

    VISION_SYSTEM の「装飾なら false」に素直に従ったモデルのせいで、
    文字だけのスライドが丸ごと消えていたのが v3.7 の症状。
    """
    items = [_page(i, useful=(i % 3 == 0)) for i in range(1, 16)]
    packed = visual_to_pack(items, max_total_chars=1_000_000)
    assert len(packed) == 15


def test_readable_text_is_not_truncated_by_default():
    packed = visual_to_pack([_page(1, True, lines=40)], max_total_chars=1_000_000)
    assert len(packed[0]["readable_text"]) == 40


def test_pack_is_page_ordered_not_confidence_ordered():
    items = [_page(3, True), _page(1, True), _page(2, True)]
    items[0].confidence = 0.99   # 3 頁目を最高信頼度にしても順序は頁順
    packed = visual_to_pack(items, max_total_chars=1_000_000)
    assert [d["page"] for d in packed] == [1, 2, 3]


def test_embedded_decoration_is_still_filtered():
    """ページではない埋込画像は従来どおり間引く（無駄な context を食わせない）。"""
    deco = VisualEvidence(evidence_id="v1", asset_kind="embedded",
                          has_useful_visual_info=False)
    assert visual_to_pack([deco], max_total_chars=10_000) == []


def test_budget_overflow_is_recorded_not_silent():
    led = LossLedger()
    items = [_page(i, True, lines=50) for i in range(1, 30)]
    visual_to_pack(items, max_total_chars=3000, ledger=led)
    assert led.dropped_total("visual_evidence") > 0
    assert any("上限" in d.reason for d in led.drops)


# ----------------------------------------------------------------------
# UNKNOWN 三分割と覆盖率
# ----------------------------------------------------------------------

def test_blank_sentinels_are_distinguishable():
    assert UNKNOWN in BLANK_SENTINELS
    assert NOT_APPLICABLE in BLANK_SENTINELS
    assert EXTRACTION_FAILED in BLANK_SENTINELS
    assert NOT_APPLICABLE != UNKNOWN != EXTRACTION_FAILED
    assert is_blank([UNKNOWN]) and is_blank("") and not is_blank(["実データ"])


def test_fill_rate_flags_template_mismatch():
    """技術報告書に依頼対応事例テンプレを当てた状況を再現する。"""
    summary = {"case_name": "解析報告",
               "request_details": {"requester": UNKNOWN, "client_issues": [UNKNOWN],
                                   "scope_of_request": [UNKNOWN],
                                   "target_product_or_system": "装置A"},
               "action_results": {"support_type": UNKNOWN, "findings": ["圧力偏り"],
                                  "effects": [UNKNOWN]}}
    appl = {"case_name": "required", "requester": "required",
            "target_product_or_system": "required", "client_issues": "required",
            "scope_of_request": "required", "support_type": "required",
            "findings": "required", "effects": "required"}
    fill = compute_fill_rate(summary, appl, is_blank)
    assert fill["required_fill_rate"] < 0.5
    verdict = template_mismatch_verdict(fill, 0.4, "依頼対応事例")
    assert verdict["mismatch"] is True
    assert "requester" in verdict["missing_required"]


def test_not_applicable_excluded_from_denominator():
    """該当なし の項目は分母に入れない（無くて当然なので減点しない）。"""
    summary = {"a": "値", "b": UNKNOWN}
    fill = compute_fill_rate(summary, {"a": "required", "b": "n_a"}, is_blank)
    assert fill["required_total"] == 1
    assert fill["required_fill_rate"] == 1.0
    assert fill["not_applicable"] == 1


# ----------------------------------------------------------------------
# 汎用テンプレートの受け皿
# ----------------------------------------------------------------------

def test_generic_doc_template_is_registered_and_valid():
    from app.template_registry import get_registry
    reg = get_registry()
    ids = {t["id"] for t in reg.list()}
    assert "generic_doc" in ids
    assert reg.verify_all() == {}, "j2 が契約に無い変数を参照している"
    spec = reg.get("generic_doc")
    assert spec.field_applicability["document_title"] == "required"


def test_case_template_declares_applicability():
    from app.template_registry import get_registry
    spec = get_registry().get("case")
    assert spec.field_applicability.get("requester") == "required"
    assert spec.min_fill_rate > 0


# ----------------------------------------------------------------------
# 台帳・一括実行履歴の削除
# ----------------------------------------------------------------------

@pytest.fixture()
def client(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    monkeypatch.setenv("AGENT_OUT_DIR", str(tmp_path / "out"))
    from app import webapp
    return TestClient(webapp.app)


def test_delete_many_rejects_empty_payload(client):
    r = client.post("/api/runs/delete-many", json={"run_ids": []})
    assert r.status_code == 400


def test_ledger_clear_requires_confirmation(client):
    assert client.post("/api/ledger/clear").status_code == 400
    r = client.post("/api/ledger/clear", params={"confirm": "DELETE"})
    assert r.status_code == 200
    assert r.json()["ok"] is True


def test_batch_delete_many_rejects_empty(client):
    r = client.post("/api/batches/delete-many", json={"batch_ids": []})
    assert r.status_code == 400


def test_ledger_delete_many_removes_rows(tmp_path):
    from app.ledger import Ledger
    led = Ledger(tmp_path / "l.db")
    for i in range(5):
        led.upsert({"run_id": f"r{i}", "run_dir": f"/d/r{i}", "case_name": f"件{i}"})
    assert led.delete_many(["r1", "r3"]) >= 2
    rows, _ = led.search(limit=50)
    assert {r["run_id"] for r in rows} == {"r0", "r2", "r4"}
    assert led.clear() == 3
    assert led.search(limit=50)[1] == 0


# ----------------------------------------------------------------------
# 視覚ルート × Excel は LibreOffice ではなく Excel COM を使うこと
# ----------------------------------------------------------------------
#
# v3.8 の初回実装で取りこぼした所。collect_visuals は
#   if vision_route: ... elif suffix == ".pdf": ... elif suffix in (".xlsx",...)
# という elif 連鎖なので、視覚ルートでは Excel 専用分岐に**到達しない**。
# 結果、PageSetup で横 1 ページに収める excel_sheet_pdfs が一度も呼ばれず、
# 横に広い表が数十ページに飛び散る LibreOffice 経路をそのまま通っていた。
# 分岐順序は将来また壊れやすいので、ここで固定する。

def test_excel_com_not_available_off_windows():
    from app.nodes import _excel_com_ready
    import os
    if os.name != "nt":
        assert _excel_com_ready() is False, "非 Windows で COM 可用と誤判定している"


def test_vision_route_excel_prefers_com_over_libreoffice(tmp_path, monkeypatch):
    """COM が使える環境では、視覚ルートの Excel は excel_sheet_pdfs を通る。"""
    import app.nodes as N
    calls = {"com": 0}

    def fake_page_images(state, wf):
        calls["com"] += 1
        return ["/fake/sheet_01_売上_p001.png"], "シート描画 1 枚（Excel COM）"

    monkeypatch.setattr(N, "_excel_com_ready", lambda: True)
    monkeypatch.setattr(N, "_excel_page_images", fake_page_images)

    # collect_visuals は build_nodes のクロージャ内なので、分岐条件だけを検証する
    src = Path(N.__file__).read_text(encoding="utf-8")
    assert 'if vision_route and suffix in (".xlsx", ".xlsm") and _excel_com_ready():' in src, \
        "視覚ルート用の Excel COM 分岐が消えている"
    # 分岐が elif 連鎖の *先頭* にあること（後ろだと到達しない）
    i_com = src.index('if vision_route and suffix in (".xlsx", ".xlsm")')
    i_generic = src.index("elif vision_route:")
    assert i_com < i_generic, "Excel COM 分岐が汎用の視覚ルート分岐より後ろにある"
    assert callable(fake_page_images) and calls["com"] == 0


def test_excel_page_images_falls_back_to_empty(tmp_path, monkeypatch):
    """COM 側が失敗しても例外を投げず空を返す（呼び出し側が後退できる）。"""
    import app.nodes as N
    import tools.excel_com as EC
    monkeypatch.setattr(EC, "excel_sheet_pdfs",
                        lambda *a, **k: {"ok": False, "sheets": [], "exported": 0,
                                         "skipped": 0, "error": "Excel なし"})
    state = {"run_dir": str(tmp_path), "input_path": str(tmp_path / "x.xlsx"),
             "errors_visual": []}

    class WF:
        excel_sheet_render_max_sheets = 20
        excel_sheet_render_landscape = True
        excel_sheet_render_timeout = 60.0
        pdf_render_scale = 2.0
        vision_route_max_render_pages = 40

    pages, meta = N._excel_page_images(state, WF())
    assert pages == []
    assert "シート描画 0 枚" in meta
