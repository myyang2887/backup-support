"""v3.24：Excel の日付を正規化する（台帳・本文の両経路）。

利用者報告：台帳から完了日を抽出すると、まったく無関係な数値になる。
さらに、アンケートの回答日時を案件の完了日と取り違える。

原因は二つ重なっていた：

  1. Excel の日付は画面に 2023/12/15 と出ていても中身は 1900-01-01 からの
     通算日数（45275）でしかない。openpyxl が datetime に直すのは書式が
     日付と判別できた場合だけで、書式が「標準」のままの列は生の数値で返る。
  2. 生の数値になった「完了日」の隣に、書式の整った「回答日時」がある。
     モデルは意味の分からない数字より、日付に見える方を選ぶ。

つまり日付を壊したうえで、より紛らわしい代替物を並べて置いていた。
"""
from __future__ import annotations

import datetime
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

openpyxl = pytest.importorskip("openpyxl")


# ======================================================================
# 書式判定
# ======================================================================

@pytest.mark.parametrize("fmt", [
    "yyyy/mm/dd", "yyyy-mm-dd", "m/d/yy", "yyyy年m月d日",
    "yyyy/mm/dd hh:mm",
    # 和暦とロケール指定子つき。日本企業の台帳でごく普通に使われる。
    "[$-ja-JP]ge.m.d", '[$-411]yyyy"年"m"月"d"日"', "[$-409]m/d/yy",
])
def test_date_formats_detected(fmt):
    from app.cell_format import is_date_format

    assert is_date_format(fmt) is True


@pytest.mark.parametrize("fmt", [
    "General", "@", "標準", "#,##0", "¥#,##0", "0.00%", "0.00E+00", None, "",
    "[$¥-411]#,##0",     # 通貨記号つきロケール指定子は日付ではない
])
def test_non_date_formats_rejected(fmt):
    """通貨やパーセントを日付と誤認すると、今度は数値を壊す。"""
    from app.cell_format import is_date_format

    assert is_date_format(fmt) is False


# ======================================================================
# シリアル値の変換
# ======================================================================

def test_serial_converts_to_correct_date():
    from app.cell_format import serial_to_datetime

    assert serial_to_datetime(45275).date() == datetime.date(2023, 12, 15)


@pytest.mark.parametrize("serial", [0, -5, 3_000_000, "abc", None])
def test_out_of_range_serial_returns_none(serial):
    from app.cell_format import serial_to_datetime

    assert serial_to_datetime(serial) is None


# ======================================================================
# 文字列化
# ======================================================================

def test_midnight_time_is_dropped():
    """00:00:00 のゼロ並びは情報ではなく雑音。

    他の列（アンケートの回答日時など）との見栄えの差にもなり、
    モデルがそちらへ乗り換える一因になっていた。
    """
    from app.cell_format import cell_to_text

    assert cell_to_text(datetime.datetime(2023, 12, 15)) == "2023-12-15"


def test_real_time_is_kept():
    from app.cell_format import cell_to_text

    assert cell_to_text(datetime.datetime(2024, 1, 20, 14, 30)) == "2024-01-20 14:30"


def test_serial_with_date_format_is_restored():
    from app.cell_format import cell_to_text

    assert cell_to_text(45275, "yyyy/mm/dd") == "2023-12-15"


def test_number_with_currency_format_is_left_alone():
    """同じ 45275 でも、書式が通貨なら金額。日付にしてはいけない。"""
    from app.cell_format import cell_to_text

    assert cell_to_text(45275, "¥#,##0") == "45275"


def test_plain_number_is_not_guessed():
    """書式が「標準」のままの数値は触らない。

    日付かもしれないが金額や個数かもしれない。推測して日付に変えると、
    今度は数値を壊す。壊さない方を選ぶ。
    """
    from app.cell_format import cell_to_text

    assert cell_to_text(45275, "General") == "45275"
    assert cell_to_text(45275, None) == "45275"


def test_float_integers_stay_integers():
    from app.cell_format import cell_to_text

    assert cell_to_text(12.0) == "12"


def test_none_becomes_empty():
    from app.cell_format import cell_to_text

    assert cell_to_text(None) == ""


# ======================================================================
# 両経路で同じ結果になること
# ======================================================================

@pytest.fixture()
def dated_ledger(tmp_path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["管理No", "件名", "完了日", "回答日時", "金額"])
    r = ws.max_row + 1
    ws.cell(r, 1, "2023-0450")
    ws.cell(r, 2, "アルミ外材硬さ試験")
    c = ws.cell(r, 3, 45275)
    c.number_format = "yyyy/mm/dd"
    c = ws.cell(r, 4, datetime.datetime(2024, 1, 20, 14, 30))
    c.number_format = "yyyy/mm/dd hh:mm"
    c = ws.cell(r, 5, 45275)
    c.number_format = "¥#,##0"
    p = tmp_path / "台帳.xlsx"
    wb.save(p)
    return p


def test_ledger_reader_normalizes_dates(dated_ledger):
    from app.reference_index import build_index, clear_cache

    clear_cache()
    values = build_index([str(dated_ledger)]).rows[0].values
    assert values["完了日"] == "2023-12-15"
    assert values["回答日時"] == "2024-01-20 14:30"
    assert values["金額"] == "45275"


def test_body_reader_normalizes_dates_the_same_way(dated_ledger):
    """経路によって同じ列が違う形で出てはいけない。"""
    from app.excel_extract import workbook_to_markdown

    md = workbook_to_markdown(str(dated_ledger)).get("markdown") or ""
    line = next(l for l in md.splitlines() if "2023-0450" in l)
    assert "2023-12-15" in line
    assert "2024-01-20 14:30" in line
    assert "00:00:00" not in line


def test_evidence_shows_readable_dates(dated_ledger):
    """要約の証拠に 45275 のような数値が完了日として載らないこと。"""
    from app.nodes import _reference_to_evidence
    from app.reference_index import build_index, clear_cache

    clear_cache()
    idx = build_index([str(dated_ledger)])
    blob = " ".join(e.content for e in _reference_to_evidence(
        idx.match("アルミ外材硬さ試験.pptx")))
    assert "「完了日」：2023-12-15" in blob
    assert "「完了日」：45275" not in blob


# ======================================================================
# v3.25：列単位の推論（結合台帳で行ごとに保存され方が違う場合）
# ======================================================================
#
# 現場の台帳を調べた結果：1 列 456 件のうち
#   日付型 362 件 / 生のシリアル値 90 件 / その他の数値 4 件
# 複数ファイルを結合した台帳では、値貼り付けや別システムからの取り込みで
# 行ごとに保存され方が変わる。セル単体では 46378 が日付か金額か
# 判断できないが、同じ列に明らかな日付が 362 件あるなら日付と見てよい。

def test_column_with_many_dates_rescues_bare_serials():
    """列内の証拠にもとづく推論。当てずっぽうではない。"""
    import datetime

    from app.cell_format import analyze_column, cell_to_text_in_column

    d = datetime.datetime(2020, 7, 1)
    info = analyze_column([d] * 362 + [46378] * 90,
                          ["mm/dd/yy"] * 362 + ["General"] * 90)
    assert info["is_date_column"] is True
    assert cell_to_text_in_column(46378, "General", info) == "2026-12-22"


def test_amount_column_with_stray_date_formats_is_left_alone():
    """誰かが誤って 2 セルだけ日付書式にした金額列を壊さないこと。

    件数ではなく比率で守っているので、しきい値を下げても安全。
    """
    import datetime

    from app.cell_format import analyze_column, cell_to_text_in_column

    d = datetime.datetime(2020, 7, 1)
    info = analyze_column([d, d] + [45275] * 400,
                          ["mm/dd/yy"] * 2 + ["#,##0"] * 400)
    assert info["is_date_column"] is False
    assert cell_to_text_in_column(45275, "#,##0", info) == "45275"


def test_plain_number_column_never_becomes_dates():
    from app.cell_format import analyze_column

    assert analyze_column([120000, 98000, 55000], ["#,##0"] * 3)["is_date_column"] is False
    assert analyze_column([1, 2, 3, 4, 5], ["General"] * 5)["is_date_column"] is False


# ---- 文字列で入っている日付 ------------------------------------------

def test_us_order_resolved_when_unambiguous():
    """05/28/2020 は 28 > 12 なので月日の順序が確定する。"""
    from app.cell_format import parse_date_string

    assert parse_date_string("05/28/2020 0:00:00").date().isoformat() == "2020-05-28"


def test_ambiguous_order_follows_column_evidence():
    """05/06/2020 は単体では確定しない。列内の傾向に従う。"""
    from app.cell_format import parse_date_string

    assert parse_date_string("05/06/2020", prefer_mdy=True).date().isoformat() == "2020-05-06"
    assert parse_date_string("05/06/2020", prefer_mdy=False).date().isoformat() == "2020-06-05"


def test_column_votes_decide_the_order():
    """順序が確定する行があれば、それを根拠に列全体を同じ順序で読む。"""
    from app.cell_format import analyze_column

    info = analyze_column(["05/28/2020", "06/15/2020", "05/06/2020"], ["General"] * 3)
    assert info["is_date_column"] is True
    assert info["prefer_mdy"] is True


def test_iso_style_strings_also_normalized():
    from app.cell_format import analyze_column, cell_to_text_in_column

    info = analyze_column(["2020/08/03", "2020/09/01", "2020/10/05"], ["General"] * 3)
    assert cell_to_text_in_column("2020/08/03", "General", info) == "2020-08-03"


def test_non_date_strings_untouched():
    from app.cell_format import analyze_column, cell_to_text_in_column

    info = analyze_column(["2020/08/03"] * 3, ["General"] * 3)
    assert cell_to_text_in_column("アルミ外材硬さ試験", "General", info) == "アルミ外材硬さ試験"


# ---- 実際の読み取り経路で効くこと ------------------------------------

def test_mixed_ledger_column_normalized_end_to_end(tmp_path):
    import datetime

    from app.reference_index import build_index, clear_cache

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["依頼番号", "依頼日", "完了日", "金額", "件名"])
    rows = [
        (2001, "05/28/2020 0:00:00", datetime.datetime(2020, 7, 1), 120000, "包材の輸送試験"),
        (2002, "06/15/2020 0:00:00", 46378, 98000, "アルミ外材硬さ試験"),
        (2003, "2020/08/03", 44105, 55000, "膜厚測定"),
        (2004, datetime.datetime(2020, 9, 1), datetime.datetime(2020, 11, 2), 77000, "振動評価"),
    ]
    for i, (a, b, c, d, e) in enumerate(rows, start=2):
        ws.cell(i, 1, a)
        ws.cell(i, 2, b)
        cc = ws.cell(i, 3, c)
        if isinstance(c, datetime.datetime):
            cc.number_format = "mm/dd/yy"
        dd = ws.cell(i, 4, d)
        dd.number_format = "#,##0"
        ws.cell(i, 5, e)
    p = tmp_path / "結合台帳.xlsx"
    wb.save(p)

    clear_cache()
    idx = build_index([str(p)])
    sheet = idx.stats()["sources"][0]["sheets"][0]
    assert set(sheet["date_columns"]) == {"依頼日", "完了日"}

    by_no = {r.values["依頼番号"]: r.values for r in idx.rows}
    assert by_no["2002"]["完了日"] == "2026-12-22"   # 生のシリアル値から復元
    assert by_no["2002"]["依頼日"] == "2020-06-15"   # 米国式文字列から復元
    assert by_no["2002"]["金額"] == "98000"          # 金額は触らない
