"""図版差し込み → PDF / Word / PPTX の通し検証（v3.27）。

Block IR に image を足したので、3 経路すべてが実際に画像を埋め込めることを
確認する。「md には出るが PDF には出ない」が一番気付きにくい壊れ方なので、
生成物のバイト列まで見に行く。
"""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.export_doc import (DocSection, parse_markdown, resolve_image,  # noqa: E402
                            section_from_run_dir)
from app.figure_select import DEFAULTS, attach_figures_to_run  # noqa: E402

MD = """# 配管流路の圧損改善

## 調査・対応により判明した事実 (Findings & Discovered Facts)

- 流路変更後の圧力損失は 12.5 kPa まで低下し、目標の 15 kPa を下回った
- 分岐部の渦は形状変更により概ね解消した

## 対応効果・メリット (Effects & Quantified Merits)

- ポンプ動力を 18.4 % 削減できる見込みとなった

## 根拠情報

- 圧力損失 12.5 kPa（p.3）
"""


def _png(path: Path, size, color):
    from PIL import Image
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", size, color).save(path)
    return path


@pytest.fixture()
def run_dir(tmp_path: Path) -> Path:
    import json
    rd = tmp_path / "圧損改善_20260910_120000"
    rd.mkdir(parents=True)
    (rd / "case_summary.md").write_text(MD, encoding="utf-8")
    (rd / "manifest.json").write_text(
        json.dumps({"input_path": "/inbox/圧損改善報告.pptx"}, ensure_ascii=False),
        encoding="utf-8")

    _png(rd / "visual_pdf" / "pdf_p003_img01.png", (1200, 800), (232, 240, 236))
    _png(rd / "visual_pdf" / "pdf_p005_img03.png", (900, 1400), (240, 232, 232))
    _png(rd / "visual_pdf" / "pdf_p009_img07.png", (700, 500), (235, 235, 240))

    ve = [
        {"evidence_id": "V1", "image_path": str(rd / "visual_pdf" / "pdf_p003_img01.png"),
         "page": 3, "asset_kind": "embedded", "visual_type": "chart",
         "visual_summary": "流路変更前後の圧力損失比較グラフ",
         "key_facts": ["変更後の圧力損失 12.5 kPa", "目標 15 kPa を下回る"],
         "readable_text": ["圧力損失 [kPa]", "変更前 21.3", "変更後 12.5"],
         "confidence": 0.86, "has_useful_visual_info": True, "possible_relevance": []},
        {"evidence_id": "V2", "image_path": str(rd / "visual_pdf" / "pdf_p005_img03.png"),
         "page": 5, "asset_kind": "embedded", "visual_type": "diagram",
         "visual_summary": "ポンプ動力の内訳",
         "key_facts": ["動力削減 18.4 %"],
         "readable_text": ["動力 [kW]", "削減率 18.4 %"],
         "confidence": 0.78, "has_useful_visual_info": True, "possible_relevance": []},
        {"evidence_id": "V3", "image_path": str(rd / "visual_pdf" / "pdf_p009_img07.png"),
         "page": 9, "asset_kind": "embedded", "visual_type": "photo",
         "visual_summary": "組立現場の写真",
         "key_facts": ["作業風景"], "readable_text": ["安全第一"],
         "confidence": 0.5, "has_useful_visual_info": True, "possible_relevance": []},
    ]
    (rd / "evidence_visual.json").write_text(
        json.dumps({"evidence": ve}, ensure_ascii=False), encoding="utf-8")
    (rd / "evidence_text.json").write_text(
        json.dumps({"evidence": [
            {"evidence_id": "E1", "content": "流路変更後の圧力損失は 12.5 kPa", "page": 3},
            {"evidence_id": "E2", "content": "ポンプ動力を 18.4 % 削減", "page": 5},
        ]}, ensure_ascii=False), encoding="utf-8")
    return rd


def test_pipeline_picks_two_and_skips_the_photo(run_dir: Path):
    res = attach_figures_to_run(run_dir, cfg=DEFAULTS, tier="internal")
    assert res["ok"] and res["figures"] == 2
    picked = {p["evidence_id"] for p in res["report"]["picked"]}
    assert picked == {"V1", "V2"}          # 無関係な現場写真は入らない

    md = (run_dir / "case_summary.md").read_text(encoding="utf-8")
    assert "（図1）" in md and "（図2）" in md
    assert (run_dir / "figures" / "fig01.png").exists()
    assert (run_dir / "figures" / "fig02.png").exists()


def test_blocks_carry_images(run_dir: Path):
    attach_figures_to_run(run_dir, cfg=DEFAULTS, tier="internal")
    sec = section_from_run_dir(run_dir)
    assert sec is not None and sec.base_dir == str(run_dir)
    imgs = [b for b in parse_markdown(sec.markdown) if b.kind == "image"]
    assert len(imgs) == 2
    for b in imgs:
        assert b.text.startswith("図")                 # キャプション
        assert resolve_image(b.path, sec.base_dir) is not None


def test_pdf_embeds_the_images(run_dir: Path, tmp_path: Path):
    from app.export_doc import export_pdf
    attach_figures_to_run(run_dir, cfg=DEFAULTS, tier="internal")
    sec = section_from_run_dir(run_dir)
    out = export_pdf([sec], tmp_path / "r.pdf", doc_title="要約レポート")
    data = out.read_bytes()
    assert out.stat().st_size > 20_000                # 画像なしなら遥かに小さい
    assert data.count(b"/Subtype /Image") >= 2 or data.count(b"/Image") >= 2


def test_docx_embeds_the_images(run_dir: Path, tmp_path: Path):
    from app.export_doc import export_docx
    attach_figures_to_run(run_dir, cfg=DEFAULTS, tier="internal")
    sec = section_from_run_dir(run_dir)
    out = export_docx([sec], tmp_path / "r.docx")
    with zipfile.ZipFile(out) as z:
        media = [n for n in z.namelist() if n.startswith("word/media/")]
    assert len(media) == 2


def test_pptx_makes_figure_slides(run_dir: Path, tmp_path: Path):
    from pptx import Presentation

    from app.export_pptx import export_pptx
    attach_figures_to_run(run_dir, cfg=DEFAULTS, tier="internal")
    sec = section_from_run_dir(run_dir)
    out = export_pptx([sec], tmp_path / "r.pptx")
    with zipfile.ZipFile(out) as z:
        assert len([n for n in z.namelist() if n.startswith("ppt/media/")]) == 2

    prs = Presentation(str(out))
    pics = [sh for s in prs.slides for sh in s.shapes if sh.shape_type == 13]
    assert len(pics) == 2
    # 図は枠内に収まっていること（縦長画像がスライドを飛び出さない）
    for p in pics:
        assert p.left >= 0 and p.top >= 0
        assert p.left + p.width <= prs.slide_width
        assert p.top + p.height <= prs.slide_height


def test_missing_image_does_not_break_export(run_dir: Path, tmp_path: Path):
    """図版ファイルが消えていても本文は出る（付加価値で本流を壊さない）。"""
    from app.export_doc import export_docx, export_pdf
    attach_figures_to_run(run_dir, cfg=DEFAULTS, tier="internal")
    for f in (run_dir / "figures").glob("*"):
        f.unlink()
    sec = section_from_run_dir(run_dir)
    assert export_pdf([sec], tmp_path / "r.pdf").exists()
    out = export_docx([sec], tmp_path / "r.docx")
    with zipfile.ZipFile(out) as z:
        assert not [n for n in z.namelist() if n.startswith("word/media/")]


def test_batch_export_resolves_each_run_base_dir(run_dir: Path, tmp_path: Path):
    """一括エクスポート：run ごとに base_dir が違っても画像を引けること。"""
    import shutil

    from app.export_doc import export_docx
    attach_figures_to_run(run_dir, cfg=DEFAULTS, tier="internal")

    other = tmp_path / "別案件_20260910_130000"
    shutil.copytree(run_dir, other)
    # python-docx は同一バイト列の画像を 1 つに畳む。中身を変えておかないと
    # 「2 件目の画像が引けていない」不具合を重複排除が隠してしまう。
    for i, f in enumerate(sorted((other / "figures").glob("*"))):
        _png(f, (600, 400), (10 + i, 90, 160))

    secs = [section_from_run_dir(run_dir), section_from_run_dir(other)]
    assert secs[0].base_dir != secs[1].base_dir
    out = export_docx(secs, tmp_path / "batch.docx", doc_title="一括")
    with zipfile.ZipFile(out) as z:
        media = [n for n in z.namelist() if n.startswith("word/media/")]
        doc_xml = z.read("word/document.xml").decode("utf-8")
    assert len(media) == 4        # 2 run x 2 枚。base_dir が効いていないと 0 か 2
    assert doc_xml.count("<w:drawing>") == 4
