"""v3.3 新特性测试：社外脱敏 / 案件台账 / 监视文件夹 / RAG 出口 / 批量上传。"""
import json
import sys
import time
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.ledger import Ledger, rebuild_from_disk
from app.rag_export import build_records
from app.redaction import NGDictionary, apply_rules, redact_summary, scan_leaks

DICT_YAML = {
    "categories": {
        "client_names": {"replacement_template": "{alias}社",
                         "terms": ["日之出精機株式会社", "青空エレクトロニクス"]},
        "internal_codes": {"replacement": "（開発コード非開示）", "terms": ["PJ-HAYABUSA"]},
    },
    "patterns": {
        "amounts": {"regex": r"[0-9０-９][0-9０-９,，.]*\s*(?:億|万|千)?\s*円",
                    "replacement": "（金額非開示）"},
    },
}

SUMMARY = {
    "case_name": "日之出精機株式会社 解析支援",
    "request_details": {
        "main_title": "", "requester": "日之出精機株式会社 設計部",
        "target_product_or_system": "PJ-HAYABUSA 用冷却ユニット",
        "background": ["青空エレクトロニクス経由で紹介", "予算は1,200万円規模"],
        "client_issues": ["熱設計リソース不足"], "scope_of_request": ["熱流体解析の代行"],
    },
    "action_results": {
        "main_title": "", "support_type": "解析代行", "tools_environment": ["FloEFD"],
        "period": "2026年1月〜3月", "findings": ["日之出精機株式会社の設計に偏流"],
        "effects": ["工数30%削減"],
    },
    "evidence": ["ev1"],
}


# ----------------------------------------------------------------------
# 1. 脱敏：规则层
# ----------------------------------------------------------------------

def test_rules_consistent_alias_and_patterns():
    d = NGDictionary.model_validate(DICT_YAML)
    out, rep = apply_rules(SUMMARY, d)
    text = json.dumps(out, ensure_ascii=False)
    # 原词全部消失
    assert "日之出精機" not in text and "青空エレクトロニクス" not in text
    assert "PJ-HAYABUSA" not in text and "1,200万円" not in text
    # 同一客户全文映射到同一别名（case_name / requester / findings 三处）
    alias = rep["alias_map"]["日之出精機株式会社"]
    assert out["case_name"].startswith(alias)
    assert out["request_details"]["requester"].startswith(alias)
    assert alias in out["action_results"]["findings"][0]
    # 两家客户拿到不同别名
    assert rep["alias_map"]["青空エレクトロニクス"] != alias
    # 金额与代号
    assert "（金額非開示）" in text and "（開発コード非開示）" in text
    # 非敏感内容原样保留
    assert "工数30%削減" in text and "FloEFD" in text


def test_scan_leaks_detects_residual():
    d = NGDictionary.model_validate(DICT_YAML)
    assert scan_leaks(SUMMARY, d)          # 原文有泄漏
    out, _ = apply_rules(SUMMARY, d)
    assert scan_leaks(out, d) == []        # 规则层后干净


# ----------------------------------------------------------------------
# 2. 脱敏：LLM 层的安全闸（幻觉复述 -> 自动回退规则版）
# ----------------------------------------------------------------------

class LeakyLLM:
    """模拟会把原公司名"复述回来"的失控改写。"""
    def chat_json(self, system, user, **kw):
        obj = json.loads(user)
        obj["request_details"]["requester"] = "日之出精機株式会社 設計部"  # 泄漏！
        return obj


class GoodLLM:
    def chat_json(self, system, user, **kw):
        obj = json.loads(user)
        obj["request_details"]["background"] = ["大手精密機器メーカー経由で紹介",
                                                obj["request_details"]["background"][1]]
        return obj


def test_llm_leak_triggers_fallback():
    d = NGDictionary.model_validate(DICT_YAML)
    external, report = redact_summary(SUMMARY, d, llm=LeakyLLM(), llm_rewrite=True)
    assert report["llm_rewrite"]["applied"] is False
    assert "重现" in (report["llm_rewrite"]["fallback_reason"] or "")
    # 最终输出仍然干净（回退 + 终扫双保险）
    assert report["leaks_after_all"] == []
    assert "日之出精機" not in json.dumps(external.model_dump(mode="json"), ensure_ascii=False)


def test_llm_clean_rewrite_applied():
    d = NGDictionary.model_validate(DICT_YAML)
    external, report = redact_summary(SUMMARY, d, llm=GoodLLM(), llm_rewrite=True)
    assert report["llm_rewrite"]["applied"] is True
    assert report["leaks_after_all"] == []


def test_redaction_disabled_llm_none():
    d = NGDictionary.model_validate(DICT_YAML)
    external, report = redact_summary(SUMMARY, d, llm=None, llm_rewrite=False)
    assert report["llm_rewrite"]["enabled"] is False
    assert report["leaks_after_all"] == []


# ----------------------------------------------------------------------
# 3. 台账
# ----------------------------------------------------------------------

def _rec(run_id, case, requester="設計部", state="done"):
    return {"run_id": run_id, "input_name": f"{run_id}.pdf", "case_name": case,
            "requester": requester, "target": "装置", "support_type": "解析",
            "period": "2026", "effects": "工数削減", "state": state,
            "warnings": "", "has_external": 1, "run_dir": f"/tmp/{run_id}"}


def test_ledger_upsert_search_export(tmp_path):
    lg = Ledger(tmp_path / "ledger.sqlite3")
    lg.upsert(_rec("r1", "冷却ユニット解析"))
    lg.upsert(_rec("r2", "光学系評価", requester="光学部"))
    lg.upsert(_rec("r1", "冷却ユニット解析（改）"))  # 同 run 更新，不重复

    rows, total = lg.search()
    assert total == 2
    rows, total = lg.search(query="光学")
    assert total == 1 and rows[0]["run_id"] == "r2"
    rows, total = lg.search(query="冷却")
    assert rows[0]["case_name"].endswith("（改）")

    xlsx = lg.export_xlsx(tmp_path / "台帳.xlsx")
    from openpyxl import load_workbook
    ws = load_workbook(xlsx).active
    assert ws.max_row == 3 and ws.cell(1, 3).value == "案件名"


def test_ledger_rebuild_from_disk(tmp_path):
    run_dir = tmp_path / "runs" / "case_abc123"
    run_dir.mkdir(parents=True)
    (run_dir / "case_summary.json").write_text(json.dumps(SUMMARY, ensure_ascii=False),
                                               encoding="utf-8")
    (run_dir / "manifest.json").write_text(json.dumps({"input_path": "/x/case.pdf"}),
                                           encoding="utf-8")
    lg = Ledger(tmp_path / "new.sqlite3")   # 全新 DB（模拟 DB 丢失）
    n = rebuild_from_disk(lg, tmp_path / "runs")
    assert n == 1
    rows, total = lg.search(query="日之出")
    assert total == 1 and rows[0]["input_name"] == "case.pdf"


# ----------------------------------------------------------------------
# 4. E2E：完整流水线产出两级输出 + RAG 文件
# ----------------------------------------------------------------------

DOC = ("# 日之出精機株式会社 解析支援\n日之出精機株式会社より冷却ユニットの熱流体解析代行の依頼。"
       "背景は熱設計リソース不足で、予算は1,200万円規模。使用ツールは FloEFD。"
       "期間は2026年1月〜3月。効果は工数30%削減。")


def _mock(system, user):
    if "文書整理エージェント" in system:
        return {"evidence": [
            {"category": "requester", "content": "日之出精機株式会社 設計部", "confidence": 0.9},
            {"category": "target", "content": "冷却ユニット", "confidence": 0.9},
            {"category": "issue", "content": "熱設計リソース不足", "confidence": 0.9},
            {"category": "request_scope", "content": "熱流体解析の代行", "confidence": 0.9},
            {"category": "tool", "content": "FloEFD", "confidence": 0.9},
            {"category": "period", "content": "2026年1月〜3月", "confidence": 0.9},
            {"category": "finding", "content": "偏流を確認", "confidence": 0.9},
            {"category": "effect", "content": "工数30%削減", "confidence": 0.9}]}
    if "視覚" in system:
        return {"has_useful_visual_info": False, "visual_type": "unknown", "readable_text": [],
                "visual_summary": "", "key_facts": [], "possible_relevance": [], "confidence": 0}
    if "匿名化エージェント" in system:
        return json.loads(user)
    return SUMMARY


@pytest.fixture()
def e2e_run(tmp_path):
    from app.config import AppConfig
    from app.graph import run_workflow
    from app.llm_client import LocalLLMClient
    import shutil

    doc = tmp_path / "hinode_case.md"
    doc.write_text(DOC, encoding="utf-8")
    config = AppConfig()
    config.paths.out_dir = str(tmp_path / "out")
    config.llm.mock = True
    # 词典指到临时文件
    import yaml
    dict_path = tmp_path / "ng.yaml"
    dict_path.write_text(yaml.safe_dump(DICT_YAML, allow_unicode=True), encoding="utf-8")
    config.redaction.dictionary_path = str(dict_path)
    llm = LocalLLMClient(base_url="", api_key="", mock=True, mock_handler=_mock)
    final = run_workflow(str(doc), config, llm)
    return final, config


def test_e2e_two_tier_outputs(e2e_run):
    final, _ = e2e_run
    run_dir = Path(final["run_dir"])
    internal = (run_dir / "case_summary.md").read_text(encoding="utf-8")
    external = (run_dir / "case_summary_external.md").read_text(encoding="utf-8")
    assert "日之出精機株式会社" in internal          # 社内版保留全信息
    assert "日之出精機" not in external              # 社外版彻底脱敏
    assert "工数30%削減" in external                 # 非敏感事实保留
    report = json.loads((run_dir / "redaction_report.json").read_text(encoding="utf-8"))
    assert report["leaks_after_all"] == []


def test_e2e_rag_files_and_tiers(e2e_run):
    final, _ = e2e_run
    run_dir = Path(final["run_dir"])
    internal = [json.loads(l) for l in
                (run_dir / "rag_internal.jsonl").read_text(encoding="utf-8").strip().split("\n")]
    external = [json.loads(l) for l in
                (run_dir / "rag_external.jsonl").read_text(encoding="utf-8").strip().split("\n")]
    types_int = {r["metadata"]["type"] for r in internal}
    assert "summary_section" in types_int and "text_evidence" in types_int
    # 社外包只含脱敏摘要，绝不携带原文证据
    assert {r["metadata"]["type"] for r in external} == {"summary_section"}
    assert all("日之出精機" not in r["text"] for r in external)
    assert all(r["metadata"]["tier"] == "external" for r in external)
    # build_records API 与落盘一致
    assert len(build_records(run_dir, "internal")) == len(internal)


# ----------------------------------------------------------------------
# 5. Web：批量上传 / 台账端点 / 词典校验 / 监视文件夹
# ----------------------------------------------------------------------

@pytest.fixture()
def web_client(tmp_path, monkeypatch):
    import app.webapp as W
    from fastapi.testclient import TestClient
    monkeypatch.setattr(W.config.llm, "mock", True)
    monkeypatch.setattr(W.config.paths, "out_dir", str(tmp_path / "out"))
    monkeypatch.setattr(W.config.paths, "inbox_dir", str(tmp_path / "inbox"))
    monkeypatch.setattr(W.config.redaction, "dictionary_path", str(tmp_path / "ng.yaml"))
    import yaml
    (tmp_path / "ng.yaml").write_text(yaml.safe_dump(DICT_YAML, allow_unicode=True),
                                      encoding="utf-8")
    monkeypatch.setattr(W, "_ledger", Ledger(tmp_path / "ledger.sqlite3"))
    W._runs.clear()
    return TestClient(W.app)


def _wait(client, run_id):
    for _ in range(80):
        st = client.get(f"/api/runs/{run_id}").json()["state"]
        if st in ("done", "failed"):
            return st
        time.sleep(0.25)
    return "timeout"


def test_batch_upload_creates_multiple_runs(web_client):
    files = [("files", (f"doc{i}.md", DOC.encode(), "text/markdown")) for i in range(3)]
    r = web_client.post("/api/runs", files=files)
    ids = r.json()["run_ids"]
    assert len(ids) == 3
    assert all(_wait(web_client, rid) == "done" for rid in ids)


def test_ledger_endpoint_and_excel(web_client):
    r = web_client.post("/api/runs", files=[("files", ("ledger_case.md", DOC.encode(),
                                                       "text/markdown"))])
    rid = r.json()["run_id"]
    assert _wait(web_client, rid) == "done"
    body = web_client.get("/api/ledger?query=モック").json()  # 默认 mock 的案件名
    assert body["total"] >= 1
    assert any(row["has_external"] for row in body["rows"])
    x = web_client.get("/api/ledger/export.xlsx")
    assert x.status_code == 200 and len(x.content) > 1000


def test_dictionary_validation_gate(web_client):
    ok = web_client.put("/api/redaction/dictionary",
                        json={"yaml": "categories:\n  x:\n    terms: [\"A\"]\n"})
    assert ok.status_code == 200
    bad = web_client.put("/api/redaction/dictionary",
                         json={"yaml": "categories:\n  x:\n    terms: 123\n"})
    assert bad.status_code == 422


def test_watch_folder_scan(web_client, tmp_path, monkeypatch):
    import app.webapp as W
    monkeypatch.setattr(W.config.watch_folder, "path", str(tmp_path / "watch"))
    watch = tmp_path / "watch"
    watch.mkdir(exist_ok=True)
    (watch / "auto_case.md").write_text(DOC, encoding="utf-8")

    assert W._watch_scan_once() == []          # 第一轮：记录大小，不处理（防半截文件）
    launched = W._watch_scan_once()            # 第二轮：大小稳定，入队
    assert len(launched) == 1
    assert not (watch / "auto_case.md").exists()  # 已移出监视目录
    assert _wait(web_client, launched[0]) == "done"


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
