"""v3.27.4：対応効果に「コスト削減」「期間短縮」を出すための下ごしらえ。

方針：**計算できるものはコードが保証し、できないものだけモデルに回す。**
常にモデルへ投げると、確実に出せた答えまで確率的になる。
意味付け（どの差が所要期間か）はモデルの仕事なので、コードは
生の表頭のまま差だけ並べる（v3.15 の「列の意味を表で決めない」を維持）。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.nodes import _looks_like_vague_date, _reference_date_evidence  # noqa: E402
from app.reference_index import ReferenceRow  # noqa: E402


def _row(cells):
    return ReferenceRow(source_file="台帳.xlsx", sheet_name="依頼一覧",
                        row_number=12, cells=list(cells))


def _contents(evs):
    return "\n".join(e.content for e in evs)


# ---- 計算できる日付 ----

def test_day_difference_is_computed_in_code():
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("希望納期", "2023/06/30"),
              ("完了日", "2023/06/02"), ("依頼部門", "製造技術部")]),
        conf=0.8, src="台帳.xlsx#依頼一覧:12", tag="")
    text = _contents(evs)
    assert "「依頼日」から「完了日」まで 53 日" in text
    assert "「完了日」から「希望納期」まで 28 日" in text
    assert "2023-04-10" in text            # 正規化した日付も並べる
    assert "製造技術部" not in text        # 日付でない列は触らない


def test_pair_is_ordered_earliest_first():
    """列の並び順ではなく時系列で「から/まで」を決める。"""
    evs = _reference_date_evidence(
        _row([("完了日", "2023/06/02"), ("依頼日", "2023/04/10")]),
        conf=0.8, src="s", tag="")
    assert "「依頼日」から「完了日」まで 53 日" in _contents(evs)


def test_months_are_included_for_readability():
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/01/10"), ("完了日", "2023/06/02")]),
        conf=0.8, src="s", tag="")
    assert "ヶ月" in _contents(evs)


def test_far_apart_dates_are_not_paired():
    """保管期限のような無関係な日付と組ませない。"""
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("完了日", "2023/06/02"),
              ("保管期限", "2043/04/10")]),
        conf=0.8, src="s", tag="")
    text = _contents(evs)
    assert "「依頼日」から「完了日」まで 53 日" in text
    assert "保管期限」まで" not in text


def test_single_date_produces_nothing():
    assert _reference_date_evidence(_row([("依頼日", "2023/04/10")]), 0.8, "s", "") == []


def test_no_dates_produces_nothing():
    assert _reference_date_evidence(_row([("依頼部門", "製造技術部")]), 0.8, "s", "") == []


# ---- 計算できない日付はモデルに回す ----

def test_vague_dates_are_flagged_not_dropped():
    """曖昧な記述を黙って落とすと、モデルは「日付の記載が無い」と読んで
    期間に触れなくなる。計算不可であることを明示的に伝える。"""
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("完了日", "2023/06/02"),
              ("希望納期", "6月末までに")]),
        conf=0.8, src="s", tag="")
    text = _contents(evs)
    assert "日付が曖昧で計算不可" in text and "希望納期" in text
    assert "概算" in text
    # 解析できた 2 つは通常どおり計算される
    assert "53 日" in text


def test_all_vague_still_reports():
    evs = _reference_date_evidence(
        _row([("依頼日", "来月中旬"), ("完了日", "6月末")]), 0.8, "s", "")
    text = _contents(evs)
    assert "日付が曖昧で計算不可" in text
    assert "日数計算" not in text          # 計算できないものを計算したふりをしない


def test_vague_detector_scope():
    for s in ("6月末", "来月中旬", "Q2中", "至急", "未定", "8月上旬頃"):
        assert _looks_like_vague_date(s), s
    for s in ("2023/06/02", "製造技術部", "", "A" * 60):
        assert not _looks_like_vague_date(s), s


def test_pair_count_is_capped():
    """日付列が多い台帳で証拠パックを食い潰さない。"""
    cells = [(f"日付{i}", f"2023/01/{i + 1:02d}") for i in range(12)]
    evs = _reference_date_evidence(_row(cells), 0.8, "s", "")
    diffs = [e for e in evs if "日数計算" in e.content]
    assert len(diffs) <= 10


def test_unconfirmed_tag_is_carried():
    evs = _reference_date_evidence(
        _row([("依頼日", "2023/04/10"), ("完了日", "2023/06/02")]),
        0.8, "s", "【要確認】")
    assert all(e.content.startswith("【要確認】") for e in evs)


# ---- プロンプト側 ----

def test_prompt_states_the_two_effects_and_bans_recomputation():
    src = (Path(__file__).resolve().parents[1] / "app" / "nodes.py").read_text(encoding="utf-8")
    assert "コスト・工数の削減" in src
    assert "期間短縮による便益" in src
    # 計算済みの値を モデルが引き直すと、保証していたはずの数字が崩れる
    assert "計算し直さない" in src
    assert "作り出すことは固く禁じる" in src


# ---- v3.27.7：period と effects の書き分け ----

def test_prompt_separates_period_from_effects():
    """実測：モデルは「依頼から完了まで 28 日。希望納期より 22 日早く完了した」を
    まるごと period に入れ、effects を空にした。プロンプトの例文が
    その並びのままだったのが誘因なので、配置を明示する。"""
    src = (Path(__file__).resolve().parents[1] / "app" / "nodes.py").read_text(encoding="utf-8")
    assert "period と effects の書き分け" in src
    assert "period に書いたことを理由に effects を省略しないでください" in src
    # 悪い例を悪い例として示していること（良い例のつもりで並べない）
    bat = src.index("してはいけない書き方")
    good = src.index("正しい配置")
    assert bat < good


def test_notice_when_effects_omit_the_period():
    from types import SimpleNamespace

    from app.nodes import _effects_missing_period
    ev = [{"content": "参照台帳（日数計算・コードによる確定値）：「依頼日」から「完了日」まで 28 日"}]
    s = SimpleNamespace(action_results=SimpleNamespace(
        effects=["満足度は 5 段階中 5 と非常に高い"]))
    assert "期間短縮の項目がありません" in _effects_missing_period(s, ev)


def test_no_notice_when_effects_mention_the_period():
    from types import SimpleNamespace

    from app.nodes import _effects_missing_period
    ev = [{"content": "参照台帳（日数計算・コードによる確定値）：28 日"}]
    for text in ("希望納期より 22 日早く完了した", "期間を短縮できた",
                 "納期に対し前倒しで完了"):
        s = SimpleNamespace(action_results=SimpleNamespace(effects=[text]))
        assert _effects_missing_period(s, ev) is None, text


def test_no_notice_without_date_evidence():
    """日数の証拠が無ければ、effects に期間が無いのは当たり前。騒がない。"""
    from types import SimpleNamespace

    from app.nodes import _effects_missing_period
    s = SimpleNamespace(action_results=SimpleNamespace(effects=["満足度 5"]))
    assert _effects_missing_period(s, [{"content": "参照台帳「依頼部門」：製造技術部"}]) is None


def test_notice_does_not_rewrite_the_summary():
    """報せるだけで直さない。機械が本文を書き換えると出所が分からなくなる。"""
    from types import SimpleNamespace

    from app.nodes import _effects_missing_period
    effects = ["満足度は 5"]
    s = SimpleNamespace(action_results=SimpleNamespace(effects=effects))
    _effects_missing_period(s, [{"content": "日数計算：28 日"}])
    assert effects == ["満足度は 5"]


# ---- v3.27.8：effects の観点と言い回しの多様性 ----

def _prompt() -> str:
    return (Path(__file__).resolve().parents[1] / "app" / "nodes.py").read_text(encoding="utf-8")


def test_effects_covers_four_viewpoints():
    src = _prompt()
    for heading in ("コスト・工数の削減", "期間短縮による便益",
                    "依頼者からの評価・アンケート結果", "技術的に達成した成果"):
        assert heading in src, heading


def test_each_viewpoint_has_several_examples():
    """1 観点 1 例だと、その 1 文がそのまま量産される。"""
    src = _prompt()
    block = src[src.index("コスト・工数の削減"):src.index("書き方の共通ルール")]
    parts = [p for p in block.split("---- (") if p.count("・") >= 1]
    assert len(parts) == 4, f"観点が 4 つでない: {len(parts)}"
    for part in parts:
        n = len([ln for ln in part.split("\n") if ln.strip().startswith("・")])
        assert n >= 3, f"例文が少ない({n}): {part[:40]}"


def test_prompt_warns_against_monotony():
    """164 件を並べて読むので、同じ語尾の反復は内容を見えなくする。"""
    src = _prompt()
    assert "同じ言い回しを繰り返さない" in src
    assert "型」であって穴埋め用の雛形ではない" in src


def test_negative_feedback_is_not_filtered_out():
    """低い評価を省くと、効果欄が宣伝文になる。"""
    assert "低い評価や指摘事項も、証拠にあれば省かずに書く" in _prompt()


# ---- 例文の数値が答えとして漏れていないか ----

def test_example_figure_leak_is_detected():
    """VISION_SYSTEM の "confidence": 0.0 と同じ事故。ルールで禁じるだけでは
    足りないので、出力側でも見張る。"""
    from types import SimpleNamespace

    from app.nodes import _example_number_leak
    s = SimpleNamespace(action_results=SimpleNamespace(
        effects=["試作費を約 120 万円圧縮できた"]))
    msg = _example_number_leak(s, [{"content": "参照台帳「依頼部門」：製造技術部"}])
    assert msg and "120万円" in msg


def test_same_figure_is_fine_when_evidence_has_it():
    from types import SimpleNamespace

    from app.nodes import _example_number_leak
    s = SimpleNamespace(action_results=SimpleNamespace(
        effects=["試作費を約 120 万円圧縮できた"]))
    ev = [{"content": "参照台帳「コスト削減見込」：約120万円"}]
    assert _example_number_leak(s, ev) is None


def test_leak_detector_tokens_exist_in_the_prompt():
    """例文を書き換えたのに検出語を直し忘れると、番人が何も見張らなくなる。"""
    from app.nodes import _PROMPT_EXAMPLE_FIGURES
    src = _prompt()
    block = src[src.index("コスト・工数の削減"):src.index("書き方の共通ルール")]
    assert any(tok in block for tok in _PROMPT_EXAMPLE_FIGURES)


def test_leak_detector_ignores_empty_effects():
    from types import SimpleNamespace

    from app.nodes import _example_number_leak
    s = SimpleNamespace(action_results=SimpleNamespace(effects=[]))
    assert _example_number_leak(s, []) is None
