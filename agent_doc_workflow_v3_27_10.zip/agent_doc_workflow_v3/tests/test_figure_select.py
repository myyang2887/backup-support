"""figure_select の検証（v3.27）。

ここで守りたいのは「挿さること」ではなく **「間違って挿さらないこと」**。
- 曖昧なとき（2 位と僅差）に不採用になるか
- 格子合成・全面レンダ・装飾画像が候補から外れるか
- 降采样版ではなく元解像度が掲載されるか
- 社外版に既定で入らないか
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.figure_select import (DEFAULTS, attach_figures_to_run, build_candidates,
                               char_ngrams, find_anchors, inject_figures,
                               numeric_tokens, select_figures)

MD = """# テスト案件

## 調査・対応により判明した事実 (Findings & Discovered Facts)

- 流路変更後の圧力損失は 12.5 kPa まで低下し、目標値を下回った
- 外材コート層の硬さは母材比で 1.8 倍となった

## 根拠情報

- 圧力損失 12.5 kPa（p.3 のグラフ）
"""


def _ve(eid, path, page, summary, facts, read, conf=0.8, kind="embedded",
        vtype="chart", useful=True):
    return {"evidence_id": eid, "image_path": path, "page": page,
            "asset_kind": kind, "visual_type": vtype, "visual_summary": summary,
            "key_facts": facts, "readable_text": read, "confidence": conf,
            "has_useful_visual_info": useful, "possible_relevance": []}


def _make_png(path: Path, size=(800, 600), color=(200, 220, 210)) -> Path:
    from PIL import Image
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", size, color).save(path)
    return path


def _run_dir(tmp: Path) -> Path:
    rd = tmp / "run1"
    (rd / "visual_pdf").mkdir(parents=True, exist_ok=True)
    _make_png(rd / "visual_pdf" / "pdf_p003_img01.png")
    _make_png(rd / "visual_pdf" / "pdf_p007_img02.png")
    (rd / "case_summary.md").write_text(MD, encoding="utf-8")
    return rd


# ----------------------------------------------------------------------

def test_numeric_tokens_weighting():
    n = numeric_tokens("圧力損失は 12.5 kPa、試験は 3 回、2024 年実施")
    assert n["12.5"] == 1.0          # 小数付き = 強い
    assert n["3"] == 0.25            # 1 桁整数 = 弱い
    assert n["2024"] == 0.25         # 年号 = 弱い
    assert numeric_tokens("1,200 件")["1200"] == 1.0   # 桁区切りを正規化


def test_ngrams_are_nfkc_normalized():
    assert char_ngrams("１２．５ｋＰａ") & char_ngrams("12.5kpa")


def test_anchors_respect_sections():
    _, anchors = find_anchors(MD, DEFAULTS)
    assert len(anchors) == 2                       # 根拠情報の項目は対象外
    assert all("根拠情報" not in a.heading for a in anchors)


def test_placeholder_bullets_are_not_anchors():
    md = "## 対応効果 (Effects)\n\n- 資料内で確認できず\n"
    _, anchors = find_anchors(md, DEFAULTS)
    assert anchors == []


def test_numeric_match_wins(tmp_path):
    rd = _run_dir(tmp_path)
    ve = [
        _ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3,
            "圧力損失の推移グラフ", ["圧力損失 12.5 kPa まで低下"], ["12.5", "kPa", "圧力損失"]),
        _ve("V2", str(rd / "visual_pdf" / "pdf_p007_img02.png"), 7,
            "組織観察写真", ["断面 SEM 像"], ["SEM", "20 um"]),
    ]
    picks, rep = select_figures(MD, ve, [], run_dir=rd, cfg=DEFAULTS)
    assert len(picks) == 1
    assert picks[0].cand.evidence_id == "V1"
    assert "圧力損失" in picks[0].anchor.text
    assert rep["picked"][0]["margin"] >= DEFAULTS["min_margin"]


def test_ambiguous_pair_is_rejected(tmp_path):
    """同じ数値を持つ図が 2 枚 → どちらとも取れるので採用しない。"""
    rd = _run_dir(tmp_path)
    same = ["圧力損失 12.5 kPa まで低下"]
    ve = [
        _ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3,
            "圧力損失の推移グラフ", same, ["12.5", "kPa"]),
        _ve("V2", str(rd / "visual_pdf" / "pdf_p007_img02.png"), 3,
            "圧力損失の推移グラフ", same, ["12.5", "kPa"]),
    ]
    picks, rep = select_figures(MD, ve, [], run_dir=rd, cfg=DEFAULTS)
    assert picks == []
    assert any("2 位との差" in r["why"] for r in rep["rejected"])


def test_contact_sheet_and_page_render_excluded(tmp_path):
    rd = _run_dir(tmp_path)
    _make_png(rd / "visual_contact" / "contact_p003_01.png")
    _make_png(rd / "visual_pages" / "page_003.png")
    ve = [
        _ve("V1", str(rd / "visual_contact" / "contact_p003_01.png"), 3,
            "圧力損失 12.5 kPa", ["12.5 kPa"], ["12.5"]),
        _ve("V2", str(rd / "visual_pages" / "page_003.png"), 3,
            "圧力損失 12.5 kPa", ["12.5 kPa"], ["12.5"], kind="page_render"),
    ]
    assert build_candidates(ve, rd, DEFAULTS) == []


def test_decorative_excluded(tmp_path):
    rd = _run_dir(tmp_path)
    p = str(rd / "visual_pdf" / "pdf_p003_img01.png")
    assert build_candidates([_ve("V1", p, 3, "s", ["f"], ["r"], vtype="logo")], rd, DEFAULTS) == []


def test_confidence_and_useful_gates_are_opt_in(tmp_path):
    """v3.27.2：どちらも既定では門にしない。

    contract の has_useful_visual_info は既定 False、confidence も既定 0.0。
    VLM が明示しないと全件が落ちるので、既定で信じてはいけない。
    """
    rd = _run_dir(tmp_path)
    p = str(rd / "visual_pdf" / "pdf_p003_img01.png")
    low = _ve("V1", p, 3, "s", ["f"], ["r"], conf=0.1)
    unflagged = _ve("V1", p, 3, "s", ["f"], ["r"], useful=False)
    assert len(build_candidates([low], rd, DEFAULTS)) == 1
    assert len(build_candidates([unflagged], rd, DEFAULTS)) == 1
    # 明示的に有効化したときだけ効く
    strict = dict(DEFAULTS, min_image_confidence=0.35, trust_has_useful_flag=True)
    assert build_candidates([low], rd, strict) == []
    assert build_candidates([unflagged], rd, strict) == []


def test_downscaled_resolves_to_original(tmp_path):
    """VLM が見たのは *_ds.jpg。掲載は元解像度に戻す。"""
    rd = _run_dir(tmp_path)
    _make_png(rd / "visual_filtered" / "x.png", size=(100, 100))
    ds = rd / "visual_filtered" / "pdf_p003_img01_ds.jpg"
    ds.parent.mkdir(parents=True, exist_ok=True)
    from PIL import Image
    Image.new("RGB", (256, 192), (1, 2, 3)).save(ds)

    cands = build_candidates(
        [_ve("V1", str(ds), 3, "圧力損失", ["12.5 kPa"], ["12.5"])], rd, DEFAULTS)
    assert len(cands) == 1
    assert cands[0].display_path.endswith("pdf_p003_img01.png")
    assert cands[0].image_path.endswith("_ds.jpg")     # 採点は VLM が見た方のまま


def test_inject_writes_reference_and_copies_file(tmp_path):
    rd = _run_dir(tmp_path)
    ve = [_ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3,
              "圧力損失の推移グラフ", ["圧力損失 12.5 kPa まで低下"], ["12.5", "kPa"])]
    picks, _ = select_figures(MD, ve, [], run_dir=rd, cfg=DEFAULTS)
    out = inject_figures(MD, picks, rd)
    assert "（図1）" in out
    assert "![図1" in out
    assert "](figures/fig01.png)" in out
    assert (rd / "figures" / "fig01.png").exists()
    # 参照は必ず本文の直後（論文と同じ並び）
    lines = out.split("\n")
    ref = next(i for i, ln in enumerate(lines) if "（図1）" in ln)
    img = next(i for i, ln in enumerate(lines) if ln.startswith("![図1"))
    assert 0 < img - ref <= 2


def test_attach_is_idempotent(tmp_path):
    rd = _run_dir(tmp_path)
    ve = [_ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3,
              "圧力損失の推移グラフ", ["圧力損失 12.5 kPa まで低下"], ["12.5", "kPa"])]
    (rd / "evidence_visual.json").write_text(json.dumps({"evidence": ve}), encoding="utf-8")

    r1 = attach_figures_to_run(rd, tier="internal")
    r2 = attach_figures_to_run(rd, tier="internal")
    assert r1["figures"] == 1
    assert r2["figures"] == 0 and "既に図版" in r2["reason"]
    assert (rd / "case_summary.md").read_text(encoding="utf-8").count("![図1") == 1


def test_external_tier_off_by_default(tmp_path):
    rd = _run_dir(tmp_path)
    (rd / "case_summary_external.md").write_text(MD, encoding="utf-8")
    (rd / "evidence_visual.json").write_text(json.dumps({"evidence": []}), encoding="utf-8")
    res = attach_figures_to_run(rd, tier="external")
    assert res["figures"] == 0
    assert "社外版" in res["reason"]
    assert "![" not in (rd / "case_summary_external.md").read_text(encoding="utf-8")


def test_report_records_why(tmp_path):
    rd = _run_dir(tmp_path)
    ve = [_ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3,
              "無関係な社内規程の抜粋", ["承認フロー"], ["承認", "部長"])]
    _, rep = select_figures(MD, ve, [], run_dir=rd, cfg=DEFAULTS)
    assert rep["picked"] == []
    assert rep["rejected"] and "閾値" in rep["rejected"][0]["why"]


# ---- v3.27.1：0 枚のときこそ理由が出ること ----

def test_zero_candidates_reports_the_gate(tmp_path):
    """候補 0 枚でも「どの門で落ちたか」が残る。黙って 0 を返さない。"""
    rd = _run_dir(tmp_path)
    p = str(rd / "visual_pdf" / "pdf_p003_img01.png")
    ve = [_ve("V1", p, 3, "", [], [], conf=0.9),
          _ve("V2", p, 3, "s", ["f"], ["r"], vtype="logo")]
    _, rep = select_figures(MD, ve, [], run_dir=rd, cfg=DEFAULTS)
    assert rep["visual_evidence_in"] == 2
    assert rep["candidates"] == 0
    assert sum(rep["dropped_by"].values()) == 2
    assert any("読み取り結果が空" in k for k in rep["dropped_by"])
    assert "全て候補から外れました" in rep["reason"]


def test_no_visual_evidence_says_so(tmp_path):
    rd = _run_dir(tmp_path)
    _, rep = select_figures(MD, [], [], run_dir=rd, cfg=DEFAULTS)
    assert "視覚証拠が 1 件もありません" in rep["reason"]


def test_near_miss_is_reported(tmp_path):
    """閾値に届かなかったとき、最高スコアと内訳が残る（調整の material）。"""
    rd = _run_dir(tmp_path)
    ve = [_ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3,
              "配管の一般的な説明図", ["配管"], ["図"])]
    picks, rep = select_figures(MD, ve, [], run_dir=rd, cfg=DEFAULTS)
    assert picks == []
    assert rep["best"]["score"] < DEFAULTS["min_score"]
    assert "届きませんでした" in rep["reason"]
    assert "parts" in rep["best"]["breakdown"]


def test_contact_sheet_kind_is_excluded_even_without_path_hint(tmp_path):
    """asset_kind='contact_sheet' はパスが visual_contact/ でなくても除外する。"""
    rd = _run_dir(tmp_path)
    ve = [_ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3,
              "圧力損失 12.5 kPa", ["12.5 kPa"], ["12.5"], kind="contact_sheet")]
    drops = {}
    assert build_candidates(ve, rd, DEFAULTS, drops=drops) == []
    assert sum(drops.values()) == 1


# ---- v3.27.2：要約側の名指し [[V3]] と、門の見直し ----

MD_CITED = """# テスト案件

## 調査・対応により判明した事実 (Findings & Discovered Facts)

- 流路変更後の圧力損失は 12.5 kPa まで低下し、目標値を下回った [[V1]]
- 外材コート層の硬さは母材比で 1.8 倍となった
"""


def test_citation_binds_directly(tmp_path):
    """名指しがあれば、2 位との差の規則を待たずに結び付く。"""
    rd = _run_dir(tmp_path)
    same = ["圧力損失 12.5 kPa まで低下"]
    ve = [_ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3, "圧力損失グラフ", same, ["12.5"]),
          _ve("V2", str(rd / "visual_pdf" / "pdf_p007_img02.png"), 3, "圧力損失グラフ", same, ["12.5"])]
    # 名指し無しなら曖昧で不採用（前のテストと同じ状況）
    assert select_figures(MD, ve, [], run_dir=rd, cfg=DEFAULTS)[0] == []
    # 名指しがあれば V1 に確定する
    picks, rep = select_figures(MD_CITED, ve, [], run_dir=rd, cfg=DEFAULTS)
    assert len(picks) == 1 and picks[0].cand.evidence_id == "V1"
    assert rep["picked"][0]["via"] == "要約の名指し"
    assert rep["citations"]["accepted"] == 1


def test_citation_is_verified_not_trusted(tmp_path):
    """名指しでも裏取りに失敗したら却下する（宣言を鵜呑みにしない）。"""
    rd = _run_dir(tmp_path)
    ve = [_ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 9,
              "社員旅行の集合写真", ["旅行"], ["記念"])]
    picks, rep = select_figures(MD_CITED, ve, [], run_dir=rd, cfg=DEFAULTS)
    assert picks == []
    assert rep["citations"]["rejected"] == 1
    assert any("却下" in r["why"] for r in rep["rejected"])


def test_citation_to_unknown_id_is_reported(tmp_path):
    rd = _run_dir(tmp_path)
    ve = [_ve("V9", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3, "圧力損失", ["12.5 kPa"], ["12.5"])]
    _, rep = select_figures(MD_CITED, ve, [], run_dir=rd, cfg=DEFAULTS)
    assert any("候補にありません" in r["why"] for r in rep["rejected"])


def test_markers_never_reach_output(tmp_path):
    """採否にかかわらず [[V3]] は本文に残さない。"""
    rd = _run_dir(tmp_path)
    (rd / "case_summary.md").write_text(MD_CITED, encoding="utf-8")
    ve = [_ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3,
              "圧力損失グラフ", ["圧力損失 12.5 kPa"], ["12.5"])]
    json_path = rd / "evidence_visual.json"
    json_path.write_text(json.dumps({"evidence": ve}, ensure_ascii=False), encoding="utf-8")
    attach_figures_to_run(rd, tier="internal")
    out = (rd / "case_summary.md").read_text(encoding="utf-8")
    assert "[[" not in out and "V1]]" not in out
    assert "（図1）" in out


def test_markers_stripped_even_when_nothing_picked(tmp_path):
    rd = _run_dir(tmp_path)
    (rd / "case_summary.md").write_text(MD_CITED, encoding="utf-8")
    (rd / "evidence_visual.json").write_text(json.dumps({"evidence": []}), encoding="utf-8")
    attach_figures_to_run(rd, tier="internal")
    assert "[[" not in (rd / "case_summary.md").read_text(encoding="utf-8")


def test_strip_citations_deep_cleans_summary_json():
    from app.figure_select import strip_citations_deep
    src = {"findings": ["圧力損失が低下した [[V1]]", "渦が解消した"],
           "nested": {"effects": ["動力を削減 ［［V2］］"]}}
    out = strip_citations_deep(src)
    assert out["findings"][0] == "圧力損失が低下した"
    assert out["nested"]["effects"][0] == "動力を削減"


def test_zero_confidence_is_not_punished(tmp_path):
    """confidence 0.0 は「答えていない」扱い。門でも係数でも罰しない。"""
    rd = _run_dir(tmp_path)
    ve = [_ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3,
              "圧力損失の推移グラフ", ["圧力損失 12.5 kPa まで低下"], ["12.5", "kPa"], conf=0.0)]
    assert len(build_candidates(ve, rd, DEFAULTS)) == 1
    picks, _ = select_figures(MD, ve, [], run_dir=rd, cfg=DEFAULTS)
    assert len(picks) == 1


def test_empty_content_is_dropped(tmp_path):
    rd = _run_dir(tmp_path)
    ve = [_ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3, "", [], [], conf=0.9)]
    drops = {}
    assert build_candidates(ve, rd, DEFAULTS, drops=drops) == []
    assert any("読み取り結果が空" in k for k in drops)


def test_core_worthiness_gets_a_bonus(tmp_path):
    rd = _run_dir(tmp_path)
    base = _ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3,
               "圧力損失グラフ", ["圧力損失 12.5 kPa"], ["12.5"])
    plain = build_candidates([base], rd, DEFAULTS)[0]
    core = build_candidates([dict(base, figure_worthiness="core")], rd, DEFAULTS)[0]
    b = "流路変更後の圧力損失は 12.5 kPa まで低下し、目標値を下回った"
    from app.figure_select import score_pair
    assert score_pair(b, core, 3)[0] > score_pair(b, plain, 3)[0]


def test_vlm_caption_preferred(tmp_path):
    rd = _run_dir(tmp_path)
    ve = [dict(_ve("V1", str(rd / "visual_pdf" / "pdf_p003_img01.png"), 3,
                   "グラフ", ["圧力損失 12.5 kPa まで低下"], ["12.5", "kPa"]),
               figure_caption="流路変更前後の圧力損失比較。変更後は 12.5 kPa まで低下")]
    picks, _ = select_figures(MD, ve, [], run_dir=rd, cfg=DEFAULTS)
    assert "流路変更前後の圧力損失比較" in picks[0].caption
