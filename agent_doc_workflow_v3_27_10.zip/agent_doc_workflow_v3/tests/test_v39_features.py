"""v3.9 の回帰テスト。

追加した 4 つ（実行トレース / 精読モード / 二段階書き出し / PPTX 生成）は
どれも「弱いモデルに判断を任せない」方針で作ってあるので、テストも
**確定的な部分**を固定する。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.deep_read import (_extract_numbers, build_page_report,
                           cross_check_page, report_to_prompt_block)
from app.trace import (ENGINE_DOCLING, ENGINE_LIBREOFFICE, ENGINE_PYPDFIUM,
                       ENGINE_WIN32COM, PipelineTrace, engine_kind,
                       environment_report)


# ----------------------------------------------------------------------
# 実行トレース
# ----------------------------------------------------------------------

def test_trace_records_route_and_engines():
    t = PipelineTrace()
    t.set_route("vision", "テキスト層が薄い", manual=False)
    t.use("parse", ENGINE_PYPDFIUM, "テキスト層抽出")
    d = t.to_dict()
    assert d["route"] == "vision"
    assert d["route_decided_by"] == "自動判定"
    assert any(e["engine"] == ENGINE_PYPDFIUM for e in d["engines_used"])


def test_trace_records_fallback_with_origin():
    """後退したときは「何から何へ」が残らないと原因究明に使えない。"""
    t = PipelineTrace()
    t.fallback("parse", ENGINE_DOCLING, ENGINE_PYPDFIUM, "Docling 失敗")
    d = t.to_dict()
    assert len(d["fallbacks"]) == 1
    assert d["fallbacks"][0]["fallback_from"] == ENGINE_DOCLING
    assert d["fallbacks"][0]["engine"] == ENGINE_PYPDFIUM


def test_trace_records_unavailable_engines():
    """「入っていない」ことが分かるのが重要（エラーにならないので）。"""
    t = PipelineTrace()
    t.unavailable("excel", ENGINE_WIN32COM, "Windows 以外")
    d = t.to_dict()
    assert d["unavailable"][0]["engine"] == ENGINE_WIN32COM
    assert any("利用不可" in line for line in t.summary_lines())


def test_trace_round_trips_and_merges():
    a, b = PipelineTrace(), PipelineTrace()
    a.set_route("text", "文章主体")
    a.use("parse", ENGINE_DOCLING)
    b.use("visual", ENGINE_PYPDFIUM)
    a.merge(PipelineTrace.from_raw(b.raw()))
    engines = a.engines_used()
    assert ENGINE_DOCLING in engines and ENGINE_PYPDFIUM in engines
    assert PipelineTrace.from_raw(a.raw()).route == "text"


def test_engine_kind_distinguishes_external_dependencies():
    """純 Python か外部アプリかが一目で分かること（環境差の切り分け用）。"""
    assert engine_kind(ENGINE_PYPDFIUM) == "純Python"
    assert engine_kind(ENGINE_LIBREOFFICE) == "外部アプリ"
    assert engine_kind(ENGINE_WIN32COM) == "Excel 実機"


def test_environment_report_lists_availability():
    env = environment_report()
    names = {r["engine"] for r in env["engines"]}
    assert ENGINE_LIBREOFFICE in names and ENGINE_WIN32COM in names
    assert all("available" in r for r in env["engines"])


# ----------------------------------------------------------------------
# 精読モード
# ----------------------------------------------------------------------

def test_units_are_matched_longest_first():
    """"0.8 m3/min" が "0.8 m" として拾われないこと。

    正規表現の選択肢は左から試されるので、単位を短い順に並べると
    複合単位が壊れる。実際にそのバグを踏んだ箇所。
    """
    got = dict((raw, unit) for _, unit, raw in
               _extract_numbers("風量 0.8 m3/min、費用 1,250 万円、圧力 0.5 MPa"))
    assert got["0.8 m3/min"] == "m3/min"
    assert got["1,250 万円"] == "万円"
    assert got["0.5 MPa"] == "MPa"


def test_conflicting_numbers_are_flagged():
    r = cross_check_page(
        2,
        [{"content": "最高温度は 68.3 degC"}],
        [{"visual_summary": "分布図", "key_facts": ["最高 68.5 degC"], "readable_text": []}])
    assert r["needs_review"] is True
    assert r["conflicts"][0]["unit"] == "degC"


def test_matching_numbers_are_corroborated_not_flagged():
    r = cross_check_page(
        2,
        [{"content": "風量 0.8 m3/min"}],
        [{"visual_summary": "", "key_facts": [], "readable_text": ["風量 0.8 m3/min"]}])
    assert r["needs_review"] is False
    assert "0.8 m3/min" in r["numbers_corroborated"]


def test_rounding_noise_is_not_a_conflict():
    """68.30 と 68.3 のような表記揺れで誤検出しないこと。"""
    r = cross_check_page(1, [{"content": "68.30 degC"}],
                         [{"key_facts": ["68.3 degC"], "readable_text": []}])
    assert r["needs_review"] is False


def test_page_coverage_is_classified():
    rep = build_page_report(
        [{"page": 1, "content": "本文のみ"}],
        [{"page": 2, "visual_summary": "図のみ", "key_facts": [], "readable_text": []}])
    cov = {p["page"]: p["coverage"] for p in rep["pages"]}
    assert cov[1] == "text_only" and cov[2] == "visual_only"


def test_unpaged_evidence_is_not_discarded():
    """頁が特定できない証拠も捨てない（v3.8 の教訓）。"""
    rep = build_page_report([{"content": "頁不明"}], [])
    assert rep["unpaged"] is not None
    assert rep["unpaged"]["text_evidence_count"] == 1


def test_prompt_block_stays_silent_when_all_clean():
    """問題の無い頁まで書くと証拠パックを無駄に圧迫する。"""
    rep = build_page_report(
        [{"page": 1, "content": "25 degC"}],
        [{"page": 1, "key_facts": ["25 degC"], "readable_text": []}])
    assert report_to_prompt_block(rep) == ""


def test_prompt_block_tells_model_not_to_assert():
    rep = build_page_report(
        [{"page": 2, "content": "68.3 degC"}],
        [{"page": 2, "key_facts": ["68.5 degC"], "readable_text": []}])
    block = report_to_prompt_block(rep)
    assert "食い違" in block and "断定" in block


# ----------------------------------------------------------------------
# 二段階書き出し（加筆）
# ----------------------------------------------------------------------

def test_expand_is_skipped_for_blank_fields(tmp_path):
    """空欄や「確認できず」は加筆対象にしない。

    そこを埋めさせるのが作話の入口になるので、意図的に触らない。
    """
    from app.config import load_config
    from app.contract import UNKNOWN
    from app.graph import run_workflow
    from app.llm_client import LocalLLMClient

    doc = tmp_path / "t.md"
    doc.write_text("# 件名\n本文が十分な長さで書かれている資料です。" * 5, encoding="utf-8")

    def mock(system, user):
        if "視覚" in system:
            return {"has_useful_visual_info": False, "confidence": 0.1}
        if "文書整理エージェント" in system:
            return {"evidence": [{"category": "finding", "content": "事実A",
                                  "confidence": 0.9}]}
        if "特定の項目だけ" in system:          # EXPAND_SYSTEM
            return {"items": ["ずっと長く具体的に書き直した内容です。" * 3]}
        return {"case_name": "件名",
                "request_details": {"requester": UNKNOWN, "background": [UNKNOWN],
                                    "client_issues": [UNKNOWN],
                                    "scope_of_request": [UNKNOWN],
                                    "target_product_or_system": UNKNOWN},
                "action_results": {"support_type": UNKNOWN, "tools_environment": [],
                                   "period": UNKNOWN, "findings": ["短い事実"],
                                   "effects": [UNKNOWN]},
                "evidence": []}

    cfg = load_config()
    cfg.llm.mock = True
    cfg.paths.out_dir = str(tmp_path / "out")
    cfg.workflow.expand_summary = True
    llm = LocalLLMClient(base_url="", api_key="", mock=True, mock_handler=mock)
    final = run_workflow(str(doc), cfg, llm, template_id="case")

    rep = json.loads((Path(final["run_dir"]) / "expand_report.json").read_text(encoding="utf-8"))
    assert "findings" in rep["expanded"], "証拠のある項目が加筆されていない"
    for blank in ("effects", "client_issues", "scope_of_request", "background"):
        assert blank not in rep["expanded"], f"空欄 {blank} を加筆してしまっている"
        assert blank in rep["skipped_blank"]


def test_expand_respects_call_budget():
    """加筆 1 項目 = LLM 1 回。上限を超えて呼ばないこと。"""
    from app.config import load_config
    cfg = load_config()
    assert cfg.workflow.expand_max_fields >= 1
    assert cfg.workflow.expand_temperature > 0, "加筆まで temperature 0 だと伸びない"


def test_llm_client_accepts_per_call_temperature():
    """抽出は 0、加筆は 0.25 のように段階ごとに変えられること。"""
    from app.llm_client import _temp_kw
    assert _temp_kw(None) == {}, "既定では呼び出し形を変えない（テストダブル互換）"
    assert _temp_kw(0.25) == {"temperature": 0.25}


# ----------------------------------------------------------------------
# PPTX 生成
# ----------------------------------------------------------------------

def _deck(tmp_path, md: str, title: str = "テスト案件"):
    from app.export_doc import DocSection
    from app.export_pptx import export_pptx
    out = tmp_path / "deck.pptx"
    export_pptx([DocSection(title=title, markdown=md, source_name="src.pdf")],
                out, deck_title=title)
    from pptx import Presentation
    return Presentation(str(out))


def test_pptx_splits_long_bullet_lists_without_losing_content(tmp_path):
    """詰め込みすぎは読めないが、**内容を落とすのは論外**。

    上限を超えたら「（続き）」スライドへ送る。
    """
    bullets = [f"- 事実{i}：数値 {i}.5 degC で確認された内容です" for i in range(1, 13)]
    md = "# 案件\n\n## 判明した事実\n" + "\n".join(bullets) + "\n"
    prs = _deck(tmp_path, md)
    all_text = "\n".join(sh.text_frame.text for s in prs.slides
                         for sh in s.shapes if sh.has_text_frame)
    for i in range(1, 13):
        assert f"事実{i}：" in all_text, f"事実{i} が消えている"
    assert "（続き）" in all_text


def test_pptx_converts_tables_to_bullets(tmp_path):
    """表はスライドで読みづらいので箇条書きに落とすが、値は残す。"""
    md = ("# 案件\n\n## 条件\n"
          "| 項目 | 値 |\n|---|---|\n| 周囲温度 | 25 degC |\n| 発熱量 | 12.5 W |\n")
    prs = _deck(tmp_path, md)
    all_text = "\n".join(sh.text_frame.text for s in prs.slides
                         for sh in s.shapes if sh.has_text_frame)
    assert "25 degC" in all_text and "12.5 W" in all_text


def test_pptx_uses_template_when_present(tmp_path):
    """社内テンプレートを渡したらその書式を土台にする（既存スライドは除去）。"""
    from pptx import Presentation
    from pptx.util import Inches
    from app.export_doc import DocSection
    from app.export_pptx import export_pptx

    tpl = tmp_path / "corp.pptx"
    base = Presentation()
    base.slide_width, base.slide_height = Inches(10), Inches(7.5)   # 4:3 の社内書式
    base.slides.add_slide(base.slide_layouts[0])                    # 既存スライド 1 枚
    base.save(str(tpl))

    out = tmp_path / "out.pptx"
    export_pptx([DocSection(title="件", markdown="# 件\n\n## 節\n- 項目\n")],
                out, deck_title="件", template_path=str(tpl))
    prs = Presentation(str(out))
    assert prs.slide_width == Inches(10), "テンプレートのページ設定を引き継いでいない"
    texts = "\n".join(sh.text_frame.text for s in prs.slides
                      for sh in s.shapes if sh.has_text_frame)
    assert "項目" in texts


def test_export_endpoint_accepts_pptx():
    from fastapi.testclient import TestClient
    from app import webapp
    c = TestClient(webapp.app)
    r = c.get("/api/runs/__nonexistent__/export.pptx")
    assert r.status_code != 400, "pptx が未対応フォーマット扱いになっている"


def test_export_endpoint_still_rejects_unknown_format():
    from fastapi.testclient import TestClient
    from app import webapp
    c = TestClient(webapp.app)
    assert c.get("/api/runs/x/export.rtf").status_code == 400


# ----------------------------------------------------------------------
# 作話への確定的な歯止め（数値検証）
# ----------------------------------------------------------------------
#
# 「詳しく書け」と言われた弱いモデルは、字数を満たすために数値を作る。
# プロンプトで禁じても完全には止まらないので、規則で潰す。
# 要約は抽出であって創造ではないので、「証拠に無い数値が出る」こと自体が異常。

def test_fabricated_numbers_are_detected():
    from app.deep_read import unsupported_numbers
    ev = "周囲温度 25 degC、最高温度 68.3 degC、風量 0.8 m3/min"
    bad = unsupported_numbers("局所的に 92.7 degC まで上昇し、消費電力は 3.5 kW", ev)
    texts = {b["text"] for b in bad}
    assert "92.7 degC" in texts and "3.5 kW" in texts


def test_numbers_present_in_evidence_pass():
    from app.deep_read import verify_items
    ev = "最高温度 68.3 degC、風量 0.8 m3/min、許容値 75 degC"
    r = verify_items(["最高温度 68.3 degC で許容値 75 degC に対し余裕があった"], ev)
    assert r["ok"] is True and r["unsupported"] == []


def test_rounding_variants_are_not_treated_as_fabrication():
    """68.30 と 68.3 は同じ値。表記の揺れで誤って破棄しないこと。"""
    from app.deep_read import verify_items
    assert verify_items(["最高温度 68.30 degC"], "最高温度 68.3 degC")["ok"] is True


def test_bare_numbers_are_not_flagged():
    """単位なしの裸の数（箇条書き番号など）で誤検出しないこと。"""
    from app.deep_read import verify_items
    assert verify_items(["3 つの観点で確認した"], "温度 25 degC")["ok"] is True


def test_unit_stripped_number_still_counts_as_supported():
    """証拠が「68.3 degC」で出力が「68.3」なら裏は取れている。"""
    from app.deep_read import unsupported_numbers
    assert unsupported_numbers("値は 68.3 % だった", "最高温度 68.3 degC") == []


def test_expansion_with_fabricated_numbers_is_discarded(tmp_path):
    """作話を含む加筆は**丸ごと**捨てて元の文面を残すこと。"""
    from app.config import load_config
    from app.graph import run_workflow
    from app.llm_client import LocalLLMClient

    doc = tmp_path / "t.md"
    doc.write_text("# 解析報告\n最高温度は 68.3 degC。" * 6, encoding="utf-8")

    def mock(system, user):
        if "視覚" in system:
            return {"has_useful_visual_info": False, "confidence": 0.1}
        if "文書整理エージェント" in system:
            return {"evidence": [{"category": "finding",
                                  "content": "最高温度 68.3 degC", "confidence": 0.9}]}
        if "特定の項目だけ" in system:
            return {"items": ["局所的に 92.7 degC まで上昇したことが判明した。" * 2]}
        return {"case_name": "解析報告",
                "request_details": {"requester": "設計部",
                                    "target_product_or_system": "装置A",
                                    "background": ["背景"], "client_issues": ["課題"],
                                    "scope_of_request": ["範囲"]},
                "action_results": {"support_type": "解析", "tools_environment": ["FloEFD"],
                                   "period": "2026Q1", "findings": ["最高温度 68.3 degC"],
                                   "effects": ["効果"]},
                "evidence": []}

    cfg = load_config()
    cfg.llm.mock = True
    cfg.paths.out_dir = str(tmp_path / "out")
    llm = LocalLLMClient(base_url="", api_key="", mock=True, mock_handler=mock)
    final = run_workflow(str(doc), cfg, llm, template_id="case")

    rep = json.loads((Path(final["run_dir"]) / "expand_report.json").read_text(encoding="utf-8"))
    assert rep["expanded"] == [], "作話を含む加筆が採用されてしまっている"
    assert rep["rejected_fabrication"], "破棄の記録が残っていない"
    assert "92.7" in json.dumps(rep["rejected_fabrication"], ensure_ascii=False)
    # 元の文面が残っていること
    summary = json.loads((Path(final["run_dir"]) / "case_summary.json").read_text(encoding="utf-8"))
    assert "92.7" not in json.dumps(summary, ensure_ascii=False)


def test_expand_budget_default_is_conservative():
    """1 項目 = LLM 1 回。弱いモデルでの所要時間に直結するので既定は控えめに。"""
    from app.config import load_config
    cfg = load_config()
    assert cfg.workflow.expand_max_fields == 3
    assert cfg.workflow.expand_verify_numbers is True
