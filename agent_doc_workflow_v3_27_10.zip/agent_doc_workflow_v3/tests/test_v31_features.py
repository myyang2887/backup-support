"""v3.1 新特性测试：adaptive 结构化输出 / 指标 / 取消 / 健康检查 / skeleton。"""
import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.contract import CaseSummary, EvidenceList, schema_skeleton
from app.llm_client import LocalLLMClient, LLMJsonError, compact_schema
from app.observability import RunCancelled, RunStore


# ----------------------------------------------------------------------
# 1. adaptive 结构化输出（性能修正的核心逻辑）
# ----------------------------------------------------------------------

class FakeTransport:
    """替换 _create：按脚本返回文本，并记录每次调用是否带了 grammar。"""

    def __init__(self, script):
        self.script = list(script)
        self.calls = []  # [(grammar_used: bool)]

    def __call__(self, messages, max_tokens, response_format):
        self.calls.append(response_format is not None)
        return self.script.pop(0)


def _client(mode: str, script) -> tuple[LocalLLMClient, FakeTransport]:
    c = LocalLLMClient(base_url="http://x/v1", api_key="k", structured_output=mode,
                       mock=False, max_retries=0)
    c.client = SimpleNamespace()  # 不会被用到
    t = FakeTransport(script)
    c._create = t  # type: ignore[method-assign]
    return c, t


def test_adaptive_good_json_never_pays_grammar():
    c, t = _client("adaptive", ['{"evidence": []}'])
    out = c.chat_json("sys", "user", json_schema=EvidenceList.model_json_schema())
    assert out == {"evidence": []}
    assert t.calls == [False], "合格输出不应触发 grammar（这是 v1 级速度的关键）"


def test_adaptive_bad_json_falls_back_to_grammar_once():
    c, t = _client("adaptive", ["これはJSONではありません", '{"evidence": []}'])
    out = c.chat_json("sys", "user", json_schema=EvidenceList.model_json_schema())
    assert out == {"evidence": []}
    assert t.calls == [False, True], "第一次文本失败后，第二次才带 grammar"


def test_always_mode_uses_grammar_first():
    c, t = _client("always", ['{"evidence": []}'])
    c.chat_json("sys", "user", json_schema=EvidenceList.model_json_schema())
    assert t.calls == [True]


def test_never_mode_raises_without_grammar():
    c, t = _client("never", ["壊れた出力"])
    with pytest.raises(LLMJsonError):
        c.chat_json("sys", "user", json_schema=EvidenceList.model_json_schema())
    assert t.calls == [False]


def test_legacy_mode_aliases():
    for legacy, expected in [("auto", "adaptive"), ("json_schema", "always"), ("none", "never")]:
        c = LocalLLMClient(base_url="", api_key="", structured_output=legacy, mock=True)
        assert c.structured_output == expected


def test_metrics_hook_receives_records():
    records = []
    c, _ = _client("adaptive", ['{"evidence": []}'])
    c.metrics_hook = records.append
    c.chat_json("sys", "user", json_schema=EvidenceList.model_json_schema(), tag="extract:c1")
    assert len(records) == 1
    r = records[0]
    assert r["tag"] == "extract:c1" and r["grammar_used"] is False
    assert r["prompt_chars"] > 0 and "duration_s" in r


def test_compact_schema_strips_noise_keeps_structure():
    schema = CaseSummary.model_json_schema()
    slim = compact_schema(schema)
    text = json.dumps(slim)
    assert '"title"' not in text and '"description"' not in text and '"default"' not in text
    assert "properties" in slim and "$defs" in slim  # 结构完整


# ----------------------------------------------------------------------
# 2. skeleton（契约 -> 紧凑 prompt 规格，单一真源）
# ----------------------------------------------------------------------

def test_skeleton_mirrors_contract_shape():
    sk = CaseSummary.skeleton()
    assert set(sk) == set(CaseSummary.model_fields)
    assert isinstance(sk["request_details"], dict)
    assert isinstance(sk["request_details"]["background"], list)
    assert isinstance(sk["evidence"], list)
    # 比完整 schema 显著小
    assert len(json.dumps(sk)) < len(json.dumps(CaseSummary.model_json_schema())) / 2


def test_skeleton_evidence_shape():
    sk = schema_skeleton(EvidenceList.model_json_schema())
    # v3.4: category 为自由字符串（各模板自定义类别表），skeleton 呈现为 string 占位
    assert isinstance(sk["evidence"][0]["category"], str)
    assert set(sk["evidence"][0]) == {"evidence_id", "category", "content", "confidence", "source"}


# ----------------------------------------------------------------------
# 3. RunStore：指标聚合 / 取消
# ----------------------------------------------------------------------

def test_runstore_metric_aggregation(tmp_path):
    store = RunStore(tmp_path / "run")
    store.llm_metric({"tag": "extract:c1", "duration_s": 2.0, "prompt_chars": 100,
                      "completion_chars": 50, "grammar_used": False})
    store.llm_metric({"tag": "extract:c2", "duration_s": 3.0, "prompt_chars": 100,
                      "completion_chars": 50, "grammar_used": True})
    store.llm_metric({"tag": "summary:main", "duration_s": 10.0, "prompt_chars": 5000,
                      "completion_chars": 800, "grammar_used": False})
    agg = store.load_json(RunStore.METRICS)
    assert agg["extract"]["calls"] == 2 and agg["extract"]["total_s"] == 5.0
    assert agg["extract"]["grammar_calls"] == 1
    assert agg["summary"]["calls"] == 1
    # 明细 JSONL 三行
    lines = store.path(RunStore.LLM_METRICS).read_text(encoding="utf-8").strip().split("\n")
    assert len(lines) == 3


def test_runstore_cancel_flag(tmp_path):
    store = RunStore(tmp_path / "run")
    assert not store.cancelled
    store.request_cancel()
    assert store.cancelled
    with pytest.raises(RunCancelled):
        store.raise_if_cancelled()
    store.reset_status()  # 新一轮运行应清除标记
    assert not store.cancelled


# ----------------------------------------------------------------------
# 4. Web：健康检查 / 取消端点 / 指标出现在状态里
# ----------------------------------------------------------------------

@pytest.fixture()
def web_client(tmp_path, monkeypatch):
    import app.webapp as W
    from fastapi.testclient import TestClient
    monkeypatch.setattr(W.config.llm, "mock", True)
    monkeypatch.setattr(W.config.paths, "out_dir", str(tmp_path / "out"))
    monkeypatch.setattr(W.config.paths, "inbox_dir", str(tmp_path / "inbox"))
    W._runs.clear()
    return TestClient(W.app)


DOC = ("# 光学解析支援\n光学設計部より、レンズユニットの流体解析代行の依頼を受けた。"
       "背景として試作段階での歩留まり低下があり、原因が特定できていなかった。"
       "使用ツールは FloEFD 2024。対応期間は2026年1月。"
       "解析の結果、特定条件で異常が判明し、解析工数を30%削減する効果が得られた。")


def test_health_mock(web_client):
    assert web_client.get("/api/health").json()["llm"] == "mock"


def test_cancel_endpoint_states(web_client):
    r = web_client.post("/api/runs", files={"files": ("c1.md", DOC.encode(), "text/markdown")})
    run_id = r.json()["run_id"]
    # 无论此刻是 queued/running/done，取消端点都应给出结构化答复
    resp = web_client.post(f"/api/runs/{run_id}/cancel").json()
    assert "state" in resp
    for _ in range(80):
        st = web_client.get(f"/api/runs/{run_id}").json()["state"]
        if st in ("done", "failed", "cancelled"):
            break
        time.sleep(0.25)
    assert st in ("done", "cancelled")  # mock 极快，可能在取消生效前已完成
    # 已结束的 run 再取消 -> ok: False
    resp = web_client.post(f"/api/runs/{run_id}/cancel").json()
    assert resp["ok"] is False


def test_status_payload_shape(web_client):
    r = web_client.post("/api/runs", files={"files": ("c2.md", DOC.encode(), "text/markdown")})
    run_id = r.json()["run_id"]
    for _ in range(80):
        info = web_client.get(f"/api/runs/{run_id}").json()
        if info["state"] in ("done", "failed"):
            break
        time.sleep(0.25)
    assert info["state"] == "done"
    assert "progress" in info and info["progress"]["history"]
    # mock 客户端不产生真实指标，但字段协议允许缺失——UI 已按可选处理


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
