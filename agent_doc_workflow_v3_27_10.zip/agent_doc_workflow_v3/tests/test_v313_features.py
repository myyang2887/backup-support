"""v3.13：視覚ルートでも Excel の数値本文を保持する／HTML を保険に降格。

背景：
    視覚ルートの終端に無条件の `md_path.write_text(text)` があり、xlsx は
    その直前の分岐で text="" になるため、_excel_text_pass が書いた
    **数値表がまるごと空文字で上書きされて消えていた**。
    実測で markdown 0 字・テキスト証拠 0 件。50 列 200 行の測定データが
    シート画像だけになり、密なデータ表が要約から完全に落ちていた。

    「ここでは何もしないのが正しい」という注釈は正しかったが、その下の
    一行が意図を無効化していた——注釈と実装がずれた典型例なので、
    契約としてテストに固定する。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


# ======================================================================
# 1. 視覚ルートが本文を消さないこと
# ======================================================================

def test_vision_route_does_not_erase_existing_markdown():
    """空文字での上書きを禁じる。ここが緩むと Excel の数値が全部消える。"""
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert "if text or not md_path.exists():" in src, \
        "視覚ルートで既存 Markdown を無条件上書きしてはいけない"
    # 無条件版が残っていないこと
    assert "\n            md_path.write_text(text, encoding=\"utf-8\")\n" not in src


@pytest.mark.parametrize("mode", ["text", "vision"])
def test_excel_keeps_numeric_text_on_both_routes(tmp_path, mode):
    """密な数値表が、どちらのルートでも本文として残ること。

    視覚ルートでもシート画像は「裏取りの目」であって数値の出所ではない。
    数値の正確さは openpyxl 経由の本文が担う。
    """
    openpyxl = pytest.importorskip("openpyxl")

    from app.config import load_config
    from app.graph import run_workflow

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "測定データ"
    ws.append([f"項目{c}" for c in range(1, 21)])
    for r in range(60):
        ws.append([round(r * 0.37 + c, 2) for c in range(1, 21)])
    src = tmp_path / "測定データ一覧.xlsx"
    wb.save(src)

    cfg = load_config().model_copy(deep=True)
    cfg.llm.mock = True
    cfg.workflow.parallel_branches = False
    cfg.workflow.warmup_on_start = False
    cfg.paths.out_dir = str(tmp_path / f"out_{mode}")

    final = run_workflow(str(src), cfg, template_id="generic_doc", input_mode=mode)
    body = Path(final["markdown_path"]).read_text(encoding="utf-8")

    assert final["route"] == mode
    assert len(body) > 2000, f"{mode} ルートで本文が失われている（{len(body)} 字）"
    assert "測定データ" in body
    assert "項目1" in body, "列見出しが残っていること（行列構造の証跡）"


def test_plain_text_forced_to_vision_keeps_content(tmp_path):
    """手動で視覚ルートにされた .md/.txt が空回りしないこと。

    描画すべき頁が無いので視覚資産はゼロ。ここで本文まで空にすると
    run が丸ごと無意味になる。
    """
    from app.config import load_config
    from app.graph import run_workflow

    src = tmp_path / "手順書.md"
    src.write_text("# ページ 1\n# 手順書\n作業手順。\n# ページ 2\n測定値は 12.3 kPa。\n",
                   encoding="utf-8")

    cfg = load_config().model_copy(deep=True)
    cfg.llm.mock = True
    cfg.workflow.parallel_branches = False
    cfg.workflow.warmup_on_start = False
    cfg.paths.out_dir = str(tmp_path / "out")

    final = run_workflow(str(src), cfg, template_id="generic_doc", input_mode="vision")
    body = Path(final["markdown_path"]).read_text(encoding="utf-8")
    assert "12.3" in body


# ======================================================================
# 2. HTML は openpyxl 失敗時の保険に降格
# ======================================================================

@pytest.fixture()
def html_stub(tmp_path, monkeypatch):
    import app.nodes as N

    calls = {"n": 0}

    def _fake(inp, outp, engine="auto"):
        calls["n"] += 1
        Path(outp).write_text("<table><tr><td>1</td></tr></table>", encoding="utf-8")
        return {"ok": True, "output_path": outp}

    monkeypatch.setattr(N, "xlsx_to_html", _fake)
    parse_dir = tmp_path / "parsed"
    parse_dir.mkdir()
    return N, parse_dir, calls


def test_html_skipped_when_openpyxl_text_is_healthy(tmp_path, html_stub):
    """本文が健在なら HTML は作らない。

    消費側は soup.get_text() で表を平坦化するため、HTML は openpyxl の
    Markdown 表の劣化版でしかない。証拠パックの文字数予算を食うだけ。
    """
    N, parse_dir, calls = html_stub

    md = parse_dir / "book.md"
    md.write_text("# book\n\n| a | b |\n|---|---|\n" + "| 1 | 2 |\n" * 40,
                  encoding="utf-8")
    state = {"errors": [], "run_dir": str(tmp_path)}
    N._excel_html_fallback(state, parse_dir, tmp_path / "book.xlsx", md)

    assert calls["n"] == 0
    assert state["excel_html_path"] == ""


def test_html_used_when_openpyxl_text_missing(tmp_path, html_stub):
    """本文が取れなかった時だけ保険が動く。平坦でも無いよりまし。"""
    N, parse_dir, calls = html_stub

    md = parse_dir / "empty.md"
    md.write_text("", encoding="utf-8")
    state = {"errors": [], "run_dir": str(tmp_path)}
    N._excel_html_fallback(state, parse_dir, tmp_path / "empty.xlsx", md)

    assert calls["n"] == 1
    assert state["excel_html_path"]
    # 劣化したことを利用者に伝える
    assert any("HTML 変換で代替" in e.get("message", "") for e in state["errors"])


def test_html_fallback_triggers_on_heading_only_stub(tmp_path, html_stub):
    """見出し行だけの「実質空」も保険に回す。

    workbook_to_markdown は失敗しても "# ファイル名" までは書けてしまうので、
    存在チェックだけでは空を検出できない。
    """
    N, parse_dir, calls = html_stub

    md = parse_dir / "stub.md"
    md.write_text("# book", encoding="utf-8")
    state = {"errors": [], "run_dir": str(tmp_path)}
    N._excel_html_fallback(state, parse_dir, tmp_path / "stub.xlsx", md)

    assert calls["n"] == 1


def test_html_fallback_reuses_existing_file(tmp_path, html_stub):
    """既にある保険 HTML は作り直さない。"""
    N, parse_dir, calls = html_stub

    md = parse_dir / "reuse.md"
    md.write_text("", encoding="utf-8")
    (parse_dir / "reuse.html").write_text("<table></table>", encoding="utf-8")
    state = {"errors": [], "run_dir": str(tmp_path)}
    N._excel_html_fallback(state, parse_dir, tmp_path / "reuse.xlsx", md)

    assert calls["n"] == 0
    assert state["excel_html_path"].endswith("reuse.html")


def test_html_fallback_reachable_from_vision_route():
    """視覚ルートは以前ここへ来る前に return していた（＝永久に空だった）。"""
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    # 視覚ルート側と通常側の両方から呼ばれていること
    assert src.count("_excel_html_fallback(state, parse_dir, input_path, md_path)") == 2
