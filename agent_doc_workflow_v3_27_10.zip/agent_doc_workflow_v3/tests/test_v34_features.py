"""v3.4 测试：模板注册表 / 反馈飞轮 / 版本历史 / 持久化队列 / 建站 agent / 流式。"""
import json
import sys
import time
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.config import AppConfig
from app.contract import UNKNOWN
from app import feedback as fb
from app.template_registry import get_registry
from app.versions import list_versions, snapshot


# ----------------------------------------------------------------------
# 1. 模板注册表
# ----------------------------------------------------------------------

def test_registry_lists_three_templates():
    ids = {t["id"] for t in get_registry().list()}
    assert {"case", "tech_report", "bulk_requests"} <= ids


def test_registry_all_templates_verified():
    assert get_registry().verify_all() == {}, "所有模板的 j2 变量必须匹配其动态契约"


def test_dynamic_model_defaults_and_records():
    spec = get_registry().get("tech_report")
    m = spec.model()
    assert m.report_title == UNKNOWN and m.objective == [UNKNOWN]
    spec2 = get_registry().get("bulk_requests")
    m2 = spec2.model.model_validate({"sheet_title": "上期台帳",
                                     "cases": [{"case_name": "X", "requester": "Y",
                                                "request": "R", "result": "OK", "period": "4月"}]})
    assert m2.cases[0].result == "OK"
    assert spec2.title_of(m2.model_dump()) == "上期台帳"


def _mock_for(template_id):
    """通用 mock：证据按模板类别返回，摘要按模板 skeleton 填充。"""
    spec = get_registry().get(template_id)

    def fill(node):
        if isinstance(node, dict):
            return {k: fill(v) for k, v in node.items()}
        if isinstance(node, list):
            return [fill(node[0])] if node else []
        if isinstance(node, float):
            return 0.9
        return "テスト値X"

    def handler(system, user):
        if "文書整理エージェント" in system:
            return {"evidence": [{"category": c, "content": f"{c} の証拠テスト値X",
                                  "confidence": 0.9} for c in spec.categories[:8]]}
        if "視覚" in system:
            return {"has_useful_visual_info": False, "visual_type": "unknown",
                    "readable_text": [], "visual_summary": "", "key_facts": [],
                    "possible_relevance": [], "confidence": 0}
        if "匿名化エージェント" in system:
            return json.loads(user)
        return fill(spec.skeleton())
    return handler


DOC = ("# 解析評価レポート\n目的は冷却効率の改善。手法は FloEFD による熱流体解析。"
       "条件：流量 2L/min、外気 25℃。結果として圧力損失が 12% 低減。"
       "考察と結論：フィン形状の変更が有効。期間は2026年2月。")


def _run(tmp_path, template_id):
    from app.graph import run_workflow
    from app.llm_client import LocalLLMClient
    doc = tmp_path / "doc.md"
    doc.write_text(DOC, encoding="utf-8")
    config = AppConfig()
    config.paths.out_dir = str(tmp_path / "out")
    config.llm.mock = True
    llm = LocalLLMClient(base_url="", api_key="", mock=True,
                         mock_handler=_mock_for(template_id))
    return run_workflow(str(doc), config, llm, template_id=template_id), config


def test_e2e_tech_report_template(tmp_path):
    final, _ = _run(tmp_path, "tech_report")
    run_dir = Path(final["run_dir"])
    manifest = json.loads((run_dir / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["template_id"] == "tech_report"
    md = (run_dir / "case_summary.md").read_text(encoding="utf-8")
    assert "## 目的 (Objective)" in md and "テスト値X" in md
    js = json.loads((run_dir / "case_summary.json").read_text(encoding="utf-8"))
    assert "objective" in js and "case_name" not in js  # 动态契约，不是 case 契约


def test_e2e_bulk_requests_records(tmp_path):
    final, _ = _run(tmp_path, "bulk_requests")
    run_dir = Path(final["run_dir"])
    js = json.loads((run_dir / "case_summary.json").read_text(encoding="utf-8"))
    assert isinstance(js["cases"], list) and len(js["cases"]) >= 1
    md = (run_dir / "case_summary.md").read_text(encoding="utf-8")
    assert "件" in md
    # RAG：records 型字段逐条成块
    rag = [json.loads(l) for l in
           (run_dir / "rag_internal.jsonl").read_text(encoding="utf-8").strip().split("\n")]
    assert any(r["metadata"]["section"].startswith("cases[") for r in rag)
    assert all(r["metadata"]["template_id"] == "bulk_requests"
               for r in rag if r["metadata"]["type"] == "summary_section")


# ----------------------------------------------------------------------
# 2. 反馈飞轮
# ----------------------------------------------------------------------

def test_flywheel_diff_examples_fewshot(tmp_path):
    config = AppConfig()
    config.paths.out_dir = str(tmp_path / "out")
    before = {"a": "x", "nested": {"b": ["1"], "c": "same"}}
    after = {"a": "y", "nested": {"b": ["1", "2"], "c": "same"}}
    n = fb.record_edit(config, "r1", "case", before, after)
    assert n == 2
    st = fb.stats(config, "case")
    assert st["total_edits"] == 2
    assert {d["field"] for d in st["top_edited_fields"]} == {"a", "nested.b"}

    assert fb.get_fewshot_block(config, "case") == ""       # 空库零成本
    fb.register_example(config, "r1", "case", {"case_name": "優良要約サンプル"})
    block = fb.get_fewshot_block(config, "case")
    assert "優良要約サンプル" in block and "良い例" in block
    assert fb.get_fewshot_block(config, "tech_report") == ""  # 按模板隔离


def test_fewshot_injected_into_summary_prompt(tmp_path):
    """飞轮闭环：注册的示例真的出现在 Agent 3 的 prompt 里。"""
    from app.graph import run_workflow
    from app.llm_client import LocalLLMClient
    config = AppConfig()
    config.paths.out_dir = str(tmp_path / "out")
    config.llm.mock = True
    fb.register_example(config, "prev", "case", {"case_name": "過去の優良要約マーカー"})

    seen = {"hit": False}
    base = _mock_for("case")

    def spy(system, user):
        if "要約エージェント" in system and "過去の優良要約マーカー" in user:
            seen["hit"] = True
        return base(system, user)

    doc = tmp_path / "d.md"
    doc.write_text(DOC, encoding="utf-8")
    llm = LocalLLMClient(base_url="", api_key="", mock=True, mock_handler=spy)
    run_workflow(str(doc), config, llm, template_id="case")
    assert seen["hit"], "few-shot 示例应注入摘要 prompt"


# ----------------------------------------------------------------------
# 3. 版本历史
# ----------------------------------------------------------------------

def test_versions_snapshot_and_list(tmp_path):
    run_dir = tmp_path / "run"
    run_dir.mkdir()
    (run_dir / "case_summary.json").write_text('{"case_name": "v1"}', encoding="utf-8")
    (run_dir / "case_summary.md").write_text("# v1", encoding="utf-8")
    d1 = snapshot(run_dir, note="pipeline")
    assert d1 and (d1 / "case_summary.md").exists()
    time.sleep(1.05)
    (run_dir / "case_summary.json").write_text('{"case_name": "v2"}', encoding="utf-8")
    snapshot(run_dir, note="hitl")
    vs = list_versions(run_dir)
    assert len(vs) == 2 and vs[0]["note"] == "hitl"       # 新的在前


def test_pipeline_creates_version_snapshot(tmp_path):
    final, _ = _run(tmp_path, "case")
    assert len(list_versions(final["run_dir"])) >= 1


# ----------------------------------------------------------------------
# 4. 建站 agent
# ----------------------------------------------------------------------

def test_site_builder_external_only_with_leak_gate(tmp_path):
    from app.ledger import Ledger
    from app.site_builder import build_site
    import yaml as _yaml

    config = AppConfig()
    config.paths.out_dir = str(tmp_path / "out")
    dict_path = tmp_path / "ng.yaml"
    dict_path.write_text(_yaml.safe_dump(
        {"categories": {"client_names": {"replacement_template": "{alias}社",
                                         "terms": ["秘密機械株式会社"]}}},
        allow_unicode=True), encoding="utf-8")
    config.redaction.dictionary_path = str(dict_path)

    lg = Ledger(tmp_path / "ledger.sqlite3")
    # run A：有社外版（干净）
    ra = tmp_path / "out" / "runs" / "run_a"
    ra.mkdir(parents=True)
    (ra / "case_summary_external.json").write_text(
        json.dumps({"case_name": "A社 冷却解析", "request_details": {"requester": "A社"},
                    "action_results": {"effects": ["工数30%削減"]}, "evidence": []},
                   ensure_ascii=False), encoding="utf-8")
    lg.upsert({"run_id": "run_a", "input_name": "a.pdf", "case_name": "A社 冷却解析",
               "requester": "", "target": "", "support_type": "", "period": "",
               "effects": "", "state": "done", "warnings": "", "has_external": 1,
               "run_dir": str(ra), "template_id": "case"})
    # run B：只有社内版 -> 必须不出现在站点
    rb = tmp_path / "out" / "runs" / "run_b"
    rb.mkdir(parents=True)
    (rb / "case_summary.json").write_text('{"case_name": "内部のみ案件"}', encoding="utf-8")
    lg.upsert({"run_id": "run_b", "input_name": "b.pdf", "case_name": "内部のみ案件",
               "requester": "", "target": "", "support_type": "", "period": "",
               "effects": "", "state": "done", "warnings": "", "has_external": 0,
               "run_dir": str(rb), "template_id": "case"})

    report = build_site(config, lg, llm=None)
    assert report["aborted"] is None and report["cases"] == 1
    site = tmp_path / "out" / "site"
    index = (site / "index.html").read_text(encoding="utf-8")
    assert "A社 冷却解析" in index and "内部のみ" not in index
    assert (site / "cases" / "run_a.html").exists()

    # 泄漏闸：社外 JSON 被污染 -> 构建中止且不落盘新页面
    (ra / "case_summary_external.json").write_text(
        json.dumps({"case_name": "秘密機械株式会社 案件", "evidence": []},
                   ensure_ascii=False), encoding="utf-8")
    lg.upsert({"run_id": "run_a", "input_name": "a.pdf", "case_name": "秘密機械株式会社 案件",
               "requester": "", "target": "", "support_type": "", "period": "",
               "effects": "", "state": "done", "warnings": "", "has_external": 1,
               "run_dir": str(ra), "template_id": "case"})
    report2 = build_site(config, lg, llm=None)
    assert report2["aborted"] and "leaks" in report2
    assert "秘密機械" not in (site / "index.html").read_text(encoding="utf-8")


# ----------------------------------------------------------------------
# 5. Web：模板上传 / 持久化队列 / 流式对话 / HITL 飞轮联动
# ----------------------------------------------------------------------

@pytest.fixture()
def web_client(tmp_path, monkeypatch):
    import app.webapp as W
    from app.ledger import Ledger
    from fastapi.testclient import TestClient
    monkeypatch.setattr(W.config.llm, "mock", True)
    monkeypatch.setattr(W.config.paths, "out_dir", str(tmp_path / "out"))
    monkeypatch.setattr(W.config.paths, "inbox_dir", str(tmp_path / "inbox"))
    monkeypatch.setattr(W.config.ledger, "db_path", str(tmp_path / "ledger.sqlite3"))
    monkeypatch.setattr(W, "_ledger", Ledger(tmp_path / "ledger.sqlite3"))
    W._runs.clear()
    return TestClient(W.app)


def _wait(client, rid):
    for _ in range(80):
        st = client.get(f"/api/runs/{rid}").json()["state"]
        if st in ("done", "failed"):
            return st
        time.sleep(0.25)
    return "timeout"


def test_templates_endpoint_and_upload_with_template(web_client):
    tpls = web_client.get("/api/templates").json()
    assert {"case", "tech_report", "bulk_requests"} <= {t["id"] for t in tpls}
    r = web_client.post("/api/runs",
                        files=[("files", ("rep.md", DOC.encode(), "text/markdown"))],
                        data={"template_id": "tech_report"})
    rid = r.json()["run_id"]
    assert _wait(web_client, rid) == "done"
    s = web_client.get(f"/api/runs/{rid}/summary").json()
    assert "objective" in s
    bad = web_client.post("/api/runs",
                          files=[("files", ("x.md", b"# x", "text/markdown"))],
                          data={"template_id": "no_such"})
    assert bad.status_code == 400


def test_persistent_queue_survives(web_client, tmp_path):
    import app.webapp as W
    # 模拟：上次崩溃时残留 queued 任务
    doc = tmp_path / "inbox" / "leftover_abc12345.md"
    doc.parent.mkdir(parents=True, exist_ok=True)
    doc.write_text(DOC, encoding="utf-8")
    W._job_set("leftover_abc12345", "queued", str(doc), "leftover.md", "case")
    W._runs.pop("leftover_abc12345", None)  # 内存中不存在（=重启后）

    n = W._requeue_pending()
    assert n == 1
    assert _wait(web_client, "leftover_abc12345") == "done"
    with W._jobs_conn() as c:
        st = c.execute("SELECT status FROM jobs WHERE run_id='leftover_abc12345'").fetchone()[0]
    assert st == "done"


def test_hitl_edit_records_flywheel_and_version(web_client):
    import app.webapp as W
    r = web_client.post("/api/runs",
                        files=[("files", ("fw.md", DOC.encode(), "text/markdown"))])
    rid = r.json()["run_id"]
    assert _wait(web_client, rid) == "done"
    s = web_client.get(f"/api/runs/{rid}/summary").json()
    s["action_results"]["effects"] = ["人手修正の効果"]
    resp = web_client.post(f"/api/runs/{rid}/summary", json=s).json()
    assert resp["recorded_changes"] >= 1
    stats = web_client.get("/api/feedback/stats?template_id=case").json()
    assert stats["total_edits"] >= 1
    vs = web_client.get(f"/api/runs/{rid}/versions").json()
    assert any(v["note"] == "hitl" for v in vs)
    # 良い例登録 -> 库里可见
    assert web_client.post(f"/api/runs/{rid}/register_example").status_code == 200
    assert web_client.get("/api/feedback/stats?template_id=case").json()["registered_examples"] >= 1


def test_ui_features_defaults_and_overrides(web_client, monkeypatch):
    import app.webapp as W
    feats = web_client.get("/api/ui").json()["features"]
    assert feats["chat_tab"] is True and feats["ledger_card"] is True
    assert feats["site"] is False                      # 跟随 site.enabled
    # config.yaml 覆盖某组
    monkeypatch.setattr(W.config.ui, "features", {"chat_tab": False, "unknown_key": False})
    feats = web_client.get("/api/ui").json()["features"]
    assert feats["chat_tab"] is False
    assert "unknown_key" not in feats                  # 未注册键被忽略（防拼写错误静默生效）
    # robot 旧字段仍然有效
    monkeypatch.setattr(W.config.ui, "robot_animation", False)
    assert web_client.get("/api/ui").json()["features"]["robot_animation"] is False


def test_site_disabled_by_default(web_client):
    assert web_client.get("/api/ui").json()["site_enabled"] is False
    assert web_client.post("/api/site/build").status_code == 403
    assert web_client.get("/api/site/preview/index.html").status_code == 403


def test_site_enabled_via_config(web_client, monkeypatch):
    import app.webapp as W
    monkeypatch.setattr(W.config.site, "enabled", True)
    assert web_client.get("/api/ui").json()["site_enabled"] is True
    rep = web_client.post("/api/site/build").json()
    assert "aborted" in rep  # 空台账 -> 正常返回构建报告（无案件而中止）


def test_chat_stream_endpoint(web_client):
    r = web_client.post("/api/runs",
                        files=[("files", ("st.md", DOC.encode(), "text/markdown"))])
    rid = r.json()["run_id"]
    assert _wait(web_client, rid) == "done"
    with web_client.stream("POST", f"/api/runs/{rid}/chat/stream",
                           json={"messages": [{"role": "user", "content": "効果は？"}]}) as resp:
        assert resp.status_code == 200
        body = "".join(resp.iter_text())
    assert "data:" in body and '"done": true' in body


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
