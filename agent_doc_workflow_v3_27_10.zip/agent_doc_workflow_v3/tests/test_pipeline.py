"""
测试套件。运行: python -m pytest tests/ -v
无需 GPU / llama.cpp / Docling（e2e 用 mock LLM + .md 输入）。
"""
import json
import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.config import AppConfig
from app.contract import CaseSummary, Evidence, EvidenceCategory, UNKNOWN
from app.evidence import aggregate_evidence, dedupe_evidence
from app.graph import run_workflow, route_after_validation
from app.llm_client import LocalLLMClient
from app.render import render_markdown, verify_template


# ----------------------------------------------------------------------
# 1. 契约 <-> 模板一致性（v1 bug 的直接回归测试）
# ----------------------------------------------------------------------

def test_template_variables_match_contract():
    template = PROJECT_ROOT / "templates" / "case_summary_v2.md.j2"
    bad = verify_template(str(template))
    assert not bad, f"模板引用了契约中不存在的变量: {bad}"


def test_render_full_data_no_unknown_leak():
    summary = CaseSummary(
        case_name="テスト案件",
        request_details=dict(
            requester="設計部", target_product_or_system="レンズX",
            background=["背景1"], client_issues=["課題1"], scope_of_request=["依頼1"],
        ),
        action_results=dict(
            support_type="解析代行", tools_environment=["FloEFD"],
            period="2026年1月", findings=["事実1"], effects=["効果1"],
        ),
        evidence=["ev_001"],
    ).finalize_titles()

    out = PROJECT_ROOT / "out" / "_test_render.md"
    text = render_markdown(summary, str(PROJECT_ROOT / "templates" / "case_summary_v2.md.j2"), str(out))
    # 数据齐全时，任何字段都不应 fallback 成"確認できず"
    assert UNKNOWN not in text
    assert "設計部" in text and "FloEFD" in text and "効果1" in text
    assert "明記なし" not in text  # v1 的幽灵词不应再出现


def test_schema_generated_from_contract():
    schema = CaseSummary.json_schema_for_validation()
    props = schema.get("properties", {})
    assert set(props) == {"case_name", "request_details", "action_results", "evidence"}


# ----------------------------------------------------------------------
# 2. 证据聚合
# ----------------------------------------------------------------------

def test_dedupe_keeps_highest_confidence():
    evs = [
        Evidence(content="FloEFD を使用", category=EvidenceCategory.tool, confidence=0.5),
        Evidence(content="FloEFDを使用", category=EvidenceCategory.tool, confidence=0.9),  # 空白差のみ
        Evidence(content="別の証拠", category=EvidenceCategory.tool, confidence=0.7),
    ]
    out = dedupe_evidence(evs)
    assert len(out) == 2
    assert max(e.confidence for e in out if "FloEFD" in e.content) == 0.9


def test_aggregate_filters_and_budgets():
    evs = [Evidence(content=f"証拠{i} " + "x" * 200, category=EvidenceCategory.finding,
                    confidence=0.2 if i % 2 else 0.9) for i in range(30)]
    out = aggregate_evidence(evs, min_confidence=0.3, max_per_category=5, max_total_chars=2000)
    assert all(e.confidence >= 0.3 for e in out)
    assert len(out) <= 5
    assert sum(len(e.content) for e in out) < 2000


# ----------------------------------------------------------------------
# 3. 校验 -> 修复条件边
# ----------------------------------------------------------------------

def test_route_ok_goes_render():
    state = {"validation": {"ok": True}, "repair_attempts": 0, "_max_repair_attempts": 2}
    assert route_after_validation(state) == "render"


def test_route_invalid_goes_repair_then_render():
    state = {"validation": {"ok": False}, "repair_attempts": 0, "_max_repair_attempts": 2}
    assert route_after_validation(state) == "repair_summary"
    state["repair_attempts"] = 2
    assert route_after_validation(state) == "render"


# ----------------------------------------------------------------------
# 4. 端到端（mock LLM，含"第一次输出坏 JSON -> 修复回路救回来"场景）
# ----------------------------------------------------------------------

def _make_mock(fail_first_summary: bool):
    calls = {"summary": 0}

    def handler(system: str, user: str):
        if "証拠情報" in system or "証拠を抽出" in user:
            return {"evidence": [
                {"category": "requester", "content": "光学設計部からの依頼", "confidence": 0.9},
                {"category": "tool", "content": "FloEFD 2024", "confidence": 0.85},
                {"category": "effect", "content": "解析工数を30%削減", "confidence": 0.8},
            ]}
        if "視覚" in system:
            return {"has_useful_visual_info": False, "visual_type": "unknown",
                    "readable_text": [], "visual_summary": "", "key_facts": [],
                    "possible_relevance": [], "confidence": 0.0}
        # 摘要 / 修复
        calls["summary"] += 1
        good = {
            "case_name": "光学解析支援",
            "request_details": {
                "requester": "光学設計部", "target_product_or_system": "レンズユニット",
                "background": ["歩留まり低下"], "client_issues": ["解析リソース不足"],
                "scope_of_request": ["流体解析の代行"],
            },
            "action_results": {
                "support_type": "解析代行", "tools_environment": ["FloEFD 2024"],
                "period": "2026年1月", "findings": ["特定条件で異常"], "effects": ["解析工数を30%削減"],
            },
            "evidence": ["text_chunk_0001_ev_001"],
        }
        if fail_first_summary and calls["summary"] == 1:
            bad = dict(good)
            bad["request_details"] = "壊れた文字列"  # 结构性错误：应为 object
            bad["evidence"] = {"oops": True}        # 应为数组
            return bad
        return good

    return handler


def _run_e2e(tmp_path: Path, fail_first: bool):
    doc = tmp_path / "sample_case.md"
    doc.write_text(
        "# 光学解析支援の依頼\n\n光学設計部より、レンズユニットの流体解析代行の依頼。\n"
        "使用ツール: FloEFD 2024。効果: 解析工数を30%削減。\n",
        encoding="utf-8",
    )
    config = AppConfig()
    config.paths.out_dir = str(tmp_path / "out")
    config.llm.mock = True
    llm = LocalLLMClient(base_url="", api_key="", mock=True, mock_handler=_make_mock(fail_first))
    return run_workflow(str(doc), config, llm)


def test_e2e_happy_path(tmp_path):
    final = _run_e2e(tmp_path, fail_first=False)
    assert final["validation"]["ok"]
    md = Path(final["output_markdown"]).read_text(encoding="utf-8")
    assert "光学設計部" in md and "FloEFD 2024" in md and "30%削減" in md
    assert UNKNOWN not in md
    js = json.loads(Path(final["output_json"]).read_text(encoding="utf-8"))
    assert js["request_details"]["main_title"].startswith("依頼対応事例")


def test_e2e_repair_loop_recovers_bad_json(tmp_path):
    final = _run_e2e(tmp_path, fail_first=True)
    # 第一次摘要输出结构损坏 -> validate 失败 -> repair -> 第二次输出正常
    assert final["repair_attempts"] >= 1
    assert final["validation"]["ok"]
    md = Path(final["output_markdown"]).read_text(encoding="utf-8")
    assert "光学設計部" in md


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
