"""v3.26：単体アップロードでも参照台帳が効くようにする。

利用者報告：フォルダ一括処理では台帳が効くのに、単体アップロードでは効かない。

原因は 2 つ重なっていた。

  1. ファイル選択の input に `webkitdirectory` が無く、`webkitRelativePath`
     が常に空だった。v3.21 で「ブラウザから相対パスを送る」実装を入れたが、
     そもそもブラウザが値を持っていなかった。
  2. Windows の区切り（円記号）を Path() が区切りと見ないため、
     サーバが Linux だと完全パスが丸ごと 1 つのファイル名として扱われ、
     フォルダ名照合に到達しなかった。

一括処理はサーバ側でフォルダを走査して rel を作るので影響が無く、
「同じ機能が入口によって効いたり効かなかったりする」状態になっていた。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

openpyxl = pytest.importorskip("openpyxl")


@pytest.fixture()
def ledger(tmp_path):
    from app.reference_index import build_index, clear_cache

    clear_cache()
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["管理No", "依頼者", "件名"])
    ws.append(["2023-0450", "製造二課 田中", "アルミ外材硬さ試験"])
    ws.append(["2023-0600", "品証 鈴木", "めっき膜厚測定"])
    p = tmp_path / "台帳.xlsx"
    wb.save(p)
    return build_index([str(p)])


# ======================================================================
# 1. Windows のパス区切りを解釈できること
# ======================================================================

@pytest.mark.parametrize("path", [
    r"\\srv\解析\2023\アルミ外材硬さ試験\速報2.xlsx",          # UNC
    r"C:\Users\yang\Desktop\解析\アルミ外材硬さ試験\メモ.docx",  # ローカル
    "解析依頼/アルミ外材硬さ試験/速報2.xlsx",                    # スラッシュ
    r"解析依頼\アルミ外材硬さ試験\速報2.xlsx",                   # 混在
])
def test_folder_name_extracted_from_any_path_style(ledger, path):
    """区切りが円記号でも、フォルダ名で照合できること。

    Linux 上の Path() は円記号を区切りと見ないので、揃えずに渡すと
    完全パスが丸ごと 1 つのファイル名になり照合に失敗する。
    """
    m = ledger.match(path)
    assert m.ok, f"{path} で照合できていない"
    assert m.row.values["管理No"] == "2023-0450"
    assert "フォルダ名" in m.reason


def test_unrelated_folder_still_finds_nothing(ledger):
    assert ledger.match(r"\\srv\別案件\無関係.xlsx").ok is False


# ======================================================================
# 2. 照合テストが完全パスを受け付けること
# ======================================================================

def test_probe_accepts_full_path(tmp_path, monkeypatch):
    """ファイル名だけで試すと本番と条件が食い違い、テストの意味が薄れる。"""
    from fastapi.testclient import TestClient

    import app.webapp as W
    from app.reference_index import clear_cache

    refdir = tmp_path / "refs"
    refdir.mkdir()
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["管理No", "依頼者", "件名"])
    ws.append(["2023-0450", "製造二課 田中", "アルミ外材硬さ試験"])
    wb.save(refdir / "台帳.xlsx")
    monkeypatch.setattr(W, "_reference_dir", lambda: refdir)
    clear_cache()

    c = TestClient(W.app)
    r = c.get("/api/references/probe",
              params={"filename": r"\\srv\解析\アルミ外材硬さ試験\速報2.xlsx"}).json()
    assert r["ok"] is True
    assert "フォルダ名" in r["reason"]


# ======================================================================
# 3. UI 側：相対パスを取得する手段があること
# ======================================================================

def _html() -> str:
    return (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(
        encoding="utf-8")


def test_folder_picker_exists():
    """webkitdirectory が無いと webkitRelativePath は常に空になる。

    v3.21 で「相対パスを送る」実装を入れたのに効かなかった原因はこれ。
    """
    html = _html()
    assert "webkitdirectory" in html
    assert 'id="file-dir"' in html


def test_dropped_folders_are_walked():
    """dataTransfer.files はフォルダを展開しない。entry API で辿る。"""
    html = _html()
    assert "webkitGetAsEntry" in html
    assert "createReader" in html


def test_upload_sends_relative_path_from_three_sources():
    html = _html()
    assert "(relPaths && relPaths[i]) || f.webkitRelativePath || \"\"" in html


def test_probe_ui_asks_for_full_path():
    html = _html()
    assert "フォルダを含む完全パス" in html
