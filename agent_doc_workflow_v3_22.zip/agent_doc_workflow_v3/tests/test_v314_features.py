"""v3.14：参照台帳（年度別の依頼一覧 Excel）。

決定事項（利用者の選択）：
  1A … 要約前に証拠として注入し、要約後はコードのみで食い違いを検出する
  2B … 確度が低くても最良の 1 行を採用し「要確認」と注記する
        ただし **同点（どれか分からない）は採用しない**——これは確度の低さ
        ではなくコイン投げなので、候補提示に留める
  3C … 常駐ライブラリを主とし、run 単位の追加指定も許す
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

openpyxl = pytest.importorskip("openpyxl")


# ======================================================================
# 台帳の作成ヘルパ
# ======================================================================

def _make_ledger(path: Path, rows, *, title_row=True, headers=None):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "2026年度"
    if title_row:
        ws.append(["2026年度 解析依頼一覧"])   # 表頭ではないタイトル行
    ws.append(headers or ["依頼番号", "依頼日", "タイトル", "依頼理由",
                          "依頼内容", "依頼者", "依頼目的", "報告書パス"])
    for r in rows:
        ws.append(r)
    wb.save(path)
    return path


@pytest.fixture()
def ledger(tmp_path):
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "2026年度_依頼一覧.xlsx", [
        ["2026-0012", "2026/04/10", "配管圧損の低減検討", "歩留り低下が続いたため",
         "形状A/BのCFD比較", "製造技術部 山田太郎", "圧損20%低減の可否判断",
         r"\\srv\解析\2026\2026-0012_配管圧損_報告書.pptx"],
        ["2026-0034", "2026/05/22", "筐体放熱評価", "客先要求", "熱流体解析",
         "設計二課 佐藤", "温度上限の確認",
         r"\\srv\解析\2026\2026-0034_筐体放熱_報告書.pptx"],
    ])
    return build_index([str(p)])


# ======================================================================
# 1. 表の読み取り
# ======================================================================

def test_header_row_autodetected_below_title_row(ledger):
    """1 行目がタイトル行の台帳が実務では普通。表頭を自動で探す。

    v3.17：表頭の語彙にも列の役割判定にも依存しない。表頭の行だけを推定する。
    """
    sheet = ledger.stats()["sources"][0]["sheets"][0]
    assert sheet["header_row"] == 2
    # 表頭は全部そのまま持つ（v3.17：列の役割判定は行わない）
    assert "依頼者" in sheet["headers"]
    assert "報告書パス" in sheet["headers"]


def test_rows_loaded(ledger):
    assert ledger.stats()["rows"] == 2


def test_broken_workbook_does_not_raise(tmp_path):
    """1 冊壊れていても他の台帳は使えること。"""
    from app.reference_index import ReferenceIndex

    bad = tmp_path / "broken.xlsx"
    bad.write_bytes(b"not an excel file")
    idx = ReferenceIndex()
    res = idx.add_workbook(str(bad))
    assert res["ok"] is False
    assert idx.errors


# ======================================================================
# 2. 照合（段階と確からしさ）
# ======================================================================

@pytest.mark.parametrize("filename,method", [
    ("2026-0012_配管圧損_報告書.pptx", "exact_filename"),
    ("2026-0012_配管圧損_報告書_ver2.pptx", "normalized_filename"),
    ("2026-0012_配管圧損_報告書(1).pptx", "normalized_filename"),
    ("2026-0034_別名で保存した報告.pptx", "request_number"),
])
def test_match_methods(ledger, filename, method):
    m = ledger.match(filename)
    assert m.ok, f"{filename} が照合できていない"
    assert m.method == method


def test_fullwidth_digits_absorbed(ledger):
    """日本語のファイル名は全角英数が平気で混ざる。"""
    m = ledger.match("２０２６-0034_筐体放熱_報告書.pptx")
    assert m.ok
    assert m.row.values["依頼者"] == "設計二課 佐藤"


def test_no_match_returns_cleanly(ledger):
    m = ledger.match("まったく無関係な資料.pptx")
    assert m.ok is False
    assert m.row is None
    assert not m.candidates


def test_request_number_regex_does_not_eat_plain_dates():
    """\\b は使えない（アンダースコアも単語文字）。日付を番号と誤認しないこと。"""
    from app.reference_index import extract_request_no

    assert extract_request_no("2026-0034_別名.pptx") == "2026-0034"
    assert extract_request_no("R07-0123_報告.pptx") == "R07-0123"
    assert extract_request_no("20260401_日報.pptx") == ""
    assert extract_request_no("報告書.pptx") == ""


# ======================================================================
# 3. 曖昧なときは採用しない（2B の境界）
# ======================================================================

def test_ambiguous_match_is_refused_not_guessed(tmp_path):
    """同名の報告書が別案件に二つ——部署別フォルダでは普通に起きる。

    「確度が低い」のではなく「どちらか分からない」。一方を選ぶのは
    コイン投げで、外すと他人の依頼者・依頼日を自信満々に要約へ書き込む。
    確認できずより悪いので、候補提示に留める。
    """
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "台帳.xlsx", [
        ["2026-0100", "2026/04/01", "第一四半期評価", "", "", "A部 田中", "",
         r"\\srv\A部\評価報告書.pptx"],
        ["2026-0200", "2026/07/01", "第二四半期評価", "", "", "B部 鈴木", "",
         r"\\srv\B部\評価報告書.pptx"],
    ])
    idx = build_index([str(p)])
    m = idx.match("評価報告書.pptx")

    assert m.ok is False, "同点で 1 行を選んではいけない"
    assert len(m.candidates) == 2
    assert "確定できません" in m.reason


def test_partial_can_be_disabled(ledger):
    """部分一致は既定で有効だが、切れること。"""
    m = ledger.match("配管圧損の低減検討について.pptx", allow_partial=False)
    assert m.ok is False
    m2 = ledger.match("配管圧損の低減検討について.pptx", allow_partial=True)
    assert m2.ok and m2.method == "partial"


def test_partial_picks_best_and_keeps_runners_up(tmp_path):
    """部分一致では複数当たるのが普通。捨てずに採点して最良を採る。

    v3.18 までは「複数なら不採用」で通していたが、台帳に報告書の
    ファイル名が載っていない現場ではそれだと永久に何も引けない。
    """
    from app.reference_index import build_index, clear_cache

    clear_cache()
    # 同じ案件が台帳の 2 行に分かれている（初回と再解析など）。
    # どちらも同程度に該当するので、片方を選びつつ他方を残す。
    p = _make_ledger(tmp_path / "compete.xlsx", [
        ["2026-0034", "2026/05/22", "筐体放熱評価", "", "", "佐藤", "", ""],
        ["2026-0035", "2026/05/30", "筐体放熱評価", "再解析", "", "佐藤", "", ""],
    ])
    m = build_index([str(p)]).match("筐体放熱評価_報告書.pptx")

    assert m.ok and m.method == "partial"
    assert m.row.values["依頼番号"] == "2026-0034"
    assert m.candidates, "次点を捨ててはいけない（人が選び直せるように）"


def test_partial_confidence_stays_below_exact(ledger):
    """部分一致を完全一致と同じ確度にしてはいけない。"""
    exact = ledger.match("2026-0012_配管圧損_報告書.pptx")
    partial = ledger.match("2026年度_配管圧損の低減検討_報告書.pptx")
    assert exact.confidence == 1.0
    assert partial.ok and partial.confidence <= 0.80
    assert partial.confirmed is False


def test_partial_rejects_unrelated_names(ledger):
    m = ledger.match("全く無関係な資料.pptx")
    assert m.ok is False


def test_ledger_evidence_confidence_is_below_source_document(ledger):
    """台帳は補助資料。報告書そのものより確度を落とす。

    記載が古いことも、部分一致で行がずれていることもある。
    食い違ったときに本文側が優先されるよう、最初から差を付ける。
    """
    from app.nodes import _reference_to_evidence

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    evs = _reference_to_evidence(m, confidence_factor=0.9)
    assert evs
    assert all(e.confidence < m.confidence for e in evs)
    assert all(abs(e.confidence - m.confidence * 0.9) < 1e-6 for e in evs)


# ======================================================================
# 4. 確度に応じた注記（2B）
# ======================================================================

def test_confirmed_flag_tracks_threshold(ledger):
    from app.reference_index import CONFIRMED_THRESHOLD

    high = ledger.match("2026-0012_配管圧損_報告書.pptx")
    assert high.confidence >= CONFIRMED_THRESHOLD
    assert high.confirmed is True


def test_unconfirmed_match_is_tagged_in_evidence(ledger, monkeypatch):
    """確度が足りない照合から作った証拠には【要確認】が付くこと。"""
    from app.nodes import _reference_to_evidence

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    m.confidence = 0.88          # path_suffix 相当まで落とす
    evs = _reference_to_evidence(m)

    assert evs
    assert all("【要確認】" in e.content for e in evs)


def test_confirmed_match_has_no_tag(ledger):
    from app.nodes import _reference_to_evidence

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    evs = _reference_to_evidence(m)
    assert evs and not any("【要確認】" in e.content for e in evs)


# ======================================================================
# 5. 証拠への変換（1A の前半）
# ======================================================================

def test_evidence_carries_ledger_origin_and_source(ledger):
    """要約の主張が報告書由来か台帳由来かは読み手にとって意味が違う。"""
    from app.nodes import _reference_to_evidence

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    evs = _reference_to_evidence(m)

    assert all(e.origin == "ledger" for e in evs)
    assert all("参照台帳" in e.source for e in evs)
    # 行まで特定できる（後から現物に当たれる）
    assert all(":" in e.source for e in evs)


def test_evidence_carries_every_column_with_its_raw_header(ledger):
    """v3.15：語彙表に無い列も含め、全列が生の表頭のまま証拠になること。

    v3.14 は語彙表に載っている列だけを拾っていたので、「使用ソフト」
    「特記事項」のような列が黙って消えていた。人が手で埋めた情報を
    こちらの都合で無かったことにするのは誤り。
    """
    from app.nodes import _reference_to_evidence

    blob = " ".join(e.content for e in _reference_to_evidence(
        ledger.match("2026-0012_配管圧損_報告書.pptx")))
    for head in ("依頼者", "依頼理由", "依頼内容", "依頼目的", "依頼日", "タイトル"):
        assert f"「{head}」" in blob, f"{head} 列が証拠に入っていない"
    # 照合鍵そのもの（保存パス）は要約に不要なので入れない
    assert "報告書パス" not in blob


def test_unknown_columns_are_not_dropped(tmp_path):
    """語彙表に一切無い表頭ばかりの台帳でも、情報が落ちないこと。"""
    from app.nodes import _reference_to_evidence
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "変な表頭.xlsx", [
        ["2026-0700", "製造技術部", "配管検討", "FloEFD", "客先立会あり",
         r"\\srv\2026-0700_配管検討.pptx"],
    ], title_row=False,
        headers=["管理No", "起案部門", "案件テーマ", "使用ソフト", "特記事項",
                 "成果物の格納場所"])
    idx = build_index([str(p)])
    blob = " ".join(e.content for e in _reference_to_evidence(
        idx.match("2026-0700_配管検討.pptx")))
    for head in ("起案部門", "案件テーマ", "使用ソフト", "特記事項"):
        assert f"「{head}」" in blob, f"語彙外の列 {head} が消えている"


def test_empty_cells_produce_no_evidence(tmp_path):
    from app.nodes import _reference_to_evidence
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "sparse.xlsx", [
        ["2026-0500", "", "表題のみ", "", "", "", "", r"\\srv\sparse_報告書.pptx"],
    ])
    idx = build_index([str(p)])
    evs = _reference_to_evidence(idx.match("sparse_報告書.pptx"))
    contents = " ".join(e.content for e in evs)
    assert "依頼者" not in contents, "空欄から証拠を作ってはいけない"


# ======================================================================
# 6. 集約で落とされないこと
# ======================================================================

def test_reference_evidence_bypasses_selection():
    """台帳の証拠が確度フィルタや類別上限で落ちないこと。

    「台帳に書いてあるのに要約に出ない」は一番間の抜けた失敗。
    """
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert 'state.get("reference_evidence"' in src
    assert "agg = ref + agg" in src


# ======================================================================
# 7. 食い違い検出（1A の後半・LLM 不使用）
# ======================================================================

def test_conflict_detected_when_summary_omits_ledger_value(ledger):
    from app.nodes import _reference_conflicts

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    summary = {"case_name": "配管圧損の低減検討",
               "detail": {"finding": ["圧損 12.3 kPa"]}}
    conflicts = _reference_conflicts(summary, m.to_dict())

    fields = {c["field"] for c in conflicts}
    assert "依頼者" in fields, "台帳の依頼者が要約に無いなら指摘すべき"
    # どちらが正しいかは判定しない
    assert all("要確認" in c["note"] for c in conflicts)


def test_no_conflict_when_summary_contains_values(ledger):
    from app.nodes import _reference_conflicts

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    summary = {"requester": "製造技術部 山田太郎",
               "background": "歩留り低下が続いたため",
               "scope": "形状A/BのCFD比較",
               "purpose": "圧損20%低減の可否判断",
               "date": "2026/04/10",
               "title": "配管圧損の低減検討",
               "no": "2026-0012"}
    assert _reference_conflicts(summary, m.to_dict()) == []


def test_conflict_check_skips_very_short_values(ledger):
    """「A」「1」のような短い値は誤検出の元なので見ない。"""
    from app.nodes import _reference_conflicts

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    m.row.cells = [("依頼者", "A")] + [c for c in m.row.cells if c[0] != "依頼者"]
    conflicts = _reference_conflicts({"x": "無関係"}, m.to_dict())
    assert "依頼者" not in {c["field"] for c in conflicts}


# ======================================================================
# 8. 結線と設定
# ======================================================================

def test_node_runs_before_first_llm_call():
    import inspect

    import app.graph as G

    src = inspect.getsource(G.build_graph)
    assert '"route_template", "lookup_reference"' in src
    assert '"lookup_reference", "prepare_html_text"' in src
    assert src.index('"lookup_reference"') < src.index('"extract_text_evidence"')


def test_run_workflow_accepts_per_run_paths():
    """3C：常駐ライブラリに **追加** できること（置き換えではない）。"""
    import inspect

    import app.graph as G

    sig = inspect.signature(G.run_workflow)
    assert "reference_paths" in sig.parameters
    src = inspect.getsource(G.run_workflow)
    assert '"reference_paths": list(reference_paths or [])' in src


def test_library_and_per_run_paths_are_merged():
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert 'paths = list(state.get("reference_paths") or [])' in src
    assert "paths.append(str(lib_path))" in src


def test_disabled_by_config_is_a_noop(tmp_path):
    from app.config import load_config

    wf = load_config().workflow
    assert isinstance(wf.reference_enabled, bool)
    assert isinstance(wf.reference_adopt_unconfirmed, bool)
    assert wf.reference_allow_partial is True, "台帳にファイル名が無い場合の本命"
    assert 0 < wf.reference_confidence_factor < 1.0, "台帳は元資料より確度を下げる"


def test_works_with_no_config_files_at_all():
    """v3.15：設定ファイルが 1 つも無いのが普通の状態。"""
    from app.reference_index import load_reference_specs

    specs = load_reference_specs()
    assert "default" in specs
    # 語彙表はもう存在しない
    assert not hasattr(specs["default"], "columns")
    assert not hasattr(specs["default"], "evidence_map")


# ======================================================================
# 9. 索引キャッシュ
# ======================================================================

def test_index_is_cached_between_calls(tmp_path):
    """一括処理で 100 件回すたびに数千行を読み直すのは無駄。"""
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "cache.xlsx", [
        ["2026-0700", "", "件名", "", "", "担当A", "", r"\\srv\cache_報告書.pptx"],
    ])
    a = build_index([str(p)])
    b = build_index([str(p)])
    assert a is b


def test_cache_key_changes_when_file_changes(tmp_path):
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = tmp_path / "mut.xlsx"
    _make_ledger(p, [["2026-0800", "", "旧", "", "", "旧担当", "", r"\\srv\mut.pptx"]])
    first = build_index([str(p)])
    _make_ledger(p, [["2026-0800", "", "新", "", "", "新担当", "", r"\\srv\mut.pptx"]])
    second = build_index([str(p)])
    assert first is not second, "台帳を差し替えたら索引も作り直すこと"


# ======================================================================
# 10. v3.17：Excel の Ctrl+F と同じ語義（列の役割を先に決めない）
# ======================================================================
#
# v3.14 は表頭の語彙表、v3.15/v3.16 は「どの列が保存パス列か」の形状判定に
# 頼っていた。どちらも前提が余計だった——人が台帳から報告書を探すとき、
# 列の役割を判定してから探したりしない。全体を検索して当たった行を読む。
# ファイル名は拡張子付きで十分に独特なので、それで足りる。

@pytest.mark.parametrize("headers,row,query,method", [
    # 保存パス列
    (["管理No", "部署", "格納先"],
     ["2026-0012", "製造", r"\\srv\解析\2026\2026-0012_配管圧損.pptx"],
     "2026-0012_配管圧損.pptx", "exact_filename"),
    # マクロ有 Excel（利用者自身の台帳形式）
    (["番号", "担当", "成果物"],
     ["2026-0013", "佐藤", "2026-0013_集計表.xlsm"],
     "2026-0013_集計表.xlsm", "exact_filename"),
    # 拡張子を持たないフォルダパス
    (["No", "担当", "格納先"],
     ["2026-0034", "鈴木", r"\\srv\解析\2026\筐体放熱検討"],
     "筐体放熱検討", "exact_filename"),
    # 「件名」欄に素のファイル名
    (["受付番号", "部署", "件名"],
     ["2026-0500", "品証", "振動解析_詳細報告"],
     "振動解析_詳細報告.pptx", "normalized_filename"),
    # CAD 図面
    (["図番", "設計", "ファイル"],
     ["DWG-1001", "設計一課", "DWG-1001_筐体図面.dwg"],
     "DWG-1001_筐体図面.dwg", "exact_filename"),
])
def test_matches_regardless_of_which_column_holds_it(tmp_path, headers, row, query, method):
    """どの列に入っていようと、どんな種類のファイルだろうと当たること。"""
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / f"{method}_{abs(hash(query))}.xlsx", [row],
                     title_row=False, headers=headers)
    m = build_index([str(p)]).match(query)
    assert m.ok, f"表頭 {headers} / 問い合わせ {query} で照合できていない"
    assert m.method == method


def test_matches_filename_buried_in_a_remarks_cell(tmp_path):
    """ファイル名が「備考」欄の文章に紛れていても当たる。

    Ctrl+F ならこれも見つかる。列の役割を決めてから探す設計では取り逃がす。
    """
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "remarks.xlsx", [
        ["2026-0600", "田中", "報告書は 2026-0600_疲労評価_最終.docx を参照"],
    ], title_row=False, headers=["番号", "担当", "備考"])
    m = build_index([str(p)]).match("2026-0600_疲労評価_最終.docx")
    assert m.ok


def test_matches_by_request_number_when_no_filename_column_exists(tmp_path):
    """ファイル名がどこにも書かれていない台帳でも、依頼番号で当たる。"""
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "nofile.xlsx", [["2026-0700", "品証", "熱伝導評価"]],
                     title_row=False, headers=["受付番号", "部署", "件名"])
    m = build_index([str(p)]).match("2026-0700_熱伝導評価_報告書.pptx")
    assert m.ok and m.method == "request_number"


def test_matched_column_is_recorded_and_excluded_from_evidence(tmp_path):
    """当たった列は「結果」であって「前提」ではない。

    記録するのは、その値が検索の鍵そのもの（保存パス等）で
    要約には要らないから。それ以外の用途は無い。
    """
    from app.nodes import _reference_to_evidence
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "matched.xlsx", [
        ["2026-0800", "製造", r"\\srv\2026-0800_検討.pptx", "備考あり"],
    ], title_row=False, headers=["番号", "部署", "格納先", "備考"])
    m = build_index([str(p)]).match("2026-0800_検討.pptx")

    assert m.matched_header == "格納先"
    blob = " ".join(e.content for e in _reference_to_evidence(m))
    assert "格納先" not in blob, "検索の鍵そのものは要約に不要"
    assert "備考" in blob, "それ以外の列は全部渡すこと"


def test_short_values_are_not_indexed(tmp_path):
    """部署コードのような短い値まで鍵にすると誤爆する。"""
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "short.xlsx", [["2026-0900", "QA", "検討"]],
                     title_row=False, headers=["番号", "部署", "件名"])
    idx = build_index([str(p)])
    assert all(len(k) >= 6 for k in idx.by_exact)


# ======================================================================
# 12. v3.18：可視性（効いていないのか、読んでいないのかを区別できること）
# ======================================================================
#
# 機能自体は動いていても、画面に何も出なければ利用者は原因を切り分けられない。
# 「台帳を置いたのに効かない」と「そもそも台帳を読んでいない」は
# 対処がまるで違うので、必ず区別できる形で出す。

def test_new_nodes_are_registered_in_ui():
    """UI に登録されていないノードは、走っていても存在しないのと同じ。"""
    html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(
        encoding="utf-8")
    assert "lookup_reference:" in html, "ノードラベルが無いと進捗に出ない"
    assert "route_template:" in html
    # どの Agent の担当かも決まっていないと進捗表示に現れない
    assert '"lookup_reference", "prepare_html_text"' in html


def test_evidence_api_exposes_reference_match():
    import inspect

    import app.webapp as W

    src = inspect.getsource(W.run_evidence)
    assert "reference_match.json" in src


def test_ui_separates_ledger_evidence_from_body_evidence():
    """台帳由来と本文由来を同じ表に混ぜると、効いているか判断できない。"""
    html = (Path(__file__).resolve().parents[1] / "static" / "index.html").read_text(
        encoding="utf-8")
    assert 'e.origin === "ledger"' in html
    assert "参照台帳の証拠" in html


def test_missing_library_is_reported_not_silent():
    """台帳が 1 冊も無いことを黙って通過してはいけない。"""
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert "参照台帳が 1 冊も見つかりません" in src


def test_no_match_reports_how_many_rows_were_searched():
    """「読んだが当たらなかった」と「読んでいない」を区別できること。"""
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert "行を検索しましたが" in src


def test_ledger_evidence_survives_vision_route_and_parallel(tmp_path):
    """精読 + 視覚ルート + 並行分岐（一括処理の既定）でも台帳が効くこと。"""
    openpyxl_mod = pytest.importorskip("openpyxl")

    from app.config import load_config
    from app.graph import run_workflow
    from app.reference_index import clear_cache

    lib = tmp_path / "refs"
    lib.mkdir()
    wb = openpyxl_mod.Workbook()
    ws = wb.active
    ws.append(["管理No", "起案者", "件名", "格納先"])
    ws.append(["2026-0012", "山田太郎", "配管圧損検討",
               r"\\srv\2026-0012_配管圧損_報告書.md"])
    wb.save(lib / "2026.xlsx")

    src = tmp_path / "2026-0012_配管圧損_報告書.md"
    src.write_text("# ページ 1\n# 配管圧損検討\n圧損は 12.3 kPa。\n", encoding="utf-8")

    clear_cache()
    cfg = load_config().model_copy(deep=True)
    cfg.llm.mock = True
    cfg.workflow.warmup_on_start = False
    cfg.workflow.reference_library_dir = str(lib)
    cfg.workflow.deep_read = True
    cfg.workflow.parallel_branches = True
    cfg.paths.out_dir = str(tmp_path / "out")

    # 一括処理と同じ呼び方（reference_paths を渡さない＝常駐ライブラリのみ）
    final = run_workflow(str(src), cfg, template_id="case", input_mode="vision")
    agg = json.loads((Path(final["run_dir"]) / "evidence_aggregated.json")
                     .read_text(encoding="utf-8"))
    ledger_ev = [e for e in agg["evidence"] if e.get("origin") == "ledger"]
    assert ledger_ev, "視覚ルート＋並行分岐で台帳証拠が消えている"
    assert any("山田太郎" in e["content"] for e in ledger_ev)


# ======================================================================
# 13. v3.20：連続一致で採点する／フォルダ名も鍵にする
# ======================================================================
#
# 現場の実例に基づく。台帳に報告書のファイル名は無く、
# ファイル名の一部だけが「件名」欄と重なる：
#   20231012_アルミ外材硬さ試験結果2_ニスなし追加.xlsx
#     → 台帳の「アルミ外材硬さ試験」と重なる（目的の行）
#     → ただし「硬さ試験」だけなら別案件の行にも当たってしまう
#   外材コート層硬さ試験 速報2.xlsx
#     → 同じ依頼の成果物だが、ファイル名だけでは十分に重ならない
#     → 同じフォルダに置かれており、フォルダ名は案件名に近い

@pytest.fixture()
def hardness_ledger(tmp_path):
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "2023年度.xlsx", [
        ["2023-0450", "2023/10/01", "アルミ外材硬さ試験", "歩留り",
         "アルミ外材硬さ試験およびニス有無の比較", "製造二課 田中", "", ""],
        ["2023-0512", "2023/11/01", "樹脂部材硬さ試験", "", "樹脂部材の硬さ試験",
         "品証 佐藤", "", ""],
        ["2023-0600", "2023/12/01", "めっき膜厚測定", "", "めっき膜厚の測定",
         "開発一課 鈴木", "", ""],
    ])
    return build_index([str(p)])


def test_generic_term_alone_does_not_match(hardness_ledger):
    """「硬さ試験」のような一般語だけの一致で当ててはいけない。

    v3.19 までは difflib の ratio（散らばった共通部分も数える）だったので、
    別案件の行にも 0.4〜0.5 の点が付いて選別にならなかった。
    v3.20 は連続一致の長さと被覆率だけを見る。
    """
    from app.reference_index import _similarity, normalize_filename

    q = normalize_filename("20231012_アルミ外材硬さ試験結果2_ニスなし追加.xlsx")
    assert _similarity(q, normalize_filename("アルミ外材硬さ試験")) >= 0.9
    assert _similarity(q, normalize_filename("樹脂部材硬さ試験")) == 0.0


def test_partial_match_requires_large_contiguous_overlap(hardness_ledger):
    m = hardness_ledger.match("20231012_アルミ外材硬さ試験結果2_ニスなし追加.xlsx")
    assert m.ok
    assert m.row.values["依頼番号"] == "2023-0450"
    assert not m.candidates, "別案件が候補に残ってはいけない"


def test_folder_name_used_when_filename_is_not_enough(tmp_path, hardness_ledger):
    """同じ依頼の別ファイルを、フォルダ名で引き当てられること。"""
    case_dir = tmp_path / "解析依頼" / "アルミ外材硬さ試験"
    case_dir.mkdir(parents=True)
    target = case_dir / "外材コート層硬さ試験 速報2.xlsx"

    # ファイル名だけでは当たらない
    assert hardness_ledger.match(target.name).ok is False
    # フォルダ名まで見れば当たる
    m = hardness_ledger.match(str(target))
    assert m.ok
    assert m.row.values["依頼番号"] == "2023-0450"
    assert "フォルダ名" in m.reason


def test_folder_name_rescues_files_with_no_clue_in_their_name(tmp_path, hardness_ledger):
    """「測定条件メモ.docx」のような手掛かりゼロのファイルも救える。"""
    case_dir = tmp_path / "解析依頼" / "アルミ外材硬さ試験"
    case_dir.mkdir(parents=True)
    m = hardness_ledger.match(str(case_dir / "測定条件メモ.docx"))
    assert m.ok and m.row.values["依頼番号"] == "2023-0450"


def test_folder_match_does_not_leak_across_cases(tmp_path, hardness_ledger):
    """別案件のフォルダに置かれたファイルが、こちらの案件に当たらないこと。"""
    other = tmp_path / "解析依頼" / "めっき膜厚測定"
    other.mkdir(parents=True)
    m = hardness_ledger.match(str(other / "データ.xlsx"))
    assert m.ok and m.row.values["依頼番号"] == "2023-0600"


def test_unrelated_folder_and_name_finds_nothing(tmp_path, hardness_ledger):
    d = tmp_path / "その他" / "雑資料"
    d.mkdir(parents=True)
    assert hardness_ledger.match(str(d / "無関係な資料.pptx")).ok is False


# ======================================================================
# 14. v3.21：照合には「元の置き場所」を使う（inbox のパスではない）
# ======================================================================
#
# 利用者報告：単体アップロード + 視覚ルート + 精読で「該当なし」になる。
# 原因はフォルダ照合の実装漏れではなく、**照合に渡すパスが違っていた** こと。
# ブラウザからのアップロードは out/inbox/ に「元の名前_8桁ID.拡張子」で
# 保存されるため、親フォルダが inbox になりフォルダ名照合が死に、
# ファイル名にも ID が混ざって一致度が落ちていた。
# 一括処理（フォルダ指定）は元パスをそのまま使うので影響を受けていなかった。

def test_lookup_uses_source_path_not_storage_path():
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert 'state.get("source_rel_path")' in src
    assert 'state.get("source_name")' in src


def test_run_workflow_accepts_source_path():
    import inspect

    import app.graph as G

    sig = inspect.signature(G.run_workflow)
    assert "source_name" in sig.parameters
    assert "source_rel_path" in sig.parameters


def test_upload_records_original_name_and_relative_path():
    import inspect

    import app.webapp as W

    src = inspect.getsource(W)
    assert "orig_name = Path(file.filename or \"\").name" in src
    assert "relative_paths" in src, "ブラウザからの相対パスを受け取ること"


def test_batch_passes_folder_relative_path():
    """一括処理は item['rel'] に階層を持っているので、それを渡すこと。"""
    import inspect

    import app.webapp as W

    src = inspect.getsource(W)
    assert 'item.get("rel", "")' in src


def test_folder_match_works_through_inbox_upload(tmp_path):
    """inbox に ID 付きで保存された後でも、元の置き場所で照合できること。"""
    openpyxl_mod = pytest.importorskip("openpyxl")

    import shutil
    import uuid

    from app.config import load_config
    from app.graph import run_workflow
    from app.reference_index import clear_cache

    lib = tmp_path / "refs"
    lib.mkdir()
    wb = openpyxl_mod.Workbook()
    ws = wb.active
    ws.append(["管理No", "依頼者", "件名", "依頼内容"])
    ws.append(["2023-0450", "製造二課 田中", "アルミ外材硬さ試験", "ニス有無の比較"])
    wb.save(lib / "2023年度.xlsx")

    case = tmp_path / "解析依頼" / "アルミ外材硬さ試験"
    case.mkdir(parents=True)
    orig = case / "外材コート層硬さ試験 速報2.md"
    orig.write_text("# 速報2\n硬さの測定結果。\n", encoding="utf-8")

    inbox = tmp_path / "inbox"
    inbox.mkdir()
    saved = inbox / f"{orig.stem}_{uuid.uuid4().hex[:8]}{orig.suffix}"
    shutil.copy(orig, saved)

    def _run(label, **kw):
        clear_cache()
        cfg = load_config().model_copy(deep=True)
        cfg.llm.mock = True
        cfg.workflow.warmup_on_start = False
        cfg.workflow.parallel_branches = False
        cfg.workflow.deep_read = True
        cfg.workflow.reference_library_dir = str(lib)
        cfg.paths.out_dir = str(tmp_path / f"out_{label}")
        final = run_workflow(str(saved), cfg, template_id="case",
                             input_mode="vision", **kw)
        return json.loads((Path(final["run_dir"]) / "reference_match.json")
                          .read_text(encoding="utf-8"))

    # inbox のパスだけでは当たらない（これが利用者の遭遇した状態）
    assert _run("bare")["ok"] is False
    # 元の相対パスを渡せば、フォルダ名で当たる
    fixed = _run("fixed", source_name=orig.name,
                 source_rel_path=f"解析依頼/アルミ外材硬さ試験/{orig.name}")
    assert fixed["ok"] is True
    assert fixed["row"]["values"]["管理No"] == "2023-0450"
    assert "フォルダ名" in fixed["reason"]


# ======================================================================
# 15. v3.22：台帳アンケートを「対応効果・メリット」へ入れる
# ======================================================================
#
# 台帳に依頼完了後のアンケート列が増えた。抽出は既に効いている
#（v3.15 以降、全列が生の表頭のまま証拠になる）が、それを **どの項目に
# 入れるか** の指示が無かった。特に内蔵 case テンプレートは
# summary_instructions が空のまま出荷されていた。

def test_case_template_has_summary_instructions():
    """内蔵テンプレートの指示スロットが空のままだと、生成の指針がゼロになる。

    YAML 側の 3 テンプレートには元からあったのに、最もよく使う case だけ
    空文字だった。
    """
    from app.template_registry import get_registry

    si = get_registry().get("case").summary_instructions
    assert si.strip(), "case テンプレートの要約指示が空"


def test_instructions_name_the_effects_field_explicitly():
    """「対応効果の項目」では曖昧。JSON のどの項目かを名指しする。

    「対応効果・メリット」は独立した項目ではなく、Markdown 側の見出しで、
    実体は action_results.effects というリスト。名前で指示しないと
    モデルが当てずっぽうで別の項目へ入れる。
    """
    from app.template_registry import get_registry

    si = get_registry().get("case").summary_instructions
    assert "action_results.effects" in si
    # 解析結果（findings）と取り違えないよう明示していること
    assert "findings" in si


def test_instructions_cover_sparse_questionnaire_answers():
    """回答量は人によってばらばら。点数だけ・空欄も普通にある。"""
    from app.template_registry import get_registry

    si = get_registry().get("case").summary_instructions
    assert "点数だけの回答" in si
    assert "憶測で埋めない" in si


def test_instructions_overridable_by_file(tmp_path, monkeypatch):
    """プロンプト調整に Python の編集を要求しないこと。"""
    import app.template_registry as TR

    tpl_dir = tmp_path / "templates"
    tpl_dir.mkdir()
    (tpl_dir / "case_summary_instructions.md").write_text(
        "差し替えた指示文", encoding="utf-8")
    monkeypatch.setattr(TR, "PROJECT_ROOT", tmp_path)
    assert TR._load_case_instructions() == "差し替えた指示文"


def test_instructions_fall_back_when_file_absent(tmp_path, monkeypatch):
    import app.template_registry as TR

    monkeypatch.setattr(TR, "PROJECT_ROOT", tmp_path)
    assert "action_results.effects" in TR._load_case_instructions()


def test_questionnaire_columns_reach_evidence(tmp_path):
    """抽出側は既に効いていること（回答量の違いも含めて）。"""
    from app.nodes import _reference_to_evidence
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "survey.xlsx", [
        ["2023-0450", "田中", "アルミ外材硬さ試験", "5",
         "試作前に不具合を潰せた", "特になし"],
        ["2023-0451", "佐藤", "樹脂部材硬さ試験", "4", "", ""],
        ["2023-0452", "鈴木", "めっき膜厚測定", "", "", ""],
    ], title_row=False,
        headers=["管理No", "依頼者", "件名", "満足度", "役に立った点", "改善要望"])
    idx = build_index([str(p)])

    rich = " ".join(e.content for e in _reference_to_evidence(
        idx.match("アルミ外材硬さ試験.pptx")))
    assert "「満足度」：5" in rich
    assert "「役に立った点」" in rich

    # 点数だけの人：記述欄は証拠にならない
    score_only = " ".join(e.content for e in _reference_to_evidence(
        idx.match("樹脂部材硬さ試験.pptx")))
    assert "「満足度」：4" in score_only
    assert "役に立った点" not in score_only

    # 全部空欄の人：アンケート列は一切出ない
    blank = " ".join(e.content for e in _reference_to_evidence(
        idx.match("めっき膜厚測定.pptx")))
    assert "満足度" not in blank
