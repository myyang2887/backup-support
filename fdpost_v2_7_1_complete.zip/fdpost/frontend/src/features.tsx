/** Feature flags: every UI capability can be switched off for debugging.
 *
 *  Design rules (keep it clean):
 *  - This file is the single registry. Adding a flag = one entry here
 *    + one <Feature> wrapper (or useFeature check) at the render site.
 *  - Granularity follows linked behavior: disabling a tool hides its rail
 *    button, its panel, its gizmo and its 3D layers together.
 *  - Each entry carries its own `on:` — the state a fresh browser starts in.
 *    Flip that one word to ship a feature switched off; nothing else to edit.
 *  - The user's own toggles persist per-browser (localStorage) and win over
 *    `on:`, so only deviations from the shipped default are stored.
 */
import { ReactNode } from "react";
import { create } from "zustand";

export interface FeatureDef {
  id: string; label: string; desc: string; group: string;
  /** Initial state in a browser that has never touched the settings panel. */
  on: boolean;
}

export const FEATURE_DEFS: FeatureDef[] = [
  // ツール: ボタン + パネル + ギズモ + 3Dレイヤーが連動して消えます
  { id: "tool.slice",   group: "ツール", label: "断面", on: true,
    desc: "軸直交・自由平面の断面(ギズモ含む)" },
  { id: "tool.probe",   group: "ツール", label: "ライン", on: true,
    desc: "2点間サンプリング(端点ギズモ含む)" },
  { id: "tool.stream",  group: "ツール", label: "流線", on: true,
    desc: "シードレーク・RK4積分(3D流線レイヤー含む)" },
  { id: "tool.iso",     group: "ツール", label: "等値面", on: true,
    desc: "marching cubes(3Dメッシュレイヤー含む)" },
  { id: "tool.region",  group: "ツール", label: "領域", on: true,
    desc: "3D box領域CSV出力(箱ギズモ含む)" },
  { id: "tool.display",  group: "ツール", label: "表示", on: true,
    desc: "点群フィルタ・速度矢印・サーフェス表現の設定パネル" },
  { id: "tool.jobs",    group: "ツール", label: "ジョブ", on: true,
    desc: "バッチ処理の進捗一覧" },
  { id: "slice.batch",  group: "ツール", label: "断面バッチ出力", on: true,
    desc: "断面パネル内のPNG一括出力セクション" },
  { id: "slice.csv",    group: "ツール", label: "断面CSV出力", on: true,
    desc: "断面パネル内の指定解像度CSV出力セクション" },
  // 3Dビュー
  { id: "viewport.drag",       group: "3Dビュー", label: "ギズモのドラッグ操作", on: true,
    desc: "OFFにすると数値入力のみに。ONのままでもAlt+ドラッグで視点回転できます" },
  { id: "viewport.keyboard",   group: "3Dビュー", label: "キーボード操作", on: true,
    desc: "←→で断面送り / Rで視点リセット" },
  { id: "viewport.cursorHud",  group: "3Dビュー", label: "カーソル座標読み取り", on: true,
    desc: "HUDチップ・ヘッダの「座標」ボタン・2D図のホバー" },
  { id: "viewport.arrows",     group: "3Dビュー", label: "速度矢印(3D)", on: true,
    desc: "3Dビューの速度ベクトル矢印レイヤーと設定" },
  { id: "viewport.shells",     group: "3Dビュー", label: "サーフェス表現(多重等値面)", on: true,
    desc: "等値面ツール内の多重半透明サーフェスと3Dレイヤー" },
  { id: "viewport.quiver2d",   group: "3Dビュー", label: "断面の速度矢印(2D)", on: true,
    desc: "実時間断面図に重ねる矢印" },
  { id: "viewport.colorbar",   group: "3Dビュー", label: "カラーバー凡例", on: true,
    desc: "ビューポート右のスケール表示" },
  { id: "viewport.modeSwitch", group: "3Dビュー", label: "3D表示モード切替", on: true,
    desc: "ポイントクラウド/完全3Dの切替セレクタ" },
  // 画面
  { id: "shell.drawer",    group: "画面", label: "結果ドロワー", on: true,
    desc: "下部の断面/ライン結果表示(実時間断面含む)" },
  { id: "shell.statusbar", group: "画面", label: "ステータスバー", on: true,
    desc: "最下部のデータ情報・座標ミラー" },
  // 保存・共有
  { id: "persist.sessions", group: "保存・共有", label: "セッション保存", on: true,
    desc: "作業状態の保存/復元メニュー" },
  { id: "persist.share",    group: "保存・共有", label: "共有リンク", on: true,
    desc: "読み取り専用スナップショットのURL発行" },
];

export type FeatureId =
  | "tool.slice" | "tool.probe" | "tool.stream" | "tool.iso"
  | "tool.region" | "tool.display" | "tool.jobs"
  | "slice.batch" | "slice.csv"
  | "viewport.drag" | "viewport.keyboard" | "viewport.cursorHud"
  | "viewport.arrows" | "viewport.shells" | "viewport.quiver2d"
  | "viewport.colorbar" | "viewport.modeSwitch"
  | "shell.drawer" | "shell.statusbar"
  | "persist.sessions" | "persist.share";

/** Shipped defaults, keyed by id — built from the table above so the two
 *  can never drift apart. */
const DEFAULT_ON: Record<string, boolean> = Object.fromEntries(
  FEATURE_DEFS.map((f) => [f.id, f.on]));

export const defaultOn = (id: string): boolean => DEFAULT_ON[id] ?? true;

const KEY = "fdpost.features.v1";

/** Persisted shape: the user's deviations, plus the shipped defaults they
 *  were deviating *from*. Keeping the second half is what makes changing an
 *  `on:` in the table actually take effect.
 *
 *  Without it, a stored `false` silently beat the new code default forever:
 *  you could flip `on: true`, rebuild, and the button still would not appear
 *  — with nothing in the UI to explain why. The only cure was toggling it in
 *  the settings panel, which happens to delete the stale entry.
 */
interface Persisted {
  overrides: Record<string, boolean>;
  /** Defaults in force when each override was written. */
  basis: Record<string, boolean>;
}

function loadOverrides(): Record<string, boolean> {
  let raw: any;
  try { raw = JSON.parse(localStorage.getItem(KEY) ?? "{}"); }
  catch { return {}; }

  // pre-v2.7 files were a bare override map with no basis recorded
  const p: Persisted = ("overrides" in (raw ?? {}))
    ? raw as Persisted
    : { overrides: (raw ?? {}) as Record<string, boolean>, basis: {} };

  // Drop an override whose shipped default has since changed: the author
  // changed their mind about that flag, so the stored choice is stale.
  // Overrides for untouched flags are kept — those are the user's own.
  const kept: Record<string, boolean> = {};
  for (const [id, v] of Object.entries(p.overrides)) {
    const was = p.basis[id];
    if (was === undefined || was === defaultOn(id)) kept[id] = v;
  }
  return kept;
}

function saveOverrides(overrides: Record<string, boolean>): void {
  const basis: Record<string, boolean> = {};
  for (const id of Object.keys(overrides)) basis[id] = defaultOn(id);
  try { localStorage.setItem(KEY, JSON.stringify({ overrides, basis })); }
  catch { /* private mode etc. */ }
}

interface FS {
  overrides: Record<string, boolean>;    // absent = default (ON)
  toggle: (id: FeatureId) => void;
  reset: () => void;
}

export const useFeatures = create<FS>((set) => ({
  overrides: loadOverrides(),
  toggle: (id) => set((s) => {
    // store only deviations from the shipped default, so changing `on:` in
    // the table later still takes effect for anyone who never toggled it
    const def = defaultOn(id);
    const overrides = { ...s.overrides, [id]: !(s.overrides[id] ?? def) };
    if (overrides[id] === def) delete overrides[id];
    saveOverrides(overrides);
    return { overrides };
  }),
  reset: () => {
    try { localStorage.removeItem(KEY); } catch { /* ignore */ }
    set({ overrides: {} });
  },
}));

export const isOn = (id: FeatureId,
                     overrides: Record<string, boolean>): boolean =>
  overrides[id] ?? defaultOn(id);

/** Hook: subscribe to one flag. */
export function useFeature(id: FeatureId): boolean {
  return useFeatures((s) => isOn(id, s.overrides));
}

/** Non-hook read for event handlers / imperative code. */
export const featureOn = (id: FeatureId): boolean =>
  isOn(id, useFeatures.getState().overrides);

/** Declarative wrapper: <Feature id="persist.share">…</Feature> */
export function Feature(props: { id: FeatureId; children: ReactNode }) {
  return useFeature(props.id) ? <>{props.children}</> : null;
}
