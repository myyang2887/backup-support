"""
LangGraph 节点（v3）。

v3 相比 v2 的变化（按对"十页 PDF 一小时"的贡献排序）：
1. Docling 只转换一次（v2 转两次，解析时间减半）+ OCR 可关
2. 阶段级缓存（resume）：同内容文件重跑时，解析/证据提取/视觉分析直接复用产物
3. 视觉资产预过滤（尺寸/字节/SHA1 去重）+ 降采样到 1024px：
   VLM 调用次数和单次 prompt 体积同时下降，这通常是 PDF 场景最大的时间黑洞
4. 视觉分析并行化（v2 只有文本提取能并行）
5. 结构感知切块 + 信息量过滤：更少、更干净的 chunk = 更少的 LLM 调用
6. 证据提取 max_tokens 4096 -> 2048
7. 新增 gap_fill 节点：聚合后关键类别缺证据时做一次针对性补提取（agent 化的第一步）
8. 细粒度进度（节点内 i/N 计数）+ 每节点耗时写入 status.json，Web UI 可视化
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, TypedDict

from pydantic import ValidationError

from tools.doc_tools import xlsx_to_html
from tools.visual_asset_tools import collect_visual_assets, collect_html_text_sources

from .config import AppConfig
from .contract import (Evidence, EvidenceList, VisualEvidence, UNKNOWN, schema_skeleton)
from .accounting import LossLedger, conservation_check
from .trace import (PipelineTrace, ENGINE_DOCLING, ENGINE_PYPDFIUM,
                    ENGINE_OPENPYXL, ENGINE_LIBREOFFICE, ENGINE_WIN32COM,
                    ENGINE_PILLOW, ENGINE_OFFICE_COM, ENGINE_OFFICE2PDF)
from .template_registry import TemplateSpec, get_registry
from .template_route import decide_template
from .evidence import aggregate_evidence, visual_to_pack
from .llm_client import LocalLLMClient, LLMJsonError
from .observability import RunCancelled, RunStore
from .rag_export import write_jsonl as rag_write_jsonl
from .redaction import NGDictionary, redact_summary
from .parsing import (convert_document_once, extract_office_visuals, extract_pdf_visuals,
                      office_to_pdf, pdf_text_fallback, render_pdf_pages,
                      prefilter_and_downscale_images, structural_chunks,
                      structural_chunks_traced)
from .route_decision import decide_route
from .excel_extract import workbook_to_markdown, extract_charts, inspect_workbook, chart_to_markdown


class WorkflowState(TypedDict, total=False):
    input_path: str
    run_dir: str

    markdown_path: str
    docling_json_path: str
    # v3.11 テンプレート自動判定の結果
    template_id: str
    template_route_reason: str
    excel_html_path: str

    # v3.6 解析ルート（"text" = Docling / "vision" = 全ページ画像化して VLM 直読）
    excel_info: Dict[str, Any]
    # v3.8 損失台帳（本文/視覚は並行に走るのでキーを分ける。合流点で merge）
    loss_text: Dict[str, Any]
    loss_visual: Dict[str, Any]
    # v3.9 実行トレース（どのルート・どの実装で処理したか）。分岐衝突を避けて分離
    trace_main: Dict[str, Any]
    trace_visual: Dict[str, Any]
    page_report: Dict[str, Any]
    expanded_fields: List[str]
    route: str
    route_reason: str
    vision_pdf_path: str

    html_text_sources: List[Dict[str, Any]]
    chunks: List[Dict[str, Any]]

    text_evidence: List[dict]
    aggregated_evidence: List[dict]
    visual_asset_paths: List[str]
    visual_evidence: List[dict]

    summary: dict
    summary_raw: dict
    summary_degraded: bool
    summary_errors: List[str]
    validation: Dict[str, Any]
    repair_attempts: int

    output_markdown: str
    output_json: str
    errors: List[Dict[str, Any]]
    errors_visual: List[Dict[str, Any]]   # 视觉分支专用（并行时避免写冲突）





# 视觉分支与文本分支并行运行时，两者不能写同一个 state key（LangGraph 会判为
# 并发写冲突）。因此视觉分支的错误进 errors_visual，在汇合节点合并回 errors。
# 【重要】parallel_branches 有効時、分支内のノードは「自分が書いた key だけ」を
# 返すこと（state 全体を返すと相手分支の key と衝突し InvalidUpdateError）。
# 対象：chunk_text / extract_text_evidence / aggregate_evidence / gap_fill（文本分支）と
#       collect_visual_assets / analyze_visual（視覚分支）。
# 分支外のノード（parse/write_summary 以降）は従来どおり state 全体を返してよい。
VISUAL_NODES = {"collect_visual_assets", "analyze_visual"}


def _error_key(node: str) -> str:
    return "errors_visual" if node in VISUAL_NODES else "errors"


def _push_error(state: WorkflowState, node: str, message: str, detail: str = "") -> None:
    state.setdefault(_error_key(node), []).append(
        {"node": node, "message": message, "detail": detail[:2000], "time": time.strftime("%Y-%m-%d %H:%M:%S")}
    )


def _all_errors(state: WorkflowState) -> List[Dict[str, Any]]:
    return list(state.get("errors", [])) + list(state.get("errors_visual", []))


def _save_json(data: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _store(state: WorkflowState) -> RunStore:
    return RunStore(state["run_dir"])


def _update_status(state: WorkflowState, node: str, phase: str = "running",
                   detail: str = "", peek: str = "") -> None:
    if not state.get("run_dir"):
        return
    _store(state).event(node, phase, detail, errors=_all_errors(state),
                        peek=peek or None)


def file_hash(path: str) -> str:
    """v3 改为内容哈希：同内容文件（哪怕改名/重新上传）命中同一 run_dir，缓存才有意义。"""
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()[:12]


def make_nodes(config: AppConfig, llm: Optional[LocalLLMClient] = None,
               vision_llm: Optional[LocalLLMClient] = None,
               template_id: str = "case"):
    spec: TemplateSpec = get_registry().get(template_id)
    # 指标 hook：run_dir 在 create_run_dir 之后才确定，用可变盒子延迟绑定
    hook_box: Dict[str, Optional[RunStore]] = {"store": None}

    def _metrics_hook(record: dict) -> None:
        if hook_box["store"] is not None:
            hook_box["store"].llm_metric(record)

    llm = llm or LocalLLMClient(**config.llm.model_dump(exclude={"vision"}),
                                metrics_hook=_metrics_hook)
    if getattr(llm, "metrics_hook", None) is None:
        llm.metrics_hook = _metrics_hook
    if vision_llm is None:
        vc = config.llm.vision
        if vc and vc.base_url:
            vision_llm = LocalLLMClient(
                base_url=vc.base_url, api_key=vc.api_key, model=vc.model,
                temperature=config.llm.temperature,
                structured_output=config.llm.structured_output,
                max_retries=config.llm.max_retries,
                timeout_seconds=config.llm.timeout_seconds,
                mock=config.llm.mock,
                metrics_hook=_metrics_hook,
            )
        else:
            vision_llm = llm
    wf = config.workflow

    def _resume_ok(state: WorkflowState, artifact: Path) -> bool:
        return wf.resume and artifact.exists()

    # ------------------------------------------------------------------
    def create_run_dir(state: WorkflowState) -> WorkflowState:
        input_path = Path(state["input_path"]).resolve()
        out_dir = config.paths.resolve(config.paths.out_dir)
        run_id = f"{input_path.stem}_{file_hash(str(input_path))}"
        run_dir = out_dir / "runs" / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        state["run_dir"] = str(run_dir)
        state["errors"] = []
        state["repair_attempts"] = 0
        store = RunStore(run_dir)
        hook_box["store"] = store
        store.save_json(RunStore.MANIFEST, {"input_path": str(input_path), "run_dir": str(run_dir),
                                            "template_id": spec.id, "template_name": spec.name})
        store.reset_status()  # 重置 status/指标/取消标记（保留缓存产物）
        store.logger().info("run start: %s", input_path.name)
        _update_status(state, "create_run_dir", "done")
        return state

    # ------------------------------------------------------------------
    def parse_document(state: WorkflowState) -> WorkflowState:
        _update_status(state, "parse_document",
                       peek=f"『{Path(state['input_path']).name}』を読み込んでいます…")
        input_path = Path(state["input_path"]).resolve()
        run_dir = Path(state["run_dir"])
        parse_dir = run_dir / "parsed"
        parse_dir.mkdir(parents=True, exist_ok=True)
        suffix = input_path.suffix.lower()

        md_path = parse_dir / f"{input_path.stem}.md"
        json_path = parse_dir / f"{input_path.stem}.json"

        # ---- v3.6 解析ルート判定（LLM ゼロ・安価なプローブのみ）----
        store = _store(state)
        prev_route = (store.load_json("route.json", {}) or {}).get("route")
        route, reason, probe = decide_route(str(input_path), wf)
        state["route"] = route
        state["route_reason"] = reason
        store.save_json("route.json", {"route": route, "reason": reason, "probe": probe,
                                       "mode": getattr(wf, "input_mode", "auto")})
        manifest = store.load_json(RunStore.MANIFEST, {}) or {}
        manifest.update({"route": route, "route_reason": reason})
        store.save_json(RunStore.MANIFEST, manifest)
        # ルートが前回と違うならキャッシュは別物なので使わない
        route_changed = prev_route is not None and prev_route != route

        # ---- v3.9 実行トレース：ルートと使用実装を残す ----
        tr = PipelineTrace()
        tr.set_route(route, reason,
                     manual=(getattr(wf, "input_mode", "auto") != "auto"))
        tr.template_id = spec.id
        tr.deep_read = bool(getattr(wf, "deep_read", False))
        _update_status(state, "parse_document", "running",
                       f"経路: {'視覚直読' if route == 'vision' else 'Docling'}",
                       peek=f"解析ルートを決めました：{reason}")

        if suffix in (".xlsx", ".xlsm") and not _resume_ok(state, md_path):
            tr.use("excel", ENGINE_OPENPYXL,
                   "セル計算結果とグラフ numCache を数値表として読み取り")
            _excel_text_pass(state, store, input_path, md_path)
            if route != "vision":
                return state          # vision 指定時はページ画像化も続けて行う

        if route == "vision":
            # Docling を完全に飛ばす。テキストは「ただで取れる分だけ」拾い、
            # 主役は collect_visual_assets が作るページ画像 → Agent 2。
            text = ""
            if suffix == ".pdf":
                tr.use("parse", ENGINE_PYPDFIUM, "PDF のテキスト層を抽出（Docling は迂回）")
                text = pdf_text_fallback(str(input_path))
            elif suffix in (".pptx", ".docx", ".ppt", ".doc"):
                conv = office_to_pdf(
                    str(input_path), str(parse_dir / "as_pdf"),
                    office2pdf_path=getattr(wf, "office2pdf_path", ""),
                    office2pdf_font_path=getattr(wf, "office2pdf_font_path", ""),
                    use_office2pdf=getattr(wf, "office2pdf_enabled", True))
                if conv.get("ok"):
                    # v3.10/v3.11：変換元は COM / office2pdf / LibreOffice のいずれか。
                    # どれで通ったかは忠実度に直結するので必ず残す。
                    tr.use("parse",
                           {"office_com": ENGINE_OFFICE_COM,
                            "office2pdf": ENGINE_OFFICE2PDF}.get(
                               conv.get("engine", ""), ENGINE_LIBREOFFICE),
                           "Office → PDF 変換（全頁描画のため）")
                    state["vision_pdf_path"] = conv["pdf_path"]
                    text = pdf_text_fallback(conv["pdf_path"])
                else:
                    tr.unavailable("parse", ENGINE_OFFICE2PDF,
                                   str(conv.get("error"))[:200]
                                   or "変換に失敗したため頁画像化は不可・埋込画像のみ")
                    _push_error(state, "parse_document",
                                "視覚直読：PDF 変換手段が無いためページ画像化は不可。"
                                "埋め込み画像のみで視覚分析を行います",
                                str(conv.get("error", "")))
            elif suffix in (".xlsx", ".xlsm", ".xls"):
                # v3.11：Excel をここで office_to_pdf に掛けるのを止めた。
                #
                # Excel の頁画像化は collect_visuals 側の Excel COM
                #（PageSetup で「横 1 ページに収める」）が担当しており、
                # この経路は最初から通らない。にもかかわらず変換を試みて
                # 失敗し「PDF 変換手段がありません」と警告を出していたため、
                # Excel COM が正常に動いている run でも画面上は
                # 「頁画像化は不可」と出て状態を誤認させていた。
                # テキスト層は _excel_text_pass が既に作っているので、
                # ここでは何もしないのが正しい。
                text = ""
            md_path.write_text(text, encoding="utf-8")
            state["markdown_path"] = str(md_path)
            state["trace_main"] = tr.raw()
            _update_status(state, "parse_document", "done",
                           f"視覚直読（テキスト層 {len(text)} 字）")
            for line in tr.summary_lines():
                store.logger().info("[trace] %s", line)
            return state

        if _resume_ok(state, md_path) and not route_changed:
            state["markdown_path"] = str(md_path)
            if json_path.exists():
                state["docling_json_path"] = str(json_path)
            _update_status(state, "parse_document", "done", "キャッシュ再利用")
        elif suffix in (".md", ".txt", ".markdown"):
            md_path.write_text(input_path.read_text(encoding="utf-8", errors="ignore"), encoding="utf-8")
            state["markdown_path"] = str(md_path)
        else:
            # v3：一次转换导出两种格式（v2 是两次完整转换）
            result = convert_document_once(str(input_path), str(parse_dir), do_ocr=wf.docling_ocr)
            if result.get("ok"):
                tr.use("parse", ENGINE_DOCLING,
                       f"レイアウト解析＋表構造（OCR {'有効' if wf.docling_ocr else '無効'}）")
                state["markdown_path"] = result["markdown_path"]
                if result.get("json_path"):
                    state["docling_json_path"] = result["json_path"]
            elif suffix == ".pdf":
                tr.fallback("parse", ENGINE_DOCLING, ENGINE_PYPDFIUM,
                            "Docling が失敗。レイアウト・表構造は失われます")
                # 降级：Docling 失败时用 pypdfium2 文本层兜底（无布局/表格，
                # 质量下降但流水线不死；质量报告与 UI 都会显示该警告）
                text = pdf_text_fallback(str(input_path))
                md_path.write_text(text, encoding="utf-8")
                state["markdown_path"] = str(md_path)
                if text.strip():
                    _push_error(state, "parse_document",
                                "Docling 解析失败，已降级为 pypdfium2 文本层抽取（无布局/表格结构）",
                                str(result.get("error", "")))
                else:
                    # 纯图片 PDF（扫描件等）：文本通道为空，视觉通道继续工作
                    _push_error(state, "parse_document",
                                "Docling 失败且 PDF 无文本层（扫描件の可能性）。"
                                "テキスト経路は空、視覚経路のみで処理を継続します",
                                str(result.get("error", "")))
            else:
                raise RuntimeError(f"文档解析失败: {result}")

        state["trace_main"] = tr.raw()
        for line in tr.summary_lines():
            store.logger().info("[trace] %s", line)

        if suffix in (".xls", ".xlsx", ".xlsm"):
            html_path = parse_dir / f"{input_path.stem}.html"
            if _resume_ok(state, html_path):
                state["excel_html_path"] = str(html_path)
            else:
                html_result = xlsx_to_html(str(input_path), str(html_path), engine="auto")
                if html_result.get("ok"):
                    state["excel_html_path"] = html_result["output_path"]
                else:
                    _push_error(state, "parse_document", "Excel->HTML 转换失败（非致命）", str(html_result))

        _update_status(state, "parse_document", "done")
        return state

    # ------------------------------------------------------------------
    def route_template(state: WorkflowState) -> WorkflowState:
        """v3.11：テンプレートを **最初の LLM 呼出の前** に決める。

        なぜここ（parse_document の後）なのか：
            判定材料の一つが「本文の冒頭 2000 字」なので、解析前＝create_run_dir
            直後には置けない。最初の LLM 呼出は extract_text_evidence なので、
            ここに置けば「全部走り終えてから不一致に気付く」問題は解消される。

        なぜ `nonlocal spec` なのか：
            spec は make_nodes のクロージャ変数で、他ノードから 27 箇所参照
            されている。同じセルを差し替えれば全ノードが新しい spec を見るので、
            27 箇所に手を入れる必要がない（state 経由に変えると全書き換えになる）。
            make_nodes は run ごとに呼ばれるため、並行 run 同士は別セルで干渉しない。
        """
        nonlocal spec
        store = _store(state)
        mode = getattr(wf, "template_mode", "manual")

        if mode != "auto":
            state["template_id"] = spec.id
            state["template_route_reason"] = "手動指定"
            _update_status(state, "route_template", "done", f"テンプレート: {spec.name}")
            return state

        head = ""
        try:
            head = Path(state["markdown_path"]).read_text(
                encoding="utf-8", errors="ignore")[:4000]
        except Exception:  # noqa: BLE001 本文が無くてもファイル名だけで判定は出来る
            pass

        verdict = decide_template(
            state["input_path"], head, get_registry(),
            fallback_id=getattr(wf, "template_auto_fallback", "generic_doc"))
        chosen = verdict["template_id"]

        prev = (store.load_json("template_route.json", {}) or {}).get("template_id")
        store.save_json("template_route.json", verdict)

        if chosen != spec.id:
            try:
                spec = get_registry().get(chosen)   # ← 全ノードがこの束縛を見る
            except KeyError:
                _push_error(state, "route_template",
                            f"自動判定したテンプレート '{chosen}' が未登録のため据え置き", "")
                chosen = spec.id

        state["template_id"] = spec.id
        state["template_route_reason"] = verdict["reason"]
        # テンプレートが変わると証拠カテゴリも変わる。前回と違うなら
        # 証拠キャッシュは別物なので使わせない（ルート変更時と同じ扱い）。
        state["template_changed"] = bool(prev and prev != spec.id)  # type: ignore[typeddict-unknown-key]

        manifest = store.load_json(RunStore.MANIFEST, {}) or {}
        manifest.update({"template_id": spec.id, "template_name": spec.name,
                         "template_route_reason": verdict["reason"],
                         "template_auto": True})
        store.save_json(RunStore.MANIFEST, manifest)

        # parse_document が書いたトレースの template_id を実際の選択で上書きする
        tr = PipelineTrace.from_raw(state.get("trace_main", {}) or {})
        tr.template_id = spec.id
        state["trace_main"] = tr.raw()

        store.logger().info("[template] %s (%s)", spec.id, verdict["reason"])
        _update_status(state, "route_template", "done",
                       f"テンプレート: {spec.name}"
                       + ("" if verdict["confident"] else "（決め手なし→汎用）"))
        return state

    # ------------------------------------------------------------------
    def prepare_html_text(state: WorkflowState) -> WorkflowState:
        _update_status(state, "prepare_html_text")
        html_paths = [state["excel_html_path"]] if state.get("excel_html_path") else []
        state["html_text_sources"] = collect_html_text_sources(html_paths=html_paths, max_chars_each=150000)
        _update_status(state, "prepare_html_text", "done")
        return state

    # ------------------------------------------------------------------
    def chunk_text(state: WorkflowState) -> WorkflowState:
        _update_status(state, "chunk_text")
        md_text = Path(state["markdown_path"]).read_text(encoding="utf-8", errors="ignore")

        led = LossLedger()
        recs, rep = structural_chunks_traced(
            md_text,
            chunk_chars=wf.chunk_chars,
            overlap=wf.chunk_overlap,
            min_informative_chars=wf.min_chunk_informative_chars,
            drop_low_info=wf.drop_low_info_chunks,
            repeat_table_header=True,
            source_label=Path(state["markdown_path"]).name,
        )
        led.drop("text_chunk", rep["dropped_low_info"],
                 f"情報量 < {wf.min_chunk_informative_chars} 文字", severity="medium")
        for src in state.get("html_text_sources", []):
            r2, rep2 = structural_chunks_traced(
                src["text"], chunk_chars=wf.chunk_chars, overlap=wf.chunk_overlap,
                min_informative_chars=wf.min_chunk_informative_chars,
                drop_low_info=wf.drop_low_info_chunks, repeat_table_header=True,
                source_label=str(src.get("label") or src.get("path") or "html"),
            )
            recs.extend(r2)
            led.drop("text_chunk", rep2["dropped_low_info"],
                     f"情報量 < {wf.min_chunk_informative_chars} 文字（HTML 由来）",
                     severity="medium")
        led.observe("text_chunk", len(recs) + led.dropped_total("text_chunk"))

        # v3.7 は texts[:40] で黙って尾部を捨てていた。v3.8 は既定で無制限
        # （max_text_chunks<=0）。上限を掛ける場合も必ず台帳に残す。
        if wf.max_text_chunks and wf.max_text_chunks > 0 and len(recs) > wf.max_text_chunks:
            led.drop("text_chunk", len(recs) - wf.max_text_chunks,
                     f"max_text_chunks={wf.max_text_chunks} 上限", severity="high",
                     detail="文書後半が要約に反映されません。上限を 0（無制限）に")
            recs = recs[: wf.max_text_chunks]

        chunks_dir = Path(state["run_dir"]) / "chunks"
        chunks_dir.mkdir(parents=True, exist_ok=True)
        chunks: List[Dict[str, Any]] = []
        for i, rec in enumerate(recs):
            cid = f"text_chunk_{i + 1:04d}"
            p = chunks_dir / f"{cid}.md"
            p.write_text(rec["text"], encoding="utf-8")
            chunks.append({"chunk_id": cid, "source_type": "structural",
                           "source": state["markdown_path"], "text": rec["text"],
                           "path": str(p),
                           # ---- v3.8 溯源 ----
                           "page": rec.get("page"),
                           "heading": rec.get("heading", ""),
                           "section_index": rec.get("section_index"),
                           "slice_index": rec.get("slice_index"),
                           "has_table": rec.get("has_table", False),
                           "table_header_repeated": rec.get("table_header_repeated", False),
                           "low_info": rec.get("low_info", False)})
        state["chunks"] = chunks
        state["loss_text"] = led.raw()
        _save_json({"chunk_report": rep, "conservation": conservation_check(led, "text_chunk")},
                   chunks_dir / "_chunk_report.json")
        if chunks:
            _update_status(state, "chunk_text", "running", f"{len(chunks)} チャンク",
                           peek=f"「{chunks[0]['text'][:60].strip()}…」から読み始めます")
        if not chunks and state.get("route") != "vision":
            # 視覚直読ルートでは本文が空なのは想定内（視覚分岐が主役）なのでエラー扱いしない
            _push_error(state, "chunk_text",
                        "本文から有効なチャンクが生成されませんでした（文書が短すぎるか、"
                        "min_chunk_informative_chars が高すぎる可能性）")
        _update_status(state, "chunk_text", "done", f"{len(chunks)} チャンク")
        return {"chunks": chunks, "loss_text": state["loss_text"],
                "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    _CATEGORIES = " | ".join(spec.categories)
    EXTRACT_SYSTEM = f"""あなたは文書整理エージェントです。
文書の断片から「{spec.name}」要約に使える証拠情報を抽出してください。
{spec.extraction_hint}

JSON のみを出力してください。形式：
{{
  "evidence": [
    {{
      "category": "{_CATEGORIES}",
      "content": "string",
      "confidence": 0.0
    }}
  ]
}}

ルール：
1. 捏造しない。断片に有用な情報がなければ evidence は空配列。
2. 製品名・システム名・部門名・日付・数値・ツール名は保持する。
3. content は日本語または原文で正確に。
"""

    def _extract_one(chunk: Dict[str, Any]) -> List[Evidence]:
        user = f"""以下は文書の断片です。テンプレート要約に関係する証拠を抽出してください。

chunk_id: {chunk["chunk_id"]}

--- 断片開始 ---
{chunk["text"]}
--- 断片終了 ---
"""
        raw = llm.chat_json(system=EXTRACT_SYSTEM, user=user,
                            max_tokens=wf.extract_max_tokens,
                            json_schema=EvidenceList.model_json_schema(),
                            tag=f"extract:{chunk['chunk_id']}")
        parsed = EvidenceList.model_validate(raw)
        out = []
        for i, raw_ev in enumerate(parsed.evidence):
            ev = Evidence.model_validate(raw_ev.model_dump())
            if not ev.evidence_id:
                ev.evidence_id = f"{chunk['chunk_id']}_ev_{i + 1:03d}"
            if not ev.source:
                ev.source = chunk["chunk_id"]
            # ---- v3.8：溯源はモデルに書かせず、コードが確定的に付ける ----
            ev.chunk_id = chunk["chunk_id"]
            ev.page = chunk.get("page")
            ev.heading = chunk.get("heading", "") or ""
            ev.origin = "text"
            out.append(ev)
        return out

    def extract_text_evidence(state: WorkflowState) -> WorkflowState:
        _update_status(state, "extract_text_evidence")
        cache = Path(state["run_dir"]) / "evidence_text.json"
        # v3.11：テンプレートが前回と変わったなら証拠カテゴリの語彙も変わる。
        # run_id はファイル内容だけで決まるので、そのまま再利用すると
        # 別テンプレート用のカテゴリが付いた証拠を使い回してしまう。
        if _resume_ok(state, cache) and not state.get("template_changed"):
            state["text_evidence"] = json.loads(cache.read_text(encoding="utf-8")).get("evidence", [])
            _update_status(state, "extract_text_evidence", "done", "キャッシュ再利用")
            return {"text_evidence": state["text_evidence"], "errors": state.get("errors", [])}

        chunks = state.get("chunks", [])
        total = len(chunks)
        all_evidence: List[Evidence] = []
        done = 0
        workers = max(1, wf.extract_workers)

        def _record(chunk, result_or_exc):
            nonlocal done
            done += 1
            if isinstance(result_or_exc, Exception):
                _push_error(state, "extract_text_evidence",
                            f"{chunk['chunk_id']} 证据提取失败，已跳过", repr(result_or_exc))
                peek = f"{chunk['chunk_id']} は読めませんでした…次へ"
            else:
                all_evidence.extend(result_or_exc)
                snippet = chunk["text"][:56].replace("\n", " ").strip()
                found = f"（証拠 {len(result_or_exc)} 件）" if result_or_exc else "（証拠なし）"
                peek = f"「{snippet}…」を読みました {found}"
            _update_status(state, "extract_text_evidence", "running", f"{done}/{total}", peek=peek)

        store = _store(state)
        if workers == 1:
            for chunk in chunks:
                store.raise_if_cancelled()
                try:
                    _record(chunk, _extract_one(chunk))
                except (LLMJsonError, ValidationError, RuntimeError) as e:
                    _record(chunk, e)
        else:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {pool.submit(_extract_one, c): c for c in chunks}
                try:
                    for fut in as_completed(futures):
                        store.raise_if_cancelled()
                        chunk = futures[fut]
                        try:
                            _record(chunk, fut.result())
                        except (LLMJsonError, ValidationError, RuntimeError) as e:
                            _record(chunk, e)
                except RunCancelled:
                    pool.shutdown(cancel_futures=True)
                    raise

        state["text_evidence"] = [e.model_dump(mode="json") for e in all_evidence]
        _save_json({"evidence": state["text_evidence"]}, cache)
        _update_status(state, "extract_text_evidence", "done", f"{total} チャンク / {len(all_evidence)} 証拠")
        return {"text_evidence": state["text_evidence"], "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    def aggregate(state: WorkflowState) -> WorkflowState:
        _update_status(state, "aggregate_evidence")
        items = [Evidence.model_validate(d) for d in state.get("text_evidence", [])]
        led = LossLedger.from_raw(state.get("loss_text"))
        agg = aggregate_evidence(
            items,
            min_confidence=wf.min_evidence_confidence,
            max_per_category=wf.max_evidence_per_category,
            max_total_chars=wf.max_evidence_pack_chars,
            ledger=led,
        )
        state["loss_text"] = led.raw()
        state["aggregated_evidence"] = [e.model_dump(mode="json") for e in agg]
        _save_json({"before": len(items), "after": len(agg), "evidence": state["aggregated_evidence"]},
                   Path(state["run_dir"]) / "evidence_aggregated.json")
        _update_status(state, "aggregate_evidence", "done", f"{len(items)} -> {len(agg)}",
                       peek=f"証拠 {len(items)} 件を整理して {len(agg)} 件に絞りました")
        return {"aggregated_evidence": state["aggregated_evidence"],
                "loss_text": state["loss_text"]}

    # ------------------------------------------------------------------
    def gap_fill(state: WorkflowState) -> WorkflowState:
        """
        agent 化的第一步：观察证据覆盖情况 -> 发现缺口 -> 针对性再行动。
        关键类别（依頼元/期間/効果等）没有任何证据时，用文档开头部分
        （标题页/概要通常在前面）做一次聚焦的补提取，只问缺的类别。
        单次调用、有界，不会显著拖慢流水线。
        """
        _update_status(state, "gap_fill")
        if not wf.gap_fill:
            _update_status(state, "gap_fill", "done", "無効")
            return {"aggregated_evidence": state.get("aggregated_evidence", [])}

        have = {d["category"] for d in state.get("aggregated_evidence", [])}
        missing = [c for c in spec.key_categories if c not in have]
        if not missing:
            _update_status(state, "gap_fill", "done", "欠落なし",
                           peek="必要な情報は揃っています")
            return {"aggregated_evidence": state.get("aggregated_evidence", [])}
        _update_status(state, "gap_fill", "running", "",
                       peek=f"『{'、'.join(missing)}』の情報が見つからないので探し直します…")

        doc_head = Path(state["markdown_path"]).read_text(encoding="utf-8", errors="ignore")[: wf.gap_fill_context_chars]
        user = f"""文書全体から、以下のカテゴリの証拠だけを重点的に探してください（他のカテゴリは不要）：

{", ".join(missing)}

--- 文書（先頭部分）---
{doc_head}
--- 文書終了 ---
"""
        try:
            raw = llm.chat_json(system=EXTRACT_SYSTEM, user=user,
                                max_tokens=wf.extract_max_tokens,
                                json_schema=EvidenceList.model_json_schema(),
                                tag="gap_fill:main")
            parsed = EvidenceList.model_validate(raw)
            added = 0
            for i, ev in enumerate(parsed.evidence):
                if ev.category not in missing:
                    continue  # 只收缺口类别，避免重复噪声
                ev.evidence_id = ev.evidence_id or f"gapfill_ev_{i + 1:03d}"
                ev.source = ev.source or "gap_fill"
                state["aggregated_evidence"].append(ev.model_dump(mode="json"))
                added += 1
            _save_json({"missing": missing, "added": added,
                        "evidence": state["aggregated_evidence"]},
                       Path(state["run_dir"]) / "evidence_aggregated.json")
            _update_status(state, "gap_fill", "done", f"欠落 {len(missing)} 類 / 補充 {added} 件")
        except (LLMJsonError, ValidationError, RuntimeError) as e:
            _push_error(state, "gap_fill", "缺口回填失败（非致命）", repr(e))
            _update_status(state, "gap_fill", "done", "失敗（続行）")
        return {"aggregated_evidence": state.get("aggregated_evidence", []),
                "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    def collect_visuals(state: WorkflowState) -> WorkflowState:
        _update_status(state, "collect_visual_assets", peek="図や画像を探しています…")
        suffix = Path(state["input_path"]).suffix.lower()
        raw_paths: List[str] = []
        pdf_meta = ""
        vision_route = state.get("route") == "vision"

        vtr = PipelineTrace()

        if vision_route and suffix in (".xlsx", ".xlsm") and _excel_com_ready():
            # ---- v3.8 修正：視覚ルートの Excel は LibreOffice ではなく Excel COM ----
            #
            # ここに分岐が無かったのが v3.8 の取りこぼし。視覚ルートは
            # `if vision_route:` が最優先で走るため、Excel も一律 LibreOffice
            # 変換の PDF（vision_pdf_path）を見に行っていた。つまり
            # excel_sheet_pdfs（PageSetup で横 1 ページに収める）は
            # **視覚ルートでは一度も呼ばれない**——横に広い表が数十ページの
            # 断片に飛び散る、まさに避けたかった経路をそのまま通っていた。
            #
            # Excel COM が使えるなら、シート単位・横 1 ページ設定で描画する。
            # 使えない環境では下の通常経路（LibreOffice）へ落ちる。
            vtr.use("visual", ENGINE_WIN32COM,
                    "各シートを横 1 ページ設定で PDF 化 → 頁画像")
            raw_paths, pdf_meta = _excel_page_images(state, wf)
            if not raw_paths:
                vtr.fallback("visual", ENGINE_WIN32COM, ENGINE_LIBREOFFICE,
                             "Excel COM の描画が空だった")
                _push_error(state, "collect_visual_assets",
                            "Excel COM でのシート描画が空だったため LibreOffice 経路へ後退",
                            "")
                src_pdf = state.get("vision_pdf_path", "")
                if src_pdf:
                    result = render_pdf_pages(
                        src_pdf, out_dir=str(Path(state["run_dir"]) / "visual_pages"),
                        max_pages=wf.vision_route_max_render_pages,
                        scale=wf.pdf_render_scale)
                    raw_paths = result.get("visual_asset_paths", [])
                    pdf_meta = f"頁描画 {result.get('pages_rendered', 0)}"
        elif vision_route:
            # v3.6 視覚直読：ページそのものを画像化して VLM に読ませる。
            # PDF はそのまま、Office は parse_document が作った PDF 経由。
            src_pdf = (state["input_path"] if suffix == ".pdf"
                       else state.get("vision_pdf_path", ""))
            if src_pdf:
                _update_status(state, "collect_visual_assets", "running", "",
                               peek="ページを画像にしています…")
                vtr.use("visual", ENGINE_PYPDFIUM,
                        f"全頁を画像化（scale {wf.pdf_render_scale}）")
                result = render_pdf_pages(
                    src_pdf, out_dir=str(Path(state["run_dir"]) / "visual_pages"),
                    max_pages=wf.vision_route_max_render_pages,
                    scale=wf.pdf_render_scale)
                raw_paths = result.get("visual_asset_paths", [])
                pdf_meta = f"頁描画 {result.get('pages_rendered', 0)}/{result.get('pages_total', 0)}"
                if not result.get("ok"):
                    _push_error(state, "collect_visual_assets", "ページ描画失敗（非致命）",
                                str(result.get("error", "")))
            if not raw_paths and suffix in (".pptx", ".docx", ".xlsx", ".xlsm"):
                # PDF 変換手段が無い時のフォールバック：埋め込み画像だけでも視覚分析する
                #
                # v3.11：上限を vision_route_max_render_pages(40) から本文ルートと
                # 同じ max_visual_assets*4(120) に揃えた。頁数の上限を画像枚数の
                # 上限に流用していたのは単なる取り違えで、最も資産が少ない
                # この経路にだけ一番きつい上限が掛かっていた。
                result = extract_office_visuals(
                    state["input_path"],
                    out_dir=str(Path(state["run_dir"]) / "visual_office"),
                    max_assets=wf.max_visual_assets * 4)
                raw_paths = result.get("visual_asset_paths", [])
                pdf_meta = f"埋込 {result.get('embedded', 0)}（頁描画不可）"
                # v3.11：EMF/WMF は Pillow で開けず黙って捨てられる。日本語資料では
                # ここが最大の欠落源なので、何枚捨てたかを必ず表に出す。
                if result.get("skipped_vector"):
                    pdf_meta += f"・ベクタ図スキップ {result['skipped_vector']}"
        elif suffix == ".pdf":
            # v3.2 修复：LibreOffice→HTML 对 PDF 基本产不出图，
            # 改用 pypdfium2 直接提取内嵌图对象 + 图像型页面整页渲染兜底
            result = extract_pdf_visuals(
                state["input_path"],
                out_dir=str(Path(state["run_dir"]) / "visual_pdf"),
                max_assets=wf.max_visual_assets * 4,
                extract_embedded=wf.pdf_extract_embedded,
                render_fallback=wf.pdf_render_fallback,
                render_min_text_chars=wf.pdf_render_min_text_chars,
                render_scale=wf.pdf_render_scale,
            )
            raw_paths = result.get("visual_asset_paths", [])
            pdf_meta = f"埋込 {result.get('embedded', 0)} / 頁描画 {result.get('pages_rendered', 0)}"
            if not result.get("ok"):
                _push_error(state, "collect_visual_assets", "PDF 视觉提取失败（非致命）",
                            str(result.get("error", "")))
        elif suffix in (".xlsx", ".xlsm"):
            vtr.use("visual", ENGINE_WIN32COM if _excel_com_ready() else ENGINE_OPENPYXL,
                    "Excel のグラフ画像／シート画像"
                    if _excel_com_ready() else "埋込画像のみ（Excel COM 不在）")
            # v3.7：Excel のグラフは xl/media に無い（ベクタ定義）。Excel COM が
            # 使えるなら実画像として書き出して Agent 2 に渡す。無ければ
            # 埋め込み画像だけ拾い、グラフの数値は本文側で表になっている。
            raw_paths, pdf_meta = _excel_visuals(state, wf)
        elif suffix in (".pptx", ".docx"):
            # v3.5 修复：OOXML 直接解 ZIP 取 media/ 原图（旧 LibreOffice→HTML 链路
            # 在新版 LO 上因 data: URI 内联而静默产出 0 资产）
            result = extract_office_visuals(
                state["input_path"],
                out_dir=str(Path(state["run_dir"]) / "visual_office"),
                max_assets=wf.max_visual_assets * 4,
            )
            raw_paths = result.get("visual_asset_paths", [])
            pdf_meta = f"埋込 {result.get('embedded', 0)}"
            if result.get("skipped_vector"):
                pdf_meta += f" / ベクタ図スキップ {result['skipped_vector']}"
            if not result.get("ok"):
                _push_error(state, "collect_visual_assets",
                            "OOXML 图片提取失败，回落 LibreOffice 链路", str(result.get("error", "")))
                raw_paths = []
        if suffix not in (".pdf",) and not raw_paths:
            # 旧格式（.ppt/.doc/.xls）或 ZIP 通道无产出时的兜底
            try:
                result = collect_visual_assets(
                    input_path=state["input_path"],
                    run_dir=state["run_dir"],
                    preferred_html_path=state.get("excel_html_path"),
                    max_assets=wf.max_visual_assets * 4,
                )
                if result.get("ok") and result.get("visual_asset_paths"):
                    raw_paths = result["visual_asset_paths"]
            except Exception:  # noqa: BLE001
                _push_error(state, "collect_visual_assets", "视觉资产收集异常（非致命）",
                            traceback.format_exc()[:2000])

        # v3：廉价预过滤 + 降采样，VLM 调用次数和 prompt 体积双降
        # v3.6：視覚直読ではページ全体を読ませるため、解像度と枚数の上限を上げる
        #       （1024px まで縮めると本文の文字が潰れて読めなくなる）
        filt = prefilter_and_downscale_images(
            raw_paths,
            work_dir=str(Path(state["run_dir"]) / "visual_filtered"),
            min_edge_px=wf.image_min_edge_px,
            min_bytes=wf.image_min_bytes,
            max_edge_px=(wf.vision_route_page_max_edge_px if vision_route else wf.image_max_edge_px),
            max_assets=(wf.vision_route_max_render_pages if vision_route else wf.max_visual_assets),
        )
        state["visual_asset_paths"] = filt["kept"]
        # v3.8：prefilter は「装飾画像を間引く」ために書かれた関数だが、視覚ルートでは
        # 入力が「資料そのもののページ」になる。同じ閾値（SHA1 重複除去・最小バイト数・
        # 枚数上限）が真逆の意味を持つので、何をどれだけ落としたかを必ず記録する。
        vled = LossLedger()
        vled.observe("visual_asset", len(raw_paths))
        vled.drop("visual_asset", filt.get("deduped", 0),
                  "内容が同一（SHA1 重複）", severity=("high" if vision_route else "low"),
                  detail=("ページ画像の重複除去は白紙ページ等を消す恐れ" if vision_route else ""))
        vled.drop("visual_asset", filt.get("dropped", 0),
                  f"最小サイズ未満（{wf.image_min_bytes}B / {wf.image_min_edge_px}px）",
                  severity=("high" if vision_route else "low"))
        _cap = (wf.vision_route_max_render_pages if vision_route else wf.max_visual_assets)
        _left = len(raw_paths) - filt.get("deduped", 0) - filt.get("dropped", 0)
        if _left > _cap:
            vled.drop("visual_asset", _left - _cap, f"枚数上限 {_cap} 超過",
                      severity="high", detail="後半のページ/図が要約に届いていません")
        state["loss_visual"] = vled.raw()
        vtr.use("visual", ENGINE_PILLOW, f"前処理・降采样（{len(raw_paths)} → {len(filt['kept'])}）")
        state["trace_visual"] = vtr.raw()
        _save_json({"raw_count": len(raw_paths), **{k: v for k, v in filt.items() if k != "kept"},
                    "kept_count": len(filt["kept"]), "kept": filt["kept"],
                    "loss": vled.to_dict()},
                   Path(state["run_dir"]) / "visual_assets_manifest.json")
        meta = f"{len(raw_paths)} -> {len(filt['kept'])}（重複 {filt['deduped']} / 除外 {filt['dropped']}）"
        if pdf_meta:
            meta = f"{pdf_meta}：{meta}"
        _update_status(state, "collect_visual_assets", "done", meta)
        # 并行分支节点只返回自己写的 key（返回整个 state 会与文本分支冲突）
        return {"visual_asset_paths": state["visual_asset_paths"],
                "loss_visual": state.get("loss_visual", {}),
                "trace_visual": state.get("trace_visual", {}),
                "errors_visual": state.get("errors_visual", [])}

    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    VISION_SYSTEM = """あなたは視覚文書分析エージェントです。
文書から抽出された画像・図表・フロー図・アーキテクチャ図・実験結果・スクリーンショットを分析します。

JSON のみを出力してください。形式：
{
  "has_useful_visual_info": true,
  "visual_type": "architecture_diagram | workflow_diagram | chart | table | screenshot | photo | simulation_result | mixed | decoration | unknown",
  "readable_text": ["string"],
  "visual_summary": "string",
  "key_facts": ["string"],
  "possible_relevance": ["background", "issue", "request_scope", "action", "tool", "finding", "effect"],
  "confidence": 0.0
}

ルール：装飾なら has_useful_visual_info=false。不確実なら捏造せず不確実と述べる。
"""

    # v3.8：ページ全体を読ませるときに上の VISION_SYSTEM を使い回すのは誤り。
    # 「装飾なら false」という指示のせいで、図の無い文字だけのスライドに対して
    # モデルが false を返し、ページ全文の書き起こしが丸ごと捨てられていた。
    # ページモードでは「これは資料の本文であって、挿絵ではない」と明示する。
    PAGE_SYSTEM = """あなたは視覚文書エージェントの中でも、ページ全体の読み取りを担当します。
入力画像は挿絵ではなく、**資料そのもののページ**です。OCR と読解を行います。

JSON のみを出力してください。形式：
{
  "has_useful_visual_info": true,
  "visual_type": "text_page | slide | table | chart | mixed | unknown",
  "readable_text": ["string"],
  "visual_summary": "string",
  "key_facts": ["string"],
  "possible_relevance": ["background", "issue", "request_scope", "action", "tool", "finding", "effect"],
  "confidence": 0.0
}

ルール：
1. has_useful_visual_info は**常に true**。ページに文字がある限り「無用」ではない。
2. readable_text はページ上の文字を上から順に、要約せず原文のまま列挙する。
   行数の上限は無い。表は行ごとに 1 要素として書く。
3. 読めない箇所は推測で埋めず「（判読不能）」と書く。捏造しない。
"""

    def _analyze_one_visual(idx: int, img: str, page_mode: bool = False) -> VisualEvidence:
        if page_mode:
            # v3.6 視覚直読：入力は「資料そのもののページ」。図の説明ではなく
            # ページに書かれている内容の読み取りを最優先させる（Docling の代役）。
            user = f"""これは資料の {idx + 1} ページ目です。ページ全体を読み取ってください。

1. 本文・見出し・表・グラフの軸ラベル・注記など、**読み取れる文字は
   readable_text にできるだけ漏らさず**書き出す（要約せず原文で）。
2. visual_summary にはこのページが何を述べているかを 1〜3 文で。
3. key_facts には数値・条件・期間・製品名・ツール名など具体的な事実を。

以下のテンプレート項目に役立つか判断してください：
依頼元の課題 / 当部への依頼内容 / 実施内容 / 使用機器・ソフト・ツール / 判明した事実 / 対応効果
"""
        else:
            user = f"""この画像を分析してください。

asset_index: {idx + 1}

以下のテンプレート項目に役立つか判断してください：
依頼元の課題 / 当部への依頼内容 / 実施内容 / 使用機器・ソフト・ツール / 判明した事実 / 対応効果
"""
        # v3.8：2048 では日本語 1 ページの全文書き起こしが途中で切れ、JSON が壊れ、
        # 例外扱いで**ページ丸ごと skip** されていた。ページモードでは上限を上げる。
        raw = vision_llm.chat_vision_json(
            image_path=img,
            system=(PAGE_SYSTEM if page_mode else VISION_SYSTEM),
            user_text=user,
            max_tokens=(wf.vision_page_max_tokens if page_mode else wf.vision_asset_max_tokens),
            json_schema=VisualEvidence.model_json_schema(),
            tag=f"vision:asset_{idx + 1:04d}",
        )
        ve = VisualEvidence.model_validate(raw)
        ve.evidence_id = f"visual_asset_{idx + 1:04d}"
        ve.image_path = img
        # ---- v3.8 溯源：ファイル名に埋まっている頁/シート情報を捨てない ----
        meta = _asset_provenance(img, idx, page_mode)
        ve.page = meta["page"]
        ve.sheet_name = meta["sheet_name"]
        ve.asset_kind = meta["asset_kind"]
        if page_mode:
            ve.has_useful_visual_info = True   # ページは常に資料本体
        return ve

    def analyze_visual(state: WorkflowState) -> WorkflowState:
        _update_status(state, "analyze_visual")
        cache = Path(state["run_dir"]) / "evidence_visual.json"
        if _resume_ok(state, cache):
            state["visual_evidence"] = json.loads(cache.read_text(encoding="utf-8")).get("evidence", [])
            _update_status(state, "analyze_visual", "done", "キャッシュ再利用")
            return {"visual_evidence": state["visual_evidence"],
                    "errors_visual": state.get("errors_visual", [])}

        paths = state.get("visual_asset_paths", [])
        total = len(paths)
        visual: List[VisualEvidence] = []
        done = 0
        workers = max(1, wf.vision_workers)
        # 視覚直読ルートでは 1 枚 = 資料 1 ページ。プロンプトを読み取り重視に切り替える
        page_mode = state.get("route") == "vision"

        failed: List[int] = []

        def _record(idx, result_or_exc):
            nonlocal done
            done += 1
            if isinstance(result_or_exc, Exception):
                # v3.8：ここは「JSON が壊れてページ丸ごと消える」入口だった。
                # errors に 1 行残るだけで UI では埋もれるので、台帳にも積む。
                failed.append(idx + 1)
                _push_error(state, "analyze_visual", f"视觉资产 {idx + 1} 分析失败，已跳过", repr(result_or_exc))
                peek = f"画像 {idx + 1} は解析できませんでした…次へ"
            else:
                visual.append(result_or_exc)
                vs = (result_or_exc.visual_summary or result_or_exc.visual_type or "").strip()
                peek = f"画像『{Path(paths[idx]).name}』を見ました：{vs[:50]}"
            _update_status(state, "analyze_visual", "running", f"{done}/{total}", peek=peek)

        store = _store(state)
        if workers == 1 or total <= 1:
            for idx, img in enumerate(paths):
                store.raise_if_cancelled()
                try:
                    _record(idx, _analyze_one_visual(idx, img, page_mode))
                except (LLMJsonError, ValidationError, RuntimeError) as e:
                    _record(idx, e)
        else:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {pool.submit(_analyze_one_visual, i, p, page_mode): i
                               for i, p in enumerate(paths)}
                try:
                    for fut in as_completed(futures):
                        store.raise_if_cancelled()
                        idx = futures[fut]
                        try:
                            _record(idx, fut.result())
                        except (LLMJsonError, ValidationError, RuntimeError) as e:
                            _record(idx, e)
                except RunCancelled:
                    pool.shutdown(cancel_futures=True)
                    raise

        # 頁順（頁が無ければ evidence_id 順）。信頼度順に並べ替えない。
        visual.sort(key=lambda v: (v.page if v.page is not None else 10**6, v.evidence_id))
        state["visual_evidence"] = [v.model_dump(mode="json") for v in visual]
        _save_json({"evidence": state["visual_evidence"]}, cache)

        vled = LossLedger.from_raw(state.get("loss_visual"))
        vled.observe("visual_evidence_analysis", total)
        vled.drop("visual_evidence_analysis", len(failed),
                  "VLM 応答の JSON 解析に失敗（出力上限超過の可能性）", severity="high",
                  detail=f"対象: {failed[:20]}" if failed else "")
        state["loss_visual"] = vled.raw()

        _update_status(state, "analyze_visual", "done", f"{total} 枚分析")
        return {"visual_evidence": state["visual_evidence"],
                "loss_visual": state["loss_visual"],
                "errors_visual": state.get("errors_visual", [])}

    # ------------------------------------------------------------------
    SUMMARY_SYSTEM = f"""あなたは日本語の業務文書要約エージェントです。
証拠に基づき、「{spec.name}」の構造化 JSON を生成します。

{spec.summary_instructions}

重要ルール：
1. evidence で確認できる情報のみ使用する。
2. 依頼元・システム名・期間・効果・ツールを捏造しない。
3. 証拠が不足している項目は「資料内で確認できず」と書く。
4. 出力は合法な JSON のみ。最終言語は日本語。
5. evidence フィールドには使用した証拠 ID を列挙する。
"""

    EXPAND_SYSTEM = """あなたは日本語の業務文書要約エージェントです。
既に作られた要約の**特定の項目だけ**を、証拠に基づいて詳しく書き直します。

JSON のみを出力してください。形式：
{"items": ["string", "string"]}

ルール：
1. 証拠に無いことは書かない。一般論・推測で字数を埋めるのは禁止。
2. 1 項目につき 1 つの事実。60〜120 文字程度で、何を・どの条件で・
   どうなったかまで書く。「対応した」「改善した」で止めない。
3. 数値・単位・固有名詞・日付は証拠の表記どおりに保持する。
4. 証拠が足りなければ**項目を増やさない**。短いままで良い。
5. 元の項目の意味を変えない。言い換えて詳しくするだけ。
"""

    #: 二段目で書き足す対象。事実の羅列になりやすく、かつ読み手が
    #: 一番知りたい項目に絞る（全項目を伸ばすと呼び出し回数が跳ねる）。
    _EXPAND_FIELDS = ("findings", "effects", "background", "client_issues",
                      "scope_of_request", "key_results", "discussion",
                      "conclusions", "main_content", "key_points", "purpose")

    def _expand_one_field(label: str, current: List[str],
                          evidence_pack: str) -> Optional[List[str]]:
        """1 項目を証拠に基づいて書き足す。失敗したら None（元のまま使う）。"""
        user = f"""項目「{label}」を詳しく書き直してください。

現在の内容：
{json.dumps(current, ensure_ascii=False)}

根拠として使える証拠：
{evidence_pack}

現在の内容と同じ事実を、証拠の範囲内でより具体的に述べ直してください。
証拠に無い項目を新しく足してはいけません。"""
        try:
            raw = llm.chat_json(system=EXPAND_SYSTEM, user=user,
                                max_tokens=wf.expand_max_tokens,
                                temperature=wf.expand_temperature,
                                tag=f"expand:{label}")
        except (LLMJsonError, RuntimeError):
            return None
        items = raw.get("items") if isinstance(raw, dict) else None
        if not isinstance(items, list):
            return None
        out = [str(x).strip() for x in items if str(x).strip()]
        return out or None

    def expand_summary(state: WorkflowState) -> WorkflowState:
        """二段階書き出しの二段目：指定項目だけを証拠に基づいて伸ばす。

        一段目（write_summary）は temperature 0 ＋ 構造制約で「正しい骨格」を
        作ることに専念させ、ここで初めて表現を厚くする。一発で「正確かつ詳しく」
        を要求すると、弱いモデルは字数を満たすために作話を始める——だから
        課題を 2 つに割る。

        伸ばすのは**証拠がある項目だけ**。空欄や「確認できず」は触らない
        （そこを埋めさせるのが作話の入口になる）。
        """
        if not wf.expand_summary or state.get("summary_degraded"):
            return {}
        summary = state.get("summary") or {}
        if not summary:
            return {}
        _update_status(state, "expand_summary", peek="要約を証拠に沿って書き足しています…")

        pack = json.dumps({"text_evidence": state.get("aggregated_evidence", [])},
                          ensure_ascii=False, separators=(",", ":"))
        pack = pack[: wf.expand_evidence_chars]

        labels = {f: (getattr(spec, "field_labels", {}) or {}).get(f, f)
                  for f in _EXPAND_FIELDS}
        changed: List[str] = []
        skipped: List[str] = []

        from .contract import is_blank

        # 加筆対象を先に集める。1 項目 = LLM 1 回なので上限を掛け、
        # 内容が多い項目（＝読み手が一番読む所）から優先して使う。
        targets: List[tuple] = []

        def _collect(node: Any) -> None:
            if not isinstance(node, dict):
                return
            for key, val in node.items():
                if isinstance(val, dict):
                    _collect(val)
                elif key in _EXPAND_FIELDS and isinstance(val, list):
                    if is_blank(val):
                        skipped.append(key)   # 空欄は触らない（埋めさせない）
                    else:
                        targets.append((node, key, val))

        _collect(summary)
        targets.sort(key=lambda t: sum(len(str(x)) for x in t[2]), reverse=True)
        budget = max(0, int(wf.expand_max_fields))
        deferred = [k for _, k, _ in targets[budget:]]

        # 加筆結果は必ず数値検証を通す。字数を満たすために数値を作るのが
        # 弱いモデルの典型的な失敗なので、プロンプトの禁止だけに頼らない。
        from .deep_read import verify_items
        rejected: List[Dict[str, Any]] = []

        for parent, key, val in targets[:budget]:
            before = sum(len(str(x)) for x in val)
            got = _expand_one_field(labels.get(key, key), [str(x) for x in val], pack)
            if not got or sum(len(x) for x in got) <= before:
                continue
            if wf.expand_verify_numbers:
                check = verify_items(got, pack)
                if not check["ok"]:
                    # 1 つでも裏が取れない数値があれば、その回の加筆を丸ごと捨てる。
                    # 部分採用は文どうしの整合が崩れてかえって危ない。
                    rejected.append({"field": key, "reason": check["reason"],
                                     "unsupported": check["unsupported"][:5]})
                    _push_error(state, "expand_summary",
                                f"「{labels.get(key, key)}」の加筆を破棄しました"
                                f"（証拠に無い数値を含むため）",
                                check["reason"])
                    continue
            parent[key] = got
            changed.append(key)
        state["summary"] = summary
        state["expanded_fields"] = changed
        _save_json({"expanded": changed, "skipped_blank": skipped,
                    "deferred_over_budget": deferred,
                    "rejected_fabrication": rejected,
                    "llm_calls": min(len(targets), budget)},
                   Path(state["run_dir"]) / "expand_report.json")
        _update_status(state, "expand_summary", "done",
                       f"{len(changed)} 項目を加筆"
                       + (f" / {len(rejected)} 項目を破棄（作話検出）" if rejected else ""),
                       peek=(f"{len(changed)} 項目を証拠に沿って書き足しました"
                             if changed else "加筆できる項目はありませんでした"))
        return {"summary": summary, "expanded_fields": changed}

    # ------------------------------------------------------------------
    def deep_read(state: WorkflowState) -> WorkflowState:
        """精読モード：ページ単位で本文証拠と視覚証拠を突き合わせる。

        逐次 refine にはしない（誤りの伝播と直列の遅さを避けるため）。
        ページ内の突き合わせだけを確定的な規則で行い、集約は従来の
        map-reduce のまま残す。LLM 呼び出しは 1 回も増えない。
        """
        if not wf.deep_read:
            return {"page_report": {}}
        _update_status(state, "deep_read", peek="ページごとに本文と図を突き合わせています…")
        from .deep_read import build_page_report, summary_lines as dr_lines

        report = build_page_report(state.get("aggregated_evidence", []),
                                   state.get("visual_evidence", []))
        state["page_report"] = report
        _save_json(report, Path(state["run_dir"]) / "page_report.json")

        lines = dr_lines(report)
        store = _store(state)
        for line in lines:
            store.logger().info("[deep_read] %s", line)
        detail = (f"{report.get('page_count', 0)} ページ / 要確認 "
                  f"{report.get('conflict_count', 0)}")
        peek = (f"{report['conflict_count']} ページで数値の食い違いを見つけました"
                if report.get("conflict_count") else "ページ間の食い違いはありませんでした")
        _update_status(state, "deep_read", "done", detail, peek=peek)
        return {"page_report": report}

    # ------------------------------------------------------------------
    def _build_summary_user(state: WorkflowState) -> str:
        template_def = spec.raw_yaml
        fewshot = ""
        try:
            from .feedback import get_fewshot_block
            fewshot = get_fewshot_block(config, spec.id)
        except Exception:  # noqa: BLE001 飞轮不可用不影响主流程
            pass
        # 視覚直読ルートでは視覚証拠が本文そのもの。既定の 8000 字上限では
        # ページの読み取り結果が切り捨てられるので、証拠パック全体の予算を回す。
        visual_budget = (wf.max_evidence_pack_chars if state.get("route") == "vision" else 8000)
        pack = {
            "text_evidence": state.get("aggregated_evidence", []),
            "visual_evidence": visual_to_pack(
                [VisualEvidence.model_validate(d) for d in state.get("visual_evidence", [])],
                max_total_chars=visual_budget,
                readable_text_limit=wf.visual_readable_text_limit,
            ),
        }
        # ---- v3.9：精読モードの突き合わせ結果 ----
        # 「食い違いがある」という事実だけを渡す。どちらが正しいかの裁定は
        # 弱いモデルに任せず、断定を避けるよう指示する。
        page_block = ""
        if wf.deep_read and state.get("page_report"):
            from .deep_read import report_to_prompt_block
            page_block = report_to_prompt_block(state["page_report"])
            if page_block:
                page_block = "\n" + page_block + "\n"

        # ---- v3.8：文書メタ（ファイル名・見出し）を prompt に入れる ----
        # v3.7 では入力ファイル名も文書タイトルも一度も prompt に届いていなかった。
        # 「ファイルに名前もタイトルも有るのに『資料内で確認できず』になる」の
        # 直接原因がこれ。モデルの賢さに頼らず、事実として渡す。
        doc_meta = _document_meta(state)
        # v3.1 prompt 瘦身：紧凑 JSON（indent=2 会放大 30-50% token）
        # + skeleton 替代完整 schema（1519 -> 410 chars，仍由契约自动生成）
        return f"""テンプレート定義（YAML）：

{template_def}
{fewshot}
文書メタ情報（ファイル自体から確定的に取得。推測ではありません）：

{json.dumps(doc_meta, ensure_ascii=False)}
{page_block}
抽出された証拠：

{json.dumps(pack, ensure_ascii=False, separators=(",", ":"))}

以下の形式に厳密に従う JSON を生成してください：

{json.dumps(spec.skeleton(), ensure_ascii=False)}
"""

    def write_summary(state: WorkflowState) -> WorkflowState:
        # 分支汇合点：把视觉分支的错误并回主 errors，后续节点与 UI 只需看一处
        if state.get("errors_visual"):
            state["errors"] = _all_errors(state)
            state["errors_visual"] = []
        n_ev = len(state.get("aggregated_evidence", [])) + len(state.get("visual_evidence", []))
        _update_status(state, "write_summary",
                       peek=f"{n_ev} 件の証拠をもとに要約を書いています…")
        raw = llm.chat_json(
            system=SUMMARY_SYSTEM, user=_build_summary_user(state),
            max_tokens=8192, json_schema=spec.json_schema(),
            tag="summary:main",
        )
        try:
            summary = spec.model.model_validate(raw)
            state["summary_degraded"] = False
            state["summary_errors"] = []
        except ValidationError as e:
            summary = _lenient_summary(raw, spec.model)
            state["summary_raw"] = raw
            state["summary_degraded"] = True
            state["summary_errors"] = [str(e)]
            _push_error(state, "write_summary", "摘要 JSON 未通过契约校验，进入修复回路", str(e))

        summary = spec.post_process(summary)
        summary = _fill_case_name(summary, state)
        state["summary"] = summary.model_dump(mode="json")
        _update_status(state, "write_summary", "done")
        return state

    # ------------------------------------------------------------------
    def validate_summary(state: WorkflowState) -> WorkflowState:
        _update_status(state, "validate_summary")
        try:
            spec.model.model_validate(state.get("summary", {}))
            errors: List[str] = []
        except ValidationError as e:
            errors = [str(e)]

        if state.get("summary_degraded"):
            errors = list(state.get("summary_errors", [])) + errors
            if not errors:
                errors = ["原始 LLM 输出未通过契约校验（已降级），需要修复"]

        summary = state.get("summary", {})
        title = spec.title_of(summary)
        warnings = (["主要項目が「確認できず」です。入力文書と証拠抽出を確認してください。"]
                    if title in ("", UNKNOWN) else [])

        state["validation"] = {"ok": not errors, "errors": errors, "warnings": warnings}
        # ---- v3.8：覆盖率とテンプレート不一致の判定 ----
        # 「ファイル名もタイトルも有るのに全項目が『資料内で確認できず』」の
        # 正体は多くの場合テンプレート不一致。人が気付く前に数値で示す。
        try:
            from .accounting import compute_fill_rate, template_mismatch_verdict
            from .contract import is_blank
            fill = compute_fill_rate(state.get("summary", {}) or {},
                                     getattr(spec, "field_applicability", {}) or {},
                                     is_blank)
            verdict = template_mismatch_verdict(
                fill, getattr(spec, "min_fill_rate", 0.4), spec.name)
            if isinstance(state.get("validation"), dict):
                state["validation"]["fill_rate"] = fill
                state["validation"]["template_verdict"] = verdict
                if verdict.get("mismatch"):
                    state["validation"].setdefault("warnings", []).append(verdict["message"])
                    state["validation"]["suggested_template"] = "generic_doc"
        except Exception:  # noqa: BLE001 判定の失敗で本流を止めない
            pass

        # ---- v3.8：品質レポートに「どれだけ落としたか」を載せる ----
        # v3.7 の quality_report は JSON schema 検証だけだった。つまり
        # 「形式は正しいが中身が半分欠けている」を正常と判定していた。
        # ---- v3.9：要約本体の数値も証拠と突き合わせる ----
        # 加筆だけでなく一段目の要約も数値を作りうる。ここは破棄はせず
        # （骨格を捨てると出力が空になる）、警告として明示する。人が
        # 「根拠情報」から辿れるように、疑わしい数値をそのまま列挙する。
        try:
            from .deep_read import unsupported_numbers
            ev_blob = json.dumps(state.get("aggregated_evidence", []), ensure_ascii=False)
            vis = state.get("visual_evidence", []) or []
            ev_blob += json.dumps(vis, ensure_ascii=False)
            summary_blob = json.dumps(state.get("summary", {}), ensure_ascii=False)
            bad = unsupported_numbers(summary_blob, ev_blob)
            if isinstance(state.get("validation"), dict):
                state["validation"]["unsupported_numbers"] = bad[:20]
                if bad:
                    state["validation"].setdefault("warnings", []).append(
                        "証拠に見当たらない数値が要約に含まれています（"
                        + "、".join(b["text"] for b in bad[:5])
                        + "）。原文で確認してください")
        except Exception:  # noqa: BLE001 検証の失敗で本流を止めない
            pass

        # ---- v3.9：実行トレース（ルート・使用実装）を品質レポートへ ----
        try:
            tr = PipelineTrace.from_raw(state.get("trace_main"))
            tr.merge(PipelineTrace.from_raw(state.get("trace_visual")))
            if isinstance(state.get("validation"), dict):
                state["validation"]["pipeline_trace"] = tr.to_dict()
                state["validation"]["pipeline_summary"] = tr.summary_lines()
            _save_json(tr.to_dict(), Path(state["run_dir"]) / "pipeline_trace.json")
        except Exception:  # noqa: BLE001 トレースの失敗で本流を止めない
            pass

        led = LossLedger.from_raw(state.get("loss_text"))
        led.merge(LossLedger.from_raw(state.get("loss_visual")))
        loss = led.to_dict()
        if isinstance(state.get("validation"), dict):
            state["validation"]["loss_ledger"] = loss
            state["validation"]["coverage_summary"] = led.summary_lines()
            if loss.get("has_critical_loss"):
                state["validation"].setdefault("warnings", []).append(
                    "入力の相当部分が要約に届いていません（損失台帳を確認してください）")
        _save_json(state["validation"], Path(state["run_dir"]) / "quality_report.json")
        _update_status(state, "validate_summary", "done")
        return state

    # ------------------------------------------------------------------
    REPAIR_SYSTEM = """あなたは JSON 修復エージェントです。
与えられた JSON はスキーマ検証に失敗しました。エラーメッセージに基づいて修正し、
スキーマに厳密に従う合法な JSON のみを出力してください。値の内容は変えず、構造だけ直してください。
"""

    def repair_summary(state: WorkflowState) -> WorkflowState:
        _update_status(state, "repair_summary", peek="JSON の形が崩れていたので直しています…")
        state["repair_attempts"] = state.get("repair_attempts", 0) + 1
        errors = "\n".join(state.get("validation", {}).get("errors", []))
        target = state.get("summary_raw") or state.get("summary", {})
        user = f"""検証エラー：

{errors}

修復対象の JSON：

{json.dumps(target, ensure_ascii=False, indent=2)}

出力形式：

{json.dumps(spec.skeleton(), ensure_ascii=False)}
"""
        try:
            raw = llm.chat_json(system=REPAIR_SYSTEM, user=user, max_tokens=8192,
                                json_schema=spec.json_schema(),
                                tag="repair:summary")
            try:
                summary = spec.model.model_validate(raw)
                state["summary_degraded"] = False
                state["summary_errors"] = []
                state.pop("summary_raw", None)
            except ValidationError as ve:
                summary = _lenient_summary(raw, spec.model)
                state["summary_raw"] = raw
                state["summary_errors"] = [str(ve)]
            summary = spec.post_process(summary)
            summary = _fill_case_name(summary, state)
            state["summary"] = summary.model_dump(mode="json")
        except (LLMJsonError, RuntimeError) as e:
            _push_error(state, "repair_summary", f"第 {state['repair_attempts']} 次修复失败", repr(e))
        _update_status(state, "repair_summary", "done")
        return state

    # ------------------------------------------------------------------
    def render(state: WorkflowState) -> WorkflowState:
        _update_status(state, "render")
        from .render import render_markdown

        run_dir = Path(state["run_dir"])
        summary = spec.model.model_validate(state["summary"])

        out_json = run_dir / "case_summary.json"
        _save_json(summary.model_dump(mode="json"), out_json)
        state["output_json"] = str(out_json)

        out_md = run_dir / "case_summary.md"
        render_markdown(summary, str(spec.md_template_path), str(out_md))
        # 版本快照：每次成功渲染都归档一份（重跑/HITL 修订永不丢历史）
        try:
            from .versions import snapshot
            snapshot(run_dir, note="pipeline")
        except Exception:  # noqa: BLE001
            pass
        state["output_markdown"] = str(out_md)

        _update_status(state, "render", "done")
        return state

    # ------------------------------------------------------------------
    def redact_external(state: WorkflowState) -> WorkflowState:
        """社外脱敏版：规则层（NG 词典）→ LLM 泛化改写（泄漏复检，可回退）。"""
        if not config.redaction.enabled:
            _update_status(state, "redact_external", "done", "無効")
            return state
        _update_status(state, "redact_external", peek="社外公開用に固有情報を伏せています…")
        run_dir = Path(state["run_dir"])
        try:
            dictionary = NGDictionary.load(config.paths.resolve(config.redaction.dictionary_path))
            external, report = redact_summary(
                state["summary"], dictionary,
                llm=llm if config.redaction.llm_rewrite else None,
                llm_rewrite=config.redaction.llm_rewrite,
                model=spec.model,
            )
            _save_json(external.model_dump(mode="json"), run_dir / "case_summary_external.json")
            _save_json(report, run_dir / "redaction_report.json")
            from .render import render_markdown
            render_markdown(external, str(spec.md_template_path),
                            str(run_dir / "case_summary_external.md"))
            n = sum(report.get("replacement_counts", {}).values()) if "replacement_counts" in report else                 sum(report.get("alias_map", {}) and [1] or [0])
            counts = report.get("replacement_counts", {})
            llm_used = report.get("llm_rewrite", {}).get("applied")
            detail = f"置換 {sum(counts.values())} 箇所" + ("・LLM 改写採用" if llm_used else "・規則のみ")
            _update_status(state, "redact_external", "done", detail)
        except Exception:  # noqa: BLE001 脱敏失败不毁掉社内版产出
            _push_error(state, "redact_external", "社外版生成失败（社内版不受影响）",
                        traceback.format_exc()[:2000])
            _update_status(state, "redact_external", "done", "失敗（続行）")
        return state

    # ------------------------------------------------------------------
    def rag_export(state: WorkflowState) -> WorkflowState:
        """RAG 出口：embedding-ready JSONL 落盘（internal 必出，external 视脱敏而定）。"""
        _update_status(state, "rag_export")
        run_dir = state["run_dir"]
        try:
            p_int = rag_write_jsonl(run_dir, "internal")
            p_ext = rag_write_jsonl(run_dir, "external")
            n_int = len(Path(p_int).read_text(encoding="utf-8").strip().split("\n")) if p_int else 0
            n_ext = len(Path(p_ext).read_text(encoding="utf-8").strip().split("\n")) if p_ext else 0
            _update_status(state, "rag_export", "done",
                           f"社内 {n_int} 件" + (f" / 社外 {n_ext} 件" if n_ext else ""))
        except Exception:  # noqa: BLE001
            _push_error(state, "rag_export", "RAG 导出失败（非致命）", traceback.format_exc()[:1500])
            _update_status(state, "rag_export", "done", "失敗（続行）")
        _update_status(state, "finished", "done", peek="完成しました！")
        return state

    return {
        "create_run_dir": create_run_dir,
        "parse_document": parse_document,
        "route_template": route_template,
        "prepare_html_text": prepare_html_text,
        "chunk_text": chunk_text,
        "extract_text_evidence": extract_text_evidence,
        "aggregate_evidence": aggregate,
        "deep_read": deep_read,
        "expand_summary": expand_summary,
        "gap_fill": gap_fill,
        "collect_visual_assets": collect_visuals,
        "analyze_visual": analyze_visual,
        "write_summary": write_summary,
        "validate_summary": validate_summary,
        "repair_summary": repair_summary,
        "render": render,
        "redact_external": redact_external,
        "rag_export": rag_export,
    }


def _excel_text_pass(state: WorkflowState, store: RunStore, input_path, md_path) -> bool:
    """
    v3.7 Excel 専用の本文抽出。

    Docling(openpyxl 既定) は数式セルを `=SUM(...)` という**文字列**のまま返し、
    グラフは `xl/media` に無いので丸ごと欠落する——大型 xlsm が「中身が取れない」
    と見える主因。ここで 計算結果・数式・グラフの実数値・注記 まで作り切る。
    """
    xl = workbook_to_markdown(str(input_path))
    if xl.get("ok") and xl.get("markdown", "").strip():
        md_path.write_text(xl["markdown"], encoding="utf-8")
        state["markdown_path"] = str(md_path)
        state["excel_info"] = xl.get("info", {})
        store.save_json("excel_info.json",
                        {"info": xl.get("info", {}), "charts": xl.get("charts", 0),
                         "notes": xl.get("notes", [])})
        for note in xl.get("notes", []):
            _push_error(state, "parse_document", note)   # 「見えていない物」を UI に出す
        _update_status(state, "parse_document", "done",
                       f"Excel 直読（グラフ {xl.get('charts', 0)} 件）")
        return True
    _push_error(state, "parse_document", "Excel 直読に失敗、他経路へフォールバックします",
                str(xl.get("error", "")))
    return False


def _excel_com_ready() -> bool:
    """Excel COM が使えるか（Windows + Excel 実機のみ true）。"""
    try:
        from tools.excel_com import excel_available
        return bool(excel_available())
    except Exception:  # noqa: BLE001
        return False


def _excel_page_images(state: WorkflowState, wf) -> tuple:
    """視覚ルート用：各シートを「横 1 ページに収める」設定でページ画像化する。

    数値表（numCache）経路は本文側で生きているので、ここは**裏取り用の目**。
    失敗しても空を返すだけで、呼び出し側が LibreOffice 経路へ後退する。
    """
    from tools.excel_com import excel_sheet_pdfs

    run_dir = Path(state["run_dir"])
    sheets = excel_sheet_pdfs(
        state["input_path"], str(run_dir / "visual_excel_sheets"),
        max_sheets=wf.excel_sheet_render_max_sheets,
        fit_to_width=True, landscape=wf.excel_sheet_render_landscape,
        timeout_seconds=wf.excel_sheet_render_timeout)
    pages = _render_sheet_pdfs(sheets.get("sheets", []),
                               run_dir / "visual_excel_sheets",
                               scale=wf.pdf_render_scale,
                               max_pages=wf.vision_route_max_render_pages)
    skipped = [x for x in sheets.get("sheets", []) if x.get("skipped")]
    if skipped:
        _push_error(state, "collect_visual_assets",
                    f"Excel シート {len(skipped)} 件を画像化せず（非致命）",
                    json.dumps(skipped, ensure_ascii=False)[:1500])
    meta = f"シート描画 {len(pages)} 枚（{sheets.get('exported', 0)} シート・Excel COM）"

    # ---- v3.11 修正：視覚ルートでも埋め込み画像を拾う ----
    #
    # ここが _excel_visuals との非対称だった。本文ルート（_excel_visuals）は
    # 「グラフ実画像化＋シート描画＋埋め込み画像」の三点セットなのに、
    # 視覚ルートのこちらはシート描画だけで return していた。
    #
    # シート描画は「印刷した見た目」なので貼り付け画像も一応写ってはいるが、
    # 縮小されて潰れる。元画像を別資産として渡せば VLM が細部を読める。
    # 重複は collect_visuals 側の SHA1 去重が面倒を見るので二重計上にならない。
    #
    # **シート描画が空の時は足さない**。呼び出し側は「戻り値が空か」だけで
    # 後退（LibreOffice 経路 → 埋め込み画像）を判断しているので、ここで
    # 埋め込み画像を混ぜると「COM は失敗したのに空でない」状態になり、
    # 後退そのものが黙って飛ばされてシート描画を永久に失う。
    # 空で返せば既存の後退チェーンが最終的に埋め込み画像へ辿り着くので、
    # 画像が失われることはない。
    if not pages:
        return pages, meta

    office = extract_office_visuals(
        state["input_path"],
        out_dir=str(run_dir / "visual_office"),
        max_assets=getattr(wf, "max_visual_assets", 30) * 4)
    pages.extend(office.get("visual_asset_paths", []))
    meta += f" / 埋込 {office.get('embedded', 0)}"
    if office.get("skipped_vector"):
        meta += f"・ベクタ図スキップ {office['skipped_vector']}"
    return pages, meta


def _excel_visuals(state: WorkflowState, wf) -> tuple:
    """Excel の視覚資産を集める。Excel COM があればグラフを実画像化、
    無ければ埋め込み画像のみ（グラフの数値は本文の表として既に入っている）。"""
    from tools.excel_com import excel_available, excel_extract, excel_sheet_pdfs

    run_dir = Path(state["run_dir"])
    raw_paths: List[str] = []
    meta_parts: List[str] = []

    if excel_available():
        res = excel_extract(state["input_path"], str(run_dir / "visual_excel"),
                            export_pdf=False, export_charts=True,
                            max_charts=wf.max_visual_assets)
        imgs = res.get("chart_images", [])
        raw_paths.extend(imgs)
        meta_parts.append(f"グラフ画像 {len(imgs)}")
        if not res.get("ok") and res.get("error"):
            _push_error(state, "collect_visual_assets",
                        "Excel COM でのグラフ書き出しに失敗（非致命）", str(res.get("error")))

        # ---- v3.8：シート単位のページ画像化（win32com）----
        # LibreOffice 経由だと横に広い表が数十ページに飛び散り、しかも
        # SinglePageSheets には約 1022 行でデータが欠ける既知の不具合がある。
        # Excel COM なら PageSetup で「横 1 ページに収める・縦は流す」を
        # 直接指定できるので、人が印刷して読むのと同じ物を VLM に渡せる。
        if wf.excel_sheet_render:
            sheets = excel_sheet_pdfs(
                state["input_path"], str(run_dir / "visual_excel_sheets"),
                max_sheets=wf.excel_sheet_render_max_sheets,
                fit_to_width=True, landscape=wf.excel_sheet_render_landscape,
                timeout_seconds=wf.excel_sheet_render_timeout)
            pages = _render_sheet_pdfs(sheets.get("sheets", []),
                                       run_dir / "visual_excel_sheets",
                                       scale=wf.pdf_render_scale,
                                       max_pages=wf.excel_sheet_render_max_pages)
            raw_paths.extend(pages)
            meta_parts.append(f"シート画像 {len(pages)}（{sheets.get('exported', 0)} シート）")
            if sheets.get("skipped"):
                _push_error(state, "collect_visual_assets",
                            f"Excel シート {sheets.get('skipped')} 件を画像化せず（非致命）",
                            json.dumps([x for x in sheets.get("sheets", []) if x.get("skipped")],
                                       ensure_ascii=False)[:1500])
            if not sheets.get("ok") and sheets.get("error"):
                _push_error(state, "collect_visual_assets",
                            "Excel シートのページ画像化に失敗（非致命・数値表経路は生きています）",
                            str(sheets.get("error")))
    else:
        n_charts = len(extract_charts(state["input_path"]))
        if n_charts:
            meta_parts.append(f"グラフ {n_charts} 件は数値表として本文に取込済")

    office = extract_office_visuals(state["input_path"],
                                    out_dir=str(run_dir / "visual_office"),
                                    max_assets=wf.max_visual_assets * 4)
    raw_paths.extend(office.get("visual_asset_paths", []))
    meta_parts.append(f"埋込 {office.get('embedded', 0)}")
    return raw_paths, " / ".join(meta_parts)


def _fill_case_name(summary, state: Dict[str, Any]):
    """case_name が空 / UNKNOWN のとき、確定的に埋める。

    「ファイルに名前もタイトルも有るのに『資料内で確認できず』になる」への
    最後の歯止め。モデルの判断を待たず、コードが事実で埋める：
        文書の先頭見出し > ファイル名（拡張子なし）
    これは推測ではない——ファイル名も見出しも資料そのものの一部。
    """
    try:
        current = (getattr(summary, "case_name", "") or "").strip()
    except Exception:  # noqa: BLE001 モデルに case_name が無いテンプレートもある
        return summary
    if current and current != UNKNOWN:
        return summary
    meta = _document_meta(state)
    fallback = (meta.get("document_title") or "").strip() or (meta.get("file_stem") or "").strip()
    if not fallback:
        return summary
    try:
        summary.case_name = fallback
        if hasattr(summary, "finalize_titles"):
            summary.finalize_titles()
    except Exception:  # noqa: BLE001
        pass
    return summary


def _asset_provenance(img: str, idx: int, page_mode: bool) -> Dict[str, Any]:
    """画像ファイル名に埋め込まれた頁/シート情報を取り出す。

    v3.7 は PDF 抽出画像が pdf_p003_img01.png と頁番号を持っていたのに、
    VLM へは asset_index しか渡さず、VisualEvidence にも頁の枠が無かった。
    せっかく有る情報を捨てていたので、ここで拾い直す。

    対応する命名（app/parsing.py と tools/excel_com.py 由来）：
        pdf_p003_img01.png  -> 3 頁の埋込画像
        pdf_p003_page.png   -> 3 頁の全面レンダリング
        page_003.png        -> 視覚ルートの全面レンダリング
        sheet_02_売上.png   -> Excel シート画像
        office_p003_image7.png -> 3 頁目に置かれた OOXML 埋込画像
        office_image3.png   -> OOXML 埋込（頁が辿れなかった場合）
    """
    name = Path(img).name
    out: Dict[str, Any] = {"page": None, "sheet_name": "", "asset_kind": "embedded"}
    m = re.match(r"pdf_p(\d+)_(img\d+|page)", name)
    if m:
        out["page"] = int(m.group(1))
        out["asset_kind"] = "page_render" if m.group(2) == "page" else "embedded"
        return out
    m = re.match(r"page_(\d+)", name)
    if m:
        out["page"] = int(m.group(1))
        out["asset_kind"] = "page_render"
        return out
    m = re.match(r"office_p(\d+)_", name)
    if m:
        out["page"] = int(m.group(1))
        out["asset_kind"] = "embedded"
        return out
    m = re.match(r"sheet_(\d+)_(.+?)_p(\d+)\.", name) or re.match(r"sheet_(\d+)_(.+?)\.", name)
    if m:
        out["page"] = int(m.group(3)) if m.lastindex and m.lastindex >= 3 else int(m.group(1))
        out["sheet_name"] = m.group(2)
        out["asset_kind"] = "sheet_render"
        return out
    if name.startswith("chart"):
        out["asset_kind"] = "chart"
        return out
    # 頁が特定できない資産（OOXML の media など）。視覚ルートなら通し番号を
    # 頁の代わりに使う（順序が保てるだけでも突き合わせの役に立つ）
    if page_mode:
        out["page"] = idx + 1
        out["asset_kind"] = "page_render"
    return out


def _document_meta(state: Dict[str, Any]) -> Dict[str, Any]:
    """ファイル自体から確定的に取れるメタ情報を集める。

    LLM に推測させず「事実」として渡すための物。case_name が
    「資料内で確認できず」になる事故の大半は、そもそもファイル名も
    見出しも prompt に入っていなかったことが原因だった。
    """
    src = Path(state.get("input_path", "") or "")
    meta: Dict[str, Any] = {
        "file_name": src.name,
        "file_stem": src.stem,          # 拡張子を除いた名前＝人が付けた題名であることが多い
        "file_type": src.suffix.lstrip(".").lower(),
    }
    # 本文の最初の見出しを文書タイトル候補として拾う
    title = ""
    md = state.get("markdown_path")
    if md:
        try:
            for line in Path(md).read_text(encoding="utf-8", errors="ignore").split("\n")[:200]:
                if line.startswith("#"):
                    cand = line.lstrip("#").strip()
                    # 「ページ 1」等の機械的見出しはタイトルではない
                    if cand and not re.match(r"^(ページ|スライド|シート|page|slide|sheet)\s*\d+$",
                                             cand, re.I):
                        title = cand
                        break
        except Exception:  # noqa: BLE001
            pass
    meta["document_title"] = title
    chunks = state.get("chunks") or []
    pages = [c.get("page") for c in chunks if c.get("page")]
    if pages:
        meta["page_range"] = [min(pages), max(pages)]
    if state.get("excel_info"):
        # excel_extract の info["sheets"] は**枚数（int）**。シート名の一覧は
        # 別経路（COM / workbook_to_markdown）でしか取れないので型で分岐する。
        sheets = (state["excel_info"] or {}).get("sheets")
        if isinstance(sheets, int) and sheets > 0:
            meta["sheet_count"] = sheets
        elif isinstance(sheets, (list, tuple)) and sheets:
            meta["sheet_names"] = [str(x) for x in sheets][:30]
    meta["route"] = state.get("route", "")
    return meta


def _render_sheet_pdfs(sheet_meta: List[Dict[str, Any]], out_dir: Path,
                       scale: float = 2.0, max_pages: int = 40) -> List[str]:
    """excel_sheet_pdfs が出した 1 シート 1 PDF を、ページ画像へ展開する。

    ファイル名に `sheet_{index}_{name}_p{page}.png` の形でシート名と頁を埋める
    ——後段の `_asset_provenance` がここから溯源を復元する。
    """
    from .parsing import render_pdf_pages

    out_dir.mkdir(parents=True, exist_ok=True)
    produced: List[str] = []
    for meta in sheet_meta:
        if meta.get("skipped") or not meta.get("pdf_path"):
            continue
        if len(produced) >= max_pages:
            break
        try:
            res = render_pdf_pages(meta["pdf_path"], str(out_dir / "_tmp"),
                                   max_pages=max(1, max_pages - len(produced)), scale=scale)
        except Exception:  # noqa: BLE001 1 シート失敗しても他は続ける
            continue
        pages = res.get("visual_asset_paths", []) if isinstance(res, dict) else (res or [])
        safe = str(meta.get("name", "sheet")).replace(" ", "_")[:40]
        for i, src in enumerate(pages):
            dst = out_dir / f"sheet_{int(meta.get('index', 0)):02d}_{safe}_p{i + 1:03d}.png"
            try:
                shutil.move(str(src), str(dst))
                produced.append(str(dst))
            except Exception:  # noqa: BLE001
                continue
    return produced


def _lenient_summary(raw: dict, model) -> Any:
    """尽力解析（模板无关）：坏字段回落契约默认值。"""
    try:
        return model.model_validate(raw)
    except ValidationError:
        pass
    cleaned: Dict[str, Any] = {}
    for field in model.model_fields:
        if field not in raw:
            continue
        try:
            model.__pydantic_validator__.validate_assignment(model(), field, raw[field])
            cleaned[field] = raw[field]
        except ValidationError:
            continue
    try:
        return model.model_validate(cleaned)
    except ValidationError:
        return model()
