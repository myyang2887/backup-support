"""Slice stacks: many parallel slices computed ahead of time.

A stack lets the slice slider be scrubbed with near-exact pictures: while the
slider moves, the browser blends the two stack slices around the position
(milliseconds); when it stops, the exact computation takes over as before.

Layout of a stack (StackPlan):

  t      positions along the stack direction (P,)
  u, v   in-plane sample coordinates (nu,), (nv,)
  values float32 (P, nv, nu) -- row-major [plane][v][u], NaN = not fluid

Everything follows the data, so no single resolution is imposed:
  * t steps by `along` x the data spacing at each position (a FloEFD mesh
    gets a slice per layer plus a midpoint: 0.05 mm at a wall, millimetres
    further out);
  * u and v are non-uniform the same way along each in-plane axis, so a
    vertical cut keeps the thin near-wall layers without sampling the whole
    height at that pitch.
Values are computed from the source points at the exact 3D positions with
the same evaluator as the exports (services.field_evaluator).

Stacks are cached on disk (cache_dir/stacks), keyed by the source file
signature, fluid rule, evaluator settings, request and algorithm version;
a changed file or setting never reuses a stale stack.
"""
from __future__ import annotations

import hashlib
import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from fdpost.core.plane import (AXIS_INDEX, IN_PLANE, euler_normal, plane_basis,
                               plane_box_extent)
from fdpost.domain.errors import FieldNotFoundError, SampleBudgetError, SliceGeometryError
from fdpost.domain.requests import StackRequest
from fdpost.services.field_evaluator import ALGORITHM_VERSION, FLUID, FieldEvaluator

log = logging.getLogger("fdpost.services.slice_stack")

STACK_FORMAT = 1
MIN_STEP_M = 1e-6


@dataclass
class StackPlan:
    mode: str
    axis: str | None
    normal: np.ndarray
    origin: np.ndarray           # t is measured from here along `normal`
    u_hat: np.ndarray
    v_hat: np.ndarray
    t: np.ndarray
    u: np.ndarray
    v: np.ndarray
    labels: tuple[str, str]
    data_spacing: dict[str, Any]

    @property
    def shape(self) -> tuple[int, int, int]:
        return (int(self.t.size), int(self.v.size), int(self.u.size))

    @property
    def n_samples(self) -> int:
        p, nv, nu = self.shape
        return p * nv * nu

    def points(self, t: float) -> np.ndarray:
        """(nv*nu, 3) world points of the slice at t, row-major [v][u]."""
        base = self.origin + t * self.normal
        return (base + self.u[None, :, None] * self.u_hat
                + self.v[:, None, None] * self.v_hat).reshape(-1, 3)

    def describe(self) -> dict[str, Any]:
        p, nv, nu = self.shape
        return {"mode": self.mode, "axis": self.axis,
                "normal": self.normal.tolist(), "origin": self.origin.tolist(),
                "u_hat": self.u_hat.tolist(), "v_hat": self.v_hat.tolist(),
                "t": self.t.tolist(), "u": self.u.tolist(), "v": self.v.tolist(),
                "labels": list(self.labels), "dims": [p, nv, nu],
                "n_samples": self.n_samples, "data_spacing": self.data_spacing}


def _walk(lo: float, hi: float, prof: dict[str, Any], factor: float, cap: int,
          which: str = "spacing_p10") -> tuple[np.ndarray, float]:
    """Positions from lo to hi, each step = factor x data spacing there
    (never below 1 um), hi included. Coarsened uniformly if over `cap`."""
    tx, sy = np.asarray(prof["t"]), np.asarray(prof[which])
    f = float(factor)
    for _ in range(12):
        pos = [lo]
        while pos[-1] < hi:
            step = max(MIN_STEP_M, f * float(np.interp(pos[-1], tx, sy)))
            nxt = pos[-1] + step
            if nxt >= hi - 0.25 * step:
                pos.append(hi)
                break
            pos.append(nxt)
            if len(pos) > cap * 4:
                break
        if len(pos) <= cap:
            return np.unique(np.asarray(pos, dtype=np.float64)), f
        f *= len(pos) / cap * 1.02
    raise SliceGeometryError("could not plan the stack within the plane limit")


def plan_stack(ev: FieldEvaluator, req: StackRequest) -> StackPlan:
    lo, hi = ev.bounds
    c = (lo + hi) / 2
    if req.mode == "axis":
        ai = AXIS_INDEX[req.axis]
        ua, va = IN_PLANE[req.axis]
        ui, vi = AXIS_INDEX[ua], AXIS_INDEX[va]
        n = np.eye(3)[ai]
        u_hat, v_hat = np.eye(3)[ui], np.eye(3)[vi]
        origin = np.zeros(3)
        t_lo, t_hi = float(lo[ai]), float(hi[ai])
        labels = (f"{ua.upper()} [m]", f"{va.upper()} [m]")
        u_rng = (float(lo[ui]), float(hi[ui]))
        v_rng = (float(lo[vi]), float(hi[vi]))
        prof_u = ev.spacing_profile(u_hat, np.zeros(3))
        prof_v = ev.spacing_profile(v_hat, np.zeros(3))
    else:
        n = euler_normal(req.tilt_deg, req.azimuth_deg)
        u_hat, v_hat = plane_basis(n)
        origin = c
        tt = (ev.fd.points - c) @ n
        t_lo, t_hi = float(tt.min()), float(tt.max())
        labels = ("u [m]", "v [m]")
        u_rng = v_rng = None
        prof_u = ev.spacing_profile(u_hat, c)
        prof_v = ev.spacing_profile(v_hat, c)
    if req.t_range is not None:
        t_lo, t_hi = max(t_lo, req.t_range[0]), min(t_hi, req.t_range[1])
        if not t_hi > t_lo:
            raise SliceGeometryError("the requested range does not overlap the data")
    prof_n = ev.spacing_profile(n, origin)
    t, f_along = _walk(t_lo, t_hi, prof_n, req.along, req.max_planes)
    if u_rng is None:                       # tilted: union of plane-box extents
        us, vs = [], []
        for ti in t:
            ext = plane_box_extent(origin + ti * n, n, u_hat, v_hat, lo, hi)
            if ext is not None:
                us += list(ext[0])
                vs += list(ext[1])
        if not us:
            raise SliceGeometryError("the planes do not intersect the data box")
        u_rng, v_rng = (min(us), max(us)), (min(vs), max(vs))
    u, f_u = _walk(u_rng[0], u_rng[1], prof_u, req.inplane, req.max_inplane)
    v, f_v = _walk(v_rng[0], v_rng[1], prof_v, req.inplane, req.max_inplane)
    ds = {"along_mm": [prof_n["spacing_min"] * 1e3, prof_n["spacing_max"] * 1e3],
          "u_mm": [prof_u["spacing_min"] * 1e3, prof_u["spacing_max"] * 1e3],
          "v_mm": [prof_v["spacing_min"] * 1e3, prof_v["spacing_max"] * 1e3],
          "coarsened": {"along": f_along / req.along, "u": f_u / req.inplane,
                        "v": f_v / req.inplane}}
    return StackPlan(mode=req.mode, axis=req.axis if req.mode == "axis" else None,
                     normal=n, origin=origin, u_hat=u_hat, v_hat=v_hat,
                     t=t, u=u, v=v, labels=labels, data_spacing=ds)


def build_stack(ev: FieldEvaluator, plan: StackPlan, field: str, method: str,
                report=None) -> np.ndarray:
    """(P, nv, nu) float32; NaN where the sample is not fluid."""
    p, nv, nu = plan.shape
    out = np.empty((p, nv, nu), dtype=np.float32)
    per = nv * nu
    group = max(1, 131_072 // max(per, 1))
    for g0 in range(0, p, group):
        idx = range(g0, min(p, g0 + group))
        pts = np.concatenate([plan.points(float(plan.t[i])) for i in idx])
        st, _ = ev.classify(pts)

        def sub(x: float, a=g0, n=len(idx)) -> None:
            if report:
                report((a + x * n) / p, "計算中")
        vals = ev.evaluate([field], pts, st, method=method, progress=sub).values[field]
        vals[st != FLUID] = np.nan
        out[g0:g0 + len(idx)] = vals.reshape(len(idx), nv, nu).astype(np.float32)
        if report:
            report((g0 + len(idx)) / p, "計算中")
    return out


def quantize(values: np.ndarray) -> tuple[bytes, float, float]:
    """uint16 per sample for the browser: lo + q*(hi-lo)/65534, 65535 = NaN.
    Display only (relative resolution 1.5e-5 of the range)."""
    fin = np.isfinite(values)
    if fin.any():
        lo, hi = float(values[fin].min()), float(values[fin].max())
    else:
        lo, hi = 0.0, 1.0
    if hi <= lo:
        hi = lo + max(abs(lo) * 1e-9, 1e-12)
    q = np.full(values.shape, 65535, dtype=np.uint16)
    q[fin] = np.rint((values[fin] - lo) / (hi - lo) * 65534).astype(np.uint16)
    return q.astype("<u2").tobytes(), lo, hi


class SliceStackService:
    def __init__(self, store: Any, settings: Any) -> None:
        self.store = store
        self.settings = settings

    @property
    def root(self) -> Path:
        d = Path(self.settings.cache_dir) / "stacks"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _key(self, ev: FieldEvaluator, req: StackRequest) -> str:
        body = {"fmt": STACK_FORMAT, "algo": ALGORITHM_VERSION, "sig": ev.signature,
                "cfg": ev.cfg.__dict__, "req": req.model_dump(mode="json")}
        return hashlib.sha1(json.dumps(body, sort_keys=True).encode()).hexdigest()[:20]

    def _prepare(self, ds_id: str, req: StackRequest):
        ev = self.store.get_evaluator(ds_id)
        if req.field not in ev.fd.fields:
            raise FieldNotFoundError(f"field '{req.field}' not in the source data; "
                                     f"available: {sorted(ev.fd.fields)}")
        plan = plan_stack(ev, req)
        if plan.n_samples > self.settings.stack_max_samples:
            raise SampleBudgetError(
                f"{plan.shape[0]} slices x {plan.shape[2]} x {plan.shape[1]} = "
                f"{plan.n_samples:,} samples exceeds the limit of "
                f"{self.settings.stack_max_samples:,}; narrow the range or lower the density")
        return ev, plan, self._key(ev, req)

    def cached(self, key: str) -> bool:
        return (self.root / f"{key}.npy").is_file() and (self.root / f"{key}.json").is_file()

    # -- estimate ------------------------------------------------------------
    def estimate(self, ds_id: str, req: StackRequest, probe: int = 16_000) -> dict[str, Any]:
        """Measured cost. The probe is laid out like the build itself: whole
        rows of a few slices spread over the range (stratified), in the same
        row-major order. Scattered random points would be several times
        slower per point than the coherent rows the build evaluates (tree
        lookups lose their locality), and over-estimate the time."""
        t0 = time.perf_counter()
        ev, plan, key = self._prepare(ds_id, req)
        p, nv, nu = plan.shape
        rng = np.random.default_rng(0)
        ns = int(min(p, 8))
        edges = np.linspace(0, p, ns + 1)
        slices = [int(min(p - 1, a + rng.random() * (b - a))) for a, b in zip(edges[:-1], edges[1:])]
        rows = int(max(1, min(nv, probe // max(ns * nu, 1))))
        chunks = []
        for i in slices:
            r0 = int(rng.integers(0, nv - rows + 1))
            q = plan.points(float(plan.t[i])).reshape(nv, nu, 3)[r0:r0 + rows]
            chunks.append(q.reshape(-1, 3))
        pts = np.concatenate(chunks)
        m = len(pts)
        st, _ = ev.classify(pts[:64])                     # warm-up: trees and fits
        ev.evaluate([req.field], pts[:64], st, method=req.method)
        warm = time.perf_counter() - t0
        # timed twice: the first pass on a freshly loaded dataset still pays
        # for lazily built structures (seen 4x slower); the build will not
        per = np.inf
        for _ in range(2):
            t1 = time.perf_counter()
            st, _ = ev.classify(pts)
            ev.evaluate([req.field], pts, st, method=req.method)
            per = min(per, (time.perf_counter() - t1) / max(m, 1))
        return {"key": key, "cached": self.cached(key), "plan": {
                    "dims": [p, nv, nu], "n_samples": plan.n_samples,
                    "t_range": [float(plan.t[0]), float(plan.t[-1])],
                    "u_range": [float(plan.u[0]), float(plan.u[-1])],
                    "v_range": [float(plan.v[0]), float(plan.v[-1])],
                    "data_spacing": plan.data_spacing},
                "bytes_server": plan.n_samples * 4, "bytes_browser": plan.n_samples * 2,
                "estimate_s": round(per * plan.n_samples, 1), "warmup_s": round(warm, 2),
                "fluid_fraction_in_probe": float((st == FLUID).mean())}

    # -- build ---------------------------------------------------------------
    def submit(self, ds_id: str, req: StackRequest, jobs: Any):
        ev, plan, key = self._prepare(ds_id, req)

        def work(report):
            if self.cached(key):
                report(1.0, "保存済み")
                return {"key": key, "cached": True}
            t0 = time.perf_counter()
            vals = build_stack(ev, plan, req.field, req.method, report)
            fin = vals[np.isfinite(vals)]
            meta = {"key": key, "format": STACK_FORMAT, "dataset_id": ds_id,
                    "source_signature": ev.signature, "field": req.field,
                    "unit": ev.fd.units.get(req.field, ""), "method": req.method,
                    "request": req.model_dump(mode="json"), **plan.describe(),
                    "value_range": [float(fin.min()), float(fin.max())] if fin.size else None,
                    "build_s": round(time.perf_counter() - t0, 2),
                    "created_unix": time.time(), "algorithm_version": ALGORITHM_VERSION}
            tmp = self.root / f"{key}.npy.part"
            with open(tmp, "wb") as fh:
                np.save(fh, vals)
            tmp.replace(self.root / f"{key}.npy")
            (self.root / f"{key}.json").write_text(json.dumps(meta), encoding="utf-8")
            return {"key": key, "cached": False, "build_s": meta["build_s"]}

        return jobs.submit("slice_stack", work)

    # -- access ----------------------------------------------------------------
    def meta(self, key: str) -> dict[str, Any]:
        p = self.root / f"{key}.json"
        if not p.is_file():
            raise SliceGeometryError(f"stack '{key}' not found")
        return json.loads(p.read_text(encoding="utf-8"))

    def data(self, key: str) -> tuple[bytes, dict[str, Any]]:
        meta = self.meta(key)
        vals = np.load(self.root / f"{key}.npy", mmap_mode="r")
        body, lo, hi = quantize(np.asarray(vals))
        return body, {"lo": lo, "hi": hi, "dims": meta["dims"], "encoding": "uint16-linear"}

    def list(self, ds_id: str) -> list[dict[str, Any]]:
        """Stacks built from this dataset's current source file."""
        try:
            sig = self.store.get_evaluator(ds_id).signature
        except Exception:  # noqa: BLE001 - source unreadable: nothing usable
            return []
        out = []
        for jp in sorted(self.root.glob("*.json")):
            try:
                m = json.loads(jp.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if m.get("source_signature") == sig and self.cached(m["key"]):
                out.append({k: m[k] for k in ("key", "field", "method", "mode", "axis",
                                              "normal", "dims", "n_samples", "request",
                                              "build_s", "created_unix")})
        return out

    def delete(self, key: str) -> None:
        for suf in (".npy", ".json"):
            (self.root / f"{key}{suf}").unlink(missing_ok=True)
