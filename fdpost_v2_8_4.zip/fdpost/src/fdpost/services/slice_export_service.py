"""Formal export of one slice: PNG / CSV / NPZ + manifest.json.

Every file is produced from one SliceResult (services.slice_compute_service),
so the picture and the numbers describe the same cut at the same samples.
What was requested and what was actually done -- position, sample lattice,
method per sample, classification, colour range, image size -- is written to
manifest.json; nothing is reduced or substituted without being recorded.
"""
from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from fdpost import __version__
from fdpost.config import Settings
from fdpost.domain.requests import SliceExportRequest
from fdpost.domain.slice_adapter import resolve_specs
from fdpost.io.csv_writer import write_csv
from fdpost.render.contour import render_slice_result
from fdpost.services.dataset_store import DatasetStore
from fdpost.services.slice_compute_service import SliceComputeService, SliceResult


def write_table(res: SliceResult, out: Path, formats: list[str],
                units: dict[str, str]) -> dict[str, str]:
    files: dict[str, str] = {}
    cols = res.table()
    if "csv" in formats:
        df = pd.DataFrame(cols)
        files["csv"] = str(write_csv(df, out / "slice.csv", units=units))
    if "npz" in formats:
        p = out / "slice.npz"
        num = {k: v for k, v in cols.items() if v.dtype.kind in "fiub"}
        np.savez_compressed(p, values=res.values, state=res.state, quality=res.quality,
                            u_m=res.lattice.u, v_m=res.lattice.v,
                            origin_m=res.plane.origin, u_hat=res.plane.u_hat,
                            v_hat=res.plane.v_hat, normal=res.plane.normal,
                            **({"vec_world": res.vec_world} if res.vec_world is not None
                               else {}),
                            **{f"col_{k}": v for k, v in num.items()})
        files["npz"] = str(p)
    return files


def build_manifest(res: SliceResult, req: Any, specs: Any,
                   render_actual: dict[str, Any] | None,
                   files: dict[str, str], settings: Settings) -> dict[str, Any]:
    keep = ("export_max_sample_points", "source_method", "local_linear_neighbors",
            "balanced_search_neighbors", "balanced_per_octant", "anisotropy_trigger",
            "max_condition", "idw_neighbors", "idw_power", "support_gap_factor",
            "chunk_query_points")
    eff = settings.effective()
    return {
        "schema_version": 2,
        "program": {"name": "fdpost", "version": __version__},
        "created_unix": time.time(),
        "request": req.model_dump(mode="json"),
        "adapter_notes": specs.notes,
        "resolved": {"sampling": specs.sampling.model_dump(exclude_none=True),
                     "evaluation": specs.evaluation.model_dump(exclude_none=True),
                     "render": specs.render.model_dump(exclude_none=True)},
        "result": {k: v for k, v in res.meta.items()},
        "render_actual": render_actual,
        "files": {k: Path(v).name for k, v in files.items()},
        "settings_in_force": {k: eff[k] for k in keep if k in eff},
        "state_codes": {"fluid": 0, "solid": 1, "outside": 2, "unknown": 3},
    }


class SliceExportService:
    def __init__(self, store: DatasetStore, settings: Settings) -> None:
        self.store = store
        self.settings = settings
        self.compute = SliceComputeService(store, settings)

    def specs(self, req: Any, batch: bool = False):
        s = self.settings
        return resolve_specs(req, default_long_edge=s.export_sample_long_edge,
                             default_image_px=s.export_image_long_edge_px,
                             default_dpi=s.export_dpi, batch=batch)

    def _check_image(self, specs: Any) -> None:
        r = specs.render
        long_px = (r.long_edge_px if r.size_mode == "pixels"
                   else int(round(r.print_long_edge_mm / 25.4 * r.dpi)))
        if long_px > self.settings.export_max_image_px:
            from fdpost.domain.errors import SampleBudgetError
            raise SampleBudgetError(
                f"image long edge {long_px:,} px exceeds the limit of "
                f"{self.settings.export_max_image_px:,} px")

    def phase_weights(self, ds_id: str, req: SliceExportRequest, specs: Any,
                      tail_share: float = 0.0) -> tuple[float, float, float]:
        """Cumulative bar positions (end of compute, end of drawing, end of
        writing) from a rough cost model; never fails (falls back to fixed
        shares)."""
        try:
            from fdpost.core.plane import plan_lattice, resolve_plane
            from fdpost.services.slice_compute_service import (
                CSV_S_PER_ROW, EVAL_S_PER_POINT, render_cost_s)
            grid = self.store.get_grid(ds_id)
            ev_ = specs.evaluation
            if ev_.source == "original":
                bounds = self.store.get_evaluator(ds_id, ev_.neighbors).bounds
                method = ev_.method or self.settings.source_method
            else:
                bounds, method = grid.bounds, "grid"
            plane = resolve_plane(req, bounds, grid_planes=(grid.origin, grid.spacing),
                                  center=(bounds[0] + bounds[1]) / 2)
            lat = plan_lattice(plane, specs.sampling,
                               default_long_edge=self.settings.export_sample_long_edge,
                               max_points=self.settings.export_max_sample_points)
            n = lat.shape[0] * lat.shape[1]
            c = n * (EVAL_S_PER_POINT.get(method, 2.5e-5) + 1e-6)
            r = specs.render
            px = (r.long_edge_px if r.size_mode == "pixels"
                   else int(round(r.print_long_edge_mm / 25.4 * r.dpi)))
            d = render_cost_s(px) if "png" in req.formats else 0.0
            w = (CSV_S_PER_ROW * n if "csv" in req.formats else 0.0) + 0.05
            tot = (c + d + w) / (1.0 - tail_share)
            return c / tot, (c + d) / tot, (c + d + w) / tot
        except Exception:
            return 0.85 * (1 - tail_share), 0.95 * (1 - tail_share), 1.0 - tail_share

    def run(self, ds_id: str, req: SliceExportRequest,
            progress: Any = None, tail_share: float = 0.0) -> dict[str, Any]:
        """`progress(fraction, message)` (optional): computing, drawing,
        writing files, each with a share of the bar proportional to its
        expected time (so the ETA extrapolated from early progress holds;
        a large CSV can take as long as the computation). The last
        `tail_share` is left to the caller (e.g. zipping). It may raise to
        cancel."""
        specs = self.specs(req)
        self._check_image(specs)
        rep = progress or (lambda f, m="": None)
        w_cmp, w_draw, w_write = self.phase_weights(ds_id, req, specs, tail_share)
        res = self.compute.compute(ds_id, req, req.field, specs.sampling, specs.evaluation,
                                   with_vectors=req.with_vectors,
                                   progress=lambda x: rep(w_cmp * x, "計算中"))
        rep(w_cmp, "描画中")
        out = Path(self.settings.output_dir) / f"slice_{uuid.uuid4().hex[:8]}"
        out.mkdir(parents=True, exist_ok=True)
        files: dict[str, str] = {}
        render_actual = None
        t = time.perf_counter()
        if "png" in req.formats:
            render_actual = render_slice_result(res, out / "slice.png", specs.render)
            files["png"] = str(out / "slice.png")
        res.meta["timings"]["render_s"] = round(time.perf_counter() - t, 4)
        rep(w_draw, "ファイル書き出し中")
        t = time.perf_counter()
        units = (self.store.get_grid(ds_id).units if res.meta.get("source") == "grid"
                 else {**self.store.get_grid(ds_id).units, res.field: res.unit})
        files.update(write_table(res, out, list(req.formats), units))
        res.meta["timings"]["write_s"] = round(time.perf_counter() - t, 4)
        rep(w_write, "ファイル書き出し中")
        manifest = build_manifest(res, req, specs, render_actual, files, self.settings)
        mpath = out / "manifest.json"
        mpath.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        result: dict[str, Any] = {
            **{k: v for k, v in files.items()},
            "dims": list(res.shape),
            "spacing_m": list(res.lattice.spacing),
            "fidelity": "scatter" if res.meta.get("source") == "original" else "grid",
            "source": res.meta.get("source"),
            "method_requested": res.meta.get("method_requested"),
            "method_used": res.meta.get("method_used"),
            "geometry_actual": res.meta.get("geometry_actual"),
            "geometry_requested": res.meta.get("geometry_requested"),
            "classification_summary": res.meta.get("classification_summary"),
            "render_actual": render_actual,
            "requested_px": req.resolution,
            "adapter_notes": specs.notes,
            "timings": res.meta.get("timings"),
        }
        multi = len(files) > 1 or "json" in req.formats
        if multi:
            result["manifest"] = str(mpath)
        else:
            result["manifest_path_on_server"] = str(mpath)
        return result
