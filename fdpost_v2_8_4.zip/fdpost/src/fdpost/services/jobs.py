"""Background job manager: progress, cancellation, two pools.

Every computation that takes noticeable time runs as a Job, so the UI can
show one kind of progress bar for all of them and can cancel any of them.

* progress  -- the work function calls `report(fraction, message)`. The
               snapshot adds elapsed time and, once there is enough progress
               to extrapolate from, an ETA.
* cancel    -- `cancel(job_id)` sets a flag; the next `report()` inside the
               work raises JobCancelled, so cancellation takes effect at the
               work's own checkpoints (every chunk of samples). A job still
               waiting in the queue never starts.
* pools     -- "batch" (preprocessing, batch exports; several workers) and
               "interactive" (preview computations; one worker). Previews are
               short and superseded constantly; giving them their own worker
               keeps them responsive while a long batch runs.
* results   -- JSON-able `result`, plus an optional binary `blob` (e.g. a
               slice payload) fetched separately and never put in snapshots.
Finished jobs are kept up to `history` entries, oldest evicted first.
"""
from __future__ import annotations

import logging
import threading
import time
import traceback
import uuid
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable

from fdpost.domain.errors import JobNotFoundError

log = logging.getLogger("fdpost.services.jobs")

Report = Callable[..., None]


class JobCancelled(Exception):
    """Raised inside a job's work when its cancellation was requested."""


@dataclass
class Job:
    id: str
    kind: str
    status: str = "pending"       # pending | running | done | error | cancelled
    progress: float = 0.0
    message: str = ""
    result: dict[str, Any] | None = None
    error: str | None = None
    created: float = field(default_factory=time.time)
    started: float | None = None
    finished: float | None = None
    blob: bytes | None = field(default=None, repr=False)
    blob_headers: dict[str, str] = field(default_factory=dict, repr=False)
    # a result file on disk (e.g. an export zip): downloaded once, then the
    # directory holding it is deleted; also deleted when the job is evicted
    file_path: str | None = field(default=None, repr=False)
    file_dir: str | None = field(default=None, repr=False)
    _cancel: threading.Event = field(default_factory=threading.Event, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    @property
    def cancel_requested(self) -> bool:
        return self._cancel.is_set()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            now = time.time()
            elapsed = ((self.finished or now) - self.started) if self.started else 0.0
            eta = None
            if self.status == "running" and self.progress >= 0.03:
                eta = elapsed * (1.0 - self.progress) / self.progress
            return {"id": self.id, "kind": self.kind, "status": self.status,
                    "progress": round(self.progress, 4), "message": self.message,
                    "result": self.result, "error": self.error,
                    "elapsed_s": round(elapsed, 2),
                    "eta_s": None if eta is None else round(eta, 1),
                    "has_blob": self.blob is not None,
                    "has_file": self.file_path is not None}


class JobManager:
    def __init__(self, workers: int = 2, interactive_workers: int = 1,
                 history: int = 300) -> None:
        self._pools = {
            "batch": ThreadPoolExecutor(max_workers=max(1, workers),
                                        thread_name_prefix="fdpost-job"),
            "interactive": ThreadPoolExecutor(max_workers=max(1, interactive_workers),
                                              thread_name_prefix="fdpost-ia"),
        }
        self._jobs: OrderedDict[str, Job] = OrderedDict()
        self._lock = threading.Lock()
        self._history = history

    def submit(self, kind: str, fn: Callable[[Report], dict[str, Any] | None],
               pool: str = "batch") -> Job:
        job = Job(id=uuid.uuid4().hex[:12], kind=kind)
        with self._lock:
            self._jobs[job.id] = job
            self._evict()

        def report(fraction: float, message: str = "") -> None:
            if job.cancel_requested:
                raise JobCancelled(job.id)
            with job._lock:
                job.progress = float(min(max(fraction, 0.0), 1.0))
                if message:
                    job.message = message

        report.job = job            # type: ignore[attr-defined]  # lets work attach a blob

        def run() -> None:
            if job.cancel_requested:
                with job._lock:
                    job.status, job.finished = "cancelled", time.time()
                return
            with job._lock:
                job.status, job.started = "running", time.time()
            try:
                result = fn(report)
                with job._lock:
                    job.status, job.progress = "done", 1.0
                    job.result = result
                    job.finished = time.time()
            except JobCancelled:
                drop_job_files(job)          # before the status: "cancelled" means clean
                with job._lock:
                    job.status, job.finished = "cancelled", time.time()
                log.info("job %s (%s) cancelled", job.id, job.kind)
            except Exception as e:  # noqa: BLE001
                log.error("job %s failed: %s\n%s", job.id, e, traceback.format_exc())
                drop_job_files(job)
                with job._lock:
                    job.status, job.error = "error", f"{type(e).__name__}: {e}"
                    job.finished = time.time()

        self._pools.get(pool, self._pools["batch"]).submit(run)
        return job

    def cancel(self, job_id: str) -> Job:
        job = self.get(job_id)
        job._cancel.set()
        return job

    def get(self, job_id: str) -> Job:
        with self._lock:
            if job_id not in self._jobs:
                raise JobNotFoundError(f"job '{job_id}' not found")
            return self._jobs[job_id]

    def _evict(self) -> None:
        """Drop the oldest finished jobs beyond `history` (never live ones)."""
        if len(self._jobs) <= self._history:
            return
        for jid in list(self._jobs):
            if len(self._jobs) <= self._history:
                break
            if self._jobs[jid].status in ("done", "error", "cancelled"):
                drop_job_files(self._jobs.pop(jid))

    def shutdown(self) -> None:
        for p in self._pools.values():
            p.shutdown(wait=False, cancel_futures=True)


def drop_job_files(job: Job) -> None:
    """Delete a job's result directory (if any)."""
    import shutil
    if job.file_dir:
        shutil.rmtree(job.file_dir, ignore_errors=True)
    job.file_path = job.file_dir = None


def sub_progress(report: Report | None, lo: float, hi: float,
                 message: str = "") -> Callable[[float], None]:
    """Map a 0..1 progress of one stage onto [lo, hi] of the whole job."""
    def f(x: float) -> None:
        if report is not None:
            report(lo + (hi - lo) * x, message)
    return f
