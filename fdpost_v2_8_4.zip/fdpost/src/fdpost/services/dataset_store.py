"""Dataset registry: source file -> FieldData -> cached UniformGrid (LRU)."""
from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from fdpost.config import Settings, memory_budget_bytes
from fdpost.core.resample import (estimate_resample, grid_geometry, grid_memory,
                                  resample_to_grid)
from fdpost.domain.errors import (DataLoadError, GridBuildError, JobNotFoundError,
                                  SampleBudgetError)
from fdpost.domain.requests import PreprocessConfig
from fdpost.domain.uniform_grid import LayeredGrid, UniformGrid
from fdpost.io.grid_cache import (cache_key, load_grid, save_grid,
                                  source_signature)
from fdpost.io.registry import Registry
from fdpost.io.tsv_loader import load_floefd_table
from fdpost.services.field_evaluator import EvaluatorConfig, FieldEvaluator
from fdpost.services.jobs import Job, JobManager
from fdpost.services.source_sampler import LRU

log = logging.getLogger("fdpost.services.dataset_store")


@dataclass
class DatasetInfo:
    id: str
    source_path: str
    cache_path: str
    status: str = "processing"           # processing | ready | error
    error: str | None = None
    meta: dict[str, Any] = field(default_factory=dict)
    units: dict[str, str] = field(default_factory=dict)
    fields: list[str] = field(default_factory=list)
    bounds: list[list[float]] | None = None
    dims: list[int] | None = None
    spacing: list[float] | None = None
    config: dict[str, Any] = field(default_factory=dict)
    # v2.8.3: several preprocessing grids per dataset. `base_grid` is the
    # full-domain grid in use; `detail_grids` are finer region grids laid
    # over it (see LayeredGrid). The fields above describe the base grid.
    grids: list[dict[str, Any]] = field(default_factory=list)
    base_grid: str | None = None
    detail_grids: list[str] = field(default_factory=list)

    def public(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}


class DatasetStore:
    """Thread-safe registry with an LRU of in-memory grids."""

    def __init__(self, settings: Settings, jobs: JobManager,
                 registry: Registry | None = None) -> None:
        self.settings = settings
        self.jobs = jobs
        self.registry = registry
        self._infos: dict[str, DatasetInfo] = {}
        # loaded grids by cache path (several per dataset since v2.8.3)
        self._grids: OrderedDict[str, UniformGrid] = OrderedDict()
        self._lock = threading.RLock()
        self._build_lock = threading.Lock()       # one grid build at a time
        self._evaluators: LRU[FieldEvaluator] = LRU(settings.source_sampler_lru)
        if registry is not None:
            self._restore(registry)

    def _restore(self, registry: Registry) -> None:
        """Rehydrate the registry from SQLite; grids reload lazily from cache."""
        for payload in registry.load_datasets():
            try:
                info = DatasetInfo(**payload)
            except TypeError:
                log.warning("skipping incompatible dataset row: %s",
                            payload.get("id"))
                continue
            if info.status == "ready" and not Path(info.cache_path).exists():
                info.status = "error"
                info.error = "キャッシュファイルが見つかりません(再前処理してください)"
            elif info.status == "processing":     # crashed mid-run
                info.status = "error"
                info.error = "前処理が中断されました(再前処理してください)"
            self._migrate(info)
            self._infos[info.id] = info
        log.info("restored %d dataset(s) from registry", len(self._infos))

    def _migrate(self, info: DatasetInfo) -> None:
        """Datasets from before v2.8.3 have one grid and no variant list."""
        if info.grids or info.status != "ready":
            return
        info.grids = [{"id": "g0", "label": "標準", "kind": "full",
                       "method": info.config.get("method", "idw"),
                       "spacing": info.spacing, "dims": info.dims,
                       "box": info.bounds, "region": None,
                       "cache_path": info.cache_path, "status": "ready",
                       "bytes_resident": None, "build_s": None,
                       "created": None, "config": dict(info.config)}]
        info.base_grid = "g0"
        info.detail_grids = []
        if info.dims and info.fields:
            info.grids[0]["bytes_resident"] = int(np.prod(info.dims)) * (4 * len(info.fields) + 1)

    def _persist(self, info: DatasetInfo) -> None:
        if self.registry is not None:
            self.registry.upsert_dataset(info.id, info.public())

    # -- registration ------------------------------------------------------
    def register(self, source: str | Path, cfg: PreprocessConfig) -> tuple[DatasetInfo, Job]:
        source = Path(source)
        if not source.exists():
            raise DataLoadError(f"file not found: {source}")
        sig = source_signature(source)
        key = cache_key(sig, json.dumps(cfg.model_dump(), sort_keys=True))
        cache_path = Path(self.settings.cache_dir) / f"{key}.npz"
        ds_id = uuid.uuid4().hex[:12]
        info = DatasetInfo(id=ds_id, source_path=str(source),
                           cache_path=str(cache_path),
                           config=cfg.model_dump())
        with self._lock:
            self._infos[ds_id] = info

        def work(report) -> dict[str, Any]:
            try:
                return self._work(info, source, cfg, cache_path, report)
            except Exception as e:
                with self._lock:
                    info.status = "error"
                    info.error = str(e)
                self._persist(info)
                raise

        job = self.jobs.submit("preprocess", work)
        return info, job

    def _work(self, info: DatasetInfo, source: Path, cfg: PreprocessConfig,
              cache_path: Path, report) -> dict[str, Any]:
            grid: UniformGrid | None = None
            t0 = time.perf_counter()
            if cache_path.exists():
                try:
                    report(0.05, "loading cached grid")
                    grid = load_grid(cache_path)
                    log.info("cache hit for %s", source.name)
                except Exception:
                    grid = None
            if grid is None:
                report(0.05, "loading table")
                fd = load_floefd_table(source, fluid_rule=cfg.fluid_rule)
                report(0.15, "resampling to uniform grid")
                grid = resample_to_grid(
                    fd, cfg,
                    progress=lambda f, m: report(0.15 + 0.75 * f, m),
                    max_cells=self.max_cells(len(fd.field_names())))
                report(0.92, "writing grid cache")
                save_grid(grid, cache_path)
            variant = self._variant_record("g0", "標準", "full", cfg, grid, cache_path,
                                           time.perf_counter() - t0)
            with self._lock:
                info.grids = [variant]
                info.base_grid = "g0"
                info.detail_grids = []
            self._finalize(info, grid)
            return {"dataset_id": info.id}

    @staticmethod
    def _variant_record(gid: str, label: str, kind: str, cfg: PreprocessConfig,
                        grid: UniformGrid, cache_path: Path, build_s: float) -> dict[str, Any]:
        return {"id": gid, "label": label, "kind": kind, "method": cfg.method,
                "spacing": [float(x) for x in grid.spacing], "dims": list(grid.dims),
                "box": grid.bounds.tolist(),
                "region": ([list(cfg.box[0]), list(cfg.box[1])] if cfg.box else None),
                "cache_path": str(cache_path), "status": "ready",
                "bytes_resident": grid.nbytes, "build_s": round(build_s, 2),
                "created": time.time(),
                "config": {**cfg.model_dump(mode="json"), "fields": sorted(grid.arrays)}}

    def _finalize(self, info: DatasetInfo, grid: UniformGrid) -> None:
        """Describe the dataset by its base grid and keep that grid loaded."""
        with self._lock:
            info.status = "ready"
            info.error = None
            info.meta = dict(grid.meta)
            info.units = dict(grid.units)
            info.fields = sorted(grid.arrays)
            info.bounds = grid.bounds.tolist()
            info.dims = list(grid.dims)
            info.spacing = grid.spacing.tolist()
            base = self._variant(info, info.base_grid) if info.base_grid else None
            if base is not None:
                info.cache_path = base["cache_path"]
            self._remember(info.cache_path, grid)
        self._persist(info)

    # -- grid memory -------------------------------------------------------
    def budget_bytes(self) -> int:
        return memory_budget_bytes(self.settings)

    def max_cells(self, n_fields: int) -> int:
        """Largest grid whose resident arrays fit the memory budget."""
        return int(self.budget_bytes() // max(4 * n_fields + 1, 1))

    def _remember(self, key: str, grid: UniformGrid, pinned: set[str] | None = None) -> None:
        """Keep a loaded grid; evict least-recently-used ones (never `pinned`)
        while the loaded total exceeds the memory budget or the count limit."""
        pinned = pinned or set()
        with self._lock:
            self._grids[key] = grid
            self._grids.move_to_end(key)
            limit_n = max(self.settings.grid_lru_size, len(pinned) + 1)
            budget = self.budget_bytes()

            def over() -> bool:
                total = sum(g.nbytes for g in self._grids.values())
                return len(self._grids) > limit_n or total > budget
            for k in list(self._grids):
                if not over():
                    break
                if k == key or k in pinned:
                    continue
                self._grids.pop(k, None)
                log.info("LRU evicted grid %s", Path(k).name)

    def _load(self, cache_path: str, pinned: set[str]) -> UniformGrid:
        with self._lock:
            if cache_path in self._grids:
                self._grids.move_to_end(cache_path)
                return self._grids[cache_path]
        grid = load_grid(cache_path)          # reload after LRU eviction
        self._remember(cache_path, grid, pinned)
        return grid

    # -- access -------------------------------------------------------------
    def info(self, ds_id: str) -> DatasetInfo:
        with self._lock:
            if ds_id not in self._infos:
                raise JobNotFoundError(f"dataset '{ds_id}' not found")
            return self._infos[ds_id]

    def storage(self, info: "DatasetInfo") -> dict[str, Any]:
        """Disk this dataset occupies, split by what deletion can free.

        `source_owned` is the distinction that matters: a file we received
        through upload lives in data_dir and is ours to remove, while a path
        the user registered in place belongs to them and is never touched —
        so its bytes are reported but not counted as reclaimable.
        """
        src = Path(info.source_path) if info.source_path else None
        caches = {g["cache_path"] for g in info.grids if g.get("cache_path")}
        if info.cache_path:
            caches.add(info.cache_path)
        src_bytes = src.stat().st_size if src and src.exists() else 0
        cache_bytes = sum(Path(c).stat().st_size for c in caches if Path(c).exists())
        owned = False
        if src and src.exists():
            data_dir = Path(self.settings.data_dir).resolve()
            owned = data_dir in src.resolve().parents
        return {"source_bytes": int(src_bytes),
                "cache_bytes": int(cache_bytes),
                "source_owned": owned,
                "reclaimable_bytes": int(cache_bytes + (src_bytes if owned else 0))}

    def describe(self, info: DatasetInfo) -> dict[str, Any]:
        """What the API shows: no server paths of the grid caches."""
        d = info.public()
        d["grids"] = [{k: v for k, v in g.items() if k != "cache_path"} for g in info.grids]
        return {**d, "storage": self.storage(info)}

    def list(self) -> list[dict[str, Any]]:
        with self._lock:
            infos = list(self._infos.values())
        return [self.describe(i) for i in infos]

    def get_evaluator(self, ds_id: str, neighbors: int | None = None) -> FieldEvaluator:
        """Evaluator over the ORIGINAL source file (not the grid).

        Loaded on first use and kept in a small LRU keyed by dataset, source
        file signature, fluid rule and evaluator settings. A source file that
        has gone missing raises DataLoadError: the caller must fail (or the
        user must choose grid output) -- never fall back to the grid silently.
        """
        info = self.info(ds_id)
        if info.status != "ready":
            raise DataLoadError(f"dataset '{ds_id}' not ready")
        src = Path(info.source_path)
        if not src.exists():
            raise DataLoadError(
                f"source file for dataset '{ds_id}' is not readable ({src.name}); "
                "original-data output is unavailable -- re-register the file "
                "or export from the grid explicitly")
        cfg = PreprocessConfig(**info.config) if info.config else PreprocessConfig()
        ecfg = EvaluatorConfig.from_settings(self.settings, neighbors)
        sig = source_signature(src)
        key = "|".join([ds_id, sig, json.dumps(cfg.fluid_rule.model_dump(), sort_keys=True),
                        json.dumps(ecfg.__dict__, sort_keys=True)])
        cached = self._evaluators.get(key)
        if cached is not None:
            return cached
        # a newer signature for the same dataset replaces older fits
        self._evaluators.drop_prefix(ds_id + "|")
        fd = load_floefd_table(src, fluid_rule=cfg.fluid_rule)
        log.info("source evaluator for %s: %d points", ds_id, fd.points.shape[0])
        return self._evaluators.put(key, FieldEvaluator(fd, ecfg, signature=sig))

    def get_grid(self, ds_id: str) -> UniformGrid:
        """The grid tools sample: the base grid, or a LayeredGrid when finer
        region grids are switched on."""
        info = self.info(ds_id)
        if info.status != "ready":
            raise DataLoadError(f"dataset '{ds_id}' not ready (status={info.status})")
        with self._lock:
            base = self._variant(info, info.base_grid) if info.base_grid else None
            base_path = base["cache_path"] if base else info.cache_path
            details = [self._variant(info, d) for d in info.detail_grids]
        paths = {base_path, *(d["cache_path"] for d in details if d)}
        grid = self._load(base_path, paths)
        layers = [self._load(d["cache_path"], paths) for d in details if d]
        return LayeredGrid(grid, layers) if layers else grid

    def get_base_grid(self, ds_id: str) -> UniformGrid:
        g = self.get_grid(ds_id)
        return g.base if isinstance(g, LayeredGrid) else g

    # -- grid variants (v2.8.3) ----------------------------------------------
    @staticmethod
    def _variant(info: DatasetInfo, gid: str | None) -> dict[str, Any] | None:
        for g in info.grids:
            if g["id"] == gid:
                return g
        return None

    def grids(self, ds_id: str) -> dict[str, Any]:
        info = self.info(ds_id)
        with self._lock:
            loaded = set(self._grids)
            rows = []
            for g in info.grids:
                p = Path(g["cache_path"])
                rows.append({**{k: v for k, v in g.items() if k != "cache_path"},
                             "bytes_disk": p.stat().st_size if p.exists() else 0,
                             "loaded": g["cache_path"] in loaded,
                             "base": g["id"] == info.base_grid,
                             "detail": g["id"] in info.detail_grids})
        src_bounds = (info.meta or {}).get("source_bounds")
        return {"grids": rows, "base": info.base_grid, "details": list(info.detail_grids),
                "budget_bytes": self.budget_bytes(), "data_bounds": src_bounds}

    def _variant_cfg(self, info: DatasetInfo, spec: dict[str, Any]) -> PreprocessConfig:
        base = PreprocessConfig(**info.config) if info.config else PreprocessConfig()
        # rebuilt (not model_copy) so the geometry validators run
        return PreprocessConfig(**{
            **base.model_dump(),
            "method": spec.get("method") or base.method,
            "spacing": spec.get("spacing"),
            "spacing_xyz": spec.get("spacing_xyz"),
            "target_dims": spec.get("target_dims"),
            "box": spec.get("box") if spec.get("kind") == "region" else None,
            "fields": None})

    def estimate_grid(self, ds_id: str, spec: dict[str, Any]) -> dict[str, Any]:
        """Measured cost of a grid variant plus the budget verdict."""
        info = self.info(ds_id)
        cfg = self._variant_cfg(info, spec)
        fd = self.get_evaluator(ds_id).fd
        est = estimate_resample(fd, cfg)
        budget = self.budget_bytes()
        est["budget_bytes"] = budget
        est["within_budget"] = est["bytes_peak"] <= budget
        est["source_points"] = int(fd.points.shape[0])
        sig = source_signature(info.source_path)
        key = cache_key(sig, json.dumps(cfg.model_dump(), sort_keys=True))
        same = [g for g in info.grids if Path(g["cache_path"]).name == f"{key}.npz"]
        est["existing"] = same[0]["id"] if same else None
        return est

    def build_grid(self, ds_id: str, spec: dict[str, Any]) -> Job:
        """Build a grid variant as a cancellable job; on success it is added
        to the dataset (and switched on when spec['activate'])."""
        info = self.info(ds_id)
        if info.status != "ready":
            raise DataLoadError(f"dataset '{ds_id}' not ready")
        cfg = self._variant_cfg(info, spec)
        kind = "region" if spec.get("kind") == "region" else "full"
        sig = source_signature(info.source_path)
        key = cache_key(sig, json.dumps(cfg.model_dump(), sort_keys=True))
        cache_path = Path(self.settings.cache_dir) / f"{key}.npz"
        activate = bool(spec.get("activate", True))
        label = (spec.get("label") or "").strip()

        def work(report) -> dict[str, Any]:
            existing = [g for g in info.grids if g["cache_path"] == str(cache_path)]
            if existing:
                report(1.0, "作成済み")
                gid = existing[0]["id"]
                if activate:
                    self._activate_one(info, gid)
                return {"grid_id": gid, "cached": True}
            with self._build_lock:
                t0 = time.perf_counter()
                report(0.01, "元データの読み込み中")
                fd = self.get_evaluator(ds_id).fd
                n_fields = len(fd.field_names())
                mem = grid_memory(int(np.prod(grid_geometry(fd.bounds, cfg)[2])),
                                  n_fields, cfg.method, int(fd.points.shape[0]))
                if mem["peak"] > self.budget_bytes():
                    raise SampleBudgetError(
                        f"estimated peak memory {mem['peak'] / 1e9:.1f} GB exceeds the budget "
                        f"of {self.budget_bytes() / 1e9:.1f} GB")
                grid = resample_to_grid(fd, cfg,
                                        progress=lambda f, m: report(0.03 + 0.85 * f, m),
                                        max_cells=self.max_cells(n_fields))
                report(0.9, "保存中")
                save_grid(grid, cache_path)
                build_s = time.perf_counter() - t0
            with self._lock:
                gid = f"g{1 + max([int(g['id'][1:]) for g in info.grids if g['id'][1:].isdigit()] or [0])}"
                parts = [f"{v * 1e3:.3g}" for v in grid.spacing]
                sp_mm = parts[0] if len(set(parts)) == 1 else "×".join(parts)
                name = label or (("全体 " if kind == "full" else "領域 ") + sp_mm + " mm")
                info.grids.append(self._variant_record(gid, name, kind, cfg, grid,
                                                       cache_path, build_s))
                self._remember(str(cache_path), grid)
            self._persist(info)
            if activate:
                self._activate_one(info, gid)
            report(1.0, "完了")
            return {"grid_id": gid, "cached": False, "build_s": round(build_s, 2)}

        return self.jobs.submit("grid_build", work)

    def _activate_one(self, info: DatasetInfo, gid: str) -> None:
        g = self._variant(info, gid)
        if g is None:
            return
        if g["kind"] == "full":
            self.set_active(info.id, base=gid, details=list(info.detail_grids))
        elif gid not in info.detail_grids:
            self.set_active(info.id, base=info.base_grid, details=[*info.detail_grids, gid])

    def set_active(self, ds_id: str, base: str | None, details: list[str]) -> DatasetInfo:
        info = self.info(ds_id)
        with self._lock:
            b = self._variant(info, base) if base else None
            if b is None or b["kind"] != "full":
                raise GridBuildError("base must be a full-domain grid of this dataset")
            ds = []
            for d in details:
                v = self._variant(info, d)
                if v is None or v["kind"] != "region":
                    raise GridBuildError(f"'{d}' is not a region grid of this dataset")
                if d not in ds:
                    ds.append(d)
            info.base_grid, info.detail_grids = base, ds
        grid = self._load(b["cache_path"], {b["cache_path"]})
        self._finalize(info, grid)
        return info

    def delete_grid(self, ds_id: str, gid: str) -> dict[str, Any]:
        info = self.info(ds_id)
        with self._lock:
            g = self._variant(info, gid)
            if g is None:
                raise JobNotFoundError(f"grid '{gid}' not found")
            if gid == info.base_grid:
                raise GridBuildError("使用中の全体メッシュは削除できません。先に別の全体メッシュに切り替えてください")
            info.grids = [x for x in info.grids if x["id"] != gid]
            info.detail_grids = [d for d in info.detail_grids if d != gid]
            self._grids.pop(g["cache_path"], None)
            shared = any(x["cache_path"] == g["cache_path"]
                         for i in self._infos.values() for x in i.grids)
        freed = 0
        p = Path(g["cache_path"])
        if not shared and p.exists():
            freed = p.stat().st_size
            p.unlink(missing_ok=True)
        self._persist(info)
        return {"deleted": gid, "freed_bytes": int(freed)}

    # -- removal -------------------------------------------------------------
    def delete(self, ds_id: str, drop_source: bool = False) -> dict[str, Any]:
        """Forget a dataset: registry row, LRU entries and npz caches.

        The uploaded source file is only removed when `drop_source` is set and
        the file lives inside our own data_dir — a registered path belongs to
        the user and is never touched.
        """
        info = self.info(ds_id)
        freed = self.storage(info)["reclaimable_bytes"] if drop_source \
            else self.storage(info)["cache_bytes"]
        caches = {g["cache_path"] for g in info.grids} | (
            {info.cache_path} if info.cache_path else set())
        with self._lock:
            self._infos.pop(ds_id, None)
            for c in caches:
                self._grids.pop(c, None)
            still_used = {g["cache_path"] for i in self._infos.values() for g in i.grids} | {
                i.cache_path for i in self._infos.values()}
        self._evaluators.drop_prefix(ds_id + "|")
        if self.registry is not None:
            self.registry.delete_dataset(ds_id)
        removed = []
        for c in caches:
            cp = Path(c)
            if c not in still_used and cp.exists():
                cp.unlink(missing_ok=True)
                removed.append(str(cp))
        if drop_source and info.source_path:
            src = Path(info.source_path).resolve()
            data_dir = Path(self.settings.data_dir).resolve()
            if src.exists() and data_dir in src.parents:   # our upload, not theirs
                src.unlink(missing_ok=True)
                removed.append(str(src))
        log.info("deleted dataset %s (%d files, %d bytes)",
                 ds_id, len(removed), freed)
        return {"id": ds_id, "removed_files": removed,
                "freed_bytes": int(freed)}
