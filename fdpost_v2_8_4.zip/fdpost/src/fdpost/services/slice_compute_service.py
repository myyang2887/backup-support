"""One computation behind every slice output.

    request ──► ResolvedPlane ──► Lattice ──► classify ──► evaluate ──► SliceResult
                (core.plane)      (core.plane)  (3D, explicit states)      │
                                                                            ├─► PNG (render.contour)
                                                                            ├─► CSV / NPZ
                                                                            └─► manifest.json

PNG, CSV and vectors are all read from the same SliceResult, so the image and
the numbers can never describe different cuts or different samples. The
renderer does not compute anything; it only colours what is here.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from fdpost.config import Settings
from fdpost.core.plane import Lattice, ResolvedPlane, plan_lattice, resolve_plane
from fdpost.domain.errors import FieldNotFoundError
from fdpost.domain.requests import EvaluationSpec, SamplingSpec
from fdpost.services.field_evaluator import (FLUID, OUTSIDE, Q_GRID, Q_NONE,
                                             QUALITY_NAMES, SOLID, STATE_NAMES,
                                             UNKNOWN, ALGORITHM_VERSION)

VEC = ("velocity_x", "velocity_y", "velocity_z")


@dataclass
class SliceResult:
    plane: ResolvedPlane
    lattice: Lattice
    field: str
    unit: str
    values: np.ndarray                    # (nu,nv) primary field
    state: np.ndarray                     # (nu,nv) uint8, FLUID/SOLID/OUTSIDE/UNKNOWN
    quality: np.ndarray                   # (nu,nv) uint8, method per sample
    vec_world: np.ndarray | None = None   # (nu,nv,3) velocity, world axes
    meta: dict[str, Any] = field(default_factory=dict)
    extras: dict[str, np.ndarray] = field(default_factory=dict)   # more fields, same samples

    @property
    def shape(self) -> tuple[int, int]:
        return self.values.shape  # type: ignore[return-value]

    @property
    def vec_uv(self) -> tuple[np.ndarray, np.ndarray] | None:
        if self.vec_world is None:
            return None
        return self.vec_world @ self.plane.u_hat, self.vec_world @ self.plane.v_hat

    def display_axes(self) -> tuple[np.ndarray, np.ndarray, str, str]:
        return self.plane.display(self.lattice.u, self.lattice.v)

    def valid_values(self) -> np.ndarray:
        """Primary-field values that a colour scale may be computed from:
        fluid (or, for fields that exist there, solid) samples with a value."""
        ok = np.isfinite(self.values) & ((self.state == FLUID) | (self.state == SOLID))
        return self.values[ok]

    def table(self) -> dict[str, np.ndarray]:
        """Flat columns for CSV/NPZ (row order: u fastest-varying last)."""
        u, v, _, _ = self.display_axes()
        gu, gv = np.meshgrid(u, v, indexing="ij")
        w = self.plane.world(self.lattice.u, self.lattice.v)
        # u_m, v_m, <field> first: the v2.x column positions, kept for scripts
        cols: dict[str, np.ndarray] = {
            "u_m": gu.ravel(), "v_m": gv.ravel(),
            self.field: self.values.ravel(),
            "x_m": w[:, 0], "y_m": w[:, 1], "z_m": w[:, 2],
        }
        for k, a in self.extras.items():
            cols[k] = a.ravel()
        if self.vec_world is not None:
            vw = self.vec_world.reshape(-1, 3)
            for j, c in enumerate(VEC):
                if c != self.field and c not in cols:
                    cols[c] = vw[:, j]
            vu, vv = self.vec_uv  # type: ignore[misc]
            cols["vec_u"] = vu.ravel()
            cols["vec_v"] = vv.ravel()
        st = self.state.ravel()
        cols["state"] = np.array([STATE_NAMES[int(c)] for c in range(4)])[st]
        cols["is_solid"] = (st == SOLID).astype(np.int8)
        cols["method"] = np.array([QUALITY_NAMES[c] for c in range(len(QUALITY_NAMES))]
                                  )[self.quality.ravel()]
        return cols


class SliceComputeService:
    def __init__(self, store: Any, settings: Settings) -> None:
        self.store = store
        self.settings = settings

    # -- public --------------------------------------------------------------
    def compute(self, ds_id: str, geometry: Any, field_name: str,
                sampling: SamplingSpec, evaluation: EvaluationSpec, *,
                with_vectors: bool = False,
                max_points: int | None = None,
                extra_fields: list[str] | None = None,
                progress: Any = None) -> SliceResult:
        """`progress(fraction)` (optional) is called through classification
        (0-10 %) and evaluation (10-100 %); it may raise to cancel."""
        t0 = time.perf_counter()
        timings: dict[str, float] = {}
        grid = self.store.get_grid(ds_id)
        if evaluation.source == "original":
            ev = self.store.get_evaluator(ds_id, evaluation.neighbors)
            bounds = ev.bounds
            if field_name not in ev.fd.fields:
                raise FieldNotFoundError(
                    f"field '{field_name}' not in the source data; "
                    f"available: {sorted(ev.fd.fields)}")
            units = ev.fd.units
        else:
            ev = None
            bounds = grid.bounds
            if field_name not in grid.arrays:
                raise FieldNotFoundError(
                    f"field '{field_name}' not in grid; available: {sorted(grid.arrays)}")
            units = grid.units
        timings["load_s"] = time.perf_counter() - t0

        plane = resolve_plane(geometry, bounds, grid_planes=(grid.origin, grid.spacing),
                              center=(bounds[0] + bounds[1]) / 2)
        lat = plan_lattice(plane, sampling,
                           default_long_edge=self.settings.export_sample_long_edge,
                           max_points=max_points or self.settings.export_max_sample_points)
        pts = plane.world(lat.u, lat.v)
        nu, nv = lat.shape

        names = [field_name]
        src_names = ev.fd.fields if ev is not None else grid.arrays
        extra = [f for f in (extra_fields or []) if f != field_name]
        missing = [f for f in extra if f not in src_names]
        if missing:
            raise FieldNotFoundError(f"fields {missing} not available; "
                                     f"available: {sorted(src_names)}")
        names += extra
        if with_vectors:
            src_fields = ev.fd.fields if ev is not None else grid.arrays
            if all(c in src_fields for c in VEC):
                names += [c for c in VEC if c not in names]
            else:
                with_vectors = False

        t1 = time.perf_counter()
        method_used: dict[str, int]
        support: dict[str, Any] = {}
        if ev is not None:
            method = evaluation.method or self.settings.source_method
            # share of the bar for classification ~ its share of the time
            # (measured: a few % next to local-linear, ~1/3 next to IDW), so
            # the ETA extrapolated from early progress is not 5x too short
            wc = 0.3 if method == "idw" else 0.05
            p_cls = (lambda x: progress(wc * x)) if progress else None
            p_ev = (lambda x: progress(wc + (1 - wc) * x)) if progress else None
            state, dnear_all = ev.classify(pts, progress=p_cls)
            timings["classify_s"] = time.perf_counter() - t1
            t2 = time.perf_counter()
            res = ev.evaluate(names, pts, state, method=method, progress=p_ev)
            timings["evaluate_s"] = time.perf_counter() - t2
            vals = res.values
            quality = res.quality
            method_used = res.counts
            dn = res.nearest_distance[np.isfinite(res.nearest_distance)]
            if dn.size:
                p50, p95 = np.percentile(dn, [50, 95])
                support = {"nearest_source_distance_m": {
                    "p50": float(p50), "p95": float(p95), "max": float(dn.max())}}
            support["in_plane_data_spacing"] = ev.in_plane_spacing(
                pts[state == FLUID][:: max(1, int((state == FLUID).sum() // 4000) or 1)],
                plane.u_hat, plane.v_hat)
            method_requested = method
            source_info = {"source": "original", "n_source_points": ev.n_points,
                           "source_bounds_m": ev.bounds.tolist(),
                           "source_signature": ev.signature,
                           "algorithm_version": ALGORITHM_VERSION}
        else:
            state = _grid_state(grid, pts)
            timings["classify_s"] = time.perf_counter() - t1
            t2 = time.perf_counter()
            vals = {}
            for nme in names:
                a = grid.sample(nme, pts)
                a[state != FLUID] = np.nan
                vals[nme] = a
            timings["evaluate_s"] = time.perf_counter() - t2
            quality = np.where(state == FLUID, Q_GRID, Q_NONE).astype(np.uint8)
            method_used = {QUALITY_NAMES[c]: int((quality == c).sum())
                           for c in np.unique(quality)}
            method_requested = "grid_trilinear"
            support = {"grid_spacing_m": grid.spacing.tolist(),
                       "grid_dims": list(grid.dims)}
            source_info = {"source": "grid", "grid_bounds_m": grid.bounds.tolist(),
                           "grid_dims": list(grid.dims),
                           "grid_spacing_m": grid.spacing.tolist()}

        values = vals[field_name].reshape(nu, nv)
        vec = None
        if with_vectors:
            vec = np.stack([vals[c].reshape(nu, nv) if c in vals else values
                            for c in VEC], axis=-1)
        state2 = state.reshape(nu, nv)
        q2 = quality.reshape(nu, nv)
        counts = {STATE_NAMES[c]: int((state2 == c).sum()) for c in range(4)}
        total = max(nu * nv, 1)
        timings["total_s"] = time.perf_counter() - t0
        meta = {
            "geometry_requested": plane.requested,
            "geometry_actual": plane.describe(),
            "sampling_requested": sampling.model_dump(exclude_none=True),
            "sampling_actual": lat.describe(),
            "evaluation_requested": evaluation.model_dump(exclude_none=True),
            "method_requested": method_requested,
            "method_used": method_used,
            "classification_summary": {
                "counts": counts,
                "fractions": {k: v / total for k, v in counts.items()}},
            "support_summary": support,
            **source_info,
            "field": field_name, "unit": units.get(field_name, ""),
            "with_vectors": bool(with_vectors),
            "timings": {k: round(v, 4) for k, v in timings.items()},
        }
        extras = {f: vals[f].reshape(nu, nv) for f in extra}
        return SliceResult(plane=plane, lattice=lat, field=field_name,
                           unit=units.get(field_name, ""), values=values,
                           state=state2, quality=q2, vec_world=vec, meta=meta,
                           extras=extras)


def _grid_state(grid: Any, pts: np.ndarray) -> np.ndarray:
    """Grid-backed classification with the same four states: beyond the
    outermost voxel half-width -> OUTSIDE (the v2.7 grid path called this
    'solid'), otherwise the nearest voxel's flag."""
    frac = grid.world_to_index(pts)
    dims = np.array(grid.dims, dtype=np.float64).reshape(3, 1)
    out = np.any((frac < -0.5) | (frac > dims - 0.5), axis=0)
    idx = np.clip(np.round(frac).astype(np.int64), 0, (dims - 1).astype(np.int64))
    solid = grid.solid_mask[idx[0], idx[1], idx[2]]
    st = np.where(solid, SOLID, FLUID).astype(np.uint8)
    st[out] = OUTSIDE
    return st


__all__ = ["SliceResult", "SliceComputeService", "FLUID", "SOLID", "OUTSIDE", "UNKNOWN"]


# --- cost estimate -------------------------------------------------------------

# Rough constants for the parts that are not measured (2-core reference
# machine; only their ratio to the compute matters for progress shares).
CSV_S_PER_ROW = 1.1e-5      # pandas to_csv of all columns + zip (fast deflate)
EVAL_S_PER_POINT = {"idw": 4e-6, "local_linear": 2.5e-5, "local_linear_hq": 6e-5,
                    "grid": 1e-6}


def render_cost_s(image_long_px: int) -> float:
    """~0.12 s per megapixel (image area ~ 0.8 x long edge squared)."""
    return 0.4 + 0.12 * (image_long_px ** 2 * 0.8) / 1e6


def estimate(svc: SliceComputeService, ds_id: str, geometry: Any, field_name: str,
             sampling: SamplingSpec, evaluation: EvaluationSpec, *,
             image_long_px: int, with_csv: bool, probe_points: int = 16_000
             ) -> dict[str, Any]:
    """Measure, don't guess: evaluate a subset of the real sample lattice
    (whole rows) with the real method on the real data, and scale up.

    The first call for a dataset also loads the source file and builds the
    search trees; that one-off cost is reported separately (`warmup_s`) and
    is not paid again by the export that follows (the evaluator is cached).
    Rendering and CSV writing are rough constants and labelled as such."""
    import time as _t

    t0 = _t.perf_counter()
    grid = svc.store.get_grid(ds_id)
    if evaluation.source == "original":
        ev = svc.store.get_evaluator(ds_id, evaluation.neighbors)
        bounds = ev.bounds
    else:
        ev, bounds = None, grid.bounds
    plane = resolve_plane(geometry, bounds, grid_planes=(grid.origin, grid.spacing),
                          center=(bounds[0] + bounds[1]) / 2)
    lat = plan_lattice(plane, sampling,
                       default_long_edge=svc.settings.export_sample_long_edge,
                       max_points=svc.settings.export_max_sample_points)
    nu, nv = lat.shape
    total = nu * nv
    # Whole rows spread over the slice (stratified), in the lattice's own
    # row-major order: random scattered points cost ~3x more per point than
    # the coherent rows the export evaluates, and over-estimated the time.
    rng = np.random.default_rng(0)
    rows_n = int(max(1, min(nv, round(probe_points / max(nu, 1)))))
    edges = np.linspace(0, nv, rows_n + 1)
    rows = np.unique([int(min(nv - 1, a + rng.random() * (b - a)))
                      for a, b in zip(edges[:-1], edges[1:])])
    pts = (plane.origin + lat.u[None, :, None] * plane.u_hat
           + lat.v[rows][:, None, None] * plane.v_hat).reshape(-1, 3)
    if len(pts) > 4 * probe_points:                   # very long rows: a centred run
        a = (len(pts) - probe_points) // 2
        pts = pts[a:a + probe_points]
    m = len(pts)
    method = evaluation.method or svc.settings.source_method
    if ev is not None:
        st, _ = ev.classify(pts[:64])                      # warm-up: trees, fits
        ev.evaluate([field_name], pts[:64], st, method=method)
        warm = _t.perf_counter() - t0
        per = np.inf
        for _ in range(2):            # the first pass may still build lazy caches
            t1 = _t.perf_counter()
            st, _ = ev.classify(pts)
            res = ev.evaluate([field_name], pts, st, method=method)
            per = min(per, (_t.perf_counter() - t1) / m)
        mix = res.counts
        fluid = float((st == FLUID).mean())
    else:
        warm = _t.perf_counter() - t0
        t1 = _t.perf_counter()
        _grid_state(grid, pts)
        grid.sample(field_name, pts)
        per = (_t.perf_counter() - t1) / m
        mix, fluid = {"grid_trilinear": m}, None
    compute = per * total
    render = render_cost_s(image_long_px)
    csv = CSV_S_PER_ROW * total if with_csv else 0.0
    return {"sample_shape": [nu, nv], "n_samples": total,
            "method": method if ev is not None else "grid_trilinear",
            "probe_points": m, "method_mix_in_probe": mix,
            "fluid_fraction_in_probe": fluid,
            "estimate_s": {"compute": round(compute, 2), "render": round(render, 2),
                           "csv": round(csv, 2),
                           "total": round(compute + render + csv, 2)},
            "warmup_s": round(warm, 2),
            "note": "compute is measured on a sample of this lattice; "
                    "render/csv are rough constants"}
