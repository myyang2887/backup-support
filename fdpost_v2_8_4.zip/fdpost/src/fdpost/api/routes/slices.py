from __future__ import annotations

from fastapi import APIRouter, Request

from fdpost.api.schemas import JobOut
from fdpost.api.ephemeral import stream_export
from fdpost.api.urlize import add_urls
from fdpost.services.slice_export_service import SliceExportService
from fdpost.domain.requests import SliceExportRequest, AxisSliceBatch, PlaneSliceBatch, PlaneSliceRequest

router = APIRouter(prefix="/api/datasets/{ds_id}/slices", tags=["slices"])


@router.post("/axis-batch", response_model=JobOut)
def axis_batch(ds_id: str, req: AxisSliceBatch, request: Request):
    svc = request.app.state.slice_service
    job = request.app.state.jobs.submit(
        "axis_slice_batch", lambda report: svc.run_axis_batch(ds_id, req, report))
    return job.snapshot()


@router.post("/plane", )
def plane(ds_id: str, req: PlaneSliceRequest, request: Request):
    """Single arbitrary plane: synchronous (~100ms) for interactive use."""
    res = request.app.state.slice_service.run_plane_slice(ds_id, req)
    return add_urls(res, request.app.state.settings.output_dir)


@router.post("/plane-batch", response_model=JobOut)
def plane_batch(ds_id: str, req: PlaneSliceBatch, request: Request):
    svc = request.app.state.slice_service
    job = request.app.state.jobs.submit(
        "plane_slice_batch", lambda report: svc.run_plane_batch(ds_id, req, report))
    return job.snapshot()


@router.post("/export")
def slice_export(ds_id: str, req: SliceExportRequest, request: Request,
                 deliver: str = "url"):
    """Export the slice currently on screen.

    deliver=url    — write into output_dir and return links (default).
    deliver=stream — build in a temp dir, return the bytes, keep nothing.
                     Use this when the server is shared: a remote user's
                     downloads should not pile up on the host's disk.
    """
    svc = request.app.state.slice_export_service
    settings = request.app.state.settings
    if deliver == "stream":
        return stream_export(
            settings,
            lambda s: SliceExportService(svc.store, s).run(ds_id, req),
            stem=f"slice_{req.axis}")
    return add_urls(svc.run(ds_id, req), settings.output_dir)


@router.post("/estimate")
def slice_estimate(ds_id: str, req: SliceExportRequest, request: Request):
    """How long would this export take? Measured on a sample of the actual
    lattice with the actual method (see services.slice_compute_service.estimate).
    Also warms the caches, so the export that follows starts hot."""
    from fdpost.services.slice_compute_service import estimate

    svc = request.app.state.slice_export_service
    specs = svc.specs(req)
    r = specs.render
    long_px = (r.long_edge_px if r.size_mode == "pixels"
               else int(round(r.print_long_edge_mm / 25.4 * r.dpi)))
    return estimate(svc.compute, ds_id, req, req.field, specs.sampling, specs.evaluation,
                    image_long_px=long_px, with_csv="csv" in req.formats)


@router.post("/export_job", response_model=JobOut)
def slice_export_job(ds_id: str, req: SliceExportRequest, request: Request):
    """The export as a background job: progress + cancellation, then one
    download from GET /api/jobs/{id}/download (zip when several files).
    Built in a private temp directory that is removed after the download."""
    import tempfile
    import zipfile
    from pathlib import Path

    from fdpost.api.ephemeral import _FILE_KEYS, _summary

    app = request.app
    settings = app.state.settings
    store = app.state.store
    store.get_grid(ds_id)                          # fail fast on a bad dataset id

    def work(report):
        root = Path(settings.output_dir) / "_jobs"
        root.mkdir(parents=True, exist_ok=True)
        td = tempfile.mkdtemp(prefix=f"export-{report.job.id}-", dir=root)
        report.job.file_dir = td
        scoped = settings.model_copy(update={"output_dir": Path(td)})
        # share of the bar for zipping (measured ~1/6 of writing a large CSV)
        tail = 0.06 if "csv" in req.formats else 0.02
        result = SliceExportService(store, scoped).run(ds_id, req, progress=report,
                                                       tail_share=tail)
        paths = [Path(result[k]) for k in _FILE_KEYS
                 if isinstance(result.get(k), str) and Path(result[k]).is_file()]
        stem = f"slice_{req.axis}" if req.mode == "axis" else "slice_plane"
        if len(paths) == 1:
            report.job.file_path = str(paths[0])
        else:
            zp = Path(td) / f"{stem}.zip"
            sizes = [max(p.stat().st_size, 1) for p in paths]
            done = 0
            with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED, compresslevel=1) as z:
                for p, sz in zip(paths, sizes):
                    z.write(p, arcname=p.name)
                    done += sz
                    report(1.0 - tail + tail * done / sum(sizes), "圧縮中")
            report.job.file_path = str(zp)
        report(1.0, "完了")
        keep = ("dims", "spacing_m", "source", "method_used", "geometry_actual",
                "render_actual", "classification_summary", "timings")
        return {**{k: result.get(k) for k in keep},
                "summary": _summary(result), "file_name": Path(report.job.file_path).name}

    return app.state.jobs.submit("slice_export", work).snapshot()
