"""3D preview endpoints for the browser front-end."""
from __future__ import annotations

import json
from typing import Literal

import numpy as np
from fastapi import APIRouter, Request, Response
from pydantic import BaseModel, Field

from fdpost.core.query import AXIS_INDEX, IN_PLANE
from fdpost.domain.errors import SliceGeometryError

router = APIRouter(prefix="/api/datasets/{ds_id}/preview", tags=["preview"])


def _preview_dim(settings, max_dim: int) -> int:
    """Requested preview grid size, within [16, preview_res_max]."""
    return max(16, min(int(max_dim or settings.preview_res), settings.preview_res_max))


@router.get("/meta")
def preview_meta(ds_id: str, request: Request, max_dim: int = 0):
    settings = request.app.state.settings
    store = request.app.state.store
    grid = store.get_grid(ds_id)
    g = grid.downsample(_preview_dim(settings, max_dim))
    gr = store.grids(ds_id)
    details = [{"id": x["id"], "label": x["label"], "box": x["box"], "spacing": x["spacing"]}
               for x in gr["grids"] if x["detail"]]
    return {"dims": list(g.dims), "origin": g.origin.tolist(),
            "spacing": g.spacing.tolist(), "bounds": g.bounds.tolist(),
            "fields": sorted(g.arrays), "units": g.units,
            "full_dims": list(grid.dims), "full_spacing": grid.spacing.tolist(),
            "details": details}


@router.get("/volume/{field}")
def preview_volume(ds_id: str, field: str, request: Request, max_dim: int = 0):
    """Binary float32 volume, Fortran (column-major) order, solid = NaN.
    Header-free: client knows dims from /meta."""
    settings = request.app.state.settings
    grid = request.app.state.store.get_grid(ds_id)
    g = grid.downsample(_preview_dim(settings, max_dim))
    arr = g.masked(field).astype(np.float32)
    return Response(content=arr.ravel(order="F").tobytes(),
                    media_type="application/octet-stream",
                    headers={"X-Dims": ",".join(map(str, g.dims))})


@router.get("/points/{field}")
def preview_points(ds_id: str, field: str, request: Request, max_points: int = 0):
    """Binary point cloud: coords (M,3) float32 then values (M,) float32
    concatenated. M = byteLength / 16."""
    settings = request.app.state.settings
    grid = request.app.state.store.get_grid(ds_id)
    n = min(max_points or settings.point_cloud_cap, settings.point_cloud_max)
    coords, ii = grid.fluid_voxel_points(max(1000, n))
    vals = grid.arrays[field][ii[:, 0], ii[:, 1], ii[:, 2]].astype(np.float32)
    finite = np.isfinite(vals)
    coords, vals = coords[finite], vals[finite]
    payload = coords.astype(np.float32).tobytes() + vals.tobytes()
    return Response(content=payload, media_type="application/octet-stream",
                    headers={"X-Count": str(int(vals.shape[0]))})


@router.get("/solid_points")
def preview_solid_points(ds_id: str, request: Request, max_points: int = 0):
    """Solid voxel centres: coords (M,3) float32, nothing else.

    Deliberately value-free — a solid cell has no field data, so colouring it
    from the colormap would be inventing numbers. The client draws these as a
    neutral grey shell.
    """
    settings = request.app.state.settings
    grid = request.app.state.store.get_grid(ds_id)
    n = min(max_points or settings.point_cloud_cap, settings.point_cloud_max)
    coords, _ = grid.voxel_points(max(1000, n), solid=True)
    return Response(content=coords.astype(np.float32).tobytes(),
                    media_type="application/octet-stream",
                    headers={"X-Count": str(int(coords.shape[0]))})


@router.get("/slice/{field}")
def preview_slice(ds_id: str, field: str, request: Request,
                  axis: str = "z", position: float = 0.0,
                  with_vectors: bool = False, max_dim: int = 0,
                  interp: bool = False):
    """Axis-orthogonal slice from the preprocessed grid, at full grid
    resolution in-plane.

    interp=false: the nearest grid plane (v2.x behaviour; `position` in the
    response is that plane, `requested_position` what was asked).
    interp=true : trilinear between the two neighbouring grid planes, at
    exactly `position` -- no snapping (v2.8.1).

    Body: f32 values, then -- when vectors are available and requested --
    f32 vec_u and f32 vec_v. Arrays are row-major [iv * nu + iu].
    Metadata rides in the X-Meta JSON header.
    """
    grid = request.app.state.store.get_grid(ds_id)
    if max_dim:                      # optional cap for very large grids
        grid = grid.downsample(max_dim)
    ai = AXIS_INDEX[axis]
    ua, va = IN_PLANE[axis]
    ui, vi = AXIS_INDEX[ua], AXIS_INDEX[va]
    vec_names = (f"velocity_{ua}", f"velocity_{va}")
    has_vec = with_vectors and all(n in grid.arrays for n in vec_names)
    lo, hi = grid.bounds[0][ai], grid.bounds[1][ai]
    du, dv = float(grid.spacing[ui]), float(grid.spacing[vi])
    o_u, o_v = float(grid.origin[ui]), float(grid.origin[vi])
    n_u, n_v = int(grid.dims[ui]), int(grid.dims[vi])
    if interp:
        pos = float(np.clip(position, lo, hi))
        if hasattr(grid, "finest_spacing_in"):
            # finer region grids in this plane: sample at their pitch
            # (whole plane, capped like the other interactive previews)
            plo, phi = grid.bounds[0].copy(), grid.bounds[1].copy()
            plo[ai] = phi[ai] = pos
            sp = grid.finest_spacing_in(plo, phi)
            cap = request.app.state.settings.slice_direct_max_px
            su, sv = (grid.bounds[1][ui] - o_u), (grid.bounds[1][vi] - o_v)
            k = max(su / sp[ui], sv / sp[vi]) / max(cap - 1, 1)
            du, dv = sp[ui] * max(1.0, k), sp[vi] * max(1.0, k)
            n_u, n_v = int(su / du + 1e-9) + 1, int(sv / dv + 1e-9) + 1
        u = o_u + du * np.arange(n_u)
        v = o_v + dv * np.arange(n_v)
        gv, gu = np.meshgrid(v, u, indexing="ij")          # rows = v
        pts = np.empty((gu.size, 3))
        pts[:, ui] = gu.ravel()
        pts[:, vi] = gv.ravel()
        pts[:, ai] = pos
        solid = grid.sample_solid(pts)

        def slab(name: str) -> np.ndarray:
            a = grid.sample(name, pts)
            a[solid] = np.nan
            return np.ascontiguousarray(a.astype(np.float32))
        k = -1
        drawn = pos
    else:
        k = int(np.clip(round((position - grid.origin[ai]) / grid.spacing[ai]),
                        0, grid.dims[ai] - 1))
        def slab(name: str) -> np.ndarray:
            """(nu,nv) slab -> row-major [iv][iu] float32 for the plot."""
            return np.ascontiguousarray(grid.plane(name, ai, k).T)
        drawn = float(grid.origin[ai] + grid.spacing[ai] * k)

    payload = slab(field).tobytes()
    if has_vec:
        payload += slab(vec_names[0]).tobytes() + slab(vec_names[1]).tobytes()
    meta = {
        "axis": axis, "index": k,
        "position": drawn,
        "requested_position": float(position),
        "snapped": not interp,
        "dims": [n_u, n_v],
        "origin": [o_u, o_v],
        "spacing": [du, dv],
        "labels": [f"{ua.upper()} [m]", f"{va.upper()} [m]"],
        "unit": grid.units.get(field, ""), "vectors": bool(has_vec),
        "full_dims": [int(d) for d in grid.dims],
        "grid_spacing": [float(x) for x in grid.spacing],
    }
    return Response(content=payload, media_type="application/octet-stream",
                    headers={"X-Meta": json.dumps(meta)})


@router.get("/vectors")
def preview_vectors(ds_id: str, request: Request,
                    max_dim: int = 0, max_points: int = 0):
    """Velocity glyph seeds on a coarse regular lattice of fluid voxels.

    Body: f32 coords (M,3) then f32 vectors (M,3). A regular lattice (rather
    than the random point-cloud subsample) is what makes the arrow field read
    as a flow field instead of noise.
    """
    settings = request.app.state.settings
    grid = request.app.state.store.get_grid(ds_id)
    g = grid.downsample(max_dim or settings.vector_glyph_dim)
    names = ("velocity_x", "velocity_y", "velocity_z")
    if not all(n in g.arrays for n in names):
        return Response(content=b"", media_type="application/octet-stream",
                        headers={"X-Count": "0", "X-Speed-Max": "0"})
    coords, ii = g.fluid_voxel_points(max_points or settings.vector_glyph_cap)
    vec = np.column_stack([g.arrays[n][ii[:, 0], ii[:, 1], ii[:, 2]]
                           for n in names]).astype(np.float32)
    ok = np.isfinite(vec).all(axis=1)
    coords, vec = coords[ok].astype(np.float32), vec[ok]
    speed = np.linalg.norm(vec, axis=1) if len(vec) else np.zeros(0)
    return Response(content=coords.tobytes() + vec.tobytes(),
                    media_type="application/octet-stream",
                    headers={"X-Count": str(int(coords.shape[0])),
                             "X-Speed-Max": repr(float(speed.max()) if len(speed) else 0.0)})


def _plane_axes(grid, axis: str):
    ai = AXIS_INDEX[axis]
    ua, va = IN_PLANE[axis]
    return ai, AXIS_INDEX[ua], AXIS_INDEX[va], ua, va


@router.get("/slice_native/{field}")
def slice_native(ds_id: str, field: str, request: Request,
                 axis: str = "z", position: float = 0.0):
    """Local data spacing near this cut, per in-plane direction.

    Replaces the v2.7 slab estimate, which counted every point within a few
    spacings of the plane (several layers, solids included) as if they lay on
    it. Here: the typical gap between neighbouring source points along u and
    along v, measured in 3D near the cut. `native_px` is the long-side sample
    count at that spacing -- a reference, not a cap: denser sampling is
    interpolation and is allowed.
    """
    from fdpost.core.plane import plan_lattice, resolve_plane
    from fdpost.domain.requests import SamplingSpec, SliceExportRequest
    from fdpost.services.field_evaluator import FLUID

    store = request.app.state.store
    ev = store.get_evaluator(ds_id)
    req = SliceExportRequest(mode="axis", axis=axis, position=position, field=field)
    plane = resolve_plane(req, ev.bounds)
    lat = plan_lattice(plane, SamplingSpec(mode="long_edge", long_edge_samples=96),
                       default_long_edge=96, max_points=1 << 20)
    pts = plane.world(lat.u, lat.v)
    st, _ = ev.classify(pts)
    sp = ev.in_plane_spacing(pts[st == FLUID], plane.u_hat, plane.v_hat)
    su = plane.extent_u[1] - plane.extent_u[0]
    sv = plane.extent_v[1] - plane.extent_v[0]
    nat_u = int(round(su / sp["spacing_u_m"])) + 1 if sp.get("spacing_u_m") else 0
    nat_v = int(round(sv / sp["spacing_v_m"])) + 1 if sp.get("spacing_v_m") else 0
    grid = store.get_grid(ds_id)
    return {"native_px": int(max(nat_u, nat_v, 16)), "native_uv": [nat_u, nat_v],
            **sp, "grid_px": int(max(grid.dims)),
            "grid_spacing_m": grid.spacing.tolist(),
            "n_source_points": ev.n_points,
            "fluid_fraction": float((st == FLUID).mean())}


def _slice_payload(sl, grid, *, axis: str, requested_position: float,
                   mode: str, extra: dict | None = None) -> tuple[bytes, dict]:
    """SliceResult -> the drawer's wire format (f32 rows [iv][iu]; values,
    then vec_u, vec_v when present) + its X-Meta dict."""
    from fdpost.services.field_evaluator import FLUID

    def rows(a: np.ndarray) -> np.ndarray:
        a = np.where(sl.state == FLUID, a, np.nan)
        return np.ascontiguousarray(a.T.astype(np.float32))

    payload = rows(sl.values).tobytes()
    has_vec = sl.vec_world is not None
    if has_vec:
        vu, vv = sl.vec_uv  # type: ignore[misc]
        payload += rows(vu).tobytes() + rows(vv).tobytes()
    u, v, xl, yl = sl.display_axes()
    nu, nv = sl.shape
    meta = {
        "axis": axis, "index": -1,
        "position": (float(sl.plane.position) if sl.plane.position is not None
                     else float(requested_position)),
        "requested_position": float(requested_position), "snapped": False,
        "dims": [nu, nv],
        "origin": [float(u[0]), float(v[0])],
        "spacing": [float(u[1] - u[0]) if nu > 1 else 0.0,
                    float(v[1] - v[0]) if nv > 1 else 0.0],
        "labels": [xl, yl], "unit": sl.unit, "vectors": bool(has_vec),
        "full_dims": [int(d) for d in grid.dims],
        "source": "scatter", "n_source_points": sl.meta.get("n_source_points"),
        "mode": mode, "method_used": sl.meta.get("method_used"),
        "native_px": 0, **(extra or {}),
    }
    return payload, meta


@router.get("/slice_direct/{field}")
def preview_slice_direct(ds_id: str, field: str, request: Request,
                         axis: str = "z", position: float = 0.0,
                         res: int = 512, with_vectors: bool = False,
                         mode: str = "hifi"):
    """Axis slice evaluated from the source data at exact 3D positions,
    synchronously (for quick IDW previews; long computations use
    POST /preview/slice_job, which reports progress and can be cancelled).

    mode: hifi -> adaptive local linear; idw -> IDW (fast). Requests above
    settings.slice_direct_max_px are reduced and the response says so
    (`capped`, `requested_px`). Same wire format as /preview/slice/{field}.
    """
    from fdpost.domain.requests import EvaluationSpec, SamplingSpec, SliceExportRequest

    settings = request.app.state.settings
    svc = request.app.state.slice_export_service.compute
    n = int(np.clip(res, 16, settings.slice_direct_max_px))
    req = SliceExportRequest(mode="axis", axis=axis, position=position, field=field)
    method = "local_linear" if mode == "hifi" else "idw"
    sl = svc.compute(ds_id, req, field, SamplingSpec(mode="long_edge", long_edge_samples=n),
                     EvaluationSpec(source="original", method=method),
                     with_vectors=with_vectors)
    grid = request.app.state.store.get_grid(ds_id)
    payload, meta = _slice_payload(sl, grid, axis=axis, requested_position=position,
                                   mode=mode, extra={"requested_px": int(res),
                                                     "capped": n != int(res)})
    return Response(content=payload, media_type="application/octet-stream",
                    headers={"X-Meta": json.dumps(meta)})


class PreviewSliceJob(BaseModel):
    """An exact preview slice computed as an interactive job (progress,
    cancellation). `u_range` / `v_range` restrict it to the visible part of
    the plot (world coordinates of the two in-plane axes) -- zooming in
    recomputes just what is on screen."""

    mode: Literal["axis", "euler"] = "axis"
    axis: Literal["x", "y", "z"] = "z"
    position: float = 0.0                 # axis mode: the coordinate
    tilt_deg: float = 0.0                 # euler mode: plane orientation ...
    azimuth_deg: float = 0.0
    distance: float = 0.0                 # ... and signed distance from the centre
    field: str
    samples: int = Field(default=256, ge=16, le=4096)
    method: Literal["idw", "local_linear", "local_linear_hq"] = "local_linear"
    with_vectors: bool = False
    u_range: tuple[float, float] | None = None
    v_range: tuple[float, float] | None = None


@router.post("/slice_job")
def preview_slice_job(ds_id: str, body: PreviewSliceJob, request: Request):
    """Start an exact preview slice; poll GET /api/jobs/{id}, then fetch the
    data from GET .../preview/slice_job/{id}. Cancel with
    POST /api/jobs/{id}/cancel (the UI does that whenever the slice moves)."""
    from fdpost.domain.requests import EvaluationSpec, SamplingSpec, SliceExportRequest

    app = request.app
    svc = app.state.slice_export_service.compute
    store = app.state.store
    store.get_grid(ds_id)                         # fail fast on a bad dataset id

    def work(report):
        ev = store.get_evaluator(ds_id)
        report(0.02, "準備中")
        lo, hi = ev.bounds
        c = (lo + hi) / 2
        ext = {}
        if body.mode == "axis":
            ua, va = IN_PLANE[body.axis]
            ui, vi = AXIS_INDEX[ua], AXIS_INDEX[va]
            if body.u_range is not None:
                a, b = sorted(body.u_range)
                ext["extent_u"] = (max(a, lo[ui]) - c[ui], min(b, hi[ui]) - c[ui])
            if body.v_range is not None:
                a, b = sorted(body.v_range)
                ext["extent_v"] = (max(a, lo[vi]) - c[vi], min(b, hi[vi]) - c[vi])
            req = SliceExportRequest(mode="axis", axis=body.axis, position=body.position,
                                     field=body.field, **ext)
        else:
            from fdpost.core.plane import euler_normal, plane_basis, plane_box_extent
            n = euler_normal(body.tilt_deg, body.azimuth_deg)
            uh, vh = plane_basis(n)
            full = plane_box_extent(c + n * body.distance, n, uh, vh, lo, hi)
            if full is None:
                raise SliceGeometryError("the plane does not intersect the data box")
            if body.u_range is not None:
                a, b = sorted(body.u_range)
                ext["extent_u"] = (max(a, full[0][0]), min(b, full[0][1]))
            if body.v_range is not None:
                a, b = sorted(body.v_range)
                ext["extent_v"] = (max(a, full[1][0]), min(b, full[1][1]))
            req = SliceExportRequest(mode="euler", tilt_deg=body.tilt_deg,
                                     azimuth_deg=body.azimuth_deg, distance=body.distance,
                                     field=body.field, **ext)
        sl = svc.compute(ds_id, req, body.field,
                         SamplingSpec(mode="long_edge", long_edge_samples=body.samples),
                         EvaluationSpec(source="original", method=body.method),
                         with_vectors=body.with_vectors,
                         progress=lambda x: report(0.02 + 0.96 * x, "計算中"))
        payload, meta = _slice_payload(sl, store.get_grid(ds_id), axis=body.axis,
                                       requested_position=(body.position if body.mode == "axis"
                                                           else body.distance),
                                       mode=body.method,
                                       extra={"roi": bool(ext)})
        report.job.blob = payload
        report.job.blob_headers = {"X-Meta": json.dumps(meta)}
        return {"dims": meta["dims"], "method_used": meta["method_used"]}

    return app.state.jobs.submit("preview_slice", work, pool="interactive").snapshot()


@router.get("/slice_job/{job_id}")
def preview_slice_job_data(ds_id: str, job_id: str, request: Request):
    job = request.app.state.jobs.get(job_id)
    if job.status != "done" or job.blob is None:
        return Response(status_code=409, content=f"job {job_id} is {job.status}")
    data, headers = job.blob, dict(job.blob_headers)
    job.blob = None                               # one fetch; frees the memory
    return Response(content=data, media_type="application/octet-stream", headers=headers)


@router.get("/spacing_profile")
def spacing_profile(ds_id: str, request: Request, axis: str | None = "z",
                    nx: float | None = None, ny: float | None = None,
                    nz: float | None = None, ox: float = 0.0, oy: float = 0.0,
                    oz: float = 0.0):
    """How far apart the source data is along an axis (or along the normal
    (nx, ny, nz), positions measured from (ox, oy, oz)), as a function of
    position. Drives the automatic arrow-key step and the batch hints."""
    ev = request.app.state.store.get_evaluator(ds_id)
    if nx is not None and ny is not None and nz is not None:
        n = np.array([nx, ny, nz], dtype=np.float64)
        if not np.all(np.isfinite(n)) or np.linalg.norm(n) < 1e-12:
            return Response(status_code=400, content="direction must be a non-zero vector")
    else:
        n = np.zeros(3)
        n[AXIS_INDEX[axis or "z"]] = 1.0
    return ev.spacing_profile(n, np.array([ox, oy, oz], dtype=np.float64))
