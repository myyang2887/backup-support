from __future__ import annotations

from fastapi import APIRouter, Request

from fdpost.api.schemas import JobOut
from fdpost.api.urlize import add_urls

router = APIRouter(prefix="/api/jobs", tags=["jobs"])


@router.get("/{job_id}", response_model=JobOut)
def get_job(job_id: str, request: Request):
    snap = request.app.state.jobs.get(job_id).snapshot()
    if snap.get("result"):
        snap["result"] = add_urls(snap["result"],
                                  request.app.state.settings.output_dir)
    return snap


@router.post("/{job_id}/cancel", response_model=JobOut)
def cancel_job(job_id: str, request: Request):
    """Request cancellation. Takes effect at the job's next checkpoint (a
    chunk of samples); a queued job never starts. Idempotent."""
    return request.app.state.jobs.cancel(job_id).snapshot()


@router.get("/{job_id}/download")
def download_job_file(job_id: str, request: Request):
    """The result file of a finished job (e.g. an export zip). Served once;
    the job's directory is deleted right after, so a shared server keeps
    nothing of anyone's downloads."""
    import mimetypes
    from pathlib import Path

    from fastapi import Response
    from starlette.background import BackgroundTask

    from fdpost.services.jobs import drop_job_files

    job = request.app.state.jobs.get(job_id)
    if job.status != "done" or not job.file_path or not Path(job.file_path).is_file():
        return Response(status_code=409, content=f"job {job_id}: no file ({job.status})")
    from fastapi.responses import FileResponse

    p = Path(job.file_path)
    media = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
    headers = {}
    summary = (job.result or {}).get("summary")
    if summary:
        headers["X-Fdpost-Summary"] = summary
    return FileResponse(p, media_type=media, filename=p.name, headers=headers,
                        background=BackgroundTask(drop_job_files, job))
