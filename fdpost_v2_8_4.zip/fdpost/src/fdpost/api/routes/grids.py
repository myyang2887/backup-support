"""Preprocessing grid variants (v2.8.3): estimate, build, switch, delete.

A dataset can hold several grids: full-domain grids of different cell sizes
(one is the base in use) and finer region grids laid over the base."""
from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, Request
from pydantic import BaseModel, Field, model_validator

from fdpost.api.schemas import JobOut

router = APIRouter(prefix="/api/datasets/{ds_id}/grids", tags=["grids"])


class GridSpec(BaseModel):
    """What to build. Cell size: `spacing_xyz` (per axis, m), or `spacing`
    (all axes, m), or `target_dims` (cells on the longest side)."""

    kind: Literal["full", "region"] = "full"
    spacing_xyz: tuple[float, float, float] | None = None
    spacing: float | None = Field(default=None, gt=0)
    target_dims: int | None = Field(default=None, ge=8, le=4096)
    box: tuple[tuple[float, float, float], tuple[float, float, float]] | None = None
    method: Literal["nearest", "idw", "linear", "rbf"] | None = None
    label: str = Field(default="", max_length=60)
    activate: bool = True

    @model_validator(mode="after")
    def _check(self):
        if self.kind == "region" and self.box is None:
            raise ValueError("a region grid needs a box")
        if self.spacing_xyz is None and self.spacing is None and self.target_dims is None:
            raise ValueError("give spacing_xyz, spacing or target_dims")
        return self


class ActiveSpec(BaseModel):
    base: str
    details: list[str] = []


@router.get("")
def list_grids(ds_id: str, request: Request):
    return request.app.state.store.grids(ds_id)


@router.post("/estimate")
def estimate_grid(ds_id: str, spec: GridSpec, request: Request):
    """Cells, memory (resident / peak while building) and time measured on
    this data with this method; `within_budget` against the memory budget."""
    return request.app.state.store.estimate_grid(ds_id, spec.model_dump())


@router.post("", response_model=JobOut)
def build_grid(ds_id: str, spec: GridSpec, request: Request):
    return request.app.state.store.build_grid(ds_id, spec.model_dump()).snapshot()


@router.put("/active")
def set_active(ds_id: str, spec: ActiveSpec, request: Request):
    store = request.app.state.store
    store.set_active(ds_id, spec.base, spec.details)
    return store.grids(ds_id)


@router.delete("/{gid}")
def delete_grid(ds_id: str, gid: str, request: Request):
    return request.app.state.store.delete_grid(ds_id, gid)
