"""Slice stacks (fine visualization): estimate, build as a job, fetch."""
from __future__ import annotations

import json

from fastapi import APIRouter, Request, Response

from fdpost.api.schemas import JobOut
from fdpost.domain.requests import StackRequest

router = APIRouter(prefix="/api/datasets/{ds_id}/stacks", tags=["stacks"])


@router.post("/estimate")
def stack_estimate(ds_id: str, req: StackRequest, request: Request):
    """Plan + measured cost: slices, in-plane samples, server / browser
    memory, and the build time measured on a random sample of the actual
    stack with the actual method. Also warms the caches. `cached` = a stack
    with exactly these settings is already on disk."""
    return request.app.state.stack_service.estimate(ds_id, req)


@router.post("", response_model=JobOut)
def stack_build(ds_id: str, req: StackRequest, request: Request):
    """Build (or reuse) a stack as a background job with progress and
    cancellation. The job result carries the stack `key`."""
    svc = request.app.state.stack_service
    return svc.submit(ds_id, req, request.app.state.jobs).snapshot()


@router.get("")
def stack_list(ds_id: str, request: Request):
    return request.app.state.stack_service.list(ds_id)


@router.get("/{key}")
def stack_meta(ds_id: str, key: str, request: Request):
    return request.app.state.stack_service.meta(key)


@router.get("/{key}/data")
def stack_data(ds_id: str, key: str, request: Request):
    """uint16 per sample, row-major [slice][v][u]; value = lo + q*(hi-lo)/65534,
    q = 65535 means no value (not fluid). lo/hi/dims in X-Meta."""
    body, meta = request.app.state.stack_service.data(key)
    return Response(content=body, media_type="application/octet-stream",
                    headers={"X-Meta": json.dumps(meta)})


@router.delete("/{key}")
def stack_delete(ds_id: str, key: str, request: Request):
    request.app.state.stack_service.delete(key)
    return {"deleted": key}
