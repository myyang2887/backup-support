"""UniformGrid: the cached uniform structured grid (core domain object)."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np

from fdpost.domain.errors import FieldNotFoundError, GridBuildError


@dataclass
class UniformGrid:
    """Uniform structured grid. `origin` is the center of voxel (0,0,0).

    arrays[name] has shape (nx,ny,nz) float32, indexed [ix,iy,iz] (x-axis first).
    """

    origin: np.ndarray            # (3,) float64
    spacing: np.ndarray           # (3,) float64, all > 0
    dims: tuple[int, int, int]    # (nx,ny,nz), each >= 2
    arrays: dict[str, np.ndarray]
    solid_mask: np.ndarray        # (nx,ny,nz) bool, True = solid
    units: dict[str, str]
    meta: dict[str, Any]

    def __post_init__(self) -> None:
        self.origin = np.asarray(self.origin, dtype=np.float64).reshape(3)
        self.spacing = np.asarray(self.spacing, dtype=np.float64).reshape(3)
        if not np.all(self.spacing > 0):
            raise GridBuildError(f"spacing must be > 0, got {self.spacing}")
        self.dims = tuple(int(d) for d in self.dims)  # type: ignore[assignment]
        if len(self.dims) != 3 or any(d < 2 for d in self.dims):
            raise GridBuildError(f"dims must be 3 values >= 2, got {self.dims}")
        for name, a in self.arrays.items():
            if a.shape != self.dims:
                raise GridBuildError(f"array '{name}' shape {a.shape} != dims {self.dims}")
            if a.dtype != np.float32:
                self.arrays[name] = a.astype(np.float32)
        if self.solid_mask.shape != self.dims:
            raise GridBuildError("solid_mask shape mismatch")
        self.solid_mask = self.solid_mask.astype(bool)

    @property
    def bounds(self) -> np.ndarray:
        """(2,3): voxel-center range [origin, origin + spacing*(dims-1)]."""
        hi = self.origin + self.spacing * (np.array(self.dims) - 1)
        return np.stack([self.origin, hi])

    def axis_coords(self, axis: int) -> np.ndarray:
        n = self.dims[axis]
        return self.origin[axis] + self.spacing[axis] * np.arange(n, dtype=np.float64)

    def world_to_index(self, pts: np.ndarray) -> np.ndarray:
        """(M,3) world coords -> (3,M) float64 fractional indices."""
        pts = np.asarray(pts, dtype=np.float64)
        return ((pts - self.origin) / self.spacing).T

    def require_field(self, name: str) -> None:
        if name not in self.arrays:
            raise FieldNotFoundError(
                f"field '{name}' not in grid; available: {sorted(self.arrays)}"
            )

    def masked(self, name: str) -> np.ndarray:
        """float64 copy with solid voxels set to NaN (copies the volume: for
        downsampled grids and small ones; point queries use `sample`)."""
        self.require_field(name)
        arr = self.arrays[name].astype(np.float64)
        arr[self.solid_mask] = np.nan
        return arr

    @property
    def nbytes(self) -> int:
        """Resident size of the field arrays plus the solid mask."""
        return int(sum(a.nbytes for a in self.arrays.values()) + self.solid_mask.nbytes)

    def contains(self, pts: np.ndarray, margin: float = 0.0) -> np.ndarray:
        """(M,) bool: inside the voxel-centre box (trilinear is defined there)."""
        lo, hi = self.bounds
        p = np.asarray(pts, dtype=np.float64)
        eps = margin + 1e-9 * float(self.spacing.max())
        return np.all((p >= lo - eps) & (p <= hi + eps), axis=1)

    def sample(self, name: str, pts: np.ndarray, mask_mode: str = "nan") -> np.ndarray:
        """Trilinear sampling at arbitrary world points. Out-of-bounds -> NaN.

        mask_mode="nan": a point whose interpolation touches a solid voxel
        (a corner with non-zero weight) is NaN -- same rule as before v2.8.3.
        Works on the 8 corners of each query point only: memory is O(points),
        never a copy of the grid (a 15-million-cell grid used to be copied to
        float64 on every call, which made streamlines and probes crawl)."""
        if name not in self.arrays:
            raise FieldNotFoundError(
                f"field '{name}' not in grid; available: {sorted(self.arrays)}"
            )
        p = np.asarray(pts, dtype=np.float64).reshape(-1, 3)
        out = np.full(p.shape[0], np.nan)
        if not p.shape[0]:
            return out
        f = (p - self.origin) / self.spacing                     # (M,3)
        dims = np.array(self.dims)
        tol = 1e-9
        ok = np.all((f >= -tol) & (f <= dims - 1 + tol), axis=1)
        if not ok.any():
            return out
        f = np.clip(f[ok], 0, dims - 1)
        i0 = np.minimum(np.floor(f).astype(np.int64), dims - 2)
        w = f - i0                                               # (m,3) in [0,1]
        arr, solid = self.arrays[name], self.solid_mask
        acc = np.zeros(f.shape[0])
        bad = np.zeros(f.shape[0], dtype=bool)
        for c in range(8):
            o = ((c >> 0) & 1, (c >> 1) & 1, (c >> 2) & 1)
            wc = np.ones(f.shape[0])
            for a in range(3):
                wc *= w[:, a] if o[a] else (1.0 - w[:, a])
            ix, iy, iz = i0[:, 0] + o[0], i0[:, 1] + o[1], i0[:, 2] + o[2]
            v = arr[ix, iy, iz].astype(np.float64)
            hit = wc > 0
            if mask_mode == "nan":
                bad |= hit & (solid[ix, iy, iz] | np.isnan(v))
            else:
                bad |= hit & np.isnan(v)
            acc += np.where(hit, wc * np.nan_to_num(v), 0.0)
        acc[bad] = np.nan
        out[ok] = acc
        return out

    def plane(self, name: str, axis: int, k: int) -> np.ndarray:
        """(n_u, n_v) float32 copy of one grid plane, solid = NaN (copies the
        plane only, not the volume)."""
        sl = [slice(None)] * 3
        sl[axis] = int(k)
        a = np.array(self.arrays[name][tuple(sl)], dtype=np.float32)
        a[self.solid_mask[tuple(sl)]] = np.nan
        return a

    def sample_solid(self, pts: np.ndarray) -> np.ndarray:
        """(M,) bool: nearest voxel is solid. Out-of-bounds points count as solid."""
        frac = self.world_to_index(pts)              # (3,M)
        dims = np.array(self.dims, dtype=np.float64).reshape(3, 1)
        out = np.any((frac < -0.5) | (frac > dims - 0.5), axis=0)
        idx = np.clip(np.round(frac).astype(np.int64), 0,
                      (dims - 1).astype(np.int64))
        solid = self.solid_mask[idx[0], idx[1], idx[2]]
        return solid | out

    def downsample(self, max_dim: int) -> UniformGrid:
        """Stride-slice downsample so that every axis has <= max_dim voxels.

        The stride is chosen per axis: an axis that already fits is kept
        whole. (Up to v2.8.3 one stride, taken from the longest axis, was
        applied to all three, so a mesh refined along one axis -- e.g.
        64x64x596 -- came out coarser across, 13x13x120, than an unrefined
        one.) The bound on the total stays max_dim**3."""
        strides = tuple(max(1, math.ceil(d / max_dim)) for d in self.dims)
        if strides == (1, 1, 1):
            return self
        sl = tuple(slice(None, None, k) for k in strides)
        arrays = {k: v[sl].copy() for k, v in self.arrays.items()}
        solid = self.solid_mask[sl].copy()
        dims = solid.shape
        return UniformGrid(
            origin=self.origin.copy(),
            spacing=self.spacing * np.asarray(strides, dtype=np.float64),
            dims=dims,  # type: ignore[arg-type]
            arrays=arrays,
            solid_mask=solid,
            units=dict(self.units),
            meta={**self.meta, "downsampled_stride": list(strides)},
        )

    def voxel_points(self, max_points: int, *, solid: bool = False
                     ) -> tuple[np.ndarray, np.ndarray]:
        """(coords (M,3) float64, voxel_index (M,3) int64) of fluid — or solid —
        voxel centers; uniformly subsampled with rng(seed=0) if M > max_points.
        The fixed seed means repeated calls return the same subset, so several
        per-voxel queries stay aligned."""
        # Same subset as argwhere + rng(0).choice + sort (the pre-v2.8.3
        # result), computed slab by slab along x: argwhere over a large grid
        # allocates 24 bytes per selected cell (GBs for a fine grid).
        nx = self.dims[0]
        step = max(1, 4_000_000 // max(self.dims[1] * self.dims[2], 1))
        counts = []
        for x0 in range(0, nx, step):
            m = self.solid_mask[x0:x0 + step]
            counts.append(int(m.sum()) if solid else int(m.size - m.sum()))
        total = int(sum(counts))
        if total > max_points:
            ranks = np.sort(np.random.default_rng(0).choice(total, max_points, replace=False))
        else:
            ranks = None
        parts, start = [], 0
        for k, x0 in enumerate(range(0, nx, step)):
            c = counts[k]
            if c == 0:
                continue
            if ranks is not None:
                a, b = np.searchsorted(ranks, [start, start + c])
                start += c
                if a == b:
                    continue
                m = self.solid_mask[x0:x0 + step]
                loc = np.argwhere(m if solid else ~m)[ranks[a:b] - (start - c)]
            else:
                m = self.solid_mask[x0:x0 + step]
                loc = np.argwhere(m if solid else ~m)
                start += c
            loc[:, 0] += x0
            parts.append(loc)
        ii = np.concatenate(parts) if parts else np.zeros((0, 3), dtype=np.int64)
        coords = self.origin + ii * self.spacing
        return coords, ii

    def fluid_voxel_points(self, max_points: int) -> tuple[np.ndarray, np.ndarray]:
        """Fluid voxel centers. Kept as the name existing callers use."""
        return self.voxel_points(max_points)


class LayeredGrid:
    """A coarse full-domain grid with finer local grids laid over it.

    Point queries (`sample`, `sample_solid`) take each point from the finest
    layer whose voxel-centre box contains it, so slices from the grid, lines,
    region exports and streamlines get the fine values where a fine layer
    exists and the coarse ones elsewhere. Whole-array consumers (the browser
    preview, point cloud, isosurface) keep using the base grid -- every other
    attribute is the base grid's, so this drops in wherever a UniformGrid is
    expected.
    """

    def __init__(self, base: UniformGrid, details: list[UniformGrid]) -> None:
        self.base = base
        # coarse -> fine: later layers overwrite earlier ones
        self.details = sorted(details, key=lambda g: -float(np.prod(g.spacing)))

    def __getattr__(self, name: str) -> Any:          # everything else: the base
        return getattr(self.base, name)

    @property
    def layers(self) -> list[UniformGrid]:
        return [self.base, *self.details]

    @property
    def nbytes(self) -> int:
        return int(sum(g.nbytes for g in self.layers))

    def sample(self, name: str, pts: np.ndarray, mask_mode: str = "nan") -> np.ndarray:
        p = np.asarray(pts, dtype=np.float64).reshape(-1, 3)
        out = self.base.sample(name, p, mask_mode)
        for g in self.details:
            if name not in g.arrays:
                continue
            m = g.contains(p)
            if m.any():
                out[m] = g.sample(name, p[m], mask_mode)
        return out

    def sample_solid(self, pts: np.ndarray) -> np.ndarray:
        p = np.asarray(pts, dtype=np.float64).reshape(-1, 3)
        out = self.base.sample_solid(p)
        for g in self.details:
            m = g.contains(p)
            if m.any():
                out[m] = g.sample_solid(p[m])
        return out

    def finest_spacing_in(self, lo: np.ndarray, hi: np.ndarray) -> np.ndarray:
        """Smallest spacing (per axis) among the layers overlapping [lo, hi]."""
        sp = self.base.spacing.copy()
        for g in self.details:
            glo, ghi = g.bounds
            if np.all(ghi >= lo) and np.all(glo <= hi):
                sp = np.minimum(sp, g.spacing)
        return sp
