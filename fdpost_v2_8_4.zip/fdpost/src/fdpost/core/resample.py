"""FieldData -> UniformGrid: the ONE expensive interpolation step.

Key optimizations (spec 5.3):
- z-slab chunking bounds peak memory;
- fields sharing the same NaN-validity mask share a single interpolator fit
  (fit is the expensive part: KDTree/Delaunay).

v2.8.3: the cell size can differ per axis, the grid can cover a region only,
progress reaches the caller per slab (so a build can be cancelled), and
`estimate_resample` measures what a build would cost before it runs."""
from __future__ import annotations

import logging
import math
import time
import zlib
from collections.abc import Callable
from typing import Any

import numpy as np

from fdpost.core.solid_mask import build_solid_mask
from fdpost.domain.errors import GridBuildError
from fdpost.domain.field_data import FieldData
from fdpost.domain.requests import PreprocessConfig
from fdpost.domain.uniform_grid import UniformGrid
from fdpost.interp import get_interpolator

log = logging.getLogger("fdpost.core.resample")

_CHUNK_TARGET = 1_000_000  # grid points per z-slab chunk (temporaries ~0.7 KB/point)

# Share of the progress bar per phase (interpolation dominates).
_P_INTERP, _P_SOLID = 0.85, 0.15


def grid_geometry(data_bounds: np.ndarray, cfg: PreprocessConfig
                  ) -> tuple[np.ndarray, np.ndarray, tuple[int, int, int]]:
    """(origin, spacing (3,), dims) of the grid cfg asks for.

    The covered box is the data box, or `cfg.box` clipped to it. The cell
    size is per axis (`spacing_xyz`), uniform (`spacing`) or derived from
    `target_dims` on the longest side. Nodes are centred in the box."""
    lo, hi = (np.asarray(b, dtype=np.float64) for b in data_bounds)
    if cfg.box is not None:
        blo, bhi = (np.asarray(b, dtype=np.float64) for b in cfg.box)
        lo, hi = np.maximum(lo, blo), np.minimum(hi, bhi)
        if np.any(hi <= lo):
            raise GridBuildError("the region does not overlap the data")
    extent = hi - lo
    if np.any(extent <= 0):
        raise GridBuildError(f"degenerate point cloud extent {extent}")
    if cfg.spacing_xyz is not None:
        sp = np.asarray(cfg.spacing_xyz, dtype=np.float64)
    elif cfg.spacing is not None:
        sp = np.full(3, float(cfg.spacing))
    else:
        target = cfg.target_dims or 128
        sp = np.full(3, float(extent.max() / max(target - 1, 1)))
    dims = tuple(int(max(2, math.floor(extent[i] / sp[i] + 1e-9) + 1)) for i in range(3))
    origin = lo + (extent - sp * (np.array(dims) - 1)) / 2
    return origin, sp, dims  # type: ignore[return-value]


def _validity_groups(fd: FieldData, names: list[str]) -> dict[bytes, list[str]]:
    groups: dict[bytes, list[str]] = {}
    for n in names:
        key = np.isnan(fd.fields[n]).tobytes()
        groups.setdefault(key, []).append(n)
    return groups


def resample_to_grid(fd: FieldData, cfg: PreprocessConfig,
                     progress: Callable[[float, str], None] | None = None,
                     max_cells: int | None = None) -> UniformGrid:
    """`progress(fraction, message)` is called per slab; it may raise to
    cancel. `max_cells` refuses grids above a size (the caller derives it
    from its memory budget)."""
    origin, spacing, dims = grid_geometry(fd.bounds, cfg)
    nx, ny, nz = dims
    cells = nx * ny * nz
    if max_cells is not None and cells > max_cells:
        raise GridBuildError(f"grid {dims} = {cells:,} cells exceeds the limit of "
                             f"{max_cells:,}; use a larger spacing or a smaller region")
    names = cfg.fields or fd.field_names()
    for n in names:
        fd.require(n)
    rep = progress or (lambda f, m: None)

    groups = _validity_groups(fd, names)
    log.info("resample: %d fields in %d validity group(s), dims=%s, method=%s",
             len(names), len(groups), dims, cfg.method)

    arrays = {n: np.empty(dims, dtype=np.float32) for n in names}
    axes = [origin[i] + spacing[i] * np.arange(dims[i]) for i in range(3)]
    z_chunk = max(1, _CHUNK_TARGET // max(nx * ny, 1))
    n_chunks = math.ceil(nz / z_chunk)
    total_steps = len(groups) * n_chunks
    step = 0

    for key, group_names in groups.items():
        valid = ~np.frombuffer(key, dtype=bool)
        if valid.sum() < 4:
            for n in group_names:
                arrays[n][:] = np.nan
            step += n_chunks
            continue
        rep(_P_INTERP * step / total_steps, "補間の準備中")
        itp = get_interpolator(cfg.method, **cfg.interp_params).fit(fd.points[valid])
        vals = np.column_stack([fd.fields[n][valid] for n in group_names])  # (Nv,F)
        for z0 in range(0, nz, z_chunk):
            z1 = min(z0 + z_chunk, nz)
            gx, gy, gz = np.meshgrid(axes[0], axes[1], axes[2][z0:z1], indexing="ij")
            q = np.column_stack([gx.ravel(), gy.ravel(), gz.ravel()])
            del gx, gy, gz
            out = itp.interpolate(vals, q)                       # (M,F)
            out = out.reshape(nx, ny, z1 - z0, len(group_names))
            for fi, n in enumerate(group_names):
                arrays[n][:, :, z0:z1] = out[..., fi].astype(np.float32)
            del q, out
            step += 1
            rep(_P_INTERP * step / total_steps, "補間中")

    solid = build_solid_mask(fd.points, fd.is_fluid, origin, spacing, dims,
                             progress=lambda f: rep(_P_INTERP + _P_SOLID * f, "固体判定中"))
    meta = {**fd.meta, "interp_method": cfg.method,
            "interp_params": dict(cfg.interp_params),
            "grid_dims": list(dims),
            # the data box itself (the grid is centred inside it and slightly
            # smaller); formal source exports use this, never the grid box
            "source_bounds": fd.bounds.tolist(),
            "grid_spacing": [float(x) for x in spacing],
            "grid_region": ([list(map(float, cfg.box[0])), list(map(float, cfg.box[1]))]
                            if cfg.box is not None else None)}
    return UniformGrid(origin=origin, spacing=spacing, dims=dims,
                       arrays=arrays, solid_mask=solid,
                       units=dict(fd.units), meta=meta)


# --- cost model -----------------------------------------------------------------

# Bytes held per query point of a slab while interpolating (meshgrid + query
# array + method temporaries), per field where noted. Calibrated against
# measured peaks (v2.8.3, see tests/test_v283_grids.py::test_memory_model).
_TMP_PER_POINT = {"nearest": 120, "idw": 260, "linear": 400, "rbf": 900}
_TMP_PER_POINT_FIELD = {"nearest": 16, "idw": 80, "linear": 40, "rbf": 40}
_SOURCE_PER_POINT = 200          # table, KD-tree, validity masks (per source point)
_LINEAR_FIT_PER_POINT = 900      # Delaunay structure (per source point)


def grid_memory(cells: int, n_fields: int, method: str, n_source: int) -> dict[str, int]:
    """Resident bytes of the finished grid, and the peak while building it."""
    resident = cells * (4 * n_fields + 1)
    chunk = min(cells, _CHUNK_TARGET)
    tmp = chunk * (_TMP_PER_POINT.get(method, 400)
                   + n_fields * _TMP_PER_POINT_FIELD.get(method, 60))
    src = n_source * (_SOURCE_PER_POINT + 8 * n_fields
                      + (_LINEAR_FIT_PER_POINT if method == "linear" else 0))
    return {"resident": int(resident), "peak": int(resident + tmp + src)}


def estimate_resample(fd: FieldData, cfg: PreprocessConfig, probe: int = 20_000
                      ) -> dict[str, Any]:
    """Measured cost of `resample_to_grid(fd, cfg)` without running it.

    Times the real method on a probe laid out like the build (whole rows of
    a few z-planes spread over the grid), the solid-mask lookup on the same
    probe, the interpolator fit (on a subsample for Delaunay, scaled), and
    the compression of the result. Memory comes from `grid_memory`."""
    origin, spacing, dims = grid_geometry(fd.bounds, cfg)
    nx, ny, nz = dims
    cells = nx * ny * nz
    names = cfg.fields or fd.field_names()
    groups = _validity_groups(fd, names)
    n = fd.points.shape[0]

    # probe: rows of up to 8 z-planes spread over the grid, row-major
    rng = np.random.default_rng(0)
    nzp = min(nz, 8)
    zs = np.unique(np.linspace(0, nz - 1, nzp).round().astype(int))
    rows = max(1, min(ny, probe // max(len(zs) * nx, 1)))
    ax = origin[0] + spacing[0] * np.arange(nx)
    pts = []
    for k in zs:
        y0 = int(rng.integers(0, ny - rows + 1))
        ys = origin[1] + spacing[1] * np.arange(y0, y0 + rows)
        gy, gx = np.meshgrid(ys, ax, indexing="ij")
        pts.append(np.column_stack([gx.ravel(), gy.ravel(),
                                    np.full(gx.size, origin[2] + spacing[2] * k)]))
    q = np.concatenate(pts)
    if q.shape[0] > 4 * probe:
        q = q[:: q.shape[0] // probe]
    m = q.shape[0]

    fit_s = per_point = 0.0
    sample_vals = None
    for key, group_names in groups.items():
        valid = ~np.frombuffer(key, dtype=bool)
        nv = int(valid.sum())
        if nv < 4:
            continue
        P = fd.points[valid]
        vals = np.column_stack([fd.fields[g][valid] for g in group_names])
        itp = get_interpolator(cfg.method, **cfg.interp_params)
        if cfg.method == "linear" and nv > 40_000:
            sel = np.sort(rng.choice(nv, 40_000, replace=False))
            t0 = time.perf_counter()
            itp.fit(P[sel])
            dt = time.perf_counter() - t0
            fit_s += dt * (nv / 40_000) * (math.log(nv) / math.log(40_000))
            vals = vals[sel]
        else:
            t0 = time.perf_counter()
            itp.fit(P)
            fit_s += time.perf_counter() - t0
        # small probe first: when a method is slow per point (Delaunay on
        # degenerate, lattice-like data can be), stop there -- the estimate
        # must stay quick
        t0 = time.perf_counter()
        small = q[:: max(1, m // 1000)]
        out = itp.interpolate(vals, small)
        dt_small = time.perf_counter() - t0
        if dt_small > 0.3 or m <= small.shape[0]:
            pp = dt_small / small.shape[0]
        else:
            best = math.inf
            for _ in range(2):
                t0 = time.perf_counter()
                out = itp.interpolate(vals, q)
                best = min(best, time.perf_counter() - t0)
            pp = best / m
        per_point += pp
        sample_vals = out
    interp_s = per_point * cells

    from scipy.spatial import cKDTree
    t0 = time.perf_counter()
    tree = cKDTree(fd.points)
    tree_s = time.perf_counter() - t0
    best = math.inf
    for _ in range(2):
        t0 = time.perf_counter()
        tree.query(q, k=1, workers=-1)
        best = min(best, time.perf_counter() - t0)
    solid_s = tree_s + best / m * cells

    # compression throughput on real values (float32, as stored)
    resident = cells * (4 * len(names) + 1)
    if sample_vals is not None:
        raw = np.asarray(sample_vals, dtype=np.float32).tobytes()
        t0 = time.perf_counter()
        zlib.compress(raw, 6)
        rate = len(raw) / max(time.perf_counter() - t0, 1e-6)
    else:
        rate = 60e6
    save_s = resident / rate

    mem = grid_memory(cells, len(names), cfg.method, n)
    return {"dims": list(dims), "cells": int(cells), "spacing": [float(x) for x in spacing],
            "origin": [float(x) for x in origin],
            "box": [[float(x) for x in origin],
                    [float(origin[i] + spacing[i] * (dims[i] - 1)) for i in range(3)]],
            "fields": len(names), "groups": len(groups),
            "bytes_resident": mem["resident"], "bytes_peak": mem["peak"],
            "estimate_s": {"fit": round(fit_s, 2), "interpolate": round(interp_s, 2),
                           "solid": round(solid_s, 2), "save": round(save_s, 2),
                           "total": round(fit_s + interp_s + solid_s + save_s, 2)},
            "probe_points": int(m)}
