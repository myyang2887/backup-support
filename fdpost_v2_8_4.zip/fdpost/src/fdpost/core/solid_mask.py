"""Point-level is_fluid -> voxel-level solid mask via nearest-point projection."""
from __future__ import annotations

from collections.abc import Callable

import numpy as np
from scipy.spatial import cKDTree

CHUNK_CELLS = 1_000_000


def build_solid_mask(points: np.ndarray, is_fluid: np.ndarray,
                     origin: np.ndarray, spacing: np.ndarray,
                     dims: tuple[int, int, int],
                     progress: Callable[[float], None] | None = None,
                     tree: cKDTree | None = None) -> np.ndarray:
    """For every voxel center, adopt the fluid/solid state of the nearest
    scattered point. (nx,ny,nz) bool, True = solid.

    Works in z-slabs of about CHUNK_CELLS cells, so the memory beyond the
    result is a few tens of MB whatever the grid size (the whole-grid
    meshgrid this replaced needed ~100 bytes per cell). `progress(fraction)`
    is called per slab and may raise to cancel."""
    tree = tree if tree is not None else cKDTree(np.asarray(points, dtype=np.float64))
    fluid = np.asarray(is_fluid, dtype=bool)
    nx, ny, nz = dims
    o, sp = np.asarray(origin, dtype=np.float64), np.asarray(spacing, dtype=np.float64)
    ax = o[0] + sp[0] * np.arange(nx)
    ay = o[1] + sp[1] * np.arange(ny)
    az = o[2] + sp[2] * np.arange(nz)
    solid = np.empty(dims, dtype=bool)
    zc = max(1, CHUNK_CELLS // max(nx * ny, 1))
    for z0 in range(0, nz, zc):
        z1 = min(nz, z0 + zc)
        gx, gy, gz = np.meshgrid(ax, ay, az[z0:z1], indexing="ij")
        q = np.column_stack([gx.ravel(), gy.ravel(), gz.ravel()])
        _, idx = tree.query(q, k=1, workers=-1)
        solid[:, :, z0:z1] = (~fluid[idx]).reshape(nx, ny, z1 - z0)
        if progress:
            progress(z1 / nz)
    return solid
