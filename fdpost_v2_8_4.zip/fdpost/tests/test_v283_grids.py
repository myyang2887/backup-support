"""v2.8.3 (step 3): adjustable preprocessing grids.

Per-axis cell size, region grids layered over the base grid, several grids
per dataset, measured estimates, a memory budget instead of a fixed cap,
and sampling / solid masks that never copy the whole grid."""
from __future__ import annotations

import time
import tracemalloc

import numpy as np
import pytest
from scipy import ndimage
from scipy.spatial import cKDTree

from fdpost.core import solid_mask as sm
from fdpost.core.resample import (estimate_resample, grid_geometry, grid_memory,
                                  resample_to_grid)
from fdpost.domain.field_data import FieldData
from fdpost.domain.requests import PreprocessConfig
from fdpost.domain.uniform_grid import LayeredGrid, UniformGrid

from test_v28_slices import lattice_wall, upload, write_tsv


def affine(p):
    return 1.0 + 2.0 * p[:, 0] - 3.0 * p[:, 1] + 1000.0 * p[:, 2]


def wall_fd(nx=24, ny=20, nz=60):
    p, fluid = lattice_wall(nx, ny, nz)
    f = affine(p)
    vel = np.where(fluid, 0.5 + p[:, 2], np.nan)
    return FieldData(points=p, fields={"f": f, "velocity_x": vel},
                     is_fluid=fluid, units={"f": "", "velocity_x": "m/s"})


# --- sampling without copies -------------------------------------------------------

def test_corner_sampling_matches_trilinear_with_solid_rule():
    rng = np.random.default_rng(1)
    dims = (17, 13, 11)
    a = rng.random(dims).astype(np.float32)
    a[3, 4, 5] = np.nan
    solid = rng.random(dims) < 0.05
    g = UniformGrid(origin=np.array([0.1, -0.2, 0.3]), spacing=np.array([0.01, 0.02, 0.005]),
                    dims=dims, arrays={"a": a}, solid_mask=solid, units={}, meta={})
    lo, hi = g.bounds
    pts = lo + (hi - lo) * (rng.random((20000, 3)) * 1.1 - 0.05)
    masked = a.astype(np.float64)
    masked[solid] = np.nan
    ref = ndimage.map_coordinates(masked, g.world_to_index(pts), order=1, mode="constant",
                                  cval=np.nan, prefilter=False)
    new = g.sample("a", pts)
    assert np.array_equal(np.isnan(ref), np.isnan(new))
    ok = np.isfinite(ref)
    assert np.abs(ref[ok] - new[ok]).max() < 1e-12
    # a point exactly on a voxel centre next to a solid voxel keeps its value
    # (the old map_coordinates path returned NaN there: 0 * NaN)
    i = np.argwhere(~solid & np.isfinite(a))[0]
    assert np.isfinite(g.sample("a", (g.origin + i * g.spacing)[None])[0])


def test_sampling_does_not_copy_the_grid():
    dims = (160, 160, 160)                                  # 16 MB per float32 field
    g = UniformGrid(origin=np.zeros(3), spacing=np.full(3, 1e-3), dims=dims,
                    arrays={"a": np.ones(dims, np.float32)},
                    solid_mask=np.zeros(dims, bool), units={}, meta={})
    pts = np.random.default_rng(0).random((1000, 3)) * 0.159
    tracemalloc.start()
    g.sample("a", pts)
    g.plane("a", 2, 80)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    assert peak < 2_000_000, peak                           # the old path copied 33 MB


def test_chunked_solid_mask_equals_nearest_point(monkeypatch):
    fd = wall_fd()
    origin, sp, dims = grid_geometry(fd.bounds, PreprocessConfig(target_dims=40))
    monkeypatch.setattr(sm, "CHUNK_CELLS", 500)             # many slabs
    seen = []
    solid = sm.build_solid_mask(fd.points, fd.is_fluid, origin, sp, dims,
                                progress=seen.append)
    ax = [origin[i] + sp[i] * np.arange(dims[i]) for i in range(3)]
    X, Y, Z = np.meshgrid(*ax, indexing="ij")
    _, idx = cKDTree(fd.points).query(np.column_stack([X.ravel(), Y.ravel(), Z.ravel()]))
    assert np.array_equal(solid, (~fd.is_fluid[idx]).reshape(dims))
    assert len(seen) > 5 and seen[-1] == 1.0


# --- geometry ----------------------------------------------------------------------

def test_per_axis_spacing_and_region_box():
    fd = wall_fd()
    lo, hi = fd.bounds
    cfg = PreprocessConfig(spacing_xyz=(0.004, 0.005, 0.0005),
                           box=((0.02, 0.03, 0.11), (0.08, 0.07, 0.13)))
    origin, sp, dims = grid_geometry(fd.bounds, cfg)
    assert np.allclose(sp, [0.004, 0.005, 0.0005])
    top = origin + sp * (np.array(dims) - 1)
    assert np.all(origin >= np.array([0.02, 0.03, 0.11]) - 1e-12)
    assert np.all(top <= np.array([0.08, 0.07, 0.13]) + 1e-12)
    assert dims == (16, 9, 41)
    # the box is clipped to the data
    o2, _, d2 = grid_geometry(fd.bounds, PreprocessConfig(spacing=0.01,
                                                          box=((-1, -1, -1), (1, 1, 1))))
    assert np.all(o2 >= lo - 1e-12) and np.all(o2 + 0.01 * (np.array(d2) - 1) <= hi + 1e-12)
    with pytest.raises(Exception):
        grid_geometry(fd.bounds, PreprocessConfig(spacing=0.01, box=((2, 2, 2), (3, 3, 3))))
    with pytest.raises(Exception):
        PreprocessConfig(spacing_xyz=(0.01, 0, 0.01))


def test_region_grid_is_exact_for_linear_fields_and_layers_over_the_base():
    rng0 = np.random.default_rng(7)
    p = rng0.random((12000, 3)) * [0.1, 0.1, 0.3]           # random: a well-shaped Delaunay
    fluid = p[:, 2] > 0.12
    fd = FieldData(points=p, fields={"f": affine(p)}, is_fluid=fluid, units={"f": ""})
    base = resample_to_grid(fd, PreprocessConfig(method="linear", target_dims=16))
    box = ((0.03, 0.03, 0.13), (0.07, 0.07, 0.16))
    fine = resample_to_grid(fd, PreprocessConfig(method="linear", spacing=0.0015, box=box))
    lay = LayeredGrid(base, [fine])
    rng = np.random.default_rng(3)
    inside = np.array(box[0]) + (np.array(box[1]) - np.array(box[0])) * rng.random((500, 3)) * 0.9 + 0.001
    v = lay.sample("f", inside)
    assert np.allclose(v, affine(inside), atol=1e-6)
    assert np.array_equal(v, fine.sample("f", inside))
    outside = np.array([[0.01, 0.01, 0.2], [0.09, 0.09, 0.25]])
    assert np.array_equal(lay.sample("f", outside), base.sample("f", outside), equal_nan=True)
    # everything else is the base grid's
    assert lay.dims == base.dims and lay.arrays is base.arrays
    assert lay.nbytes == base.nbytes + fine.nbytes
    assert np.allclose(lay.finest_spacing_in(np.array(box[0]), np.array(box[1])), fine.spacing)


def test_build_progress_reaches_one_and_cancel_stops():
    fd = wall_fd()
    seen = []
    resample_to_grid(fd, PreprocessConfig(target_dims=24), progress=lambda f, m: seen.append(f))
    assert seen[-1] == pytest.approx(1.0) and seen == sorted(seen)

    class Stop(Exception):
        pass

    def cancel(f, m):
        if f > 0.3:
            raise Stop

    with pytest.raises(Stop):
        resample_to_grid(fd, PreprocessConfig(target_dims=24), progress=cancel)
    with pytest.raises(Exception):
        resample_to_grid(fd, PreprocessConfig(target_dims=200), max_cells=10_000)


# --- cost model --------------------------------------------------------------------

def test_estimate_and_memory_model():
    fd = wall_fd(40, 36, 90)
    cfg = PreprocessConfig(method="idw", target_dims=96)
    est = estimate_resample(fd, cfg)
    t0 = time.perf_counter()
    tracemalloc.start()
    grid = resample_to_grid(fd, cfg)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    took = time.perf_counter() - t0
    assert est["dims"] == list(grid.dims) and est["cells"] == int(np.prod(grid.dims))
    assert est["bytes_resident"] == grid.nbytes
    # numpy allocations are traced (scipy's KD-tree is not): the model is an upper bound
    assert est["bytes_peak"] >= peak, (est["bytes_peak"], peak)
    assert est["bytes_peak"] < 6 * peak + 50e6
    total = est["estimate_s"]["total"] - est["estimate_s"]["save"]
    assert total < 10 * took + 1.0 and took < 10 * total + 1.0
    assert grid_memory(1000, 6, "idw", 10)["resident"] == 1000 * 25


# --- API ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def ds_grid(api_client, tmp_path_factory):
    c, _ = api_client
    p, fluid = lattice_wall(30, 26, 70)
    path = write_tsv(tmp_path_factory.mktemp("grids") / "grid_wall.txt", p,
                     {"Temperature (K)": affine(p),
                      "Velocity (X) (m/s)": np.where(fluid, 0.4 + p[:, 2], np.nan)}, fluid)
    return upload(c, path, dims=24)


def _wait(c, jid, timeout=120):
    for _ in range(int(timeout / 0.05)):
        j = c.get(f"/api/jobs/{jid}").json()
        if j["status"] in ("done", "error", "cancelled"):
            return j
        time.sleep(0.05)
    raise TimeoutError


def test_grid_api_list_estimate_build_switch_delete(api_client, ds_grid):
    c, _ = api_client
    ds = ds_grid
    g = c.get(f"/api/datasets/{ds}/grids").json()
    assert g["base"] == "g0" and len(g["grids"]) == 1 and g["grids"][0]["base"]
    assert "cache_path" not in g["grids"][0] and g["budget_bytes"] > 0

    region = {"kind": "region", "spacing_xyz": [0.002, 0.002, 0.0008],
              "box": [[0.02, 0.02, 0.12], [0.08, 0.08, 0.15]], "method": "idw"}
    est = c.post(f"/api/datasets/{ds}/grids/estimate", json=region).json()
    assert est["within_budget"] and est["cells"] == np.prod(est["dims"])
    assert est["estimate_s"]["total"] >= 0 and est["existing"] is None

    j = _wait(c, c.post(f"/api/datasets/{ds}/grids", json=region).json()["id"])
    assert j["status"] == "done", j
    gid = j["result"]["grid_id"]
    g = c.get(f"/api/datasets/{ds}/grids").json()
    assert g["details"] == [gid]
    row = [x for x in g["grids"] if x["id"] == gid][0]
    assert row["kind"] == "region" and row["dims"] == est["dims"] and row["bytes_disk"] > 0

    store = c.app.state.store
    lay = store.get_grid(ds)
    assert isinstance(lay, LayeredGrid)
    q = np.array([[0.05, 0.05, 0.135], [0.04, 0.06, 0.145]])
    fine = [x for x in lay.details][0]
    assert np.array_equal(lay.sample("temperature", q), fine.sample("temperature", q))
    assert np.allclose(lay.sample("temperature", q), affine(q), atol=2.0)    # idw, lattice data

    # the grid slice through the region is sampled at the region's pitch
    m = c.get(f"/api/datasets/{ds}/preview/slice/temperature",
              params={"axis": "z", "position": 0.135, "interp": "true"})
    meta = __import__("json").loads(m.headers["X-Meta"])
    assert meta["spacing"][0] == pytest.approx(0.002, rel=0.01)
    pm = c.get(f"/api/datasets/{ds}/preview/meta").json()
    assert pm["details"] and pm["details"][0]["id"] == gid

    # same request again: reused, no rebuild
    again = c.post(f"/api/datasets/{ds}/grids/estimate", json=region).json()
    assert again["existing"] == gid

    # a second full grid, switched to as the base
    full = {"kind": "full", "spacing_xyz": [0.004, 0.004, 0.003], "activate": True}
    j2 = _wait(c, c.post(f"/api/datasets/{ds}/grids", json=full).json()["id"])
    gid2 = j2["result"]["grid_id"]
    info = c.get(f"/api/datasets/{ds}").json()
    assert info["base_grid"] == gid2 and info["spacing"] == pytest.approx([0.004, 0.004, 0.003])
    assert info["detail_grids"] == [gid]

    # the base in use cannot be deleted; others can
    assert c.delete(f"/api/datasets/{ds}/grids/{gid2}").status_code == 400
    r = c.put(f"/api/datasets/{ds}/grids/active", json={"base": "g0", "details": []})
    assert r.status_code == 200 and r.json()["base"] == "g0" and r.json()["details"] == []
    assert not isinstance(store.get_grid(ds), LayeredGrid)
    assert c.delete(f"/api/datasets/{ds}/grids/{gid}").json()["freed_bytes"] > 0
    assert c.put(f"/api/datasets/{ds}/grids/active",
                 json={"base": gid, "details": []}).status_code in (400, 404)


def test_grid_api_budget_and_cancel(api_client, ds_grid):
    c, _ = api_client
    ds = ds_grid
    settings = c.app.state.settings
    old = settings.grid_memory_budget_mb
    try:
        settings.grid_memory_budget_mb = 1          # 1 MB: nothing fits
        big = {"kind": "full", "spacing": 0.0005}
        est = c.post(f"/api/datasets/{ds}/grids/estimate", json=big).json()
        assert not est["within_budget"]
        j = _wait(c, c.post(f"/api/datasets/{ds}/grids", json=big).json()["id"])
        assert j["status"] == "error" and "budget" in (j["error"] or "")
    finally:
        settings.grid_memory_budget_mb = old
    n0 = len(c.get(f"/api/datasets/{ds}/grids").json()["grids"])
    fine = {"kind": "full", "spacing": 0.0012, "method": "idw"}
    jid = c.post(f"/api/datasets/{ds}/grids", json=fine).json()["id"]
    time.sleep(0.4)
    c.post(f"/api/jobs/{jid}/cancel")
    j = _wait(c, jid)
    assert j["status"] in ("cancelled", "done")
    if j["status"] == "cancelled":
        assert len(c.get(f"/api/datasets/{ds}/grids").json()["grids"]) == n0
    assert c.post(f"/api/datasets/{ds}/grids",
                  json={"kind": "region", "spacing": 0.01}).status_code == 422


def test_display_caps(api_client, ds_grid):
    c, _ = api_client
    ds = ds_grid
    r = c.get(f"/api/datasets/{ds}/preview/points/temperature", params={"max_points": 10**9})
    assert int(r.headers["X-Count"]) <= c.app.state.settings.point_cloud_max
    m = c.get(f"/api/datasets/{ds}/preview/meta", params={"max_dim": 10**6}).json()
    assert max(m["dims"]) <= c.app.state.settings.preview_res_max


def test_downsample_is_per_axis():
    """A mesh refined along one axis must not come out coarser across."""
    dims = (64, 64, 596)
    g = UniformGrid(origin=np.zeros(3), spacing=np.array([1.56e-3, 1.56e-3, 0.5e-3]),
                    dims=dims, arrays={"t": np.zeros(dims, np.float32)},
                    solid_mask=np.zeros(dims, bool), units={}, meta={})
    d = g.downsample(128)
    assert d.dims == (64, 64, 120)
    assert np.allclose(d.spacing, [1.56e-3, 1.56e-3, 2.5e-3])
    assert d.meta["downsampled_stride"] == [1, 1, 5]
    assert g.downsample(600) is g
    c = g.downsample(30)                        # every axis within the cap
    assert max(c.dims) <= 30 and c.dims == (22, 22, 30)

