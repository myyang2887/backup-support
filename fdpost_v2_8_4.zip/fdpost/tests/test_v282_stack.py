"""v2.8.2 (step 2): slice stacks, export as a job, free-plane preview jobs."""
from __future__ import annotations

import io
import json
import time
import zipfile
from pathlib import Path

import numpy as np
import pytest

from fdpost.domain.field_data import FieldData
from fdpost.domain.requests import StackRequest
from fdpost.services.field_evaluator import FieldEvaluator
from fdpost.services.slice_stack import build_stack, plan_stack, quantize

from test_v28_slices import lattice_wall, upload, write_tsv

WALL = 0.12


def layered(nxy=24, dz0=5e-5, growth=1.12, top=0.18):
    h = 0.1 / nxy
    xc = (np.arange(nxy) + 0.5) * h
    zs = np.arange(0.104, WALL, 0.004)
    f, d = [WALL], dz0
    while f[-1] < top:
        f.append(min(top, f[-1] + d))
        d *= growth
    f = np.array(f)
    z = np.concatenate([zs, 0.5 * (f[1:] + f[:-1])])
    X, Y, Z = np.meshgrid(xc, xc, z, indexing="ij")
    return np.column_stack([X.ravel(), Y.ravel(), Z.ravel()]), z


def affine(p):
    return 1.0 + 2.0 * p[:, 0] - 3.0 * p[:, 1] + 1000.0 * p[:, 2]


def ev_for(p, f, fluid=None):
    return FieldEvaluator(FieldData(points=p, fields={"f": f},
                                    is_fluid=np.ones(len(p), bool) if fluid is None else fluid,
                                    units={}))


# --- planning -------------------------------------------------------------------

def test_stack_positions_follow_the_data_layers():
    p, z = layered()
    ev = ev_for(p, affine(p))
    plan = plan_stack(ev, StackRequest(field="f", axis="z", along=1.0))
    t = plan.t
    near = t[(t > WALL) & (t < WALL + 5e-4)]
    far = t[t > 0.16]
    assert near.size >= 5                                  # thin layers resolved
    assert np.diff(far).min() > 20 * np.diff(near).max()  # coarse where the data is
    assert t.size < 3 * len(z)                            # not a uniform fine pitch
    # along=0.5: a midpoint between layers -> about twice as many slices
    plan2 = plan_stack(ev, StackRequest(field="f", axis="z", along=0.5))
    assert 1.6 < plan2.t.size / t.size < 2.4


def test_vertical_stack_samples_layers_non_uniformly_in_plane():
    p, z = layered()
    ev = ev_for(p, affine(p))
    plan = plan_stack(ev, StackRequest(field="f", axis="y", inplane=1.0))
    assert plan.labels == ("X [m]", "Z [m]")
    dv = np.diff(plan.v)
    assert dv.min() < 1e-4 and dv.max() > 1e-3            # dense at the wall only
    assert abs(np.diff(plan.u).mean() - 0.1 / 24) < 2e-4    # one sample per column


def test_plane_cap_coarsens_instead_of_exploding():
    p, z = layered()
    ev = ev_for(p, affine(p))
    plan = plan_stack(ev, StackRequest(field="f", axis="z", along=0.05, max_planes=40))
    assert plan.t.size <= 40 and plan.data_spacing["coarsened"]["along"] > 1


# --- values -----------------------------------------------------------------------

def test_stack_values_equal_the_exact_evaluator_and_interpolate_linear_fields():
    p, z = layered()
    ev = ev_for(p, affine(p))
    plan = plan_stack(ev, StackRequest(field="f", axis="z", t_range=(0.1201, 0.13),
                                       inplane=1.0))
    vals = build_stack(ev, plan, "f", "local_linear")
    i = plan.t.size // 2
    q = plan.points(float(plan.t[i]))
    st, _ = ev.classify(q)
    exact = ev.evaluate(["f"], q, st).values["f"].reshape(plan.v.size, plan.u.size)
    assert np.allclose(vals[i], exact, equal_nan=True, rtol=1e-6)
    # between slices: linear in t + bilinear in-plane is exact for an affine field
    rng = np.random.default_rng(3)
    for _ in range(20):
        tq = rng.uniform(plan.t[0], plan.t[-1])
        j = int(np.clip(np.searchsorted(plan.t, tq) - 1, 0, plan.t.size - 2))
        w = (tq - plan.t[j]) / (plan.t[j + 1] - plan.t[j])
        iu, iv = rng.integers(0, plan.u.size), rng.integers(0, plan.v.size)
        got = (1 - w) * vals[j, iv, iu] + w * vals[j + 1, iv, iu]
        pt = plan.origin + tq * plan.normal + plan.u[iu] * plan.u_hat + plan.v[iv] * plan.v_hat
        assert got == pytest.approx(affine(pt[None])[0], rel=1e-6)


def test_quantize_roundtrip_and_nan_code():
    a = np.array([[1.0, np.nan], [3.0, 2.0]], dtype=np.float32)
    body, lo, hi = quantize(a)
    q = np.frombuffer(body, "<u2").reshape(2, 2)
    assert q[0, 1] == 65535 and lo == 1.0 and hi == 3.0
    dec = lo + q * (hi - lo) / 65534
    assert np.allclose(dec[np.isfinite(a)], a[np.isfinite(a)], atol=(hi - lo) * 2e-5)


def test_euler_stack_plans_union_extent():
    p, z = layered()
    ev = ev_for(p, affine(p))
    plan = plan_stack(ev, StackRequest(field="f", mode="euler", tilt_deg=30,
                                       azimuth_deg=20, along=2.0, inplane=2.0))
    assert plan.mode == "euler" and plan.labels == ("u [m]", "v [m]")
    c = (ev.bounds[0] + ev.bounds[1]) / 2
    assert np.allclose(plan.origin, c)
    tt = (p - c) @ plan.normal
    assert plan.t[0] == pytest.approx(tt.min()) and plan.t[-1] == pytest.approx(tt.max())


# --- API ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def ds_wall(api_client, tmp_path_factory):
    c, _ = api_client
    pts, fluid = lattice_wall(20, 18, 50)
    path = write_tsv(tmp_path_factory.mktemp("stk") / "wall.txt", pts,
                     {"Fz (-)": np.where(fluid, 1000 * pts[:, 2], np.nan),
                      "Temperature (K)": 300 + 100 * pts[:, 2]}, fluid)
    return upload(c, path, dims=24), path


def _wait(c, jid, timeout=180):
    t0 = time.time()
    while time.time() - t0 < timeout:
        j = c.get(f"/api/jobs/{jid}").json()
        if j["status"] in ("done", "error", "cancelled"):
            return j
        time.sleep(0.05)
    raise TimeoutError


def test_stack_api_estimate_build_cache_fetch(api_client, ds_wall):
    c, _ = api_client
    ds, _ = ds_wall
    body = {"field": "fz", "axis": "z", "t_range": [0.121, 0.2], "method": "local_linear"}
    est = c.post(f"/api/datasets/{ds}/stacks/estimate", json=body).json()
    p, nv, nu = est["plan"]["dims"]
    assert est["cached"] is False and est["estimate_s"] >= 0
    assert est["bytes_browser"] == p * nv * nu * 2
    j = _wait(c, c.post(f"/api/datasets/{ds}/stacks", json=body).json()["id"])
    assert j["status"] == "done" and j["result"]["cached"] is False
    key = j["result"]["key"]
    assert c.post(f"/api/datasets/{ds}/stacks/estimate", json=body).json()["cached"] is True
    j2 = _wait(c, c.post(f"/api/datasets/{ds}/stacks", json=body).json()["id"])
    assert j2["result"] == {"key": key, "cached": True}
    meta = c.get(f"/api/datasets/{ds}/stacks/{key}").json()
    assert meta["dims"] == [p, nv, nu] and len(meta["t"]) == p
    r = c.get(f"/api/datasets/{ds}/stacks/{key}/data")
    hm = json.loads(r.headers["X-Meta"])
    q = np.frombuffer(r.content, "<u2").reshape(p, nv, nu)
    vals = hm["lo"] + q * (hm["hi"] - hm["lo"]) / 65534
    t = np.array(meta["t"])
    # fz = 1000 z (local linear reproduces it): every fluid sample of slice i
    # equals 1000 t_i, to the uint16 quantization
    for i in (0, p // 2, p - 1):
        ok = q[i] != 65535
        assert ok.any()
        assert np.allclose(vals[i][ok], 1000 * t[i], atol=(hm["hi"] - hm["lo"]) * 3e-5)
    assert any(s["key"] == key for s in c.get(f"/api/datasets/{ds}/stacks").json())
    # a different method or field is a different stack
    other = c.post(f"/api/datasets/{ds}/stacks/estimate",
                   json={**body, "method": "idw"}).json()
    assert other["key"] != key and other["cached"] is False
    assert c.delete(f"/api/datasets/{ds}/stacks/{key}").status_code == 200
    assert c.post(f"/api/datasets/{ds}/stacks/estimate", json=body).json()["cached"] is False


def test_stack_budget_and_cancel(api_client, ds_wall):
    c, _ = api_client
    ds, _ = ds_wall
    s = c.app.state.settings
    old = s.stack_max_samples
    s.stack_max_samples = 1000
    try:
        r = c.post(f"/api/datasets/{ds}/stacks/estimate", json={"field": "fz", "axis": "z"})
        assert r.status_code == 413 and "exceeds the limit" in r.text
    finally:
        s.stack_max_samples = old
    body = {"field": "temperature", "axis": "y", "along": 0.1, "inplane": 0.25,
            "method": "local_linear"}
    jid = c.post(f"/api/datasets/{ds}/stacks", json=body).json()["id"]
    c.post(f"/api/jobs/{jid}/cancel")
    assert _wait(c, jid)["status"] == "cancelled"
    key = c.post(f"/api/datasets/{ds}/stacks/estimate", json=body).json()
    assert key["cached"] is False                         # nothing half-written


def test_export_job_progress_download_once_and_cleanup(api_client, ds_wall):
    c, _ = api_client
    ds, _ = ds_wall
    body = {"mode": "axis", "axis": "z", "position": 0.15, "field": "temperature",
            "formats": ["png", "csv", "json"],
            "sampling": {"mode": "long_edge", "long_edge_samples": 64},
            "render": {"long_edge_px": 500, "dpi": 100}}
    snap = c.post(f"/api/datasets/{ds}/slices/export_job", json=body).json()
    j = _wait(c, snap["id"])
    assert j["status"] == "done" and j["has_file"] and j["progress"] == 1.0
    summary = json.loads(j["result"]["summary"])
    assert max(summary["dims"]) == 64 and max(summary["image_px"]) == 500
    job = c.app.state.jobs.get(snap["id"])
    tmpdir = Path(job.file_dir)
    assert tmpdir.is_dir()
    r = c.get(f"/api/jobs/{snap['id']}/download")
    assert r.status_code == 200
    names = set(zipfile.ZipFile(io.BytesIO(r.content)).namelist())
    assert {"slice.png", "slice.csv", "manifest.json"} <= names
    assert json.loads(r.headers["X-Fdpost-Summary"])["dims"] == summary["dims"]
    assert not tmpdir.exists()                            # deleted after the download
    assert c.get(f"/api/jobs/{snap['id']}/download").status_code == 409


def test_export_job_cancel_leaves_nothing(api_client, ds_wall):
    c, _ = api_client
    ds, _ = ds_wall
    body = {"mode": "axis", "axis": "y", "position": 0.05, "field": "temperature",
            "formats": ["png"], "sampling": {"mode": "long_edge", "long_edge_samples": 1500},
            "evaluation": {"source": "original", "method": "local_linear"}}
    jid = c.post(f"/api/datasets/{ds}/slices/export_job", json=body).json()["id"]
    time.sleep(0.3)
    c.post(f"/api/jobs/{jid}/cancel")
    j = _wait(c, jid)
    assert j["status"] == "cancelled"
    assert c.app.state.jobs.get(jid).file_dir is None


def test_free_plane_preview_job(api_client, ds_wall):
    c, _ = api_client
    ds, _ = ds_wall
    body = {"mode": "euler", "tilt_deg": 25, "azimuth_deg": 10, "distance": 0.01,
            "field": "temperature", "samples": 48, "method": "local_linear"}
    j = _wait(c, c.post(f"/api/datasets/{ds}/preview/slice_job", json=body).json()["id"])
    assert j["status"] == "done", j
    r = c.get(f"/api/datasets/{ds}/preview/slice_job/{j['id']}")
    meta = json.loads(r.headers["X-Meta"])
    assert meta["labels"] == ["u [m]", "v [m]"] and meta["position"] == pytest.approx(0.01)
    vals = np.frombuffer(r.content, np.float32)
    assert np.isfinite(vals).any()
    # ROI in in-plane offsets
    j = _wait(c, c.post(f"/api/datasets/{ds}/preview/slice_job",
                        json={**body, "u_range": [-0.01, 0.01], "v_range": [-0.02, 0.0]}
                        ).json()["id"])
    meta = json.loads(c.get(f"/api/datasets/{ds}/preview/slice_job/{j['id']}").headers["X-Meta"])
    assert meta["origin"][0] == pytest.approx(-0.01) and meta["origin"][1] == pytest.approx(-0.02)


def test_export_progress_shares_follow_the_cost_model(api_client, ds_wall):
    """A big CSV gets a big share of the bar (the ETA extrapolated from
    early progress must not be several times too short); progress is
    monotonic and the zip step is reported."""
    from fdpost.domain.requests import SliceExportRequest
    from fdpost.services.slice_export_service import SliceExportService

    c, _ = api_client
    ds, _ = ds_wall
    svc = SliceExportService(c.app.state.store, c.app.state.settings)
    base = {"mode": "axis", "axis": "z", "position": 0.15, "field": "temperature",
            "sampling": {"mode": "long_edge", "long_edge_samples": 512},
            "evaluation": {"source": "original", "method": "idw"},
            "render": {"long_edge_px": 500, "dpi": 100}}
    png = SliceExportRequest(**base, formats=["png"])
    csv = SliceExportRequest(**base, formats=["png", "csv"])
    a = svc.phase_weights(ds, png, svc.specs(png), 0.02)
    b = svc.phase_weights(ds, csv, svc.specs(csv), 0.06)
    for w, tail in ((a, 0.02), (b, 0.06)):
        assert 0 < w[0] < w[1] <= w[2] == pytest.approx(1 - tail)
    assert b[0] < a[0] - 0.2                   # writing the CSV takes a real share

    seen, msgs = [], set()
    body = {**base, "formats": ["png", "csv", "json"]}
    jid = c.post(f"/api/datasets/{ds}/slices/export_job", json=body).json()["id"]
    job = c.app.state.jobs.get(jid)
    while job.status not in ("done", "error", "cancelled"):
        seen.append(job.progress)
        msgs.add(job.message)
        time.sleep(0.01)
    assert job.status == "done"
    assert all(x <= y + 1e-12 for x, y in zip(seen, seen[1:]))
    assert job.progress == 1.0


def test_stack_estimate_is_measured_on_whole_rows(api_client, ds_wall):
    c, _ = api_client
    ds, _ = ds_wall
    body = {"field": "temperature", "mode": "axis", "axis": "z", "method": "idw",
            "along": 1.0, "inplane": 1.0}
    e = c.post(f"/api/datasets/{ds}/stacks/estimate", json=body).json()
    assert e["estimate_s"] >= 0 and 0 <= e["fluid_fraction_in_probe"] <= 1
    t0 = time.perf_counter()
    jid = c.post(f"/api/datasets/{ds}/stacks", json=body).json()["id"]
    assert _wait(c, jid)["status"] == "done"
    took = time.perf_counter() - t0
    # same order of magnitude (generous: CI machines are noisy)
    assert took < 10 * e["estimate_s"] + 2.0


def test_version_endpoint_reports_the_package_version(api_client):
    import fdpost

    c, _ = api_client
    assert c.get("/api/version").json()["version"] == fdpost.__version__
