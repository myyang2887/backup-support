/** The loaded slice stack (精細可視化), kept outside the React store: it can
 *  be tens of MB and must not be copied or diffed on every state change.
 *
 *  Data: uint16 per sample, [slice][v][u]; value = lo + q*(hi-lo)/65534,
 *  65535 = no value. A slice between two stack slices is blended linearly
 *  (where one side has no value, the nearer slice decides -- walls stay sharp). */
import { useEffect, useState } from "react";
import type { SliceParams } from "./store";

export interface StackMeta {
  key: string; field: string; unit: string; method: string;
  mode: "axis" | "euler"; axis: "x" | "y" | "z" | null;
  normal: number[]; origin: number[]; u_hat: number[]; v_hat: number[];
  t: number[]; u: number[]; v: number[]; labels: [string, string];
  dims: [number, number, number]; n_samples: number;
  request: { tilt_deg: number; azimuth_deg: number; axis: string; mode: string;
             along: number; inplane: number };
  build_s?: number;
}
export interface LoadedStack {
  dsId: string; meta: StackMeta; q: Uint16Array; lo: number; hi: number;
}

let loaded: LoadedStack | null = null;
const listeners = new Set<() => void>();
const notify = () => listeners.forEach((f) => f());

export function getStack(): LoadedStack | null { return loaded; }

export function clearStack(): void { loaded = null; notify(); }

export async function loadStack(dsId: string, key: string): Promise<LoadedStack> {
  const [m, r] = await Promise.all([
    fetch(`/api/datasets/${dsId}/stacks/${key}`).then((x) => x.json()),
    fetch(`/api/datasets/${dsId}/stacks/${key}/data`),
  ]);
  if (!r.ok) throw new Error(await r.text());
  const hm = JSON.parse(r.headers.get("X-Meta") ?? "{}");
  loaded = { dsId, meta: m, q: new Uint16Array(await r.arrayBuffer()), lo: hm.lo, hi: hm.hi };
  notify();
  return loaded;
}

export function useLoadedStack(): LoadedStack | null {
  const [, bump] = useState(0);
  useEffect(() => {
    const f = () => bump((x) => x + 1);
    listeners.add(f);
    return () => { listeners.delete(f); };
  }, []);
  return loaded;
}

const near = (a: number, b: number) => Math.abs(a - b) < 1e-9;

/** Does the loaded stack serve this slice (same dataset, field, direction,
 *  position inside its range)? */
export function stackServes(L: LoadedStack | null, dsId: string | null, field: string,
                            s: SliceParams): boolean {
  if (!L || L.dsId !== dsId || L.meta.field !== field) return false;
  const m = L.meta;
  const t = s.submode === "axis" ? s.pos : s.distance;
  if (t < m.t[0] - 1e-12 || t > m.t[m.t.length - 1] + 1e-12) return false;
  if (s.submode === "axis") return m.mode === "axis" && m.axis === s.axis;
  return m.mode === "euler" && near(m.request.tilt_deg, s.tilt)
    && near(m.request.azimuth_deg, s.azimuth);
}

/** Does the loaded stack have this direction at all (position aside)? */
export function stackDirectionMatches(L: LoadedStack | null, s: SliceParams): boolean {
  if (!L) return false;
  const m = L.meta;
  if (s.submode === "axis") return m.mode === "axis" && m.axis === s.axis;
  return m.mode === "euler" && near(m.request.tilt_deg, s.tilt)
    && near(m.request.azimuth_deg, s.azimuth);
}

/** The slice at t, blended from the two stack slices around it. */
export function stackSlice(L: LoadedStack, t: number)
  : { x: number[]; y: number[]; z: (number | null)[][] } {
  const { t: ts, u, v, dims } = L.meta;
  const [, nv, nu] = dims;
  let a = 0, b = ts.length - 1;
  while (b - a > 1) { const m = (a + b) >> 1; if (ts[m] <= t) a = m; else b = m; }
  const j = Math.min(a, ts.length - 2 < 0 ? 0 : ts.length - 2);
  const k = Math.min(j + 1, ts.length - 1);
  const w = k === j ? 0 : Math.min(Math.max((t - ts[j]) / (ts[k] - ts[j]), 0), 1);
  const sc = (L.hi - L.lo) / 65534;
  const q = L.q, per = nv * nu, o0 = j * per, o1 = k * per;
  const z: (number | null)[][] = new Array(nv);
  for (let iv = 0; iv < nv; iv++) {
    const row: (number | null)[] = new Array(nu);
    const base = iv * nu;
    for (let iu = 0; iu < nu; iu++) {
      const q0 = q[o0 + base + iu], q1 = q[o1 + base + iu];
      if (q0 === 65535 || q1 === 65535) {
        const qq = w < 0.5 ? q0 : q1;
        row[iu] = qq === 65535 ? null : L.lo + qq * sc;
      } else {
        row[iu] = L.lo + ((1 - w) * q0 + w * q1) * sc;
      }
    }
    z[iv] = row;
  }
  return { x: u, y: v, z };
}
