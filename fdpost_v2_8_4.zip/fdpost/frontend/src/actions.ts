/** Shared use-case actions: dataset activation, field switch, session state. */
import { computeClim, getDataset, getIsoRange, getIsoStats, getIsosurface, getPreviewMeta,
         getPreviewPoints, getPreviewVectors, getPreviewVolume,
         getSolidPoints,
         listDatasets } from "./api";
import { shellLevels } from "./viz3d/isosurface";
import type { IsoMesh } from "./types";
import { DISPLAY_DEFAULTS, EXPORT_DEFAULTS, useStore } from "./store";
import { toast } from "./toast";
import { fieldRole } from "./types";

const st = () => useStore.getState();

export async function refreshDatasets(): Promise<void> {
  st().set({ datasets: await listDatasets() });
}

export async function activateDataset(id: string, field?: string): Promise<void> {
  const meta = await getDataset(id);
  if (meta.status !== "ready") {
    throw new Error(`前処理が未完了です(${meta.status})`);
  }
  const f = field ??
    meta.fields.find((x) => fieldRole(x) === "scalar_field") ?? meta.fields[0];
  const prev = st().display;
  const pm = await getPreviewMeta(id, prev.previewRes);
  const [data, points] = await Promise.all([
    getPreviewVolume(id, f, prev.previewRes), getPreviewPoints(id, f, prev.pointCap)]);
  const lo = meta.bounds![0], hi = meta.bounds![1];
  const mid: [number, number, number] = [
    (lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2];
  st().set({
    activeId: id, meta, previewMeta: pm, activeField: f,
    clim: computeClim(data),
    previewGrid: { dims: pm.dims, origin: pm.origin as any,
                   spacing: pm.spacing as any, data },
    points,
    // a grid plane near the middle, as a physical position (v2.8 state)
    slice: { ...st().slice, submode: "axis", axis: "z",
             pos: pm.origin[2] + pm.spacing[2] * Math.floor(pm.dims[2] / 2),
             tilt: 0, azimuth: 0, distance: 0 },
    probe: { p0: [lo[0], mid[1], mid[2]], p1: [hi[0], mid[1], mid[2]] },
    stream: { ...st().stream, p0: [lo[0], mid[1], mid[2]],
              p1: [lo[0], mid[1], hi[2]] },
    // default steps follow the grid pitch: the natural "one sample per cell"
    region: { min: [lo[0], lo[1], lo[2]], max: [hi[0], hi[1], hi[2]],
              sampling: "count", res: [20, 20, 20],
              step: [pm.spacing[0], pm.spacing[1], pm.spacing[2]] },
    sliceExport: { sampling: "step", res: [200, 200],
                   step: [pm.spacing[0], pm.spacing[1]] },
    // sweep defaults to the full Z range of THIS dataset, not a blind 0..1
    batch: { start: lo[2], end: hi[2], step: pm.spacing[2] * 4,
             vectors: false, preview: true },
    iso: { ...st().iso, field: f, visible: false },
    isoMesh: null, streamData: null, vectors: null, shellMeshes: null,
    solidPoints: null,
    display: { ...DISPLAY_DEFAULTS, ...climFilter(computeClim(data)),
               pointCap: prev.pointCap, previewRes: prev.previewRes },
    planePng: "", probePng: "", drawerOpen: false,
  });
  try {
    const range = await getIsoRange(id, f);
    st().setIso({ range, level: 0.5 * (range[0] + range[1]) });
  } catch { /* range best-effort */ }
}

export async function refreshField(field: string): Promise<void> {
  const s = st();
  if (!s.activeId) return;
  const [data, points] = await Promise.all([
    getPreviewVolume(s.activeId, field, s.display.previewRes),
    getPreviewPoints(s.activeId, field, s.display.pointCap)]);
  const clim = computeClim(data);
  s.set({
    activeField: field, clim,
    previewGrid: s.previewGrid ? { ...s.previewGrid, data } : null,
    points,
    // the filter window is expressed in field units, so re-fit it on switch
    display: { ...s.display, ...climFilter(clim) },
  });
}

/** Re-fetch everything drawn from the grid, keeping the rest of the state
 *  (slice position, tool settings, camera). Used after the grid in use
 *  changes or the 3D detail settings change. */
export async function reloadGridData(opts: { points?: boolean; preview?: boolean } = {})
  : Promise<void> {
  const s = st();
  if (!s.activeId) return;
  const id = s.activeId, f = s.activeField;
  const all = !opts.points && !opts.preview;
  const meta = all ? await getDataset(id) : s.meta;
  const wantPreview = all || opts.preview;
  const [pm, data] = wantPreview
    ? await Promise.all([getPreviewMeta(id, s.display.previewRes),
                        getPreviewVolume(id, f, s.display.previewRes)])
    : [s.previewMeta, null];
  const points = (all || opts.points) ? await getPreviewPoints(id, f, s.display.pointCap)
    : s.points;
  const upd: any = { meta, previewMeta: pm, points };
  if (data && pm) {
    upd.previewGrid = { dims: pm.dims, origin: pm.origin, spacing: pm.spacing, data };
  }
  if (all) {
    // anything computed from the old grid is stale
    Object.assign(upd, { isoMesh: null, shellMeshes: null, vectors: null,
                         solidPoints: null, streamData: null });
  }
  st().set(upd);
}

/** A fresh filter window covering the whole range of a field. */
function climFilter(clim: [number, number]) {
  return { filterMin: clim[0], filterMax: clim[1] };
}

/** Fetch solid voxel centres for the 3D shell. */
export async function loadSolidPoints(): Promise<void> {
  const s = st();
  if (!s.activeId) return;
  const c = await getSolidPoints(s.activeId);
  if (!c.length) throw new Error("このデータに固体セルはありません");
  s.set({ solidPoints: c });
}

/** Fetch the velocity glyph lattice for the 3D arrow field. */
export async function loadVectors(): Promise<void> {
  const s = st();
  if (!s.activeId) return;
  const vf = await getPreviewVectors(s.activeId, s.display.arrowDensity);
  if (!vf.coords.length) throw new Error("このデータには速度の3成分が含まれていません");
  s.set({ vectors: vf });
}

/** Build the nested translucent isosurface shells for the active field. */
export async function loadShells(): Promise<void> {
  const s = st();
  if (!s.activeId) return;
  const stats = await getIsoStats(s.activeId, s.activeField);
  const range: [number, number] = [stats.min, stats.max];
  const levels = shellLevels(range, s.display.shellCount, stats.quantiles);
  // One unreachable level must not lose the whole stack: downsampling and
  // smoothing lower the peak, so a high level can legitimately fail while
  // the others are fine.
  const settled = await Promise.allSettled(
    levels.map((lv) => getIsosurface(s.activeId!, s.activeField, lv, {
      maxDim: s.display.shellMaxDim, smooth: s.display.shellSmooth,
      minComponentFrac: s.display.shellDespeckle,
    })));
  const meshes = settled
    .filter((r): r is PromiseFulfilledResult<IsoMesh> => r.status === "fulfilled")
    .map((r) => r.value)
    .filter((m) => m.verts.length > 0);
  if (!meshes.length) {
    const why = settled.find((r) => r.status === "rejected");
    throw new Error((why as PromiseRejectedResult | undefined)?.reason?.message
                    ?? "サーフェスを生成できませんでした");
  }
  if (meshes.length < levels.length) {
    toast(`${levels.length - meshes.length} 層は生成できませんでした`
          + "(平滑化・抽出解像度の影響で上限に届かない層があります)", "err");
  }
  st().setIso({ range });
  st().set({ shellMeshes: meshes });
}

// ---- session / snapshot state ------------------------------------------

/** v1 (<= 2.7) stored the axis cut as a preview-grid index `slice.k`;
 *  v2 (2.8) stores the physical position `slice.pos` [m]. */
export const SESSION_SCHEMA = 2;

export interface SessionState {
  schema?: number;
  /** preview grid the session was captured against (v2+) */
  previewBasis?: { origin: number[]; spacing: number[]; dims: number[] };
  exportSettings?: any;
  activeField: string; clim: [number, number];
  vizMode: string; activeTool: string; cursorReadout: boolean;
  slice: any; probe: any; region: any; stream: any;
  iso: { field: string; level: number; opacity: number; visible: boolean };
  display?: any;
  camera: { position: number[]; target: number[] } | null;
}

export function captureState(): SessionState {
  const s = st();
  return {
    schema: SESSION_SCHEMA,
    previewBasis: s.previewGrid ? { origin: [...s.previewGrid.origin],
      spacing: [...s.previewGrid.spacing], dims: [...s.previewGrid.dims] } : undefined,
    exportSettings: s.exportSettings,
    activeField: s.activeField, clim: s.clim,
    vizMode: s.vizMode, activeTool: s.activeTool,
    cursorReadout: s.cursorReadout,
    slice: s.slice, probe: s.probe, region: s.region, stream: s.stream,
    iso: { field: s.iso.field, level: s.iso.level,
           opacity: s.iso.opacity, visible: s.iso.visible },
    display: s.display,
    camera: s.viewerApi ? s.viewerApi.getCamera() : null,
  };
}

export async function applyState(datasetId: string,
                                 state: SessionState): Promise<void> {
  await activateDataset(datasetId, state.activeField);
  const s = st();
  const slice = migrateSlice(state, s);
  s.set({
    clim: state.clim ?? s.clim,
    vizMode: (state.vizMode as any) ?? "guide",
    activeTool: (state.activeTool as any) ?? "slice",
    cursorReadout: state.cursorReadout ?? true,
    slice,
    exportSettings: { ...EXPORT_DEFAULTS, ...(state.exportSettings ?? {}) },
    probe: { ...s.probe, ...state.probe },
    region: { ...s.region, ...state.region },
    stream: { ...s.stream, ...state.stream },
    display: { ...s.display, ...(state.display ?? {}) },
  });
  if (state.display?.arrowsVisible) {
    try { await loadVectors(); }
    catch (e: any) { toast(`矢印の復元に失敗しました: ${e.message}`, "err"); }
  }
  if (state.display?.solidVisible) {
    try { await loadSolidPoints(); }
    catch (e: any) { toast(`固体セルの復元に失敗しました: ${e.message}`, "err"); }
  }
  if (state.display?.shellsVisible) {
    try { await loadShells(); }
    catch (e: any) { toast(`サーフェスの復元に失敗しました: ${e.message}`, "err"); }
  }
  if (state.iso) {
    try {
      const range = await getIsoRange(datasetId, state.iso.field);
      s.setIso({ ...state.iso, range });
      if (state.iso.visible) {
        s.set({ isoMesh: await getIsosurface(datasetId, state.iso.field,
                                             state.iso.level) });
      }
    } catch (e: any) { toast(`等値面の復元に失敗しました: ${e.message}`, "err"); }
  }
  if (state.camera && s.viewerApi) s.viewerApi.setCamera(state.camera);
  if (state.stream) toast("流線は「生成」で再計算できます");
}


/** Session slice -> v2 SliceParams. A v1 session only has a grid index k;
 *  it is converted with the preview grid it referred to. v1 sessions did not
 *  record that grid, so the current preview grid of the same dataset is used
 *  and the user is told the position was converted and should be checked. */
function migrateSlice(state: SessionState, s: ReturnType<typeof st>) {
  const raw = { ...(state.slice ?? {}) };
  const cur = s.slice;
  if (typeof raw.pos === "number") {
    delete raw.k;
    return { ...cur, ...raw };
  }
  if (typeof raw.k === "number" && s.previewGrid) {
    const a = { x: 0, y: 1, z: 2 }[(raw.axis ?? cur.axis) as "x" | "y" | "z"];
    const g = state.previewBasis ?? s.previewGrid;
    const pos = g.origin[a] + g.spacing[a] * Math.min(raw.k, g.dims[a] - 1);
    delete raw.k;
    if (!state.previewBasis) {
      toast(`旧形式のセッションです。断面位置をメッシュの番号から ${pos.toFixed(6)} m に換算しました。`
            + "前処理の設定が当時と異なる場合はずれるので、位置を確認してください。");
    }
    return { ...cur, ...raw, pos };
  }
  delete raw.k;
  return { ...cur, ...raw };
}
