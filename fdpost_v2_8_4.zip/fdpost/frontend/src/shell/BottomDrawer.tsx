/** Resizable results drawer: real-time contour / plane PNG / probe curve.
 *
 *  The contour tab follows result2d/sliceSource: the grid while the slice
 *  moves, the exact computation once it has been still for a second. The
 *  status chip says which one is on screen; a 2-px line on the plot's top
 *  edge shows the progress of the exact computation. */
import { useEffect, useRef, useState } from "react";
import { getSliceNative, type SliceNativeOut } from "../api";
import Contour2D from "../result2d/Contour2D";
import { QUIVER_DEFAULTS } from "../result2d/quiver";
import { KIND_LABEL, orientKey, useSliceData, type ViewRange } from "../result2d/sliceSource";
import { freePlane } from "../planeGeom";
import { useFeature } from "../features";
import { IconClose } from "../icons";
import { dataBounds } from "../exportSpecs";
import { useStore } from "../store";
import ProgressLine, { ProgressText } from "../ui/ProgressLine";
import ExportBar from "../panels/ExportBar";

const mm = (m: number) => (Math.abs(m) * 1e3).toPrecision(3);

function Toggle({ on, label, title, onChange }: {
  on: boolean; label: string; title: string; onChange: (v: boolean) => void;
}) {
  return (
    <label className="drawer-toggle" title={title}>
      <input type="checkbox" checked={on} onChange={(e) => onChange(e.target.checked)} />
      {label}
    </label>
  );
}

export default function BottomDrawer() {
  const { meta, activeId, activeField, clim, slice, drawerOpen, drawerTab,
          planePng, probePng, cursorReadout, display, setDisplay,
          set } = useStore();
  const drawerFeature = useFeature("shell.drawer");
  const hudFeature = useFeature("viewport.cursorHud");
  const quiverFeature = useFeature("viewport.quiver2d");
  const [height, setHeight] = useState(320);
  const [arrows, setArrows] = useState(false);
  const [native, setNative] = useState<SliceNativeOut | null>(null);
  const [files] = useState<string[]>([]);
  const [density, setDensity] = useState(QUIVER_DEFAULTS.targetCount);
  const [view, setView] = useState<ViewRange | null>(null);
  const [box, setBox] = useState({ w: 900, h: 280 });
  const dragRef = useRef<{ y: number; h: number } | null>(null);
  const bodyRef = useRef<HTMLDivElement>(null);

  const isAxis = slice.submode === "axis";
  // zoom survives moving the cut, not turning it or switching data
  const viewKey = `${activeId}|${orientKey(slice)}|${activeField}`;
  useEffect(() => setView(null), [viewKey]);

  useEffect(() => {
    const el = bodyRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setBox({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el);
    return () => ro.disconnect();
  }, [drawerOpen, drawerTab]);

  // "high" = one sample per device pixel the data actually covers. The plot
  // keeps the true aspect ratio, so the data rarely fills the drawer's width;
  // when zoomed, only the part of the visible range that holds data counts.
  // A free plane's data extent is plane ∩ data box in in-plane (u, v).
  const plotPx = (() => {
    if (!meta?.bounds) return 512;
    const [lo, hi] = dataBounds(meta);
    let eu: [number, number], ev: [number, number];
    if (isAxis) {
      const a = { x: 0, y: 1, z: 2 }[slice.axis];
      const [iu, iv] = [0, 1, 2].filter((i) => i !== a);
      eu = [lo[iu], hi[iu]]; ev = [lo[iv], hi[iv]];
    } else {
      const ext = freePlane(slice.tilt, slice.azimuth, slice.distance, lo, hi).ext;
      if (!ext) return 512;
      [eu, ev] = ext;
    }
    const vu: [number, number] = view ? view.x : eu;
    const vv: [number, number] = view ? view.y : ev;
    const su = Math.max(vu[1] - vu[0], 1e-12), sv = Math.max(vv[1] - vv[0], 1e-12);
    const availW = Math.max(100, box.w - 60 - 90), availH = Math.max(80, box.h - 84);
    const pxPerM = Math.min(availW / su, availH / sv);
    const cu = Math.max(0, Math.min(vu[1], eu[1]) - Math.max(vu[0], eu[0]));
    const cv = Math.max(0, Math.min(vv[1], ev[1]) - Math.max(vv[0], ev[0]));
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    return Math.max(cu, cv) * pxPerM * dpr;
  })();

  const wantVectors = quiverFeature && arrows;
  const { plot, detail, task } = useSliceData(wantVectors, { pxLongEdge: plotPx, view });

  // data spacing near the cut: context for the status chip
  useEffect(() => {
    const s2 = useStore.getState();
    if (!s2.activeId || drawerTab !== "contour" || slice.submode !== "axis") {
      setNative(null); return;
    }
    let live2 = true;
    const t = window.setTimeout(() => {
      getSliceNative(s2.activeId!, s2.activeField, s2.slice.axis, s2.slice.pos)
        .then((r) => { if (live2) setNative(r); })
        .catch(() => { if (live2) setNative(null); });
    }, 1200);
    return () => { live2 = false; window.clearTimeout(t); };
  }, [drawerTab, slice.pos, slice.axis, activeField]);

  if (!drawerFeature || !drawerOpen || !meta) return null;
  const unit = meta.units?.[activeField] ?? "";

  const onGrab = (e: React.PointerEvent) => {
    dragRef.current = { y: e.clientY, h: height };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onMove = (e: React.PointerEvent) => {
    if (!dragRef.current) return;
    const h = dragRef.current.h + (dragRef.current.y - e.clientY);
    setHeight(Math.min(window.innerHeight * 0.65, Math.max(180, h)));
  };
  const onRelease = () => { dragRef.current = null; };

  const shown = detail ?? plot;
  const chipTitle = [
    plot ? `表示中: ${KIND_LABEL[plot.kind]}` : "",
    shown ? `サンプル間隔 ${mm(shown.spacing[0])} × ${mm(shown.spacing[1])} mm` : "",
    native?.spacing_u_m && native?.spacing_v_m
      ? `この断面付近のデータ点の面内間隔 約 ${mm(native.spacing_u_m)} × ${mm(native.spacing_v_m)} mm`
        + "(これより細かい部分は補間値)" : "",
    plot?.kind === "stack"
      ? "動かしている間は断面スタック(前もって計算した断面)、止めて 1 秒後にこの位置で精確計算します。"
      : "動かしている間はメッシュ、止めて 1 秒後に元データから精確計算します。",
  ].filter(Boolean).join("\n");
  const chip = drawerTab === "contour" && plot && (
    <span className="drawer-chip" title={chipTitle}>
      {task.active
        ? <ProgressText task={task} />
        : <>
            <span className={plot.kind === "exact" || plot.kind === "fast" || detail ? "k-exact"
                             : plot.kind === "stack" ? "k-stack" : "k-grid"}>
              {detail ? "精確・拡大範囲" : KIND_LABEL[plot.kind]}
            </span>
            <span className="k-dim">
              {" · "}{shown!.dims[0]}×{shown!.dims[1]}
              {" · "}{mm(Math.max(shown!.spacing[0], shown!.spacing[1]))} mm
            </span>
          </>}
    </span>
  );

  return (
    <div style={{ height, background: "var(--bg-1)",
                  borderTop: "1px solid var(--line)", display: "flex",
                  flexDirection: "column", flexShrink: 0 }}>
      <div onPointerDown={onGrab} onPointerMove={onMove} onPointerUp={onRelease}
           style={{ height: 5, cursor: "ns-resize", background: "transparent",
                    borderTop: "2px solid var(--line-strong)" }} />
      <div className="row" style={{ padding: "2px 10px 0", gap: 0, flexWrap: "nowrap" }}>
        <div className="tabs">
          <button className={drawerTab === "contour" ? "on" : ""}
                  onClick={() => set({ drawerTab: "contour" })}>断面(リアルタイム)</button>
          <button className={drawerTab === "plane" ? "on" : ""}
                  onClick={() => set({ drawerTab: "plane" })}>斜め断面</button>
          <button className={drawerTab === "probe" ? "on" : ""}
                  onClick={() => set({ drawerTab: "probe" })}>ライン結果</button>
        </div>
        {chip}
        {drawerTab === "contour" && (
          <div className="row drawer-tools">
            <span className="drawer-group" title={"止めて 1 秒後に元データから精確計算します。\n"
                + "標準: 256 点 / 高: 表示画素ぶん(ドロワーを広げるか拡大表示すると細かくなります。拡大中は見えている範囲だけ計算)"}>
              <span className="drawer-label">精確計算</span>
              <span className="seg">
                {(["off", "standard", "high"] as const).map((v) => (
                  <button key={v} className={display.sliceExact === v ? "on" : ""}
                          onClick={() => setDisplay({ sliceExact: v })}>
                    {v === "off" ? "オフ" : v === "standard" ? "標準" : "高"}
                  </button>
                ))}
              </span>
            </span>
            <span className="drawer-sep" />
            <Toggle on={display.sliceSmooth !== false} label="平滑"
                    title="OFFにすると補間なしの生のセルを表示します(メッシュのセルそのものの確認用)"
                    onChange={(v) => setDisplay({ sliceSmooth: v })} />
            <Toggle on={display.solid2d} label="固体"
                    title="固体部分を塗りつぶします。この設定は出力される画像にも反映されます"
                    onChange={(v) => setDisplay({ solid2d: v })} />
            {quiverFeature && (
              <Toggle on={arrows} label="矢印" title="断面内の速度矢印"
                      onChange={setArrows} />
            )}
            {quiverFeature && arrows && (
              <input type="range" min={10} max={50} step={2} value={density}
                     title="矢印の密度" style={{ width: 70 }}
                     onInput={(e) => setDensity(+(e.target as HTMLInputElement).value)} />
            )}
            {files.length > 0 && <ExportBar files={files} />}
            {plot && (
              <button className="primary" style={{ fontSize: 11, padding: "2px 10px",
                                                    marginLeft: 6 }}
                      title="プレビューとは別に、出力用の設定で計算し直して PNG / CSV を出力します"
                      onClick={() => set({ exportDialogOpen: true, fineVizOpen: false, gridDialogOpen: false })}>
                断面を出力…
              </button>
            )}
          </div>
        )}
        <button className="quiet" style={{ marginLeft: "auto" }}
                title="閉じる" onClick={() => set({ drawerOpen: false })}>
          <IconClose size={13} />
        </button>
      </div>
      <div ref={bodyRef}
           style={{ flex: 1, overflow: "auto", padding: "4px 10px 10px", position: "relative" }}>
        {drawerTab === "contour" && <ProgressLine task={task} inset={10} />}
        {drawerTab === "contour" && (plot
          ? <Contour2D slice={plot} detail={detail} field={activeField} unit={unit}
                       clim={clim}
                       hover={hudFeature && cursorReadout}
                       smooth={display.sliceSmooth !== false}
                       solidColor={display.solid2d ? display.solidColor : null}
                       quiver={wantVectors
                         ? { ...QUIVER_DEFAULTS, targetCount: density } : null}
                       viewKey={viewKey}
                       onView={setView}
                       title={isAxis
                         ? `${slice.axis.toUpperCase()} = ${plot.position.toFixed(6)} m`
                         : `回転角 ${slice.tilt}°  方位角 ${slice.azimuth}°  距離 ${plot.position.toFixed(6)} m`} />
          : <div className="hint">断面ツールで断面を動かすとここにリアルタイム表示されます</div>)}
        {drawerTab === "plane" && (planePng
          ? <img src={planePng}
                 style={{ maxHeight: "100%", maxWidth: "100%", borderRadius: 4 }} />
          : <div className="hint">断面ツールの「断面を描画」の結果がここに表示されます</div>)}
        {drawerTab === "probe" && (probePng
          ? <img src={probePng}
                 style={{ maxHeight: "100%", maxWidth: "100%", borderRadius: 4 }} />
          : <div className="hint">ラインツールの実行結果がここに表示されます</div>)}
      </div>
    </div>
  );
}
