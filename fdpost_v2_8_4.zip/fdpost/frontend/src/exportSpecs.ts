/** One place that turns the UI state into v2.8 slice requests.
 *
 *  Every slice output (single export, free-plane render, batches) is built
 *  here, so they cannot drift apart again: in v2.7 the free-plane batch sent
 *  quality parameters the server never applied. The estimates below use the
 *  same rules as the server's lattice planner (core/plane.py); the server's
 *  response still reports what was actually done. */
import type { DatasetOut } from "./types";
import type { DisplayParams, ExportSettings, SliceParams } from "./store";

const AXIS_IDX = { x: 0, y: 1, z: 2 } as const;
const IN_PLANE = { x: [1, 2], y: [0, 2], z: [0, 1] } as const;

/** The data box. Prefer the source bounds the server recorded at
 *  preprocessing (v2.8); older caches only know the grid box. */
export function dataBounds(meta: DatasetOut): [number[], number[]] {
  const sb = (meta.meta as any)?.source_bounds as number[][] | undefined;
  if (sb && sb.length === 2) return [sb[0], sb[1]];
  return [meta.bounds![0], meta.bounds![1]];
}

/** Geometry fields of the cut currently being edited. */
export function currentGeometry(slice: SliceParams) {
  return slice.submode === "axis"
    ? { mode: "axis" as const, axis: slice.axis, position: slice.pos }
    : { mode: "euler" as const, tilt_deg: slice.tilt,
        azimuth_deg: slice.azimuth, distance: slice.distance };
}

export function sliceSpecs(ex: ExportSettings, display: DisplayParams) {
  const sampling = ex.sampling === "spacing"
    ? { mode: "spacing", spacing_m: [ex.spacingMm / 1e3, ex.spacingMm / 1e3] }
    : { mode: "long_edge", long_edge_samples: ex.sampleLongEdge };
  const evaluation = ex.source === "original"
    ? { source: "original", method: ex.method }
    : { source: "grid" };
  const render = {
    size_mode: "pixels", long_edge_px: ex.imagePx, dpi: ex.dpi,
    show_solid: display.solid2d, solid_color: display.solidColor,
    transparent_background: ex.transparent, show_axes: ex.showAxes,
  };
  return { sampling, evaluation, render };
}

/** In-plane extent [su, sv] in metres for an axis cut; null for free planes
 *  (their extent is the plane/box intersection, computed by the server). */
export function axisExtent(meta: DatasetOut, slice: SliceParams): [number, number] | null {
  if (slice.submode !== "axis") return null;
  const [lo, hi] = dataBounds(meta);
  const [a, b] = IN_PLANE[slice.axis];
  return [hi[a] - lo[a], hi[b] - lo[b]];
}

/** Same rule as plan_lattice() on the server. */
export function estimateLattice(ex: ExportSettings, ext: [number, number])
  : { nu: number; nv: number; du: number; dv: number } {
  const [su, sv] = ext;
  if (ex.sampling === "spacing") {
    const h = ex.spacingMm / 1e3;
    const nu = Math.floor(su / h + 1e-9) + 1, nv = Math.floor(sv / h + 1e-9) + 1;
    return { nu, nv, du: h, dv: h };
  }
  const n = ex.sampleLongEdge;
  const h = Math.max(su, sv) / Math.max(n - 1, 1);
  const nu = Math.max(2, Math.round(su / h) + 1);
  const nv = Math.max(2, Math.round(sv / h) + 1);
  return { nu, nv, du: su / (nu - 1), dv: sv / (nv - 1) };
}

export function inRange(meta: DatasetOut, slice: SliceParams): boolean {
  if (slice.submode !== "axis") return true;
  const [lo, hi] = dataBounds(meta);
  const a = AXIS_IDX[slice.axis];
  const tol = 1e-9 * Math.max(hi[a] - lo[a], 1e-12);
  return slice.pos >= lo[a] - tol && slice.pos <= hi[a] + tol;
}

/** Speed <-> quality presets. Any manual change shows as カスタム; nothing
 *  is locked, the presets only fill the fields. */
export interface Preset {
  id: string; label: string; hint: string; s: Partial<ExportSettings>;
}
export const PRESETS: Preset[] = [
  { id: "fast", label: "高速",
    hint: "前処理したメッシュから読む。数秒。細部はメッシュ間隔まで",
    s: { source: "grid", sampling: "long_edge", sampleLongEdge: 512,
         imagePx: 2400, dpi: 150 } },
  { id: "standard", label: "標準",
    hint: "元データを局所線形で評価。通常の報告用",
    s: { source: "original", method: "local_linear", sampling: "long_edge",
         sampleLongEdge: 1024, imagePx: 3000, dpi: 300 } },
  { id: "high", label: "高品質",
    hint: "標準と同じ方法で点数と画素を増やす(時間は約4倍)",
    s: { source: "original", method: "local_linear", sampling: "long_edge",
         sampleLongEdge: 2048, imagePx: 4500, dpi: 600 } },
  { id: "max", label: "最高精度",
    hint: "薄い層の近くで最も正確な方法(その部分は約10倍遅い)",
    s: { source: "original", method: "local_linear_hq", sampling: "long_edge",
         sampleLongEdge: 2048, imagePx: 4500, dpi: 600 } },
];
export function matchPreset(ex: ExportSettings): string {
  for (const p of PRESETS) {
    const ok = Object.entries(p.s).every(([k, v]) => (ex as any)[k] === v)
      && (p.s.source === "grid" || ex.source === "original");
    if (ok) return p.id;
  }
  return "custom";
}

export const SAMPLE_CHOICES = [256, 512, 1024, 2048];
export const IMAGE_CHOICES = [1600, 2400, 3000, 4500];
export const DPI_CHOICES = [150, 300, 600];

/** Human label for the data source + method. */
export function sourceLabel(ex: ExportSettings): string {
  if (ex.source === "grid") return "メッシュから高速出力";
  return ex.method === "idw" ? "元データ(IDW・高速)"
    : ex.method === "local_linear_hq" ? "元データ(最高精度)" : "元データ(局所線形)";
}

/** The X-Fdpost-Summary header the server attaches to streamed exports. */
export interface ExportSummary {
  dims?: number[]; spacing_m?: number[]; position_m?: number | null;
  source?: string; method_used?: Record<string, number>;
  image_px?: number[] | null; states?: Record<string, number>;
}

export function describeSummary(s: ExportSummary | null): string {
  if (!s || !s.dims) return "";
  const sp = (s.spacing_m ?? []).map((x) => (Math.abs(x) * 1e3).toPrecision(3));
  const img = s.image_px ? `、PNG ${s.image_px[0]}×${s.image_px[1]} px` : "";
  const mu = s.method_used ?? {};
  const fb = (mu["idw_fallback"] ?? 0);
  const fbTxt = fb > 0 ? `、IDW代替 ${fb} 点` : "";
  return `${s.dims[0]}×${s.dims[1]} 点(間隔 ${sp.join(" × ")} mm)${img}${fbTxt}`;
}


export interface EstimateOut {
  sample_shape: number[]; n_samples: number; method: string;
  estimate_s: { compute: number; render: number; csv: number; total: number };
  warmup_s: number; method_mix_in_probe: Record<string, number>;
}

export function fmtSeconds(s: number): string {
  if (s < 1) return "1 秒未満";
  if (s < 90) return `約 ${Math.round(s)} 秒`;
  return `約 ${(s / 60).toFixed(1)} 分`;
}
