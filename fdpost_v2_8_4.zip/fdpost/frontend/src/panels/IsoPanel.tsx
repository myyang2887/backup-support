/** Isosurface: field + level slider driven by the server-reported range. */
import { useState } from "react";
import { loadShells } from "../actions";
import { getIsoRange, getIsosurface } from "../api";
import { Feature } from "../features";
import { useStore } from "../store";
import NumberSlider from "../ui/NumberSlider";
import { toast } from "../toast";
import { fieldRole } from "../types";

export default function IsoPanel() {
  const { meta, activeId, iso, setIso, set, display, setDisplay,
          shellMeshes } = useStore();
  const [busy, setBusy] = useState(false);
  const [busy2, setBusy2] = useState("");
  const withBusy = async (tag: string, fn: () => Promise<void>) => {
    setBusy2(tag);
    try { await fn(); } catch (e: any) { toast(e.message, "err"); }
    setBusy2("");
  };
  if (!meta?.bounds) return <div className="hint">データセットを読み込んでください</div>;
  const fields = [...meta.fields].sort((a, b) =>
    +(fieldRole(b) === "scalar_field") - +(fieldRole(a) === "scalar_field"));
  const [lo, hi] = iso.range;
  const span = hi - lo || 1;

  const changeField = async (f: string) => {
    try {
      const range = await getIsoRange(activeId!, f);
      setIso({ field: f, range, level: 0.5 * (range[0] + range[1]) });
    } catch (e: any) { toast(e.message, "err"); }
  };

  const compute = async (level = iso.level) => {
    setBusy(true);
    try {
      const mesh = await getIsosurface(activeId!, iso.field, level,
                                       { maxDim: display.isoMaxDim });
      set({ isoMesh: mesh });
      setIso({ visible: true, level });
      toast(`等値面を生成しました(${mesh.faces.length / 3} 面)`);
    } catch (e: any) { toast(e.message, "err"); }
    setBusy(false);
  };

  return (
    <>
    <div className="panel">
      <h3>等値面</h3>
      <div className="row">
        <label>フィールド</label>
        <select value={iso.field} onChange={(e) => changeField(e.target.value)}>
          {fields.map((f) => <option key={f}>{f}</option>)}
        </select>
      </div>
      <div style={{ marginTop: 10 }}>
        <div className="row" style={{ justifyContent: "space-between" }}>
          <label>レベル</label>
          <span className="mono" style={{ fontSize: 11 }}>
            {iso.level.toPrecision(5)} {meta.units?.[iso.field] ?? ""}
          </span>
        </div>
        <input type="range" min={0} max={1000}
               value={Math.round(((iso.level - lo) / span) * 1000)}
               onInput={(e) => setIso({
                 level: lo + (+(e.target as HTMLInputElement).value / 1000) * span })}
               onMouseUp={() => iso.visible && compute()}
               onTouchEnd={() => iso.visible && compute()} />
        <div className="row mono"
             style={{ justifyContent: "space-between", fontSize: 10,
                      color: "var(--text-faint)" }}>
          <span>{lo.toPrecision(3)}</span><span>{hi.toPrecision(3)}</span>
        </div>
      </div>
      <div style={{ marginTop: 8 }}>
        <div className="row" style={{ justifyContent: "space-between" }}>
          <label>不透明度</label>
          <span className="mono" style={{ fontSize: 11 }}>
            {(iso.opacity * 100).toFixed(0)}%</span>
        </div>
        <input type="range" min={10} max={100} value={iso.opacity * 100}
               onInput={(e) => setIso({
                 opacity: +(e.target as HTMLInputElement).value / 100 })} />
      </div>
      <NumberSlider label="抽出解像度" value={display.isoMaxDim}
              min={64} max={512} step={32}
              fmt={(v) => `${v}³ まで`}
              onChange={(v) => setDisplay({ isoMaxDim: v })}
              onCommit={() => { if (iso.visible) compute(); }} />
      <div className="row" style={{ marginTop: 10 }}>
        <button className="primary" onClick={() => compute()} disabled={busy}>
          {busy ? "計算中…" : iso.visible ? "再計算" : "表示"}
        </button>
        {iso.visible && (
          <button onClick={() => setIso({ visible: false })}>非表示</button>
        )}
      </div>
      <div className="hint" style={{ marginTop: 8 }}>
        固体はレンジ外の値で埋めるため、壁際で面が途切れません。
        スライダーを離すと自動で再計算されます。抽出解像度を上げると細かくなり、
        計算に時間がかかります(メッシュのセル数より細かくはなりません)。
      </div>
    </div>

    <Feature id="viewport.shells">
    <div className="panel">
      <h3>サーフェス表現(多重等値面)</h3>
      <div className="hint" style={{ marginBottom: 6 }}>
        等値面を入れ子状に重ねた半透明表示です。外殻で流れの輪郭、
        内側でコアを見ます。点群より全体形状が掴みやすくなります。
      </div>
      <div className="row">
        <button className="primary" disabled={busy2 === "shell"}
                onClick={() => withBusy("shell", async () => {
                  await loadShells();
                  setDisplay({ shellsVisible: true });
                })}>
          {busy2 === "shell" ? "生成中…" : shellMeshes ? "再生成" : "サーフェスを表示"}
        </button>
        {shellMeshes && (
          <button onClick={() => setDisplay({
                    shellsVisible: !display.shellsVisible })}>
            {display.shellsVisible ? "非表示" : "表示"}
          </button>
        )}
      </div>
      <NumberSlider label="層数" value={display.shellCount} min={1} max={5} step={1}
              fmt={(v) => `${v} 層`}
              onChange={(v) => setDisplay({ shellCount: v })}
              onCommit={() => { if (shellMeshes) withBusy("shell", loadShells); }} />
      <NumberSlider label="外殻の不透明度" value={display.shellOpacity}
              min={0.05} max={0.6} step={0.05}
              onChange={(v) => setDisplay({ shellOpacity: v })} />
      <NumberSlider label="平滑化 (ボクセル)" value={display.shellSmooth}
              min={0} max={3} step={0.2}
              fmt={(v) => (v === 0 ? "なし(生データ)" : `σ ${v.toFixed(1)}`)}
              onChange={(v) => setDisplay({ shellSmooth: v })}
              onCommit={() => { if (shellMeshes) withBusy("shell", loadShells); }} />
      <NumberSlider label="抽出解像度" value={display.shellMaxDim}
              min={64} max={512} step={32}
              fmt={(v) => `${v}³ まで`}
              onChange={(v) => setDisplay({ shellMaxDim: v })}
              onCommit={() => { if (shellMeshes) withBusy("shell", loadShells); }} />
      <NumberSlider label="微小片の除去" value={display.shellDespeckle}
              min={0} max={0.2} step={0.01}
              fmt={(v) => (v === 0 ? "なし" : `最大塊の ${(v * 100).toFixed(0)}% 未満を除去`)}
              onChange={(v) => setDisplay({ shellDespeckle: v })}
              onCommit={() => { if (shellMeshes) withBusy("shell", loadShells); }} />
      <div className="hint" style={{ marginTop: 6 }}>
        穴やギザギザが目立つときは平滑化と抽出解像度を上げてください。
        点群を非表示にすると、サーフェスがいちばん綺麗に見えます。
      </div>
    </div>
    </Feature>
    </>
  );
}
