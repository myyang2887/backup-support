/** Slice tool: axis (real-time) / free plane (drag the gizmo or type values),
 *  high-res render, batch export. Results appear in the bottom drawer. */
import { useState } from "react";
import { postAxisBatch, postPlaneBatch, postPlaneSlice } from "../api";
import { Feature } from "../features";
import NumberSlider from "../ui/NumberSlider";
import SliceCsvExport from "./SliceCsvExport";
import { ArrowStepRow, SweepHint, onSliderArrow } from "./SliceStepControls";
import { MIN_STEP_M, useStore } from "../store";
import { toast } from "../toast";
import { currentGeometry, dataBounds, sliceSpecs, sourceLabel } from "../exportSpecs";
import { useSpacingProfile } from "../sliceStep";
import { clearStack, stackDirectionMatches, stackServes, useLoadedStack } from "../stackStore";

export default function SlicePanel() {
  const { meta, previewGrid, activeId, activeField, slice, setSlice,
          batch, setBatch, display, set, addJob, exportSettings: ex,
          commitSlice } = useStore();
  const [busy, setBusy] = useState(false);
  const { profile } = useSpacingProfile();
  const stack = useLoadedStack();
  if (!meta?.bounds) return <div className="hint">データセットを読み込んでください</div>;

  const axisIdx = { x: 0, y: 1, z: 2 }[slice.axis];
  // The cut position is physical (v2.8): a typed 0.120000 m stays 0.120000 m.
  // The data range comes from the source points, not the (smaller) grid.
  const [dLo, dHi] = dataBounds(meta);
  const axisMin = dLo[axisIdx], axisMax = dHi[axisIdx];
  const [lo, hi] = meta.bounds;
  // Sweep bounds come from the data, so the sliders can never leave it.
  // Axis mode sweeps an absolute coordinate; plane mode a signed distance
  // from the centre, whose reach is half the body diagonal.
  const diag = Math.hypot(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]);
  const sweepLo = slice.submode === "axis" ? lo[axisIdx] : -diag / 2;
  const sweepHi = slice.submode === "axis" ? hi[axisIdx] : diag / 2;
  const sweepSpan = sweepHi - sweepLo;
  // Slider granularity, not a limit: the grid pitch is a sensible place for
  // the thumb to land, but it must not stop you typing a finer interval.
  // Batch output samples the SOURCE scatter, which the grid pitch says
  // nothing about.
  const sweepStepUnit = previewGrid
    ? Math.min(...previewGrid.spacing) : sweepSpan / 200;
  // smallest interval worth allowing: 200 planes is the job cap anyway
  const minStep = Math.max(sweepSpan / 1e6, 1e-9);
  const sweepAxisLabel = slice.submode === "axis"
    ? `${slice.axis.toUpperCase()} 軸` : "中心からの符号付き距離";
  // Free-plane distance: the reach of the data along the normal (measured),
  // else half the body diagonal; a typed value outside still widens it.
  const distLo = Math.min(profile && slice.submode === "plane" ? profile.t_min : -diag / 2,
                          slice.distance);
  const distHi = Math.max(profile && slice.submode === "plane" ? profile.t_max : diag / 2,
                          slice.distance);
  const showDrawer = () => {
    const st = useStore.getState();
    if (!st.drawerOpen || st.drawerTab !== "contour") set({ drawerOpen: true, drawerTab: "contour" });
  };

  // 精細可視化 status, one line
  const stackMine = stack && stack.dsId === activeId && stack.meta.field === activeField
    && stackDirectionMatches(stack, slice);
  const stackInUse = stackServes(stack, activeId, activeField, slice);
  const fineStatus = stackMine ? (
    <span style={{ color: stackInUse ? "var(--ok)" : "var(--text-dim)" }}
          title={`${stack!.meta.dims[0]} 枚 × ${stack!.meta.dims[2]} × ${stack!.meta.dims[1]} 点、`
                 + (stack!.meta.method === "idw" ? "IDW" : "局所線形")
                 + (stackInUse ? "" : "\nこの位置はスタックの範囲外です")}>
      {stackInUse ? "● " : "○ "}スタック {stack!.meta.dims[0]} 枚
    </span>
  ) : stack ? <span title="読み込んだ断面スタックは別の向き・変数用です">スタックは別の向き用</span>
    : "動かしている間も精細に表示";
  const nPlanes = Math.floor(
    Math.abs(batch.end - batch.start) / Math.max(batch.step, 1e-12)) + 1;

  const renderPlane = async () => {
    setBusy(true);
    try {
      // the same specs as the formal export, at a screen-sized image
      const sp = sliceSpecs(ex, display);
      const r = await postPlaneSlice(activeId!, {
        ...currentGeometry({ ...slice, submode: "plane" }), field: activeField,
        sampling: sp.sampling, evaluation: sp.evaluation,
        render: { ...sp.render, long_edge_px: 1600, dpi: 150 },
      });
      if (!r.file_url) throw new Error("PNGのURLを取得できませんでした");
      set({ planePng: r.file_url + "?t=" + Date.now(),
            drawerOpen: true, drawerTab: "plane" });
    } catch (e: any) { toast(e.message, "err"); }
    setBusy(false);
  };

  const runBatch = async () => {
    try {
      // data source, sampling and image size: the 断面を出力 settings, so a
      // batch item equals the single export with the same parameters
      const specs = sliceSpecs(ex, display);
      const j = slice.submode === "axis"
        ? await postAxisBatch(activeId!, {
            axis: slice.axis, start: batch.start, stop: batch.end,
            step: batch.step, field: activeField, with_vectors: batch.vectors,
            ...specs })
        : await postPlaneBatch(activeId!, {
            mode: "euler", tilt_deg: slice.tilt, azimuth_deg: slice.azimuth,
            distance: 0, field: activeField, with_vectors: batch.vectors,
            distance_start: batch.start, distance_stop: batch.end,
            distance_step: batch.step, ...specs });
      addJob(j.id);
      toast("バッチ出力を開始しました(ジョブに追加)");
    } catch (e: any) { toast(e.message, "err"); }
  };

  return (
    <>
      <div className="panel">
        <h3>断面の定義</h3>
        <div className="tabs" style={{ marginBottom: 10 }}>
          <button className={slice.submode === "axis" ? "on" : ""}
                  onClick={() => setSlice({ submode: "axis" })}>軸直交</button>
          <button className={slice.submode === "plane" ? "on" : ""}
                  onClick={() => setSlice({ submode: "plane" })}>自由平面</button>
        </div>

        {slice.submode === "axis" && (
          <>
            <div className="row">
              <label>軸</label>
              {(["x", "y", "z"] as const).map((a) => (
                <button key={a} className={slice.axis === a ? "primary" : ""}
                        style={{ padding: "4px 12px" }}
                        onClick={() => setSlice({
                          axis: a, pos: (dLo[{ x: 0, y: 1, z: 2 }[a]]
                                         + dHi[{ x: 0, y: 1, z: 2 }[a]]) / 2 })}>
                  {a.toUpperCase()}</button>
              ))}
            </div>
            <NumberSlider
              label="位置" value={slice.pos} unit="m" decimals={6}
              min={axisMin} max={axisMax} step={MIN_STEP_M}
              onChange={(m) => {
                setSlice({ pos: m });
                set({ drawerOpen: true, drawerTab: "contour" });
              }}
              onTypedCommit={commitSlice}
              onArrow={onSliderArrow} />
            <ArrowStepRow />
            <div className="hint" style={{ marginTop: 6 }}>
              3Dビューの平面をドラッグ / ←→キーでも移動できます。
              矢印をつかむと自由平面に切り替わります。
              平面が邪魔で視点を回せないときは Alt を押しながらドラッグ。
            </div>
          </>
        )}

        {slice.submode === "plane" && (
          <>
            <div className="hint" style={{ marginBottom: 8 }}>
              3Dビュー: 平面のドラッグ = 距離、矢印の先端 = 向き、
              <b>T</b> + 上下ドラッグ = 回転角、<b>A</b> + 左右ドラッグ = 方位角。
            </div>
            <div className="field-grid">
              <label>回転角 [°]</label>
              <input type="number" step="1" value={slice.tilt}
                     onChange={(e) => { setSlice({ tilt: +e.target.value }); showDrawer(); }} />
              <label style={{ gridColumn: "3" }}>方位角 [°]</label>
              <input type="number" step="1" value={slice.azimuth}
                     onChange={(e) => { setSlice({ azimuth: +e.target.value }); showDrawer(); }} />
            </div>
            <NumberSlider
              label="距離" value={slice.distance} unit="m" decimals={6}
              min={distLo} max={distHi} step={MIN_STEP_M}
              onChange={(m) => { setSlice({ distance: m }); showDrawer(); }}
              onTypedCommit={commitSlice}
              onArrow={onSliderArrow} />
            <ArrowStepRow />
            <div className="row" style={{ marginTop: 6 }}>
              <span className="hint" style={{ flex: 1 }}>
                出力設定の PNG を「斜め断面」タブに表示
              </span>
              <button onClick={renderPlane} disabled={busy}
                      title="出力設定のデータとサンプリングで描画し、下の「斜め断面」タブに PNG を表示します">
                {busy ? "計算中…" : "PNG で描画"}
              </button>
            </div>
          </>
        )}
        <div className="row fine-row">
          <span className="hint" style={{ flex: 1 }}>{fineStatus}</span>
          {stackMine && <button className="quiet" onClick={clearStack}
                                title="断面スタックを使わない表示に戻します(保存したデータは残ります)">解除</button>}
          <button onClick={() => set({ fineVizOpen: true, exportDialogOpen: false, gridDialogOpen: false })}
                  title="スライスの向きに沿って断面を前もって計算し、動かしている間も精確に近い断面を表示します">
            精細可視化…
          </button>
        </div>
        <div className="row" style={{ marginTop: 6 }}>
          <span className="hint" style={{ flex: 1 }}>
            出力: {sourceLabel(ex)}、{ex.sampling === "spacing"
              ? `間隔 ${ex.spacingMm} mm` : `長辺 ${ex.sampleLongEdge} 点`}、
            PNG {ex.imagePx} px
          </span>
          <button className="primary" onClick={() => set({ exportDialogOpen: true, fineVizOpen: false, gridDialogOpen: false })}>
            断面を出力…
          </button>
        </div>
      </div>

      <Feature id="slice.csv">
        <SliceCsvExport />
      </Feature>

      <Feature id="slice.batch">
      <div className="panel">
        <h3>バッチ出力(PNG一括)</h3>
        <div className="hint" style={{ marginBottom: 8 }}>
          {sweepAxisLabel}の範囲を掃引して PNG を連続出力します。
          スライダーは常にデータ範囲内に収まります。
        </div>

        <NumberSlider label="開始" value={batch.start} unit="m"
                      min={sweepLo} max={sweepHi} step={minStep} decimals={7}
                      onChange={(v) => setBatch({ start: v })} />
        <NumberSlider label="終了" value={batch.end} unit="m"
                      min={sweepLo} max={sweepHi} step={minStep} decimals={7}
                      onChange={(v) => setBatch({ end: v })} />
        <NumberSlider label="間隔" value={batch.step} unit="m"
                      min={minStep}
                      max={Math.max(sweepStepUnit * 2, sweepSpan / 2)}
                      step={minStep} decimals={7}
                      onChange={(v) => setBatch({
                        step: Math.max(minStep, v) })} />

        <SweepHint start={Math.min(batch.start, batch.end)}
                   end={Math.max(batch.start, batch.end)} step={batch.step} />
        <div className="row" style={{ marginTop: 6 }}>
          <span className="mono" style={{ fontSize: 11,
                color: nPlanes > 200 ? "var(--err)" : "var(--text-dim)" }}>
            {nPlanes} 枚
            {nPlanes > 200 && " — 多すぎます(上限200枚)"}
          </span>
          <label style={{ marginLeft: "auto", display: "flex", gap: 5,
                          alignItems: "center", fontSize: 12 }}>
            <input type="checkbox" checked={batch.preview}
                   onChange={(e) => setBatch({ preview: e.target.checked })} />
            3Dビューに表示
          </label>
        </div>

        <div className="row" style={{ marginTop: 8 }}>
          <label style={{ display: "flex", gap: 5, alignItems: "center" }}>
            <input type="checkbox" checked={batch.vectors}
                   onChange={(e) => setBatch({ vectors: e.target.checked })} />
            ベクトル表示
          </label>
          <button className="quiet" style={{ fontSize: 11 }}
                  onClick={() => set({ exportDialogOpen: true, fineVizOpen: false, gridDialogOpen: false })}
                  title="データ・サンプリング・画像サイズは「断面を出力」の設定を使います">
            {sourceLabel(ex)}、PNG {ex.imagePx} px
          </button>
          <button style={{ marginLeft: "auto" }} className="primary"
                  disabled={nPlanes > 200} onClick={runBatch}>実行</button>
        </div>
        <div className="hint" style={{ marginTop: 6 }}>
          「3Dビューに表示」で開始面・終了面・各ステップ位置が
          ビューポートに黄色い枠として重なります。実行前に確認できます。
          <br />
          固体の塗りつぶしは「表示」ツールの設定に従います。
          データ・サンプリング・画像サイズは「断面を出力」の設定と同じで、
          同じ条件の単独出力と同じ数値になります。色の範囲は全枚数で共通です。
          ZIP には manifest.json(各断面の実際の位置・点数・計算方法)が入ります。
        </div>
      </div>
      </Feature>
    </>
  );
}
