/** Two small pieces of the slice tool that read the data-spacing profile:
 *
 *  ArrowStepRow - one line: how far an arrow key moves the slice.
 *                 自動 = the data's own spacing here (one press = next data
 *                 layer), 固定 = a typed step. Minimum 1 um either way.
 *  SweepHint    - for a batch sweep: a thin strip over [start, end] showing
 *                 where each slice reaches new data and where slices fall
 *                 between data layers (interpolated), plus one line of text.
 *                 Replaces the v2.7/2.8 warning, which compared the interval
 *                 against the *preprocessing grid* pitch and called it the
 *                 data spacing. */
import { sliceT, spacingAt, stepSlice, sweepSegments, useSpacingProfile } from "../sliceStep";
import { MIN_STEP_M, useStore } from "../store";

const mm = (m: number) => {
  const v = Math.abs(m) * 1e3;
  return v >= 10 ? v.toFixed(1) : v >= 1 ? v.toFixed(2) : v.toPrecision(2);
};

export function ArrowStepRow() {
  const { slice, setSlice } = useStore();
  const { profile, loading } = useSpacingProfile();
  const autoStep = profile
    ? Math.max(MIN_STEP_M, spacingAt(profile, sliceT(slice), "p10")) : null;
  return (
    <div className="row step-row"
         title={"矢印キー(3Dビュー、またはスライダー選択中)で動く量。\n"
                + "自動: この位置のデータ間隔(1回 = 次のデータ層)。押し続けると連続で動きます。"}>
      <span className="drawer-label">←→ 刻み</span>
      <span className="seg">
        <button className={slice.arrowMode === "auto" ? "on" : ""}
                onClick={() => setSlice({ arrowMode: "auto" })}>自動</button>
        <button className={slice.arrowMode === "fixed" ? "on" : ""}
                onClick={() => setSlice({ arrowMode: "fixed" })}>固定</button>
      </span>
      {slice.arrowMode === "auto" ? (
        <span className="mono step-val">
          {autoStep != null ? `${mm(autoStep)} mm` : loading ? "測定中…" : "—"}
        </span>
      ) : (
        <span className="row" style={{ gap: 4, flexWrap: "nowrap" }}>
          <input type="number" min={0.001} step={0.001} value={slice.arrowFixedMm}
                 style={{ width: 72 }}
                 onChange={(e) => {
                   const v = +e.target.value;
                   if (Number.isFinite(v)) setSlice({ arrowFixedMm: Math.max(0.001, v) });
                 }} />
          <span className="drawer-label">mm</span>
        </span>
      )}
    </div>
  );
}

export function SweepHint({ start, end, step }: { start: number; end: number; step: number }) {
  const { slice } = useStore();
  const { profile, loading } = useSpacingProfile();
  if (!profile) {
    return loading
      ? <div className="hint" style={{ marginTop: 6 }}>データ間隔を測定中…</div>
      : null;
  }
  if (!(end > start) || !(step > 0)) return null;
  const which = slice.submode === "axis" ? "median" : "p10";
  const { segments, minSp, maxSp } = sweepSegments(profile, start, end, step, which);
  const span = end - start;
  const denseLen = segments.filter((s) => s.dense).reduce((a, s) => a + s.to - s.from, 0);
  const range = minSp === maxSp ? `${mm(minSp)} mm` : `${mm(minSp)}–${mm(maxSp)} mm`;
  let text: React.ReactNode;
  if (denseLen <= span * 0.002) {
    text = <>各断面が新しいデータに届きます。データ間隔 {range}</>;
  } else if (denseLen >= span * 0.998) {
    text = <>間隔がデータ間隔({range})より細かく、断面の間は補間です</>;
  } else {
    text = <>
      <span className="nw"><span className="lg fresh" />新しいデータ</span>
      <span className="nw"><span className="lg dense" />データより細かい(補間)</span>
      <span className="nw" style={{ display: "block" }}>データ間隔 {range}</span>
    </>;
  }
  return (
    <div style={{ marginTop: 8 }}>
      <div className="sweep-strip" aria-hidden>
        {segments.map((s, i) => (
          <span key={i} className={s.dense ? "dense" : "fresh"}
                style={{ left: `${((s.from - start) / span) * 100}%`,
                         width: `${((s.to - s.from) / span) * 100}%` }} />
        ))}
      </div>
      <div className="hint sweep-legend" style={{ marginTop: 4 }}
           title={segments.filter((x) => x.dense)
             .map((x) => `補間: ${x.from.toFixed(4)}–${x.to.toFixed(4)}`).join("\n")}>
        {text}
      </div>
    </div>
  );
}

/** Arrow-key handler for the position slider: the same step as the 3D
 *  view, and -- like dragging the slider -- it brings up the result. */
export const onSliderArrow = (dir: 1 | -1): void => {
  stepSlice(dir);
  const st = useStore.getState();
  if (!st.drawerOpen || st.drawerTab !== "contour") {
    st.set({ drawerOpen: true, drawerTab: "contour" });
  }
};
