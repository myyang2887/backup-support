/** 精細可視化 — build (or reuse) a slice stack for the current slice direction.
 *
 *  Nothing is computed until the user decides: the dialog first shows what
 *  the stack would be (slices x samples, memory on the server and in the
 *  browser) and how long it would take, measured on this data with the
 *  chosen method. Building runs as a job with progress and can be stopped.
 *  Finished stacks are saved on the server and listed for reuse. */
import { useEffect, useState } from "react";
import { dataBounds } from "../exportSpecs";
import { clearStack, loadStack, stackDirectionMatches, useLoadedStack } from "../stackStore";
import { useSpacingProfile } from "../sliceStep";
import { useStore } from "../store";
import { Cancelled, useTask } from "../tasks";
import { toast } from "../toast";
import ProgressLine, { ProgressText } from "../ui/ProgressLine";

interface Estimate {
  key: string; cached: boolean; estimate_s: number; warmup_s: number;
  bytes_server: number; bytes_browser: number;
  plan: { dims: [number, number, number]; n_samples: number; t_range: [number, number];
          data_spacing: { along_mm: [number, number]; u_mm: [number, number];
                          v_mm: [number, number] } };
}
interface Saved {
  key: string; field: string; method: string; mode: string; axis: string | null;
  dims: [number, number, number]; request: any;
}

const MB = (b: number) => (b >= 1e9 ? `${(b / 1e9).toFixed(1)} GB` : `${Math.max(0.1, b / 1e6).toFixed(1)} MB`);
const dur = (s: number) => (s < 1 ? "1 秒未満" : s < 90 ? `約 ${Math.round(s)} 秒`
  : s < 5400 ? `約 ${(s / 60).toFixed(1)} 分` : `約 ${(s / 3600).toFixed(1)} 時間`);
const mmR = ([a, b]: [number, number]) =>
  (a.toPrecision(2) === b.toPrecision(2) ? a.toPrecision(2) : `${a.toPrecision(2)}–${b.toPrecision(2)}`);

function Seg<T extends string | number>({ value, options, onPick }: {
  value: T; options: [T, string][]; onPick: (v: T) => void;
}) {
  return (
    <span className="seg">
      {options.map(([v, label]) => (
        <button key={String(v)} className={v === value ? "on" : ""} onClick={() => onPick(v)}>
          {label}
        </button>
      ))}
    </span>
  );
}

export default function FineVizDialog() {
  const { fineVizOpen, set, slice, meta, activeId, activeField } = useStore();
  const stack = useLoadedStack();
  const { profile } = useSpacingProfile();
  const build = useTask();
  const measure = useTask();
  const [range, setRange] = useState<"all" | "custom">("all");
  const [t0, setT0] = useState(0);
  const [t1, setT1] = useState(0);
  const [along, setAlong] = useState(0.5);
  const [inplane, setInplane] = useState(0.5);
  const [method, setMethod] = useState<"idw" | "local_linear">("local_linear");
  const [est, setEst] = useState<Estimate | null>(null);
  const [estErr, setEstErr] = useState("");
  const [saved, setSaved] = useState<Saved[]>([]);
  const [loading, setLoading] = useState(false);

  const isAxis = slice.submode === "axis";
  const curT = isAxis ? slice.pos : slice.distance;
  const dirLabel = isAxis ? `${slice.axis.toUpperCase()} 軸`
    : `法線(回転角 ${slice.tilt}°、方位角 ${slice.azimuth}°)`;

  // full range of the direction (for the custom-range defaults)
  const full: [number, number] | null = (() => {
    if (!meta?.bounds) return null;
    if (isAxis) {
      const [lo, hi] = dataBounds(meta);
      const a = { x: 0, y: 1, z: 2 }[slice.axis];
      return [lo[a], hi[a]];
    }
    return profile ? [profile.t_min, profile.t_max] : null;
  })();

  useEffect(() => {                                     // custom range: around the cut
    if (!fineVizOpen || !full) return;
    setT0(+Math.max(full[0], curT - 0.005).toFixed(6));
    setT1(+Math.min(full[1], curT + 0.005).toFixed(6));
  }, [fineVizOpen, slice.submode, slice.axis, slice.tilt, slice.azimuth]);

  const request = {
    field: activeField, mode: isAxis ? "axis" : "euler", axis: slice.axis,
    tilt_deg: slice.tilt, azimuth_deg: slice.azimuth,
    t_range: range === "custom" && t1 > t0 ? [t0, t1] : null,
    along, inplane, method,
  };
  const reqKey = JSON.stringify(request);

  const refreshSaved = () => {
    if (!activeId) return;
    fetch(`/api/datasets/${activeId}/stacks`).then((r) => r.json())
      .then((x) => setSaved(Array.isArray(x) ? x : [])).catch(() => setSaved([]));
  };
  useEffect(() => { if (fineVizOpen) refreshSaved(); }, [fineVizOpen, activeId]);

  // measured estimate, re-run when the settings change
  useEffect(() => {
    if (!fineVizOpen || !activeId || build.state.active) return;
    setEst(null); setEstErr("");
    const timer = window.setTimeout(() => {
      measure.track("測定", async (signal) => {
        const r = await fetch(`/api/datasets/${activeId}/stacks/estimate`, {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: reqKey, signal });
        const j = await r.json().catch(() => ({}));
        if (r.status === 413) {
          const m = /=\s*([\d,]+) samples exceeds the limit of ([\d,]+)/.exec(String(j.detail));
          const M = (x: string) => `${(+x.replace(/,/g, "") / 1e6).toFixed(0)} M`;
          throw new Error(m
            ? `点数 ${M(m[1])} 点が上限 ${M(m[2])} 点を超えます。範囲を指定するか、断面の数・面内を粗くしてください。`
            : "点数が上限を超えます。範囲を指定するか、断面の数・面内を粗くしてください。");
        }
        if (!r.ok) throw new Error(j.detail ?? r.statusText);
        setEst(j);
      }).catch((e) => {
        if (!(e instanceof Cancelled) && e?.name !== "AbortError") setEstErr(String(e.message ?? e));
      });
    }, 450);
    return () => { window.clearTimeout(timer); measure.cancel(); };
  }, [fineVizOpen, activeId, reqKey]);

  if (!fineVizOpen || !meta?.bounds) return null;

  const use = async (key: string) => {
    if (!activeId) return;
    setLoading(true);
    try {
      const L = await loadStack(activeId, key);
      toast(`断面スタックを読み込みました(${L.meta.dims[0]} 枚)`);
    } catch (e: any) { toast(`読み込めませんでした: ${e.message}`, "err"); }
    setLoading(false);
  };

  const run = async () => {
    if (!activeId) return;
    try {
      const snap = await build.run("計算中", (signal) =>
        fetch(`/api/datasets/${activeId}/stacks`, {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: reqKey, signal }).then(async (r) => {
            if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail ?? r.statusText);
            return r.json();
          }));
      await use(snap.result.key);
      refreshSaved();
      setEst((e) => (e ? { ...e, cached: true } : e));
    } catch (e: any) {
      if (!(e instanceof Cancelled)) toast(`作成できませんでした: ${e.message}`, "err");
    }
  };

  const del = async (key: string) => {
    if (!activeId) return;
    await fetch(`/api/datasets/${activeId}/stacks/${key}`, { method: "DELETE" });
    if (stack?.meta.key === key) clearStack();
    refreshSaved();
  };

  const active = stack && stack.dsId === activeId && stackDirectionMatches(stack, slice)
    && stack.meta.field === activeField;
  const busy = build.state.active || loading;
  const line = build.state.active ? build.state
    : { active: measure.state.active || loading, label: "", progress: null, etaS: null };

  return (
    <div className="panel dialog-panel" role="dialog" aria-label="精細可視化">
      <ProgressLine task={line} inset={6} />
      <div className="row" style={{ justifyContent: "space-between", marginBottom: 4 }}>
        <h3 style={{ margin: 0 }}>
          精細可視化 <span className="mono dialog-tag">{activeField}</span>
        </h3>
        <button className="quiet" onClick={() => set({ fineVizOpen: false })} title="閉じる">×</button>
      </div>
      <div className="hint" style={{ marginBottom: 10 }}>
        {dirLabel}に沿って断面を前もって計算しておき(断面スタック)、
        動かしている間も精確に近い断面を表示します。
        止めた位置では今までどおり精確計算します。
      </div>

      <div className="field-grid" style={{ gridTemplateColumns: "64px 1fr", rowGap: 8 }}>
        <label>範囲</label>
        <span className="row" style={{ gap: 6, flexWrap: "nowrap" }}>
          <Seg<"all" | "custom"> value={range} options={[["all", "全体"], ["custom", "指定"]]} onPick={setRange} />
          {range === "custom" && (
            <span className="row range-inputs">
              <input type="number" step={0.001} value={t0}
                     onChange={(e) => setT0(+e.target.value)} />
              <span className="drawer-label">–</span>
              <input type="number" step={0.001} value={t1}
                     onChange={(e) => setT1(+e.target.value)} />
              <span className="drawer-label">m</span>
            </span>
          )}
        </span>
        <label>断面の数</label>
        <Seg<number> value={along} onPick={setAlong}
             options={[[1, "データ層ごと"], [0.5, "層の間も"], [0.25, "さらに細かく"]]} />
        <label>面内</label>
        <Seg<number> value={inplane} onPick={setInplane}
             options={[[1, "データ間隔"], [0.5, "1/2 間隔"], [0.25, "1/4 間隔"]]} />
        <label>計算方法</label>
        <Seg<"idw" | "local_linear"> value={method} onPick={setMethod}
             options={[["idw", "IDW(速い)"], ["local_linear", "局所線形(精確)"]]} />
      </div>

      <div className="estimate-box">
        {est ? (
          <>
            <div>
              <span className="mono">{est.plan.dims[0]}</span> 枚 ×{" "}
              <span className="mono">{est.plan.dims[2]} × {est.plan.dims[1]}</span> 点
              <span className="hint">({(est.plan.n_samples / 1e6).toFixed(1)} M 点)</span>
            </div>
            <div className="hint">
              {`データ間隔: 断面方向 ${mmR(est.plan.data_spacing.along_mm)} mm、`
               + `面内 ${mmR(est.plan.data_spacing.u_mm)} × ${mmR(est.plan.data_spacing.v_mm)} mm`}
            </div>
            <div>メモリ: サーバー <span className="mono">{MB(est.bytes_server)}</span>
              {" · "}ブラウザー <span className="mono">{MB(est.bytes_browser)}</span></div>
            <div>
              {est.cached
                ? <span style={{ color: "var(--ok)" }}>保存済み — すぐ読み込めます</span>
                : <>予想時間: <span className="mono">{dur(est.estimate_s)}</span>
                    <span className="hint">(このデータで実測)</span></>}
            </div>
          </>
        ) : (
          <span className={estErr ? "" : "hint"}
                style={estErr ? { color: "var(--err)" } : undefined}>
            {estErr || "見積もり中…"}
          </span>
        )}
      </div>

      <div className="row" style={{ marginTop: 10, justifyContent: "flex-end", gap: 8 }}>
        {build.state.active ? (
          <>
            <ProgressText task={build.state} style={{ marginRight: "auto" }} />
            <button onClick={build.cancel}>中止</button>
          </>
        ) : (
          <>
            {active && (
              <span className="hint" style={{ marginRight: "auto", color: "var(--ok)" }}>
                使用中: {stack!.meta.dims[0]} 枚
              </span>
            )}
            {active && <button onClick={clearStack}>解除</button>}
            {active && est && stack!.meta.key === est.key ? (
              <button className="primary" onClick={() => set({ fineVizOpen: false })}>閉じる</button>
            ) : (
              <button className="primary" disabled={!est || busy}
                      onClick={() => (est?.cached ? use(est.key) : run())}>
                {est?.cached ? "読み込む" : "計算する"}
              </button>
            )}
          </>
        )}
      </div>

      {saved.length > 0 && (
        <details className="saved-list">
          <summary>保存済みの断面スタック({saved.length})</summary>
          {saved.map((s) => (
            <div key={s.key} className="row saved-row">
              <span className="mono">
                {s.mode === "axis" ? `${(s.axis ?? "").toUpperCase()} 軸`
                  : `面 ${s.request.tilt_deg}°/${s.request.azimuth_deg}°`}
              </span>
              <span>{s.field}</span>
              <span className="hint">{s.dims[0]} 枚 · {s.method === "idw" ? "IDW" : "局所線形"}</span>
              <span style={{ marginLeft: "auto" }} />
              <button className="quiet" disabled={busy} onClick={() => use(s.key)}>使う</button>
              <button className="quiet" title="削除" onClick={() => del(s.key)}>×</button>
            </div>
          ))}
        </details>
      )}
    </div>
  );
}
