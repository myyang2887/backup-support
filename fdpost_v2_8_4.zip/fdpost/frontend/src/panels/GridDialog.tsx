/** メッシュの精度 — the preprocessing grids of the active dataset.
 *
 *  A dataset can keep several grids: full-domain grids of different cell
 *  sizes (one is in use) and finer region grids laid over it. New grids are
 *  measured first (cells, memory, time on this data), then built as a job
 *  with progress that can be stopped. Nothing here touches the exact
 *  (original-data) slice computation. */
import { useEffect, useState } from "react";
import { deleteGrid, estimateGrid, listGrids, setActiveGrids, startGridBuild } from "../api";
import { refreshDatasets, reloadGridData } from "../actions";
import { dataBounds } from "../exportSpecs";
import { useStore } from "../store";
import { Cancelled, useTask } from "../tasks";
import { toast } from "../toast";
import type { GridEstimate, GridList } from "../types";
import ProgressLine, { ProgressText } from "../ui/ProgressLine";

const GB = (b: number) => (b >= 1e9 ? `${(b / 1e9).toFixed(1)} GB`
  : b >= 1e6 ? `${(b / 1e6).toFixed(0)} MB` : `${Math.max(1, b / 1e3).toFixed(0)} KB`);
const mm = (m: number) => {
  const v = m * 1e3;
  return v >= 10 ? v.toFixed(1) : v >= 1 ? v.toFixed(2) : v.toPrecision(2);
};
const spText = (sp: number[]) =>
  sp.every((v) => Math.abs(v - sp[0]) < 1e-12) ? `${mm(sp[0])} mm` : `${sp.map(mm).join(" × ")} mm`;
const dur = (s: number) => (s < 1 ? "1 秒未満" : s < 90 ? `約 ${Math.round(s)} 秒`
  : s < 5400 ? `約 ${(s / 60).toFixed(1)} 分` : `約 ${(s / 3600).toFixed(1)} 時間`);
const cellsText = (n: number) => (n >= 1e8 ? `${(n / 1e8).toFixed(1)} 億`
  : n >= 1e4 ? `${Math.round(n / 1e4).toLocaleString()} 万` : `${n}`);

function Seg<T extends string>({ value, options, onPick }: {
  value: T; options: [T, string][]; onPick: (v: T) => void;
}) {
  return (
    <span className="seg">
      {options.map(([v, label]) => (
        <button key={v} className={v === value ? "on" : ""} onClick={() => onPick(v)}>{label}</button>
      ))}
    </span>
  );
}

type Prof = { lo: number; hi: number } | null;

export default function GridDialog() {
  const { gridDialogOpen, set, meta, activeId, slice } = useStore();
  const [list, setList] = useState<GridList | null>(null);
  const [kind, setKind] = useState<"full" | "region">("full");
  const [mode, setMode] = useState<"iso" | "axis">("axis");
  const [sp1, setSp1] = useState(1);
  const [spx, setSpx] = useState(1);
  const [spy, setSpy] = useState(1);
  const [spz, setSpz] = useState(1);
  const [box, setBox] = useState<number[]>([0, 0, 0, 1, 1, 1]);
  const [method, setMethod] = useState("idw");
  const [activate, setActivate] = useState(true);
  const [est, setEst] = useState<GridEstimate | null>(null);
  const [estErr, setEstErr] = useState("");
  const [dataSp, setDataSp] = useState<Prof[]>([null, null, null]);
  const [armed, setArmed] = useState("");
  const [rev, setRev] = useState(0);          // bumps when the grid list changes
  const build = useTask();
  const measure = useTask();

  const refresh = async () => {
    if (!activeId) return;
    try { setList(await listGrids(activeId)); } catch { setList(null); }
    setRev((r) => r + 1);                     // "作成済み" in the estimate may have changed
  };

  // defaults when opened: half the cell size in use, the whole data box
  useEffect(() => {
    if (!gridDialogOpen || !meta?.bounds || !activeId) return;
    refresh();
    const s = meta.spacing ?? [0.002, 0.002, 0.002];
    const half = (v: number) => +(v * 1e3 / 2).toPrecision(3);
    setSpx(half(s[0])); setSpy(half(s[1])); setSpz(half(s[2]));
    setSp1(half(Math.min(...s)));
    const [lo, hi] = dataBounds(meta);
    setBox([...lo, ...hi].map((v) => +v.toFixed(6)));
    setMethod((meta.config?.method as string) || "idw");
    setArmed("");
    // the data's own spacing per axis (reference for choosing a cell size)
    const ax = ["x", "y", "z"];
    Promise.all(ax.map((a) => fetch(`/api/datasets/${activeId}/preview/spacing_profile?axis=${a}`)
      .then((r) => (r.ok ? r.json() : null)).catch(() => null)))
      .then((ps) => setDataSp(ps.map((p) => (p ? { lo: p.spacing_min, hi: p.spacing_max } : null))));
  }, [gridDialogOpen, activeId]);

  const spacing = mode === "iso" ? [sp1, sp1, sp1] : [spx, spy, spz];
  const valid = spacing.every((v) => Number.isFinite(v) && v > 0)
    && (kind === "full" || [0, 1, 2].every((i) => box[i + 3] > box[i]));
  const spec = {
    kind, method, activate,
    spacing_xyz: spacing.map((v) => v / 1e3),
    box: kind === "region" ? [box.slice(0, 3), box.slice(3)] : null,
  };
  const specKey = JSON.stringify(spec);

  useEffect(() => {
    if (!gridDialogOpen || !activeId || build.state.active) return;
    setEst(null); setEstErr("");
    if (!valid) { setEstErr("間隔と範囲を確認してください"); return; }
    const t = window.setTimeout(() => {
      measure.track("測定", (signal) => estimateGrid(activeId, spec, signal))
        .then(setEst)
        .catch((e) => {
          if (!(e instanceof Cancelled) && e?.name !== "AbortError") setEstErr(String(e.message ?? e));
        });
    }, 500);
    return () => { window.clearTimeout(t); measure.cancel(); };
  }, [gridDialogOpen, activeId, specKey, rev, build.state.active]);

  if (!gridDialogOpen || !meta?.bounds || !activeId) return null;

  const afterChange = async (msg: string) => {
    await refresh();
    await reloadGridData();
    refreshDatasets().catch(() => {});
    toast(msg);
  };

  const useBase = async (gid: string) => {
    if (!list) return;
    try {
      await setActiveGrids(activeId, gid, list.details);
      await afterChange("使用する全体メッシュを切り替えました");
    } catch (e: any) { toast(e.message, "err"); }
  };
  const toggleDetail = async (gid: string, on: boolean) => {
    if (!list?.base) return;
    const details = on ? [...list.details, gid] : list.details.filter((d) => d !== gid);
    try {
      await setActiveGrids(activeId, list.base, details);
      await afterChange(on ? "領域のメッシュを重ねました" : "領域のメッシュを外しました");
    } catch (e: any) { toast(e.message, "err"); }
  };
  const remove = async (gid: string) => {
    if (armed !== gid) { setArmed(gid); return; }
    setArmed("");
    try {
      const r = await deleteGrid(activeId, gid);
      await refresh();
      refreshDatasets().catch(() => {});
      toast(`メッシュを削除しました(${GB(r.freed_bytes)} 解放)`);
    } catch (e: any) { toast(e.message, "err"); }
  };
  const run = async () => {
    try {
      const snap = await build.run("メッシュの作成", (signal) => startGridBuild(activeId, spec, signal));
      await refresh();
      if (activate) await reloadGridData();
      refreshDatasets().catch(() => {});
      toast(snap.result?.cached ? "同じメッシュが作成済みでした" : "メッシュを作成しました");
    } catch (e: any) {
      if (!(e instanceof Cancelled)) toast(`作成できませんでした: ${e.message}`, "err");
    }
  };
  const aroundSlice = () => {
    const [lo, hi] = dataBounds(meta);
    const b = [...lo, ...hi];
    if (slice.submode === "axis") {
      const a = { x: 0, y: 1, z: 2 }[slice.axis];
      b[a] = Math.max(lo[a], slice.pos - 0.005);
      b[a + 3] = Math.min(hi[a], slice.pos + 0.005);
    }
    setBox(b.map((v) => +v.toFixed(6)));
  };

  const fulls = list?.grids.filter((g) => g.kind === "full") ?? [];
  const regions = list?.grids.filter((g) => g.kind === "region") ?? [];
  const over = est && !est.within_budget;
  const line = build.state.active ? build.state
    : { active: measure.state.active, label: "", progress: null, etaS: null };
  const setB = (i: number, v: number) => setBox(box.map((x, j) => (j === i ? v : x)));

  return (
    <div className="panel dialog-panel" role="dialog" aria-label="メッシュの精度" style={{ width: 420 }}>
      <ProgressLine task={line} inset={6} />
      <div className="row" style={{ justifyContent: "space-between", marginBottom: 4 }}>
        <h3 style={{ margin: 0 }}>メッシュの精度</h3>
        <button className="quiet" onClick={() => set({ gridDialogOpen: false })} title="閉じる">×</button>
      </div>
      <div className="hint" style={{ marginBottom: 8 }}>
        読み込んだ点群から作る等間隔のメッシュです(FloEFD の計算メッシュとは別のものです)。3D 表示・即時の断面・ライン・流線・等値面・領域の出力に使います。
        断面の精確計算と出力は元データから計算するため、ここの設定は関係しません。
      </div>

      <div className="grid-list">
        <div className="grid-group">全体のメッシュ(1 つを使用)</div>
        {fulls.map((g) => (
          <label key={g.id} className="grid-row">
            <input type="radio" name="base" checked={!!g.base} disabled={build.state.active}
                   onChange={() => useBase(g.id)} />
            <span className="grid-name">{g.label}</span>
            <span className="mono grid-meta">{g.dims.join("×")} · {g.bytes_resident ? GB(g.bytes_resident) : "—"}</span>
            <button className="quiet" disabled={!!g.base}
                    title={g.base ? "使用中は削除できません" : "削除(もう一度押すと削除)"}
                    style={{ color: armed === g.id ? "var(--err)" : undefined }}
                    onClick={(e) => { e.preventDefault(); remove(g.id); }}>
              {armed === g.id ? "削除?" : "×"}
            </button>
          </label>
        ))}
        {regions.length > 0 && <div className="grid-group">領域のメッシュ(チェックしたものを重ねて使用)</div>}
        {regions.map((g) => (
          <label key={g.id} className="grid-row">
            <input type="checkbox" checked={!!g.detail} disabled={build.state.active}
                   onChange={(e) => toggleDetail(g.id, e.target.checked)} />
            <span className="grid-name" title={g.box.map((p) => p.map((v) => v.toFixed(4)).join(", ")).join(" – ")}>
              {g.label}
            </span>
            <span className="mono grid-meta">{g.dims.join("×")} · {g.bytes_resident ? GB(g.bytes_resident) : "—"}</span>
            <button className="quiet" title="削除(もう一度押すと削除)"
                    style={{ color: armed === g.id ? "var(--err)" : undefined }}
                    onClick={(e) => { e.preventDefault(); remove(g.id); }}>
              {armed === g.id ? "削除?" : "×"}
            </button>
          </label>
        ))}
      </div>

      <div className="grid-group" style={{ marginTop: 12 }}>新しいメッシュを作る</div>
      <div className="field-grid" style={{ gridTemplateColumns: "64px 1fr", rowGap: 8 }}>
        <label>範囲</label>
        <span className="row" style={{ gap: 6 }}>
          <Seg<"full" | "region"> value={kind} onPick={setKind} options={[["full", "全体"], ["region", "領域"]]} />
          {kind === "region" && slice.submode === "axis" && (
            <button className="quiet" style={{ fontSize: 11 }} onClick={aroundSlice}
                    title={`${slice.axis.toUpperCase()} = ${slice.pos.toFixed(4)} m の前後 5 mm`}>
              断面の周り
            </button>
          )}
        </span>
        {kind === "region" && (
          <>
            <span />
            <span className="box-inputs">
              {["X", "Y", "Z"].map((a, i) => (
                <span key={a} className="row range-inputs">
                  <span className="drawer-label" style={{ width: 12 }}>{a}</span>
                  <input type="number" step={0.001} value={box[i]}
                         onChange={(e) => setB(i, +e.target.value)} />
                  <span className="drawer-label">–</span>
                  <input type="number" step={0.001} value={box[i + 3]}
                         onChange={(e) => setB(i + 3, +e.target.value)} />
                  <span className="drawer-label">m</span>
                </span>
              ))}
            </span>
          </>
        )}
        <label>間隔</label>
        <span className="row" style={{ gap: 6 }}>
          <Seg<"iso" | "axis"> value={mode} onPick={setMode} options={[["axis", "方向ごと"], ["iso", "全方向同じ"]]} />
        </span>
        <span />
        {mode === "iso" ? (
          <span className="row range-inputs">
            <input type="number" min={0.001} step={0.01} value={sp1}
                   onChange={(e) => setSp1(+e.target.value)} />
            <span className="drawer-label">mm</span>
          </span>
        ) : (
          <span className="row range-inputs" style={{ flexWrap: "wrap" }}>
            {([["X", spx, setSpx], ["Y", spy, setSpy], ["Z", spz, setSpz]] as const).map(([a, v, f]) => (
              <span key={a} className="row" style={{ gap: 3, flexWrap: "nowrap" }}>
                <span className="drawer-label">{a}</span>
                <input type="number" min={0.001} step={0.01} value={v} style={{ width: 66 }}
                       onChange={(e) => (f as (x: number) => void)(+e.target.value)} />
              </span>
            ))}
            <span className="drawer-label">mm</span>
          </span>
        )}
        <span />
        <span className="hint" style={{ marginTop: -4 }}>
          {"データ点の間隔: "}
          {["X", "Y", "Z"].map((a, i) => {
            const p = dataSp[i];
            const t = !p ? "…" : Math.abs(p.hi - p.lo) / p.hi < 0.05 ? `${mm(p.lo)}`
              : `${mm(p.lo)}–${mm(p.hi)}`;
            return `${a} ${t}`;
          }).join("、")} mm
        </span>
        <label>補間法</label>
        <select value={method} onChange={(e) => setMethod(e.target.value)} style={{ width: 120 }}>
          {["nearest", "idw", "linear", "rbf"].map((m) => <option key={m}>{m}</option>)}
        </select>
      </div>

      <div className="estimate-box">
        {est ? (
          <>
            <div>
              <span className="mono">{est.dims.join(" × ")}</span> セル
              <span className="hint">({cellsText(est.cells)})、間隔 {spText(est.spacing)}</span>
            </div>
            <div>
              メモリ: メッシュ <span className="mono">{GB(est.bytes_resident)}</span>
              {" · "}作成中の最大 <span className="mono">{GB(est.bytes_peak)}</span>
              <span className="hint">(上限 {GB(est.budget_bytes)})</span>
            </div>
            {est.existing ? (
              <div style={{ color: "var(--ok)" }}>同じ設定のメッシュが作成済みです</div>
            ) : (
              <div>予想時間: <span className="mono">{dur(est.estimate_s.total)}</span>
                <span className="hint">(このデータで実測)</span></div>
            )}
            {over && (
              <div style={{ color: "var(--err)" }}>
                メモリの上限を超えます。間隔を大きくするか、範囲を狭めてください。
              </div>
            )}
          </>
        ) : (
          <span className={estErr ? "" : "hint"} style={estErr ? { color: "var(--err)" } : undefined}>
            {estErr || "見積もり中…"}
          </span>
        )}
      </div>

      <div className="row" style={{ marginTop: 10, justifyContent: "flex-end", gap: 8 }}>
        {build.state.active ? (
          <>
            <ProgressText task={build.state} style={{ marginRight: "auto" }} />
            <button onClick={build.cancel}>中止</button>
          </>
        ) : (
          <>
            <label className="drawer-toggle" style={{ marginRight: "auto" }}>
              <input type="checkbox" checked={activate} onChange={(e) => setActivate(e.target.checked)} />
              作成後に使う
            </label>
            <button className="primary" disabled={!est || !!over || !valid} onClick={run}>
              {est?.existing ? "使う" : "作成する"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
