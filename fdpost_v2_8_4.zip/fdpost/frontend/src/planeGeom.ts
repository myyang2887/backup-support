/** Plane geometry in the browser, mirroring core/plane.py on the server, so
 *  the instant preview of a free plane lands on exactly the same cut (same
 *  normal, same in-plane basis, same extent) as the exact computation. */
import { eulerNormal } from "./sliceStep";
import type { PreviewGrid } from "./types";

export type V3 = [number, number, number];

const dot = (a: V3, b: V3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a: V3, b: V3): V3 =>
  [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a: V3): V3 => { const l = Math.hypot(...a); return [a[0] / l, a[1] / l, a[2] / l]; };

/** Same rule as plane_basis(): stable for any normal, right-handed. */
export function planeBasis(n: V3): [V3, V3] {
  const ref: V3 = Math.abs(n[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0];
  const u = norm(cross(ref, n));
  return [u, cross(n, u)];
}

const EDGES = [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7],
               [0, 4], [1, 5], [2, 6], [3, 7]];

/** (u, v) bounding box of plane ∩ box relative to `o`; null if no cut. */
export function planeBoxExtent(o: V3, n: V3, u: V3, v: V3, lo: number[], hi: number[])
  : [[number, number], [number, number]] | null {
  const c: V3[] = [];
  for (const x of [lo[0], hi[0]]) for (const y of [lo[1], hi[1]]) for (const z of [lo[2], hi[2]]) c.push([x, y, z]);
  const s = c.map((p) => dot([p[0] - o[0], p[1] - o[1], p[2] - o[2]], n));
  const pts: V3[] = [];
  c.forEach((p, i) => { if (Math.abs(s[i]) <= 1e-12) pts.push(p); });
  for (const [i, j] of EDGES) {
    if ((s[i] < 0) !== (s[j] < 0) && s[i] !== s[j]) {
      const t = s[i] / (s[i] - s[j]);
      pts.push([c[i][0] + t * (c[j][0] - c[i][0]), c[i][1] + t * (c[j][1] - c[i][1]),
                c[i][2] + t * (c[j][2] - c[i][2])]);
    }
  }
  if (pts.length < 3) return null;
  const us = pts.map((p) => dot([p[0] - o[0], p[1] - o[1], p[2] - o[2]], u));
  const vs = pts.map((p) => dot([p[0] - o[0], p[1] - o[1], p[2] - o[2]], v));
  return [[Math.min(...us), Math.max(...us)], [Math.min(...vs), Math.max(...vs)]];
}

export interface FreePlane { origin: V3; n: V3; u: V3; v: V3;
                             ext: [[number, number], [number, number]] | null }

/** Euler plane: origin = data centre + n * distance (server convention). */
export function freePlane(tilt: number, azimuth: number, distance: number,
                          lo: number[], hi: number[]): FreePlane {
  const n = eulerNormal(tilt, azimuth) as V3;
  const c: V3 = [(lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2];
  const origin: V3 = [c[0] + n[0] * distance, c[1] + n[1] * distance, c[2] + n[2] * distance];
  const [u, v] = planeBasis(n);
  return { origin, n, u, v, ext: planeBoxExtent(origin, n, u, v, lo, hi) };
}

/** Trilinear sample of the preview grid; where a corner is solid (NaN) the
 *  nearest corner decides, so walls stay sharp. null outside the grid. */
export function sampleGrid(g: PreviewGrid, p: V3): number | null {
  const [nx, ny, nz] = g.dims;
  const f = [0, 1, 2].map((i) => (p[i] - g.origin[i]) / g.spacing[i]);
  if (f[0] < -0.5 || f[1] < -0.5 || f[2] < -0.5
      || f[0] > nx - 0.5 || f[1] > ny - 0.5 || f[2] > nz - 0.5) return null;
  const cl = (x: number, n: number) => Math.min(Math.max(x, 0), n - 1);
  const x = cl(f[0], nx), y = cl(f[1], ny), z = cl(f[2], nz);
  const x0 = Math.min(Math.floor(x), nx - 2 < 0 ? 0 : nx - 2), y0 = Math.min(Math.floor(y), Math.max(ny - 2, 0));
  const z0 = Math.min(Math.floor(z), Math.max(nz - 2, 0));
  const wx = x - x0, wy = y - y0, wz = z - z0;
  const d = g.data;
  const at = (i: number, j: number, k: number) =>
    d[Math.min(i, nx - 1) + nx * (Math.min(j, ny - 1) + ny * Math.min(k, nz - 1))];
  let acc = 0, bad = false;
  for (let c = 0; c < 8; c++) {
    const ix = c & 1, iy = (c >> 1) & 1, iz = (c >> 2) & 1;
    const val = at(x0 + ix, y0 + iy, z0 + iz);
    const w = (ix ? wx : 1 - wx) * (iy ? wy : 1 - wy) * (iz ? wz : 1 - wz);
    if (Number.isNaN(val)) { if (w > 0) bad = true; continue; }
    acc += w * val;
  }
  if (!bad) return acc;
  const v = at(Math.round(x), Math.round(y), Math.round(z));
  return Number.isNaN(v) ? null : v;
}

/** Instant free-plane slice from the preview grid, `n` samples on the long
 *  side of the plane's extent. Coordinates are in-plane offsets (u, v). */
export function previewPlaneSlice(g: PreviewGrid, fp: FreePlane, n = 160)
  : { x: number[]; y: number[]; z: (number | null)[][]; spacing: [number, number] } | null {
  if (!fp.ext) return null;
  const [[u0, u1], [v0, v1]] = fp.ext;
  const h = Math.max(u1 - u0, v1 - v0) / (n - 1);
  const nu = Math.max(2, Math.round((u1 - u0) / h) + 1), nv = Math.max(2, Math.round((v1 - v0) / h) + 1);
  const x = Array.from({ length: nu }, (_, i) => u0 + ((u1 - u0) * i) / (nu - 1));
  const y = Array.from({ length: nv }, (_, j) => v0 + ((v1 - v0) * j) / (nv - 1));
  const z = y.map((vv) => x.map((uu) => sampleGrid(g, [
    fp.origin[0] + uu * fp.u[0] + vv * fp.v[0],
    fp.origin[1] + uu * fp.u[1] + vv * fp.v[1],
    fp.origin[2] + uu * fp.u[2] + vv * fp.v[2]])));
  return { x, y, z, spacing: [x[1] - x[0], y[1] - y[0]] };
}
