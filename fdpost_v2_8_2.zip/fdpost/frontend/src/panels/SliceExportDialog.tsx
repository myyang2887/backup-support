/** 断面を出力 — the formal export, separate from the preview.
 *
 *  The preview may be coarse (it is drawn from the preprocessing grid); the
 *  export is computed fresh at the settings here. Before anything runs the
 *  dialog shows the three facts that decide the result: where the cut is,
 *  how many samples at what spacing (next to the data's own spacing), and
 *  the exact PNG size. After the export it shows what the server actually
 *  did. */
import ProgressLine, { ProgressText } from "../ui/ProgressLine";
import { useEffect, useState } from "react";
import { downloadJobFile, getSliceNative, postSliceEstimate, startExportJob,
         type SliceNativeOut } from "../api";
import { Cancelled, useTask } from "../tasks";
import {
  axisExtent, currentGeometry, describeSummary, DPI_CHOICES, estimateLattice,
  type EstimateOut, type ExportSummary, fmtSeconds, IMAGE_CHOICES, inRange,
  matchPreset, PRESETS, SAMPLE_CHOICES, sliceSpecs,
} from "../exportSpecs";
import { axisIndex, useStore } from "../store";
import { toast } from "../toast";

const mm = (m: number | null | undefined, d = 3) =>
  m == null ? "—" : (m * 1e3).toPrecision(d);

function Choice<T extends string | number>({ value, options, label, onPick }: {
  value: T; options: T[]; label?: (v: T) => string; onPick: (v: T) => void;
}) {
  return (
    <span className="row" style={{ gap: 2, flexWrap: "nowrap" }}>
      {options.map((o) => (
        <button key={String(o)} className={o === value ? "primary" : ""}
                style={{ padding: "2px 8px", fontSize: 11 }}
                onClick={() => onPick(o)}>
          {label ? label(o) : String(o)}
        </button>
      ))}
    </span>
  );
}

export default function SliceExportDialog() {
  const { exportDialogOpen, exportSettings: ex, setExportSettings, slice, meta,
          activeId, activeField, display, previewGrid, set } = useStore();
  const [native, setNative] = useState<SliceNativeOut | null>(null);
  const task = useTask();
  const busy = task.state.active;
  const [last, setLast] = useState<ExportSummary | null>(null);
  const [est, setEst] = useState<EstimateOut | null>(null);
  const [estBusy, setEstBusy] = useState(false);
  const [estErr, setEstErr] = useState("");

  const axisMode = slice.submode === "axis";
  useEffect(() => {
    setNative(null);
    if (!exportDialogOpen || !activeId || !axisMode || !meta?.bounds) return;
    if (!inRange(meta, slice)) return;
    let live = true;
    getSliceNative(activeId, activeField, slice.axis, slice.pos)
      .then((r) => { if (live) setNative(r); }).catch(() => {});
    return () => { live = false; };
  }, [exportDialogOpen, activeId, activeField, axisMode, slice.axis, slice.pos]);

  // Measured time estimate: re-run (debounced) whenever anything that
  // changes the cost changes. Also warms the server caches.
  useEffect(() => {
    if (!exportDialogOpen || !activeId || !meta?.bounds || !inRange(meta, slice)) {
      setEst(null); return;
    }
    let live = true;
    setEstBusy(true);
    const timer = window.setTimeout(async () => {
      try {
        const formats = ["png", ...(ex.csv ? ["csv"] : [])];
        const r = await postSliceEstimate(activeId, {
          ...currentGeometry(slice), field: activeField, formats,
          ...sliceSpecs(ex, display) });
        if (live) { setEst(r as EstimateOut); setEstErr(""); }
      } catch (e: any) {
        if (live) { setEst(null); setEstErr(String(e.message ?? e)); }
      }
      if (live) setEstBusy(false);
    }, 450);
    return () => { live = false; window.clearTimeout(timer); };
  }, [exportDialogOpen, activeId, activeField, slice.submode, slice.axis, slice.pos,
      slice.tilt, slice.azimuth, slice.distance, ex.source, ex.method, ex.sampling,
      ex.sampleLongEdge, ex.spacingMm, ex.imagePx, ex.dpi, ex.csv]);

  if (!exportDialogOpen || !meta?.bounds) return null;
  const preset = matchPreset(ex);

  const ext = axisExtent(meta, slice);
  const lat = ext ? estimateLattice(ex, ext) : null;
  const tooMany = lat ? lat.nu * lat.nv > 4_194_304 : false;
  const okPos = inRange(meta, slice);
  const ai = { x: 0, y: 1, z: 2 }[slice.axis];
  const drawnPos = previewGrid && axisMode
    ? previewGrid.origin[ai] + previewGrid.spacing[ai] * axisIndex(previewGrid, slice.axis, slice.pos)
    : null;
  const snappedPreview = drawnPos != null && Math.abs(drawnPos - slice.pos) > 1e-12;
  const finer = native && lat && native.spacing_u_m && native.spacing_v_m
    && (lat.du < native.spacing_u_m * 0.95 || lat.dv < native.spacing_v_m * 0.95);

  // A job with real progress (計算 → 描画 → 書き出し) that can be stopped;
  // the finished file is downloaded once and then removed on the server.
  const run = async () => {
    if (!activeId) return;
    setLast(null);
    try {
      const formats = ["png", "json", ...(ex.csv ? ["csv"] : [])];
      const req = { ...currentGeometry(slice), field: activeField,
                    with_vectors: false, formats, ...sliceSpecs(ex, display) };
      const snap = await task.run("出力", (signal) => startExportJob(activeId, req, signal));
      const { name, summary } = await downloadJobFile(snap.id, snap.result?.file_name ?? "slice.zip");
      setLast(summary ?? (snap.result?.summary ? JSON.parse(snap.result.summary) : null));
      toast(`出力しました: ${name}`);
    } catch (e: any) {
      if (!(e instanceof Cancelled)) toast(`出力できませんでした: ${e.message}`, "err");
    }
  };

  const posText = axisMode
    ? `${slice.axis.toUpperCase()} = ${slice.pos.toFixed(6)} m`
    : `回転角 ${slice.tilt}°、方位角 ${slice.azimuth}°、中心からの距離 ${slice.distance} m`;

  return (
    <div className="panel dialog-panel" role="dialog" aria-label="断面を出力">
      <ProgressLine task={busy ? task.state
                          : { active: estBusy, label: "測定", progress: null, etaS: null }}
                    inset={6} />
      <div className="row" style={{ justifyContent: "space-between", marginBottom: 6 }}>
        <h3 style={{ margin: 0 }}>断面を出力</h3>
        <button className="quiet" onClick={() => set({ exportDialogOpen: false })}
                title="閉じる">×</button>
      </div>

      <div className="mono" style={{ fontSize: 12, marginBottom: 4 }}>{posText}</div>
      {!okPos && (
        <div className="hint" style={{ color: "var(--err)" }}>
          この位置はデータの範囲外です。位置を範囲内に戻してください。
        </div>
      )}
      {snappedPreview && (
        <div className="hint">
          プレビューは格子面 {drawnPos!.toFixed(6)} m を表示しています。
          出力は指定した位置そのもので計算します。
        </div>
      )}

      <div style={{ marginTop: 10 }}>
        <div className="row" style={{ gap: 2, flexWrap: "nowrap" }}>
          {PRESETS.map((p) => (
            <button key={p.id} className={preset === p.id ? "primary" : ""}
                    style={{ flex: 1, padding: "4px 0", fontSize: 12 }}
                    title={p.hint} onClick={() => setExportSettings(p.s)}>
              {p.label}
            </button>
          ))}
          <span style={{ flex: 1, textAlign: "center", fontSize: 12, padding: "4px 0",
                         color: preset === "custom" ? "var(--accent)" : "var(--text-faint)" }}>
            カスタム
          </span>
        </div>
        <div className="hint" style={{ marginTop: 4, minHeight: 16 }}>
          {preset === "custom"
            ? "下の項目を自由に組み合わせています"
            : PRESETS.find((p) => p.id === preset)!.hint}
        </div>
      </div>

      <div className="field-grid" style={{ gridTemplateColumns: "84px 1fr",
                                           rowGap: 8, marginTop: 8 }}>
        <label>データ</label>
        <Choice value={ex.source === "grid" ? "grid" : ex.method}
                options={["grid", "idw", "local_linear", "local_linear_hq"] as string[]}
                label={(v) => v === "local_linear" ? "局所線形"
                  : v === "idw" ? "IDW" : v === "local_linear_hq" ? "最高精度" : "格子"}
                onPick={(v) => setExportSettings(v === "grid"
                  ? { source: "grid" }
                  : { source: "original", method: v as any })} />

        <label>サンプリング</label>
        <span className="row" style={{ gap: 6 }}>
          <Choice value={ex.sampling} options={["long_edge", "spacing"] as const as any}
                  label={(v) => v === "long_edge" ? "長辺の点数" : "間隔"}
                  onPick={(v) => setExportSettings({ sampling: v as any })} />
          {ex.sampling === "long_edge"
            ? <Choice value={ex.sampleLongEdge} options={SAMPLE_CHOICES}
                      onPick={(v) => setExportSettings({ sampleLongEdge: v })} />
            : <span className="row" style={{ gap: 4 }}>
                <input type="number" min={0.001} step={0.01} value={ex.spacingMm}
                       style={{ width: 70 }}
                       onChange={(e) => setExportSettings({
                         spacingMm: Math.max(0.001, +e.target.value || 0.1) })} />
                <span className="hint">mm</span>
              </span>}
        </span>

        <label>画像</label>
        <span className="row" style={{ gap: 6 }}>
          <Choice value={ex.imagePx} options={IMAGE_CHOICES}
                  label={(v) => `${v} px`}
                  onPick={(v) => setExportSettings({ imagePx: v })} />
          <Choice value={ex.dpi} options={DPI_CHOICES} label={(v) => `${v} dpi`}
                  onPick={(v) => setExportSettings({ dpi: v })} />
        </span>

        <label>内容</label>
        <span className="row" style={{ gap: 10, fontSize: 12 }}>
          <label style={{ display: "flex", gap: 4, alignItems: "center" }}>
            <input type="checkbox" checked={ex.csv}
                   onChange={(e) => setExportSettings({ csv: e.target.checked })} />
            CSV も出力
          </label>
          <label style={{ display: "flex", gap: 4, alignItems: "center" }}>
            <input type="checkbox" checked={ex.showAxes}
                   onChange={(e) => setExportSettings({ showAxes: e.target.checked })} />
            軸と色バー
          </label>
          <label style={{ display: "flex", gap: 4, alignItems: "center" }}>
            <input type="checkbox" checked={ex.transparent}
                   onChange={(e) => setExportSettings({ transparent: e.target.checked })} />
            背景を透明
          </label>
        </span>
      </div>

      <div className="estimate-box">
        <div>
          サンプル:{" "}
          {lat ? <span className="mono">
                   {lat.nu} × {lat.nv} 点、間隔 {mm(lat.du)} × {mm(lat.dv)} mm
                 </span>
               : <span className="hint">斜め断面は平面とデータ範囲の交わりから決まります
                   (出力後に実際の値を表示)</span>}
          {tooMany && <span style={{ color: "var(--err)" }}> — 上限を超えます</span>}
        </div>
        {native && (
          <div>
            データ点の面内間隔: <span className="mono">
              約 {mm(native.spacing_u_m)} × {mm(native.spacing_v_m)} mm</span>
            {finer && <div className="hint">
              サンプル間隔の方が細かい部分は補間値です(データ以上の情報は増えません)。
            </div>}
          </div>
        )}
        <div>
          PNG: <span className="mono">長辺 {ex.imagePx} px</span>
          <span className="hint">({ex.dpi} dpi で {(ex.imagePx / ex.dpi * 25.4).toFixed(0)} mm)</span>
        </div>
        <div style={{ marginTop: 2 }}>
          予想時間:{" "}
          {estBusy ? <span className="hint">測定中…</span>
            : est ? <span className="mono" title={
                      `計算 ${est.estimate_s.compute} 秒(このデータ・この断面で実測した`
                      + `1点あたりの時間から算出)、描画 ${est.estimate_s.render} 秒`
                      + `、CSV ${est.estimate_s.csv} 秒(描画とCSVは目安)`}>
                      {fmtSeconds(est.estimate_s.total)}
                      <span className="hint">
                        (計算 {fmtSeconds(est.estimate_s.compute)})</span>
                    </span>
            : <span className="hint">{estErr || "—"}</span>}
          {est && est.warmup_s > 1 && (
            <div className="hint">
              データの読み込み {est.warmup_s.toFixed(0)} 秒は今の測定で済みました
              (出力時には再度かかりません)。
            </div>
          )}
        </div>
      </div>

      {last && (
        <div className="hint" style={{ marginTop: 8, color: "var(--ok)" }}>
          実際の出力: {describeSummary(last)}
          {last.position_m != null && `、位置 ${last.position_m.toFixed(6)} m`}
        </div>
      )}

      <div className="row" style={{ marginTop: 10, justifyContent: "flex-end" }}>
        {busy ? (
          <>
            <ProgressText task={task.state} style={{ marginRight: "auto" }} />
            <button onClick={task.cancel}>中止</button>
          </>
        ) : (
          <>
            <span className="hint" style={{ marginRight: "auto" }}>
              ZIP に PNG{ex.csv ? "・CSV" : ""}・manifest.json が入ります
            </span>
            <button className="primary" disabled={!okPos || tooMany} onClick={run}>出力</button>
          </>
        )}
      </div>
    </div>
  );
}
