import { create } from "zustand";
import type {
  DatasetOut, IsoMesh, PointCloud, PreviewGrid, PreviewMetaOut, StreamData,
  Tool, VectorField, VizMode,
} from "./types";

/** Shipped display defaults — also the target of「初期値に戻す」. */
export const DISPLAY_DEFAULTS: DisplayParams = {
  pointsVisible: true, pointStyle: "round", pointSize: 1, pointOpacity: 0.95,
  filterEnabled: false, filterMin: 0, filterMax: 1,
  arrowsVisible: false, arrowDensity: 22, arrowScale: 1,
  arrowMinFrac: 0.35, arrowMaxFrac: 1.15,
  shellsVisible: false, shellCount: 3, shellOpacity: 0.22,
  shellSmooth: 1.0, shellMaxDim: 192, shellDespeckle: 0.02,
  sliceExact: "standard", sliceSmooth: true,
  solidVisible: false, solidOpacity: 0.28, solidSize: 1,
  solid2d: true, solidColor: "#000000",
};

export interface SliceParams {
  submode: "axis" | "plane";
  axis: "x" | "y" | "z";
  /** Axis cut position in metres — the state of record (v2.8). The preview
   *  grid can only *draw* its own planes; the nearest one is derived for
   *  display (see axisIndex) and never written back here. */
  pos: number;
  tilt: number; azimuth: number; distance: number;
  /** Arrow-key step: "auto" = the data's own spacing at the current
   *  position (one key press = one data layer), "fixed" = arrowFixedMm. */
  arrowMode: "auto" | "fixed";
  arrowFixedMm: number;
}
/** Smallest step anywhere in the slice UI: 1 um. */
export const MIN_STEP_M = 1e-6;

/** Formal export settings (断面出力). Independent of the preview: the
 *  preview resolution never decides what gets exported. */
export interface ExportSettings {
  /** original = evaluate the source points at the exact sample positions;
   *  grid = read the preprocessed grid (fast, grid-limited). */
  source: "original" | "grid";
  /** local_linear_hq: most accurate on layered data, ~10x slower there */
  method: "local_linear" | "idw" | "local_linear_hq";
  sampling: "long_edge" | "spacing";
  sampleLongEdge: number;     // samples along the longer in-plane side
  spacingMm: number;          // physical step when sampling === "spacing"
  imagePx: number;            // PNG long edge, exact
  dpi: number;                // print-size label for the PNG
  csv: boolean;
  showAxes: boolean;
  transparent: boolean;
}
export const EXPORT_DEFAULTS: ExportSettings = {
  source: "original", method: "local_linear", sampling: "long_edge",
  sampleLongEdge: 1024, spacingMm: 0.1, imagePx: 3000, dpi: 300,
  csv: true, showAxes: true, transparent: false,
};

/** Nearest preview-grid plane for a physical position (display only). */
export function axisIndex(g: { origin: number[]; spacing: number[]; dims: number[] },
                          axis: "x" | "y" | "z", pos: number): number {
  const a = { x: 0, y: 1, z: 2 }[axis];
  return Math.max(0, Math.min(g.dims[a] - 1,
    Math.round((pos - g.origin[a]) / (g.spacing[a] || 1))));
}
export interface ProbeParams { p0: [number, number, number]; p1: [number, number, number]; }
export interface RegionParams {
  min: [number, number, number]; max: [number, number, number];
  /** Sampling resolution: point counts per axis, or physical steps per axis. */
  sampling: "count" | "step";
  res: [number, number, number];
  step: [number, number, number];
}

/** Batch sweep parameters, in the store so the 3D preview can draw them. */
export interface BatchParams {
  start: number; end: number; step: number;
  vectors: boolean;
  preview: boolean;          // show the sweep planes in the 3D view
  // data source / sampling / image size come from ExportSettings (v2.8)
}

/** In-plane CSV export settings for the slice tool (要件書 3項). */
export interface SliceExportParams {
  sampling: "count" | "step";
  res: [number, number];
  step: [number, number];
}

/** How the 3D viewport draws the field. Purely visual — nothing here
 *  changes exported data. */
export interface DisplayParams {
  // point cloud
  pointsVisible: boolean;
  pointStyle: "round" | "square";
  pointSize: number;                 // multiplier on the auto size
  pointOpacity: number;
  // value filter: hides voxels outside [min,max] of the active field
  filterEnabled: boolean;
  filterMin: number; filterMax: number;
  // velocity glyphs
  arrowsVisible: boolean;
  arrowDensity: number;              // lattice max_dim on the server
  arrowScale: number;                // multiplier on the auto length
  arrowMinFrac: number;              // clamps, as a fraction of lattice pitch
  arrowMaxFrac: number;
  // layered translucent isosurfaces ("industrial" surface look)
  shellsVisible: boolean;
  shellCount: number;                // 1..5 nested levels
  shellOpacity: number;              // opacity of the outermost shell
  shellSmooth: number;               // gaussian sigma in voxels (0 = raw)
  shellMaxDim: number;               // extraction resolution cap
  shellDespeckle: number;            // drop blobs below this fraction
  /** What the drawer computes once the slice has been still for a second:
   *  off      - nothing beyond the grid preview
   *  standard - exact at the slice position, 256 samples on the long side
   *  high     - exact, as many samples as the plot has pixels (and, when
   *             zoomed in, only for the visible part) */
  sliceExact: "off" | "standard" | "high";
  /** Display-level bilinear smoothing of the 2D slice. */
  sliceSmooth: boolean;
  // --- solid cells -------------------------------------------------------
  /** 3D: draw solid voxels as a neutral grey shell. */
  solidVisible: boolean;
  solidOpacity: number;
  solidSize: number;
  /** 2D slice + exported PNG: paint solid cells, or leave them transparent. */
  solid2d: boolean;
  solidColor: string;
}
export interface StreamParams {
  p0: [number, number, number]; p1: [number, number, number];
  n_seeds: number; max_steps: number;
  direction: "forward" | "backward" | "both";
}
export interface IsoParams {
  field: string; level: number; range: [number, number];
  opacity: number; visible: boolean;
}
export interface CursorInfo {
  x: number; y: number; z: number;
  value: number | null; solid: boolean; field: string;
}
export interface ViewerApi {
  getCamera: () => { position: number[]; target: number[] };
  setCamera: (c: { position: number[]; target: number[] }) => void;
  resetView: () => void;
}

interface S {
  datasets: DatasetOut[]; activeId: string | null;
  meta: DatasetOut | null;
  previewMeta: PreviewMetaOut | null;
  previewGrid: PreviewGrid | null;
  points: PointCloud | null;
  activeField: string; clim: [number, number];
  vizMode: VizMode; activeTool: Tool;
  /** Viewport input mode. "camera" = the mouse ALWAYS orbits and gizmos are
   *  inert; "edit" = gizmo handles become grabbable. Keeping these apart is
   *  what guarantees the camera can never be locked by a gizmo. */
  interactMode: "camera" | "edit";
  cursorReadout: boolean;
  cursorInfo: CursorInfo | null;
  slice: SliceParams; probe: ProbeParams; region: RegionParams;
  /** Bumped when a position is committed deliberately (typed + Enter/blur,
   *  slider released, arrow key released): the drawer then computes the
   *  exact slice right away instead of waiting for the idle second. */
  sliceCommit: number;
  commitSlice: () => void;
  sliceExport: SliceExportParams;
  exportSettings: ExportSettings;
  exportDialogOpen: boolean;
  fineVizOpen: boolean;
  batch: BatchParams;
  display: DisplayParams;
  vectors: VectorField | null;
  solidPoints: Float32Array | null;
  shellMeshes: IsoMesh[] | null;
  stream: StreamParams; iso: IsoParams;
  streamData: StreamData | null;
  isoMesh: IsoMesh | null;
  planePng: string; probePng: string;
  drawerOpen: boolean; drawerTab: "contour" | "plane" | "probe";
  jobs: string[];
  sharedBanner: string | null;
  viewerApi: ViewerApi | null;
  busyText: string;
  set: (p: Partial<S>) => void;
  setSlice: (p: Partial<SliceParams>) => void;
  setProbe: (p: Partial<ProbeParams>) => void;
  setRegion: (p: Partial<RegionParams>) => void;
  setSliceExport: (p: Partial<SliceExportParams>) => void;
  setExportSettings: (p: Partial<ExportSettings>) => void;
  setBatch: (p: Partial<BatchParams>) => void;
  setDisplay: (p: Partial<DisplayParams>) => void;
  setInteractMode: (m: "camera" | "edit") => void;
  setStream: (p: Partial<StreamParams>) => void;
  setIso: (p: Partial<IsoParams>) => void;
  addJob: (id: string) => void;
}

export const useStore = create<S>((set) => ({
  datasets: [], activeId: null, meta: null,
  previewMeta: null, previewGrid: null, points: null,
  activeField: "velocity_magnitude", clim: [0, 1],
  vizMode: "guide", activeTool: "data", interactMode: "camera",
  cursorReadout: true, cursorInfo: null,
  slice: { submode: "axis", axis: "z", pos: 0, tilt: 0, azimuth: 0, distance: 0,
           arrowMode: "auto", arrowFixedMm: 0.01 },
  sliceCommit: 0,
  probe: { p0: [0, 0, 0], p1: [1, 1, 1] },
  region: { min: [0, 0, 0], max: [1, 1, 1], sampling: "count",
            res: [20, 20, 20], step: [0.01, 0.01, 0.01] },
  sliceExport: { sampling: "count", res: [200, 200], step: [0.001, 0.001] },
  exportSettings: EXPORT_DEFAULTS,
  exportDialogOpen: false,
  fineVizOpen: false,
  batch: { start: 0, end: 1, step: 0.1, vectors: false, preview: true },
  display: DISPLAY_DEFAULTS,
  vectors: null, shellMeshes: null, solidPoints: null,
  stream: { p0: [0, 0, 0], p1: [1, 1, 1], n_seeds: 30, max_steps: 400,
            direction: "both" },
  iso: { field: "velocity_magnitude", level: 0, range: [0, 1],
         opacity: 0.85, visible: false },
  streamData: null, isoMesh: null,
  planePng: "", probePng: "",
  drawerOpen: false, drawerTab: "contour",
  jobs: [], sharedBanner: null, viewerApi: null, busyText: "",
  set: (p) => set(p),
  setInteractMode: (m) => set({ interactMode: m }),
  setSlice: (p) => set((s) => ({ slice: { ...s.slice, ...p } })),
  commitSlice: () => set((s) => ({ sliceCommit: s.sliceCommit + 1 })),
  setProbe: (p) => set((s) => ({ probe: { ...s.probe, ...p } })),
  setRegion: (p) => set((s) => ({ region: { ...s.region, ...p } })),
  setSliceExport: (p) => set((s) => ({ sliceExport: { ...s.sliceExport, ...p } })),
  setExportSettings: (p) => set((s) => ({ exportSettings: { ...s.exportSettings, ...p } })),
  setBatch: (p) => set((s) => ({ batch: { ...s.batch, ...p } })),
  setDisplay: (p) => set((s) => ({ display: { ...s.display, ...p } })),
  setStream: (p) => set((s) => ({ stream: { ...s.stream, ...p } })),
  setIso: (p) => set((s) => ({ iso: { ...s.iso, ...p } })),
  addJob: (id) => set((s) => ({ jobs: [id, ...s.jobs] })),
}));
