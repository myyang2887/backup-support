"""Geometry request models, PreprocessConfig, FluidRule (Pydantic v2)."""
from __future__ import annotations

import math
from typing import Literal

from pydantic import BaseModel, Field, model_validator

Vec3 = tuple[float, float, float]


def _finite(name: str, *vals: float | None) -> None:
    for v in vals:
        if v is not None and not math.isfinite(float(v)):
            raise ValueError(f"{name} must be finite, got {v}")


class FluidRule(BaseModel):
    """Explicit fluid/solid classification override (mode='auto' -> classifier chain)."""

    mode: Literal["auto", "field_present", "field_threshold",
                  "label_column", "all_fluid"] = "auto"
    field: str | None = None
    threshold: float | None = None
    comparison: Literal["gt", "ge", "lt", "le", "ne"] | None = None
    label_column: str | None = None
    fluid_values: list[str] = []

    @model_validator(mode="after")
    def _check(self) -> FluidRule:
        if self.mode == "field_present" and not self.field:
            raise ValueError("field_present requires 'field'")
        if self.mode == "field_threshold" and not (
            self.field and self.threshold is not None and self.comparison
        ):
            raise ValueError("field_threshold requires field/threshold/comparison")
        if self.mode == "label_column" and not self.label_column:
            raise ValueError("label_column requires 'label_column'")
        return self


class PreprocessConfig(BaseModel):
    method: str = "idw"
    spacing: float | None = Field(default=None, gt=0)
    target_dims: int | None = Field(default=None, ge=8, le=1024)
    fields: list[str] | None = None
    interp_params: dict = {}
    fluid_rule: FluidRule = FluidRule()


# --- v2.8 slice specs ---------------------------------------------------------
# Three independent knobs that used to be one overloaded "resolution":
#   SamplingSpec   - where the field is evaluated (2D sample lattice)
#   EvaluationSpec - which data and which method produce the numbers
#   RenderOptions  - how many pixels the PNG has and how it is coloured
# Changing one never changes the others: DPI does not touch the CSV, and the
# sample count does not decide the PNG size.

class SamplingSpec(BaseModel):
    """2D sample lattice on the plane. Exactly one mode, no mixing.

    long_edge : `long_edge_samples` on the longer in-plane side, the other side
                gets the count that keeps the physical spacing (near) equal.
    counts    : explicit (nu, nv), both endpoints included.
    spacing   : explicit physical steps (du, dv) [m] from the lower edge; the
                last sample is the last one that fits (never stretched).
    auto      : a named quality preset (see QUALITY_PRESETS).
    """

    mode: Literal["long_edge", "counts", "spacing", "auto"] = "long_edge"
    long_edge_samples: int | None = Field(default=None, ge=2, le=16384)
    counts: tuple[int, int] | None = None
    spacing_m: tuple[float, float] | None = None
    quality: Literal["preview", "standard", "detail"] | None = None

    @model_validator(mode="after")
    def _one_mode(self) -> SamplingSpec:
        given = {"long_edge": self.long_edge_samples is not None,
                 "counts": self.counts is not None,
                 "spacing": self.spacing_m is not None,
                 "auto": self.quality is not None}
        extra = [k for k, v in given.items() if v and k != self.mode]
        if extra:
            raise ValueError(f"sampling mode '{self.mode}' conflicts with {extra}")
        if self.counts is not None and min(self.counts) < 1:
            raise ValueError("counts must be >= 1")
        if self.spacing_m is not None:
            _finite("spacing_m", *self.spacing_m)
            if min(self.spacing_m) <= 0:
                raise ValueError("spacing_m must be > 0")
        if self.mode == "counts" and self.counts is None:
            raise ValueError("mode 'counts' needs counts=(nu, nv)")
        if self.mode == "spacing" and self.spacing_m is None:
            raise ValueError("mode 'spacing' needs spacing_m=(du, dv)")
        return self


QUALITY_PRESETS: dict[str, int] = {"preview": 256, "standard": 1024, "detail": 2048}


class EvaluationSpec(BaseModel):
    """source='original' evaluates the source points at the exact 3D sample
    positions; source='grid' reads the preprocessed uniform grid (fast,
    resolution-capped). `method` applies to 'original' only; None = the
    server default (Settings.source_method)."""

    source: Literal["original", "grid"] = "original"
    method: Literal["local_linear_hq", "local_linear", "idw", "nearest"] | None = None
    neighbors: int | None = Field(default=None, ge=4, le=128)


class RenderOptions(BaseModel):
    """PNG contract. size_mode='pixels': the long edge is exactly
    `long_edge_px` and dpi only labels the print size. size_mode='print':
    the long edge is print_long_edge_mm at `dpi`."""

    size_mode: Literal["pixels", "print"] = "pixels"
    long_edge_px: int | None = Field(default=None, ge=200, le=20000)
    print_long_edge_mm: float | None = Field(default=None, gt=0, le=2000)
    dpi: int | None = Field(default=None, ge=50, le=1200)
    cmap: str = "jet"
    clim: tuple[float, float] | None = None
    clim_mode: Literal["auto", "fixed", "batch_global"] = "auto"
    show_solid: bool = True
    solid_color: str = "#000000"
    unknown_color: str = "#bdbdbd"
    transparent_background: bool = False
    smooth: bool = False                 # display-only shading, never the CSV
    show_axes: bool = True               # False = bare field image (+ metadata)
    vector_stride: int | None = Field(default=None, ge=1)

    @model_validator(mode="after")
    def _check(self) -> RenderOptions:
        if self.clim is not None:
            _finite("clim", *self.clim)
            if self.clim[1] <= self.clim[0]:
                raise ValueError("clim must be (low, high) with high > low")
        if self.clim_mode == "fixed" and self.clim is None:
            raise ValueError("clim_mode 'fixed' needs clim")
        if self.size_mode == "print" and self.long_edge_px is not None:
            raise ValueError("size_mode 'print' takes print_long_edge_mm + dpi, "
                             "not long_edge_px")
        if self.size_mode == "pixels" and self.print_long_edge_mm is not None:
            raise ValueError("size_mode 'pixels' takes long_edge_px, "
                             "not print_long_edge_mm")
        return self


class SliceSpecs(BaseModel):
    """Mixin: the three v2.8 specs, all optional for backward compatibility.
    Old flat fields are translated by `domain.slice_adapter`."""

    sampling: SamplingSpec | None = None
    evaluation: EvaluationSpec | None = None
    render: RenderOptions | None = None


class BatchFidelity(SliceSpecs):
    """Shared batch quality knobs.

    Batch output is an archival deliverable, not a live preview, so the
    default is the highest fidelity: sampled from the source scatter at a
    resolution the data can actually support, with smooth shading.
    """

    fidelity: Literal["grid", "scatter"] = "scatter"
    sample_px: int | None = None       # None = use the data's native detail
    smooth: bool = True
    show_solid: bool = True
    solid_color: str = "black"


class AxisSliceBatch(BatchFidelity):
    axis: Literal["x", "y", "z"]
    start: float
    stop: float
    step: float = Field(gt=0)
    field: str = "velocity_magnitude"
    clim: tuple[float, float] | None = None
    cmap: str = "jet"
    with_vectors: bool = False
    vector_stride: int = Field(default=8, ge=1)
    dpi: int = 150

    @model_validator(mode="after")
    def _check(self) -> AxisSliceBatch:
        if self.stop < self.start:
            raise ValueError("stop must be >= start")
        if (self.stop - self.start) / self.step + 1 > 10000:
            raise ValueError("too many slices (>10000)")
        return self


class PlaneGeometry(BaseModel):
    """How an arbitrary-orientation plane is specified: point+normal, or the
    requirement書 form (XY平面からの回転角度 + 方位角 + その平面からの距離).

    Shared by every plane use-case — PNG rendering (PlaneSliceRequest) and
    CSV export (PlaneRegionRequest) — so both accept identical geometry.
    """

    mode: Literal["axis", "point_normal", "euler"] = "point_normal"
    origin: Vec3 | None = None
    normal: Vec3 | None = None
    tilt_deg: float | None = None
    azimuth_deg: float | None = None
    distance: float | None = None
    extent_u: tuple[float, float] | None = None
    extent_v: tuple[float, float] | None = None

    @model_validator(mode="after")
    def _check_geometry(self) -> PlaneGeometry:
        for nm in ("origin", "normal", "extent_u", "extent_v"):
            val = getattr(self, nm)
            if val is not None:
                _finite(nm, *val)
        _finite("tilt_deg", self.tilt_deg)
        _finite("azimuth_deg", self.azimuth_deg)
        _finite("distance", self.distance)
        for nm in ("extent_u", "extent_v"):
            ext = getattr(self, nm)
            if ext is not None and not ext[1] > ext[0]:
                raise ValueError(f"{nm} must be (low, high) with high > low")
        if self.mode == "axis":          # axis slices carry their own fields
            return self
        if self.mode == "point_normal":
            if self.origin is None or self.normal is None:
                raise ValueError("point_normal mode requires origin and normal")
            if all(abs(c) < 1e-15 for c in self.normal):
                raise ValueError("normal must be non-zero")
        else:
            if self.tilt_deg is None or self.azimuth_deg is None or self.distance is None:
                raise ValueError("euler mode requires tilt_deg/azimuth_deg/distance")
        return self


class PlaneSliceRequest(PlaneGeometry, SliceSpecs):
    """Plane slice rendered to PNG.

    Legacy: `resolution` used to be the grid sample count (400x400) and the
    data source was always the grid. v2.8 reads `sampling` / `evaluation` /
    `render` when given; see domain.slice_adapter for the translation."""

    resolution: tuple[int, int] = (400, 400)
    field: str = "velocity_magnitude"
    clim: tuple[float, float] | None = None
    cmap: str = "jet"
    with_vectors: bool = False
    vector_stride: int = Field(default=8, ge=1)
    dpi: int = 150


class PlaneSliceBatch(PlaneSliceRequest, BatchFidelity):
    """Batch of plane slices stepped along the normal by distance."""

    distance_start: float = 0.0
    distance_stop: float = 0.0
    distance_step: float = Field(default=1.0, gt=0)


class LineProbeRequest(BaseModel):
    p0: Vec3
    p1: Vec3
    n_samples: int = Field(default=200, ge=2, le=100_000)
    fields: list[str] = ["pressure"]

    @model_validator(mode="after")
    def _check(self) -> LineProbeRequest:
        if tuple(self.p0) == tuple(self.p1):
            raise ValueError("p0 and p1 must differ")
        return self


class BoxRegionRequest(BaseModel):
    """3D box -> CSV. Resolution per axis as point counts (`resolution`) or as
    physical steps (`spacing`, 何mm間隔); exactly one of the two."""

    min_point: Vec3
    max_point: Vec3
    resolution: tuple[int, int, int] | None = None
    spacing: Vec3 | None = None
    fields: list[str] | None = None

    @model_validator(mode="after")
    def _check(self) -> BoxRegionRequest:
        if (self.resolution is None) == (self.spacing is None):
            raise ValueError("give exactly one of resolution / spacing")
        for i in range(3):
            if self.max_point[i] < self.min_point[i]:
                raise ValueError(f"max_point[{i}] < min_point[{i}]")
            if self.spacing is not None:
                if self.spacing[i] <= 0:
                    raise ValueError("spacing must be > 0 per axis")
                continue
            if self.resolution[i] < 1:  # type: ignore[index]
                raise ValueError("resolution must be >= 1 per axis")
            if (self.max_point[i] == self.min_point[i]
                    and self.resolution[i] != 1):  # type: ignore[index]
                raise ValueError(f"axis {i} degenerate: resolution must be 1")
        return self


class SliceExportRequest(PlaneGeometry, SliceSpecs):
    """Export the currently previewed slice as PNG and/or CSV.

    `fidelity` picks the data source: "grid" reads the preprocessed volume
    (instant, capped at the grid resolution); "scatter" triangulates the
    source points near the plane (not capped, true linear gradients).
    """

    mode: Literal["axis", "point_normal", "euler"] = "axis"   # type: ignore[assignment]
    axis: Literal["x", "y", "z"] = "z"
    position: float = 0.0
    # False (default): the cut sits exactly at `position`. True: move it to
    # the nearest preprocessing-grid plane; both positions are reported.
    snap_to_grid: bool = False
    field: str = "velocity_magnitude"
    # Legacy long-edge sample count. None = the server's standard quality
    # (Settings.export_sample_long_edge) -- no longer "what the slab density
    # suggests", which under-counted and was silently applied.
    resolution: int | None = Field(default=None, ge=2, le=16384)
    fidelity: Literal["grid", "scatter"] = "scatter"
    formats: list[Literal["png", "csv", "npz", "json"]] = ["png"]
    with_vectors: bool = False
    smooth: bool = True
    # paint solid cells (真っ黒) or leave them transparent
    show_solid: bool = True
    solid_color: str = "black"
    cmap: str = "jet"
    dpi: int = Field(default=150, ge=50, le=600)

    @model_validator(mode="after")
    def _check_export(self) -> SliceExportRequest:
        if not self.formats:
            raise ValueError("choose at least one output format")
        _finite("position", self.position)
        return self


class PlaneRegionRequest(PlaneGeometry):
    """断面 (plane) -> CSV at a chosen in-plane resolution.

    Requirement書 3項:「指定した領域(断面)について、指定した解像度でのcsv出力…
    何mm間隔、xy方向で別々に指定したい」. `spacing` is the in-plane step
    (u, v) in metres; `resolution` is the point-count alternative.
    """

    resolution: tuple[int, int] | None = None
    spacing: tuple[float, float] | None = None
    fields: list[str] | None = None
    # v2.8: "grid" (default, as before) or "original" (exact 3D evaluation of
    # the source points, same path as the slice export).
    source: Literal["grid", "original"] = "grid"
    method: Literal["local_linear_hq", "local_linear", "idw", "nearest"] | None = None

    @model_validator(mode="after")
    def _check_sampling(self) -> PlaneRegionRequest:
        if (self.resolution is None) == (self.spacing is None):
            raise ValueError("give exactly one of resolution / spacing")
        if self.spacing is not None and any(s <= 0 for s in self.spacing):
            raise ValueError("spacing must be > 0 per in-plane axis")
        if self.resolution is not None and any(r < 1 for r in self.resolution):
            raise ValueError("resolution must be >= 1 per in-plane axis")
        return self


class StreamlineRequest(BaseModel):
    """Rake of seeds on segment p0-p1, integrated through the velocity field."""

    p0: Vec3
    p1: Vec3
    n_seeds: int = Field(default=30, ge=1, le=500)
    max_steps: int = Field(default=400, ge=10, le=5000)
    step_scale: float = Field(default=0.75, gt=0, le=5.0)
    direction: Literal["forward", "backward", "both"] = "both"


class SessionIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    dataset_id: str
    state: dict


class SnapshotIn(BaseModel):
    dataset_id: str
    state: dict


class StackRequest(BaseModel):
    """A slice stack: many parallel slices, precomputed so a slider can be
    scrubbed with near-exact results (services.slice_stack).

    t is the position along the stack direction: the coordinate for axis
    stacks, the signed distance from the data centre for Euler planes (the
    same convention as the slice tool and the spacing profile).
    `along` / `inplane` scale the data's own spacing: 0.5 = two samples per
    data spacing (each data layer plus a midpoint)."""

    field: str
    mode: Literal["axis", "euler"] = "axis"
    axis: Literal["x", "y", "z"] = "z"
    tilt_deg: float = 0.0
    azimuth_deg: float = 0.0
    t_range: tuple[float, float] | None = None
    along: float = Field(default=0.5, gt=0, le=8)
    inplane: float = Field(default=0.5, gt=0, le=8)
    method: Literal["idw", "local_linear"] = "local_linear"
    max_planes: int = Field(default=1500, ge=2, le=10000)
    max_inplane: int = Field(default=1024, ge=16, le=4096)

    @model_validator(mode="after")
    def _check(self) -> StackRequest:
        _finite("tilt_deg", self.tilt_deg)
        _finite("azimuth_deg", self.azimuth_deg)
        if self.t_range is not None:
            _finite("t_range", *self.t_range)
            if not self.t_range[1] > self.t_range[0]:
                raise ValueError("t_range must be (low, high) with high > low")
        return self
