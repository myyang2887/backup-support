"""Global configuration (env prefix FDPOST_) and resource path helpers."""
from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path
from typing import Any

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Global settings. Override via environment variables, e.g. FDPOST_CACHE_DIR."""

    data_dir: Path = Path("./data")
    cache_dir: Path = Path("./cache")
    output_dir: Path = Path("./output")
    preview_res: int = 128
    max_export_rows: int = 5_000_000
    default_interp: str = "idw"
    host: str = "127.0.0.1"
    port: int = 8000
    job_workers: int = 2
    grid_lru_size: int = 3
    point_cloud_cap: int = 80_000
    vector_glyph_dim: int = 22        # lattice max_dim for 3D arrows
    vector_glyph_cap: int = 24_000    # hard cap on arrow instances
    source_sampler_lru: int = 2       # datasets kept fitted for hi-res slices
    # Interactive preview only: a slice_direct request above this is reduced
    # AND reported as reduced (meta.capped). Formal export never shrinks a
    # request silently -- see export_max_sample_points.
    slice_direct_max_px: int = 1200

    # --- formal slice export (v2.8) -----------------------------------------
    export_sample_long_edge: int = 1024     # default 2D samples on the long side
    export_image_long_edge_px: int = 3000   # default PNG long edge
    export_dpi: int = 300
    export_max_sample_points: int = 4_194_304   # nu*nv budget; above -> refuse
    export_max_image_px: int = 12_000       # longest PNG edge accepted
    chunk_query_points: int = 16_384        # evaluator chunk size (bounded memory)

    # --- source-data evaluation (independent of the preprocessing method) ---
    source_method: str = "local_linear"     # local_linear | idw | nearest
    local_linear_neighbors: int = 32
    balanced_search_neighbors: int = 512    # largest candidate pool for octant balancing
    balanced_per_octant: int = 4
    hq_max_pool: int = 4096                 # local_linear_hq: largest candidate pool
    anisotropy_trigger: float = 4.0         # neighbour spread ratio that triggers balancing
    max_condition: float = 1e6              # local design-matrix condition limit
    idw_neighbors: int = 8
    idw_power: float = 2.0
    support_gap_factor: float = 2.0         # query farther than this x local radius -> unknown

    # --- slice stacks (fine visualization) ------------------------------------
    stack_max_samples: int = 64_000_000     # planes x nu x nv; above -> refuse

    # --- batch ----------------------------------------------------------------
    batch_max_slices: int = 200

    model_config = {"env_prefix": "FDPOST_"}

    def effective(self) -> dict[str, Any]:
        """Values actually in force (logged and written into manifests)."""
        return {k: (str(v) if isinstance(v, Path) else v)
                for k, v in self.model_dump().items()}


log = logging.getLogger("fdpost.config")

# Optional JSON config. Precedence (low -> high): built-in defaults, this file,
# FDPOST_* environment variables, then per-request parameters (which can never
# raise the resource limits set here). Sections are flattened with "_":
#   {"export": {"sample_long_edge": 1024}}  ->  export_sample_long_edge
CONFIG_ENV = "FDPOST_CONFIG"
_RESOURCE_LIMITS = ("export_max_sample_points", "export_max_image_px",
                    "batch_max_slices", "max_export_rows")


def _flatten(d: dict[str, Any], prefix: str = "") -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in d.items():
        key = f"{prefix}_{k}" if prefix else k
        if isinstance(v, dict):
            out.update(_flatten(v, key))
        else:
            out[key] = v
    return out


def load_settings(path: str | Path | None = None) -> Settings:
    """Settings from defaults + optional JSON file + environment."""
    path = path or os.environ.get(CONFIG_ENV)
    if not path:
        cand = Path("fdpost.config.json")
        path = cand if cand.is_file() else None
    file_vals: dict[str, Any] = {}
    if path:
        p = Path(path)
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
            flat = _flatten(raw)
            known = set(Settings.model_fields)
            unknown = sorted(set(flat) - known)
            if unknown:
                log.warning("config %s: ignoring unknown keys %s", p, unknown)
            file_vals = {k: v for k, v in flat.items() if k in known}
        except (OSError, ValueError) as e:
            log.error("config %s unreadable (%s); using defaults", p, e)
    # environment wins over the file: drop file keys that the env sets
    env_set = {k for k in Settings.model_fields
               if f"FDPOST_{k.upper()}" in os.environ}
    s = Settings(**{k: v for k, v in file_vals.items() if k not in env_set})
    if file_vals:
        log.info("config loaded from %s", path)
    return s


settings = load_settings()


def ensure_dirs() -> None:
    """Create data/cache/output directories (exist_ok)."""
    for d in (settings.data_dir, settings.cache_dir, settings.output_dir):
        Path(d).mkdir(parents=True, exist_ok=True)


def frontend_dist() -> Path | None:
    """Locate the built UI.

    Two copies can exist at once — the one inside an installed package
    (``fdpost/web``, shipped by the wheel) and the one in a source checkout
    (``frontend/dist``) — and either can be the stale one:

    * install fresh over an old checkout  -> the checkout is stale
    * rebuild the checkout without reinstalling -> the install is stale

    A fixed priority gets one of those wrong, so the newest ``index.html``
    wins. That is self-correcting in both directions: whichever you just
    built is the one you get. Set ``FDPOST_FRONTEND_DIR`` to pin it
    explicitly when a deterministic choice matters (packaging, CI).
    """
    override = os.environ.get("FDPOST_FRONTEND_DIR")
    if override:
        d = Path(override).expanduser().resolve()
        return d if (d / "index.html").is_file() else None

    if hasattr(sys, "_MEIPASS"):          # frozen build: nothing else applies
        d = Path(sys._MEIPASS) / "frontend/dist"  # type: ignore[attr-defined]
        return d if (d / "index.html").is_file() else None

    here = Path(__file__).resolve().parent
    candidates = [
        here / "web",                                       # pip install
        Path(sys.argv[0]).resolve().parent / "frontend/dist",  # onedir
        here.parents[1] / "frontend/dist",                  # source checkout
    ]
    found = [(c, (c / "index.html").stat().st_mtime)
             for c in candidates if (c / "index.html").is_file()]
    if not found:
        return None
    best = max(found, key=lambda t: t[1])
    if len(found) > 1:
        log.info("multiple frontend builds found; serving the newest: %s", best[0])
    return best[0]


def resource_path(rel: str) -> Path:
    """Locate bundled resources in dev and frozen (PyInstaller) environments."""
    if hasattr(sys, "_MEIPASS"):  # PyInstaller onefile
        return Path(sys._MEIPASS) / rel  # type: ignore[attr-defined]
    exe_dir = Path(sys.argv[0]).resolve().parent
    if (exe_dir / rel).exists():  # onedir: next to the executable
        return exe_dir / rel
    # dev: project root = three levels above this file (src/fdpost/config.py)
    return Path(__file__).resolve().parents[2] / rel
