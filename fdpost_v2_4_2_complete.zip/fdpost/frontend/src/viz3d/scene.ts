/** Tier-1 scene pieces: bounding box, axis labels, fluid point cloud.
 *  Standard three.js primitives only — no custom shaders. */
import * as THREE from "three";
import { jet, normalize } from "../colormap";
import type { PointCloud } from "../types";

/** Soft round sprite. A disc with a feathered edge reads as a volume of
 *  particles instead of a wall of squares — the cheapest big win in how
 *  the cloud looks. Built once and shared by every point cloud. */
let discTexture: THREE.Texture | null = null;
function roundSprite(): THREE.Texture {
  if (discTexture) return discTexture;
  const n = 64;
  const c = document.createElement("canvas");
  c.width = c.height = n;
  const ctx = c.getContext("2d")!;
  const g = ctx.createRadialGradient(n / 2, n / 2, 0, n / 2, n / 2, n / 2);
  g.addColorStop(0.0, "rgba(255,255,255,1)");
  g.addColorStop(0.55, "rgba(255,255,255,0.95)");
  g.addColorStop(1.0, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, n, n);
  discTexture = new THREE.CanvasTexture(c);
  return discTexture;
}

export interface CloudOptions {
  style: "round" | "square";
  opacity: number;
  /** Keep only values inside this range (null = keep everything). This is
   *  what removes the fog of near-zero-velocity voxels. */
  range: [number, number] | null;
}

export function buildBoundsBox(bounds: number[][]): THREE.Object3D {
  const [lo, hi] = bounds;
  const box = new THREE.Box3(
    new THREE.Vector3(lo[0], lo[1], lo[2]), new THREE.Vector3(hi[0], hi[1], hi[2]),
  );
  return new THREE.Box3Helper(box, new THREE.Color(0x5a6478));
}

function textSprite(text: string, color: string): THREE.Sprite {
  const c = document.createElement("canvas");
  c.width = 128; c.height = 64;
  const ctx = c.getContext("2d")!;
  ctx.font = "bold 40px sans-serif";
  ctx.fillStyle = color;
  ctx.fillText(text, 8, 46);
  const tex = new THREE.CanvasTexture(c);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false }));
  return sp;
}

export function buildAxes(bounds: number[][]): THREE.Group {
  const [lo, hi] = bounds;
  const L = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]);
  const g = new THREE.Group();
  const axes = new THREE.AxesHelper(L * 0.4);
  axes.position.set(lo[0], lo[1], lo[2]);
  g.add(axes);
  const sc = L * 0.08;
  const mk = (t: string, col: string, p: [number, number, number]) => {
    const s = textSprite(t, col);
    s.scale.set(sc * 2, sc, 1);
    s.position.set(...p);
    g.add(s);
  };
  mk("X", "#ff6666", [lo[0] + L * 0.45, lo[1], lo[2]]);
  mk("Y", "#66ff66", [lo[0], lo[1] + L * 0.45, lo[2]]);
  mk("Z", "#6699ff", [lo[0], lo[1], lo[2] + L * 0.45]);
  return g;
}

export function buildPointCloud(
  pc: PointCloud, clim: [number, number], size: number,
  opts: CloudOptions = { style: "round", opacity: 1, range: null },
): THREE.Points {
  const m = pc.values.length;
  const keep = (v: number) => !opts.range
    || (v >= opts.range[0] && v <= opts.range[1]);
  let n = 0;
  for (let i = 0; i < m; i++) if (keep(pc.values[i])) n++;

  const pos = new Float32Array(n * 3);
  const colors = new Float32Array(n * 3);
  let w = 0;
  for (let i = 0; i < m; i++) {
    if (!keep(pc.values[i])) continue;
    pos[3 * w] = pc.coords[3 * i];
    pos[3 * w + 1] = pc.coords[3 * i + 1];
    pos[3 * w + 2] = pc.coords[3 * i + 2];
    const [r, g, b] = jet(normalize(pc.values[i], clim));
    colors[3 * w] = r; colors[3 * w + 1] = g; colors[3 * w + 2] = b;
    w++;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  const round = opts.style === "round";
  const mat = new THREE.PointsMaterial({
    size, vertexColors: true, sizeAttenuation: true,
    map: round ? roundSprite() : null,
    alphaTest: round ? 0.12 : 0,
    transparent: opts.opacity < 0.999 || round,
    opacity: opts.opacity,
    depthWrite: opts.opacity > 0.9,
  });
  const points = new THREE.Points(geo, mat);
  points.userData.visibleCount = n;
  return points;
}

export function disposeObject(obj: THREE.Object3D): void {
  obj.traverse((o: any) => {
    o.geometry?.dispose?.();
    const mats = Array.isArray(o.material) ? o.material : [o.material];
    mats.forEach((m: any) => { m?.map?.dispose?.(); m?.dispose?.(); });
  });
}
