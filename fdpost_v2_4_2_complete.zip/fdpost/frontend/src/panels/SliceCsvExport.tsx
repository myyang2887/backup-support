/** 断面CSV出力 — requirement書 3項:「指定した領域(断面)について、指定した
 *  解像度でのcsvデータ出力(何mm間隔、xy方向で別々に指定)」.
 *
 *  Belongs to the slice tool: it exports *the cut you are currently looking
 *  at*, axis-orthogonal or free plane alike, so the PNG preview and the CSV
 *  always describe the same plane.
 */
import { useState } from "react";
import { postPlaneRegion } from "../api";
import { useStore } from "../store";
import { toast } from "../toast";
import ExportBar from "./ExportBar";

const AXIS_IDX = { x: 0, y: 1, z: 2 } as const;
const LIMIT = 5_000_000;

/** The plane geometry currently shown in the 3D view, in request form. */
function currentPlane(s: ReturnType<typeof useStore.getState>) {
  const { slice, previewGrid, meta } = s;
  if (slice.submode === "plane") {
    return { mode: "euler" as const, tilt_deg: slice.tilt,
             azimuth_deg: slice.azimuth, distance: slice.distance };
  }
  const a = AXIS_IDX[slice.axis];
  const pos = previewGrid
    ? previewGrid.origin[a] + previewGrid.spacing[a] * slice.k
    : meta!.bounds![0][a];
  const origin: [number, number, number] = [0, 0, 0];
  const normal: [number, number, number] = [0, 0, 0];
  const mid = meta!.bounds!;
  origin[0] = (mid[0][0] + mid[1][0]) / 2;
  origin[1] = (mid[0][1] + mid[1][1]) / 2;
  origin[2] = (mid[0][2] + mid[1][2]) / 2;
  origin[a] = pos;
  normal[a] = 1;
  return { mode: "point_normal" as const, origin, normal };
}

/** In-plane extent of the current cut, used for the row estimate. */
function inPlaneSpan(s: ReturnType<typeof useStore.getState>): [number, number] {
  const [lo, hi] = s.meta!.bounds!;
  const d: [number, number, number] = [hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]];
  if (s.slice.submode === "axis") {
    const a = AXIS_IDX[s.slice.axis];
    const rest = [0, 1, 2].filter((i) => i !== a);
    return [d[rest[0]], d[rest[1]]];
  }
  const diag = Math.hypot(d[0], d[1], d[2]);   // tilted cut: bounding square
  return [diag, diag];
}

export default function SliceCsvExport() {
  const store = useStore();
  const { sliceExport: ex, setSliceExport, slice, activeId } = store;
  const [busy, setBusy] = useState(false);
  const [files, setFiles] = useState<string[]>([]);

  const [su, sv] = inPlaneSpan(store);
  const rows = ex.sampling === "count"
    ? ex.res[0] * ex.res[1]
    : (Math.floor(su / ex.step[0]) + 1) * (Math.floor(sv / ex.step[1]) + 1);
  const over = rows > LIMIT;

  const run = async () => {
    setBusy(true);
    try {
      const r = await postPlaneRegion(activeId!, {
        ...currentPlane(store),
        ...(ex.sampling === "count"
          ? { resolution: ex.res } : { spacing: ex.step }),
      });
      toast(`${r.n_rows.toLocaleString()} 行を出力しました`);
      if (r.csv_url) setFiles([r.csv_url.replace("/api/files/", "")]);
    } catch (e: any) { toast(e.message, "err"); }
    setBusy(false);
  };

  const pair = (v: [number, number], i: number, x: number): [number, number] =>
    (i === 0 ? [x, v[1]] : [v[0], x]);

  return (
    <div className="panel">
      <h3>断面CSV出力</h3>
      <div className="hint" style={{ marginBottom: 8 }}>
        いま表示中の{slice.submode === "axis" ? "軸直交断面" : "自由平面"}
        を、指定解像度でCSVに出力します。
        面内2方向を別々に指定できます。
      </div>

      <div className="tabs" style={{ marginBottom: 8 }}>
        <button className={ex.sampling === "step" ? "on" : ""}
                onClick={() => setSliceExport({ sampling: "step" })}>間隔指定</button>
        <button className={ex.sampling === "count" ? "on" : ""}
                onClick={() => setSliceExport({ sampling: "count" })}>点数指定</button>
      </div>

      {ex.sampling === "step" ? (
        <div className="field-grid">
          <label>面内u間隔 [m]</label>
          <input type="number" step="0.0001" min="1e-9" value={ex.step[0]}
                 onChange={(e) => setSliceExport({
                   step: pair(ex.step, 0, Math.max(1e-9, +e.target.value)) })} />
          <label style={{ gridColumn: "3" }}>面内v間隔 [m]</label>
          <input type="number" step="0.0001" min="1e-9" value={ex.step[1]}
                 onChange={(e) => setSliceExport({
                   step: pair(ex.step, 1, Math.max(1e-9, +e.target.value)) })} />
        </div>
      ) : (
        <div className="field-grid">
          <label>面内u点数</label>
          <input type="number" step="1" min="1" value={ex.res[0]}
                 onChange={(e) => setSliceExport({
                   res: pair(ex.res, 0, Math.max(1, Math.round(+e.target.value))) })} />
          <label style={{ gridColumn: "3" }}>面内v点数</label>
          <input type="number" step="1" min="1" value={ex.res[1]}
                 onChange={(e) => setSliceExport({
                   res: pair(ex.res, 1, Math.max(1, Math.round(+e.target.value))) })} />
        </div>
      )}

      <div className="mono" style={{ fontSize: 11, marginTop: 6,
           color: over ? "var(--err)" : "var(--text-dim)" }}>
        推定行数 {rows.toLocaleString()}
        {over && ` — 上限 ${LIMIT.toLocaleString()} 行を超えています`}
      </div>

      <div className="row" style={{ marginTop: 8 }}>
        <button className="primary" disabled={over || busy} onClick={run}>
          {busy ? "出力中…" : "CSV出力"}
        </button>
      </div>
      <div className="hint" style={{ marginTop: 8 }}>
        列: u,v(面内座標) + x,y,z(世界座標) + 全フィールド + is_solid。
        {ex.sampling === "step"
          && " 間隔は厳密に守られ、端点は間隔の整数倍に収まる範囲までです。"}
      </div>
      <ExportBar files={files} />
    </div>
  );
}
