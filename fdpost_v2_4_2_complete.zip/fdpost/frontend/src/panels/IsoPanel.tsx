/** Isosurface: field + level slider driven by the server-reported range. */
import { useState } from "react";
import { loadShells } from "../actions";
import { getIsoRange, getIsosurface } from "../api";
import { Feature } from "../features";
import { useStore } from "../store";
import { toast } from "../toast";
import { fieldRole } from "../types";

/** Labelled slider with a live readout (shared shape with the display tool). */
function Slider(props: {
  label: string; value: number; min: number; max: number; step: number;
  fmt?: (v: number) => string; onChange: (v: number) => void;
  onCommit?: () => void;
}) {
  return (
    <div style={{ marginTop: 8 }}>
      <div className="row" style={{ marginBottom: 2 }}>
        <label>{props.label}</label>
        <span className="mono" style={{ marginLeft: "auto", fontSize: 11 }}>
          {(props.fmt ?? ((v: number) => v.toFixed(2)))(props.value)}
        </span>
      </div>
      <input type="range" min={props.min} max={props.max} step={props.step}
             value={props.value}
             onInput={(e) => props.onChange(+(e.target as HTMLInputElement).value)}
             onPointerUp={props.onCommit} />
    </div>
  );
}

export default function IsoPanel() {
  const { meta, activeId, iso, setIso, set, display, setDisplay,
          shellMeshes } = useStore();
  const [busy, setBusy] = useState(false);
  const [busy2, setBusy2] = useState("");
  const withBusy = async (tag: string, fn: () => Promise<void>) => {
    setBusy2(tag);
    try { await fn(); } catch (e: any) { toast(e.message, "err"); }
    setBusy2("");
  };
  if (!meta?.bounds) return <div className="hint">データセットを読み込んでください</div>;
  const fields = [...meta.fields].sort((a, b) =>
    +(fieldRole(b) === "scalar_field") - +(fieldRole(a) === "scalar_field"));
  const [lo, hi] = iso.range;
  const span = hi - lo || 1;

  const changeField = async (f: string) => {
    try {
      const range = await getIsoRange(activeId!, f);
      setIso({ field: f, range, level: 0.5 * (range[0] + range[1]) });
    } catch (e: any) { toast(e.message, "err"); }
  };

  const compute = async (level = iso.level) => {
    setBusy(true);
    try {
      const mesh = await getIsosurface(activeId!, iso.field, level);
      set({ isoMesh: mesh });
      setIso({ visible: true, level });
      toast(`等値面を生成しました(${mesh.faces.length / 3} 面)`);
    } catch (e: any) { toast(e.message, "err"); }
    setBusy(false);
  };

  return (
    <>
    <div className="panel">
      <h3>等値面</h3>
      <div className="row">
        <label>フィールド</label>
        <select value={iso.field} onChange={(e) => changeField(e.target.value)}>
          {fields.map((f) => <option key={f}>{f}</option>)}
        </select>
      </div>
      <div style={{ marginTop: 10 }}>
        <div className="row" style={{ justifyContent: "space-between" }}>
          <label>レベル</label>
          <span className="mono" style={{ fontSize: 11 }}>
            {iso.level.toPrecision(5)} {meta.units?.[iso.field] ?? ""}
          </span>
        </div>
        <input type="range" min={0} max={1000}
               value={Math.round(((iso.level - lo) / span) * 1000)}
               onInput={(e) => setIso({
                 level: lo + (+(e.target as HTMLInputElement).value / 1000) * span })}
               onMouseUp={() => iso.visible && compute()}
               onTouchEnd={() => iso.visible && compute()} />
        <div className="row mono"
             style={{ justifyContent: "space-between", fontSize: 10,
                      color: "var(--text-faint)" }}>
          <span>{lo.toPrecision(3)}</span><span>{hi.toPrecision(3)}</span>
        </div>
      </div>
      <div style={{ marginTop: 8 }}>
        <div className="row" style={{ justifyContent: "space-between" }}>
          <label>不透明度</label>
          <span className="mono" style={{ fontSize: 11 }}>
            {(iso.opacity * 100).toFixed(0)}%</span>
        </div>
        <input type="range" min={10} max={100} value={iso.opacity * 100}
               onInput={(e) => setIso({
                 opacity: +(e.target as HTMLInputElement).value / 100 })} />
      </div>
      <div className="row" style={{ marginTop: 10 }}>
        <button className="primary" onClick={() => compute()} disabled={busy}>
          {busy ? "計算中…" : iso.visible ? "再計算" : "表示"}
        </button>
        {iso.visible && (
          <button onClick={() => setIso({ visible: false })}>非表示</button>
        )}
      </div>
      <div className="hint" style={{ marginTop: 8 }}>
        固体境界に人工的な面は張りません(マスク処理)。
        スライダーを離すと自動で再計算されます。
      </div>
    </div>

    <Feature id="viewport.shells">
    <div className="panel">
      <h3>サーフェス表現(多重等値面)</h3>
      <div className="hint" style={{ marginBottom: 6 }}>
        等値面を入れ子状に重ねた半透明表示です。外殻で流れの輪郭、
        内側でコアを見ます。点群より全体形状が掴みやすくなります。
      </div>
      <div className="row">
        <button className="primary" disabled={busy2 === "shell"}
                onClick={() => withBusy("shell", async () => {
                  await loadShells();
                  setDisplay({ shellsVisible: true });
                })}>
          {busy2 === "shell" ? "生成中…" : shellMeshes ? "再生成" : "サーフェスを表示"}
        </button>
        {shellMeshes && (
          <button onClick={() => setDisplay({
                    shellsVisible: !display.shellsVisible })}>
            {display.shellsVisible ? "非表示" : "表示"}
          </button>
        )}
      </div>
      <Slider label="層数" value={display.shellCount} min={1} max={5} step={1}
              fmt={(v) => `${v} 層`}
              onChange={(v) => setDisplay({ shellCount: v })}
              onCommit={() => { if (shellMeshes) withBusy("shell", loadShells); }} />
      <Slider label="外殻の不透明度" value={display.shellOpacity}
              min={0.05} max={0.6} step={0.05}
              onChange={(v) => setDisplay({ shellOpacity: v })} />
      <Slider label="平滑化 (voxel)" value={display.shellSmooth}
              min={0} max={3} step={0.2}
              fmt={(v) => (v === 0 ? "なし(生データ)" : `σ ${v.toFixed(1)}`)}
              onChange={(v) => setDisplay({ shellSmooth: v })}
              onCommit={() => { if (shellMeshes) withBusy("shell", loadShells); }} />
      <Slider label="抽出解像度" value={display.shellMaxDim}
              min={64} max={384} step={32}
              fmt={(v) => `${v}³ まで`}
              onChange={(v) => setDisplay({ shellMaxDim: v })}
              onCommit={() => { if (shellMeshes) withBusy("shell", loadShells); }} />
      <Slider label="小片除去" value={display.shellDespeckle}
              min={0} max={0.2} step={0.01}
              fmt={(v) => (v === 0 ? "なし" : `最大塊の ${(v * 100).toFixed(0)}% 未満を除去`)}
              onChange={(v) => setDisplay({ shellDespeckle: v })}
              onCommit={() => { if (shellMeshes) withBusy("shell", loadShells); }} />
      <div className="hint" style={{ marginTop: 6 }}>
        穴やギザギザが目立つときは平滑化と抽出解像度を上げてください。
        点群を非表示にすると、サーフェスがいちばん綺麗に見えます。
      </div>
    </div>
    </Feature>
    </>
  );
}
