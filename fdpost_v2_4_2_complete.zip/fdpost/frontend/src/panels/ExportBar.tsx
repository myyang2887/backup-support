/** Export: desktop (pywebview) -> native path; Chromium -> save-as picker;
 *  otherwise plain download. */
import { fileUrl } from "../api";
import { IconDown } from "../icons";
import { toast } from "../toast";

declare global {
  interface Window {
    pywebview?: { api: { choose_save_dir(): Promise<string | null>;
                         export_to(rel: string, dir: string): Promise<string> } };
    showSaveFilePicker?: (o: any) => Promise<any>;
  }
}

export async function exportFile(relPath: string): Promise<void> {
  const name = relPath.split("/").pop() || "result";
  if (window.pywebview?.api) {
    const dir = await window.pywebview.api.choose_save_dir();
    if (!dir) return;
    const dest = await window.pywebview.api.export_to(relPath, dir);
    toast(`保存しました: ${dest}`);
    return;
  }
  const resp = await fetch(fileUrl(relPath));
  const blob = await resp.blob();
  if (window.showSaveFilePicker) {
    try {
      const h = await window.showSaveFilePicker({ suggestedName: name });
      const w = await h.createWritable();
      await w.write(blob); await w.close();
      toast(`保存しました: ${name}`);
    } catch { /* user cancelled */ }
    return;
  }
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name;
  a.click(); URL.revokeObjectURL(a.href);
  toast("ダウンロードを開始しました");
}

export default function ExportBar(props: { files: string[] }) {
  if (!props.files.length) return null;
  return (
    <div className="row" style={{ marginTop: 8 }}>
      {props.files.map((f) => (
        <button key={f} className="quiet" style={{ fontSize: 11,
                display: "inline-flex", gap: 5, alignItems: "center" }}
                onClick={() => exportFile(f)}>
          <IconDown size={13} /> {f.split("/").pop()}
        </button>
      ))}
    </div>
  );
}
