import type { DatasetOut, JobOut, PointCloud, PreviewMetaOut } from "./types";

async function jsonOrThrow(r: Response) {
  if (!r.ok) {
    let detail = r.statusText;
    try {
      const j = await r.json();
      detail = j.detail ?? j.error ?? detail;
    } catch { /* ignore */ }
    throw new Error(detail);
  }
  return r.json();
}

export async function uploadDataset(
  file: File, cfg: { method: string; target_dims?: number; fluid_rule?: string },
): Promise<{ dataset_id: string; job_id: string }> {
  const fd = new FormData();
  fd.append("file", file);
  fd.append("method", cfg.method);
  if (cfg.target_dims) fd.append("target_dims", String(cfg.target_dims));
  if (cfg.fluid_rule) fd.append("fluid_rule", cfg.fluid_rule);
  return jsonOrThrow(await fetch("/api/datasets/upload", { method: "POST", body: fd }));
}

export const listDatasets = async (): Promise<DatasetOut[]> =>
  jsonOrThrow(await fetch("/api/datasets"));
export const getDataset = async (id: string): Promise<DatasetOut> =>
  jsonOrThrow(await fetch(`/api/datasets/${id}`));
export const deleteDataset = async (id: string, dropSource = false):
  Promise<{ id: string; removed_files: string[] }> =>
  jsonOrThrow(await fetch(
    `/api/datasets/${id}?drop_source=${dropSource}`, { method: "DELETE" }));
export const getPreviewMeta = async (id: string): Promise<PreviewMetaOut> =>
  jsonOrThrow(await fetch(`/api/datasets/${id}/preview/meta`));

export async function getPreviewVolume(id: string, field: string): Promise<Float32Array> {
  const r = await fetch(`/api/datasets/${id}/preview/volume/${encodeURIComponent(field)}`);
  if (!r.ok) throw new Error(r.statusText);
  return new Float32Array(await r.arrayBuffer()); // F-order float32, solid = NaN
}

export async function getPreviewPoints(id: string, field: string): Promise<PointCloud> {
  const r = await fetch(`/api/datasets/${id}/preview/points/${encodeURIComponent(field)}`);
  if (!r.ok) throw new Error(r.statusText);
  const buf = await r.arrayBuffer();
  const m = Math.floor(buf.byteLength / 16); // coords (M,3) f32 + values (M,) f32
  return {
    coords: new Float32Array(buf, 0, m * 3),
    values: new Float32Array(buf, m * 12, m),
  };
}

const post = async (url: string, body: unknown) =>
  jsonOrThrow(await fetch(url, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }));

export const postAxisBatch = (id: string, req: unknown): Promise<JobOut> =>
  post(`/api/datasets/${id}/slices/axis-batch`, req);
export const postPlaneSlice = (id: string, req: unknown):
  Promise<{ file: string; file_url?: string; origin: number[]; normal: number[] }> =>
  post(`/api/datasets/${id}/slices/plane`, req);
export const postPlaneBatch = (id: string, req: unknown): Promise<JobOut> =>
  post(`/api/datasets/${id}/slices/plane-batch`, req);
export const postProbe = (id: string, req: unknown):
  Promise<{ csv_url?: string; png_url?: string; n_rows: number }> =>
  post(`/api/datasets/${id}/probe`, req);
export const postRegion = (id: string, req: unknown):
  Promise<{ csv_url?: string; n_rows: number; fields: string[] }> =>
  post(`/api/datasets/${id}/region`, req);
export const postPlaneRegion = (id: string, req: unknown):
  Promise<{ csv_url?: string; n_rows: number; fields: string[];
            extent_u: number[]; extent_v: number[] }> =>
  post(`/api/datasets/${id}/region/plane`, req);
export const getJob = async (jobId: string): Promise<JobOut> =>
  jsonOrThrow(await fetch(`/api/jobs/${jobId}`));

/** NaN-aware min/max over a Float32Array (client-side clim). */
export function computeClim(a: Float32Array): [number, number] {
  let lo = Infinity, hi = -Infinity;
  for (let i = 0; i < a.length; i++) {
    const v = a[i];
    if (Number.isNaN(v)) continue;
    if (v < lo) lo = v;
    if (v > hi) hi = v;
  }
  return lo <= hi ? [lo, hi] : [0, 1];
}

export const fileUrl = (relPath: string) => `/api/files/${relPath}`;

// ---- v2.1 additions ----
import type { IsoMesh, SessionRow, StreamData } from "./types";

export async function getIsoRange(id: string, field: string): Promise<[number, number]> {
  const j = await jsonOrThrow(await fetch(
    `/api/datasets/${id}/isosurface/${encodeURIComponent(field)}/range`));
  return [j.min, j.max];
}

export async function getIsosurface(
  id: string, field: string, level: number,
  opt: { maxDim?: number; smooth?: number; minComponentFrac?: number } = {},
): Promise<IsoMesh> {
  const q = new URLSearchParams({ level: String(level) });
  if (opt.maxDim) q.set("max_dim", String(opt.maxDim));
  if (opt.smooth !== undefined) q.set("smooth", String(opt.smooth));
  if (opt.minComponentFrac) q.set("min_component_frac", String(opt.minComponentFrac));
  const r = await fetch(
    `/api/datasets/${id}/isosurface/${encodeURIComponent(field)}?${q}`);
  if (!r.ok) {
    let d = r.statusText;
    try { d = (await r.json()).detail ?? d; } catch { /* ignore */ }
    throw new Error(d);
  }
  const buf = await r.arrayBuffer();
  const head = new Uint32Array(buf, 0, 2);
  const nV = head[0], nF = head[1];
  return {
    verts: new Float32Array(buf, 8, nV * 3),
    normals: new Float32Array(buf, 8 + nV * 12, nV * 3),
    faces: new Uint32Array(buf, 8 + nV * 24, nF * 3),
    level, field,
  };
}

export async function postStreamlines(id: string, req: unknown): Promise<StreamData> {
  const r = await fetch(`/api/datasets/${id}/streamlines`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
  });
  if (!r.ok) {
    let d = r.statusText;
    try { d = (await r.json()).detail ?? d; } catch { /* ignore */ }
    throw new Error(d);
  }
  const buf = await r.arrayBuffer();
  const nL = new Uint32Array(buf, 0, 1)[0];
  const counts = new Uint32Array(buf.slice(4, 4 + nL * 4));
  let total = 0;
  for (let i = 0; i < nL; i++) total += counts[i];
  const off = 4 + nL * 4;
  const points = new Float32Array(buf, off, total * 3);
  const speeds = new Float32Array(buf, off + total * 12, total);
  let lo = Infinity, hi = -Infinity;
  for (let i = 0; i < speeds.length; i++) {
    if (speeds[i] < lo) lo = speeds[i];
    if (speeds[i] > hi) hi = speeds[i];
  }
  return { counts, points, speeds,
           speedRange: lo <= hi ? [lo, hi] : [0, 1] };
}

export const listSessions = async (): Promise<SessionRow[]> =>
  jsonOrThrow(await fetch("/api/sessions"));
export const saveSession = async (name: string, dataset_id: string, state: unknown):
  Promise<{ id: string }> =>
  jsonOrThrow(await fetch("/api/sessions", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, dataset_id, state }) }));
export const getSession = async (id: string) =>
  jsonOrThrow(await fetch(`/api/sessions/${id}`));
export const deleteSession = async (id: string) =>
  jsonOrThrow(await fetch(`/api/sessions/${id}`, { method: "DELETE" }));
export const createSnapshot = async (dataset_id: string, state: unknown):
  Promise<{ token: string }> =>
  jsonOrThrow(await fetch("/api/snapshots", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ dataset_id, state }) }));
export const getSnapshot = async (token: string):
  Promise<{ dataset_id: string; state: any }> =>
  jsonOrThrow(await fetch(`/api/snapshots/${token}`));

// ---- v2.2 additions ----
import type { SliceField, VectorField } from "./types";

/** Axis slice at full grid resolution, optionally with in-plane velocity.
 *  `signal` lets the caller abort superseded requests while scrubbing. */
export async function getSliceField(
  id: string, field: string,
  q: { axis: string; position: number; withVectors: boolean; maxDim?: number },
  signal?: AbortSignal,
): Promise<SliceField> {
  const p = new URLSearchParams({
    axis: q.axis, position: String(q.position),
    with_vectors: String(q.withVectors), max_dim: String(q.maxDim ?? 0),
  });
  const r = await fetch(
    `/api/datasets/${id}/preview/slice/${encodeURIComponent(field)}?${p}`, { signal });
  if (!r.ok) throw new Error(r.statusText);
  const meta = JSON.parse(r.headers.get("X-Meta") ?? "{}");
  const buf = await r.arrayBuffer();
  const n = meta.dims[0] * meta.dims[1];
  return {
    dims: meta.dims, origin: meta.origin, spacing: meta.spacing,
    labels: meta.labels, axis: meta.axis, index: meta.index,
    position: meta.position, unit: meta.unit,
    values: new Float32Array(buf, 0, n),
    vecU: meta.vectors ? new Float32Array(buf, n * 4, n) : null,
    vecV: meta.vectors ? new Float32Array(buf, n * 8, n) : null,
  };
}

/** Slice sampled straight from the scattered source — bypasses the grid's
 *  resolution ceiling. Slower than the grid path, so only for fine slices. */
export async function getSliceFieldDirect(
  id: string, field: string,
  q: { axis: string; position: number; withVectors: boolean; res: number;
       mode?: "hifi" | "idw" },
  signal?: AbortSignal,
): Promise<SliceField> {
  const p = new URLSearchParams({
    axis: q.axis, position: String(q.position),
    with_vectors: String(q.withVectors), res: String(q.res),
    mode: q.mode ?? "hifi",
  });
  const r = await fetch(
    `/api/datasets/${id}/preview/slice_direct/${encodeURIComponent(field)}?${p}`,
    { signal });
  if (!r.ok) throw new Error(r.statusText);
  const meta = JSON.parse(r.headers.get("X-Meta") ?? "{}");
  const buf = await r.arrayBuffer();
  const n = meta.dims[0] * meta.dims[1];
  return {
    dims: meta.dims, origin: meta.origin, spacing: meta.spacing,
    labels: meta.labels, axis: meta.axis, index: meta.index,
    position: meta.position, unit: meta.unit,
    values: new Float32Array(buf, 0, n),
    vecU: meta.vectors ? new Float32Array(buf, n * 4, n) : null,
    vecV: meta.vectors ? new Float32Array(buf, n * 8, n) : null,
  };
}

/** Resolution the data can actually support at this plane, plus the numbers
 *  behind it — the UI shows this so "more pixels" isn't mistaken for "more
 *  information". */
export const getSliceNative = async (
  id: string, field: string, axis: string, position: number,
): Promise<{ native_px: number; grid_px: number; slab_points: number;
             point_pitch: number; n_source_points: number }> =>
  jsonOrThrow(await fetch(
    `/api/datasets/${id}/preview/slice_native/${encodeURIComponent(field)}`
    + `?axis=${axis}&position=${position}`));

/** Export the slice currently previewed. */
export const postSliceExport = async (id: string, req: unknown):
  Promise<{ png_url?: string; csv_url?: string; dims: number[];
            fidelity: string }> =>
  post(`/api/datasets/${id}/slices/export`, req);

export async function getPreviewVectors(
  id: string, maxDim: number,
): Promise<VectorField> {
  const r = await fetch(`/api/datasets/${id}/preview/vectors?max_dim=${maxDim}`);
  if (!r.ok) throw new Error(r.statusText);
  const buf = await r.arrayBuffer();
  const m = Math.floor(buf.byteLength / 24); // coords(3) + vectors(3) f32
  return {
    coords: new Float32Array(buf, 0, m * 3),
    vectors: new Float32Array(buf, m * 12, m * 3),
    speedMax: Number(r.headers.get("X-Speed-Max") ?? 0),
  };
}

/** Backend version + which frontend bundle the server is actually serving.
 *  Shown in the status bar so a stale UI is visible at a glance. */
export const getVersion = async (): Promise<
  { version: string; frontend_dir: string | null; frontend_bundle: string | null }
> => jsonOrThrow(await fetch("/api/version"));
