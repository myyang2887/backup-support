/** Bottom telemetry strip: dataset facts left, live cursor mirror right. */
import { useFeature } from "../features";
import { useEffect, useState } from "react";
import { getVersion } from "../api";
import { useStore } from "../store";

/** Which build is on screen — the answer to "did my upgrade take effect?". */
function BuildStamp() {
  const [v, setV] = useState<string>("");
  useEffect(() => {
    getVersion()
      .then((r) => setV(`v${r.version} · ${r.frontend_bundle ?? "no bundle"}`))
      .catch(() => setV(""));
  }, []);
  if (!v) return null;
  return (
    <span className="mono" title="バックエンド版数 / 実際に配信されているUIバンドル"
          style={{ marginLeft: 12, color: "var(--text-faint)", fontSize: 10 }}>
      {v}
    </span>
  );
}

export default function StatusBar() {
  const { meta, cursorInfo, activeField } = useStore();
  if (!useFeature("shell.statusbar")) return null;
  return (
    <div className="mono"
         style={{ height: 26, display: "flex", alignItems: "center", gap: 16,
                  padding: "0 12px", fontSize: 11, background: "var(--bg-1)",
                  borderTop: "1px solid var(--line)",
                  color: "var(--text-dim)" }}>
      {meta ? (
        <>
          <span>{(meta.source_path.split(/[\\/]/).pop() ?? "")}</span>
          <span>grid {meta.dims?.join("×")}</span>
          <span>
            流体 <span style={{ color: "var(--ok)" }}>{meta.meta?.n_fluid}</span>
            {" / 固体 "}
            <span style={{ color: "var(--warn)" }}>{meta.meta?.n_solid}</span>
          </span>
          <span>判定 {meta.meta?.fluid_rule_used}</span>
          <span>{meta.meta?.interp_method}</span>
        </>
      ) : (
        <span>データ未読込</span>
      )}
      <span style={{ flex: 1 }} />
      {cursorInfo && (
        <span style={{ color: "var(--text)" }}>
          X {cursorInfo.x.toFixed(5)}  Y {cursorInfo.y.toFixed(5)}
          {"  Z "}{cursorInfo.z.toFixed(5)}
          {"   "}{activeField}{" "}
          <span style={{ color: cursorInfo.solid ? "var(--warn)" : "var(--accent)" }}>
            {cursorInfo.solid ? "固体"
              : cursorInfo.value !== null ? cursorInfo.value.toPrecision(5) : "---"}
          </span>
        </span>
      )}
      <BuildStamp />
    </div>
  );
}
