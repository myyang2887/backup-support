"""Global configuration (env prefix FDPOST_) and resource path helpers."""
from __future__ import annotations

import sys
from pathlib import Path

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Global settings. Override via environment variables, e.g. FDPOST_CACHE_DIR."""

    data_dir: Path = Path("./data")
    cache_dir: Path = Path("./cache")
    output_dir: Path = Path("./output")
    preview_res: int = 128
    max_export_rows: int = 5_000_000
    default_interp: str = "idw"
    host: str = "127.0.0.1"
    port: int = 8000
    job_workers: int = 2
    grid_lru_size: int = 3
    point_cloud_cap: int = 80_000
    vector_glyph_dim: int = 22        # lattice max_dim for 3D arrows
    vector_glyph_cap: int = 24_000    # hard cap on arrow instances
    source_sampler_lru: int = 2       # datasets kept fitted for hi-res slices
    slice_direct_max_px: int = 1200   # per-axis cap on a direct slice

    model_config = {"env_prefix": "FDPOST_"}


settings = Settings()


def ensure_dirs() -> None:
    """Create data/cache/output directories (exist_ok)."""
    for d in (settings.data_dir, settings.cache_dir, settings.output_dir):
        Path(d).mkdir(parents=True, exist_ok=True)


def frontend_dist() -> Path | None:
    """Locate the built UI, newest-install-wins order:

    1. PyInstaller bundle
    2. inside the installed package (fdpost/web) — what `pip install` ships
    3. next to the executable (onedir builds)
    4. the source tree (dev: repo_root/frontend/dist)

    Returning the packaged copy first is what stops a stale checkout from
    shadowing a freshly installed UI.
    """
    here = Path(__file__).resolve().parent
    candidates = []
    if hasattr(sys, "_MEIPASS"):
        candidates.append(Path(sys._MEIPASS) / "frontend/dist")  # type: ignore[attr-defined]
    candidates += [
        here / "web",
        Path(sys.argv[0]).resolve().parent / "frontend/dist",
        here.parents[1] / "frontend/dist",
    ]
    for c in candidates:
        if (c / "index.html").is_file():
            return c
    return None


def resource_path(rel: str) -> Path:
    """Locate bundled resources in dev and frozen (PyInstaller) environments."""
    if hasattr(sys, "_MEIPASS"):  # PyInstaller onefile
        return Path(sys._MEIPASS) / rel  # type: ignore[attr-defined]
    exe_dir = Path(sys.argv[0]).resolve().parent
    if (exe_dir / rel).exists():  # onedir: next to the executable
        return exe_dir / rel
    # dev: project root = three levels above this file (src/fdpost/config.py)
    return Path(__file__).resolve().parents[2] / rel
