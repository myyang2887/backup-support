"""Geometry request models, PreprocessConfig, FluidRule (Pydantic v2)."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, model_validator

Vec3 = tuple[float, float, float]


class FluidRule(BaseModel):
    """Explicit fluid/solid classification override (mode='auto' -> classifier chain)."""

    mode: Literal["auto", "field_present", "field_threshold",
                  "label_column", "all_fluid"] = "auto"
    field: str | None = None
    threshold: float | None = None
    comparison: Literal["gt", "ge", "lt", "le", "ne"] | None = None
    label_column: str | None = None
    fluid_values: list[str] = []

    @model_validator(mode="after")
    def _check(self) -> FluidRule:
        if self.mode == "field_present" and not self.field:
            raise ValueError("field_present requires 'field'")
        if self.mode == "field_threshold" and not (
            self.field and self.threshold is not None and self.comparison
        ):
            raise ValueError("field_threshold requires field/threshold/comparison")
        if self.mode == "label_column" and not self.label_column:
            raise ValueError("label_column requires 'label_column'")
        return self


class PreprocessConfig(BaseModel):
    method: str = "idw"
    spacing: float | None = Field(default=None, gt=0)
    target_dims: int | None = Field(default=None, ge=8, le=1024)
    fields: list[str] | None = None
    interp_params: dict = {}
    fluid_rule: FluidRule = FluidRule()


class BatchFidelity(BaseModel):
    """Shared batch quality knobs.

    Batch output is an archival deliverable, not a live preview, so the
    default is the highest fidelity: sampled from the source scatter at a
    resolution the data can actually support, with smooth shading.
    """

    fidelity: Literal["grid", "scatter"] = "scatter"
    sample_px: int | None = None       # None = use the data's native detail
    smooth: bool = True


class AxisSliceBatch(BatchFidelity):
    axis: Literal["x", "y", "z"]
    start: float
    stop: float
    step: float = Field(gt=0)
    field: str = "velocity_magnitude"
    clim: tuple[float, float] | None = None
    cmap: str = "jet"
    with_vectors: bool = False
    vector_stride: int = Field(default=8, ge=1)
    dpi: int = 150

    @model_validator(mode="after")
    def _check(self) -> AxisSliceBatch:
        if self.stop < self.start:
            raise ValueError("stop must be >= start")
        if (self.stop - self.start) / self.step + 1 > 10000:
            raise ValueError("too many slices (>10000)")
        return self


class PlaneGeometry(BaseModel):
    """How an arbitrary-orientation plane is specified: point+normal, or the
    requirement書 form (XY平面からの回転角度 + 方位角 + その平面からの距離).

    Shared by every plane use-case — PNG rendering (PlaneSliceRequest) and
    CSV export (PlaneRegionRequest) — so both accept identical geometry.
    """

    mode: Literal["axis", "point_normal", "euler"] = "point_normal"
    origin: Vec3 | None = None
    normal: Vec3 | None = None
    tilt_deg: float | None = None
    azimuth_deg: float | None = None
    distance: float | None = None
    extent_u: tuple[float, float] | None = None
    extent_v: tuple[float, float] | None = None

    @model_validator(mode="after")
    def _check_geometry(self) -> PlaneGeometry:
        if self.mode == "axis":          # axis slices carry their own fields
            return self
        if self.mode == "point_normal":
            if self.origin is None or self.normal is None:
                raise ValueError("point_normal mode requires origin and normal")
            if all(abs(c) < 1e-15 for c in self.normal):
                raise ValueError("normal must be non-zero")
        else:
            if self.tilt_deg is None or self.azimuth_deg is None or self.distance is None:
                raise ValueError("euler mode requires tilt_deg/azimuth_deg/distance")
        return self


class PlaneSliceRequest(PlaneGeometry):
    """Plane slice rendered to PNG. `resolution` is in pixels."""

    resolution: tuple[int, int] = (400, 400)
    field: str = "velocity_magnitude"
    clim: tuple[float, float] | None = None
    cmap: str = "jet"
    with_vectors: bool = False
    vector_stride: int = Field(default=8, ge=1)
    dpi: int = 150


class PlaneSliceBatch(PlaneSliceRequest, BatchFidelity):
    """Batch of plane slices stepped along the normal by distance."""

    distance_start: float = 0.0
    distance_stop: float = 0.0
    distance_step: float = Field(default=1.0, gt=0)


class LineProbeRequest(BaseModel):
    p0: Vec3
    p1: Vec3
    n_samples: int = Field(default=200, ge=2, le=100_000)
    fields: list[str] = ["pressure"]

    @model_validator(mode="after")
    def _check(self) -> LineProbeRequest:
        if tuple(self.p0) == tuple(self.p1):
            raise ValueError("p0 and p1 must differ")
        return self


class BoxRegionRequest(BaseModel):
    """3D box -> CSV. Resolution per axis as point counts (`resolution`) or as
    physical steps (`spacing`, 何mm間隔); exactly one of the two."""

    min_point: Vec3
    max_point: Vec3
    resolution: tuple[int, int, int] | None = None
    spacing: Vec3 | None = None
    fields: list[str] | None = None

    @model_validator(mode="after")
    def _check(self) -> BoxRegionRequest:
        if (self.resolution is None) == (self.spacing is None):
            raise ValueError("give exactly one of resolution / spacing")
        for i in range(3):
            if self.max_point[i] < self.min_point[i]:
                raise ValueError(f"max_point[{i}] < min_point[{i}]")
            if self.spacing is not None:
                if self.spacing[i] <= 0:
                    raise ValueError("spacing must be > 0 per axis")
                continue
            if self.resolution[i] < 1:  # type: ignore[index]
                raise ValueError("resolution must be >= 1 per axis")
            if (self.max_point[i] == self.min_point[i]
                    and self.resolution[i] != 1):  # type: ignore[index]
                raise ValueError(f"axis {i} degenerate: resolution must be 1")
        return self


class SliceExportRequest(PlaneGeometry):
    """Export the currently previewed slice as PNG and/or CSV.

    `fidelity` picks the data source: "grid" reads the preprocessed volume
    (instant, capped at the grid resolution); "scatter" triangulates the
    source points near the plane (not capped, true linear gradients).
    """

    mode: Literal["axis", "point_normal", "euler"] = "axis"   # type: ignore[assignment]
    axis: Literal["x", "y", "z"] = "z"
    position: float = 0.0
    field: str = "velocity_magnitude"
    resolution: int = Field(default=512, ge=16, le=4096)
    fidelity: Literal["grid", "scatter"] = "scatter"
    formats: list[Literal["png", "csv"]] = ["png"]
    with_vectors: bool = False
    smooth: bool = True
    cmap: str = "jet"
    dpi: int = Field(default=150, ge=50, le=600)

    @model_validator(mode="after")
    def _check_export(self) -> SliceExportRequest:
        if not self.formats:
            raise ValueError("choose at least one output format")
        return self


class PlaneRegionRequest(PlaneGeometry):
    """断面 (plane) -> CSV at a chosen in-plane resolution.

    Requirement書 3項:「指定した領域(断面)について、指定した解像度でのcsv出力…
    何mm間隔、xy方向で別々に指定したい」. `spacing` is the in-plane step
    (u, v) in metres; `resolution` is the point-count alternative.
    """

    resolution: tuple[int, int] | None = None
    spacing: tuple[float, float] | None = None
    fields: list[str] | None = None

    @model_validator(mode="after")
    def _check_sampling(self) -> PlaneRegionRequest:
        if (self.resolution is None) == (self.spacing is None):
            raise ValueError("give exactly one of resolution / spacing")
        if self.spacing is not None and any(s <= 0 for s in self.spacing):
            raise ValueError("spacing must be > 0 per in-plane axis")
        if self.resolution is not None and any(r < 1 for r in self.resolution):
            raise ValueError("resolution must be >= 1 per in-plane axis")
        return self


class StreamlineRequest(BaseModel):
    """Rake of seeds on segment p0-p1, integrated through the velocity field."""

    p0: Vec3
    p1: Vec3
    n_seeds: int = Field(default=30, ge=1, le=500)
    max_steps: int = Field(default=400, ge=10, le=5000)
    step_scale: float = Field(default=0.75, gt=0, le=5.0)
    direction: Literal["forward", "backward", "both"] = "both"


class SessionIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    dataset_id: str
    state: dict


class SnapshotIn(BaseModel):
    dataset_id: str
    state: dict
