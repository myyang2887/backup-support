"""High-quality 2D slice PNG rendering (matplotlib, headless)."""
from __future__ import annotations

from pathlib import Path

import numpy as np

from fdpost.core.query import Slice2D
from fdpost.render.style import apply_style, make_cmap


def compute_global_clim(slabs: list[np.ndarray]) -> tuple[float, float]:
    """NaN-ignoring global (vmin, vmax) across a batch for a shared colorbar."""
    lo = min(float(np.nanmin(s)) for s in slabs if np.isfinite(s).any())
    hi = max(float(np.nanmax(s)) for s in slabs if np.isfinite(s).any())
    if lo == hi:
        hi = lo + 1e-12
    return lo, hi


def render_slice_png(sl: Slice2D, path: str | Path,
                     clim: tuple[float, float] | None = None,
                     cmap: str = "jet", dpi: int = 150,
                     vector_stride: int = 8, smooth: bool = False) -> Path:
    """`smooth` uses gouraud shading: cells are interpolated instead of drawn
    as flat rectangles. On a fine slice this is the difference between visible
    stair-steps and continuous gradients."""
    apply_style()
    import matplotlib.pyplot as plt

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    du = float(sl.u[-1] - sl.u[0]) or 1.0
    dv = float(sl.v[-1] - sl.v[0]) or 1.0
    if du >= dv:
        figsize = (9.0, max(3.0, 7.0 * dv / du + 1.2))
    else:
        figsize = (max(4.0, 7.0 * du / dv + 1.8), 8.0)
    fig, ax = plt.subplots(figsize=figsize)
    vmin, vmax = clim if clim else compute_global_clim([sl.values])
    # values[iu,iv] -> pcolormesh expects (nv,nu): transpose
    mesh = ax.pcolormesh(sl.u, sl.v, sl.values.T, cmap=make_cmap(cmap),
                         vmin=vmin, vmax=vmax,
                         shading="gouraud" if smooth else "nearest")
    if sl.vec_u is not None and sl.vec_v is not None:
        s = max(1, int(vector_stride))
        gu, gv = np.meshgrid(sl.u[::s], sl.v[::s], indexing="ij")
        ax.quiver(gu, gv, sl.vec_u[::s, ::s], sl.vec_v[::s, ::s],
                  color="white", width=0.0022, scale_units="width")
    ax.set_xlabel(sl.u_label); ax.set_ylabel(sl.v_label)
    ax.set_title(sl.title, fontsize=10)
    ax.set_aspect("equal", adjustable="box")
    unit = f" [{sl.unit}]" if sl.unit else ""
    fig.colorbar(mesh, ax=ax, label=f"{sl.field}{unit}")
    fig.savefig(path, dpi=dpi)
    plt.close(fig)
    return path


def render_slice_batch(slices: list[Slice2D], out_dir: str | Path, axis: str,
                       positions: np.ndarray,
                       clim: tuple[float, float] | None = None,
                       cmap: str = "jet", dpi: int = 150,
                       vector_stride: int = 8,
                       progress=None, smooth: bool = False) -> list[Path]:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if clim is None:
        clim = compute_global_clim([s.values for s in slices])
    paths = []
    for i, (sl, pos) in enumerate(zip(slices, positions)):
        p = out_dir / f"slice_{axis}_{i:04d}_{pos:+.6f}m.png"
        render_slice_png(sl, p, clim=clim, cmap=cmap, dpi=dpi,
                         vector_stride=vector_stride, smooth=smooth)
        paths.append(p)
        if progress:
            progress((i + 1) / len(slices), f"rendered {p.name}")
    return paths
