"""Region CSV endpoints: 3D box and plane (断面) at a chosen resolution."""
from __future__ import annotations

from fastapi import APIRouter, Request

from fdpost.api.urlize import add_urls
from fdpost.domain.requests import BoxRegionRequest, PlaneRegionRequest

router = APIRouter(prefix="/api/datasets/{ds_id}", tags=["regions"])


@router.post("/region")
def region(ds_id: str, req: BoxRegionRequest, request: Request):
    res = request.app.state.region_service.run_box(ds_id, req)
    return add_urls(res, request.app.state.settings.output_dir)


@router.post("/region/plane")
def region_plane(ds_id: str, req: PlaneRegionRequest, request: Request):
    res = request.app.state.region_service.run_plane(ds_id, req)
    return add_urls(res, request.app.state.settings.output_dir)
