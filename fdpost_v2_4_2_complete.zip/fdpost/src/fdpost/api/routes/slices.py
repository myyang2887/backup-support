from __future__ import annotations

from fastapi import APIRouter, Request

from fdpost.api.schemas import JobOut
from fdpost.api.urlize import add_urls
from fdpost.domain.requests import SliceExportRequest, AxisSliceBatch, PlaneSliceBatch, PlaneSliceRequest

router = APIRouter(prefix="/api/datasets/{ds_id}/slices", tags=["slices"])


@router.post("/axis-batch", response_model=JobOut)
def axis_batch(ds_id: str, req: AxisSliceBatch, request: Request):
    svc = request.app.state.slice_service
    job = request.app.state.jobs.submit(
        "axis_slice_batch", lambda report: svc.run_axis_batch(ds_id, req, report))
    return job.snapshot()


@router.post("/plane", )
def plane(ds_id: str, req: PlaneSliceRequest, request: Request):
    """Single arbitrary plane: synchronous (~100ms) for interactive use."""
    res = request.app.state.slice_service.run_plane_slice(ds_id, req)
    return add_urls(res, request.app.state.settings.output_dir)


@router.post("/plane-batch", response_model=JobOut)
def plane_batch(ds_id: str, req: PlaneSliceBatch, request: Request):
    svc = request.app.state.slice_service
    job = request.app.state.jobs.submit(
        "plane_slice_batch", lambda report: svc.run_plane_batch(ds_id, req, report))
    return job.snapshot()


@router.post("/export")
def slice_export(ds_id: str, req: SliceExportRequest, request: Request):
    """Export the slice currently on screen at a chosen resolution/fidelity."""
    res = request.app.state.slice_export_service.run(ds_id, req)
    return add_urls(res, request.app.state.settings.output_dir)
