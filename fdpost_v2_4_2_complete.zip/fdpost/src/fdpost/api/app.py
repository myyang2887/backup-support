"""FastAPI application factory."""
from __future__ import annotations

import logging
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from fdpost.config import (Settings, ensure_dirs, frontend_dist,
                            resource_path)
from fdpost.domain.errors import (DataLoadError, FdPostError,
                                  FieldNotFoundError, GridBuildError,
                                  JobNotFoundError, RegionTooLargeError)
from fdpost.io.registry import Registry
from fdpost.services.dataset_store import DatasetStore
from fdpost.services.jobs import JobManager
from fdpost.services.probe_service import ProbeService
from fdpost.services.region_service import RegionService
from fdpost.services.slice_export_service import SliceExportService
from fdpost.services.slice_service import SliceService

log = logging.getLogger("fdpost.api")

try:                                   # installed distribution
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("fdpost")
except Exception:                      # running straight from a source tree
    __version__ = "dev"

_STATUS = {JobNotFoundError: 404, FieldNotFoundError: 404,
           RegionTooLargeError: 413, DataLoadError: 400, GridBuildError: 400}


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings()
    ensure_dirs.__globals__["settings"] = settings  # keep helper consistent
    for d in (settings.data_dir, settings.cache_dir, settings.output_dir):
        Path(d).mkdir(parents=True, exist_ok=True)

    app = FastAPI(title="fdpost", version="2.0.0")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
        allow_methods=["*"], allow_headers=["*"],
    )

    jobs = JobManager(workers=settings.job_workers)
    registry = Registry(Path(settings.data_dir) / "fdpost.db")
    store = DatasetStore(settings, jobs, registry=registry)
    app.state.settings = settings
    app.state.registry = registry
    app.state.jobs = jobs
    app.state.store = store
    app.state.slice_service = SliceService(store, settings)
    app.state.slice_export_service = SliceExportService(store, settings)
    app.state.probe_service = ProbeService(store, settings)
    app.state.region_service = RegionService(store, settings)

    @app.exception_handler(FdPostError)
    async def fdpost_error(request: Request, exc: FdPostError):
        status = next((s for t, s in _STATUS.items() if isinstance(exc, t)), 400)
        return JSONResponse(status_code=status,
                            content={"detail": f"{type(exc).__name__}: {exc}"})

    from fdpost.api.routes import (datasets, files, jobs as jobs_r, preview,
                                   probes, regions, sessions, slices, viz3d)
    for r in (datasets, preview, slices, probes, regions, jobs_r, files,
              viz3d, sessions):
        app.include_router(r.router)

    @app.get("/api/health")
    def health():
        return {"status": "ok", "version": "2.0.0"}

    @app.get("/api/version", tags=["meta"])
    def version() -> dict[str, str | None]:
        """Backend version + which frontend build is actually being served.
        If the UI looks unchanged after an upgrade, compare these."""
        d = frontend_dist()
        bundle = None
        if d is not None:
            js = sorted((d / "assets").glob("index-*.js")) if (d / "assets").is_dir() else []
            bundle = js[0].name if js else None
        return {"version": __version__, "frontend_dir": str(d) if d else None,
                "frontend_bundle": bundle}

    dist = frontend_dist()
    if dist is not None:
        # index.html must never be cached: the asset filenames are hashed, so
        # a cached index keeps pointing at the previous build's bundle and the
        # UI looks unchanged after an upgrade.
        class NoCacheIndex(StaticFiles):
            def is_not_modified(self, response_headers, request_headers) -> bool:
                if response_headers.get("content-type", "").startswith("text/html"):
                    return False
                return super().is_not_modified(response_headers, request_headers)

        app.mount("/", NoCacheIndex(directory=dist, html=True), name="frontend")
        log.info("serving frontend from %s", dist)
    else:
        log.warning("no built frontend found — run `npm run build` in frontend/")

    @app.on_event("shutdown")
    def _shutdown():
        jobs.shutdown()

    return app
def __getattr__(name: str):
    """Build the ASGI app lazily, on first attribute access.

    `uvicorn fdpost.api.app:app` resolves the target with getattr, so this
    still works — but merely *importing* this module no longer constructs an
    app, and therefore no longer creates data/cache/output in the current
    working directory as a side effect of an import.
    """
    if name == "app":
        instance = create_app()
        globals()["app"] = instance          # build once, then cache
        return instance
    raise AttributeError(name)
