"""Export the slice you are currently previewing: PNG and/or CSV.

Two fidelity levels, deliberately explicit rather than automatic:

  grid    — read the preprocessed uniform grid. Instant, but capped at the
            grid resolution chosen during preprocessing.
  scatter — gather the source points near the plane and triangulate them in
            2D. Costs a re-read of the source file on first use, but is not
            bound by the grid and produces true linear gradients.

The same two levels back the interactive preview, so what you export is what
you were looking at.
"""
from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any

import numpy as np

from fdpost.config import Settings
from fdpost.core.query import (AXIS_INDEX, IN_PLANE, Slice2D, resolve_plane,
                               plane_frame, slice_axis)
from fdpost.domain.requests import SliceExportRequest
from fdpost.io.csv_writer import write_csv
from fdpost.render.contour import render_slice_png
from fdpost.services.dataset_store import DatasetStore


class SliceExportService:
    def __init__(self, store: DatasetStore, settings: Settings) -> None:
        self.store = store
        self.settings = settings

    # -- sampling ------------------------------------------------------------
    def _sample_scatter(self, ds_id: str, req: SliceExportRequest,
                        grid) -> Slice2D:
        sampler = self.store.get_sampler(ds_id)
        lo, hi = grid.bounds
        if req.mode == "axis":
            ai = AXIS_INDEX[req.axis]
            ua, va = IN_PLANE[req.axis]
            ui, vi = AXIS_INDEX[ua], AXIS_INDEX[va]
            origin = grid.bounds.mean(axis=0).copy()
            origin[ai] = float(np.clip(req.position, lo[ai], hi[ai]))
            normal = np.zeros(3); normal[ai] = 1.0
            u_hat = np.zeros(3); u_hat[ui] = 1.0
            v_hat = np.zeros(3); v_hat[vi] = 1.0
            eu = (float(lo[ui] - origin[ui]), float(hi[ui] - origin[ui]))
            ev = (float(lo[vi] - origin[vi]), float(hi[vi] - origin[vi]))
            labels = (f"{ua.upper()} [m]", f"{va.upper()} [m]")
            title = f"{req.axis.upper()} = {origin[ai]:.5f} m"
        else:
            origin, normal = resolve_plane(req, grid)
            fr = plane_frame(grid, origin, normal)
            u_hat, v_hat = fr.u_hat, fr.v_hat
            eu, ev = fr.extent_u, fr.extent_v
            labels = ("u [m]", "v [m]")
            title = (f"tilt {req.tilt_deg:g}deg  azimuth {req.azimuth_deg:g}deg"
                     f"  distance {req.distance:g} m")

        nu, nv = _shape_for(req.resolution, eu, ev,
                            self.settings.slice_direct_max_px)
        u = np.linspace(eu[0], eu[1], nu)
        v = np.linspace(ev[0], ev[1], nv)
        gu, gv = np.meshgrid(u, v, indexing="ij")
        uv = np.column_stack([gu.ravel(), gv.ravel()])

        vec_names = (f"velocity_{'xyz'[AXIS_INDEX[req.axis]]}",)  # placeholder
        wanted = [req.field]
        want_vec = req.with_vectors and all(
            f"velocity_{c}" in sampler.fd.fields for c in "xyz")
        if want_vec:
            wanted += ["velocity_x", "velocity_y", "velocity_z"]
        slab = sampler.plane_slab(origin, normal, u_hat, v_hat, fields=wanted)
        itp = sampler.plane_interpolator(slab)
        solid = itp.solid(uv).reshape(nu, nv)

        def grab(name: str) -> np.ndarray:
            a = itp.sample(name, uv).reshape(nu, nv)
            a[solid] = np.nan
            return a

        values = grab(req.field)
        vu = vv = None
        if want_vec:
            vx, vy, vz = (grab(f"velocity_{c}") for c in "xyz")
            vec = np.stack([vx, vy, vz], axis=-1)
            vu = vec @ u_hat
            vv = vec @ v_hat
        return Slice2D(u=u + (u_hat @ origin), v=v + (v_hat @ origin),
                       values=values, u_label=labels[0], v_label=labels[1],
                       field=req.field, unit=grid.units.get(req.field, ""),
                       title=f"{title}   [source scatter, {nu}x{nv}]",
                       vec_u=vu, vec_v=vv, solid=solid)

    def _sample_grid(self, ds_id: str, req: SliceExportRequest, grid) -> Slice2D:
        if req.mode != "axis":
            raise ValueError("grid fidelity supports axis slices; "
                             "use fidelity='scatter' for a free plane")
        return slice_axis(grid, req.axis, req.position, req.field,
                          with_vectors=req.with_vectors)

    # -- entry point ---------------------------------------------------------
    def run(self, ds_id: str, req: SliceExportRequest) -> dict[str, Any]:
        grid = self.store.get_grid(ds_id)
        sl = (self._sample_scatter(ds_id, req, grid) if req.fidelity == "scatter"
              else self._sample_grid(ds_id, req, grid))

        out = Path(self.settings.output_dir) / f"slice_{uuid.uuid4().hex[:8]}"
        out.mkdir(parents=True, exist_ok=True)
        res: dict[str, Any] = {"dims": [int(sl.values.shape[0]),
                                        int(sl.values.shape[1])],
                               "fidelity": req.fidelity}
        if "png" in req.formats:
            res["png"] = str(render_slice_png(
                sl, out / "slice.png", cmap=req.cmap, dpi=req.dpi,
                vector_stride=max(1, min(sl.values.shape) // 24),
                smooth=req.smooth))
        if "csv" in req.formats:
            gu, gv = np.meshgrid(sl.u, sl.v, indexing="ij")
            data = {"u_m": gu.ravel(), "v_m": gv.ravel(),
                    sl.field: sl.values.ravel()}
            if sl.vec_u is not None and sl.vec_v is not None:
                data["vec_u"] = sl.vec_u.ravel()
                data["vec_v"] = sl.vec_v.ravel()
            if sl.solid is not None:
                data["is_solid"] = sl.solid.ravel().astype(int)
            import pandas as pd
            res["csv"] = str(write_csv(pd.DataFrame(data), out / "slice.csv",
                                       units=grid.units))
        return res


def _shape_for(res: int, eu: tuple[float, float], ev: tuple[float, float],
               cap: int) -> tuple[int, int]:
    """Split the pixel budget along the longer in-plane axis, keeping the
    pixels square so the exported image is not distorted."""
    n = int(np.clip(res, 16, cap))
    su, sv = abs(eu[1] - eu[0]), abs(ev[1] - ev[0])
    if su >= sv:
        return n, max(16, int(round(n * sv / max(su, 1e-12))))
    return max(16, int(round(n * su / max(sv, 1e-12)))), n
