"""v2.2: resolution-controlled plane CSV, spacing-based box CSV,
full-resolution slice preview, vector glyph seeds."""
from __future__ import annotations

import json

import numpy as np
import pytest

from fdpost.core.query import lattice_1d, lattice_len, sample_box, sample_plane
from fdpost.domain.errors import RegionTooLargeError
from fdpost.domain.requests import BoxRegionRequest, PlaneRegionRequest


# --- lattice primitive ------------------------------------------------------

def test_lattice_spacing_is_exact():
    a = lattice_1d(0.0, 1.0, spacing=0.3)
    assert np.allclose(np.diff(a), 0.3)          # interval exact, not divided
    assert a[-1] <= 1.0 + 1e-12
    assert len(a) == lattice_len(0.0, 1.0, spacing=0.3)


def test_lattice_count_hits_both_endpoints():
    a = lattice_1d(2.0, 3.0, count=5)
    assert a[0] == 2.0 and a[-1] == 3.0 and len(a) == 5
    assert len(lattice_1d(2.0, 3.0, count=1)) == 1
    assert len(lattice_1d(5.0, 5.0, spacing=0.1)) == 1     # degenerate axis


# --- box region with spacing ------------------------------------------------

def test_sample_box_spacing(grid_idw):
    df = sample_box(grid_idw, (0.2, 0.2, 0.2), (0.8, 0.8, 0.8), None,
                    ["pressure"], max_rows=10**7, spacing=(0.2, 0.2, 0.1))
    assert len(df) == 4 * 4 * 7
    assert np.allclose(np.diff(np.unique(df["x_m"])), 0.2)


def test_sample_box_row_limit_uses_spacing(grid_idw):
    with pytest.raises(RegionTooLargeError):
        sample_box(grid_idw, (0, 0, 0), (1, 1, 1), None, ["pressure"],
                   max_rows=100, spacing=(0.01, 0.01, 0.01))


# --- plane region -----------------------------------------------------------

def test_sample_plane_axis_aligned(grid_idw):
    df = sample_plane(grid_idw, (0.5, 0.5, 0.5), (0, 0, 1), ["pressure"],
                      max_rows=10**7, spacing=(0.05, 0.05))
    assert list(df.columns) == ["u_m", "v_m", "x_m", "y_m", "z_m",
                                "pressure", "is_solid"]
    assert df["z_m"].nunique() == 1               # a plane, not a slab
    assert np.isclose(df["z_m"].iloc[0], 0.5)


def test_sample_plane_tilted_and_limit(grid_idw):
    df = sample_plane(grid_idw, (0.5, 0.5, 0.5), (1, 1, 1), ["pressure"],
                      max_rows=10**7, resolution=(40, 40))
    assert len(df) == 1600
    assert df["pressure"].notna().any()           # the cut hits real data
    with pytest.raises(RegionTooLargeError):
        sample_plane(grid_idw, (0.5, 0.5, 0.5), (0, 0, 1), ["pressure"],
                     max_rows=100, resolution=(400, 400))


# --- request validation -----------------------------------------------------

def test_region_requests_demand_exactly_one_resolution_spec():
    with pytest.raises(ValueError):
        BoxRegionRequest(min_point=(0, 0, 0), max_point=(1, 1, 1))
    with pytest.raises(ValueError):
        BoxRegionRequest(min_point=(0, 0, 0), max_point=(1, 1, 1),
                         resolution=(4, 4, 4), spacing=(0.1, 0.1, 0.1))
    with pytest.raises(ValueError):
        PlaneRegionRequest(mode="euler", tilt_deg=0, azimuth_deg=0, distance=0)
    ok = PlaneRegionRequest(mode="euler", tilt_deg=30, azimuth_deg=10,
                            distance=0.01, spacing=(0.002, 0.002))
    assert ok.resolution is None


# --- API --------------------------------------------------------------------

def test_plane_region_endpoint(api_client, api_dataset):
    c, _ = api_client
    r = c.post(f"/api/datasets/{api_dataset}/region/plane",
               json={"mode": "euler", "tilt_deg": 0, "azimuth_deg": 0,
                     "distance": 0.0, "spacing": [0.05, 0.05],
                     "fields": ["pressure"]})
    assert r.status_code == 200
    j = r.json()
    assert j["n_rows"] > 100 and j["csv_url"].endswith(".csv")
    assert np.allclose(j["normal"], [0, 0, 1], atol=1e-9)

    r = c.post(f"/api/datasets/{api_dataset}/region/plane",
               json={"mode": "point_normal", "origin": [0.5, 0.5, 0.5],
                     "normal": [1, 1, 0], "resolution": [4000, 4000]})
    assert r.status_code == 413


def test_box_region_spacing_endpoint(api_client, api_dataset):
    c, _ = api_client
    r = c.post(f"/api/datasets/{api_dataset}/region",
               json={"min_point": [0.2, 0.2, 0.2], "max_point": [0.4, 0.4, 0.4],
                     "spacing": [0.1, 0.1, 0.1]})
    assert r.status_code == 200 and r.json()["n_rows"] == 27


def test_full_resolution_slice_preview(api_client, api_dataset):
    c, _ = api_client
    r = c.get(f"/api/datasets/{api_dataset}/preview/slice/pressure",
              params={"axis": "z", "position": 0.5, "with_vectors": True})
    assert r.status_code == 200
    meta = json.loads(r.headers["X-Meta"])
    nu, nv = meta["dims"]
    assert meta["axis"] == "z" and meta["labels"] == ["X [m]", "Y [m]"]
    assert meta["vectors"] is True
    # values + vec_u + vec_v, each nu*nv float32
    assert len(r.content) == nu * nv * 4 * 3
    vals = np.frombuffer(r.content, np.float32, count=nu * nv)
    assert np.isnan(vals).any()                   # solid sphere shows as NaN
    assert np.isfinite(vals).any()


def test_slice_preview_beats_point_cloud_resolution(api_client, api_dataset):
    """The drawer preview must not be capped at the downsampled preview grid."""
    c, _ = api_client
    pm = c.get(f"/api/datasets/{api_dataset}/preview/meta").json()
    r = c.get(f"/api/datasets/{api_dataset}/preview/slice/pressure",
              params={"axis": "z", "position": 0.5})
    meta = json.loads(r.headers["X-Meta"])
    assert meta["full_dims"] == pm["full_dims"]


def test_vector_glyph_seeds(api_client, api_dataset):
    c, _ = api_client
    r = c.get(f"/api/datasets/{api_dataset}/preview/vectors", params={"max_dim": 16})
    assert r.status_code == 200
    m = int(r.headers["X-Count"])
    assert m > 0 and len(r.content) == m * 24     # coords(3) + vec(3) f32
    arr = np.frombuffer(r.content, np.float32)
    assert np.isfinite(arr).all()                 # solid/NaN rows filtered out
    assert float(r.headers["X-Speed-Max"]) > 0


# --- v2.2.1 fixes -----------------------------------------------------------

def test_isosurface_is_a_closed_shell(grid_idw):
    """Regression: masking cubes near solid used to punch holes in the mesh.
    A watertight mesh has no edge used by only one triangle."""
    from collections import Counter

    from fdpost.core.isosurface import compute_isosurface, field_range

    lo, hi = field_range(grid_idw, "velocity_magnitude")
    _, faces, _ = compute_isosurface(grid_idw, "velocity_magnitude",
                                     lo + 0.55 * (hi - lo))
    edges: Counter = Counter()
    for a, b, c in faces:
        for e in ((a, b), (b, c), (c, a)):
            edges[tuple(sorted(e))] += 1
    open_edges = sum(1 for v in edges.values() if v == 1)
    assert open_edges == 0, f"{open_edges} open edges -> holes in the surface"


def test_isosurface_smoothing_reduces_roughness(grid_idw):
    """Smoothing should measurably calm the surface, not just change it."""
    from fdpost.core.isosurface import compute_isosurface, field_range

    lo, hi = field_range(grid_idw, "pressure")
    level = 0.5 * (lo + hi)

    def roughness(smooth: float) -> float:
        verts, faces, _ = compute_isosurface(grid_idw, "pressure", level,
                                             smooth=smooth)
        # mean dihedral-ish proxy: spread of face normals against their mean
        v = verts[faces]
        n = np.cross(v[:, 1] - v[:, 0], v[:, 2] - v[:, 0])
        ln = np.linalg.norm(n, axis=1, keepdims=True)
        n = n / np.maximum(ln, 1e-20)
        return float(np.std(n))

    assert roughness(1.2) < roughness(0.0)


def test_dataset_delete(api_client, api_dataset):
    c, tsv = api_client
    with open(tsv, "rb") as f:
        r = c.post("/api/datasets/upload",
                   files={"file": ("throwaway.txt", f, "text/plain")},
                   data={"method": "nearest", "target_dims": "16"})
    ds = r.json()["dataset_id"]
    assert any(d["id"] == ds for d in c.get("/api/datasets").json())

    assert c.delete(f"/api/datasets/{ds}").status_code == 200
    assert not any(d["id"] == ds for d in c.get("/api/datasets").json())
    assert c.get(f"/api/datasets/{ds}").status_code == 404
    # the still-live dataset is untouched
    assert any(d["id"] == api_dataset for d in c.get("/api/datasets").json())


def test_slice_preview_resolution_is_capped_on_request(api_client, api_dataset):
    """max_dim lets the UI trade detail for speed at any time."""
    c, _ = api_client
    dims = {}
    for md in (0, 24):
        r = c.get(f"/api/datasets/{api_dataset}/preview/slice/pressure",
                  params={"axis": "z", "position": 0.5, "max_dim": md})
        dims[md] = json.loads(r.headers["X-Meta"])["dims"]
    assert dims[24][0] <= 24 and dims[24][1] <= 24
    assert dims[0][0] > dims[24][0]


# --- v2.3: slice resolution decoupled from the grid -------------------------

def test_direct_slice_exceeds_grid_resolution(api_client, api_dataset):
    """The whole point: a slice finer than the preprocessing grid."""
    c, _ = api_client
    grid_dims = c.get(f"/api/datasets/{api_dataset}/preview/meta").json()["full_dims"]
    ceiling = max(grid_dims)

    r = c.get(f"/api/datasets/{api_dataset}/preview/slice_direct/pressure",
              params={"axis": "z", "position": 0.5, "res": 256})
    assert r.status_code == 200
    meta = json.loads(r.headers["X-Meta"])
    nu, nv = meta["dims"]
    assert max(nu, nv) == 256 > ceiling          # past the grid ceiling
    assert meta["source"] == "scatter"
    assert meta["n_source_points"] > 0
    assert len(r.content) == nu * nv * 4

    vals = np.frombuffer(r.content, np.float32)
    assert np.isfinite(vals).any()
    assert np.isnan(vals).any()                  # solid sphere still a hole


def test_direct_slice_agrees_with_grid_slice(api_client, api_dataset):
    """Different sampling paths, same physics — they must broadly agree."""
    c, _ = api_client

    def plane(url, params):
        r = c.get(f"/api/datasets/{api_dataset}{url}", params=params)
        m = json.loads(r.headers["X-Meta"])
        nu, nv = m["dims"]
        return np.frombuffer(r.content, np.float32, count=nu * nv), m

    g, _ = plane("/preview/slice/pressure", {"axis": "z", "position": 0.5})
    d, _ = plane("/preview/slice_direct/pressure",
                 {"axis": "z", "position": 0.5, "res": 48})
    gm, dm = np.nanmean(g), np.nanmean(d)
    assert abs(gm - dm) / max(abs(gm), 1e-9) < 0.15


def test_direct_slice_is_capped(api_client, api_dataset):
    c, _ = api_client
    r = c.get(f"/api/datasets/{api_dataset}/preview/slice_direct/pressure",
              params={"axis": "z", "position": 0.5, "res": 99999})
    meta = json.loads(r.headers["X-Meta"])
    assert max(meta["dims"]) <= 1200             # settings.slice_direct_max_px


def test_direct_slice_vectors(api_client, api_dataset):
    c, _ = api_client
    r = c.get(f"/api/datasets/{api_dataset}/preview/slice_direct/velocity_magnitude",
              params={"axis": "y", "position": 0.5, "res": 64,
                      "with_vectors": True})
    meta = json.loads(r.headers["X-Meta"])
    nu, nv = meta["dims"]
    assert meta["vectors"] is True
    assert meta["labels"] == ["X [m]", "Z [m]"]
    assert len(r.content) == nu * nv * 4 * 3


# --- packaging: the UI must actually ship and be findable -------------------

def test_frontend_is_locatable(api_client):
    """Regression: `pip install` used to ship the backend only, so the server
    fell back to whatever frontend/dist sat next to the source tree it was
    launched from — silently serving a stale UI."""
    from fdpost.config import frontend_dist

    d = frontend_dist()
    if d is None:
        pytest.skip("frontend not built in this checkout")
    assert (d / "index.html").is_file()


def test_version_endpoint_reports_served_bundle(api_client):
    c, _ = api_client
    j = c.get("/api/version").json()
    assert "version" in j
    # when a UI is present, the endpoint must name the exact bundle on disk
    if j["frontend_dir"]:
        assert j["frontend_bundle"] and j["frontend_bundle"].endswith(".js")


# --- v2.4: slice fidelity ---------------------------------------------------

def _slice_img(c, ds, params):
    r = c.get(f"/api/datasets/{ds}/preview/slice_direct/pressure", params=params)
    m = json.loads(r.headers["X-Meta"])
    nu, nv = m["dims"]
    return np.frombuffer(r.content, np.float32, count=nu * nv).reshape(nv, nu), m


def _roughness(img):
    """2nd-difference energy: high = plateaued / stair-stepped."""
    a = img[1:-1, 1:-1]
    lap = (img[:-2, 1:-1] + img[2:, 1:-1] + img[1:-1, :-2] + img[1:-1, 2:] - 4 * a)
    return float(np.nanstd(lap) / max(np.nanstd(img), 1e-12))


def test_hifi_slice_is_smoother_than_idw(api_client, api_dataset):
    """The 'fake resolution' complaint: 3D IDW plateaus around each source
    point, so extra pixels add no gradient. Slab + 2D triangulation does."""
    c, _ = api_client
    base = {"axis": "z", "position": 0.5, "res": 256}
    idw, _ = _slice_img(c, api_dataset, {**base, "mode": "idw"})
    hifi, m = _slice_img(c, api_dataset, {**base, "mode": "hifi"})
    assert m["mode"] == "hifi" and m["native_px"] > 0
    # The margin is much wider on real data (0.013 vs 0.037 on a 120k-point
    # export); this fixture is deliberately small, so assert the direction
    # with a threshold the fixture can actually demonstrate.
    assert _roughness(hifi) < _roughness(idw) * 0.9


def test_native_resolution_is_reported(api_client, api_dataset):
    c, _ = api_client
    j = c.get(f"/api/datasets/{api_dataset}/preview/slice_native/pressure",
              params={"axis": "z", "position": 0.5}).json()
    assert j["slab_points"] > 0 and j["point_pitch"] > 0
    assert 16 <= j["native_px"] <= 4096
    assert j["n_source_points"] > j["slab_points"]      # a slab, not the cloud


def test_slice_export_both_formats(api_client, api_dataset):
    c, _ = api_client
    r = c.post(f"/api/datasets/{api_dataset}/slices/export", json={
        "mode": "axis", "axis": "z", "position": 0.5, "field": "pressure",
        "resolution": 320, "fidelity": "scatter", "formats": ["png", "csv"]})
    assert r.status_code == 200
    j = r.json()
    assert j["fidelity"] == "scatter" and max(j["dims"]) == 320
    assert j["png_url"].endswith(".png") and j["csv_url"].endswith(".csv")


def test_slice_export_beats_grid_resolution(api_client, api_dataset):
    """Export must not be capped by the preprocessing grid."""
    c, _ = api_client
    grid_px = max(c.get(f"/api/datasets/{api_dataset}/preview/meta"
                        ).json()["full_dims"])
    r = c.post(f"/api/datasets/{api_dataset}/slices/export", json={
        "mode": "axis", "axis": "z", "position": 0.5, "field": "pressure",
        "resolution": 600, "fidelity": "scatter", "formats": ["png"]})
    assert max(r.json()["dims"]) == 600 > grid_px


def test_batch_defaults_to_high_fidelity():
    from fdpost.domain.requests import AxisSliceBatch

    req = AxisSliceBatch(axis="z", start=0.0, stop=0.1, step=0.05)
    assert req.fidelity == "scatter"     # archival output: fidelity over speed
    assert req.smooth is True
    assert req.sample_px is None         # backend picks from source density


# --- hygiene: imports must not touch the filesystem -------------------------

def test_importing_the_app_module_creates_no_directories(tmp_path, monkeypatch):
    """`app.py` used to build an app at import time with default settings,
    so any import created data/, cache/ and output/ in the working directory.
    A smoke-test session left 70 MB of uploads in the repo that way."""
    import subprocess
    import sys

    r = subprocess.run(
        [sys.executable, "-c", "import fdpost.api.app"],
        cwd=tmp_path, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    stray = [d for d in ("data", "cache", "output") if (tmp_path / d).exists()]
    assert not stray, f"importing created {stray}"


def test_uvicorn_style_attribute_access_still_builds_the_app(tmp_path):
    """The lazy hook must not break `uvicorn fdpost.api.app:app`."""
    import subprocess
    import sys

    r = subprocess.run(
        [sys.executable, "-c",
         "import fdpost.api.app as m; assert m.app is m.app; print(type(m.app).__name__)"],
        cwd=tmp_path, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert "FastAPI" in r.stdout
