"""v3.33：案件の三段構えを、弱いモデルの出力でも動かす。

- 形の違う出力（オブジェクト・数値・入れ子・辞書）を受け取って使う
- 何も使えないときだけ、理由を添えて 1 回やり直す
- 分析できなかった資料は、その資料自身の証拠で書くか「分析できなかった」と書く
- 比較を飛ばした理由を正しく出す
- 「資料ごとの分析」の数値は、その資料自身の原文で確かめる
- 画像の照合：表示の丸め・接頭辞（p・f）・換算
"""
from __future__ import annotations

import json

import pytest

from app import deep_read as D
from app.case_analysis import (CaseFindings, FileAnalysis, coerce_case_findings)
from app.llm_coerce import coerce_flat, to_list, to_text

from tests.test_v332_source_check_and_case_layers import (  # noqa: F401  （fixture も読み込む）
    _CaseLLM, _mixed_case, _run, cfg)


# ----------------------------------------------------------------------
# 出力の形を寄せる
# ----------------------------------------------------------------------

def test_measurement_objects_become_sentences():
    row = {"試料": "PET", "条件": "ポアソン比 0.3", "測定項目": "複合弾性率",
           "値": 3301.129875, "単位": "MPa"}
    assert to_text(row) == "PET（ポアソン比 0.3）：複合弾性率 3301.129875 MPa"
    assert to_text({"sample": "S-1", "value": 2.31, "unit": "GPa"}) == "S-1：2.31 GPa"
    assert to_text({"試料": "A", "最大値": 12, "単位": "nm"}) == "A：最大値 12 nm"
    # 役割の分からないキーは「キー：値」で残す（情報を落とさない）
    assert to_text({"試料": "A", "硬さ": 2.3, "弾性率": 45}) == "試料：A、硬さ：2.3、弾性率：45"


def test_to_list_flattens_any_shape():
    assert to_list([{"sample": "A", "value": 1.5, "unit": "GPa"}, ["x", ["y"]], 5]) == ["A：1.5 GPa", "x", "y", "5"]
    assert to_list("- a\n- b\n") == ["a", "b"]
    assert to_list({"S-1": 2.31, "S-2": 2.47}) == ["S-1：2.31", "S-2：2.47"]


def test_coerce_flat_keeps_usable_fields():
    raw = {"document_type": ["測定結果", "表"], "purpose": None,
           "measurements": [{"試料": "A", "値": 1.5, "単位": "GPa"}, "B：2.0 GPa"],
           "conclusions": "結論A\n結論B", "unknown": 1}
    fa, rep = coerce_flat(raw, FileAnalysis)
    assert fa.measurements == ["A：1.5 GPa", "B：2.0 GPa"]
    assert fa.conclusions == ["結論A", "結論B"] and fa.document_type == "測定結果、表"
    assert any(x.startswith("measurements") for x in rep["fixed"])
    # 1 段包まれていても読む
    fa, _ = coerce_flat({"analysis": {"purpose": "p"}}, FileAnalysis)
    assert fa.purpose == "p"


@pytest.mark.parametrize("raw", [
    {"by_file": [{"file": "a.xlsx", "points": [{"試料": "S-1", "値": 2.31, "単位": "GPa"}]}],
     "comparison": "共通点", "conclusions": ["まとめ"]},
    {"by_file": {"a.xlsx": ["S-1：2.31 GPa"]}, "comparison": ["共通点"],
     "conclusions": {"資料の結論": ["まとめ"]}},
    {"資料ごとの分析": [{"資料名": "a.xlsx", "内容": ["S-1：2.31 GPa"]}],
     "資料間の比較": ["共通点"], "案件としての結論": [{"kind": "資料の結論", "text": "まとめ"}]},
])
def test_findings_in_various_shapes(raw):
    cf, _ = coerce_case_findings(raw)
    assert cf.by_file[0].file == "a.xlsx" and cf.by_file[0].points[0].startswith("S-1")
    assert cf.comparison == ["共通点"] and cf.conclusions[0].text == "まとめ"


# ----------------------------------------------------------------------
# 案件：分析の受け取り・失敗の扱い
# ----------------------------------------------------------------------

class _ObjLLM(_CaseLLM):
    """Gemma4 が実際に返した形：measurements をオブジェクトで返す。"""

    def chat_json(self, **kw):
        if "技術資料を読み" in kw["system"]:
            self.calls.append(kw)
            return {"document_type": "測定結果の表",
                    "measurements": [{"試料": "S-1", "荷重": "500 μN", "測定項目": "硬さ",
                                      "値": 2.31, "単位": "GPa"}],
                    "conclusions": [{"text": "基準を満たす"}]}
        return super().chat_json(**kw)


def test_object_measurements_are_accepted(cfg, tmp_path):
    case = _mixed_case(cfg, tmp_path)
    llm = _ObjLLM(cfg, findings={"by_file": [], "comparison": [], "conclusions": []})
    cdir = _run(cfg, case, llm)
    fa = json.loads((cdir / "case_file_analyses.json").read_text(encoding="utf-8"))["files"]
    assert all(f["status"] == "ok" for f in fa)
    assert fa[0]["analysis"]["measurements"] == ["S-1：硬さ 2.31 GPa、荷重：500 μN"]
    assert "case:compare" in [c.get("tag") for c in llm.calls]          # 比較も走る
    q = json.loads((cdir / "quality_report.json").read_text(encoding="utf-8"))
    assert q["case_layers"]["analysis"] == {**q["case_layers"]["analysis"], "ok": 3, "total": 3}


class _FailLLM(_CaseLLM):
    """分析は毎回 JSON にならない。比較・判明した事実は普通に返す。"""

    def __init__(self, cfg, *, fail_files=None, findings=None):
        super().__init__(cfg, findings=findings)
        self.fail_files = fail_files            # None = すべて失敗

    def chat_json(self, **kw):
        if "技術資料を読み" in kw["system"]:
            self.calls.append(kw)
            if self.fail_files is None or any(f in kw["user"] for f in self.fail_files):
                raise ValueError("JSON が読めません")
            return {"document_type": "資料", "conclusions": ["資料の結論"]}
        return super().chat_json(**kw)


def test_all_analyses_failed_is_reported_honestly(cfg, tmp_path):
    case = _mixed_case(cfg, tmp_path)
    files = [m["rel_in_case"] for m in case["members"]]
    llm = _FailLLM(cfg, findings={"by_file": [], "comparison": [], "conclusions": []})
    cdir = _run(cfg, case, llm)
    tags = [c.get("tag", "") for c in llm.calls]
    # 1 件につき 2 回（やり直し 1 回）、やり直しには前回の問題を添える
    assert sum(t.startswith("case:analyze") for t in tags) == 2 * len(files)
    retry = [c for c in llm.calls if c.get("tag", "").endswith(":retry")][0]
    assert "前回の出力について" in retry["user"] and "JSON として読めませんでした" in retry["user"]
    # 分析が無くても、各資料の証拠を材料にして比較は行う（資料が 1 件と誤って言わない）
    cmp_call = [c for c in llm.calls if c.get("tag") == "case:compare"]
    assert cmp_call and "本文から抜き出した証拠を渡します" in cmp_call[0]["user"]
    # 判明した事実の材料に要約の下書きは入れない
    fnd = [c for c in llm.calls if c.get("tag") == "case:findings"][0]
    assert "下書き" not in fnd["user"]
    md = (cdir / "case_summary.md").read_text(encoding="utf-8")
    sec = md[md.index("## 調査"):md.index("## 対応効果")]
    for f in files:
        assert f"『{f}』" in sec
    q = json.loads((cdir / "quality_report.json").read_text(encoding="utf-8"))
    assert q["content_status"] == "要確認"
    assert q["warnings"][0].startswith(f"資料ごとの分析ができたのは 0/{len(files)} 件です")


def test_comparison_skip_reason_is_true(cfg, tmp_path):
    """内容を取り出せた資料が 1 件しか無いときは、その理由を出す（「資料が 1 件」ではない）。"""
    case = _mixed_case(cfg, tmp_path)
    llm = _FailLLM(cfg, findings={"by_file": [], "comparison": [], "conclusions": []})
    from app import case_analysis as CA
    real = CA.make_case_analysis_nodes

    def no_evidence(config, l):
        nodes = real(config, l)
        inner = nodes["analyze_files"]

        def wrapped(state):
            out = inner(state)
            # 証拠も無い状態（スキャン PDF だけの案件など）を再現する
            for a in out["file_analyses"]:
                a.pop("fallback_evidence", None)
            out["aggregated_evidence"] = []
            return out
        nodes["analyze_files"] = wrapped
        return nodes

    CA.make_case_analysis_nodes = no_evidence
    try:
        cdir = _run(cfg, case, llm)
    finally:
        CA.make_case_analysis_nodes = real
    rep = json.loads((cdir / "case_comparison.json").read_text(encoding="utf-8"))
    assert rep["ran"] is False and "資料ごとの分析 0/3 件" in rep["reason"]
    md = (cdir / "case_summary.md").read_text(encoding="utf-8")
    assert "この資料は分析できませんでした" in md
    q = json.loads((cdir / "quality_report.json").read_text(encoding="utf-8"))
    assert any(w.startswith("資料間の比較を行えませんでした") for w in q["warnings"])


def test_partial_failure_uses_that_files_evidence(cfg, tmp_path):
    case = _mixed_case(cfg, tmp_path)
    llm = _FailLLM(cfg, fail_files=["測定結果.xlsx"],
                   findings={"by_file": [], "comparison": [], "conclusions": []})
    cdir = _run(cfg, case, llm)
    fa = json.loads((cdir / "case_file_analyses.json").read_text(encoding="utf-8"))["files"]
    st = {f["file"]: f["status"] for f in fa}
    assert st["測定結果.xlsx"] == "failed" and list(st.values()).count("ok") == 2
    # 失敗した資料の材料は、その資料の証拠だけ
    xl = [f for f in fa if f["file"] == "測定結果.xlsx"][0]
    assert xl["fallback_evidence"]
    q = json.loads((cdir / "quality_report.json").read_text(encoding="utf-8"))
    assert "2/3 件" in q["warnings"][0] and "『測定結果.xlsx』" in q["warnings"][0]


def test_findings_numbers_are_checked_against_own_file(cfg, tmp_path):
    """別の資料にしか無い数値を、ある資料の記述として書いたら外す。"""
    case = _mixed_case(cfg, tmp_path)
    llm = _CaseLLM(cfg, findings={
        "by_file": [{"file": "メモ.md", "points": ["S-2 の硬さは 2.47 GPa"]},          # 他の資料の値
                    {"file": "測定結果.xlsx", "points": ["S-2：硬さ 2.47 GPa"]}],
        "comparison": ["S-2 の硬さ 2.47 GPa は報告書と測定結果で一致"], "conclusions": []})
    cdir = _run(cfg, case, llm)
    rep = json.loads((cdir / "case_findings_report.json").read_text(encoding="utf-8"))
    rm = [r for r in rep["removed"] if r["where"] == "メモ.md"]
    assert rm and rm[0]["reason"] == "他の資料の数値" and "測定結果.xlsx" in rm[0]["found_in"]
    md = (cdir / "case_summary.md").read_text(encoding="utf-8")
    sec = md[md.index("## 調査"):md.index("## 対応効果")]
    assert "S-2：硬さ 2.47 GPa" in sec                       # 本来の資料の記述は残る
    assert "S-2 の硬さ 2.47 GPa は報告書と測定結果で一致" in sec   # 比較は案件全体で確かめる
    q = json.loads((cdir / "quality_report.json").read_text(encoding="utf-8"))
    assert any("別の資料の数値" in w for w in q["warnings"])


def test_findings_retry_when_output_unusable(cfg, tmp_path):
    case = _mixed_case(cfg, tmp_path, only_excel=True)

    class Flaky(_CaseLLM):
        n = 0

        def chat_json(self, **kw):
            if "判明した事実」の欄を書く担当" in kw["system"]:
                self.calls.append(kw)
                Flaky.n += 1
                if Flaky.n == 1:
                    return ["配列だけ"]
                return {"by_file": {"測定結果.xlsx": ["S-1：硬さ 2.31 GPa"]}}
            return super().chat_json(**kw)

    llm = Flaky(cfg)
    cdir = _run(cfg, case, llm)
    assert Flaky.n == 2
    retry = [c for c in llm.calls if c.get("tag") == "case:findings:retry"][0]
    assert "JSON オブジェクトではなく list でした" in retry["user"]
    md = (cdir / "case_summary.md").read_text(encoding="utf-8")
    assert "S-1：硬さ 2.31 GPa" in md


# ----------------------------------------------------------------------
# 画像の照合：表示の丸め・接頭辞・換算
# ----------------------------------------------------------------------

SRC = ("## シート: 測定\n| 試料 | 荷重(μN) | 深さ(nm) | 弾性率(MPa) | 比 |\n|---|---|---|---|---|\n"
       "| S-1 | 1 | 316.5335 | 3301.129875 | 0.125 |\n| S-2 | 1000 | 150 | 2.5 | x |\n" + "説明" * 20)


def _check(lines):
    vis = [{"evidence_id": "v", "asset_kind": "sheet_render", "sheet_name": "測定", "readable_text": lines}]
    return D.build_source_check(SRC, vis)["items"][0]


def test_excel_display_rounding_is_not_a_misread():
    it = _check(["S-1 1 317 3301.13 12.5%", "3.30E+03"])
    assert it["status"] == D.CHECK_OK and "317" in it["rounded"]


def test_wrong_prefix_is_caught_even_without_unit_next_to_value():
    it = _check(["S-1 荷重 1 pN"])
    assert it["status"] == D.CHECK_DIFF
    assert it["unit_mismatch"] == [{"read": "1 pN", "source": "原文の単位：μN"}]


def test_real_digit_misread_is_still_caught():
    it = _check(["S-1 318 3301.13"])
    assert "318" in it["numbers_missing"] and it["status"] == D.CHECK_DIFF


def test_prefix_conversion_counts_as_match():
    src = "## p.1\n荷重は 1 μN、速度は 150 nm/s とした。" + "説明" * 20
    vis = [{"evidence_id": "p", "asset_kind": "page_render", "page": 1,
            "readable_text": ["荷重 0.001 mN", "速度 0.15 μm/s"]}]
    it = D.build_source_check(src, vis)["items"][0]
    assert it["status"] == D.CHECK_OK and len(it["converted"]) == 2


def test_new_prefixes_in_unit_table():
    assert [u for _, u, _ in D._extract_numbers("1 pN、2 fF、3 ps")] == ["pN", "fF", "ps"]


def test_unsupported_numbers_accepts_display_rounding_and_conversion():
    assert D.unsupported_numbers("深さは 317 nm、荷重は 0.001 mN", "深さ 316.5335 nm、荷重 1 μN") == []
    assert D.unsupported_numbers("深さは 320 nm", "深さ 316.5335 nm")
