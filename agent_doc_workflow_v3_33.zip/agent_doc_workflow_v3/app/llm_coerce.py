"""
モデルの出力を、決めた形に寄せる（v3.33）。

v3.32 の資料ごとの分析は、measurements を「文字列の配列」と決めていた。ところが
Gemma4 は測定結果を {試料, 条件, 測定項目, 値, 単位} のような**オブジェクト**で
返し、型が合わないという理由で分析 1 件が丸ごと捨てられていた（4 件中 4 件）。

弱いモデルに形式を完全に守らせることはできない。中身が正しいのに形が少し違う
だけで捨てるのはもったいないので、受け取る側で寄せる。

- オブジェクト → 1 行の文（試料・条件・項目・値・単位が分かれば「試料（条件）：項目 値 単位」）
- 数値・真偽 → 文字列
- 入れ子の配列 → 平らにする
- 文字列欄に配列が来たら「、」でつなぐ
- 欄ごとに寄せる。ある欄が使えなくても、他の欄は残す
- 寄せられなかった欄・無かった欄は記録して返す（再試行の判断と報告に使う）
"""
from __future__ import annotations

import json
import re
import typing
from typing import Any, Dict, List, Tuple, Type

from pydantic import BaseModel

# キーの名前から役割を推す（英語・日本語のどちらで返ってきても拾う）
_ROLES = {
    "sample": ("sample", "specimen", "試料", "サンプル", "試験片", "検体", "品名", "name", "id", "対象"),
    "condition": ("condition", "条件", "setting", "設定"),
    "item": ("item", "property", "parameter", "metric", "項目", "測定項目", "特性", "物性", "評価項目"),
    "value": ("value", "values", "result", "値", "数値", "測定値", "結果"),
    "unit": ("unit", "units", "単位"),
}


def _role_of(key: str) -> str:
    k = str(key).strip().lower()
    # 完全一致を優先し、次に部分一致
    for role, names in _ROLES.items():
        if k in names:
            return role
    # 部分一致：日本語は 1 文字から（「最大値」→ 値）、英字は短い語を誤って拾わないよう 4 文字以上
    for role, names in _ROLES.items():
        if any(n in k for n in names if (not n.isascii()) or len(n) >= 4):
            return role
    return ""


def _scalar(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, bool):
        return "はい" if v else "いいえ"
    if isinstance(v, float):
        # json の数値はそのまま（3301.129875 → "3301.129875"、2.0 → "2"）
        return f"{v:.15g}"
    return str(v).strip()


def to_text(v: Any) -> str:
    """どんな値も 1 行の文にする。"""
    if v is None:
        return ""
    if isinstance(v, (str, int, float, bool)):
        return _scalar(v)
    if isinstance(v, (list, tuple)):
        return "、".join(t for t in (to_text(x) for x in v) if t)
    if isinstance(v, dict):
        roles: Dict[str, str] = {}
        rest: List[str] = []
        value_key = ""
        for k, val in v.items():
            t = to_text(val)
            if not t:
                continue
            r = _role_of(k)
            if r and r not in roles:
                roles[r] = t
                if r == "value":
                    value_key = str(k)
            else:
                rest.append(f"{k}：{t}")
        # 「最大値」「測定値」のようにキー自体が項目名を兼ねている場合は、項目として残す
        if value_key and "item" not in roles and value_key.lower() not in _ROLES["value"]:
            roles["item"] = value_key
        if "value" in roles and (roles.keys() & {"sample", "item", "unit", "condition"}):
            head = roles.get("sample", "")
            if roles.get("condition"):
                head = f"{head}（{roles['condition']}）" if head else roles["condition"]
            body = " ".join(x for x in (roles.get("item", ""), roles["value"], roles.get("unit", "")) if x)
            line = f"{head}：{body}" if head else body
        else:
            # 役割が読めない物は「キー：値」を並べる（情報は落とさない）
            line = "、".join([f"{k}：{t}" for k, t in
                             ((k, to_text(val)) for k, val in v.items()) if t])
            return line
        return "、".join([line] + rest) if rest else line
    return _scalar(v)


def to_list(v: Any) -> List[str]:
    """配列欄に来た値を、文字列の配列にする。"""
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        out: List[str] = []
        for x in v:
            if isinstance(x, (list, tuple)):
                out += to_list(x)
            else:
                t = to_text(x)
                if t:
                    out.append(t)
        return out
    if isinstance(v, dict):
        # {"S-1": "...", "S-2": "..."} のような形は 1 キー 1 項目として読む
        vals = list(v.values())
        if v and all(isinstance(x, (str, int, float)) for x in vals) and not (
                set(_role_of(k) for k in v) & {"value", "unit"}):
            return [f"{k}：{_scalar(x)}" for k, x in v.items() if _scalar(x)]
        t = to_text(v)
        return [t] if t else []
    if isinstance(v, str):
        # 改行区切りの箇条書きで返ってくることがある
        lines = [re.sub(r"^\s*(?:[-・*●]|\d{1,2}[.)）])\s*", "", ln).strip() for ln in v.split("\n")]
        lines = [ln for ln in lines if ln]
        return lines
    t = to_text(v)
    return [t] if t else []


def _is_list_of_str(ann: Any) -> bool:
    return typing.get_origin(ann) in (list, List) and typing.get_args(ann) in ((str,),)


def unwrap(raw: Any, field_names: List[str]) -> Any:
    """{"analysis": {...}} のように 1 段包まれていたら外す。"""
    if isinstance(raw, dict) and not (set(raw) & set(field_names)):
        inner = [v for v in raw.values() if isinstance(v, dict) and set(v) & set(field_names)]
        if len(inner) == 1:
            return inner[0]
    if isinstance(raw, list) and len(raw) == 1 and isinstance(raw[0], dict):
        return unwrap(raw[0], field_names)
    return raw


def coerce_flat(raw: Any, model: Type[BaseModel]) -> Tuple[BaseModel, Dict[str, Any]]:
    """文字列欄・文字列配列欄だけのモデルに寄せる。

    戻り値: (モデル, 報告)。報告は
      fixed   … 形を寄せた欄（例：measurements：オブジェクト 12 件を文にした）
      missing … 出力に無かった欄
      unusable… 寄せても使えなかった欄
      shape   … 出力そのものが辞書でなかった場合の型名
    """
    names = list(model.model_fields)
    raw = unwrap(raw, names)
    report: Dict[str, Any] = {"fixed": [], "missing": [], "unusable": []}
    if not isinstance(raw, dict):
        report["shape"] = type(raw).__name__
        return model(), report
    data: Dict[str, Any] = {}
    for name, f in model.model_fields.items():
        if name not in raw:
            report["missing"].append(name)
            continue
        v = raw[name]
        try:
            if _is_list_of_str(f.annotation):
                if not (isinstance(v, list) and all(isinstance(x, str) for x in v)):
                    kinds = sorted({type(x).__name__ for x in v}) if isinstance(v, list) else [type(v).__name__]
                    report["fixed"].append(f"{name}（{'・'.join(kinds)}）")
                data[name] = to_list(v)
            elif f.annotation is str:
                if not isinstance(v, str):
                    report["fixed"].append(f"{name}（{type(v).__name__}）")
                data[name] = to_text(v)
            else:
                data[name] = v
        except Exception:  # noqa: BLE001 1 つの欄の失敗で他を捨てない
            report["unusable"].append(name)
    try:
        return model.model_validate(data), report
    except Exception:  # noqa: BLE001
        ok = {}
        for k, v in data.items():
            try:
                model.model_validate({k: v})
                ok[k] = v
            except Exception:  # noqa: BLE001
                report["unusable"].append(k)
        return model.model_validate(ok), report


def is_empty(m: BaseModel) -> bool:
    for v in m.model_dump().values():
        if isinstance(v, str) and v.strip():
            return False
        if isinstance(v, list) and v:
            return False
    return True


def describe(report: Dict[str, Any]) -> str:
    """再試行のときにモデルへ伝える、前回の出力の問題（日本語）。"""
    parts = []
    if report.get("shape"):
        parts.append(f"出力が JSON オブジェクトではなく {report['shape']} でした")
    if report.get("error"):
        parts.append(f"JSON として読めませんでした（{str(report['error'])[:120]}）。出力が途中で切れた可能性があります")
    if report.get("unusable"):
        parts.append("次の項目が読めませんでした：" + "、".join(report["unusable"]))
    if report.get("empty"):
        parts.append("すべての項目が空でした")
    return "。".join(parts)


def dumps(o: Any) -> str:
    return json.dumps(o, ensure_ascii=False, separators=(",", ":"))
