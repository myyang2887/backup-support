"""
案件の三段構え（v3.32）— 資料ごとの分析 → 資料間の比較 → 「判明した事実」の欄。

## なぜ必要か

v3.31 の案件要約は、全資料の「抜き出した証拠」を 1 つの山にして要約モデルへ
渡していた。そのため

- 資料 1 件ずつの中身（何の資料で、どんな条件で何を測り、何と結論したか）を
  誰も整理しないまま、いきなり全体の要約を書かせていた
- 資料どうしの関係（版違いか、補い合うのか、同じ測定の別条件か）を比べる
  段が無かった
- 証拠の抽出で表が「測定データあり」のように丸められると、その先で
  数値を取り戻す手段が無かった

ここでは人が複数の資料を読むときと同じ順に分ける。

1. analyze_files  … 資料 1 件ごとに、**原文そのもの**（PDF・PowerPoint・Word は
   取り出した本文、Excel はセルの値）と、原文と照合済みの画像の読み取りを
   渡して整理させる。資料の種類は問わない。結果は資料の置き場にキャッシュする。
2. compare_files  … 1 で作った整理結果を並べて、関係・共通点・違いを出す。
   資料が 1 件なら飛ばす。
3. case_findings  … 1 と 2 から「調査・対応により判明した事実」の欄を書く。
   3 つの部分（資料ごとの分析／資料間の比較／案件としての結論）に分け、
   プログラムが目印を付けて 1 つの欄に入れる。テンプレートが目印で見出しを付ける。

数値は最後にコードで確かめる。どの資料の原文・画像の読み取りにも無い数値を含む
項目は、欄に入れない（理由は報告ファイルに残す）。

## v3.33 で直したこと（実案件で資料ごとの分析が 4 件中 0 件だった）

- モデルが measurements をオブジェクトで返すと、型が合わないという理由で分析を
  丸ごと捨てていた → 受け取る側で形を寄せ（llm_coerce）、使える欄は残す。
  何も使えなかったときだけ、理由を添えて 1 回やり直す
- 分析に失敗した資料は「抜き出した証拠だけで書く」と言いながら、実際には何も
  渡していなかった。モデルは資料名と下書きだけを見て、資料ごとの記述を作っていた
  → その資料自身の証拠を資料ごとに分けて渡す。何も無い資料は「分析できなかった」
  とはっきり書く。要約の下書きは渡さない（どの資料の話か分からない記述が混ざるため）
- 比較を飛ばしたときの理由を正しく出す（「資料が 1 件」ではなく「分析が 0/4 件」）
- 「資料ごとの分析」の数値は、その資料自身の原文・画像の読み取りで確かめる。
  他の資料にしか無い数値は、その資料の記述として扱わない
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field, ValidationError

from .config import AppConfig
from .contract import VisualEvidence, schema_skeleton
from .deep_read import report_prompt_block, unsupported_numbers
from .evidence import visual_to_pack
from .llm_coerce import coerce_flat, describe, dumps, is_empty, to_list, to_text, unwrap

CASE_ANALYSIS_VERSION = "3.33"

#: 「判明した事実」の各項目の頭に付ける目印。テンプレートがこれで見出しを分ける。
TAG_FILE = "【資料別】"
TAG_COMPARE = "【資料間】"
TAG_CONCLUSION = "【結論】"
CONCLUSION_KINDS = ("資料の結論", "データから読み取れること", "未解決の点")

ANALYSIS_FILE = "file_analysis.json"
COMPARISON_FILE = "case_comparison.json"
FINDINGS_REPORT_FILE = "case_findings_report.json"


# ----------------------------------------------------------------------
# 出力の形（LLM との境界）
# ----------------------------------------------------------------------

class FileAnalysis(BaseModel):
    document_type: str = ""
    date_or_version: str = ""
    purpose: str = ""
    contents: List[str] = Field(default_factory=list)
    measurements: List[str] = Field(default_factory=list)
    conclusions: List[str] = Field(default_factory=list)
    limitations: List[str] = Field(default_factory=list)
    open_points: List[str] = Field(default_factory=list)


class CaseComparison(BaseModel):
    relations: List[str] = Field(default_factory=list)
    common: List[str] = Field(default_factory=list)
    added: List[str] = Field(default_factory=list)
    differences: List[str] = Field(default_factory=list)
    not_comparable: List[str] = Field(default_factory=list)
    case_conclusions: List[str] = Field(default_factory=list)
    unresolved: List[str] = Field(default_factory=list)


class FileFindings(BaseModel):
    file: str = ""
    points: List[str] = Field(default_factory=list)


class ConclusionItem(BaseModel):
    kind: str = ""
    text: str = ""


class CaseFindings(BaseModel):
    by_file: List[FileFindings] = Field(default_factory=list)
    comparison: List[str] = Field(default_factory=list)
    conclusions: List[ConclusionItem] = Field(default_factory=list)


# ----------------------------------------------------------------------
# プロンプト
# ----------------------------------------------------------------------

FILE_ANALYSIS_SYSTEM = """あなたは技術資料を読み、内容を正確に整理する担当です。
渡すのは、1 つの案件フォルダに入っている資料のうちの 1 件です。
この資料だけを読んで、何が書かれているかを整理してください。

JSON のみを出力してください。

各項目の書き方：
- document_type：資料の種類（測定結果の表、解析報告書、打ち合わせ資料、依頼書 など）。
- date_or_version：資料に書かれている日付・版。書かれていなければ空文字。
- purpose：この資料が何のために作られたか。資料から分からなければ空文字。
- contents：資料に書かれている内容を、まとまりごとに 1 項目ずつ。
- measurements：測定・解析の条件と結果。試料名（番号）・条件・測定項目・値・単位を、
  原文の表記のまま書く。1 項目には 1 つの試料、または 1 つの条件の結果をまとめる。
  各項目は 1 つの文字列にする。書き方の例：「<試料名>（<条件>）：<測定項目> <値> <単位>」
  表の行が多くても省略しない。値を丸めたり、別の単位に換算したりしない。
- conclusions：資料自身が述べている結論・判断。資料に書かれていない解釈は入れない。
- limitations：前提・条件の制約・注意書き。
- open_points：資料からは分からない点、検討中・未完了と書かれている点。

守ること：
- 資料に無いことを書かない。分からない項目は空にする（空文字・空配列）。
- 数値は原文にある物だけを使う。
- 「原文との照合」の注意書きがある場合は、それに従う。"""


COMPARE_SYSTEM = """あなたは複数の資料を突き合わせる担当です。
同じ案件フォルダに入っている資料を、1 件ずつ整理した結果を渡します。
整理できなかった資料は、代わりに本文から抜き出した証拠を渡します。
資料どうしを比べて、関係・共通点・違いを整理してください。

JSON のみを出力してください。

各項目の書き方（資料名は『』で囲む）：
- relations：資料どうしの関係。「同じ測定の別条件」「速報と最終報告（版違い）」
  「測定データとその報告書」などを、内容から判断して書く。
- common：複数の資料に共通して書かれている事実と、それがどの資料にあるか。
- added：ある資料にだけ書かれている事実と、その資料名。
- differences：同じ事柄について値や結論が違う点。両方の値を資料名付きで書く。
  どちらが正しいかは決めない。
- not_comparable：試料・条件・単位が違うため、そのままでは比べられない点。
- case_conclusions：資料全体から言えること。資料に結論として書かれていることと、
  数値から直接読み取れることに限る。判断には根拠になる代表的な値（資料名・試料・
  条件付き）を添える。「範囲内」「範囲外」だけで終わらせない。
- unresolved：資料をすべて読んでも分からない点、資料間で決着していない点。

守ること：
- 渡された整理結果・証拠に無いことを書かない。
- 数値は渡された表記のまま使う。計算し直さない。
- 各項目は 1 つの文字列にする。"""


FINDINGS_SYSTEM = """あなたは案件の要約のうち「調査・対応により判明した事実」の欄を書く担当です。
この欄は次の 3 つの部分から成ります。

1. by_file（資料ごとの分析）
   資料 1 件ごとに、その資料から分かる事実を points に書く。file には資料名をそのまま書く。
   測定・解析の結果は、試料・条件・値・単位を省かずに書く。
   ある資料の points には、その資料の材料に書かれていることだけを書く。
   別の資料にある条件・値を持ち込まない。
   渡した資料はすべて取り上げる。
2. comparison（資料間の比較）
   資料どうしで共通する点・違う点・一方にしか無い点。値が違う場合は、両方の値を
   資料名付きで書く。資料が 1 件だけなら空配列にする。
3. conclusions（案件としての結論）
   kind は次の 3 つのどれかにする。
   - 資料の結論：資料に結論として書かれていること
   - データから読み取れること：数値から直接言えること（比較・傾向など）。資料に無い推測は書かない
   - 未解決の点：資料からは分からないこと、決着していないこと
   結論・判断には、根拠になる代表的な値を資料名・試料・条件付きで添え、何を基準に
   そう判断したかを書く。「範囲内」「範囲外」だけで終わらせない。

JSON のみを出力してください。

守ること：
- 渡した材料に無い事実・数値を書かない。数値を計算し直さない。
- 1 項目は 1〜3 文。長くなってもよいので、必要なことは省略しない。
- 項目の頭に記号・番号・見出しを付けない（見出しはプログラムが付けます）。
- points・comparison・text は、それぞれ 1 つの文字列にする。
- 「原文との照合」で本文に書かないよう指示された表記は使わない。"""


# ----------------------------------------------------------------------
# 材料づくり
# ----------------------------------------------------------------------

def _load(p: Path) -> Any:
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def _read(p: str) -> str:
    try:
        return Path(p).read_text(encoding="utf-8", errors="ignore") if p else ""
    except OSError:
        return ""


def member_visuals(mdir: Path) -> List[dict]:
    doc = _load(mdir / "evidence_visual_checked.json") or _load(mdir / "evidence_visual.json") or {}
    return doc.get("evidence", []) or []


def _visual_pack(vis: List[dict], readable_text_limit: int = 0) -> List[dict]:
    items = []
    for d in vis:
        try:
            items.append(VisualEvidence.model_validate(d))
        except ValidationError:
            continue
    return visual_to_pack(items, max_total_chars=0, readable_text_limit=readable_text_limit)


def _sheet_names(source: str) -> List[str]:
    return re.findall(r"^#{1,3}\s*シート\s*[:：]\s*(.+?)\s*$", source, re.M)


def member_material(member: Dict[str, Any], *, source_limit: int = 0,
                    readable_text_limit: int = 0) -> Dict[str, Any]:
    """資料 1 件分の分析材料。原文が長すぎる場合だけ、抜き出した証拠で代える。"""
    mdir = Path(member["run_dir"])
    source = _read(member.get("markdown_path", ""))
    report = _load(mdir / "page_report.json") or {}
    vis = _visual_pack(member_visuals(mdir), readable_text_limit)
    note = ""
    text_evidence: List[dict] = []
    if source_limit and len(source) > source_limit:
        text_evidence = [{"content": e.get("content", ""), "category": e.get("category", ""),
                          **({"page": e["page"]} if e.get("page") else {}),
                          **({"sheet_name": e["sheet_name"]} if e.get("sheet_name") else {})}
                         for e in ((_load(mdir / "evidence_aggregated.json") or {}).get("evidence") or [])
                         if (e.get("origin") or "text") != "reference"]
        note = (f"原文が長い（約 {len(source):,} 字）ため、原文の代わりに本文から抜き出した"
                f"証拠 {len(text_evidence)} 件を渡しています。")
        source = ""
    return {"file": member["rel_in_case"], "source": source, "visual": vis,
            "check_block": report_prompt_block(report) if report.get("version") == 2 else "",
            "text_evidence": text_evidence, "note": note,
            "sheets": _sheet_names(source) if source else []}


def material_key(mat: Dict[str, Any], model: str) -> str:
    h = hashlib.sha1()
    for part in (CASE_ANALYSIS_VERSION, model, mat["source"], mat["check_block"], mat["note"],
                 json.dumps(mat["visual"], ensure_ascii=False, sort_keys=True),
                 json.dumps(mat["text_evidence"], ensure_ascii=False, sort_keys=True),
                 json.dumps(FileAnalysis.model_json_schema(), sort_keys=True), FILE_ANALYSIS_SYSTEM):
        h.update(str(part).encode("utf-8"))
        h.update(b"\x00")
    return h.hexdigest()[:16]


def file_analysis_user(mat: Dict[str, Any], title: str = "") -> str:
    parts = [f"資料名：{mat['file']}"]
    if title:
        parts.append(f"資料の見出し：{title}")
    if mat["sheets"]:
        parts.append("シート：" + "、".join(mat["sheets"]))
    if mat["note"]:
        parts.append(mat["note"])
    if mat["source"]:
        parts += ["", "【原文】（文字として取り出せた本文。Excel はセルの値をシートごとの表にした物）",
                  mat["source"]]
    if mat["text_evidence"]:
        parts += ["", "【本文から抜き出した証拠】",
                  json.dumps(mat["text_evidence"], ensure_ascii=False, separators=(",", ":"))]
    if mat["visual"]:
        parts += ["", "【画像からの読み取り】（ページ・シートを画像にして読み取った物。"
                      "原文と照らし合わせ、合わない行は外してあります）",
                  json.dumps(mat["visual"], ensure_ascii=False, separators=(",", ":"))]
    if mat["check_block"]:
        parts += ["", mat["check_block"]]
    parts += ["", "次の形式の JSON で出力してください：",
              json.dumps(schema_skeleton(FileAnalysis.model_json_schema()), ensure_ascii=False)]
    return "\n".join(parts)


# ----------------------------------------------------------------------
# 目印付きの文字列 ⇔ 構造
# ----------------------------------------------------------------------

_LEAD_MARK = re.compile(r"^\s*(?:[-・*●■□◆◇▼▶︎>]+|\(?\d{1,2}[.)）]|[①-⑳])\s*")


def _clean(text: str) -> str:
    t = re.sub(r"\s+", " ", str(text or "")).strip()
    t = _LEAD_MARK.sub("", t)
    for tag in (TAG_FILE, TAG_COMPARE, TAG_CONCLUSION):
        if t.startswith(tag):
            t = t[len(tag):].strip()
    return t


def _norm_name(name: str) -> str:
    return re.sub(r"[\s『』「」\"'（）()]+", "", str(name or "")).lower()


def match_file(name: str, files: List[str]) -> str:
    """モデルが書いた資料名を、実際の資料名に当てる（拡張子なし・パス違いも許す）。"""
    key = _norm_name(name)
    if not key:
        return ""
    for f in files:
        if _norm_name(f) == key:
            return f
    for f in files:
        nf = _norm_name(f)
        stem = _norm_name(Path(f).stem)
        base = _norm_name(Path(f).name)
        if key in (stem, base) or (len(key) >= 4 and (key in nf or nf.endswith(key))):
            return f
    return ""


def findings_to_strings(by_file: List[Tuple[str, List[str]]], comparison: List[str],
                        conclusions: List[Tuple[str, str]]) -> List[str]:
    out: List[str] = []
    for f, points in by_file:
        for p in points:
            out.append(f"{TAG_FILE}『{f}』{p}")
    for c in comparison:
        out.append(f"{TAG_COMPARE}{c}")
    for kind, text in conclusions:
        out.append(f"{TAG_CONCLUSION}{kind}：{text}" if kind else f"{TAG_CONCLUSION}{text}")
    return out


def files_in_findings(findings: List[str]) -> List[str]:
    """「資料ごとの分析」に出てくる資料名（出てきた順）。"""
    seen: List[str] = []
    for item in findings or []:
        s = str(item)
        if s.startswith(TAG_FILE):
            m = re.match(r"『(.+?)』", s[len(TAG_FILE):])
            if m and m.group(1) not in seen:
                seen.append(m.group(1))
    return seen


# ----------------------------------------------------------------------
# 「判明した事実」の欄をどこに書くか
# ----------------------------------------------------------------------

_FINDINGS_CANDIDATES = (("action_results", "findings"), ("findings",), ("key_results",),
                        ("main_content",), ("key_points",))


def findings_path(summary: Dict[str, Any]) -> Optional[Tuple[str, ...]]:
    for path in _FINDINGS_CANDIDATES:
        node: Any = summary
        ok = True
        for k in path:
            if isinstance(node, dict) and k in node:
                node = node[k]
            else:
                ok = False
                break
        if ok and isinstance(node, list):
            return path
    return None


def get_path(summary: Dict[str, Any], path: Tuple[str, ...]) -> Any:
    node: Any = summary
    for k in path:
        node = node[k]
    return node


def set_path(summary: Dict[str, Any], path: Tuple[str, ...], value: Any) -> None:
    node: Any = summary
    for k in path[:-1]:
        node = node[k]
    node[path[-1]] = value


# ----------------------------------------------------------------------
# 「判明した事実」の出力を寄せる
# ----------------------------------------------------------------------

_BY_FILE_KEYS = ("by_file", "資料ごとの分析", "files", "per_file")
_COMPARE_KEYS = ("comparison", "資料間の比較", "compare", "comparisons")
_CONCL_KEYS = ("conclusions", "案件としての結論", "conclusion")
_FILE_NAME_KEYS = ("file", "資料名", "資料", "name", "filename", "document")
_POINT_KEYS = ("points", "facts", "内容", "事実", "items", "point")


def _first(d: Dict[str, Any], keys: Tuple[str, ...]) -> Any:
    for k in keys:
        if k in d:
            return d[k]
    return None


def coerce_case_findings(raw: Any) -> Tuple[CaseFindings, Dict[str, Any]]:
    """「判明した事実」の出力を寄せる。by_file はオブジェクトの配列でも
    {資料名: [事実…]} の辞書でもよい。conclusions は {kind, text} の配列・
    文字列の配列・{種類: [文…]} の辞書のどれでもよい。"""
    raw = unwrap(raw, list(_BY_FILE_KEYS + _COMPARE_KEYS + _CONCL_KEYS))
    rep: Dict[str, Any] = {"fixed": [], "missing": [], "unusable": []}
    if not isinstance(raw, dict):
        rep["shape"] = type(raw).__name__
        return CaseFindings(), rep

    by_file: List[FileFindings] = []
    bf = _first(raw, _BY_FILE_KEYS)
    if bf is None:
        rep["missing"].append("by_file")
    elif isinstance(bf, dict):
        rep["fixed"].append("by_file（dict）")
        for name, pts in bf.items():
            by_file.append(FileFindings(file=str(name), points=to_list(pts)))
    elif isinstance(bf, list):
        for x in bf:
            if isinstance(x, dict):
                name = to_text(_first(x, _FILE_NAME_KEYS))
                pts = _first(x, _POINT_KEYS)
                if pts is None:      # {file, 何か別のキー…} → 残りを全部事実として読む
                    pts = [v for k, v in x.items() if k not in _FILE_NAME_KEYS]
                if not (isinstance(pts, list) and all(isinstance(p, str) for p in pts)):
                    rep["fixed"].append("by_file.points")
                by_file.append(FileFindings(file=name, points=to_list(pts)))
            else:
                rep["unusable"].append("by_file")
    else:
        rep["unusable"].append("by_file")

    cmp_raw = _first(raw, _COMPARE_KEYS)
    if cmp_raw is None:
        rep["missing"].append("comparison")
    comparison = to_list(cmp_raw)

    concl: List[ConclusionItem] = []
    cr = _first(raw, _CONCL_KEYS)
    if cr is None:
        rep["missing"].append("conclusions")
    elif isinstance(cr, dict):
        rep["fixed"].append("conclusions（dict）")
        for kind, texts in cr.items():
            for t in to_list(texts):
                concl.append(ConclusionItem(kind=str(kind), text=t))
    else:
        for x in (cr if isinstance(cr, list) else [cr]):
            if isinstance(x, dict):
                kind = to_text(x.get("kind") or x.get("種類") or x.get("type") or "")
                text = x.get("text") if "text" in x else x.get("内容", None)
                if text is None:
                    text = {k: v for k, v in x.items() if k not in ("kind", "種類", "type")}
                for t in to_list(text):
                    concl.append(ConclusionItem(kind=kind, text=t))
            else:
                t = to_text(x)
                if t:
                    concl.append(ConclusionItem(kind="", text=t))
    return CaseFindings(by_file=by_file, comparison=comparison, conclusions=concl), rep


def _findings_empty(cf: CaseFindings) -> bool:
    return not (any(f.points for f in cf.by_file) or cf.comparison or cf.conclusions)


# ----------------------------------------------------------------------
# ノード
# ----------------------------------------------------------------------

#: 分析に失敗した資料について、代わりに渡す証拠の件数の上限（0 = すべて）
FALLBACK_EVIDENCE_PER_FILE = 0
#: モデルが取り上げなかった資料を、その資料の証拠から補うときの件数
FILL_FROM_EVIDENCE_PER_FILE = 20


def make_case_analysis_nodes(config: AppConfig, llm):
    from .nodes import _push_error, _save_json, _store, _update_status

    wf = config.workflow
    cc = config.case

    def _members(state) -> List[Dict[str, Any]]:
        return [m for m in (state.get("case") or {}).get("members", []) if m.get("state") == "done"]

    def _titles(state) -> Dict[str, str]:
        docs = ((state.get("case_meta") or {}).get("documents")) or []
        return {d.get("file", ""): d.get("document_title", "") for d in docs}

    def _file_evidence(state, rel: str) -> List[Dict[str, Any]]:
        """その資料自身の証拠（台帳は除く）。分析に失敗した資料の代わりの材料。"""
        out = []
        for e in state.get("aggregated_evidence", []) or []:
            if (e.get("origin") or "text") == "reference":
                continue
            # 資料をまたいだ完全な重複は 1 件にまとめてある（also_in に他の資料名）
            if e.get("file") != rel and rel not in (e.get("also_in") or []):
                continue
            d = {"content": e.get("content", "")}
            for k in ("category", "sheet_name", "page"):
                if e.get(k):
                    d[k] = e[k]
            out.append(d)
        n = FALLBACK_EVIDENCE_PER_FILE
        return out[:n] if n else out

    def _layers(state) -> Dict[str, Any]:
        return dict(state.get("case_layers") or {})

    # ---- モデルに聞いて、形を寄せる。何も使えなければ理由を添えて 1 回だけやり直す ----
    def _ask(*, system: str, user: str, schema: dict, tag: str, max_tokens: int, coerce):
        attempts: List[Dict[str, Any]] = []
        best = None
        for n in (1, 2):
            u, mt = user, max_tokens
            if n == 2:
                u = (user + "\n\n【前回の出力について】" + (describe(attempts[-1]) or "使える内容がありませんでした")
                     + "。上の形式に合わせて、もう一度すべて出力してください。")
                if attempts[-1].get("error"):
                    mt = min(int(max_tokens * 1.5), 16384)   # 途中で切れた可能性があるので少し広げる
            try:
                raw = llm.chat_json(system=system, user=u, max_tokens=mt, json_schema=schema,
                                    tag=tag if n == 1 else tag + ":retry", temperature=0.0)
                inst, rep = coerce(raw)
                empty = _findings_empty(inst) if isinstance(inst, CaseFindings) else is_empty(inst)
                if empty:
                    rep["empty"] = True
                else:
                    best = inst
            except Exception as e:  # noqa: BLE001
                rep = {"error": repr(e)[:300]}
            attempts.append(rep)
            if best is not None:
                break
        return best, attempts

    # ------------------------------------------------------------------
    def analyze_files(state) -> Dict[str, Any]:
        members = _members(state)
        titles = _titles(state)
        _update_status(state, "analyze_files", peek=f"{len(members)} 件の資料を 1 件ずつ読んでいます…")
        store = _store(state)
        out: List[Dict[str, Any]] = []
        reused = 0
        for i, m in enumerate(members, 1):
            store.raise_if_cancelled()
            rel = m["rel_in_case"]
            mat = member_material(m, source_limit=int(cc.analysis_source_chars or 0),
                                  readable_text_limit=wf.visual_readable_text_limit)
            key = material_key(mat, config.llm.model)
            cache_p = Path(m["run_dir"]) / ANALYSIS_FILE
            cached = _load(cache_p) or {}
            if wf.resume and cached.get("key") == key and isinstance(cached.get("analysis"), dict):
                out.append({"file": rel, "analysis": cached["analysis"], "status": "ok", "cached": True})
                reused += 1
                continue
            _update_status(state, "analyze_files", "running", f"{i}/{len(members)}",
                           peek=f"『{rel}』を読んでいます…")
            if not (mat["source"] or mat["visual"] or mat["text_evidence"]):
                out.append({"file": rel, "analysis": None, "status": "no_material",
                            "fallback_evidence": _file_evidence(state, rel)})
                continue
            fa, attempts = _ask(system=FILE_ANALYSIS_SYSTEM,
                                user=file_analysis_user(mat, titles.get(rel, "")),
                                schema=FileAnalysis.model_json_schema(),
                                tag=f"case:analyze:{i:02d}", max_tokens=int(cc.analysis_max_tokens),
                                coerce=lambda raw: coerce_flat(raw, FileAnalysis))
            if fa is None:
                why = describe(attempts[-1]) or "使える内容がありませんでした"
                _push_error(state, "analyze_files",
                            f"資料『{rel}』の分析に失敗しました（2 回試しました）。"
                            f"この資料は本文から抜き出した証拠を代わりに使います",
                            dumps(attempts)[:1500])
                out.append({"file": rel, "analysis": None, "status": "failed", "reason": why,
                            "attempts": attempts, "fallback_evidence": _file_evidence(state, rel)})
                continue
            fa_d = fa.model_dump()
            fixed = sorted({x for a in attempts for x in a.get("fixed", [])})
            _save_json({"key": key, "version": CASE_ANALYSIS_VERSION, "file": rel,
                        "material": {"source_chars": len(mat["source"]), "visual": len(mat["visual"]),
                                     "text_evidence": len(mat["text_evidence"]), "note": mat["note"]},
                        "attempts": attempts, "analysis": fa_d}, cache_p)
            out.append({"file": rel, "analysis": fa_d, "status": "ok",
                        **({"fixed": fixed} if fixed else {}),
                        **({"retried": True} if len(attempts) > 1 else {})})
        _save_json({"files": out}, Path(state["run_dir"]) / "case_file_analyses.json")

        ok = [x["file"] for x in out if x.get("analysis")]
        bad = [x["file"] for x in out if not x.get("analysis")]
        layers = _layers(state)
        layers["analysis"] = {"total": len(members), "ok": len(ok), "failed": bad,
                              "reused": reused,
                              "fixed": [x["file"] for x in out if x.get("fixed")]}
        detail = f"{len(ok)}/{len(members)} 件" + (f"（前回の結果を使用 {reused} 件）" if reused else "")
        if bad:
            peek = (f"{len(bad)} 件の資料は分析できませんでした（"
                    + "、".join(f"『{f}』" for f in bad[:3]) + ("…" if len(bad) > 3 else "")
                    + "）。抜き出した証拠で代わりに書きます")
        else:
            peek = f"{len(ok)} 件の資料を整理しました"
        _update_status(state, "analyze_files", "done", detail, peek=peek)
        return {"file_analyses": out, "case_layers": layers, "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    def _file_materials(state) -> List[Dict[str, Any]]:
        """比較・「判明した事実」に渡す資料ごとの材料。分析が無い資料は証拠で代える。"""
        titles = _titles(state)
        mats = []
        for a in state.get("file_analyses") or []:
            d: Dict[str, Any] = {"file": a["file"]}
            if titles.get(a["file"]):
                d["title"] = titles[a["file"]]
            if a.get("analysis"):
                d.update(a["analysis"])
            elif a.get("fallback_evidence"):
                d["note"] = "この資料は整理できなかったため、本文から抜き出した証拠を渡します"
                d["evidence"] = a["fallback_evidence"]
            else:
                d["note"] = "この資料からは内容を取り出せていません"
            mats.append(d)
        return mats

    def compare_files(state) -> Dict[str, Any]:
        run_dir = Path(state["run_dir"])
        mats = _file_materials(state)
        usable = [m for m in mats if "evidence" in m or not m.get("note")]
        layers = _layers(state)
        reason = ""
        if len(mats) < 2:
            reason = "資料が 1 件のため"
        elif len(usable) < 2:
            ok = (layers.get("analysis") or {}).get("ok", 0)
            reason = (f"内容を取り出せた資料が {len(usable)} 件しかないため"
                      f"（資料ごとの分析 {ok}/{len(mats)} 件）")
        if reason:
            layers["comparison"] = {"ran": False, "reason": reason}
            _save_json({"ran": False, "reason": reason}, run_dir / COMPARISON_FILE)
            _update_status(state, "compare_files", "done", f"省略：{reason}",
                           peek=f"{reason}、資料間の比較は行いませんでした")
            return {"case_comparison": {}, "case_layers": layers}

        _update_status(state, "compare_files", peek=f"{len(mats)} 件の資料を突き合わせています…")
        user = ("同じ案件フォルダに入っている資料の整理結果です。\n\n" + dumps(mats)
                + "\n\n次の形式の JSON で出力してください：\n"
                + json.dumps(schema_skeleton(CaseComparison.model_json_schema()), ensure_ascii=False))
        comp_m, attempts = _ask(system=COMPARE_SYSTEM, user=user,
                                schema=CaseComparison.model_json_schema(), tag="case:compare",
                                max_tokens=int(cc.compare_max_tokens),
                                coerce=lambda raw: coerce_flat(raw, CaseComparison))
        if comp_m is None:
            why = describe(attempts[-1]) or "使える内容がありませんでした"
            _push_error(state, "compare_files", "資料間の比較に失敗しました（2 回試しました。比較なしで続けます）",
                        dumps(attempts)[:1500])
            layers["comparison"] = {"ran": False, "reason": f"比較の出力が使えなかったため（{why}）"}
            _save_json({"ran": False, "attempts": attempts}, run_dir / COMPARISON_FILE)
            _update_status(state, "compare_files", "done", "失敗（続行）",
                           peek="資料間の比較はできませんでした")
            return {"case_comparison": {}, "case_layers": layers, "errors": state.get("errors", [])}
        comp = comp_m.model_dump()
        n = sum(len(v) for v in comp.values() if isinstance(v, list))
        from_ev = [m["file"] for m in mats if "evidence" in m]
        layers["comparison"] = {"ran": True, "items": n, "from_evidence": from_ev}
        _save_json({**comp, "_attempts": attempts}, run_dir / COMPARISON_FILE)
        _update_status(state, "compare_files", "done", f"{n} 項目",
                       peek=("資料どうしの関係と違いを整理しました" if n else "比較できる点が見つかりませんでした"))
        return {"case_comparison": comp, "case_layers": layers, "errors": state.get("errors", [])}

    # ------------------------------------------------------------------
    def _file_blobs(state) -> Dict[str, str]:
        """資料ごとの裏付け：その資料の原文・照合済みの画像の読み取り・その資料の証拠。"""
        vis_by: Dict[str, list] = {}
        for v in state.get("visual_evidence", []) or []:
            vis_by.setdefault(v.get("file", ""), []).append(v)
        ev_by: Dict[str, list] = {}
        for e in state.get("aggregated_evidence", []) or []:
            if (e.get("origin") or "text") != "reference":
                for f in [e.get("file", "")] + list(e.get("also_in") or []):
                    ev_by.setdefault(f, []).append(e)
        blobs = {}
        for m in _members(state):
            rel = m["rel_in_case"]
            blobs[rel] = "\n".join([_read(m.get("markdown_path", "")),
                                    json.dumps(vis_by.get(rel, []), ensure_ascii=False),
                                    json.dumps(ev_by.get(rel, []), ensure_ascii=False)])
        return blobs

    def case_findings(state) -> Dict[str, Any]:
        summary = state.get("summary") or {}
        path = findings_path(summary)
        files = [m["rel_in_case"] for m in _members(state)]
        run_dir = Path(state["run_dir"])
        layers = _layers(state)
        if path is None or not files:
            _update_status(state, "case_findings", "done", "対象の欄なし")
            return {}
        _update_status(state, "case_findings", peek="「判明した事実」の欄を資料ごと・資料間・結論に分けて書いています…")
        mats = _file_materials(state)
        # 要約の下書きは渡さない。どの資料の話か分からない記述が、資料ごとの欄に紛れ込むため
        material = {"資料ごとの材料": mats, "資料間の比較": state.get("case_comparison") or {}}
        cmp_state = layers.get("comparison") or {}
        if cmp_state and not cmp_state.get("ran"):
            material["資料間の比較"] = f"行っていません（{cmp_state.get('reason', '')}）"
        check_block = state.get("case_page_block") or ""
        user = ("材料：\n" + dumps(material)
                + (("\n\n" + check_block) if check_block else "")
                + "\n\n次の形式の JSON で出力してください：\n"
                + json.dumps(schema_skeleton(CaseFindings.model_json_schema()), ensure_ascii=False))
        report: Dict[str, Any] = {"files": files, "removed": [], "filled_from_analysis": [],
                                  "filled_from_evidence": [], "not_analysed": [], "llm_failed": False}
        cf, attempts = _ask(system=FINDINGS_SYSTEM, user=user, schema=CaseFindings.model_json_schema(),
                            tag="case:findings", max_tokens=int(cc.findings_max_tokens),
                            coerce=coerce_case_findings)
        report["attempts"] = attempts
        if cf is None:
            _push_error(state, "case_findings",
                        "「判明した事実」の専用パスに失敗しました（2 回試しました。資料ごとの材料から組み立てます）",
                        dumps(attempts)[:1500])
            cf = CaseFindings()
            report["llm_failed"] = True

        blobs = _file_blobs(state)
        whole = "\n".join(blobs.values()) + "\n" + json.dumps(
            [e for e in state.get("aggregated_evidence", []) or [] if (e.get("origin") or "") == "reference"],
            ensure_ascii=False)

        def verified(items: List[str], where: str, blob: str, *, own_file: str = "") -> List[str]:
            kept = []
            for it in items:
                t = _clean(it)
                if not t:
                    continue
                bad = unsupported_numbers(t, blob)
                if bad:
                    entry = {"where": where, "text": t, "numbers": [b["text"] for b in bad[:5]]}
                    if own_file:
                        # 他の資料にはある数値か（＝資料の取り違え）を記録する
                        others = [f for f, b in blobs.items() if f != own_file
                                  and not unsupported_numbers(" ".join(entry["numbers"]), b)]
                        entry["reason"] = ("他の資料の数値" if others else "どの資料にも無い数値")
                        if others:
                            entry["found_in"] = others[:3]
                    else:
                        entry["reason"] = "どの資料にも無い数値"
                    report["removed"].append(entry)
                    continue
                kept.append(t)
            return kept

        by_file: Dict[str, List[str]] = {f: [] for f in files}
        for ff in cf.by_file:
            f = match_file(ff.file, files)
            if not f:
                report.setdefault("unknown_files", []).append(ff.file)
                continue
            by_file[f] += verified(ff.points, f, blobs.get(f, ""), own_file=f)

        # モデルが取り上げなかった資料は、その資料自身の分析結果、無ければ証拠から補う。
        # どちらも無い資料は、分析できなかったことをそのまま書く
        amap = {a["file"]: a for a in state.get("file_analyses") or []}
        not_analysed: List[str] = []
        for f in files:
            if by_file[f]:
                continue
            a = amap.get(f) or {}
            if a.get("analysis"):
                an = a["analysis"]
                pts = ([an["purpose"]] if an.get("purpose") else []) + list(an.get("measurements") or []) \
                    + list(an.get("conclusions") or [])
                got = verified(pts, f, blobs.get(f, ""), own_file=f)
                if got:
                    by_file[f] = got
                    report["filled_from_analysis"].append(f)
                    continue
            ev = [e["content"] for e in (a.get("fallback_evidence") or _file_evidence(state, f))
                  if e.get("content")][:FILL_FROM_EVIDENCE_PER_FILE]
            got = verified(ev, f, blobs.get(f, ""), own_file=f)
            if got:
                by_file[f] = got
                report["filled_from_evidence"].append(f)
            else:
                not_analysed.append(f)
        report["not_analysed"] = not_analysed

        comparison = verified(cf.comparison, "資料間の比較", whole) if len(files) > 1 else []
        if len(files) > 1 and not comparison and cmp_state and not cmp_state.get("ran"):
            # 比較をしなかった理由を、そのまま欄に書く（「比較できる点が無い」と区別する）
            comparison = [f"資料間の比較は行っていません（{cmp_state.get('reason', '理由不明')}）"]
        conclusions: List[Tuple[str, str]] = []
        for c in cf.conclusions:
            kind = c.kind.strip() if c.kind.strip() in CONCLUSION_KINDS else ""
            for t in verified([c.text], "案件としての結論", whole):
                conclusions.append((kind, t))
        order = {k: i for i, k in enumerate(CONCLUSION_KINDS)}
        conclusions.sort(key=lambda kc: order.get(kc[0], len(order)))

        file_items = []
        for f in files:
            if by_file[f]:
                file_items.append((f, by_file[f]))
            elif f in not_analysed:
                file_items.append((f, ["この資料は分析できませんでした（原文・画像の読み取りから、"
                                       "要約に使える内容を取り出せませんでした）"]))
        items = findings_to_strings(file_items, comparison, conclusions)
        report["counts"] = {"by_file": sum(len(v) for v in by_file.values()),
                            "comparison": len(comparison), "conclusions": len(conclusions)}
        report["missing_files"] = [f for f in files if not by_file[f]]
        if items:
            set_path(summary, path, items)
            state["summary"] = summary
        else:
            report["kept_draft"] = True
        _save_json(report, run_dir / FINDINGS_REPORT_FILE)
        layers["findings"] = {k: report[k] for k in ("llm_failed", "filled_from_analysis",
                                                    "filled_from_evidence", "not_analysed")}
        layers["findings"]["removed"] = len(report["removed"])
        layers["findings"]["removed_other_file"] = sum(
            1 for r in report["removed"] if r.get("reason") == "他の資料の数値")
        if report["removed"]:
            _push_error(state, "case_findings",
                        f"裏付けの無い数値を含む {len(report['removed'])} 項目を「判明した事実」に入れませんでした"
                        f"（うち他の資料の数値 {layers['findings']['removed_other_file']} 項目）",
                        dumps(report["removed"][:5]))
        c = report["counts"]
        _update_status(state, "case_findings", "done",
                       f"資料別 {c['by_file']}・資料間 {c['comparison']}・結論 {c['conclusions']}",
                       peek=("「判明した事実」を書き分けました" if items
                             else "書き分けられなかったため、要約の下書きのままにしました"))
        return {"summary": summary, "case_layers": layers, "errors": state.get("errors", [])}

    return {"analyze_files": analyze_files, "compare_files": compare_files,
            "case_findings": case_findings}


def external_file_labels(summary: Dict[str, Any], files: List[str]) -> Dict[str, Any]:
    """社外版用：「判明した事実」の資料名（社内のファイル名）を「資料1」「資料2」…に置き換えた写し。"""
    import copy

    path = findings_path(summary)
    if path is None or not files:
        return summary
    out = copy.deepcopy(summary)
    label = {f: f"資料{i}" for i, f in enumerate(files, 1)}
    items = []
    for item in get_path(out, path) or []:
        s = str(item)
        for f, lab in label.items():
            s = s.replace(f"『{f}』", f"『{lab}』")
        items.append(s)
    set_path(out, path, items)
    return out


def analyses_prompt_block(state: Dict[str, Any]) -> str:
    """write_summary に渡す「資料ごとの分析」「資料間の比較」。"""
    fa = state.get("file_analyses") or []
    analyses = [{"file": a["file"], **a["analysis"]} for a in fa if a.get("analysis")]
    failed = [a["file"] for a in fa if not a.get("analysis")]
    if not analyses and not failed:
        return ""
    out = []
    if analyses:
        out += ["資料ごとの分析（各資料の原文を 1 件ずつ読んで整理した物。証拠より詳しい場合はこちらを優先）：",
                json.dumps(analyses, ensure_ascii=False, separators=(",", ":"))]
    if failed:
        out.append("次の資料は整理できませんでした。この資料については、証拠（file がこの資料名の物）"
                   "だけを根拠にしてください：" + "、".join(f"『{f}』" for f in failed))
    comp = state.get("case_comparison") or {}
    if any(comp.get(k) for k in comp):
        out += ["資料間の比較：", json.dumps(comp, ensure_ascii=False, separators=(",", ":"))]
    return "\n".join(out)
