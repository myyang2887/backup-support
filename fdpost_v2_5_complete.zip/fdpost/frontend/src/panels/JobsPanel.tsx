/** Background jobs: 1s polling, progress, result links. */
import { useEffect, useState } from "react";
import { getJob } from "../api";
import type { JobOut } from "../types";
import { useStore } from "../store";
import ExportBar from "./ExportBar";

const KIND_LABEL: Record<string, string> = {
  preprocess: "前処理", axis_slice_batch: "断面バッチ",
  plane_slice_batch: "斜め断面バッチ",
};

function resultFiles(j: JobOut): string[] {
  const r = j.result ?? {};
  const urls: string[] = [];
  if (typeof r.zip_url === "string") urls.push(r.zip_url);
  if (typeof r.csv_url === "string") urls.push(r.csv_url);
  if (Array.isArray(r.file_urls)) urls.push(...r.file_urls.slice(0, 2));
  return urls.map((u) => u.replace("/api/files/", ""));
}

export default function JobsPanel() {
  const jobs = useStore((s) => s.jobs);
  const [state, setState] = useState<Record<string, JobOut>>({});

  useEffect(() => {
    if (!jobs.length) return;
    const t = setInterval(async () => {
      const pending = jobs.filter(
        (id) => !state[id] || !["done", "error"].includes(state[id].status));
      if (!pending.length) return;
      const updates: Record<string, JobOut> = {};
      await Promise.all(pending.map(async (id) => {
        try { updates[id] = await getJob(id); } catch { /* ignore */ }
      }));
      if (Object.keys(updates).length) setState((s) => ({ ...s, ...updates }));
    }, 1000);
    return () => clearInterval(t);
  }, [jobs, state]);

  if (!jobs.length) {
    return <div className="hint" style={{ padding: 12 }}>
      バッチ出力を実行するとここに進捗が表示されます。</div>;
  }
  return (
    <div className="panel">
      <h3>ジョブ</h3>
      {jobs.map((id) => {
        const j = state[id];
        if (!j) return <div key={id} className="mono"
                            style={{ fontSize: 11 }}>{id.slice(0, 8)}…</div>;
        return (
          <div key={id} style={{ marginBottom: 12 }}>
            <div className="row" style={{ fontSize: 12, marginBottom: 4 }}>
              <b>{KIND_LABEL[j.kind] ?? j.kind}</b>
              <span className="mono" style={{ fontSize: 10, marginLeft: "auto",
                color: j.status === "error" ? "var(--err)"
                     : j.status === "done" ? "var(--ok)" : "var(--warn)" }}>
                {j.status}
              </span>
            </div>
            <div style={{ background: "var(--bg-viewport)", borderRadius: 3,
                          height: 6, overflow: "hidden" }}>
              <div style={{ width: `${j.progress * 100}%`, height: 6,
                            background: j.status === "error" ? "var(--err)"
                                                             : "var(--accent)",
                            transition: "width .3s" }} />
            </div>
            {j.status === "running" && j.message && (
              <div className="mono" style={{ fontSize: 10,
                   color: "var(--text-faint)", marginTop: 2 }}>{j.message}</div>
            )}
            {j.error && <div className="err">{j.error}</div>}
            {j.status === "done" && <ExportBar files={resultFiles(j)} />}
          </div>
        );
      })}
    </div>
  );
}
