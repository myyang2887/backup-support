/** Box-region CSV export; the box can be dragged in the 3D view.
 *  Resolution is given either as point counts per axis or as physical steps
 *  per axis (要件書「何mm間隔」), each axis independent. */
import { useState } from "react";
import { postExportStream } from "../api";
import { useStore } from "../store";
import { toast } from "../toast";

import { Vec3Field } from "./ProbePanel";

const LIMIT = 5_000_000;

/** Row count per axis, matching the backend lattice exactly. */
function countFor(lo: number, hi: number, step: number): number {
  const span = hi - lo;
  if (!(step > 0)) return 1;
  return span <= 0 ? 1 : Math.floor(span / step + 1e-9) + 1;
}

export default function RegionPanel() {
  const { meta, activeId, region, setRegion } = useStore();
  const [busy, setBusy] = useState(false);
  if (!meta?.bounds) return <div className="hint">データセットを読み込んでください</div>;

  const counts: [number, number, number] = region.sampling === "count"
    ? region.res
    : ([0, 1, 2].map((i) =>
        countFor(region.min[i], region.max[i], region.step[i])) as any);
  const rows = counts[0] * counts[1] * counts[2];
  const size = [0, 1, 2].map((i) => region.max[i] - region.min[i]);
  const over = rows > LIMIT;

  const run = async () => {
    setBusy(true);
    try {
      const name = await postExportStream(
        `/api/datasets/${activeId}/region`, {
          min_point: region.min, max_point: region.max,
          ...(region.sampling === "count"
            ? { resolution: region.res } : { spacing: region.step }),
        }, "region.csv");
      toast(`${name} をダウンロードしました`);
    } catch (e: any) { toast(e.message, "err"); }
    setBusy(false);
  };

  return (
    <div className="panel">
      <h3>3D領域CSV出力</h3>
      <Vec3Field label="最小点" v={region.min}
                 onChange={(v) => setRegion({ min: v })} />
      <Vec3Field label="最大点" v={region.max}
                 onChange={(v) => setRegion({ max: v })} />

      <div className="tabs" style={{ margin: "10px 0 6px" }}>
        <button className={region.sampling === "step" ? "on" : ""}
                onClick={() => setRegion({ sampling: "step" })}>間隔指定</button>
        <button className={region.sampling === "count" ? "on" : ""}
                onClick={() => setRegion({ sampling: "count" })}>点数指定</button>
      </div>

      {region.sampling === "step" ? (
        <Vec3Field label="間隔 [m]" v={region.step} step="0.0001"
                   onChange={(v) => setRegion({
                     step: v.map((x) => Math.max(1e-9, x)) as any })} />
      ) : (
        <Vec3Field label="点数" v={region.res} step="1"
                   onChange={(v) => setRegion({
                     res: v.map((x) => Math.max(1, Math.round(x))) as any })} />
      )}

      <div className="mono" style={{ fontSize: 11,
           color: over ? "var(--err)" : "var(--text-dim)" }}>
        {counts[0]} x {counts[1]} x {counts[2]} = {rows.toLocaleString()} 行
        {over && ` — 上限 ${LIMIT.toLocaleString()} 行を超えています`}
      </div>
      <div className="row" style={{ marginTop: 8 }}>
        <button className="primary" disabled={over || busy} onClick={run}>
          {busy ? "出力中…" : "CSV出力"}
        </button>
      </div>
      <div className="mono" style={{ fontSize: 11, color: "var(--text-dim)",
                                     marginTop: 4 }}>
        サイズ {size.map((v) => v.toPrecision(3)).join(" x ")} m
      </div>
      <div className="hint" style={{ marginTop: 8 }}>
        3Dビュー左上を <b>「編集」</b>に切り替える(または <b>G</b> キー)と、
        箱の最小/最大コーナーに <b>X(赤)/Y(緑)/Z(青) の矢印</b>が出ます。
        矢印をドラッグするとその面だけが動くので、サイズ変更ができます。
        枠(辺)のドラッグは箱ごと平行移動です。
        「視点」モードではマウスは常に視点操作になります。
        全フィールド + is_solid 列を出力します。
        間隔指定では x/y/z それぞれの刻みが厳密に守られます。
      </div>
    </div>
  );
}
