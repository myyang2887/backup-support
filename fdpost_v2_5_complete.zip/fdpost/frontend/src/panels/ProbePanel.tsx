/** Line probe: drag the endpoints in 3D or type; CSV + curve to the drawer. */
import { useState } from "react";
import { postProbe } from "../api";
import { useStore } from "../store";
import { toast } from "../toast";
import ExportBar from "./ExportBar";

export function Vec3Field(props: {
  label: string; v: [number, number, number];
  onChange: (v: [number, number, number]) => void; step?: string;
}) {
  return (
    <div className="field-grid" style={{ marginBottom: 6 }}>
      <label>{props.label}</label>
      {[0, 1, 2].map((i) => (
        <input key={i} type="number" step={props.step ?? "0.001"}
               value={props.v[i]}
               onChange={(e) => {
                 const nv = [...props.v] as [number, number, number];
                 nv[i] = +e.target.value; props.onChange(nv);
               }} />
      ))}
    </div>
  );
}

export default function ProbePanel() {
  const { meta, activeId, activeField, probe, setProbe, set } = useStore();
  const [n, setN] = useState(200);
  const [files, setFiles] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  if (!meta?.bounds) return <div className="hint">データセットを読み込んでください</div>;

  const run = async () => {
    setBusy(true);
    try {
      const r = await postProbe(activeId!, {
        p0: probe.p0, p1: probe.p1, n_samples: n, fields: [activeField] });
      if (r.png_url) {
        set({ probePng: r.png_url + "?t=" + Date.now(),
              drawerOpen: true, drawerTab: "probe" });
      }
      setFiles([r.csv_url, r.png_url].filter(Boolean)
        .map((u) => (u as string).replace("/api/files/", "")));
      toast(`ラインサンプリング完了(${n} 点)`);
    } catch (e: any) { toast(e.message, "err"); }
    setBusy(false);
  };

  return (
    <div className="panel">
      <h3>2点間ラインサンプリング</h3>
      <Vec3Field label="始点" v={probe.p0} onChange={(v) => setProbe({ p0: v })} />
      <Vec3Field label="終点" v={probe.p1} onChange={(v) => setProbe({ p1: v })} />
      <div className="hint" style={{ margin: "6px 0" }}>
        3Dビュー左上を<b>「編集」</b>に切り替える(または <b>G</b> キー)と、
        両端点に <b>X(赤)/Y(緑)/Z(青) の矢印</b>が出ます。矢印をドラッグすると
        その軸方向にだけ動くので、3D空間でも狙った位置に置けます。
      </div>
      <div className="row" style={{ marginTop: 4 }}>
        <label>サンプル数</label>
        <input type="number" style={{ width: 84 }} value={n} min={2} max={100000}
               onChange={(e) => setN(+e.target.value)} />
        <button className="primary" style={{ marginLeft: "auto" }}
                onClick={run} disabled={busy}>
          {busy ? "実行中…" : "実行"}
        </button>
      </div>
      <div className="hint" style={{ marginTop: 8 }}>
        3Dビューの端点球をドラッグして測定線を動かせます。
        固体を通る区間は CSV で is_solid=True、グラフは断線します。
      </div>
      <ExportBar files={files} />
    </div>
  );
}
