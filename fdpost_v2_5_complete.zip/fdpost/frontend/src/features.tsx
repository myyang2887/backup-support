/** Feature flags: every UI capability can be switched off for debugging.
 *
 *  Design rules (keep it clean):
 *  - This file is the single registry. Adding a flag = one entry here
 *    + one <Feature> wrapper (or useFeature check) at the render site.
 *  - Granularity follows linked behavior: disabling a tool hides its rail
 *    button, its panel, its gizmo and its 3D layers together.
 *  - All defaults are ON; overrides persist per-browser (localStorage).
 */
import { ReactNode } from "react";
import { create } from "zustand";

export interface FeatureDef {
  id: string; label: string; desc: string; group: string;
}

export const FEATURE_DEFS: FeatureDef[] = [
  // ツール: ボタン + パネル + ギズモ + 3Dレイヤーが連動して消えます
  { id: "tool.slice",   group: "ツール", label: "断面",
    desc: "軸直交・自由平面の断面(ギズモ含む)" },
  { id: "tool.probe",   group: "ツール", label: "ライン",
    desc: "2点間サンプリング(端点ギズモ含む)" },
  { id: "tool.stream",  group: "ツール", label: "流線",
    desc: "シードレーク・RK4積分(3D流線レイヤー含む)" },
  { id: "tool.iso",     group: "ツール", label: "等値面",
    desc: "marching cubes(3Dメッシュレイヤー含む)" },
  { id: "tool.region",  group: "ツール", label: "領域",
    desc: "3D box領域CSV出力(箱ギズモ含む)" },
  { id: "tool.display",  group: "ツール", label: "表示",
    desc: "点群フィルタ・速度矢印・サーフェス表現の設定パネル" },
  { id: "tool.jobs",    group: "ツール", label: "ジョブ",
    desc: "バッチ処理の進捗一覧" },
  { id: "slice.batch",  group: "ツール", label: "断面バッチ出力",
    desc: "断面パネル内のPNG一括出力セクション" },
  { id: "slice.csv",    group: "ツール", label: "断面CSV出力",
    desc: "断面パネル内の指定解像度CSV出力セクション" },
  // 3Dビュー
  { id: "viewport.drag",       group: "3Dビュー", label: "ギズモのドラッグ操作",
    desc: "OFFにすると数値入力のみに。ONのままでもAlt+ドラッグで視点回転できます" },
  { id: "viewport.keyboard",   group: "3Dビュー", label: "キーボード操作",
    desc: "←→で断面送り / Rで視点リセット" },
  { id: "viewport.cursorHud",  group: "3Dビュー", label: "カーソル座標読み取り",
    desc: "HUDチップ・ヘッダの「座標」ボタン・2D図のホバー" },
  { id: "viewport.arrows",     group: "3Dビュー", label: "速度矢印(3D)",
    desc: "3Dビューの速度ベクトル矢印レイヤーと設定" },
  { id: "viewport.shells",     group: "3Dビュー", label: "サーフェス表現(多重等値面)",
    desc: "等値面ツール内の多重半透明サーフェスと3Dレイヤー" },
  { id: "viewport.quiver2d",   group: "3Dビュー", label: "断面の速度矢印(2D)",
    desc: "実時間断面図に重ねる矢印" },
  { id: "viewport.colorbar",   group: "3Dビュー", label: "カラーバー凡例",
    desc: "ビューポート右のスケール表示" },
  { id: "viewport.modeSwitch", group: "3Dビュー", label: "3D表示モード切替",
    desc: "ポイントクラウド/完全3Dの切替セレクタ" },
  // 画面
  { id: "shell.drawer",    group: "画面", label: "結果ドロワー",
    desc: "下部の断面/ライン結果表示(実時間断面含む)" },
  { id: "shell.statusbar", group: "画面", label: "ステータスバー",
    desc: "最下部のデータ情報・座標ミラー" },
  // 保存・共有
  { id: "persist.sessions", group: "保存・共有", label: "セッション保存",
    desc: "作業状態の保存/復元メニュー" },
  { id: "persist.share",    group: "保存・共有", label: "共有リンク",
    desc: "読み取り専用スナップショットのURL発行" },
];

export type FeatureId =
  | "tool.slice" | "tool.probe" | "tool.stream" | "tool.iso"
  | "tool.region" | "tool.display" | "tool.jobs"
  | "slice.batch" | "slice.csv"
  | "viewport.drag" | "viewport.keyboard" | "viewport.cursorHud"
  | "viewport.arrows" | "viewport.shells" | "viewport.quiver2d"
  | "viewport.colorbar" | "viewport.modeSwitch"
  | "shell.drawer" | "shell.statusbar"
  | "persist.sessions" | "persist.share";

const KEY = "fdpost.features.v1";

function loadOverrides(): Record<string, boolean> {
  try { return JSON.parse(localStorage.getItem(KEY) ?? "{}"); }
  catch { return {}; }
}

interface FS {
  overrides: Record<string, boolean>;    // absent = default (ON)
  toggle: (id: FeatureId) => void;
  reset: () => void;
}

export const useFeatures = create<FS>((set) => ({
  overrides: loadOverrides(),
  toggle: (id) => set((s) => {
    const overrides = { ...s.overrides, [id]: !(s.overrides[id] ?? true) };
    if (overrides[id]) delete overrides[id];      // store only OFF entries
    try { localStorage.setItem(KEY, JSON.stringify(overrides)); }
    catch { /* private mode etc. */ }
    return { overrides };
  }),
  reset: () => {
    try { localStorage.removeItem(KEY); } catch { /* ignore */ }
    set({ overrides: {} });
  },
}));

export const isOn = (id: FeatureId,
                     overrides: Record<string, boolean>): boolean =>
  overrides[id] ?? true;

/** Hook: subscribe to one flag. */
export function useFeature(id: FeatureId): boolean {
  return useFeatures((s) => isOn(id, s.overrides));
}

/** Non-hook read for event handlers / imperative code. */
export const featureOn = (id: FeatureId): boolean =>
  isOn(id, useFeatures.getState().overrides);

/** Declarative wrapper: <Feature id="persist.share">…</Feature> */
export function Feature(props: { id: FeatureId; children: ReactNode }) {
  return useFeature(props.id) ? <>{props.children}</> : null;
}
