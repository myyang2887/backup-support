"""Binary 3D geometry endpoints: isosurface mesh + streamline polylines.

Wire formats (little-endian, offsets all 4-byte aligned):
  isosurface : uint32 nV | uint32 nF | f32 verts (nV,3) | f32 normals (nV,3)
               | uint32 faces (nF,3)
  streamlines: uint32 nL | uint32 counts (nL,) | f32 points (sum,3)
               | f32 speeds (sum,)
"""
from __future__ import annotations

import struct

import numpy as np
from fastapi import APIRouter, Request, Response

from fdpost.core.isosurface import compute_isosurface, field_range
from fdpost.core.streamlines import line_seeds, trace_streamlines
from fdpost.domain.requests import StreamlineRequest

router = APIRouter(prefix="/api/datasets/{ds_id}", tags=["viz3d"])


@router.get("/isosurface/{field}/range")
def iso_range(ds_id: str, field: str, request: Request):
    grid = request.app.state.store.get_grid(ds_id)
    lo, hi = field_range(grid, field)
    return {"min": lo, "max": hi}


@router.get("/isosurface/{field}")
def isosurface(ds_id: str, field: str, level: float, request: Request,
               max_dim: int = 192, smooth: float = 1.0,
               min_component_frac: float = 0.0) -> Response:
    grid = request.app.state.store.get_grid(ds_id)
    verts, faces, normals = compute_isosurface(
        grid, field, level, max_dim=max(16, min(512, max_dim)),
        smooth=max(0.0, min(4.0, smooth)),
        min_component_frac=max(0.0, min(0.9, min_component_frac)))
    blob = (struct.pack("<II", verts.shape[0], faces.shape[0])
            + verts.tobytes() + normals.tobytes() + faces.tobytes())
    return Response(content=blob, media_type="application/octet-stream",
                    headers={"X-Verts": str(verts.shape[0]),
                             "X-Faces": str(faces.shape[0])})


@router.post("/streamlines")
def streamlines(ds_id: str, req: StreamlineRequest, request: Request) -> Response:
    grid = request.app.state.store.get_grid(ds_id)
    seeds = line_seeds(req.p0, req.p1, req.n_seeds)
    step = req.step_scale * float(grid.spacing.min())
    lines = [ln for ln in trace_streamlines(grid, seeds, step=step,
                                            max_steps=req.max_steps,
                                            direction=req.direction)
             if ln[0].shape[0] >= 2]
    counts = np.array([ln[0].shape[0] for ln in lines], dtype=np.uint32)
    pts = (np.vstack([ln[0] for ln in lines]).astype(np.float32)
           if lines else np.empty((0, 3), np.float32))
    spd = (np.concatenate([ln[1] for ln in lines]).astype(np.float32)
           if lines else np.empty(0, np.float32))
    blob = (struct.pack("<I", len(lines)) + counts.tobytes()
            + pts.tobytes() + spd.tobytes())
    return Response(content=blob, media_type="application/octet-stream",
                    headers={"X-Lines": str(len(lines))})
