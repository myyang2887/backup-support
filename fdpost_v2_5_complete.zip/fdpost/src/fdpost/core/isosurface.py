"""Isosurface extraction (marching cubes) on the cached uniform grid.
scikit-image is BSD-3 licensed.

Producing a *good looking* surface is mostly about what happens to the data
before marching cubes ever runs. Three things decide it:

1. **Solid handling.** Passing skimage's `mask=` skips every cube that
   touches a solid voxel, which punches ragged holes wherever the flow meets
   a wall. Instead the solid region is filled with a sentinel *below* the
   whole field range, so any level is guaranteed to sit outside it: the
   surface then closes cleanly against the wall and never passes through it.
2. **Open borders.** Marching cubes leaves the surface open where it exits
   the array, which reads as missing chunks. Padding one voxel of sentinel
   around the volume caps it into a closed shell.
3. **Noise.** Interpolated CFD data is lumpy at voxel scale; a light
   Gaussian blur before extraction is what turns stair-stepped blobs into
   smooth, flowing surfaces. It costs nothing and dominates the visual
   result.
"""
from __future__ import annotations

import numpy as np
from scipy import ndimage
from skimage import measure

from fdpost.domain.errors import GridBuildError
from fdpost.domain.uniform_grid import UniformGrid


def field_range(grid: UniformGrid, field: str) -> tuple[float, float]:
    arr = grid.masked(field)
    if np.all(np.isnan(arr)):
        raise GridBuildError(f"field '{field}' has no fluid data")
    return float(np.nanmin(arr)), float(np.nanmax(arr))


def _prepare_volume(g: UniformGrid, field: str, smooth: float
                    ) -> tuple[np.ndarray, float, float]:
    """Solid-filled, smoothed, sentinel-padded volume ready for extraction."""
    arr = g.masked(field)                       # NaN at solid
    finite = np.isfinite(arr)
    if finite.sum() < 8:
        raise GridBuildError(f"field '{field}' has too little fluid data")
    lo, hi = float(np.nanmin(arr)), float(np.nanmax(arr))
    span = (hi - lo) or 1.0
    sentinel = lo - 0.10 * span                 # strictly outside every level

    vol = np.where(finite, arr, sentinel).astype(np.float32)
    if smooth > 0:
        # blur the field, and blur the fluid indicator the same way, so the
        # wall stays put instead of creeping outward with the smoothing
        weight = ndimage.gaussian_filter(finite.astype(np.float32), smooth)
        blurred = ndimage.gaussian_filter(
            np.where(finite, arr, 0.0).astype(np.float32), smooth)
        with np.errstate(invalid="ignore", divide="ignore"):
            filled = np.where(weight > 1e-6, blurred / np.maximum(weight, 1e-6),
                              sentinel)
        vol = np.where(finite, filled, sentinel).astype(np.float32)

    vol = np.pad(vol, 1, mode="constant", constant_values=sentinel)
    return vol, lo, hi


def compute_isosurface(grid: UniformGrid, field: str, level: float,
                       max_dim: int = 192, smooth: float = 1.0,
                       min_component_frac: float = 0.0
                       ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Returns (verts (V,3) f32 world coords, faces (F,3) u32, normals (V,3) f32).

    `smooth` is the Gaussian sigma in voxels (0 disables).
    `min_component_frac` drops connected blobs smaller than this fraction of
    the largest one — useful for clearing speckle at aggressive levels.
    """
    g = grid.downsample(max_dim) if max(grid.dims) > max_dim else grid
    vol, lo, hi = _prepare_volume(g, field, smooth)
    if not (lo < level < hi):
        raise GridBuildError(
            f"level {level:g} outside the field range ({lo:g} .. {hi:g})")

    if min_component_frac > 0:
        vol = _drop_small_blobs(vol, float(level), min_component_frac)

    try:
        verts, faces, normals, _ = measure.marching_cubes(
            vol, level=float(level), spacing=tuple(g.spacing))
    except (ValueError, RuntimeError) as e:
        raise GridBuildError(f"isosurface failed: {e}") from e
    if verts.shape[0] == 0:
        raise GridBuildError("isosurface is empty at this level")

    # undo the 1-voxel pad, then move into world coordinates
    verts = verts - g.spacing[None, :] + g.origin[None, :]
    # the cap generated inside the pad lands just outside the data box;
    # clamping flattens it exactly onto the boundary plane (the usual
    # "surface clipped by the domain" look) and keeps every vert in bounds
    b = g.bounds
    verts = np.clip(verts, b[0][None, :], b[1][None, :])
    return (verts.astype(np.float32), faces.astype(np.uint32),
            normals.astype(np.float32))


def _drop_small_blobs(vol: np.ndarray, level: float, frac: float) -> np.ndarray:
    """Flatten connected regions above `level` that are much smaller than the
    biggest one — removes floating speckle without touching the main body."""
    labels, n = ndimage.label(vol > level)
    if n <= 1:
        return vol
    sizes = np.bincount(labels.ravel())
    sizes[0] = 0
    keep = sizes >= max(1, int(frac * sizes.max()))
    return np.where(keep[labels], vol, vol.min()).astype(np.float32)
