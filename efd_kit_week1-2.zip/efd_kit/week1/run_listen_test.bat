@echo off
rem FLOEFD automation - inbound port test, run on the REMOTE (FLOEFD) machine.
rem Opens one TCP port for a limited time so another PC can test reachability.
rem Usage: run_listen_test.bat [port] [seconds]     defaults: 50555 180
setlocal
cd /d "%~dp0"
set PORT=%~1
if "%PORT%"=="" set PORT=50555
set SECS=%~2
if "%SECS%"=="" set SECS=180
echo Listening on TCP %PORT% for %SECS% seconds.
echo On the other PC run:  client_portcheck.bat ^<this-machine-ip^> %PORT%
echo If Windows asks to allow firewall access, choose Cancel and ask IT instead.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0survey.ps1" -SkipNetwork -ListenPort %PORT% -ListenSeconds %SECS%
pause
