@echo off
rem FLOEFD automation - Week 1 environment survey (read-only).
rem Double-click, or run from cmd. Extra options are passed to survey.ps1, e.g.
rem   run_survey.bat -SkipNetwork
setlocal
cd /d "%~dp0"
echo FLOEFD environment survey (read-only). This usually takes 1-3 minutes.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0survey.ps1" %*
echo.
echo Finished. Open the newest survey_* folder and read summary.md first.
pause
