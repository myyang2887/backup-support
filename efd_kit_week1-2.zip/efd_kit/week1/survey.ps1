﻿<#
  FLOEFD automation - Week 1 environment survey (read-only)

  What it does
    Collects facts about this machine that decide whether FLOEFD can be
    automated from Python: FLOEFD products/versions and their COM launcher
    ProgIDs, type library files, Python / pywin32, Office (for a VBA fallback),
    network and proxy, remote-desktop session, license-related env vars.

  What it does NOT do
    Installs nothing, changes no settings, starts no FLOEFD.
    Only with -ListenPort does it open a TCP port for a limited time, so that
    another PC can test whether it can reach this machine.

  Output
    survey_<COMPUTER>_<time>\report.json   all collected data
    survey_<COMPUTER>_<time>\summary.md    short Chinese summary for the weekly report
    survey_<COMPUTER>_<time>\survey.log    what ran and what failed
    survey_<COMPUTER>_<time>.zip           the folder above, zipped

  Usage (normally via run_survey.bat)
    powershell -NoProfile -ExecutionPolicy Bypass -File survey.ps1
    powershell -NoProfile -ExecutionPolicy Bypass -File survey.ps1 -SkipNetwork
    powershell -NoProfile -ExecutionPolicy Bypass -File survey.ps1 -ListenPort 50555 -ListenSeconds 180

  Compatible with Windows PowerShell 5.1 (no PowerShell 7 required).
#>
param(
    [string]$OutDir = "",
    [int]$ListenPort = 0,
    [int]$ListenSeconds = 180,
    [switch]$SkipNetwork,
    [int]$SearchDepth = 4
)

$ErrorActionPreference = 'Continue'
$script:Started = Get-Date
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$baseDir = $PSScriptRoot
if (-not $baseDir) { $baseDir = (Get-Location).Path }
if (-not $OutDir) { $OutDir = Join-Path $baseDir ("survey_{0}_{1}" -f $env:COMPUTERNAME, $stamp) }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$script:LogLines = New-Object System.Collections.Generic.List[string]
function Write-Note([string]$msg) {
    $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $msg
    $script:LogLines.Add($line)
    Write-Host $line
}

# Runs a block; on error records the message instead of stopping the survey.
function Invoke-Section([string]$name, [scriptblock]$block) {
    $t0 = Get-Date
    try {
        $r = & $block
        Write-Note ("OK   {0} ({1:N1}s)" -f $name, ((Get-Date) - $t0).TotalSeconds)
        # The leading comma keeps an array intact when it is returned.
        return , $r
    } catch {
        Write-Note ("FAIL {0}: {1}" -f $name, $_.Exception.Message)
        return [ordered]@{ error = $_.Exception.Message }
    }
}

function Get-CimSafe([string]$cls) {
    try { return Get-CimInstance -ClassName $cls -ErrorAction Stop }
    catch { return Get-WmiObject -Class $cls -ErrorAction SilentlyContinue }
}

function Get-RegDefault([string]$path) {
    try {
        $item = Get-Item -LiteralPath $path -ErrorAction Stop
        $v = $item.GetValue('')
        if ($null -ne $v) { return [string]$v }
    } catch { }
    return $null
}

# Runs an exe with a timeout and returns exit code + output. Never hangs the survey.
function Invoke-Exe([string]$exe, [string]$arguments, [int]$timeoutSec = 30) {
    $res = [ordered]@{ exe = $exe; args = $arguments; exit = $null; stdout = ''; stderr = ''; timed_out = $false }
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $exe
        $psi.Arguments = $arguments
        $psi.UseShellExecute = $false
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.CreateNoWindow = $true
        $p = [System.Diagnostics.Process]::Start($psi)
        $outTask = $p.StandardOutput.ReadToEndAsync()
        $errTask = $p.StandardError.ReadToEndAsync()
        if (-not $p.WaitForExit($timeoutSec * 1000)) {
            try { $p.Kill() } catch { }
            $res.timed_out = $true
        } else {
            $res.exit = $p.ExitCode
        }
        $res.stdout = $outTask.Result.Trim()
        $res.stderr = $errTask.Result.Trim()
    } catch {
        $res.stderr = $_.Exception.Message
    }
    return $res
}

# Full path of a Windows system exe, or $null when it cannot be located.
function Get-SysExe([string]$name) {
    if ($env:SystemRoot) {
        $p = Join-Path $env:SystemRoot ("System32\" + $name)
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

$report = [ordered]@{}
$report.meta = [ordered]@{
    tool = 'floefd-week1-survey'
    tool_version = '1.0'
    started = $script:Started.ToString('s')
    out_dir = $OutDir
}

Write-Note "FLOEFD environment survey started. Output: $OutDir"

# ---------------------------------------------------------------- system
$report.system = Invoke-Section 'system' {
    $os = Get-CimSafe 'Win32_OperatingSystem'
    $cs = Get-CimSafe 'Win32_ComputerSystem'
    $cpu = Get-CimSafe 'Win32_Processor' | Select-Object -First 1
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    [ordered]@{
        computer         = $env:COMPUTERNAME
        user             = ("{0}\{1}" -f $env:USERDOMAIN, $env:USERNAME)
        is_admin         = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        os               = $os.Caption
        os_version       = $os.Version
        os_build         = $os.BuildNumber
        os_arch          = $os.OSArchitecture
        ui_culture       = (Get-UICulture).Name
        system_codepage  = [System.Text.Encoding]::Default.CodePage
        cpu              = $cpu.Name
        cpu_cores        = $cpu.NumberOfCores
        cpu_threads      = $cpu.NumberOfLogicalProcessors
        ram_gb           = [math]::Round(($cs.TotalPhysicalMemory / 1GB), 1)
        powershell       = $PSVersionTable.PSVersion.ToString()
        execution_policy = ((Get-ExecutionPolicy -List | ForEach-Object { "{0}={1}" -f $_.Scope, $_.ExecutionPolicy }) -join '; ')
    }
}

$report.disks = Invoke-Section 'disks' {
    , @(Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Used -ne $null } | ForEach-Object {
        [ordered]@{ drive = $_.Name; free_gb = [math]::Round($_.Free / 1GB, 1); used_gb = [math]::Round($_.Used / 1GB, 1) }
    })
}

# ---------------------------------------------------------------- session
$report.session = Invoke-Section 'session' {
    $qu = $null
    $quserExe = Get-SysExe 'quser.exe'
    if ($quserExe) { $qu = Invoke-Exe $quserExe '' 10 }
    [ordered]@{
        session_name   = $env:SESSIONNAME
        session_id     = [System.Diagnostics.Process]::GetCurrentProcess().SessionId
        is_remote      = $null
        quser          = if ($qu) { $qu.stdout } else { $null }
    }
}
# TerminalServerSession needs the WinForms assembly.
try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    $report.session.is_remote = [System.Windows.Forms.SystemInformation]::TerminalServerSession
} catch { }

# ---------------------------------------------------------------- installed software
$uninstallRoots = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
)
$installed = Invoke-Section 'installed software' {
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($root in $uninstallRoots) {
        Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue | ForEach-Object {
            $p = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
            if ($p -and $p.DisplayName) {
                $rows.Add([ordered]@{
                    name      = [string]$p.DisplayName
                    version   = [string]$p.DisplayVersion
                    publisher = [string]$p.Publisher
                    location  = [string]$p.InstallLocation
                    hive      = $root
                })
            }
        }
    }
    , $rows.ToArray()
}
if ($installed -is [System.Collections.IDictionary]) { $installed = @() }
$report.floefd_installs = @($installed | Where-Object { $_.name -match 'FLOEFD|FloEFD|Simcenter' })
$report.python_installs = @($installed | Where-Object { $_.name -match '^Python [0-9]' })
$report.office_installs = @($installed | Where-Object { $_.name -match 'Microsoft Office|Microsoft 365|Excel' })

# ---------------------------------------------------------------- COM launcher ProgIDs
$productNames = @{ '0' = 'Standalone'; '2' = 'CATIA V5'; '3' = 'Creo'; '4' = 'NX'; '5' = 'Solid Edge' }

function Get-ClsidInfo([string]$clsid) {
    $info = [ordered]@{ clsid = $clsid; local_server = $null; inproc_server = $null; typelib = $null; view = $null }
    foreach ($view in @('CLSID', 'WOW6432Node\CLSID')) {
        $base = "Registry::HKEY_CLASSES_ROOT\$view\$clsid"
        if (Test-Path -LiteralPath $base) {
            $info.view = $view
            $info.local_server = Get-RegDefault "$base\LocalServer32"
            $info.inproc_server = Get-RegDefault "$base\InprocServer32"
            $info.typelib = Get-RegDefault "$base\TypeLib"
            break
        }
    }
    return $info
}

$report.com_launchers = Invoke-Section 'COM launcher ProgIDs' {
    $names = @(Get-ChildItem -LiteralPath 'Registry::HKEY_CLASSES_ROOT' -Name -ErrorAction SilentlyContinue |
               Where-Object { $_ -like 'EFDApi*' })
    , @($names | ForEach-Object {
        $prog = $_
        $clsid = Get-RegDefault "Registry::HKEY_CLASSES_ROOT\$prog\CLSID"
        $code = $null; $ver = $null; $product = $null
        if ($prog -match '^EFDApiSrv\.EFDLauncher\.(\d+)\.(\d+)$') {
            $code = $Matches[1]; $ver = [int]$Matches[2]
            if ($productNames.ContainsKey($code)) { $product = $productNames[$code] } else { $product = "unknown code $code" }
        }
        $ci = $null
        if ($clsid) { $ci = Get-ClsidInfo $clsid }
        [ordered]@{
            progid       = $prog
            product_code = $code
            product      = $product
            version      = $ver
            new_api_ok   = if ($ver) { $ver -ge 2312 } else { $null }
            clsid        = $clsid
            server       = $ci
        }
    })
}

# ---------------------------------------------------------------- type libraries
$report.typelibs_registered = Invoke-Section 'registered type libraries' {
    $found = New-Object System.Collections.Generic.List[object]
    Get-ChildItem -LiteralPath 'Registry::HKEY_CLASSES_ROOT\TypeLib' -ErrorAction SilentlyContinue | ForEach-Object {
        $guidKey = $_
        Get-ChildItem -LiteralPath $guidKey.PSPath -ErrorAction SilentlyContinue | ForEach-Object {
            $verKey = $_
            $desc = $verKey.GetValue('')
            if ($desc -and ([string]$desc -match 'EFD')) {
                $paths = [ordered]@{}
                Get-ChildItem -LiteralPath $verKey.PSPath -ErrorAction SilentlyContinue | ForEach-Object {
                    Get-ChildItem -LiteralPath $_.PSPath -ErrorAction SilentlyContinue | ForEach-Object {
                        $paths[$_.PSChildName] = $_.GetValue('')
                    }
                }
                $found.Add([ordered]@{ guid = $guidKey.PSChildName; version = $verKey.PSChildName; name = [string]$desc; paths = $paths })
            }
        }
    }
    , $found.ToArray()
}

$report.typelib_files = Invoke-Section 'type library files on disk' {
    $roots = New-Object System.Collections.Generic.List[string]
    foreach ($l in $report.com_launchers) {
        if ($l.server -and $l.server.local_server) {
            $exe = ([string]$l.server.local_server).Trim().Trim('"')
            if ($exe -match '^(.+?\.exe)') { $exe = $Matches[1] }
            $dir = Split-Path -Parent $exe
            if ($dir) { $roots.Add($dir); $roots.Add((Split-Path -Parent $dir)) }
        }
    }
    foreach ($i in $report.floefd_installs) { if ($i.location) { $roots.Add($i.location) } }
    foreach ($pf in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ($pf) {
            Get-ChildItem -LiteralPath $pf -Directory -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match 'FLOEFD|FloEFD|Siemens|Simcenter' } |
                ForEach-Object { $roots.Add($_.FullName) }
        }
    }
    $seen = @{}
    $files = New-Object System.Collections.Generic.List[object]
    foreach ($r in ($roots | Where-Object { $_ } | Select-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $r)) { continue }
        Get-ChildItem -LiteralPath $r -Recurse -Depth $SearchDepth -Filter 'EFDApi*.tlb' -File -ErrorAction SilentlyContinue | ForEach-Object {
            if (-not $seen.ContainsKey($_.FullName)) {
                $seen[$_.FullName] = $true
                $files.Add([ordered]@{ path = $_.FullName; size = $_.Length; modified = $_.LastWriteTime.ToString('s') })
            }
        }
    }
    [ordered]@{ searched = @($roots | Select-Object -Unique); files = $files.ToArray() }
}

# ---------------------------------------------------------------- running processes
$report.processes = Invoke-Section 'related processes' {
    , @(Get-Process -ErrorAction SilentlyContinue |
      Where-Object { $_.ProcessName -match 'efd|floefd|simcenter|ugraf|xtop|cnext|python|excel' -and $_.ProcessName -notmatch '^msedge' } |
      ForEach-Object {
          $path = $null; try { $path = $_.Path } catch { }
          [ordered]@{ name = $_.ProcessName; id = $_.Id; session = $_.SessionId; path = $path }
      })
}

# ---------------------------------------------------------------- Python
$report.python = Invoke-Section 'python' {
    $cands = New-Object System.Collections.Generic.List[string]
    foreach ($n in @('python.exe', 'python3.exe', 'py.exe')) {
        Get-Command $n -All -ErrorAction SilentlyContinue | ForEach-Object { $cands.Add($_.Source) }
    }
    foreach ($glob in @("$env:LOCALAPPDATA\Programs\Python\Python*\python.exe", "$env:ProgramFiles\Python*\python.exe", 'C:\Python*\python.exe')) {
        Get-ChildItem -Path $glob -ErrorAction SilentlyContinue | ForEach-Object { $cands.Add($_.FullName) }
    }
    $results = New-Object System.Collections.Generic.List[object]
    $code = 'import sys,struct;print(sys.version.split()[0]);print(struct.calcsize(chr(80))*8);print(sys.executable)'
    $pyw = 'import win32com.client,pythoncom;print(chr(111)+chr(107))'
    foreach ($exe in ($cands | Select-Object -Unique)) {
        $row = [ordered]@{ path = $exe; note = $null; version = $null; bits = $null; pywin32 = $null; pip = $null }
        if ($exe -match '\\WindowsApps\\') {
            # Microsoft Store alias: running it may open the Store instead of Python.
            $row.note = 'Microsoft Store alias, not executed'
            $results.Add($row); continue
        }
        if ($exe -match '\\py\.exe$') {
            $r = Invoke-Exe $exe '-0p' 15
            $row.note = 'py launcher; installed versions listed in version field'
            $row.version = $r.stdout
            $results.Add($row); continue
        }
        $r = Invoke-Exe $exe ('-c "' + $code + '"') 20
        if ($r.exit -eq 0) {
            $lines = $r.stdout -split "`r?`n"
            $row.version = $lines[0]; $row.bits = $lines[1]
            $r2 = Invoke-Exe $exe ('-c "' + $pyw + '"') 20
            $row.pywin32 = ($r2.exit -eq 0 -and $r2.stdout -match 'ok')
            $r3 = Invoke-Exe $exe '-m pip --version' 20
            $row.pip = $r3.stdout
        } else {
            $row.note = ("run failed: exit={0} timed_out={1} {2}" -f $r.exit, $r.timed_out, $r.stderr)
        }
        $results.Add($row)
    }
    , $results.ToArray()
}

# ---------------------------------------------------------------- script hosts (fallback probes)
$report.script_hosts = Invoke-Section 'script hosts' {
    [ordered]@{
        cscript_exists      = [bool](Get-SysExe 'cscript.exe')
        excel_com_available = (Test-Path -LiteralPath 'Registry::HKEY_CLASSES_ROOT\Excel.Application')
    }
}

# ---------------------------------------------------------------- licenses
$report.license_env = Invoke-Section 'license environment variables' {
    $o = [ordered]@{}
    Get-ChildItem env: | Where-Object { $_.Name -match 'LICENSE|SALT|MGLS|LM_|FLEX' } | ForEach-Object { $o[$_.Name] = $_.Value }
    $o
}

# ---------------------------------------------------------------- network
if (-not $SkipNetwork) {
    $report.network = Invoke-Section 'network' {
        $ips = @()
        try {
            $ips = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
                     Where-Object { $_.IPAddress -ne '127.0.0.1' } |
                     ForEach-Object { "{0} ({1})" -f $_.IPAddress, $_.InterfaceAlias })
        } catch {
            $ips = @([System.Net.Dns]::GetHostAddresses($env:COMPUTERNAME) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | ForEach-Object { $_.ToString() })
        }
        $winhttp = [ordered]@{ stdout = $null }
        $netsh = Get-SysExe 'netsh.exe'
        if ($netsh) { $winhttp = Invoke-Exe $netsh 'winhttp show proxy' 10 }
        $inet = Get-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction SilentlyContinue
        $fw = @()
        try { $fw = @(Get-NetFirewallProfile -ErrorAction Stop | ForEach-Object { "{0}={1}" -f $_.Name, $_.Enabled }) } catch { }

        $tcp = New-Object System.Collections.Generic.List[object]
        foreach ($h in @('pypi.org', 'files.pythonhosted.org', 'github.com', 'api.openai.com', 'login.microsoftonline.com')) {
            $ok = $false; $err = $null
            try {
                $c = New-Object System.Net.Sockets.TcpClient
                $ar = $c.BeginConnect($h, 443, $null, $null)
                if ($ar.AsyncWaitHandle.WaitOne(4000)) { $c.EndConnect($ar); $ok = $true } else { $err = 'timeout 4s' }
                $c.Close()
            } catch { $err = $_.Exception.Message }
            $tcp.Add([ordered]@{ host = $h; port = 443; direct_tcp_ok = $ok; error = $err })
        }
        $http = $null
        try {
            $resp = Invoke-WebRequest -UseBasicParsing -Uri 'https://pypi.org/simple/pip/' -Method Head -TimeoutSec 10 -ErrorAction Stop
            $http = [ordered]@{ url = 'https://pypi.org/simple/pip/'; ok = $true; status = [int]$resp.StatusCode }
        } catch {
            $http = [ordered]@{ url = 'https://pypi.org/simple/pip/'; ok = $false; error = $_.Exception.Message }
        }
        [ordered]@{
            ipv4              = $ips
            winhttp_proxy     = $winhttp.stdout
            ie_proxy_enabled  = $inet.ProxyEnable
            ie_proxy_server   = $inet.ProxyServer
            ie_proxy_pac      = $inet.AutoConfigURL
            env_proxy         = [ordered]@{ HTTP_PROXY = $env:HTTP_PROXY; HTTPS_PROXY = $env:HTTPS_PROXY }
            firewall_profiles = $fw
            tcp_443           = $tcp.ToArray()
            https_via_system  = $http
        }
    }
} else {
    $report.network = [ordered]@{ skipped = $true }
}

# ---------------------------------------------------------------- optional inbound port test
if ($ListenPort -gt 0) {
    $report.listen_test = Invoke-Section ("listen test on port {0}" -f $ListenPort) {
        $result = [ordered]@{ port = $ListenPort; seconds = $ListenSeconds; started = $false; connections = @(); error = $null }
        $listener = $null
        try {
            $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, $ListenPort)
            $listener.Start()
            $result.started = $true
            Write-Note ("Listening on TCP {0} for {1}s. On the other PC run: client_portcheck.bat <this-ip> {0}" -f $ListenPort, $ListenSeconds)
            Write-Note "If Windows asks to allow access through the firewall, choose Cancel and ask IT instead."
            $deadline = (Get-Date).AddSeconds($ListenSeconds)
            $conns = New-Object System.Collections.Generic.List[string]
            while ((Get-Date) -lt $deadline) {
                if ($listener.Pending()) {
                    $client = $listener.AcceptTcpClient()
                    $ep = $client.Client.RemoteEndPoint.ToString()
                    $conns.Add(("{0} at {1}" -f $ep, (Get-Date -Format 'HH:mm:ss')))
                    Write-Note "Connection received from $ep"
                    try {
                        $bytes = [System.Text.Encoding]::ASCII.GetBytes("FLOEFD-SURVEY-OK`r`n")
                        $client.GetStream().Write($bytes, 0, $bytes.Length)
                    } catch { }
                    $client.Close()
                }
                Start-Sleep -Milliseconds 250
            }
            $result.connections = $conns.ToArray()
        } catch {
            $result.error = $_.Exception.Message
        } finally {
            if ($listener) { try { $listener.Stop() } catch { } }
        }
        $result
    }
}

# ---------------------------------------------------------------- write outputs
$report.meta.finished = (Get-Date).ToString('s')
$jsonPath = Join-Path $OutDir 'report.json'
$report | ConvertTo-Json -Depth 8 | Out-File -LiteralPath $jsonPath -Encoding utf8

# ---- Chinese summary for the weekly report
$sb = New-Object System.Text.StringBuilder
function Add-Line([string]$s) { [void]$sb.AppendLine($s) }
function YesNo($v) { if ($v -eq $true) { '是' } elseif ($v -eq $false) { '否' } else { '未知' } }

Add-Line ("# 环境调查结果：{0}" -f $env:COMPUTERNAME)
Add-Line ""
Add-Line ("调查时间：{0}　执行用户：{1}　管理员权限：{2}" -f $script:Started.ToString('yyyy-MM-dd HH:mm'), $report.system.user, (YesNo $report.system.is_admin))
Add-Line ""
Add-Line "## FLOEFD"
Add-Line ""
$launchers = @($report.com_launchers | Where-Object { $_.progid })
if ($launchers.Count -eq 0) {
    Add-Line "- 没有找到 EFDApi 开头的 COM 注册项。可能是未安装、版本早于 2312，或注册表权限受限。"
} else {
    Add-Line "| 启动名 (ProgID) | 宿主 | 版本 | 新版 API 可用 | 服务器程序 |"
    Add-Line "| --- | --- | --- | --- | --- |"
    foreach ($l in $launchers) {
        $srv = $null
        if ($l.server) { if ($l.server.local_server) { $srv = 'LocalServer32: ' + $l.server.local_server } elseif ($l.server.inproc_server) { $srv = 'InprocServer32: ' + $l.server.inproc_server } }
        Add-Line ("| {0} | {1} | {2} | {3} | {4} |" -f $l.progid, $l.product, $l.version, (YesNo $l.new_api_ok), $srv)
    }
}
Add-Line ""
foreach ($i in $report.floefd_installs) { Add-Line ("- 已安装：{0} {1}（{2}）" -f $i.name, $i.version, $i.location) }
$tl = @($report.typelib_files.files)
if ($tl.Count -gt 0) { foreach ($f in $tl) { Add-Line ("- 类型库：{0}" -f $f.path) } } else { Add-Line "- 类型库文件（EFDApi*.tlb）：未找到" }
Add-Line ""
Add-Line "## Python"
Add-Line ""
$pys = @($report.python)
if (($pys.Count -eq 0) -or (($pys[0] -is [System.Collections.IDictionary]) -and $pys[0].Contains('error'))) {
    Add-Line "- 没有找到可用的 Python。"
} else {
    foreach ($p in $pys) {
        Add-Line ("- {0}：版本 {1}，{2} 位，pywin32 {3}{4}" -f $p.path, $p.version, $p.bits, (YesNo $p.pywin32), $(if ($p.note) { '，' + $p.note } else { '' }))
    }
}
Add-Line ("- 备用脚本环境：cscript {0}，Excel COM {1}" -f (YesNo $report.script_hosts.cscript_exists), (YesNo $report.script_hosts.excel_com_available))
Add-Line ""
Add-Line "## 网络"
Add-Line ""
if ($report.network.skipped) {
    Add-Line "- 已跳过"
} else {
    Add-Line ("- IPv4：{0}" -f (($report.network.ipv4) -join '，'))
    foreach ($t in $report.network.tcp_443) { Add-Line ("- 直连 {0}:443：{1}" -f $t.host, (YesNo $t.direct_tcp_ok)) }
    Add-Line ("- 通过系统代理访问 pypi.org：{0}" -f (YesNo $report.network.https_via_system.ok))
    Add-Line ("- 防火墙：{0}" -f (($report.network.firewall_profiles) -join '，'))
}
if ($report.listen_test) {
    $n = @($report.listen_test.connections).Count
    Add-Line ("- 入站端口测试（TCP {0}）：监听{1}，收到 {2} 次连接{3}" -f $report.listen_test.port, $(if ($report.listen_test.started) { '成功' } else { '失败' }), $n, $(if ($report.listen_test.error) { '，错误：' + $report.listen_test.error } else { '' }))
}
Add-Line ""
Add-Line "## 会话"
Add-Line ""
Add-Line ("- 会话名：{0}　远程会话：{1}" -f $report.session.session_name, (YesNo $report.session.is_remote))
Add-Line ""
Add-Line "## 运行中的相关进程"
Add-Line ""
if (@($report.processes).Count -eq 0) { Add-Line "- 无" } else { foreach ($p in $report.processes) { Add-Line ("- {0} (PID {1}) {2}" -f $p.name, $p.id, $p.path) } }
Add-Line ""
Add-Line "详细数据见 report.json，执行记录见 survey.log。"

$sb.ToString() | Out-File -LiteralPath (Join-Path $OutDir 'summary.md') -Encoding utf8
$script:LogLines | Out-File -LiteralPath (Join-Path $OutDir 'survey.log') -Encoding utf8

$zip = "$OutDir.zip"
try {
    Compress-Archive -Path (Join-Path $OutDir '*') -DestinationPath $zip -Force -ErrorAction Stop
    Write-Note "Zipped: $zip"
} catch {
    Write-Note "Zip failed (folder is still complete): $($_.Exception.Message)"
}
Write-Note ("Done in {0:N0}s. Open summary.md first." -f ((Get-Date) - $script:Started).TotalSeconds)
