@echo off
rem FLOEFD automation - run on the USER'S PC while run_listen_test.bat is listening on the remote machine.
rem Usage: client_portcheck.bat <remote-ip-or-name> [port]     default port: 50555
setlocal
if "%~1"=="" (
  echo Usage: client_portcheck.bat ^<remote-ip-or-name^> [port]
  pause
  exit /b 1
)
set HOST=%~1
set PORT=%~2
if "%PORT%"=="" set PORT=50555
powershell -NoProfile -ExecutionPolicy Bypass -Command "$r = Test-NetConnection -ComputerName '%HOST%' -Port %PORT% -WarningAction SilentlyContinue; if ($r.TcpTestSucceeded) { Write-Host ('REACHABLE: {0}:{1}' -f '%HOST%', %PORT%) -ForegroundColor Green } else { Write-Host ('NOT REACHABLE: {0}:{1}  (ping ok: {2})' -f '%HOST%', %PORT%, $r.PingSucceeded) -ForegroundColor Red }"
pause
