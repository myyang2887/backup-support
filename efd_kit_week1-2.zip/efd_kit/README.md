# FLOEFD 自动化 第 1–2 周工具包

第 1 周调查远程机的环境，第 2 周验证 Python 能否连上 FLOEFD。所有脚本都只读：不改模型、不改项目、不改系统设置。

## 内容

| 文件 | 在哪台机器运行 | 作用 |
| --- | --- | --- |
| `week1\run_survey.bat` | 远程机 | 环境调查（FLOEFD 版本与启动名、Python、网络、会话等） |
| `week1\run_listen_test.bat` | 远程机 | 临时打开一个端口，供客户端测试能否连通 |
| `week1\client_portcheck.bat` | 使用者的电脑 | 配合上一项，测试能否连到远程机的端口 |
| `week2\run_probe.bat` | 远程机 | Python 连接探针（类型库导出、名称核对、连接 FLOEFD） |
| `week2\run_probe_vbs.bat` | 远程机 | 不需要 Python 的备用连接探针 |
| `week2\install_offline.bat` | 远程机 | 不联网安装 pywin32 |
| `week2\make_offline_bundle.bat` | 能上网的电脑 | 下载指定 Python 版本用的 pywin32 |
| `pywin32_wheels_py39-311.zip`、`pywin32_wheels_py312-314.zip` | — | 已下载好的 pywin32 312（64 位），按 Python 版本分成两个包 |

先把整个 `efd_kit` 文件夹复制到远程机，路径用英文且不带空格，例如 `D:\efd_kit`。

---

## 第 1 周：环境调查

### 运行

双击 `week1\run_survey.bat`，1–3 分钟后结束。同一文件夹下会生成：

- `survey_<机器名>_<时间>\summary.md`：中文摘要，先看这个
- `survey_<机器名>_<时间>\report.json`：全部数据
- `survey_<机器名>_<时间>\survey.log`：每一项是否成功
- `survey_<机器名>_<时间>.zip`：以上打包，方便带回

### summary.md 里最重要的三项

1. **FLOEFD 表格**：启动名（如 `EFDApiSrv.EFDLauncher.0.2606`）、宿主、版本，以及"新版 API 可用"一栏。版本必须是 2312 或以上；为"否"时到关口 1 重新讨论计划。
2. **Python**：有没有 Python、是几位的、是否已装 pywin32。
3. **网络**：能否直连 pypi.org。不能的话，第 2 周用离线安装。

### 选项

```
run_survey.bat -SkipNetwork        跳过联网测试（更快）
run_survey.bat -SearchDepth 6      类型库文件搜索得更深（默认 4 层）
```

### 入站端口测试（为以后做 MCP 确认网络）

1. 远程机：`week1\run_listen_test.bat 50555 180`，在 50555 端口监听 180 秒。
2. 使用者的电脑：`week1\client_portcheck.bat <远程机IP> 50555`。远程机 IP 见第 1 步的 summary.md。
3. 显示 `REACHABLE` 表示能连通；显示 `NOT REACHABLE` 表示被防火墙或网络隔离挡住了，需要找 IT。

远程机如果弹出"是否允许通过防火墙"，选**取消**，不要自行放行，结果交给 IT 判断。

### 常见问题

- **提示禁止运行脚本**：公司策略禁止 PowerShell 脚本。把截图交给 IT，或改用第 2 周的 VBScript 探针先测连接。
- **summary.md 乱码**：用记事本或 VS Code 打开（文件是 UTF-8）。

---

## 第 2 周：连接探针

### 准备 Python 和 pywin32

**情况 A：远程机没有 Python**

从 python.org 下载与远程机相同位数的安装包（一般选 64 位，3.12 或 3.13）。点 "Install Now" 默认按当前用户安装，不需要管理员权限；记得勾选 "Add python.exe to PATH"。

**情况 B：有 Python、没有 pywin32、远程机不能联网**

1. 按远程机的 Python 版本，把 `pywin32_wheels_py39-311.zip` 或 `pywin32_wheels_py312-314.zip` 解压到 `week2\wheels\`（解压后里面直接是 `.whl` 文件）。
2. 双击 `week2\install_offline.bat`，最后显示 `pywin32 OK` 即成功。

工具包里的 wheel 覆盖 Python 3.9–3.14、64 位。其他版本或 32 位 Python，在能上网的电脑上运行 `make_offline_bundle.bat 3.12 win32`（换成实际版本），再把生成的 `wheels` 文件夹带过去。

**情况 C：能联网**

```
python -m pip install pywin32
```

### 运行

双击 `week2\run_probe.bat`，依次做两件事：

1. **typelib**：找到启动名和类型库（EFDApi.tlb、EFDApiSrv.tlb），生成 Python 包装模块，导出所有常量和方法名，并和工具包内附的 API 参考、官方示例逐一核对。这一步不启动 FLOEFD，也不占许可证。
2. **connect**：先附着到已打开的 FLOEFD，没有就新启动一个；然后读取版本号、CAD 信息、打开的文档和项目名。

### 建议的测试顺序

| 顺序 | 命令 | 验证什么 |
| --- | --- | --- |
| 1 | `run_probe.bat typelib` | 类型库能否找到，示例里的方法名和常量值在本机是否一致 |
| 2 | 手动打开 FLOEFD，再运行 `run_probe.bat connect --mode attach` | 能否附着到已打开的实例 |
| 3 | 关闭 FLOEFD，再运行 `run_probe.bat connect --mode run` | 能否由程序启动 FLOEFD |
| 4 | `run_probe.bat connect --mode attach --open "D:\work\model.prt"` | 能否打开同事的模型并列出项目名（只读，不保存） |

### 全部选项

```
run_probe.bat [all|typelib|connect] [选项]

--progid EFDApiSrv.EFDLauncher.0.2606  指定启动名（默认自动检测；装了多个时优先 Standalone）
--mode auto|attach|run                 auto = 先附着，失败再启动（默认）
--pid 1234                             附着到指定 CAD 进程；0 = 唯一运行中的实例（默认）
--open <模型路径>                      连接后打开一个模型
--close                                结束时关闭由本探针启动的 FLOEFD（默认保留，方便截图）
--binding default|early|dynamic        COM 绑定方式；default 与官方示例相同
--tlb-dir <FLOEFD 的 bin 文件夹>       自动找不到类型库时手动指定
--no-makepy                            不生成包装模块
--attach-timeout 90                    附着的时间上限（秒）
--start-timeout 900                    启动或打开模型的时间上限（秒）
--out <文件夹>                         指定输出位置
```

### 输出

结果写在 `week2\probe_<机器名>_<时间>\` 里：

| 文件 | 内容 |
| --- | --- |
| `summary.md` | 中文摘要，末尾写明关口 2 是否通过 |
| `probe_report.json` | 每一次 COM 调用的参数、结果、耗时、错误码 |
| `probe.log` | 执行过程 |
| `name_check.json` | 本机类型库与 API 参考、官方示例的差异明细 |
| `constants.json` | 本机全部常量及数值（以后写代码时直接查，不用照抄示例里写死的数字） |
| `typelib_dump.json` | 每个接口的方法和参数名 |
| `wrappers\efdapi.py`、`wrappers\efdapisrv.py` | makepy 生成的包装模块 |

退出码：0 全部成功，1 有部分失败，2 某一步超时，3 环境问题（不是 Windows 或没有 pywin32），4 连不上 FLOEFD。

超时的含义：某个调用在时间上限内没有返回，多半是 FLOEFD 弹出了对话框在等人点。登录远程桌面看一眼屏幕，把对话框内容截图记下来。

### 不用 Python 的备用探针

```
run_probe_vbs.bat                                   默认启动名，auto 模式
run_probe_vbs.bat EFDApiSrv.EFDLauncher.0.2606 attach
```

结果写在 `probe_vbs_<时间>.log`。Python 版连不上而 VBScript 版能连上，说明问题在 Python 一侧；两个都连不上，说明是 COM 注册、权限或许可证的问题。

### 常见错误码

| 错误码 | 含义 | 先检查什么 |
| --- | --- | --- |
| 0x800401F3 | 启动名不存在 | 用 summary.md 里列出的启动名，或加 `--progid` |
| 0x80080005 | COM 服务器启动失败 | 是否在远程桌面会话里登录着；用户权限 |
| 0x80070005 | 拒绝访问 | 用户权限，或 FLOEFD 由其他用户启动 |
| 0x800706BA | RPC 服务器不可用 | FLOEFD 进程已崩溃或被关闭 |
| 0x80010001 | 调用被拒绝 | FLOEFD 正忙或有对话框 |

---

## 带回和分享时注意

调查和探针的结果里包含机器名、用户名、IP 地址和安装路径。贴到汇报材料之前，确认这些信息能否公开。
