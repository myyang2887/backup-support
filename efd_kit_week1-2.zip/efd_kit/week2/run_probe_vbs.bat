@echo off
rem FLOEFD automation - fallback probe without Python.
rem Usage: run_probe_vbs.bat [ProgID] [auto|attach|run]
setlocal
cd /d "%~dp0"
cscript //nologo "%~dp0probe.vbs" %*
echo.
echo Exit code: %ERRORLEVEL%   (0 connected, 4 failed). A probe_vbs_*.log file was written here.
pause
