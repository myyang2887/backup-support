@echo off
rem FLOEFD automation - install pywin32 on the remote machine WITHOUT internet.
rem Needs the "wheels" folder next to this file (from make_offline_bundle.bat or the kit's wheels zip).
rem Usage: install_offline.bat [path-to-python.exe]
setlocal
cd /d "%~dp0"
set PY=%~1
if "%PY%"=="" (
  set PY=python
  where python >nul 2>nul
  if errorlevel 1 set PY=py
)
echo Using Python:
%PY% -c "import sys,struct; print(sys.version); print(struct.calcsize('P')*8, 'bit')"
if errorlevel 1 (
  echo Python was not found. Install Python first, or pass the full path to python.exe.
  pause
  exit /b 1
)
if not exist "%~dp0wheels" (
  echo The "wheels" folder is missing next to this file.
  pause
  exit /b 1
)
%PY% -m pip install --no-index --find-links "%~dp0wheels" pywin32
if errorlevel 1 (
  echo Retrying as a per-user install ...
  %PY% -m pip install --user --no-index --find-links "%~dp0wheels" pywin32
)
%PY% -c "import win32com.client, pythoncom; print('pywin32 OK')"
if errorlevel 1 (
  echo pywin32 could not be imported. Check that a wheel matching this Python version and bitness is in "wheels".
  pause
  exit /b 1
)
pause
