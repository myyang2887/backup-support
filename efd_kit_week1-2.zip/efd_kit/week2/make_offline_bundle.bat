@echo off
rem FLOEFD automation - run on a PC WITH internet to download pywin32 for the remote machine.
rem Usage: make_offline_bundle.bat <remote-python-version> [win_amd64|win32]
rem   e.g. make_offline_bundle.bat 3.12
rem Then copy the "wheels" folder next to install_offline.bat on the remote machine.
setlocal
cd /d "%~dp0"
set PYVER=%~1
set PLAT=%~2
if "%PYVER%"=="" (
  echo Usage: make_offline_bundle.bat ^<remote-python-version^> [win_amd64^|win32]
  echo Example: make_offline_bundle.bat 3.12
  pause
  exit /b 1
)
if "%PLAT%"=="" set PLAT=win_amd64
set PY=python
where python >nul 2>nul
if errorlevel 1 set PY=py
%PY% -m pip download pywin32 --only-binary=:all: --platform %PLAT% --python-version %PYVER% -d "%~dp0wheels"
if errorlevel 1 (
  echo Download failed. Check internet/proxy, or that pywin32 has a wheel for Python %PYVER%.
  pause
  exit /b 1
)
dir "%~dp0wheels"
pause
