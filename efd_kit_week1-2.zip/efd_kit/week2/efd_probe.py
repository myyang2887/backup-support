"""FLOEFD automation - Week 2 connection probe.

Run on the machine where FLOEFD is installed (Windows, Python 3.8+, pywin32).

Two stages, each usable on its own:

  typelib   Finds the FLOEFD launcher ProgID and the type libraries
            (EFDApi.tlb / EFDApiSrv.tlb) in the registry and on disk, then
              - generates Python wrapper modules with makepy,
              - dumps every enum constant and every interface method,
              - compares them with the API reference shipped with this kit
                (reference/api_reference.json) and with the method names and
                constant values used in the official examples.
            Does NOT start FLOEFD and needs no license.

  connect   Connects to FLOEFD (attach to a running instance, or start one)
            and reads version information, open documents and project names.
            Read-only: it changes no model and no project.

  all       typelib, then connect (default).

Every COM call is logged with its arguments, result, duration and error code,
so the log alone is enough to diagnose a failure.

Examples
  python efd_probe.py                       # all, connect mode "auto"
  python efd_probe.py typelib               # no FLOEFD start, no license used
  python efd_probe.py connect --mode attach # only attach to an open FLOEFD
  python efd_probe.py connect --mode run --open "D:\\work\\model.prt"
  python efd_probe.py all --progid EFDApiSrv.EFDLauncher.0.2606
  python efd_probe.py connect --binding early   # early binding via makepy/gencache

Exit codes
  0 everything succeeded      1 finished with some failures
  2 a step timed out          3 environment problem (not Windows / no pywin32)
  4 could not connect to FLOEFD
"""

from __future__ import annotations

import argparse
import datetime as _dt
import difflib
import json
import os
import platform
import re
import subprocess
import sys
import threading
import time
import traceback

TOOL_VERSION = "1.0"
HERE = os.path.dirname(os.path.abspath(__file__))
REFERENCE_PATH = os.path.join(HERE, "reference", "api_reference.json")

# Product codes in the launcher ProgID, from the official examples (2606).
PRODUCT_NAMES = {"0": "Standalone", "2": "CATIA V5", "3": "Creo", "4": "NX", "5": "Solid Edge"}
PROGID_RE = re.compile(r"^EFDApiSrv\.EFDLauncher\.(\d+)\.(\d+)$")
NEW_API_MIN_VERSION = 2312

# Methods of IDispatch / IUnknown that every interface carries; not FLOEFD API.
OLE_BASE_METHODS = {
    "QueryInterface", "AddRef", "Release",
    "GetTypeInfoCount", "GetTypeInfo", "GetIDsOfNames", "Invoke",
}

# Type-library constants (pythoncom has them too; kept here so the
# module imports on any OS for testing).
TKIND_ENUM, TKIND_INTERFACE, TKIND_DISPATCH = 0, 3, 4
INVOKE_KINDS = {1: "method", 2: "propget", 4: "propput", 8: "propputref"}

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:
        pass


# --------------------------------------------------------------------------- logging and records

class Probe:
    """Holds the log, the call records and the final report for one run."""

    def __init__(self, out_dir: str):
        self.out_dir = out_dir
        os.makedirs(out_dir, exist_ok=True)
        self.log_path = os.path.join(out_dir, "probe.log")
        self._log = open(self.log_path, "a", encoding="utf-8")
        self.calls: list[dict] = []
        self.report: dict = {
            "tool": "floefd-week2-probe",
            "tool_version": TOOL_VERSION,
            "started": _dt.datetime.now().isoformat(timespec="seconds"),
            "status": "running",
        }
        self._lock = threading.Lock()

    def log(self, msg: str) -> None:
        line = f"[{_dt.datetime.now():%H:%M:%S}] {msg}"
        with self._lock:
            print(line, flush=True)
            self._log.write(line + "\n")
            self._log.flush()

    def call(self, label: str, fn, *args, watchdog: "Watchdog | None" = None, timeout: float | None = None,
             shown_args: tuple | None = None):
        """Runs fn(*args), records it, and returns (ok, value). Never raises.

        shown_args: the arguments to record when fn is a wrapper that takes none itself.
        """
        rec = {"call": label, "args": [_short(a) for a in (args if shown_args is None else shown_args)], "ok": False}
        t0 = time.time()
        if watchdog and timeout:
            watchdog.arm(label, timeout)
        try:
            value = fn(*args)
            rec["ok"] = True
            rec["result"] = _short(value)
            rec["result_type"] = _type_name(value)
            return_value = (True, value)
        except Exception as exc:  # noqa: BLE001 - every failure must be recorded, not raised
            rec["error"] = describe_error(exc)
            return_value = (False, exc)
        finally:
            if watchdog and timeout:
                watchdog.disarm()
            rec["seconds"] = round(time.time() - t0, 3)
            self.calls.append(rec)
        status = "OK  " if rec["ok"] else "FAIL"
        detail = rec.get("result") if rec["ok"] else rec["error"].get("summary")
        if isinstance(detail, dict):
            detail = f"<{len(detail)} fields>"
        shown = ", ".join(str(a) for a in rec["args"])
        self.log(f"{status} {label}({shown}) -> {str(detail)[:200]}  [{rec['seconds']}s]")
        return return_value

    def invoke(self, label: str, obj, method: str, *args, watchdog: "Watchdog | None" = None,
               timeout: float | None = None):
        """Calls obj.method(*args) through COM and records it like call().

        Works with early and late binding: when late binding has no type
        information, reading the attribute already performs the call and
        returns the value, so it is not called a second time.
        """
        def _do():
            attr = getattr(obj, method)
            if hasattr(attr, "_oleobj_") or not callable(attr):
                if args:
                    raise TypeError(f"{method} behaved like a property but arguments were given")
                return attr
            return attr(*args)
        return self.call(label, _do, watchdog=watchdog, timeout=timeout, shown_args=args)

    def write(self, status: str | None = None) -> None:
        if status:
            self.report["status"] = status
        self.report["finished"] = _dt.datetime.now().isoformat(timespec="seconds")
        self.report["calls"] = self.calls
        with open(os.path.join(self.out_dir, "probe_report.json"), "w", encoding="utf-8") as f:
            json.dump(self.report, f, ensure_ascii=False, indent=2, default=str)
        with open(os.path.join(self.out_dir, "summary.md"), "w", encoding="utf-8") as f:
            f.write(render_summary(self.report))


class Watchdog:
    """Ends the process if one COM call hangs longer than its time limit.

    A hung COM call cannot be interrupted from Python, so on timeout the
    report is written with status "timeout" and the process exits with code 2.
    """

    def __init__(self, probe: Probe):
        self.probe = probe
        self._timer: threading.Timer | None = None

    def arm(self, label: str, seconds: float) -> None:
        self.disarm()
        self._timer = threading.Timer(seconds, self._fire, args=(label, seconds))
        self._timer.daemon = True
        self._timer.start()

    def disarm(self) -> None:
        if self._timer:
            self._timer.cancel()
            self._timer = None

    def _fire(self, label: str, seconds: float) -> None:
        self.probe.log(f"TIMEOUT {label} did not return within {seconds:.0f}s; writing report and exiting.")
        self.probe.calls.append({"call": label, "ok": False, "error": {"summary": f"timeout after {seconds:.0f}s"}})
        self.probe.report["timed_out_call"] = label
        try:
            self.probe.write("timeout")
        finally:
            os._exit(2)


def describe_error(exc: BaseException) -> dict:
    """Turns a COM error into readable fields (HRESULT in hex, source, description)."""
    info: dict = {"type": type(exc).__name__, "summary": str(exc)}
    args = getattr(exc, "args", ())
    if type(exc).__name__ == "com_error" and len(args) >= 2:
        hr = args[0]
        info["hresult"] = f"0x{hr & 0xFFFFFFFF:08X}" if isinstance(hr, int) else str(hr)
        info["message"] = args[1]
        if len(args) >= 3 and args[2]:
            ex = args[2]
            try:
                info["source"], info["description"] = ex[1], ex[2]
                if len(ex) > 5 and isinstance(ex[5], int):
                    info["scode"] = f"0x{ex[5] & 0xFFFFFFFF:08X}"
            except Exception:  # noqa: BLE001
                info["excepinfo"] = str(ex)
        info["summary"] = " | ".join(str(info[k]) for k in ("hresult", "message", "description") if info.get(k))
    info["traceback"] = traceback.format_exception_only(type(exc), exc)[-1].strip()
    return info


def _is_com_object(v) -> bool:
    return hasattr(v, "_oleobj_")


def _type_name(v) -> str:
    if _is_com_object(v):
        return "COM object"
    return type(v).__name__


def _short(v, limit: int = 300, depth: int = 0):
    """JSON-friendly, length-limited representation of a value."""
    if _is_com_object(v):
        return "<COM object>"
    if isinstance(v, str):
        return v if len(v) <= limit else v[:limit] + "..."
    if isinstance(v, (int, float, bool)) or v is None:
        return v
    if isinstance(v, dict):
        return f"<dict with {len(v)} keys>"
    if isinstance(v, (list, tuple)) and depth < 2:
        items = [_short(x, 80, depth + 1) for x in list(v)[:20]]
        if len(v) > 20:
            items.append(f"... {len(v) - 20} more")
        return items
    s = repr(v)
    return s if len(s) <= limit else s[:limit] + "..."


# --------------------------------------------------------------------------- environment

def environment_info() -> dict:
    info = {
        "python": sys.version.split()[0],
        "python_bits": 64 if sys.maxsize > 2**32 else 32,
        "python_exe": sys.executable,
        "os": platform.platform(),
        "computer": os.environ.get("COMPUTERNAME", platform.node()),
        "user": os.environ.get("USERNAME", ""),
        "session": os.environ.get("SESSIONNAME", ""),
    }
    try:
        from importlib.metadata import version
        info["pywin32"] = version("pywin32")
    except Exception:  # noqa: BLE001
        info["pywin32"] = None
    return info


def require_pywin32(probe: Probe) -> bool:
    allow_fake = os.environ.get("EFD_PROBE_ALLOW_NON_WINDOWS") == "1"  # test harness only
    if os.name != "nt" and not allow_fake:
        probe.log("This probe must run on the Windows machine where FLOEFD is installed.")
        return False
    try:
        import pythoncom  # noqa: F401
        import win32com.client  # noqa: F401
    except ImportError as exc:
        probe.log(f"pywin32 is not installed ({exc}). See README: install_offline.bat.")
        return False
    return True


# --------------------------------------------------------------------------- registry discovery

def _reg_default(root, subkey: str):
    import winreg
    try:
        return winreg.QueryValue(root, subkey) or None
    except OSError:
        return None


def _reg_subkeys(root, subkey: str):
    import winreg
    try:
        key = winreg.OpenKey(root, subkey)
    except OSError:
        return
    with key:
        i = 0
        while True:
            try:
                yield winreg.EnumKey(key, i)
            except OSError:
                return
            i += 1


def find_launchers(probe: Probe) -> list[dict]:
    """Lists EFDApiSrv.EFDLauncher* ProgIDs with product, version and server paths."""
    import winreg
    hkcr = winreg.HKEY_CLASSES_ROOT
    found = []
    for name in _reg_subkeys(hkcr, ""):
        if not name.startswith("EFDApiSrv.EFDLauncher"):
            continue
        clsid = _reg_default(hkcr, name + r"\CLSID")
        entry = {"progid": name, "clsid": clsid, "product_code": None, "product": None, "version": None}
        m = PROGID_RE.match(name)
        if m:
            entry["product_code"] = m.group(1)
            entry["product"] = PRODUCT_NAMES.get(m.group(1), f"unknown code {m.group(1)}")
            entry["version"] = int(m.group(2))
        if clsid:
            for view in ("CLSID", r"WOW6432Node\CLSID"):
                base = f"{view}\\{clsid}"
                local = _reg_default(hkcr, base + r"\LocalServer32")
                inproc = _reg_default(hkcr, base + r"\InprocServer32")
                if local or inproc:
                    entry.update({"registry_view": view, "local_server": local, "inproc_server": inproc,
                                  "typelib_guid": _reg_default(hkcr, base + r"\TypeLib")})
                    break
        found.append(entry)
    probe.log(f"Found {len(found)} launcher ProgID(s): {', '.join(e['progid'] for e in found) or 'none'}")
    return found


def choose_launcher(launchers: list[dict], wanted: str | None, probe: Probe) -> dict | None:
    if wanted:
        for e in launchers:
            if e["progid"].lower() == wanted.lower():
                return e
        probe.log(f"Requested ProgID {wanted} is not registered; trying it anyway.")
        return {"progid": wanted}
    versioned = [e for e in launchers if e.get("version")]
    if len(versioned) == 1:
        return versioned[0]
    if versioned:
        standalone = [e for e in versioned if e["product_code"] == "0"]
        pool = standalone or versioned
        pick = max(pool, key=lambda e: e["version"])
        probe.log(f"Several launchers registered; picked {pick['progid']} "
                  f"({'Standalone preferred' if standalone else 'highest version'}). Use --progid to override.")
        return pick
    plain = [e for e in launchers if e["progid"] == "EFDApiSrv.EFDLauncher"]
    return plain[0] if plain else None


def _server_dir(entry: dict | None) -> str | None:
    if not entry:
        return None
    path = entry.get("local_server") or entry.get("inproc_server")
    if not path:
        return None
    path = path.strip()
    if path.startswith('"'):
        path = path[1:].split('"', 1)[0]
    else:
        m = re.match(r"(.+?\.(exe|dll))", path, re.I)
        path = m.group(1) if m else path.split(" ")[0]
    return os.path.dirname(path)


def find_typelibs(probe: Probe, launcher: dict | None, extra_dir: str | None, max_depth: int = 4,
                  other_launchers: list[dict] | None = None) -> dict:
    """Returns {'EFDApi': path, 'EFDApiSrv': path} for the best-matching tlb files."""
    import winreg
    candidates: list[str] = []
    order_hint: list[str] = []

    if extra_dir:
        order_hint.append(extra_dir)
    sdir = _server_dir(launcher)
    if sdir:
        order_hint += [sdir, os.path.dirname(sdir)]

    # Registered type libraries whose description mentions EFD.
    hkcr = winreg.HKEY_CLASSES_ROOT
    for guid in _reg_subkeys(hkcr, "TypeLib"):
        for ver in _reg_subkeys(hkcr, f"TypeLib\\{guid}"):
            desc = _reg_default(hkcr, f"TypeLib\\{guid}\\{ver}") or ""
            if "EFD" not in desc.upper():
                continue
            for lcid in _reg_subkeys(hkcr, f"TypeLib\\{guid}\\{ver}"):
                for plat in ("win64", "win32"):
                    p = _reg_default(hkcr, f"TypeLib\\{guid}\\{ver}\\{lcid}\\{plat}")
                    if p and p.lower().endswith(".tlb") and os.path.isfile(p):
                        candidates.append(p)

    roots = list(order_hint)
    for other in other_launchers or []:
        odir = _server_dir(other)
        if odir:
            roots += [odir, os.path.dirname(odir)]
    for pf in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)")):
        if pf and os.path.isdir(pf):
            for d in os.listdir(pf):
                if re.search(r"FLOEFD|FloEFD|Siemens|Simcenter", d, re.I):
                    roots.append(os.path.join(pf, d))

    for root in dict.fromkeys(r for r in roots if r and os.path.isdir(r)):
        base_depth = root.rstrip("\\/").count(os.sep)
        for dirpath, dirnames, filenames in os.walk(root):
            if dirpath.count(os.sep) - base_depth >= max_depth:
                dirnames[:] = []
            for fn in filenames:
                if fn.lower() in ("efdapi.tlb", "efdapisrv.tlb"):
                    candidates.append(os.path.join(dirpath, fn))

    candidates = list(dict.fromkeys(os.path.normpath(c) for c in candidates))
    probe.report.setdefault("typelib", {})["candidates"] = candidates

    def pick(filename: str) -> str | None:
        matches = [c for c in candidates if os.path.basename(c).lower() == filename]
        for hint in order_hint:
            for c in matches:
                if os.path.normcase(os.path.dirname(c)).startswith(os.path.normcase(hint)):
                    return c
        return matches[0] if matches else None

    result = {"EFDApi": pick("efdapi.tlb"), "EFDApiSrv": pick("efdapisrv.tlb")}
    probe.log(f"Type libraries: EFDApi={result['EFDApi']}  EFDApiSrv={result['EFDApiSrv']}")
    return result


# --------------------------------------------------------------------------- type library export

def _attr(obj, name: str, index: int):
    try:
        return getattr(obj, name)
    except AttributeError:
        return obj[index]


def dump_typelib(path: str) -> dict:
    """Reads one .tlb: library info, enum constants and interface methods."""
    import pythoncom
    tlb = pythoncom.LoadTypeLib(path)
    lib_attr = tlb.GetLibAttr()
    out = {
        "path": path,
        "name": tlb.GetDocumentation(-1)[0],
        "guid": str(lib_attr[0]),
        "lcid": lib_attr[1],
        "version": f"{lib_attr[3]}.{lib_attr[4]}",
        "enums": {},
        "interfaces": {},
    }
    for i in range(tlb.GetTypeInfoCount()):
        ti = tlb.GetTypeInfo(i)
        ta = ti.GetTypeAttr()
        name = tlb.GetDocumentation(i)[0]
        kind = _attr(ta, "typekind", 5)
        if kind == TKIND_ENUM:
            values = {}
            for j in range(_attr(ta, "cVars", 7)):
                vd = ti.GetVarDesc(j)
                memid = _attr(vd, "memid", 0)
                values[ti.GetNames(memid)[0]] = _attr(vd, "value", 1)
            out["enums"][name] = values
        elif kind in (TKIND_DISPATCH, TKIND_INTERFACE):
            methods = out["interfaces"].setdefault(name, {})
            for j in range(_attr(ta, "cFuncs", 6)):
                fd = ti.GetFuncDesc(j)
                names = ti.GetNames(_attr(fd, "memid", 0))
                if not names or names[0] in OLE_BASE_METHODS:
                    continue
                entry = methods.setdefault(names[0], {"params": list(names[1:]), "kinds": []})
                kind_name = INVOKE_KINDS.get(_attr(fd, "invkind", 4), "?")
                if kind_name not in entry["kinds"]:
                    entry["kinds"].append(kind_name)
    return out


def generate_wrapper(path: str, out_py: str, probe: Probe) -> bool:
    """Runs makepy to write a static wrapper module (constants + early-bound classes)."""
    cmd = [sys.executable, "-m", "win32com.client.makepy", "-o", out_py, path]
    probe.log("makepy: " + " ".join(f'"{c}"' if " " in c else c for c in cmd))
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    except subprocess.TimeoutExpired:
        probe.log("makepy timed out after 600s")
        return False
    if r.returncode != 0 or not os.path.isfile(out_py):
        probe.log(f"makepy failed (exit {r.returncode}): {(r.stderr or r.stdout)[-500:]}")
        return False
    probe.log(f"Wrapper written: {out_py} ({os.path.getsize(out_py)} bytes)")
    return True


def compare_with_reference(dumps: dict, reference: dict | None) -> dict:
    """Machine type library vs. the kit's API reference and the official examples."""
    machine_methods: dict[str, set] = {}
    machine_consts: dict[str, object] = {}
    for d in dumps.values():
        for iface, methods in d["interfaces"].items():
            machine_methods.setdefault(iface, set()).update(methods)
        for values in d["enums"].values():
            machine_consts.update(values)
    all_methods = set().union(*machine_methods.values()) if machine_methods else set()

    result: dict = {"machine_interfaces": len(machine_methods), "machine_methods": len(all_methods),
                    "machine_constants": len(machine_consts)}
    if not reference:
        result["note"] = "reference/api_reference.json not found; comparison skipped"
        return result

    # 1. Method names the official examples call.
    rows = []
    for item in reference.get("example_methods", []):
        name = item["name"]
        present = name in all_methods
        rows.append({
            "name": name,
            "on_this_machine": present,
            "in_reference": item["in_reference"],
            "close_matches": [] if present else difflib.get_close_matches(name, all_methods, n=3, cutoff=0.8),
        })
    result["example_methods"] = rows

    # 2. Constant values hardcoded in the official examples.
    const_rows = []
    for name, value in sorted(reference.get("example_constants", {}).items()):
        mv = machine_consts.get(name)
        const_rows.append({"name": name, "example": value, "machine": mv,
                           "status": "missing" if mv is None else ("same" if mv == value else "DIFFERENT")})
    result["example_constants"] = const_rows

    # 3. Interface-level differences against the reference (version drift).
    ref_ifaces = reference.get("interfaces", {})
    missing_ifaces = sorted(set(ref_ifaces) - set(machine_methods))
    new_ifaces = sorted(set(machine_methods) - set(ref_ifaces))
    missing_methods = {}
    for iface, info in ref_ifaces.items():
        if iface in machine_methods:
            gone = sorted(set(info["methods"]) - machine_methods[iface])
            if gone:
                missing_methods[iface] = gone
    result["reference_diff"] = {
        "interfaces_missing_on_machine": missing_ifaces,
        "interfaces_only_on_machine": new_ifaces,
        "methods_missing_on_machine": missing_methods,
    }

    # 4. Enum values that differ from the reference.
    ref_consts = {}
    for values in reference.get("enums", {}).values():
        ref_consts.update(values)
    diff = {k: {"reference": v, "machine": machine_consts[k]}
            for k, v in ref_consts.items() if k in machine_consts and machine_consts[k] != v}
    result["reference_diff"]["constant_value_differences"] = diff
    result["reference_diff"]["constants_missing_on_machine"] = sorted(set(ref_consts) - set(machine_consts))[:200]
    return result


def stage_typelib(probe: Probe, args) -> dict:
    probe.log("=== Stage: typelib ===")
    launchers = find_launchers(probe)
    probe.report["launchers"] = launchers
    launcher = choose_launcher(launchers, args.progid, probe)
    probe.report["chosen_launcher"] = launcher
    if launcher and launcher.get("version"):
        probe.report["new_api_ok"] = launcher["version"] >= NEW_API_MIN_VERSION

    tlbs = find_typelibs(probe, launcher, args.tlb_dir, other_launchers=launchers)
    probe.report["typelib"]["files"] = tlbs
    wrapper_dir = os.path.join(probe.out_dir, "wrappers")
    os.makedirs(wrapper_dir, exist_ok=True)

    dumps = {}
    for key, path in tlbs.items():
        if not path:
            msg = f"{key}.tlb not found. Pass --tlb-dir <FLOEFD bin folder> if you know where it is."
            probe.log(msg)
            probe.report.setdefault("warnings", []).append(msg)
            continue
        ok, dump = probe.call(f"LoadTypeLib[{key}]", dump_typelib, path)
        if ok:
            dumps[key] = dump
            probe.log(f"{key}: library {dump['name']} v{dump['version']}, "
                      f"{len(dump['enums'])} enums, {len(dump['interfaces'])} interfaces")
        if not args.no_makepy:
            generate_wrapper(path, os.path.join(wrapper_dir, key.lower() + ".py"), probe)

    with open(os.path.join(probe.out_dir, "typelib_dump.json"), "w", encoding="utf-8") as f:
        json.dump(dumps, f, ensure_ascii=False, indent=1, default=str)
    constants = {}
    for d in dumps.values():
        for values in d["enums"].values():
            constants.update(values)
    with open(os.path.join(probe.out_dir, "constants.json"), "w", encoding="utf-8") as f:
        json.dump(dict(sorted(constants.items())), f, ensure_ascii=False, indent=1, default=str)

    reference = None
    if os.path.isfile(REFERENCE_PATH):
        with open(REFERENCE_PATH, encoding="utf-8") as f:
            reference = json.load(f)
    comparison = compare_with_reference(dumps, reference) if dumps else {"note": "no type library loaded"}
    with open(os.path.join(probe.out_dir, "name_check.json"), "w", encoding="utf-8") as f:
        json.dump(comparison, f, ensure_ascii=False, indent=1, default=str)
    probe.report["typelib"]["loaded"] = {k: {kk: v[kk] for kk in ("name", "guid", "version")} for k, v in dumps.items()}
    probe.report["typelib"]["comparison_summary"] = _comparison_summary(comparison)
    return {"launcher": launcher, "tlbs": tlbs, "dumps": dumps}


def _comparison_summary(c: dict) -> dict:
    s = {k: c.get(k) for k in ("machine_interfaces", "machine_methods", "machine_constants", "note")}
    if "example_methods" in c:
        missing = [r for r in c["example_methods"] if not r["on_this_machine"]]
        s["example_methods_total"] = len(c["example_methods"])
        s["example_methods_missing"] = [{"name": r["name"], "close_matches": r["close_matches"]} for r in missing]
    if "example_constants" in c:
        s["example_constants_total"] = len(c["example_constants"])
        s["example_constants_not_same"] = [r for r in c["example_constants"] if r["status"] != "same"]
    if "reference_diff" in c:
        rd = c["reference_diff"]
        s["interfaces_missing_on_machine"] = rd["interfaces_missing_on_machine"]
        s["interfaces_only_on_machine"] = rd["interfaces_only_on_machine"]
        s["interfaces_with_missing_methods"] = len(rd["methods_missing_on_machine"])
        s["constant_value_differences"] = len(rd["constant_value_differences"])
    return s


# --------------------------------------------------------------------------- connect

def prepare_early_binding(probe: Probe, typelib_dumps: dict) -> None:
    """Registers the FLOEFD type libraries in pywin32's gencache (early binding)."""
    from win32com.client import gencache
    for key, d in (typelib_dumps or {}).items():
        major, minor = (int(x) for x in d["version"].split("."))
        probe.call(f"gencache.EnsureModule[{key}]", gencache.EnsureModule, d["guid"], d["lcid"], major, minor)


def stage_connect(probe: Probe, args, launcher: dict | None, typelib_dumps: dict | None = None) -> bool:
    probe.log("=== Stage: connect ===")
    import pythoncom
    import win32com.client

    wd = Watchdog(probe)
    progid = args.progid or (launcher or {}).get("progid") or "EFDApiSrv.EFDLauncher"
    conn: dict = {"progid": progid, "mode_requested": args.mode, "binding": args.binding}
    probe.report["connect"] = conn

    pythoncom.CoInitialize()
    if args.binding == "early":
        prepare_early_binding(probe, typelib_dumps)
    if args.binding == "dynamic":
        import win32com.client.dynamic
        dispatch = win32com.client.dynamic.Dispatch
    else:
        dispatch = win32com.client.Dispatch  # same call as the official examples
    ok, srv = probe.call("Dispatch", dispatch, progid, watchdog=wd, timeout=120)
    if not ok:
        conn["result"] = "launcher object could not be created"
        return False

    probe.invoke("Launcher.GetAvailableCADVersions", srv, "GetAvailableCADVersions", watchdog=wd, timeout=120)

    app = None
    started_by_probe = False
    if args.mode in ("attach", "auto"):
        ok, app = probe.invoke("Launcher.Attach2RunningCADInstance", srv, "Attach2RunningCADInstance", args.pid,
                               watchdog=wd, timeout=args.attach_timeout)
        if not ok or app is None:
            app = None
            probe.log("Attach did not return an application object.")
    if app is None and args.mode in ("run", "auto"):
        probe.log(f"Starting FLOEFD with RunProduct (time limit {args.start_timeout}s) ...")
        ok, app = probe.invoke("Launcher.RunProduct", srv, "RunProduct", watchdog=wd, timeout=args.start_timeout)
        if not ok or app is None:
            app = None
        else:
            started_by_probe = True
    if app is None:
        conn["result"] = "no application object (attach and/or start failed)"
        return False
    conn["result"] = "connected"
    conn["mode_used"] = "run" if started_by_probe else "attach"

    t = 120
    _, conn["floefd_version"] = _val(probe.invoke("App.GetVersion", app, "GetVersion", watchdog=wd, timeout=t))
    _, conn["silent_mode"] = _val(probe.invoke("App.IsSilentMode", app, "IsSilentMode", watchdog=wd, timeout=t))
    _, conn["templates_dir"] = _val(probe.invoke("App.GetProjectsTemplatesDir", app, "GetProjectsTemplatesDir",
                                                 watchdog=wd, timeout=t))

    ok, cad = probe.invoke("App.GetCAD", app, "GetCAD", watchdog=wd, timeout=t)
    if not ok:
        cad = None
    if cad is not None:
        _, conn["cad_version"] = _val(probe.invoke("CAD.GetVersionString", cad, "GetVersionString", watchdog=wd, timeout=t))
        _, conn["cad_revision"] = _val(probe.invoke("CAD.RevisionNumber", cad, "RevisionNumber", watchdog=wd, timeout=t))
        _, conn["cad_language"] = _val(probe.invoke("CAD.GetCurrentLanguage", cad, "GetCurrentLanguage", watchdog=wd, timeout=t))
        if args.open:
            probe.log(f"Opening model (read-only use): {args.open}")
            probe.invoke("CAD.OpenDoc", cad, "OpenDoc", args.open, watchdog=wd, timeout=args.start_timeout)

    conn["documents"] = read_documents(probe, app, wd)

    if args.close and started_by_probe and cad is not None:
        probe.invoke("CAD.CloseApplication", cad, "CloseApplication", watchdog=wd, timeout=300)
    elif started_by_probe:
        probe.log("FLOEFD was started by this probe and is left open (use --close to close it).")
    return True


def _as_list(v) -> list:
    """COM arrays arrive as tuples; a single object or None is normalised to a list."""
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return list(v)
    return [v]


def _val(result):
    ok, v = result
    return ok, (_short(v) if ok else None)


def read_documents(probe: Probe, app, wd: Watchdog) -> list[dict]:
    """Titles of open documents and the names of their FLOEFD projects (read-only)."""
    docs_info: list[dict] = []
    ok, docs = probe.invoke("App.GetDocuments", app, "GetDocuments", watchdog=wd, timeout=120)
    docs = _as_list(docs) if ok else []
    ok, active = probe.invoke("App.GetActiveDoc", app, "GetActiveDoc", watchdog=wd, timeout=120)
    if ok and active is not None and not docs:
        docs = [active]
    for i, doc in enumerate(docs[:10]):
        info: dict = {"index": i}
        _, info["title"] = _val(probe.invoke(f"Doc[{i}].GetTitle", doc, "GetTitle", watchdog=wd, timeout=60))
        _, info["projects_count"] = _val(probe.invoke(f"Doc[{i}].GetProjectsCount", doc, "GetProjectsCount",
                                                      watchdog=wd, timeout=60))
        ok, projects = probe.invoke(f"Doc[{i}].GetProjects1", doc, "GetProjects1", watchdog=wd, timeout=60)
        names = []
        for j, p in enumerate(_as_list(projects)[:30] if ok else []):
            okn, n = probe.invoke(f"Doc[{i}].Project[{j}].GetName", p, "GetName", watchdog=wd, timeout=60)
            names.append(n if okn else None)
        info["projects"] = names
        okp, ap = probe.invoke(f"Doc[{i}].GetActiveProject", doc, "GetActiveProject", watchdog=wd, timeout=60)
        if okp and ap is not None:
            _, info["active_project"] = _val(probe.invoke(f"Doc[{i}].ActiveProject.GetName", ap, "GetName",
                                                          watchdog=wd, timeout=60))
        docs_info.append(info)
    if not docs_info:
        probe.log("No open documents (this is normal if FLOEFD was just started).")
    return docs_info


# --------------------------------------------------------------------------- summary

def _yes_no(v) -> str:
    return "是" if v is True else ("否" if v is False else "未知")


def render_summary(r: dict) -> str:
    env = r.get("environment", {})
    lines = [f"# 连接探针结果：{env.get('computer', '')}", ""]
    lines.append(f"运行时间：{r.get('started', '')} 至 {r.get('finished', '')}　状态：{r.get('status')}")
    lines.append("")
    lines.append("## 环境")
    lines.append("")
    lines.append(f"- Python {env.get('python')}（{env.get('python_bits')} 位），pywin32 {env.get('pywin32') or '未安装'}")
    lines.append(f"- 会话：{env.get('session') or '未知'}")
    lines.append("")

    lines.append("## 启动名与类型库")
    lines.append("")
    launchers = r.get("launchers") or []
    if launchers:
        lines.append("| 启动名 (ProgID) | 宿主 | 版本 | 服务器程序 |")
        lines.append("| --- | --- | --- | --- |")
        for e in launchers:
            lines.append(f"| {e.get('progid')} | {e.get('product') or ''} | {e.get('version') or ''} | "
                         f"{e.get('local_server') or e.get('inproc_server') or ''} |")
    else:
        lines.append("- 注册表中没有找到 EFDApiSrv.EFDLauncher 启动名。")
    ch = r.get("chosen_launcher") or {}
    if ch:
        lines.append(f"- 本次使用：{ch.get('progid')}；新版 API（2312 以上）：{_yes_no(r.get('new_api_ok'))}")
    tl = (r.get("typelib") or {})
    files = tl.get("files") or {}
    for k in ("EFDApi", "EFDApiSrv"):
        lines.append(f"- {k}.tlb：{files.get(k) or '未找到'}")
    for k, v in (tl.get("loaded") or {}).items():
        lines.append(f"- {k} 类型库：{v.get('name')} v{v.get('version')}")
    cs = tl.get("comparison_summary") or {}
    if cs:
        lines.append("")
        lines.append("## 与 API 参考和官方示例的核对")
        lines.append("")
        if cs.get("note"):
            lines.append(f"- {cs['note']}")
        if "machine_methods" in cs and cs["machine_methods"] is not None:
            lines.append(f"- 本机类型库：{cs.get('machine_interfaces')} 个接口，{cs.get('machine_methods')} 个方法名，"
                         f"{cs.get('machine_constants')} 个常量")
        if "example_methods_total" in cs:
            miss = cs["example_methods_missing"]
            lines.append(f"- 示例里调用的 {cs['example_methods_total']} 个方法名中，本机缺少 {len(miss)} 个")
            for m in miss:
                alt = "、".join(m["close_matches"]) or "无相近名称"
                lines.append(f"    - {m['name']} → 本机相近名称：{alt}")
        if "example_constants_total" in cs:
            bad = cs["example_constants_not_same"]
            lines.append(f"- 示例里写死的 {cs['example_constants_total']} 个常量值中，与本机不一致或缺失的 {len(bad)} 个")
            for b in bad[:20]:
                lines.append(f"    - {b['name']}：示例 {b['example']}，本机 {b['machine']}")
        if "interfaces_missing_on_machine" in cs:
            lines.append(f"- 参考文档有而本机没有的接口：{len(cs['interfaces_missing_on_machine'])} 个；"
                         f"本机独有的接口：{len(cs['interfaces_only_on_machine'])} 个；"
                         f"缺少部分方法的接口：{cs['interfaces_with_missing_methods']} 个；"
                         f"值不同的常量：{cs['constant_value_differences']} 个（明细见 name_check.json）")
    lines.append("")

    conn = r.get("connect")
    lines.append("## 连接 FLOEFD")
    lines.append("")
    if not conn:
        lines.append("- 未执行连接（只运行了 typelib 阶段）。")
    else:
        lines.append(f"- 结果：{conn.get('result')}；请求方式 {conn.get('mode_requested')}，实际方式 {conn.get('mode_used', '无')}")
        if conn.get("result") == "connected":
            lines.append(f"- FLOEFD 版本：{conn.get('floefd_version')}")
            lines.append(f"- CAD：{conn.get('cad_version')}，修订 {conn.get('cad_revision')}，语言 {conn.get('cad_language')}")
            lines.append(f"- 项目模板目录：{conn.get('templates_dir')}")
            docs = conn.get("documents") or []
            if docs:
                for d in docs:
                    lines.append(f"- 文档 {d.get('title')}：项目 {d.get('projects') or []}，当前项目 {d.get('active_project')}")
            else:
                lines.append("- 当前没有打开的文档")
    lines.append("")

    if r.get("warnings"):
        lines.append("## 警告")
        lines.append("")
        for w in r["warnings"]:
            lines.append(f"- {w}")
        lines.append("")
    fails = [c for c in r.get("calls", []) if not c.get("ok")]
    lines.append("## 失败的调用")
    lines.append("")
    if fails:
        for c in fails:
            lines.append(f"- {c['call']}：{(c.get('error') or {}).get('summary')}")
    else:
        lines.append("- 无")
    lines.append("")
    gate = (conn or {}).get("result") == "connected" and (conn or {}).get("floefd_version") is not None
    lines.append(f"关口 2（Python 能连上 FLOEFD 并读出版本号）：{'通过' if gate else '未通过或未执行'}")
    lines.append("")
    lines.append("明细：probe_report.json（全部调用记录）、probe.log、name_check.json、constants.json、wrappers/。")
    return "\n".join(lines) + "\n"


# --------------------------------------------------------------------------- main

def parse_args(argv=None):
    p = argparse.ArgumentParser(description="FLOEFD Week 2 connection probe (read-only).")
    p.add_argument("stage", nargs="?", default="all", choices=["all", "typelib", "connect"])
    p.add_argument("--progid", help="launcher ProgID, e.g. EFDApiSrv.EFDLauncher.0.2606 (default: auto-detect)")
    p.add_argument("--mode", default="auto", choices=["auto", "attach", "run"],
                   help="auto = attach to a running FLOEFD, start one if none (default)")
    p.add_argument("--pid", type=int, default=0, help="CAD process id for attach; 0 = the only running instance")
    p.add_argument("--open", help="model file to open after connecting (optional)")
    p.add_argument("--close", action="store_true", help="close FLOEFD at the end if this probe started it")
    p.add_argument("--binding", default="default", choices=["default", "dynamic", "early"],
                   help="default = win32com.client.Dispatch as in the official examples; "
                        "early = register makepy wrappers in gencache first; dynamic = pure late binding")
    p.add_argument("--tlb-dir", help="folder containing EFDApi.tlb / EFDApiSrv.tlb if auto-detect fails")
    p.add_argument("--no-makepy", action="store_true", help="skip generating wrapper modules")
    p.add_argument("--attach-timeout", type=float, default=90, help="seconds (default 90)")
    p.add_argument("--start-timeout", type=float, default=900, help="seconds for RunProduct / OpenDoc (default 900)")
    p.add_argument("--out", help="output folder (default: probe_<COMPUTER>_<time> next to this script)")
    return p.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    computer = os.environ.get("COMPUTERNAME", platform.node() or "pc")
    out_dir = args.out or os.path.join(HERE, f"probe_{computer}_{stamp}")
    probe = Probe(out_dir)
    probe.report["arguments"] = vars(args)
    probe.report["environment"] = environment_info()
    probe.log(f"FLOEFD probe {TOOL_VERSION} | stage={args.stage} | output: {out_dir}")

    if not require_pywin32(probe):
        probe.write("environment_problem")
        return 3

    exit_code = 0
    launcher = None
    dumps: dict = {}
    try:
        if args.stage in ("all", "typelib"):
            t = stage_typelib(probe, args)
            launcher, dumps = t["launcher"], t["dumps"]
        if args.stage in ("all", "connect"):
            if launcher is None:
                launcher = choose_launcher(find_launchers(probe), args.progid, probe)
            if args.binding == "early" and not dumps:
                tlbs = find_typelibs(probe, launcher, args.tlb_dir)
                for key, path in tlbs.items():
                    if path:
                        ok, d = probe.call(f"LoadTypeLib[{key}]", dump_typelib, path)
                        if ok:
                            dumps[key] = d
            if not stage_connect(probe, args, launcher, dumps):
                exit_code = 4
    except Exception as exc:  # noqa: BLE001
        probe.log("Unexpected error: " + "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
        probe.report["unexpected_error"] = describe_error(exc)
        exit_code = 1

    if exit_code == 0 and (any(not c.get("ok") for c in probe.calls) or probe.report.get("warnings")):
        exit_code = 1
    status = {0: "ok", 1: "finished_with_failures", 4: "connect_failed"}[exit_code]
    probe.write(status)
    probe.log(f"Done: {status}. Open {os.path.join(out_dir, 'summary.md')}")
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
