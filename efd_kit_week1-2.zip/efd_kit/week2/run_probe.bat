@echo off
rem FLOEFD automation - Week 2 connection probe (Python).
rem Double-click to run everything (typelib + connect, mode auto).
rem Options are passed through, e.g.:
rem   run_probe.bat typelib
rem   run_probe.bat connect --mode attach
rem   run_probe.bat all --progid EFDApiSrv.EFDLauncher.0.2606
setlocal
cd /d "%~dp0"
set PY=python
where python >nul 2>nul
if errorlevel 1 set PY=py
%PY% "%~dp0efd_probe.py" %*
echo.
echo Exit code: %ERRORLEVEL%   (0 ok, 1 some failures, 2 timeout, 3 environment, 4 connect failed)
echo Open the newest probe_* folder and read summary.md first.
pause
