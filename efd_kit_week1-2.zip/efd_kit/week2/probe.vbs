' FLOEFD automation - fallback connection probe WITHOUT Python (Windows Script Host).
' Use it when Python cannot be installed, or to tell a COM problem from a Python problem.
'
' Usage:  cscript //nologo probe.vbs [ProgID] [auto|attach|run]
'   ProgID  default EFDApiSrv.EFDLauncher (works when only one FLOEFD is installed)
'   mode    auto (default) = attach to a running FLOEFD, start one if none
'
' Read-only: connects, reads version strings, lists open documents. Writes probe_vbs_<time>.log
Option Explicit

Dim progId, mode, fso, logFile, logPath, srv, app, cad, v, docs, d, i
progId = "EFDApiSrv.EFDLauncher"
mode = "auto"
If WScript.Arguments.Count >= 1 Then progId = WScript.Arguments(0)
If WScript.Arguments.Count >= 2 Then mode = LCase(WScript.Arguments(1))

Set fso = CreateObject("Scripting.FileSystemObject")
logPath = fso.BuildPath(fso.GetParentFolderName(WScript.ScriptFullName), _
          "probe_vbs_" & Year(Now) & Right("0" & Month(Now), 2) & Right("0" & Day(Now), 2) & "_" & _
          Right("0" & Hour(Now), 2) & Right("0" & Minute(Now), 2) & Right("0" & Second(Now), 2) & ".log")
Set logFile = fso.CreateTextFile(logPath, True)

Sub LogLine(msg)
    Dim line
    line = "[" & Right("0" & Hour(Now), 2) & ":" & Right("0" & Minute(Now), 2) & ":" & Right("0" & Second(Now), 2) & "] " & msg
    WScript.Echo line
    logFile.WriteLine line
End Sub

Function ErrText()
    ErrText = "error 0x" & Hex(Err.Number) & " " & Err.Source & ": " & Err.Description
End Function

LogLine "FLOEFD VBScript probe. ProgID=" & progId & " mode=" & mode

On Error Resume Next

Err.Clear
Set srv = CreateObject(progId)
If Err.Number <> 0 Then
    LogLine "FAIL CreateObject(" & progId & "): " & ErrText()
    LogLine "Result: COM launcher is not available. Check the ProgID (see week 1 summary.md)."
    logFile.Close
    WScript.Quit 4
End If
LogLine "OK   CreateObject(" & progId & ")"

Set app = Nothing
If mode = "attach" Or mode = "auto" Then
    Err.Clear
    Set app = srv.Attach2RunningCADInstance(0)
    If Err.Number <> 0 Then
        LogLine "FAIL Attach2RunningCADInstance(0): " & ErrText()
        Set app = Nothing
    ElseIf app Is Nothing Then
        LogLine "FAIL Attach2RunningCADInstance(0): returned Nothing"
    Else
        LogLine "OK   Attach2RunningCADInstance(0)"
    End If
End If

If app Is Nothing And (mode = "run" Or mode = "auto") Then
    LogLine "Starting FLOEFD with RunProduct (may take several minutes) ..."
    Err.Clear
    Set app = srv.RunProduct()
    If Err.Number <> 0 Then
        LogLine "FAIL RunProduct(): " & ErrText()
        Set app = Nothing
    ElseIf app Is Nothing Then
        LogLine "FAIL RunProduct(): returned Nothing"
    Else
        LogLine "OK   RunProduct()"
    End If
End If

If app Is Nothing Then
    LogLine "Result: could not get the FLOEFD application object."
    logFile.Close
    WScript.Quit 4
End If

Err.Clear
v = app.GetVersion()
If Err.Number <> 0 Then LogLine "FAIL App.GetVersion(): " & ErrText() Else LogLine "OK   App.GetVersion() = " & v

Err.Clear
Set cad = app.GetCAD()
If Err.Number <> 0 Then
    LogLine "FAIL App.GetCAD(): " & ErrText()
Else
    Err.Clear
    v = cad.GetVersionString()
    If Err.Number <> 0 Then LogLine "FAIL CAD.GetVersionString(): " & ErrText() Else LogLine "OK   CAD.GetVersionString() = " & v
End If

Err.Clear
docs = app.GetDocuments()
If Err.Number <> 0 Then
    LogLine "FAIL App.GetDocuments(): " & ErrText()
ElseIf IsArray(docs) Then
    LogLine "OK   App.GetDocuments(): " & (UBound(docs) + 1) & " document(s)"
    For i = 0 To UBound(docs)
        Err.Clear
        Set d = docs(i)
        v = d.GetTitle()
        If Err.Number <> 0 Then LogLine "FAIL Doc(" & i & ").GetTitle(): " & ErrText() Else LogLine "     Doc(" & i & ") = " & v
    Next
Else
    LogLine "OK   App.GetDocuments(): no open documents"
End If

LogLine "Result: connected. Log written to " & logPath
logFile.Close
WScript.Quit 0
