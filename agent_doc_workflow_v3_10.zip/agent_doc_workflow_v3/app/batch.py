"""
フォルダ一括処理（v3.6 新增）。

これまでの投入口はブラウザのファイル選択／ドロップだけで、
「このフォルダの中身を全部やっておいて」ができなかった。数百件の存量資料を
消化する導線としては致命的なので、**パスを渡して配下を丸ごと処理する**入口を足す。

設計方針は既存部分と揃える：

- **ディスクが真源**：バッチの実体は `out/batches/<batch_id>/batch.json`。
  DB は使わない。サービスを再起動しても JSON を読み直せば復元できる。
- **原本には触らない**：inbox へコピーせず、フォルダ内のファイルを直接読む。
  したがって run を削除しても利用者の原本は消えない（削除は inbox 配下限定）。
- **run_id はディスクの run ディレクトリ名と一致させる**
  （`<stem>_<内容ハッシュ>`）。アップロード経路が抱えていた
  「API の run_id とディスクの run ディレクトリ名が別物」問題を、
  こちらでは最初から作らない。再起動後も履歴が二重に出ない。
- **履歴は分離**：単発投入の実行履歴とは別カードに出す（利用者の要望）。
  run 側には batch_id を持たせ、単発履歴からは除外する。
"""
from __future__ import annotations

import json
import shutil
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

_lock = threading.Lock()

# 一括処理の対象拡張子（webapp の ALLOWED_SUFFIXES と揃える）
DEFAULT_SUFFIXES = {".pdf", ".docx", ".pptx", ".xlsx", ".xlsm", ".xls",
                    ".md", ".txt", ".html"}

# 走査時に無視するフォルダ（自分の出力を食べに行かないための最低限の防御）
_SKIP_DIRS = {"out", "__pycache__", ".git", "node_modules", "versions",
              "processed", "runs", "batches"}


def batches_root(out_dir: str | Path) -> Path:
    return Path(out_dir) / "batches"


# ----------------------------------------------------------------------
# 走査
# ----------------------------------------------------------------------

def scan_folder(folder: str | Path, recursive: bool = True,
                suffixes: Optional[set] = None, max_files: int = 500) -> Dict[str, Any]:
    """対象ファイルを列挙するだけ（副作用なし）。UI の事前確認にも使う。"""
    suffixes = suffixes or DEFAULT_SUFFIXES
    root = Path(folder).expanduser()
    if not root.exists():
        return {"ok": False, "error": f"パスが存在しません: {root}", "files": []}
    if not root.is_dir():
        return {"ok": False, "error": f"フォルダではありません: {root}", "files": []}

    files: List[Path] = []
    skipped_unsupported = 0
    it = root.rglob("*") if recursive else root.glob("*")
    for p in sorted(it):
        if p.is_dir():
            continue
        if any(part in _SKIP_DIRS or part.startswith(".") for part in p.relative_to(root).parts[:-1]):
            continue
        if p.name.startswith((".", "~$")):        # Office のロックファイル対策
            continue
        if p.suffix.lower() not in suffixes:
            skipped_unsupported += 1
            continue
        files.append(p)
        if len(files) >= max_files:
            break

    return {"ok": True, "folder": str(root), "recursive": recursive,
            "count": len(files), "skipped_unsupported": skipped_unsupported,
            "truncated": len(files) >= max_files,
            "files": [{"name": f.name, "rel": str(f.relative_to(root)), "path": str(f)}
                      for f in files]}


def check_allowed(folder: str | Path, allowed_roots: List[str]) -> Optional[str]:
    """allowed_roots が設定されている場合のみ、その配下かを検査する。"""
    if not allowed_roots:
        return None
    target = Path(folder).expanduser().resolve()
    for root in allowed_roots:
        try:
            if str(target).startswith(str(Path(root).expanduser().resolve())):
                return None
        except OSError:
            continue
    return f"許可されていないパスです（config.yaml の batch.allowed_roots を確認）: {target}"


# ----------------------------------------------------------------------
# バッチの生成・読み書き
# ----------------------------------------------------------------------

def create_batch(out_dir: str | Path, folder: str, items: List[Dict[str, Any]],
                 template_id: str = "case", input_mode: str = "auto",
                 recursive: bool = True) -> Dict[str, Any]:
    root = batches_root(out_dir)
    batch_id = f"batch_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    record = {
        "batch_id": batch_id,
        "folder": str(folder),
        "recursive": recursive,
        "template_id": template_id,
        "input_mode": input_mode,
        "created": time.time(),
        "items": items,
    }
    d = root / batch_id
    d.mkdir(parents=True, exist_ok=True)
    _write(d / "batch.json", record)
    return record


def _write(path: Path, data: Dict[str, Any]) -> None:
    with _lock:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)          # 途中で落ちても壊れた JSON を残さない


def load_batch(out_dir: str | Path, batch_id: str) -> Optional[Dict[str, Any]]:
    if ".." in batch_id or "/" in batch_id or "\\" in batch_id:
        return None
    p = batches_root(out_dir) / batch_id / "batch.json"
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def all_batches(out_dir: str | Path) -> List[Dict[str, Any]]:
    root = batches_root(out_dir)
    if not root.exists():
        return []
    out = []
    for d in sorted(root.iterdir(), reverse=True):
        p = d / "batch.json"
        if d.is_dir() and p.exists():
            try:
                out.append(json.loads(p.read_text(encoding="utf-8")))
            except Exception:  # noqa: BLE001 壊れた 1 件で一覧全体を壊さない
                continue
    return out


def set_item_state(out_dir: str | Path, batch_id: str, run_id: str, state: str) -> None:
    """run 完了時に呼ぶ。ディスク側にも状態を残すので再起動後も進捗が読める。"""
    record = load_batch(out_dir, batch_id)
    if not record:
        return
    changed = False
    for item in record.get("items", []):
        if item.get("run_id") == run_id and item.get("state") != state:
            item["state"] = state
            item["updated"] = time.time()
            changed = True
    if changed:
        _write(batches_root(out_dir) / batch_id / "batch.json", record)


def delete_batch(out_dir: str | Path, batch_id: str) -> bool:
    d = batches_root(out_dir) / batch_id
    root = batches_root(out_dir).resolve()
    if not d.exists() or not str(d.resolve()).startswith(str(root)):
        return False
    shutil.rmtree(d, ignore_errors=True)
    return True


def run_to_batch_map(out_dir: str | Path) -> Dict[str, str]:
    """起動時の復元用：run_id -> batch_id。単発履歴からバッチ分を外すのに使う。"""
    mapping: Dict[str, str] = {}
    for record in all_batches(out_dir):
        for item in record.get("items", []):
            rid = item.get("run_id")
            if rid:
                mapping[rid] = record["batch_id"]
    return mapping


def summarize(record: Dict[str, Any], live_states: Dict[str, str]) -> Dict[str, Any]:
    """一覧表示用の集計。live_states（メモリ上の run 状態）を優先する。"""
    items = record.get("items", [])
    states = [live_states.get(it.get("run_id", ""), it.get("state", "unknown")) for it in items]
    counts: Dict[str, int] = {}
    for s in states:
        counts[s] = counts.get(s, 0) + 1
    total = len(items)
    finished = sum(counts.get(s, 0) for s in ("done", "failed", "cancelled"))
    return {
        "batch_id": record["batch_id"],
        "folder": record.get("folder", ""),
        "template_id": record.get("template_id", "case"),
        "input_mode": record.get("input_mode", "auto"),
        "created": record.get("created", 0),
        "total": total,
        "done": counts.get("done", 0),
        "failed": counts.get("failed", 0),
        "finished": finished,
        "complete": total > 0 and finished >= total,
        "counts": counts,
    }
