"""
模板注册表（v3.4）。

设计目标：**不写 Python 也能新增一种输出模板**。每个模板是
templates/registry/<id>/ 下的一个文件夹：

    template.yaml   —— 元数据、字段定义、证据类别、提取/摘要指示
    output.md.j2    —— Markdown 渲染模板

字段定义会在加载时动态生成 Pydantic 模型（pydantic.create_model），
因此"契约单一真源"原则对注册模板同样成立：schema/校验/skeleton/
模板变量校验全部由 template.yaml 自动派生，不存在手抄漂移。

内置 "case"（依頼対応事例）模板桥接既有的 CaseSummary 硬编码契约，
保证向后兼容；新模板全部走动态路径。

用户自学新增模板的完整教程见 docs/TEMPLATE_GUIDE.md。
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

import yaml
from pydantic import BaseModel, Field, create_model

from .config import PROJECT_ROOT
from .contract import CaseSummary, EvidenceCategory, UNKNOWN, schema_skeleton

REGISTRY_DIR = PROJECT_ROOT / "templates" / "registry"


# ----------------------------------------------------------------------
# template.yaml 的结构定义（本身也用 Pydantic 校验，坏模板加载即报错）
# ----------------------------------------------------------------------

class FieldSpec(BaseModel):
    type: str = "str"                 # str | list | records
    label: str = ""                   # 渲染/RAG 用的日文标签
    item_fields: Dict[str, str] = Field(default_factory=dict)  # records 专用: 名->str/list
    # v3.8：この項目がこの文書種別に「有って当然か」を宣言する。
    #   required  … 無ければ本当に欠落（覆盖率の分母に入る）
    #   optional  … 有れば良いが無くても異常ではない
    #   n_a       … この種別には概念が無い（該当なしと描画し、分母に入れない）
    # 覆盖率（fill_rate）の計算と、テンプレート不一致の自動検知に使う。
    applicability: str = "required"


class TemplateYaml(BaseModel):
    id: str
    name: str
    description: str = ""
    evidence_categories: List[str] = Field(default_factory=list)
    key_categories: List[str] = Field(default_factory=list)     # gap_fill 检查的关键类别
    title_field: str = ""             # 台账"案件名"取哪个字段
    summary_instructions: str = ""    # Agent 3 的模板专属指示
    extraction_hint: str = ""         # Agent 1 的模板专属补充提示
    fields: Dict[str, FieldSpec] = Field(default_factory=dict)
    markdown_template: str = "output.md.j2"
    rag_sections: Dict[str, List[str]] = Field(default_factory=dict)  # 节名->字段列表
    # v3.8：この値を下回る fill_rate なら「テンプレートが文書に合っていない」
    # と判断して汎用テンプレートへの切り替えを提案する。
    min_fill_rate: float = 0.4
    # 自動判定のヒント（ファイル名・見出しに現れる語）。LLM を呼ぶ前に効く。
    filename_hints: List[str] = Field(default_factory=list)


# ----------------------------------------------------------------------
# 动态模型生成
# ----------------------------------------------------------------------

def _build_model(ty: TemplateYaml) -> Type[BaseModel]:
    defs: Dict[str, Any] = {}
    for fname, fs in ty.fields.items():
        if fs.type == "str":
            defs[fname] = (str, UNKNOWN)
        elif fs.type == "list":
            defs[fname] = (List[str], Field(default_factory=lambda: [UNKNOWN]))
        elif fs.type == "records":
            item_defs = {}
            for iname, itype in fs.item_fields.items():
                item_defs[iname] = ((List[str], Field(default_factory=list))
                                    if itype == "list" else (str, UNKNOWN))
            Item = create_model(f"{ty.id}_{fname}_item", **item_defs)
            defs[fname] = (List[Item], Field(default_factory=list))
        else:
            raise ValueError(f"模板 {ty.id} 字段 {fname}: 未知 type '{fs.type}'")
    if "evidence" not in defs:
        defs["evidence"] = (List[str], Field(default_factory=list))
    return create_model(f"Summary_{ty.id}", **defs)


# ----------------------------------------------------------------------
# TemplateSpec：流水线各节点消费的统一接口
# ----------------------------------------------------------------------

class TemplateSpec:
    def __init__(self, ty: TemplateYaml, model: Type[BaseModel],
                 md_template_path: Path, raw_yaml: str):
        # v3.8：項目ごとの「有って当然か」宣言と不一致しきい値。
        # 覆盖率の計算と、テンプレート差し替えの提案に使う。
        self.field_applicability: Dict[str, str] = {
            fname: fs.applicability for fname, fs in ty.fields.items()}
        self.min_fill_rate: float = ty.min_fill_rate
        self.filename_hints: List[str] = list(ty.filename_hints)
        self.id = ty.id
        self.name = ty.name
        self.description = ty.description
        self.categories = ty.evidence_categories
        self.key_categories = ty.key_categories
        self.title_field = ty.title_field
        self.summary_instructions = ty.summary_instructions
        self.extraction_hint = ty.extraction_hint
        self.model = model
        self.md_template_path = md_template_path
        self.raw_yaml = raw_yaml
        self.rag_sections = ty.rag_sections
        self.field_labels = {k: (v.label or k) for k, v in ty.fields.items()}

    def skeleton(self) -> Any:
        return schema_skeleton(self.model.model_json_schema())

    def json_schema(self) -> dict:
        return self.model.model_json_schema()

    def post_process(self, summary: BaseModel) -> BaseModel:
        """模板专属后处理（内置 case 模板生成标题；动态模板默认无操作）。"""
        return summary

    def title_of(self, summary_dict: dict) -> str:
        if self.title_field:
            v = summary_dict.get(self.title_field, "")
            return v if isinstance(v, str) else ""
        return summary_dict.get("case_name", "")


class _CaseSpec(TemplateSpec):
    """内置模板：桥接既有 CaseSummary 硬编码契约（向后兼容）。"""

    def __init__(self):
        yaml_path = PROJECT_ROOT / "templates" / "case_summary_v1.yaml"
        ty = TemplateYaml(
            id="case", name="依頼対応事例",
            description="一件の解析依頼とその対応結果を要約（PDF/PPT/Word 向け）",
            evidence_categories=[c.value for c in EvidenceCategory],
            key_categories=["requester", "target", "issue", "request_scope",
                            "tool", "period", "finding", "effect"],
            title_field="case_name",
        )
        super().__init__(
            ty, CaseSummary,
            md_template_path=PROJECT_ROOT / "templates" / "case_summary_v2.md.j2",
            raw_yaml=yaml_path.read_text(encoding="utf-8") if yaml_path.exists() else "",
        )
        self.rag_sections = {
            "request_details": ["request_details"],
            "action_results": ["action_results"],
        }
        # v3.8：この内蔵テンプレートは fields を YAML で宣言していないので、
        # CaseSummary の構造に合わせて applicability をここで与える。
        # 「依頼対応事例」という枠が前提とする項目＝required。これが軒並み
        # 埋まらない文書は、そもそもこのテンプレートの対象ではない。
        self.field_applicability = {
            "case_name": "required",
            "requester": "required",
            "target_product_or_system": "required",
            "background": "optional",
            "client_issues": "required",
            "scope_of_request": "required",
            "support_type": "required",
            "tools_environment": "optional",
            "period": "optional",
            "findings": "required",
            "effects": "required",
        }
        self.min_fill_rate = 0.4

    def post_process(self, summary: BaseModel) -> BaseModel:
        return summary.finalize_titles()  # type: ignore[attr-defined]


# ----------------------------------------------------------------------
# 注册表加载
# ----------------------------------------------------------------------

class TemplateRegistry:
    def __init__(self):
        self._specs: Dict[str, TemplateSpec] = {"case": _CaseSpec()}
        self._load_dir()

    def _load_dir(self) -> None:
        if not REGISTRY_DIR.exists():
            return
        for d in sorted(REGISTRY_DIR.iterdir()):
            yml = d / "template.yaml"
            if not d.is_dir() or not yml.exists():
                continue
            raw = yml.read_text(encoding="utf-8")
            ty = TemplateYaml.model_validate(yaml.safe_load(raw))  # 坏模板此处即报错
            md_path = d / ty.markdown_template
            if not md_path.exists():
                raise FileNotFoundError(f"模板 {ty.id}: 缺少 {ty.markdown_template}")
            model = _build_model(ty)
            self._specs[ty.id] = TemplateSpec(ty, model, md_path, raw)

    def get(self, template_id: str) -> TemplateSpec:
        if template_id not in self._specs:
            raise KeyError(f"未注册的模板: {template_id}（可用: {list(self._specs)}）")
        return self._specs[template_id]

    def list(self) -> List[Dict[str, str]]:
        return [{"id": s.id, "name": s.name, "description": s.description}
                for s in self._specs.values()]

    def verify_all(self) -> Dict[str, set]:
        """启动时校验：每个模板的 j2 引用的变量必须在其契约字段里（v1 教训的注册表版）。"""
        from .render import verify_template_for_model
        bad = {}
        for spec in self._specs.values():
            unknown = verify_template_for_model(str(spec.md_template_path), spec.model)
            if unknown:
                bad[spec.id] = unknown
        return bad


@lru_cache(maxsize=1)
def get_registry() -> TemplateRegistry:
    return TemplateRegistry()
