"""v2.2: resolution-controlled plane CSV, spacing-based box CSV,
full-resolution slice preview, vector glyph seeds."""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pytest

from fdpost.core.query import lattice_1d, lattice_len, sample_box, sample_plane
from fdpost.domain.errors import RegionTooLargeError
from fdpost.domain.requests import BoxRegionRequest, PlaneRegionRequest


# --- lattice primitive ------------------------------------------------------

def test_lattice_spacing_is_exact():
    a = lattice_1d(0.0, 1.0, spacing=0.3)
    assert np.allclose(np.diff(a), 0.3)          # interval exact, not divided
    assert a[-1] <= 1.0 + 1e-12
    assert len(a) == lattice_len(0.0, 1.0, spacing=0.3)


def test_lattice_count_hits_both_endpoints():
    a = lattice_1d(2.0, 3.0, count=5)
    assert a[0] == 2.0 and a[-1] == 3.0 and len(a) == 5
    assert len(lattice_1d(2.0, 3.0, count=1)) == 1
    assert len(lattice_1d(5.0, 5.0, spacing=0.1)) == 1     # degenerate axis


# --- box region with spacing ------------------------------------------------

def test_sample_box_spacing(grid_idw):
    df = sample_box(grid_idw, (0.2, 0.2, 0.2), (0.8, 0.8, 0.8), None,
                    ["pressure"], max_rows=10**7, spacing=(0.2, 0.2, 0.1))
    assert len(df) == 4 * 4 * 7
    assert np.allclose(np.diff(np.unique(df["x_m"])), 0.2)


def test_sample_box_row_limit_uses_spacing(grid_idw):
    with pytest.raises(RegionTooLargeError):
        sample_box(grid_idw, (0, 0, 0), (1, 1, 1), None, ["pressure"],
                   max_rows=100, spacing=(0.01, 0.01, 0.01))


# --- plane region -----------------------------------------------------------

def test_sample_plane_axis_aligned(grid_idw):
    df = sample_plane(grid_idw, (0.5, 0.5, 0.5), (0, 0, 1), ["pressure"],
                      max_rows=10**7, spacing=(0.05, 0.05))
    assert list(df.columns) == ["u_m", "v_m", "x_m", "y_m", "z_m",
                                "pressure", "is_solid"]
    assert df["z_m"].nunique() == 1               # a plane, not a slab
    assert np.isclose(df["z_m"].iloc[0], 0.5)


def test_sample_plane_tilted_and_limit(grid_idw):
    df = sample_plane(grid_idw, (0.5, 0.5, 0.5), (1, 1, 1), ["pressure"],
                      max_rows=10**7, resolution=(40, 40))
    assert len(df) == 1600
    assert df["pressure"].notna().any()           # the cut hits real data
    with pytest.raises(RegionTooLargeError):
        sample_plane(grid_idw, (0.5, 0.5, 0.5), (0, 0, 1), ["pressure"],
                     max_rows=100, resolution=(400, 400))


# --- request validation -----------------------------------------------------

def test_region_requests_demand_exactly_one_resolution_spec():
    with pytest.raises(ValueError):
        BoxRegionRequest(min_point=(0, 0, 0), max_point=(1, 1, 1))
    with pytest.raises(ValueError):
        BoxRegionRequest(min_point=(0, 0, 0), max_point=(1, 1, 1),
                         resolution=(4, 4, 4), spacing=(0.1, 0.1, 0.1))
    with pytest.raises(ValueError):
        PlaneRegionRequest(mode="euler", tilt_deg=0, azimuth_deg=0, distance=0)
    ok = PlaneRegionRequest(mode="euler", tilt_deg=30, azimuth_deg=10,
                            distance=0.01, spacing=(0.002, 0.002))
    assert ok.resolution is None


# --- API --------------------------------------------------------------------

def test_plane_region_endpoint(api_client, api_dataset):
    c, _ = api_client
    r = c.post(f"/api/datasets/{api_dataset}/region/plane",
               json={"mode": "euler", "tilt_deg": 0, "azimuth_deg": 0,
                     "distance": 0.0, "spacing": [0.05, 0.05],
                     "fields": ["pressure"]})
    assert r.status_code == 200
    j = r.json()
    assert j["n_rows"] > 100 and j["csv_url"].endswith(".csv")
    assert np.allclose(j["normal"], [0, 0, 1], atol=1e-9)

    r = c.post(f"/api/datasets/{api_dataset}/region/plane",
               json={"mode": "point_normal", "origin": [0.5, 0.5, 0.5],
                     "normal": [1, 1, 0], "resolution": [4000, 4000]})
    assert r.status_code == 413


def test_box_region_spacing_endpoint(api_client, api_dataset):
    c, _ = api_client
    r = c.post(f"/api/datasets/{api_dataset}/region",
               json={"min_point": [0.2, 0.2, 0.2], "max_point": [0.4, 0.4, 0.4],
                     "spacing": [0.1, 0.1, 0.1]})
    assert r.status_code == 200 and r.json()["n_rows"] == 27


def test_full_resolution_slice_preview(api_client, api_dataset):
    c, _ = api_client
    r = c.get(f"/api/datasets/{api_dataset}/preview/slice/pressure",
              params={"axis": "z", "position": 0.5, "with_vectors": True})
    assert r.status_code == 200
    meta = json.loads(r.headers["X-Meta"])
    nu, nv = meta["dims"]
    assert meta["axis"] == "z" and meta["labels"] == ["X [m]", "Y [m]"]
    assert meta["vectors"] is True
    # values + vec_u + vec_v, each nu*nv float32
    assert len(r.content) == nu * nv * 4 * 3
    vals = np.frombuffer(r.content, np.float32, count=nu * nv)
    assert np.isnan(vals).any()                   # solid sphere shows as NaN
    assert np.isfinite(vals).any()


def test_slice_preview_beats_point_cloud_resolution(api_client, api_dataset):
    """The drawer preview must not be capped at the downsampled preview grid."""
    c, _ = api_client
    pm = c.get(f"/api/datasets/{api_dataset}/preview/meta").json()
    r = c.get(f"/api/datasets/{api_dataset}/preview/slice/pressure",
              params={"axis": "z", "position": 0.5})
    meta = json.loads(r.headers["X-Meta"])
    assert meta["full_dims"] == pm["full_dims"]


def test_vector_glyph_seeds(api_client, api_dataset):
    c, _ = api_client
    r = c.get(f"/api/datasets/{api_dataset}/preview/vectors", params={"max_dim": 16})
    assert r.status_code == 200
    m = int(r.headers["X-Count"])
    assert m > 0 and len(r.content) == m * 24     # coords(3) + vec(3) f32
    arr = np.frombuffer(r.content, np.float32)
    assert np.isfinite(arr).all()                 # solid/NaN rows filtered out
    assert float(r.headers["X-Speed-Max"]) > 0


# --- v2.2.1 fixes -----------------------------------------------------------

def test_isosurface_is_a_closed_shell(grid_idw):
    """Regression: masking cubes near solid used to punch holes in the mesh.
    A watertight mesh has no edge used by only one triangle."""
    from collections import Counter

    from fdpost.core.isosurface import compute_isosurface, field_range

    lo, hi = field_range(grid_idw, "velocity_magnitude")
    _, faces, _ = compute_isosurface(grid_idw, "velocity_magnitude",
                                     lo + 0.55 * (hi - lo))
    edges: Counter = Counter()
    for a, b, c in faces:
        for e in ((a, b), (b, c), (c, a)):
            edges[tuple(sorted(e))] += 1
    open_edges = sum(1 for v in edges.values() if v == 1)
    assert open_edges == 0, f"{open_edges} open edges -> holes in the surface"


def test_isosurface_smoothing_reduces_roughness(grid_idw):
    """Smoothing should measurably calm the surface, not just change it."""
    from fdpost.core.isosurface import compute_isosurface, field_range

    lo, hi = field_range(grid_idw, "pressure")
    level = 0.5 * (lo + hi)

    def roughness(smooth: float) -> float:
        verts, faces, _ = compute_isosurface(grid_idw, "pressure", level,
                                             smooth=smooth)
        # mean dihedral-ish proxy: spread of face normals against their mean
        v = verts[faces]
        n = np.cross(v[:, 1] - v[:, 0], v[:, 2] - v[:, 0])
        ln = np.linalg.norm(n, axis=1, keepdims=True)
        n = n / np.maximum(ln, 1e-20)
        return float(np.std(n))

    assert roughness(1.2) < roughness(0.0)


def test_dataset_delete(api_client, api_dataset):
    c, tsv = api_client
    with open(tsv, "rb") as f:
        r = c.post("/api/datasets/upload",
                   files={"file": ("throwaway.txt", f, "text/plain")},
                   data={"method": "nearest", "target_dims": "16"})
    ds = r.json()["dataset_id"]
    assert any(d["id"] == ds for d in c.get("/api/datasets").json())

    assert c.delete(f"/api/datasets/{ds}").status_code == 200
    assert not any(d["id"] == ds for d in c.get("/api/datasets").json())
    assert c.get(f"/api/datasets/{ds}").status_code == 404
    # the still-live dataset is untouched
    assert any(d["id"] == api_dataset for d in c.get("/api/datasets").json())


def test_slice_preview_resolution_is_capped_on_request(api_client, api_dataset):
    """max_dim lets the UI trade detail for speed at any time."""
    c, _ = api_client
    dims = {}
    for md in (0, 24):
        r = c.get(f"/api/datasets/{api_dataset}/preview/slice/pressure",
                  params={"axis": "z", "position": 0.5, "max_dim": md})
        dims[md] = json.loads(r.headers["X-Meta"])["dims"]
    assert dims[24][0] <= 24 and dims[24][1] <= 24
    assert dims[0][0] > dims[24][0]


# --- v2.3: slice resolution decoupled from the grid -------------------------

def test_direct_slice_exceeds_grid_resolution(api_client, api_dataset):
    """The whole point: a slice finer than the preprocessing grid."""
    c, _ = api_client
    grid_dims = c.get(f"/api/datasets/{api_dataset}/preview/meta").json()["full_dims"]
    ceiling = max(grid_dims)

    r = c.get(f"/api/datasets/{api_dataset}/preview/slice_direct/pressure",
              params={"axis": "z", "position": 0.5, "res": 256})
    assert r.status_code == 200
    meta = json.loads(r.headers["X-Meta"])
    nu, nv = meta["dims"]
    assert max(nu, nv) == 256 > ceiling          # past the grid ceiling
    assert meta["source"] == "scatter"
    assert meta["n_source_points"] > 0
    assert len(r.content) == nu * nv * 4

    vals = np.frombuffer(r.content, np.float32)
    assert np.isfinite(vals).any()
    assert np.isnan(vals).any()                  # solid sphere still a hole


def test_direct_slice_agrees_with_grid_slice(api_client, api_dataset):
    """Different sampling paths, same physics — they must broadly agree."""
    c, _ = api_client

    def plane(url, params):
        r = c.get(f"/api/datasets/{api_dataset}{url}", params=params)
        m = json.loads(r.headers["X-Meta"])
        nu, nv = m["dims"]
        return np.frombuffer(r.content, np.float32, count=nu * nv), m

    g, _ = plane("/preview/slice/pressure", {"axis": "z", "position": 0.5})
    d, _ = plane("/preview/slice_direct/pressure",
                 {"axis": "z", "position": 0.5, "res": 48})
    gm, dm = np.nanmean(g), np.nanmean(d)
    assert abs(gm - dm) / max(abs(gm), 1e-9) < 0.15


def test_direct_slice_is_capped(api_client, api_dataset):
    c, _ = api_client
    r = c.get(f"/api/datasets/{api_dataset}/preview/slice_direct/pressure",
              params={"axis": "z", "position": 0.5, "res": 99999})
    meta = json.loads(r.headers["X-Meta"])
    assert max(meta["dims"]) <= 1200             # settings.slice_direct_max_px


def test_direct_slice_vectors(api_client, api_dataset):
    c, _ = api_client
    r = c.get(f"/api/datasets/{api_dataset}/preview/slice_direct/velocity_magnitude",
              params={"axis": "y", "position": 0.5, "res": 64,
                      "with_vectors": True})
    meta = json.loads(r.headers["X-Meta"])
    nu, nv = meta["dims"]
    assert meta["vectors"] is True
    assert meta["labels"] == ["X [m]", "Z [m]"]
    assert len(r.content) == nu * nv * 4 * 3


# --- packaging: the UI must actually ship and be findable -------------------

def test_frontend_is_locatable(api_client):
    """Regression: `pip install` used to ship the backend only, so the server
    fell back to whatever frontend/dist sat next to the source tree it was
    launched from — silently serving a stale UI."""
    from fdpost.config import frontend_dist

    d = frontend_dist()
    if d is None:
        pytest.skip("frontend not built in this checkout")
    assert (d / "index.html").is_file()


def test_version_endpoint_reports_served_bundle(api_client):
    c, _ = api_client
    j = c.get("/api/version").json()
    assert "version" in j
    # when a UI is present, the endpoint must name the exact bundle on disk
    if j["frontend_dir"]:
        assert j["frontend_bundle"] and j["frontend_bundle"].endswith(".js")


# --- v2.4: slice fidelity ---------------------------------------------------

def _slice_img(c, ds, params):
    r = c.get(f"/api/datasets/{ds}/preview/slice_direct/pressure", params=params)
    m = json.loads(r.headers["X-Meta"])
    nu, nv = m["dims"]
    return np.frombuffer(r.content, np.float32, count=nu * nv).reshape(nv, nu), m


def _roughness(img):
    """2nd-difference energy: high = plateaued / stair-stepped."""
    a = img[1:-1, 1:-1]
    lap = (img[:-2, 1:-1] + img[2:, 1:-1] + img[1:-1, :-2] + img[1:-1, 2:] - 4 * a)
    return float(np.nanstd(lap) / max(np.nanstd(img), 1e-12))


def test_hifi_slice_is_smoother_than_idw(api_client, api_dataset):
    """The 'fake resolution' complaint: 3D IDW plateaus around each source
    point, so extra pixels add no gradient. Slab + 2D triangulation does."""
    c, _ = api_client
    base = {"axis": "z", "position": 0.5, "res": 256}
    idw, _ = _slice_img(c, api_dataset, {**base, "mode": "idw"})
    hifi, m = _slice_img(c, api_dataset, {**base, "mode": "hifi"})
    assert m["mode"] == "hifi" and m["native_px"] > 0
    # The margin is much wider on real data (0.013 vs 0.037 on a 120k-point
    # export); this fixture is deliberately small, so assert the direction
    # with a threshold the fixture can actually demonstrate.
    assert _roughness(hifi) < _roughness(idw) * 0.9


def test_native_resolution_is_reported(api_client, api_dataset):
    c, _ = api_client
    j = c.get(f"/api/datasets/{api_dataset}/preview/slice_native/pressure",
              params={"axis": "z", "position": 0.5}).json()
    assert j["slab_points"] > 0 and j["point_pitch"] > 0
    assert 16 <= j["native_px"] <= 4096
    assert j["n_source_points"] > j["slab_points"]      # a slab, not the cloud


def test_slice_export_both_formats(api_client, api_dataset):
    c, _ = api_client
    r = c.post(f"/api/datasets/{api_dataset}/slices/export", json={
        "mode": "axis", "axis": "z", "position": 0.5, "field": "pressure",
        "resolution": 320, "fidelity": "scatter", "formats": ["png", "csv"]})
    assert r.status_code == 200
    j = r.json()
    assert j["fidelity"] == "scatter" and max(j["dims"]) == 320
    assert j["png_url"].endswith(".png") and j["csv_url"].endswith(".csv")


def test_slice_export_beats_grid_resolution(api_client, api_dataset):
    """Export must not be capped by the preprocessing grid."""
    c, _ = api_client
    grid_px = max(c.get(f"/api/datasets/{api_dataset}/preview/meta"
                        ).json()["full_dims"])
    r = c.post(f"/api/datasets/{api_dataset}/slices/export", json={
        "mode": "axis", "axis": "z", "position": 0.5, "field": "pressure",
        "resolution": 600, "fidelity": "scatter", "formats": ["png"]})
    assert max(r.json()["dims"]) == 600 > grid_px


def test_batch_defaults_to_high_fidelity():
    from fdpost.domain.requests import AxisSliceBatch

    req = AxisSliceBatch(axis="z", start=0.0, stop=0.1, step=0.05)
    assert req.fidelity == "scatter"     # archival output: fidelity over speed
    assert req.smooth is True
    assert req.sample_px is None         # backend picks from source density


# --- hygiene: imports must not touch the filesystem -------------------------

def test_importing_the_app_module_creates_no_directories(tmp_path, monkeypatch):
    """`app.py` used to build an app at import time with default settings,
    so any import created data/, cache/ and output/ in the working directory.
    A smoke-test session left 70 MB of uploads in the repo that way."""
    import subprocess
    import sys

    r = subprocess.run(
        [sys.executable, "-c", "import fdpost.api.app"],
        cwd=tmp_path, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    stray = [d for d in ("data", "cache", "output") if (tmp_path / d).exists()]
    assert not stray, f"importing created {stray}"


def test_uvicorn_style_attribute_access_still_builds_the_app(tmp_path):
    """The lazy hook must not break `uvicorn fdpost.api.app:app`."""
    import subprocess
    import sys

    r = subprocess.run(
        [sys.executable, "-c",
         "import fdpost.api.app as m; assert m.app is m.app; print(type(m.app).__name__)"],
        cwd=tmp_path, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert "FastAPI" in r.stdout


# --- which UI build gets served --------------------------------------------

def _make_build(d, tag, mtime):
    import os

    d.mkdir(parents=True, exist_ok=True)
    (d / "index.html").write_text(f"<!--{tag}-->")
    os.utime(d / "index.html", (mtime, mtime))
    return d


def test_newest_frontend_build_wins_both_ways(tmp_path, monkeypatch):
    """A fixed priority is wrong half the time: installing over an old
    checkout leaves the checkout stale, and rebuilding a checkout without
    reinstalling leaves the install stale. Newest wins is self-correcting."""
    import time

    import fdpost.config as cfg

    # Both candidates are derived from the module's own location:
    #   <pkg>/web              (installed copy)
    #   <pkg>/../../frontend/dist  (source checkout)
    pkg = tmp_path / "src" / "fdpost"
    installed = pkg / "web"
    checkout = tmp_path / "frontend" / "dist"
    monkeypatch.setattr(cfg, "__file__", str(pkg / "config.py"))
    monkeypatch.delenv("FDPOST_FRONTEND_DIR", raising=False)
    now = time.time()

    _make_build(installed, "installed", now)
    _make_build(checkout, "checkout", now - 9999)
    assert cfg.frontend_dist() == installed        # fresh install wins

    _make_build(installed, "installed", now - 9999)
    _make_build(checkout, "checkout", now)
    assert cfg.frontend_dist() == checkout         # fresh rebuild wins


def test_frontend_dir_env_override(tmp_path, monkeypatch):
    import fdpost.config as cfg

    d = _make_build(tmp_path / "custom", "custom", 0)
    monkeypatch.setenv("FDPOST_FRONTEND_DIR", str(d))
    assert cfg.frontend_dist() == d.resolve()

    monkeypatch.setenv("FDPOST_FRONTEND_DIR", str(tmp_path / "nope"))
    assert cfg.frontend_dist() is None


def test_index_html_is_not_cacheable(api_client):
    """index.html names the hashed bundle. If a browser caches it, the UI
    keeps loading the previous build and edits appear to have no effect."""
    c, _ = api_client
    r = c.get("/")
    if r.status_code != 200 or "text/html" not in r.headers.get("content-type", ""):
        pytest.skip("no frontend build present in this checkout")
    cache = r.headers.get("cache-control", "")
    assert "no-store" in cache or "no-cache" in cache


# --- v2.4.7: ephemeral delivery + honest export resolution ------------------

def test_stream_delivery_leaves_nothing_on_the_host(api_client, api_dataset):
    """A shared server must not accumulate remote users' downloads."""
    c, _ = api_client
    out = Path(c.app.state.settings.output_dir)
    before = {p for p in out.rglob("*") if p.is_file()}

    body = {"mode": "axis", "axis": "z", "position": 0.5, "field": "pressure",
            "fidelity": "scatter", "formats": ["png", "csv"]}
    r = c.post(f"/api/datasets/{api_dataset}/slices/export?deliver=stream",
               json=body)
    assert r.status_code == 200
    assert r.headers["content-type"] == "application/zip"   # two files -> zip
    assert "attachment;" in r.headers["content-disposition"]
    assert r.headers.get("X-Fdpost-Ephemeral") == "1"
    assert len(r.content) > 1000

    after = {p for p in out.rglob("*") if p.is_file()}
    assert after == before, "stream delivery wrote to output_dir"


def test_stream_single_format_is_not_zipped(api_client, api_dataset):
    c, _ = api_client
    r = c.post(f"/api/datasets/{api_dataset}/slices/export?deliver=stream",
               json={"mode": "axis", "axis": "z", "position": 0.5,
                     "field": "pressure", "formats": ["csv"]})
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("text/csv")
    assert r.content.count(b"\n") > 10


def test_region_stream_delivery(api_client, api_dataset):
    c, _ = api_client
    out = Path(c.app.state.settings.output_dir)
    before = {p for p in out.rglob("*") if p.is_file()}
    r = c.post(f"/api/datasets/{api_dataset}/region?deliver=stream",
               json={"min_point": [0.2, 0.2, 0.2], "max_point": [0.4, 0.4, 0.4],
                     "spacing": [0.05, 0.05, 0.05]})
    assert r.status_code == 200 and len(r.content) > 100
    assert {p for p in out.rglob("*") if p.is_file()} == before


def test_export_resolution_defaults_to_what_the_data_supports(api_client,
                                                              api_dataset):
    """resolution=None must mean 'native', not 'whatever the preview showed'."""
    c, _ = api_client
    r = c.post(f"/api/datasets/{api_dataset}/slices/export", json={
        "mode": "axis", "axis": "z", "position": 0.5, "field": "pressure",
        "fidelity": "scatter", "formats": ["csv"]})
    j = r.json()
    assert j["requested_px"] is None
    assert j["native_px"] >= 16
    assert max(j["dims"]) == j["native_px"]

    r2 = c.post(f"/api/datasets/{api_dataset}/slices/export", json={
        "mode": "axis", "axis": "z", "position": 0.5, "field": "pressure",
        "fidelity": "scatter", "resolution": 200, "formats": ["csv"]})
    assert max(r2.json()["dims"]) == 200      # explicit request still wins


def test_scatter_export_reads_the_source_not_the_grid(api_client, api_dataset):
    """Regression on provenance: 'scatter' must bypass the resampled grid.
    Proven by exporting far above the grid resolution and checking the values
    are not piecewise-constant at grid cell size."""
    c, _ = api_client
    grid_px = max(c.get(f"/api/datasets/{api_dataset}/preview/meta"
                        ).json()["full_dims"])
    r = c.post(f"/api/datasets/{api_dataset}/slices/export?deliver=stream",
               json={"mode": "axis", "axis": "z", "position": 0.5,
                     "field": "pressure", "fidelity": "scatter",
                     "resolution": grid_px * 4, "formats": ["csv"]})
    body = r.content.decode("utf-8", "replace")
    rows = [l for l in body.splitlines() if l and not l.startswith("#")][1:]
    vals = []
    for line in rows:
        parts = line.split(",")
        if len(parts) > 2:
            try:
                vals.append(float(parts[2]))
            except ValueError:
                pass
    uniq = len({round(v, 9) for v in vals if v == v})
    # a grid-sourced export would repeat each cell value many times over
    assert uniq > grid_px * grid_px, f"only {uniq} distinct values"


# --- v2.5: solid cell visibility -------------------------------------------

def test_solid_points_endpoint(api_client, api_dataset):
    c, _ = api_client
    r = c.get(f"/api/datasets/{api_dataset}/preview/solid_points")
    assert r.status_code == 200
    m = int(r.headers["X-Count"])
    assert m > 0
    assert len(r.content) == m * 12          # (M,3) float32, values-free
    arr = np.frombuffer(r.content, np.float32)
    assert np.isfinite(arr).all()


def test_solid_and_fluid_points_are_disjoint(api_client, api_dataset):
    """Every voxel is one or the other — a point in both would mean the
    solid mask and its complement disagree."""
    c, _ = api_client
    solid = np.frombuffer(
        c.get(f"/api/datasets/{api_dataset}/preview/solid_points").content,
        np.float32).reshape(-1, 3)
    fr = c.get(f"/api/datasets/{api_dataset}/preview/points/pressure")
    n = int(fr.headers["X-Count"])
    fluid = np.frombuffer(fr.content, np.float32, count=n * 3).reshape(-1, 3)
    a = {tuple(np.round(p, 9)) for p in solid}
    b = {tuple(np.round(p, 9)) for p in fluid}
    assert a and b and not (a & b)


def test_voxel_points_solid_flag(grid_idw):
    solid, si = grid_idw.voxel_points(10**9, solid=True)
    fluid, fi = grid_idw.voxel_points(10**9)
    assert len(solid) + len(fluid) == int(np.prod(grid_idw.dims))
    assert grid_idw.solid_mask[si[:, 0], si[:, 1], si[:, 2]].all()
    assert not grid_idw.solid_mask[fi[:, 0], fi[:, 1], fi[:, 2]].any()


def test_export_solid_toggle_changes_the_image(api_client, api_dataset):
    c, _ = api_client

    def png(show_solid: bool) -> bytes:
        r = c.post(f"/api/datasets/{api_dataset}/slices/export?deliver=stream",
                   json={"mode": "axis", "axis": "z", "position": 0.5,
                         "field": "pressure", "fidelity": "scatter",
                         "formats": ["png"], "show_solid": show_solid})
        assert r.status_code == 200
        return r.content

    assert png(True) != png(False)


def test_batch_carries_the_solid_choice():
    from fdpost.domain.requests import AxisSliceBatch

    req = AxisSliceBatch(axis="z", start=0.0, stop=0.1, step=0.05,
                         show_solid=False, solid_color="#333333")
    assert req.show_solid is False and req.solid_color == "#333333"
    assert AxisSliceBatch(axis="z", start=0.0, stop=0.1,
                          step=0.05).show_solid is True     # 真っ黒 by default


# --- v2.6: server-side output management -----------------------------------

def test_outputs_list_and_delete(api_client, api_dataset):
    c, _ = api_client
    c.post(f"/api/datasets/{api_dataset}/slices/export", json={
        "mode": "axis", "axis": "z", "position": 0.5, "field": "pressure",
        "fidelity": "scatter", "formats": ["png", "csv"]})

    j = c.get("/api/outputs").json()
    assert j["entries"] and j["total_bytes"] > 0
    e = j["entries"][0]
    assert e["n_files"] >= 1 and e["files"]
    # the listed paths must be fetchable through the existing files endpoint
    assert c.get(f"/api/files/{e['files'][0]}").status_code == 200

    d = c.delete(f"/api/outputs/{e['name']}").json()
    assert d["freed_bytes"] == e["bytes"]
    assert e["name"] not in [x["name"] for x in c.get("/api/outputs").json()["entries"]]


def test_outputs_reject_path_traversal(api_client, tmp_path):
    """A crafted name must not reach outside the output root."""
    c, _ = api_client
    canary = Path(c.app.state.settings.output_dir).resolve().parent / "canary.txt"
    canary.write_text("do not delete")
    try:
        for bad in ("../canary.txt", "..%2Fcanary.txt", "%2e%2e%2fcanary.txt"):
            assert c.delete(f"/api/outputs/{bad}").status_code in (400, 404, 405)
        assert canary.exists(), "traversal deleted a file outside output_dir"
    finally:
        canary.unlink(missing_ok=True)


def test_outputs_refuse_to_delete_the_root(api_client):
    c, _ = api_client
    root = Path(c.app.state.settings.output_dir)
    # `.` normalises to the bulk route, which now refuses without confirm=true
    assert c.delete("/api/outputs/.").status_code in (400, 404, 405)
    assert root.exists()


def test_outputs_clear_all(api_client, api_dataset):
    c, _ = api_client
    c.post(f"/api/datasets/{api_dataset}/slices/export", json={
        "mode": "axis", "axis": "z", "position": 0.4, "field": "pressure",
        "fidelity": "grid", "formats": ["csv"]})
    assert c.get("/api/outputs").json()["entries"]
    # bulk delete demands explicit confirmation
    assert c.delete("/api/outputs").status_code == 400
    r = c.delete("/api/outputs?confirm=true").json()
    assert r["deleted"] >= 1
    assert c.get("/api/outputs").json()["entries"] == []
    assert Path(c.app.state.settings.output_dir).is_dir()   # root survives


# --- v2.6.2: dataset deletion must actually free disk ------------------------

def test_dataset_delete_frees_the_uploaded_file(api_client, tmp_path):
    """Deleting used to leave the uploaded source behind — the largest part
    of a dataset's footprint — so the list emptied but the disk did not."""
    c, tsv = api_client
    data_dir = Path(c.app.state.settings.data_dir)
    cache_dir = Path(c.app.state.settings.cache_dir)

    def payload_files() -> set[str]:
        """Data files only. The SQLite registry (and its WAL) legitimately
        stays behind — it holds the other datasets — and SQLite does not
        shrink a page file on DELETE, so byte-for-byte equality is the wrong
        thing to assert."""
        return {f.name
                for d in (data_dir, cache_dir) if d.exists()
                for f in d.rglob("*")
                if f.is_file() and "fdpost.db" not in f.name}

    before = payload_files()
    with open(tsv, "rb") as f:
        r = c.post("/api/datasets/upload",
                   files={"file": ("space.txt", f, "text/plain")},
                   data={"method": "nearest", "target_dims": "24"})
    ds, job = r.json()["dataset_id"], r.json()["job_id"]
    for _ in range(400):
        if c.get(f"/api/jobs/{job}").json()["status"] in ("done", "error"):
            break
        time.sleep(0.25)
    assert payload_files() > before

    entry = next(d for d in c.get("/api/datasets").json() if d["id"] == ds)
    assert entry["storage"]["source_owned"] is True
    assert entry["storage"]["reclaimable_bytes"] > 0

    d = c.delete(f"/api/datasets/{ds}?drop_source=true").json()
    assert d["freed_bytes"] > 0
    assert len(d["removed_files"]) == 2          # npz cache + uploaded source
    assert payload_files() == before, "delete left data files behind"


def test_registered_source_is_never_deleted(api_client, tmp_path):
    """A path the user registered in place is their file, not ours."""
    c, tsv = api_client
    mine = tmp_path / "my_own_data.txt"
    mine.write_bytes(Path(tsv).read_bytes())

    r = c.post("/api/datasets/register", json={"path": str(mine),
                                               "method": "nearest",
                                               "target_dims": 24})
    if r.status_code != 200:
        pytest.skip("register endpoint unavailable")
    ds = r.json()["dataset_id"]
    for _ in range(400):
        if c.get(f"/api/datasets/{ds}").json()["status"] in ("ready", "error"):
            break
        time.sleep(0.25)

    entry = next(d for d in c.get("/api/datasets").json() if d["id"] == ds)
    assert entry["storage"]["source_owned"] is False

    c.delete(f"/api/datasets/{ds}?drop_source=true")
    assert mine.exists(), "deleted a file the user registered in place"
