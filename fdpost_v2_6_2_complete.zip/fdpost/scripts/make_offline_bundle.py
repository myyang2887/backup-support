#!/usr/bin/env python
"""Build a self-contained folder that installs fdpost on a machine with no
network access.

The idea: do all the downloading here, where the network works, and hand the
target machine one folder it can install from with `--no-index`.

    python scripts/make_offline_bundle.py                 # for THIS platform
    python scripts/make_offline_bundle.py --platform win_amd64 --python 3.12

Platform matters. Wheels for numpy/scipy/pandas/matplotlib/scikit-image are
compiled, so a Linux wheel will not install on Windows. By default this
targets the machine you are running on; pass --platform to cross-build (which
also forces --only-binary, since a source archive cannot be built offline).

The bundle contains no Python interpreter. The target still needs Python
installed; only the packages travel. If the server has no Python at all, use
PyInstaller instead (see packaging/entry.py).
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(cmd: list[str], **kw) -> None:
    print("  $", " ".join(str(c) for c in cmd))
    subprocess.run(cmd, check=True, **kw)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default=str(ROOT.parent / "fdpost_offline"),
                    help="bundle directory to create")
    ap.add_argument("--platform", default=None,
                    help="target platform tag, e.g. win_amd64 / "
                         "manylinux2014_x86_64 (default: this machine)")
    ap.add_argument("--python", default=None,
                    help="target python version, e.g. 3.12 (with --platform)")
    ap.add_argument("--skip-frontend", action="store_true",
                    help="reuse the existing frontend/dist")
    args = ap.parse_args()

    out = Path(args.out).resolve()
    wheels = out / "wheels"
    if out.exists():
        shutil.rmtree(out)
    wheels.mkdir(parents=True)

    # 1. the UI must be built before the wheel, because the wheel embeds it
    if not args.skip_frontend:
        print("[1/4] building frontend")
        npm = shutil.which("npm")
        if npm is None:
            print("  npm not found — pass --skip-frontend to reuse frontend/dist")
            return 2
        run([npm, "install", "--no-audit", "--no-fund"], cwd=ROOT / "frontend")
        run([npm, "run", "build"], cwd=ROOT / "frontend")
    elif not (ROOT / "frontend/dist/index.html").is_file():
        print("  frontend/dist is missing; build it or drop --skip-frontend")
        return 2

    print("[2/4] building the fdpost wheel")
    run([sys.executable, "-m", "build", "--wheel", "-o", str(wheels)], cwd=ROOT)

    print("[3/4] downloading dependencies")
    cmd = [sys.executable, "-m", "pip", "download",
           "--dest", str(wheels), str(ROOT)]
    if args.platform:
        # cross-building: only binary wheels can be used without a compiler
        cmd += ["--platform", args.platform, "--only-binary=:all:"]
        if args.python:
            cmd += ["--python-version", args.python]
    run(cmd)

    print("[4/4] writing install scripts")
    _write_scripts(out)
    n = len(list(wheels.glob("*")))
    size = sum(p.stat().st_size for p in wheels.glob("*")) / (1 << 20)
    print(f"\ndone: {out}\n  {n} packages, {size:.0f} MB")
    print("  copy this whole folder to the server and run install.bat / install.sh")
    return 0


def _write_scripts(out: Path) -> None:
    (out / "install.bat").write_text(
        "@echo off\r\n"
        "REM Installs fdpost from the bundled wheels. No network needed.\r\n"
        "setlocal\r\n"
        "if not exist \"%~dp0venv\" python -m venv \"%~dp0venv\"\r\n"
        "call \"%~dp0venv\\Scripts\\activate.bat\"\r\n"
        "python -m pip install --no-index --find-links \"%~dp0wheels\" "
        "--upgrade pip 1>nul 2>nul\r\n"
        "python -m pip install --no-index --find-links \"%~dp0wheels\" "
        "--force-reinstall fdpost\r\n"
        "if errorlevel 1 (echo INSTALL FAILED & pause & exit /b 1)\r\n"
        "echo.\r\n"
        "echo Installed. Start it with run.bat\r\n"
        "pause\r\n", encoding="utf-8")

    (out / "run.bat").write_text(
        "@echo off\r\n"
        "REM --host 0.0.0.0 exposes the server to the local network.\r\n"
        "REM Use 127.0.0.1 to keep it on this machine only.\r\n"
        "setlocal\r\n"
        "call \"%~dp0venv\\Scripts\\activate.bat\"\r\n"
        "set FDPOST_OUTPUT_DIR=%~dp0output\r\n"
        "set FDPOST_DATA_DIR=%~dp0data\r\n"
        "set FDPOST_CACHE_DIR=%~dp0cache\r\n"
        "fdpost serve --host 0.0.0.0 --port 8000\r\n"
        "pause\r\n", encoding="utf-8")

    (out / "install.sh").write_text(
        "#!/usr/bin/env bash\n"
        "# Installs fdpost from the bundled wheels. No network needed.\n"
        "set -euo pipefail\n"
        'cd "$(dirname "$0")"\n'
        '[ -d venv ] || python3 -m venv venv\n'
        './venv/bin/python -m pip install --no-index --find-links ./wheels '
        '--upgrade pip >/dev/null 2>&1 || true\n'
        './venv/bin/python -m pip install --no-index --find-links ./wheels '
        '--force-reinstall fdpost\n'
        'echo "Installed. Start it with ./run.sh"\n', encoding="utf-8")

    (out / "run.sh").write_text(
        "#!/usr/bin/env bash\n"
        "set -euo pipefail\n"
        'cd "$(dirname "$0")"\n'
        'export FDPOST_OUTPUT_DIR="$PWD/output"\n'
        'export FDPOST_DATA_DIR="$PWD/data"\n'
        'export FDPOST_CACHE_DIR="$PWD/cache"\n'
        './venv/bin/fdpost serve --host 0.0.0.0 --port 8000\n', encoding="utf-8")
    for f in ("install.sh", "run.sh"):
        (out / f).chmod(0o755)

    (out / "README.txt").write_text(
        "fdpost offline bundle\n"
        "=====================\n\n"
        "The target machine needs Python installed (3.11+). Everything else\n"
        "is in wheels/ — no network access is required.\n\n"
        "Windows:\n"
        "  1. copy this whole folder to the server\n"
        "  2. double-click install.bat   (creates venv\\ and installs)\n"
        "  3. double-click run.bat       (starts the server on port 8000)\n\n"
        "Linux / macOS:\n"
        "  1. copy this whole folder to the server\n"
        "  2. ./install.sh\n"
        "  3. ./run.sh\n\n"
        "Open http://<server-ip>:8000 from any machine on the network.\n"
        "Find the IP with `ipconfig` (Windows) or `ip addr` (Linux).\n\n"
        "Data, cache and output stay inside this folder, so the whole thing\n"
        "can be moved or deleted as one unit.\n\n"
        "NOTE: the wheels were downloaded for one platform and Python version.\n"
        "If install fails with 'no matching distribution', rebuild the bundle\n"
        "with --platform / --python matching the server.\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
