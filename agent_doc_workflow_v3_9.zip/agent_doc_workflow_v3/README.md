# agent_doc_workflow v3.9 — マルチテンプレート文書要約プラットフォーム

## v3.9：精読モード・二段階書き出し・PPTX 出力・実行トレース

### 1. 精読モード（`app/deep_read.py`・UI トグル）

ページ単位で「本文が言っている数値」と「図から読み取った数値」を突き合わせ、
食い違いを検出する。人が 1 ページの中で本文と図を見比べてから次へ進むのと同じ動き。

**逐次 refine にはしていない。** 前ページの要約に次ページを溶かし込む方式は
早い段階の誤りが最後まで伝播し、位置バイアスが出て、直列なので遅い——弱い
モデルでは特に悪化する。ここでは *ページ内の突き合わせだけを並列で* 行い、
集約は従来どおり map-reduce に残した。**LLM 呼び出しは 1 回も増えない。**

裁定はモデルに任せず確定的な規則で行う：
- 単位付き数値の照合（丸め表記の揺れ 68.30/68.3 は同一とみなす）
- 本文のみ／図のみのページの検出
- 食い違いは「事実」としてプロンプトに渡し、**断定しないよう指示**する

> 実装上の注意：単位の正規表現は**長い順**に並べること。`m` を先に置くと
> `0.8 m3/min` が `0.8 m` として拾われる（実際に踏んだ）。

### 2. 二段階書き出し（要約の加筆）

一段目（`write_summary`）は temperature 0 ＋ 構造制約で **正しい骨格**を作ることに
専念し、二段目（`expand_summary`, temperature 0.25）で初めて表現を厚くする。
一発で「正確かつ詳しく」を求めると、弱いモデルは字数のために作話を始めるので、
課題を 2 つに割る。

`llm_client` に段階ごとの temperature 指定を追加（抽出は 0 のまま）。

### 3. 作話への確定的な歯止め ★

プロンプトで「推測するな」と書くだけでは止まらないので、**規則で潰す**。

要約は抽出であって創造ではない。したがって *証拠に無い数値が出てくること自体が
異常*——この一点を使って機械的に判定する（`deep_read.unsupported_numbers`）。

- **加筆**：裏の取れない数値が 1 つでもあれば、その回の加筆を **丸ごと破棄**して
  元の文面に戻す。部分採用は文どうしの整合が崩れてかえって危ない。
  破棄は `expand_report.json` と UI に記録される。
- **要約本体**：破棄はせず（骨格を捨てると出力が空になる）、
  `quality_report.json` に `unsupported_numbers` として列挙し警告を出す。

判定にモデルを使わないので、モデルの巧拙に左右されない。
丸め表記の揺れや単位なしの裸の数（箇条書き番号など）では誤検出しない。

### 4. PPTX 自動生成（`app/export_pptx.py`）

**モデルには 1 行も PPTX を書かせない。** 契約検証を通った要約だけを入力に、
スライドの組み立ては確定的なコードが行う。LLM の担当は「何を書くか」まで。

- 箇条書きが 1 枚の上限を超えたら「（続き）」スライドへ送る — **内容は落とさない**
- 表はスライドで読みづらいので箇条書きへ落とすが、値は残す
- 日本語フォントを `a:ea`（東アジア用スロット）まで明示指定（抜けると豆腐になる）
- 社内テンプレート `templates/deck_template.potx`（または .pptx）があれば書式を継承

> 実装上の注意：テンプレートの既存スライドは `_sldIdLst` から消すだけでは
> パートが残り、保存時に `ppt/slides/slide1.xml` が重複する。`drop_rel` が要る。

### 5. 実行トレース（`app/trace.py`）

**どのルートを通り、どの実装で処理したか**を記録する。同じ入力でも通る道は
何通りもあり、依存が入っていない場合は**エラーにならず静かに代替経路へ落ちる**ため、
結果だけ見ても原因に辿り着けなかった。

記録する 3 種：
- **使用**：`Docling v2.x — レイアウト解析＋表構造（OCR 有効）`
- **後退**：`Docling → pypdfium2 へ後退（レイアウト・表構造は失われます）`
- **利用不可**：`Excel COM は利用不可（Windows 以外のため）`

各実装に **依存区分**（純Python / 外部アプリ / Excel 実機）を付けているので、
「この環境で何が使えるのか」が一目で分かる。`environment_report()` は起動時の
環境確認にも使える。出力先は `pipeline_trace.json` / `quality_report.json` / `run.log`、
UI では折りたたみパネルに表示。

### 6. 設定（既定値）

| 項目 | 既定 | 意味 |
|---|---|---|
| `deep_read` | `false` | 精読モード（UI トグルで実行ごとに切替） |
| `expand_summary` | `true` | 二段階書き出し |
| `expand_max_fields` | `3` | 加筆する項目数の上限（1 項目 = LLM 1 回） |
| `expand_temperature` | `0.25` | 加筆のみ。抽出・構造化は 0 のまま |
| `expand_verify_numbers` | `true` | 作話検出（証拠に無い数値を含む加筆を破棄） |

加筆が遅いと感じたら `expand_max_fields` を下げる。0 で実質無効。

## v3.8：「黙って捨てる」の一掃 — 損失の可視化・溯源・テンプレート適合判定

v3.7 までの症状は「要約が不正確・短い・『資料内で確認できず』だらけ」だったが、
原因はプロンプトではなく**前処理で情報が静かに落ちていたこと**だった。
本バージョンはまず損失を数えられるようにし、その上で落ちていた所を塞ぐ。

### 1. 損失台帳（`app/accounting.py`・新規）
各段階の「本来いくつ有ったか / いくつ捨てたか / なぜ」を記録し、保持率を出す。
`quality_report.json` に `loss_ledger` として載る。保持率 60% 未満は critical 判定。
v3.7 の品質レポートは JSON schema 検証だけで、「形式は正しいが中身が半分欠けている」
を正常と判定していた。

### 2. 塞いだ静的截断（既定値の変更を伴う）

| 箇所 | v3.7 | v3.8 |
|---|---|---|
| `max_text_chunks` | 40 で黙って打ち切り | **0（無制限）**、上限を掛けても台帳に記録 |
| 情報量フィルタ | 閾値未満を黙って破棄 | 既定で**破棄しない**（`drop_low_info_chunks: false`） |
| `readable_text[:10]` | 1 ページの 6〜7 割を破棄 | **無制限**（`visual_readable_text_limit: 0`） |
| `has_useful_visual_info` | false のページ画像を全破棄 | ページ由来は**必ず残す** |
| 視覚証拠の並び | confidence 降順 | **頁順** |
| ページ VLM `max_tokens` | 2048（溢れて JSON 破損→頁ごと skip） | **6144** |
| 予算超過 | `break` | 記録して継続 |

### 3. 溯源（provenance）
チャンクと視覚資産が `page` / `heading` / `sheet_name` / `asset_kind` を持つ。
PDF 抽出画像はファイル名に頁番号を持っていたのに v3.7 は捨てていた。
**溯源はコードが確定的に埋める**——LLM 向けスキーマ（`EvidenceIn`）には出さない。

### 4. Excel シートのページ画像化（Windows + Excel COM）

> **視覚ルートでの分岐順序に注意**：`collect_visuals` は `if vision_route:` が
> 最優先の elif 連鎖なので、Excel 専用分岐をその後ろに置くと**到達しない**。
> v3.8 では Excel COM 分岐を連鎖の先頭に置いている（`tests/test_v38_features.py`
> が順序を固定しているので、並べ替えるとテストが落ちる）。

`excel_sheet_pdfs()` が各シートを「横 1 ページに収める・縦は流す」設定で PDF 化。
LibreOffice の `SinglePageSheets` と違い `PageSetup` を直接制御できるので、
横に広い表が数十ページに飛び散らない。`PrintTitleRows` で各ページに見出し行を反復。
数値表（numCache）経路はそのまま生きているので、**精度を落とさずに視覚での裏取りを足す**形。

### 5. テンプレート適合判定
項目ごとに `applicability`（required / optional / n_a）を宣言し、充足率を計算。
必須項目の充足率が閾値を下回ると「テンプレートが合っていない」と警告し、
汎用テンプレート `generic_doc` を提案する。
`UNKNOWN` は「未確認 / 該当なし / 抽出失敗」の 3 状態に分離。

### 6. 文書メタの注入と確定的補完
ファイル名・先頭見出しを prompt に渡す（v3.7 では一度も届いていなかった）。
`case_name` が空なら「見出し > ファイル名」でコードが埋める。

### 7. 台帳・一括実行履歴の削除
- `POST /api/runs/delete-many` — 複数 run を一括削除（成果物を残す/消すを選択可）
- `POST /api/ledger/clear?confirm=DELETE` — 台帳のみ全消去（成果物は残る）
- `POST /api/batches/delete-many` — 一括実行履歴をまとめて削除
- 全ての削除操作は `out/audit_log.jsonl` に監査証跡を追記

### 8. プロンプト
テンプレート YAML から「簡潔にまとめる」を削除（要約が短い直接原因だった）。
代わりに可算指標（1 項目 60〜120 字 / 1 フィールド 3〜7 件）と、
「字数のために推測で埋めるな」という逆方向の歯止めを置いた。

## v3.7：不具合 2 件の修正 と Excel 処理の作り直し

### 修正 1：VLM テストが既定構成で必ず失敗していた

```python
# 旧コード（app/webapp.py）
_C(**config.llm.model_dump(exclude={"vision"}), timeout_seconds=60)
```

`model_dump()` には `timeout_seconds` が既に入っている。よって
`TypeError: got multiple values for keyword argument 'timeout_seconds'` が
**必ず**送出される。しかもそれを広い `except Exception` が飲み込み、
「視覚エンドポイント未応答。llama-server の --mmproj を確認してください」と
**見当違いのヒント**を出していた。`llm.vision` を別途立てている場合だけ
別の分岐に入るので動く——既定構成（主端点を共用）でだけ壊れる、という
分かりにくい壊れ方をしていた。

対策：視覚クライアントの生成を `_vision_client()` の 1 か所に集約。
ついでに以下も直した。

- `NamedTemporaryFile(delete=False)` にハンドルを開いたまま同じパスへ `save`
  していた（Windows で PermissionError になりうる。かつプローブのたびに
  temp ファイルが残っていた）→ 一時ディレクトリ方式＋確実な後始末
- JSON で返らなかっただけの応答を「エンドポイント未応答」と誤診していた
  → `LLMJsonError` を分けて扱い、生テキストからでも色を判定
- 色判定が `red/赤/紅` の 3 語だけ → `レッド`・`#FF0000`・文章応答にも対応

### 修正 2：RAG ダウンロードが `'latin-1' codec can't encode` で落ちる

HTTP ヘッダは latin-1 しか載らない。`Content-Disposition` を手組みしていた
2 か所が、run_id（＝入力ファイル名の stem 由来なので日本語が普通に混ざる）を
そのまま埋めていたため、送信時に UnicodeEncodeError → 500。

対策：RFC 6266/5987 に従い ASCII 版を `filename=` に、原名を
`filename*=UTF-8''<percent-encoded>` に入れる `_attachment()` を用意して集約。
（`FileResponse` は Starlette が同じ処理をしてくれるので、手組みのここだけの問題だった）

### Excel 処理の作り直し（`app/excel_extract.py` / `tools/excel_com.py`）

**pywin32 は既に `tools/doc_tools.py` に居た**（`xlsx_to_html` の Excel COM 経路）。
ただし本流の解析は Docling＝openpyxl 頼みで、そこに構造的な穴があった：

| 中身 | 在り処 | 旧経路で見えたか |
|---|---|---|
| 数式の計算結果 | worksheet の `<v>` キャッシュ | ✗ `'=SUM(B2:B4)'` という**文字列**が返る |
| **グラフ** | `xl/charts/chartN.xml`（ベクタ定義） | ✗ 画像ではないので `xl/media` 抽出に掛からない |
| ピボット | 表示セルは worksheet | △ 値は見えるが何の集計か不明 |
| 外部データ | `xl/externalLinks/`、Power Pivot はデータモデル | △ キャッシュ分のみ |

つまり**グラフだけのシートは視覚資産ゼロ**で Agent 2 に渡す物が無く、
数式だらけのシートは数字が一つも入らない。これが「大型 xlsm を処理できない」の実体。

新方針は **純 Python を本命、COM を上乗せ**：

1. セル値は `data_only=True`（計算結果）＋ `read_only=True`（巨大ブック対策）
2. **グラフは `numCache` から実数値を復元して Markdown 表にする**。
   ローカルの小さいモデルに「画像の軸を読め」と要求するより桁違いに確実
3. ピボット / 外部リンク / データモデル / VBA の存在を**注記として明示**
   （見えていない物があると分かるだけで人の確認コストが下がる）
4. Excel はページ画像化しない（`route_decision` で常に text 経路）。
   表を画像で見せて数字を読ませるのは失敗しやすいため。手動 `vision` 指定は尊重

Windows + Excel がある環境では `tools/excel_com.py` が **PDF 全体**
（→ v3.6 の視覚ルートに載せればピボットも条件付き書式も「印刷したとおり」）と
**グラフ実画像**を追加する。COM を業務プロセスから叩くための安全弁も入れた
——旧 `_xlsx_to_html_with_excel` にはどれも無かった：

- `AutomationSecurity = ForceDisable`：**`.xlsm` を開いても `Workbook_Open` を実行しない**
- `UpdateLinks=0` / `AskToUpdateLinks=False` / `IgnoreReadOnlyRecommended`：
  モーダルダイアログで固まるのを防ぐ（外部リンク付きブックが固まる主因）
- ダミーパスワード：保護ブックを入力待ちにせず即失敗させる
- 別スレッド＋ハードタイムアウト、起動した PID だけを狙った後始末
  （利用者が開いている Excel は絶対に落とさない）

`pywin32` は requirements に**コメントアウトで記載**（Windows 任意）。
未導入でも純 Python 経路で完結する。

---

# agent_doc_workflow v3.6

## v3.6：計時バグ修正 / 視覚直読ルート / フォルダ一括処理 / 書面出力 / 多 agent UI

### 1. 秒表が上下に飛ぶバグ（3 つの原因が重なっていた）

見た目の不具合ではなく、素直に 3 箇所のバグだった：

| 原因 | 症状 | 修正 |
|---|---|---|
| ノード内 `i/N` 進捗のたびに history 末尾を丸ごと差し替えており、**開始時刻まで「今」に書き換わっていた** | 進捗が 1 つ進むたびに秒表が 0 に戻る | 開始時刻 `time` は保持し、最新時刻は `updated` に別途記録（`observability.py`） |
| 並行分岐なのに `current_node` が 1 つしか無く、文本鎖と視覚鎖が交互に上報 → 前端が「実時間」を毎回別ノードに加算 | 累計が行ったり来たり | `running_nodes` 集合を持たせ、動いているノード**全部**にそれぞれの経過を加算 |
| 経過秒を `Date.now()` で引き算 | サーバと時計がずれると値が飛ぶ／負になる | `/api/runs/{id}` が `server_time` を返し、前端が毎回オフセットを取り直す |

さらに **「累計処理時間」を壁時計に変更**した。並行実行ではノード時間の総和が
壁時計を超えるうえ、どこまで数えたかで値が揺れる。総和は括弧内に併記して
「並行で短縮された分」が読めるようにしてある。表示値には単調増加の下限も掛けた。

### 2. Docling を通さない「視覚モデル直読」ルート（`workflow.input_mode`）

Docling は重い。図版主体・スキャン資料なら**ページを丸ごと VLM に読ませた方が
速くて質も良い**ので、ルートを二本立てにした。

```
text   … 従来どおり Docling 解析 → テキスト分岐が主役
vision … Docling を完全に飛ばし、全ページを画像化 → Agent 2 が主役
         （PDF テキスト層は pypdfium2 でタダで拾えるので補助に使う）
```

指定方法は 3 通り：投入カードのプルダウン（都度）／`config.yaml` の
`input_mode`（既定値）／`auto`（自動判定）。自動判定は **LLM を一切使わない
安価なプローブ**だけで決める（`app/route_decision.py`）：

- ページ数が `vision_route_max_pages`(30) 超 → 画像化が割高なので **text**
- 1 ページあたり文字数 < `vision_route_text_chars_per_page`(200) → **vision**
- 1 ページあたり画像数 ≥ `vision_route_images_per_page`(1.5) → **vision**

判定結果と理由は `route.json` に残り、結果画面にも出るので後から追える。
vision ルートでは Agent 2 のプロンプトが「図の説明」から**「ページの読み取り」**に
切り替わり、ページ画像の解像度上限も 1024 → 1536px に上がる（1024 では本文が潰れる）。
Office は LibreOffice 経由で PDF 化してから描画、LibreOffice が無ければ
埋め込み画像だけで続行する。

### 3. フォルダ一括処理（パス投入・履歴は分離）

左カラムに「フォルダ一括処理」カード。パスを入れて **下見**（対象件数の事前確認）→
**一括実行**。設計は既存部分と揃えてある：

- **原本には触らない**：inbox へコピーせず、その場で読む。run を削除しても
  利用者の元ファイルは消えない（削除対象は inbox 配下限定のまま）
- **ディスクが真源**：`out/batches/<batch_id>/batch.json` が実体。DB は使わない。
  再起動しても進捗を読み直せる
- **run_id をディスクの run ディレクトリ名と一致**させた（`<stem>_<内容ハッシュ>`）。
  アップロード経路が抱えていた「API の run_id とディレクトリ名が別物」問題を
  こちらでは最初から作らない
- **履歴は分離**：`/api/runs?scope=single`（既定）が一括処理分を除外するので、
  単発の実行履歴には混ざらない。一括分は専用カードから辿る

### 4. PDF / Word の書面エクスポート

要約 Markdown を単一の中間表現に落としてから PDF と Word の 2 つのレンダラへ流す
（`app/export_doc.py`）。体裁の定義は 1 か所なので両者の見た目がずれない。
見出しの罫線・箇条書き・表・ページ番号付きフッタ入り。

- PDF: **reportlab**（BSD-3-Clause）。日本語は ①システムの日本語 TrueType を埋め込む
  → ②無ければ Adobe 標準 CID フォント `HeiseiKakuGo-W5` に自動フォールバック。
  LibreOffice も wkhtmltopdf も要らない
- Word: **python-docx**（MIT）

ボタンの出る場所は要望どおり **「要約が完了してから」**：単一ファイルは結果画面の
ツールバー（社内/社外の切替に追随）、フォルダ一括処理は**配下の全件が終わってから**
バッチ画面に出る。一括分は索引ページ付きで 1 冊にまとまり、案件ごとに改ページする。

### 5. ピクセル風マルチ agent スクワッド

ロボット 1 体では多 agent 構成が伝わらなかったので、役割ごとに 1 体に分けた。
純 CSS/SVG のドット絵（11×13 のピクセルマップから `<rect>` を生成、外部リソース零）：

| | 役割 | 担当ノード | 大きさ |
|---|---|---|---|
| パーサー | 文書解析 | create_run_dir / parse_document / prepare_html_text | 小 |
| **Agent 1** | 証拠抽出 | chunk_text / extract / aggregate / gap_fill | 大 |
| **Agent 2** | 視覚分析 | collect_visual_assets / analyze_visual | 大 |
| **Agent 3** | 要約生成 | write_summary / validate / repair | 大 |
| 出力係 | 整形・出口 | render / redact_external / rag_export | 小 |

`running_nodes` を見るので、**並行分岐では Agent 1 と Agent 2 が同時に動く**
——並行実行していることが画面で分かる。ひとことは `status.json` の `peeks`
（ノード別に保持）から拾い、話者名を agent の色付きで表示する。

---

# v3.5 までの経緯

## v3.5：分支并行 / run 删除 / Office 图片提取根治

### 文本分支与视觉分支并行（`workflow.parallel_branches`，默认 true）

两条链没有依赖关系，改为 LangGraph 扇出/扇入拓扑：

```
parse -> prepare_html_text ┬─ chunk -> extract -> aggregate -> gap_fill ─┐
                           └─ collect_visual -> analyze_visual ──────────┴─> write_summary
```

实测（mock 计时，两分支都有负载）：顺序 4.17s → 并行 3.29s，**缩短 21%**，
产出完全一致。收益随视觉分支长度增长；视觉模型另起端点（`llm.vision`）时最大。

工程约束（改节点时务必遵守）：**分支内的节点只能返回自己写的 key**，返回整个
state 会与另一分支冲突（InvalidUpdateError）。视觉分支的错误写入 `errors_visual`，
在汇合节点 write_summary 并回 `errors`。扇入必须用列表源写法
`add_edge(["gap_fill", "analyze_visual"], "write_summary")`——分别 add_edge
两条是「任一触发」，会让汇合节点提前启动。`parallel_branches: false` 回到顺序模式便于调试。

### 実行履歴の削除

履歴项 hover 出现 ×，确认后删除 run 目录 + 台账记录 + 任务记录 + 上传文件。
磁盘是真源，因此必须删目录，否则重启会复活。顺带修了一个既存 bug：
API 的 run_id（上传 stem）与磁盘 run 目录名（含内容哈希）是两套 ID，
导致重启后履歴出现重复条目、台账删不干净——现已统一处理。

## v3.5：Office 图片提取根治

实测发现 v1 继承的 LibreOffice→HTML 抽图链路在新版 LibreOffice 上把图片
内联为 data: URI，旧代码将其当文件路径检查 → OSError → 被 try/except 吞成
「0 资产」——**PPT/Word/Excel 的图片一直在静默丢失**（与 PDF 曾经的问题同类）。

根治方案：PPTX/DOCX/XLSX 本质是 ZIP，`app/parsing.py::extract_office_visuals`
直接解包 `ppt/media/`、`word/media/`、`xl/media/` 取**原始分辨率原图**，
零 LibreOffice 依赖；EMF/WMF 矢量图尽力转 PNG。旧二进制格式（.ppt/.doc/.xls）
自动回落打过防崩补丁的 LibreOffice 链路（data: 位图可解码、矢量残片安全跳过）。

全本地部署的资料整理总结 agent 工作流：Docling 解析 → 证据提取（Agent 1）→
视觉分析（Agent 2）→ 结构化摘要（Agent 3）→ 校验/修复回路 → Markdown 渲染，
附带一个零依赖的 Web 交互界面。

## v1 → v2 的核心变化

| 问题（v1） | 解决（v2） |
|---|---|
| schema / YAML / Jinja 模板 / fill_missing_fields 四处手抄字段名，漂移导致 MD 全部渲染成「明記なし」 | **`app/contract.py` 唯一数据契约**：JSON Schema 由 Pydantic 自动生成，LLM 输出用契约解析，模板绑定契约字段；`verify_template()` 在启动时静态校验模板变量，漂移直接拒绝启动 |
| Jinja 默认 Undefined 静默吞掉不存在的变量 | `StrictUndefined`：引用不存在变量立即抛异常 |
| 校验只写日志，无论结果照常渲染 | **LangGraph 条件边**：校验失败 → LLM 修复节点 → 再校验（回路，次数可配置）；额度用尽仍出稿但 quality_report 保留完整失败记录 |
| chunk 证据原样全量塞给 Agent 3，易爆 context；confidence 采集了从不用 | **证据归并**（`app/evidence.py`）：NFKC 规范化去重 → 置信度过滤 → 每类别 top-N → 全局字符预算 |
| LLM 输出 JSON 全靠正则提取碰运气 | 优先用 llama.cpp 的 **json_schema 约束解码**（grammar 保证合法 JSON），不支持自动降级 |
| chunk 解析失败静默吞掉 | 失败记入 `state["errors"]` → `status.json` → Web UI 可见 |
| 40 chunk 串行调 LLM | 线程池并行（`extract_workers`，配合 llama.cpp `--parallel N`） |
| 「確認できず」/「明記なし」两套哨兵词混用 | 统一为 `contract.UNKNOWN` 一个常量 |
| 无测试 | 9 个测试：契约↔模板一致性回归、证据聚合、条件边路由、mock 端到端（含修复回路场景） |
| 只有 CLI | **FastAPI Web App**：上传 → 后台运行 → 节点级进度轮询 → 结果预览/下载，前端单文件、无 CDN、无 npm 构建 |

## v3.4：模板注册表 / 反馈飞轮 / 可靠性三件套 / 建站 agent

### 模板注册表（零代码扩展）
`templates/registry/<id>/`＝template.yaml＋output.md.j2 即一种新模板；字段定义
动态生成 Pydantic 契约——schema/校验/skeleton/RAG/台账/脱敏全部自动跟随，
"单一真源"对用户自定义模板同样成立。启动时双重校验（YAML 结构＋j2 变量），
坏模板拒绝启动。内置三种：**依頼対応事例**（既有）、**技術レポート**
（目的→手法→結果→結論）、**解析依頼一覧**（Excel 台帳型多案件，records 字段
每依頼一条记录）。自学教程：docs/TEMPLATE_GUIDE.md。

### 反馈飞轮（app/feedback.py）
① HITL 保存时自动 diff 机器稿 vs 人工稿，按字段路径入库——
/api/feedback/stats 给出高频修正字段排行（prompt 该修哪里一目了然）；
② UI「良い例に登録」把满意摘要收进示例库（按模板隔离）；
③ Agent 3 生成时自动携带同模板最近优质示例（few-shot 注入，空库零成本）。

### 可靠性三件套
- **持久化队列**：任务落 SQLite jobs 表，服务重启后 queued/running 自动重入队
- **版本历史**：每次渲染/每次 HITL 修订前快照进 versions/，UI 可回看下载
- **LangGraph SqliteSaver**（`checkpoint_enabled: true`，可选）：图内节点级
  断点，与文件缓存互补；**流式对话**：チャット改 SSE 逐 token 推送

### 前端功能开关（feature flags）

所有前端功能按"功能组"集中开关（联动的按钮/面板归同一组，如 tier_switch
同时管 社内/社外切换+社外下载+脱敏报告）。三层控制，代码只有一套：

1. 默认值：`app/config.py` 的 `DEFAULT_UI_FEATURES`（唯一定义处，加新功能在此注册）
2. 持久覆盖：`config.yaml` 的 `ui.features:`（重启生效；未注册的键被忽略，防拼写错误静默生效）
3. 运行时调试：页面头部 ⚙ 面板，勾选即时生效、刷新复位（不写任何配置）

前端消费方式统一：静态元素挂 `data-feature="组名"` 属性由 applyFeatures()
一次隐显；动态构建的区域（页签/按钮）调 `feat("组名")`。新增功能时：
DEFAULT_UI_FEATURES 注册一行 + 元素挂属性（或一处 feat() 判断）即完成接线。

### 対外紹介サイト agent（app/site_builder.py）
数据源**只有社外层**（社内数据物理隔离）；产物是**纯静态 HTML**（公开站点
零运行时 LLM、零攻击面）；LLM 仅在构建时写介绍与案例导语；落盘前全部页面
过 **NG 词出口泄漏闸**——命中任何原词立即中止构建。幂等重建＝追加新知识。
UI 左栏「サイト生成」→「プレビュー」，确认后把 out/site/ 拷到部门 Web 服务器即发布。

## v3.3：两级输出 / 案件台账 / RAG 出口（商业交付三件套）

### 社内完整版 / 社外脱敏版（`app/redaction.py`）

流水线末尾新增 `redact_external` 节点，一次运行同时产出两份：

- **规则层是权威**：`redaction/ng_words.yaml` 词典（客户名/内部代号/人名 +
  金额等正则）做确定性替换。同一客户全文映射同一别名（A社/B社…）保持可读；
  词典可在 Web UI 直接编辑（保存前 Pydantic 校验结构，坏词典 422 拒绝）
- **LLM 改写层可回退**：规则层漏掉的未登录识别信息交给 LLM 泛化改写；
  改写结果必须过 (a) 契约校验 (b) NG 词复扫——任何原词重现（LLM 幻觉复述）
  **自动回退纯规则版**。输出前再终扫一次，双保险
- 全程留痕 `redaction_report.json`（替换明细/别名映射/LLM 采用与回退原因）；
  脱敏失败绝不影响社内版产出
- UI：预览页签 社内版⇄社外版 切换，社外 MD/JSON/脱敏报告 下载

### 案件台账（`app/ledger.py`）

- SQLite（标准库，WAL 模式，线程安全）跨 run 索引；**磁盘是真源，DB 只是索引**
  ——DB 损坏/丢失时启动自动从 run 目录全量重建，台账永不成为单点
- Web UI 台账卡：全文检索（案件名/依頼元/効果…）、点击跳转对应 run
- **一键 Excel 台账**（openpyxl，MIT）：日文表头/冻结首行/自适应列宽，可直接提交
- **批量上传**（多选/多文件拖拽）+ **监视文件夹**（`watch_folder.enabled: true`
  后丢进 inbox_watch/ 即自动排队；两次扫描大小稳定才处理，防半截文件；
  处理后移入 processed/）——几百份存量资料的消化通道

### RAG 出口（`app/rag_export.py`）

每次运行落盘 embedding-ready JSONL（`rag_internal.jsonl` / `rag_external.jsonl`）：

- 三类记录：摘要章节（依頼内容/対応結果 拼成自然文）、文本证据（逐条+置信度）、
  视觉证据（摘要+关键事实，从文件名解析页码溯源）
- 每条含完整元数据：run_id / case_name / doc / type / category / confidence /
  page / tier / created_at——检索命中后可回溯到具体案件具体页
- **社外包只含脱敏摘要，永不携带原文证据**（证据是原文摘录无法保证脱敏）
- 导出：单 run（结果页 RAG 按钮）/ 全案件语料一键导出（台账卡，分社内/社外）

## v3.2：PDF 视觉修复、冷启动治理、机器人 UI

### 修复「PDF 图像资产为 0 / Agent 2 不工作」

根因：旧视觉链路（v1 传承）是 LibreOffice→HTML→抽图，而 **LibreOffice 对
PDF 转 HTML 基本产不出内容**（它是文档编辑器不是 PDF 渲染器），html 目录为空、
资产 0、Agent 2 无活可干。v3.2 起 PDF 走专用通道（`app/parsing.py::extract_pdf_visuals`，
pypdfium2，BSD/Apache 许可）：

1. **内嵌图片对象提取**：遍历每页 IMAGE 对象还原为 PNG（云图/照片/截图）
2. **整页渲染兜底**：文本字符数 < `pdf_render_min_text_chars` 的页视为图像型
   （扫描页/整页图表），整页渲染送 VLM——内嵌提取失败也不漏视觉信息
3. 文件名携带页码（`pdf_p003_img01.png`），天然页级溯源

Office 格式（PPT/Word/Excel）继续走 LibreOffice 链路（对它们有效）。
另新增两级降级：Docling 崩溃时 PDF 用 pypdfium2 文本层兜底；纯图片 PDF
（无文本层）不再报错死掉，文本通道置空、视觉通道独立完成任务。

### 「首次运行卡 20-30 分钟」冷启动治理

你观察到的现象（第一次极慢、第二次正常，RapidOCR onnx 模型加载）对应三个成因与对策：

1. **服务内预热（已实现）**：`warmup_on_start: true` 时 Web 服务启动即在后台线程
   实例化 Docling（触发全部模型加载），首个用户请求不再撞冷启动。
   `/api/health` 的 `docling` 字段显示 warming/ready
2. **模型预下载**：`docling-tools models download` 一次性拉全模型；
   离线环境设 `DOCLING_ARTIFACTS_PATH` 指向本地模型目录
3. **Windows 特有的两个坑**：
   - Defender 实时扫描大 onnx 文件——把 venv 的 site-packages 与模型缓存目录
     加入排除列表（`Add-MpPreference -ExclusionPath ...`），首载可从分钟级降到秒级
   - 你已知的 PATH 遍历撞断连网络驱动器问题——清理 PATH 里失效的网络路径
   数字原生 PDF 记得 `docling_ocr: false`，OCR 整个不加载

### 机器人 UI 与实时可视化

- **agent 小机器人**（纯 CSS/SVG，零依赖零外部资源）：工作时打字+摇摆+天线发光，
  完成时跳跃，排队/失败时睡眠。双开关：`config.yaml` 的 `ui.robot_animation`
  （总开关，false 前端不渲染）+ 页面头部复选框（临时开关）
- **气泡 peek**：各节点上报"正在看什么"（`「切削条件は…」を読みました（証拠 3 件）`、
  `画像『pdf_p003_img01.png』を見ました：圧力分布図`、
  `『期間、効果』の情報が見つからないので探し直します…`），
  peek 截断 120 字符，同时写入 events.jsonl 审计流
- **实时秒表**：运行中的节点每秒刷新已耗时（此前只能完成后显示）
- **VLM テスト按钮**：现场生成一张红色方块图发给视觉端点验证 mmproj 真的生效
  ——Ollama/llama-server 静默丢 mmproj 时文本 API 一切正常，只有实拍才能发现。
  模型答不出颜色会给出明确提示

### 性能限制放宽（基于你的实测数据）

extract_max_tokens 2048→3072、max_evidence_pack_chars 24000→32768、
gap_fill_context_chars 12000→16000。

## v2 → v3 的变化

### 性能（针对"十页 PDF 一小时"）

| 瓶颈（v2） | 优化（v3） |
|---|---|
| Docling 完整转换跑两次（markdown + json 各一次） | `convert_document_once`：一次转换导出两种格式，解析时间减半 |
| OCR 无条件开启 | `docling_ocr: false` 可关（数字原生 PDF 大幅提速；扫描件再开） |
| PDF/PPT 内嵌图片全部串行送 VLM，含图标/logo/重复母版图，且原尺寸 base64 | 预过滤（尺寸/字节阈值 + SHA1 去重）+ 降采样到 1024px + `vision_workers` 并行——视觉分析通常是 PDF 场景最大的时间黑洞 |
| 固定 6000 字符滑窗切块，块数多且脏 | 结构感知切块（按标题/页/节）+ 小节合并 + 信息量过滤：更少更干净的 chunk = 更少 LLM 调用 |
| `extract_workers: 1` 串行提取 | 默认 4 并行（llama-server 需加 `--parallel 4`） |
| 每次重跑全部重算 | 阶段级缓存（`resume: true`，按**内容哈希**）：同内容文件重跑时解析/证据/视觉分析秒过 |
| 证据提取 max_tokens=4096 | 2048 |
| 每节点耗时不可见 | status.json 记录每节点耗时 + 节点内 i/N 进度，Web UI 直接显示时间花在哪 |

### agent 逻辑

- **gap_fill 缺口回填节点**：聚合后检查关键类别（依頼元/期間/効果等）证据覆盖，
  有缺口时用文档头部做一次聚焦补提取（观察→发现缺口→针对性行动，单次调用、有界）
- 视觉模型可配置独立端点（`llm.vision`，例如 Qwen3-VL 起在 8081）

### Web 交互

- 节点级耗时 + 节点内进度（"証拠抽出 7/12"）+ 累计处理时间
- 四页签结果区：**プレビュー**（MD 渲染）/ **証拠**（分类·置信度·出典表格，人工核对）/
  **修訂 HITL**（直接编辑 JSON → 契约校验 → 重渲染，坏数据 422 拒绝）/
  **チャット**（针对该 run 的摘要+证据问答，本地 LLM 驱动）

### 运行速度自查

跑一次后看 Web UI 每个节点的耗时（或 `out/runs/*/status.json`）。经验分布：
- `parse_document` 慢 → 关 OCR / 确认 Docling 用上 GPU
- `analyze_visual` 慢 → 降低 `max_visual_assets`、确认预过滤生效（manifest 里有 raw→kept 统计）
- `extract_text_evidence` 慢 → 提高 `extract_workers` 并确认 llama-server `--parallel` 已开

## v3.1：性能回归的根因修复与工程化收尾

### 「v1 几分钟 / v2 一小时」的根因档案

对比 v1 与 v2 的 llm_client 可以确认：**v1 的 chat_json 是普通文本模式；
v2 每次调用都带 `response_format=json_schema`（grammar 约束解码）**。
llama.cpp 处理该模式时需要为每个请求编译 schema→GBNF 语法，解码时逐 token
做 logit 掩码，且语法约束下模型不产出完整 JSON 结构不能自然停止，容易烧满
max_tokens——agent1（每 chunk 一次）与 agent3（8192 上限）全部中招。
这与 LibreOffice / PyMuPDF 无关：v1/v2/v3 的视觉工具链完全相同
（LibreOffice + pypdfium2；PyMuPDF 是 AGPL，从一开始就被许可证策略排除）。

### 修复：adaptive 结构化输出（`llm.structured_output: adaptive`，新默认）

平时走 v1 的快速文本模式；仅当 JSON 解析失败时，才对**那一次调用**用
grammar 约束重试。合格率高的模型（Gemma 对简单 JSON 任务）几乎零 grammar
开销，坏输出仍有硬保证兜底。另有 `always`（v2 行为，调试用）/ `never`（v1 行为）。

### 其余 v3.1 变化

- **LLM 调用指标**：每次调用的耗时/模式/重试/prompt 与输出规模落
  `llm_metrics.jsonl`，按类别聚合进 `metrics.json`，Web UI 显示
  「LLM 呼出 × 回数 × 合計 × 平均 × grammar 使用」——"为什么慢"从猜变成看
- **prompt 瘦身**：证据包改紧凑 JSON（indent=2 放大 30-50% token）；
  prompt 内的完整 JSON Schema 换成契约自动生成的 skeleton（1519→410 字符）；
  提取 prompt 的类别列表由 EvidenceCategory 枚举生成（消灭最后一处手抄）
- **RunStore（app/observability.py）**：run 目录文件布局唯一定义处；
  事件流（status.json + events.jsonl）、指标、协作式取消、每 run 日志统一收口
- **运行队列**：`max_concurrent_runs`（默认 1）保护单 GPU，多文件上传自动排队
- **中断按钮**：协作式取消（进行中的单次 LLM 调用无法打断，返回后立即停止）
- **健康检查**：`/api/health` 探测 llama-server 连通性，UI 头部常驻指示灯
- FastAPI lifespan 替代已废弃的 on_event

### 运维注意（重要）

`llama-server --parallel N` 会把上下文窗口按 N **均分**给各槽位。
`extract_workers: 4` + `-c 32768 --parallel 4` 意味着每槽只有 8192 上下文，
agent3 的大 prompt 可能放不下。建议：`-c 65536 --parallel 4`（每槽 16k），
显存不够就 `--parallel 2` + `extract_workers: 2`。

## 目录结构

```
app/
  contract.py    # ★ 唯一数据契约（Pydantic）——一切字段名的真源
  route_decision.py # v3.6：解析ルート判定（Docling / 視覚直読）— LLM 不使用のプローブ
  excel_extract.py  # v3.7：Excel 直読（計算結果 / グラフ numCache / 構造注記）
  batch.py       # v3.6：フォルダ一括処理（ディスクが真源、原本は非コピー）
  export_doc.py  # v3.6：PDF(reportlab) / Word(python-docx) 書面エクスポート
  parsing.py     # v3：单次 Docling 转换 / 结构切块 / 图片预过滤降采样
  observability.py # v3.1：RunStore——事件流/LLM 指标/取消/日志 统一收口
  config.py      # 类型化配置
  llm_client.py  # llama.cpp 客户端：约束解码/重试/降级/mock
  evidence.py    # 证据去重、聚合、预算
  nodes.py       # LangGraph 节点（错误追踪、并行提取）
  graph.py       # 图拓扑 + 校验→修复条件边
  render.py      # StrictUndefined 渲染 + 模板静态校验
  webapp.py      # FastAPI 交互层
tools/           # v1 原样复用（Docling / Excel COM / 视觉资产提取）
templates/       # case_summary_v2.md.j2（绑定契约字段）
static/          # index.html（单文件前端）
tests/           # pytest 套件（无需 GPU / Docling 即可运行）
run_cli.py       # CLI 入口
```

## 使用

```bash
pip install -r requirements.txt

# Web 界面（推荐）
uvicorn app.webapp:app --host 0.0.0.0 --port 8000
# 浏览器打开 http://localhost:8000

# CLI 批处理
python run_cli.py inbox/xxx.pptx

# 测试（无需 llama.cpp / GPU）
python -m pytest tests/ -v
```

llama.cpp server 侧建议启动参数（配合 extract_workers > 1）：

```bash
llama-server -m gemma-4-26b.gguf --port 8080 --parallel 4 -c 32768
```

## 许可证合规

requirements.txt 内逐条标注，全部为 MIT / Apache-2.0 / BSD：
langgraph、langchain-core、pydantic、fastapi、uvicorn、python-multipart、
openai（仅作本地兼容客户端）、jinja2、PyYAML、docling、beautifulsoup4、pypdfium2。
无 GPL/AGPL，无商用限制条款；前端零外部资源（无 CDN 字体/JS）。

## 修改模板 / 新增字段的正确姿势

1. 在 `app/contract.py` 的 `CaseSummary` 加字段（带默认值）
2. 在 `templates/case_summary_v2.md.j2` 引用它
3. `python -m pytest tests/ -v` —— 契约↔模板一致性测试会替你把关

schema、校验、修复 prompt 里的 schema 全部自动跟随契约，不需要手改。
