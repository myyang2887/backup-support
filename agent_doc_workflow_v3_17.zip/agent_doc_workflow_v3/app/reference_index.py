"""
参照台帳（v3.14）— 年度別の依頼一覧 Excel から、報告書ファイル名に対応する
行を引き当てるための索引。

## なぜ要るのか

要約に出てくる「資料内で確認できず」の多くは、**モデルの読み取り不足ではなく、
アップロードされた報告書そのものにその情報が書かれていない**ことが原因。
依頼番号・依頼日・依頼者・依頼目的といったメタ情報は、報告書ではなく
年度別の管理台帳の側に記録されている。

その台帳には報告書ファイルの保存パスが載っているので、
**ファイル名を鍵にすれば残りの列を引ける**。

## なぜ LLM に読ませないのか

台帳は数千行になりうる。丸ごと文脈に載せるのは高価だが、理由はそれだけではない。
**この照合には判断の余地が無い**——ファイル名で行を引くのは決定論的な join であって、
賢さを必要としない。同じ入力からは常に同じ行が返るべきで、モデルを挟むと
その保証が消える（同じ run を二度回して違う行が出るようでは追跡できない）。

なのでここは純粋なコード。モデルは引いてきた行を「証拠」として受け取るだけで、
検索そのものには関与しない。

## 何を返すか

`match()` は「どの行か」だけでなく **「どうやって当てたか」と「どれくらい確からしいか」**
を返す。照合を誤ると他人の依頼者や依頼日を自信満々に要約へ書き込むことになり、
「確認できず」よりよほど悪い。だから根拠を必ず持ち回る。
"""
from __future__ import annotations

import hashlib
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

from .config import PROJECT_ROOT

# ---------------------------------------------------------------------------
# 照合の段階と確からしさ
# ---------------------------------------------------------------------------
#
# 数値そのものより「どの段で当たったか」が重要なので、段ごとに名前を付けておく。
# UI とレポートにはこの名前を出す。
MATCH_EXACT_NAME = "exact_filename"        # ファイル名が完全一致
MATCH_NORMALIZED = "normalized_filename"   # 正規化して一致（全角/版番号/連番を吸収）
MATCH_REQUEST_NO = "request_number"        # ファイル名から依頼番号を抽出して一致
MATCH_PATH_SUFFIX = "path_suffix"          # 台帳のパスが入力の相対パスで終わる
MATCH_TITLE_FUZZY = "title_fuzzy"          # どこかの列と部分一致（既定では採用しない）

_CONFIDENCE = {
    MATCH_EXACT_NAME:  1.00,
    MATCH_NORMALIZED:  0.95,
    MATCH_REQUEST_NO:  0.95,
    MATCH_PATH_SUFFIX: 0.88,
    MATCH_TITLE_FUZZY: 0.65,
}

#: これ以上なら「確定」として扱い、注記を付けない
CONFIRMED_THRESHOLD = 0.95

#: ファイル名に紛れ込む版番号・連番・コピー痕。正規化時に落とす。
_NOISE_PATTERNS = [
    r"[_\-\s]*(?:ver?|version|rev)[_\-\.\s]*\d+(?:[_\-\.]\d+)*",
    r"[_\-\s]*v\d+(?:[_\-\.]\d+)*",
    r"[_\-\s]*\(\d+\)",
    r"[_\-\s]*(?:コピー|copy|最終|最新|完成|確定|修正済?|旧|新)",
    r"[_\-\s]*\d{8}",          # 末尾の日付
    r"[_\-\s]*(?:提出用|社内用|配布用|案)",
]

#: 依頼番号らしき並び。年度＋連番、または連番のみ。
#
# \b は使えない：アンダースコアも単語文字なので "2026-0034_別名.pptx" の
# "0034" と "_" の間には境界が立たず、最も普通の命名規則を取り逃がす。
# 前後を明示的な否定先読み／後読みで囲む。
_REQUEST_NO_PATTERNS = [
    re.compile(r"(?<![0-9A-Za-z])(\d{4}[-_]\d{3,6})(?![0-9])"),
    re.compile(r"(?<![0-9A-Za-z])(R\d{1,2}[-_]\d{3,6})(?![0-9])", re.I),  # 令和年度表記
    re.compile(r"(?<![0-9A-Za-z])([A-Z]{1,4}[-_]?\d{4,8})(?![0-9])", re.I),
]


def normalize_text(value: Any) -> str:
    """全角/半角・大小文字・空白の揺れを吸収する。

    日本語のファイル名と台帳のセルは、同じ物を指していても
    全角英数と半角、スペースとアンダースコアが平気で混ざる。
    """
    if value is None:
        return ""
    text = unicodedata.normalize("NFKC", str(value)).strip().lower()
    return re.sub(r"[\s　]+", " ", text)


def normalize_filename(name: str) -> str:
    """ファイル名から拡張子・版番号・連番などの雑音を落として比較用の形にする。"""
    stem = Path(str(name)).stem
    text = normalize_text(stem)
    for pat in _NOISE_PATTERNS:
        text = re.sub(pat, "", text, flags=re.I)
    return re.sub(r"[_\-\s]+", "", text).strip()


def extract_request_no(text: str) -> str:
    """ファイル名や表題から依頼番号らしき並びを取り出す。"""
    raw = unicodedata.normalize("NFKC", str(text or ""))
    for pat in _REQUEST_NO_PATTERNS:
        m = pat.search(raw)
        if m:
            return m.group(1).replace("_", "-").upper()
    return ""


# ---------------------------------------------------------------------------
# 列マッピング（YAML で拡張する）
# ---------------------------------------------------------------------------

@dataclass
class ReferenceSpec:
    """台帳の読み取りに対する **任意の** 微調整（v3.15 で縮小）。

    v3.14 では列名の語彙表を持ち、そこに載っている列だけを拾っていた。
    これは二重に誤りだった：

      1. 載っていない列（「使用ソフト」「特記事項」など）が黙って消える。
         人が手で埋めた情報を、こちらの都合で無かったことにしていた。
      2. 「起案部門」が依頼者を指すかどうかは **語彙ではなく意味の問題**。
         コードが表で決めることではなく、モデルが判断すべきこと。

    今は構造（表頭の行・照合鍵の列）を **値の形** から検出し、
    列の意味付けは一切しない。ここに残っているのは、自動検出が外れたときに
    人が上書きするための逃げ道だけ。**普通は何も書かなくてよい。**
    """
    id: str = "default"
    name: str = "自動検出"
    description: str = ""
    #: 表頭の行を固定したい場合のみ（0 始まり）。None なら自動検出。
    header_row: Optional[int] = None


_DEFAULT_SPEC = ReferenceSpec(
    id="default",
    name="自動検出（表頭の語彙に依存しない）",
    description="表頭の行と照合鍵の列を値の形から検出し、全列を生の表頭のまま保持します",
)


def load_reference_specs(root: Optional[Path] = None) -> Dict[str, ReferenceSpec]:
    """`references/registry/<id>/reference.yaml` を読む。

    v3.15 以降、ここに置けるのは header_row の上書きくらいで、
    列名の語彙は不要になった。ファイルが 1 つも無いのが普通の状態。
    """
    specs = {"default": _DEFAULT_SPEC}
    base = Path(root) if root else (PROJECT_ROOT / "references" / "registry")
    if not base.is_dir():
        return specs
    for entry in sorted(base.iterdir()):
        cfg = entry / "reference.yaml"
        if not (entry.is_dir() and cfg.is_file()):
            continue
        try:
            data = yaml.safe_load(cfg.read_text(encoding="utf-8")) or {}
            spec = ReferenceSpec(
                id=str(data.get("id") or entry.name),
                name=str(data.get("name") or entry.name),
                description=str(data.get("description") or ""),
                header_row=data.get("header_row"),
            )
            specs[spec.id] = spec
        except Exception:  # noqa: BLE001 壊れた 1 件で全体を止めない
            continue
    return specs


# ---------------------------------------------------------------------------
# 索引
# ---------------------------------------------------------------------------

@dataclass
class ReferenceRow:
    """台帳の 1 行。**全列を生の表頭のまま持つ。**

    v3.15 で「論理名に翻訳して持つ」のを止めた。語彙表に載っている列だけを
    拾う作りだと、「使用ソフト」「特記事項」「予算コード」のような
    載っていない列が黙って消える——人が手で埋めた情報を、こちらの都合で
    無かったことにしていた。

    表頭が何を意味するか（「起案部門」は依頼者か？）は語彙の問題ではなく
    意味の問題なので、コードでは決めない。生の表頭ごとモデルへ渡す。
    """
    source_file: str
    sheet_name: str
    row_number: int                                  # 1 始まり（Excel の行番号）
    cells: List[Tuple[str, str]] = field(default_factory=list)  # (表頭, 値) を列順で

    @property
    def values(self) -> Dict[str, str]:
        """表頭 -> 値。表頭が重複していれば後ろに #2 を付けて区別する。"""
        out: Dict[str, str] = {}
        for head, val in self.cells:
            key = head or "(無題列)"
            if key in out:
                i = 2
                while f"{key}#{i}" in out:
                    i += 1
                key = f"{key}#{i}"
            out[key] = val
        return out

    def nonempty(self) -> List[Tuple[str, str]]:
        return [(h, v) for h, v in self.cells if str(v).strip()]

    def to_dict(self) -> Dict[str, Any]:
        return {"source_file": self.source_file, "sheet_name": self.sheet_name,
                "row_number": self.row_number, "values": self.values}


@dataclass
class MatchResult:
    ok: bool = False
    row: Optional[ReferenceRow] = None
    method: str = ""
    confidence: float = 0.0
    #: 照合が当たった列の表頭。証拠から除く（＝検索の鍵そのものなので要約に不要）
    matched_header: str = ""
    #: 同じ段で複数当たった場合の候補（採用はしない）
    candidates: List[ReferenceRow] = field(default_factory=list)
    reason: str = ""

    @property
    def confirmed(self) -> bool:
        """注記なしで確定扱いしてよいか。"""
        return self.ok and self.confidence >= CONFIRMED_THRESHOLD

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok, "method": self.method, "confidence": round(self.confidence, 3),
            "matched_header": self.matched_header,
            "confirmed": self.confirmed, "reason": self.reason,
            "row": self.row.to_dict() if self.row else None,
            "candidates": [c.to_dict() for c in self.candidates],
        }


#: 日付そのもの。番号判定から除外する。
_LOOKS_LIKE_DATE = re.compile(r"^\d{4}[/\-年]\d{1,2}[/\-月]\d{1,2}日?$")

#: 索引に入れる値の最小長。短すぎる値（部署コード「QA」等）は誤爆の元。
_MIN_KEY_LEN = 6

#: 構造検出のために読む最大行数
_STRUCTURE_SCAN_ROWS = 60


def _detect_header_row(rows: List[List[Any]], scan_rows: int = 12) -> int:
    """表頭の行番号（0 始まり）を推定する。表頭の語彙は使わない。

    台帳の 1 行目はタイトル行であることが多い。
    「短い文字列が、隙間なく、横に並んでいる」行を表頭とみなす。
    """
    best_idx, best_score = 0, -1.0
    for i, row in enumerate(rows[:scan_rows]):
        if not row:
            continue
        cells = [c for c in row if c is not None and str(c).strip()]
        if len(cells) < 2:
            continue
        texts = [str(c).strip() for c in cells]
        short = sum(1 for t in texts if len(t) <= 24) / len(texts)
        nonnum = sum(1 for t in texts
                     if not re.fullmatch(r"[-+]?\d[\d,\.]*", t)
                     and not _LOOKS_LIKE_DATE.match(unicodedata.normalize("NFKC", t))) / len(texts)
        density = len(cells) / max(1, len(row))
        score = short * 0.3 + nonnum * 0.4 + density * 0.3
        if score > best_score + 1e-9:
            best_idx, best_score = i, score
    return best_idx


@dataclass
class ReferenceRow:
    """台帳の 1 行。**全列を生の表頭のまま持つ。**

    v3.15 で「論理名に翻訳して持つ」のを止めた。語彙表に載っている列だけを
    拾う作りだと、「使用ソフト」「特記事項」「予算コード」のような
    載っていない列が黙って消える——人が手で埋めた情報を、こちらの都合で
    無かったことにしていた。

    表頭が何を意味するか（「起案部門」は依頼者か？）は語彙の問題ではなく
    意味の問題なので、コードでは決めない。生の表頭ごとモデルへ渡す。
    """
    source_file: str
    sheet_name: str
    row_number: int                                  # 1 始まり（Excel の行番号）
    cells: List[Tuple[str, str]] = field(default_factory=list)  # (表頭, 値) を列順で

    @property
    def values(self) -> Dict[str, str]:
        """表頭 -> 値。表頭が重複していれば後ろに #2 を付けて区別する。"""
        out: Dict[str, str] = {}
        for head, val in self.cells:
            key = head or "(無題列)"
            if key in out:
                i = 2
                while f"{key}#{i}" in out:
                    i += 1
                key = f"{key}#{i}"
            out[key] = val
        return out

    def nonempty(self) -> List[Tuple[str, str]]:
        return [(h, v) for h, v in self.cells if str(v).strip()]

    def to_dict(self) -> Dict[str, Any]:
        return {"source_file": self.source_file, "sheet_name": self.sheet_name,
                "row_number": self.row_number, "values": self.values}


@dataclass
class MatchResult:
    ok: bool = False
    row: Optional[ReferenceRow] = None
    method: str = ""
    confidence: float = 0.0
    #: 照合が当たった列の表頭。証拠から除く（＝検索の鍵そのものなので要約に不要）
    matched_header: str = ""
    #: 同じ段で複数当たった場合の候補（採用はしない）
    candidates: List[ReferenceRow] = field(default_factory=list)
    reason: str = ""

    @property
    def confirmed(self) -> bool:
        """注記なしで確定扱いしてよいか。"""
        return self.ok and self.confidence >= CONFIRMED_THRESHOLD

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok, "method": self.method, "confidence": round(self.confidence, 3),
            "matched_header": self.matched_header,
            "confirmed": self.confirmed, "reason": self.reason,
            "row": self.row.to_dict() if self.row else None,
            "candidates": [c.to_dict() for c in self.candidates],
        }


# v3.16：拡張子の**列挙**を止めた。
#
# v3.15 は .pptx/.docx/.xlsx/.pdf… と並べていたが、それは表頭の語彙表を
# 拡張子の語彙表に置き換えただけで、脆さの質は同じだった。実際 .xlsm
#（マクロ有 Excel）や .pptm、拡張子を持たないフォルダパスを取り逃がしていた。
#
# 形だけを見る：
#   - 「点 + 英字始まりの 2〜5 文字」で終わる → 何であれ拡張子
#   - 区切り記号を含む → パス
# 日付（2026/06/30）は区切り記号を持つので明示的に除く。
class ReferenceIndex:
    """複数の台帳 Excel をまとめた検索索引。

    索引は「正規化キー -> 行のリスト」の辞書がいくつか。数千行でも一瞬で引ける。
    行の実体は 1 度しか持たない（各索引は参照を指すだけ）。
    """

    def __init__(self, spec: Optional[ReferenceSpec] = None):
        self.spec = spec or _DEFAULT_SPEC
        self.rows: List[ReferenceRow] = []
        self.by_exact: Dict[str, List[ReferenceRow]] = {}
        self.by_normalized: Dict[str, List[ReferenceRow]] = {}
        self.by_request_no: Dict[str, List[ReferenceRow]] = {}
        self.by_path_tail: Dict[str, List[ReferenceRow]] = {}
        self.sources: List[Dict[str, Any]] = []
        self.errors: List[Dict[str, str]] = []

    # -- 構築 ------------------------------------------------------------
    def add_workbook(self, xlsx_path: str) -> Dict[str, Any]:
        """台帳 Excel を 1 冊読み込む。**表頭の語彙には依存しない。**"""
        try:
            import openpyxl
        except ImportError:
            self.errors.append({"file": xlsx_path, "error": "openpyxl が導入されていません"})
            return {"ok": False, "rows": 0}

        path = Path(xlsx_path)
        info: Dict[str, Any] = {"file": str(path), "name": path.name,
                                "sheets": [], "rows": 0}
        try:
            wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
        except Exception as e:  # noqa: BLE001 1 冊壊れても他は使う
            self.errors.append({"file": str(path), "error": f"{type(e).__name__}: {e}"})
            return {"ok": False, "rows": 0}

        added = 0
        for ws in wb.worksheets:
            if getattr(ws, "sheet_state", "visible") != "visible":
                continue

            all_rows = [list(r) for r in ws.iter_rows(values_only=True)]
            if not all_rows:
                continue

            hdr_idx = (self.spec.header_row if self.spec and self.spec.header_row is not None
                       else _detect_header_row(all_rows))
            header_cells = all_rows[hdr_idx] if hdr_idx < len(all_rows) else []
            headers = [("" if c is None else str(c).strip()) for c in header_cells]
            data_rows = [r for r in all_rows[hdr_idx + 1:]
                         if r and any(c is not None and str(c).strip() for c in r)]
            if not headers or not data_rows:
                info["sheets"].append({"name": ws.title, "rows": 0,
                                       "note": "データ行が見つかりませんでした"})
                continue

            sheet_rows = 0
            for offset, row in enumerate(data_rows):
                cells: List[Tuple[str, str]] = []
                for c, head in enumerate(headers):
                    v = row[c] if c < len(row) else None
                    cells.append((head, "" if v is None else str(v).strip()))
                if not any(v for _, v in cells):
                    continue
                rr = ReferenceRow(source_file=str(path), sheet_name=ws.title,
                                  row_number=hdr_idx + 2 + offset, cells=cells)
                self._index_row(rr)
                sheet_rows += 1
                added += 1

            info["sheets"].append({
                "name": ws.title, "rows": sheet_rows, "header_row": hdr_idx + 1,
                "headers": headers,
            })
        try:
            wb.close()
        except Exception:  # noqa: BLE001
            pass

        info["rows"] = added
        info["ok"] = added > 0
        self.sources.append(info)
        return info

    def _index_row(self, rr: ReferenceRow) -> None:
        """行の **全セル** を索引に入れる。

        v3.17：列の役割判定をやめた。Excel で Ctrl+F するとき、
        人は「どの列を探すか」を決めてから探したりしない——全体を探して
        当たったセルの行を読む。それと同じにする。

        ファイル名は拡張子付きで十分に独特なので、どの列に入っていようと
        当たれば同じ行を指す。役割を先に決める必要がそもそも無かった。
        部署名や状態の列も索引に入るが、ファイル名の問い合わせとは
        一致しないので無害。
        """
        self.rows.append(rr)

        for _, raw in rr.cells:
            if not raw:
                continue
            val = str(raw).replace("\\", "/")

            # セルの値そのもの／その末尾のファイル名で引けるようにする
            name = Path(val).name if ("/" in val) else val
            for key in {normalize_text(val), normalize_text(name)}:
                if key and len(key) >= _MIN_KEY_LEN:
                    self.by_exact.setdefault(key, []).append(rr)
            for key in {normalize_filename(val), normalize_filename(name)}:
                if key and len(key) >= _MIN_KEY_LEN:
                    self.by_normalized.setdefault(key, []).append(rr)

            # パス全体（末尾一致の照合用）
            if "/" in val:
                tail = normalize_text(val)
                if tail:
                    self.by_path_tail.setdefault(tail, []).append(rr)

            # 依頼番号らしき並びはどの列にあっても拾う
            no = extract_request_no(val)
            if no and not _LOOKS_LIKE_DATE.match(val.strip()):
                self.by_request_no.setdefault(
                    normalize_text(no).replace("_", "-"), []).append(rr)

    # -- 照合 ------------------------------------------------------------
    def match(self, input_path: str, *, allow_fuzzy: bool = False) -> MatchResult:
        """入力ファイルに対応する行を引く。**Excel の Ctrl+F と同じ考え方。**

        v3.17：列の役割を先に決めるのをやめた。人が台帳から報告書を探すとき、
        「どの列が保存パス列か」を判定してから探すことはない。全体を検索して、
        当たったセルの行を読む。ファイル名は拡張子付きで十分に独特なので、
        それで足りる。

        段は「どこを探すか」ではなく「どこまで崩して探すか」で分ける：

          1. ファイル名そのもの
          2. 版番号・連番・全角を落としたファイル名
          3. ファイル名から抽出した依頼番号
          4. パスの末尾一致
          5. 部分一致（既定では採用しない）

        最初に当たった段で打ち切る。同じ段で 2 行以上当たったら採用しない
        ——これは確度が低いのではなく「どちらか分からない」状態で、
        一方を選ぶのはコイン投げでしかない。
        """
        p = Path(input_path)
        fname = p.name

        # 段 1：ファイル名そのもの
        r = self._decide(self.by_exact.get(normalize_text(fname), []),
                         MATCH_EXACT_NAME, f"ファイル名『{fname}』が一致", fname)
        if r.ok or r.candidates:
            return r

        # 段 2：版番号・連番・全角の揺れを落として一致
        nk = normalize_filename(fname)
        if nk and len(nk) >= _MIN_KEY_LEN:
            r = self._decide(self.by_normalized.get(nk, []), MATCH_NORMALIZED,
                             f"版番号等を除いた『{nk}』が一致", fname)
            if r.ok or r.candidates:
                return r

        # 段 3：ファイル名から依頼番号を抽出
        no = extract_request_no(fname)
        if no:
            r = self._decide(
                self.by_request_no.get(normalize_text(no).replace("_", "-"), []),
                MATCH_REQUEST_NO, f"ファイル名の依頼番号『{no}』が一致", fname)
            if r.ok or r.candidates:
                return r

        # 段 4：台帳のパスが入力の相対パスで終わる（フォルダ一括処理向け）
        tail_key = normalize_text(str(p).replace("\\", "/"))
        hits = [rr for key, rows in self.by_path_tail.items()
                if key and (tail_key.endswith(key) or key.endswith(tail_key))
                for rr in rows]
        if hits:
            r = self._decide(hits, MATCH_PATH_SUFFIX, "保存パスの末尾が一致", fname)
            if r.ok or r.candidates:
                return r

        # 段 5：どこかのセルに主要部が含まれるか。既定では採用しない。
        if allow_fuzzy and len(nk) >= _MIN_KEY_LEN:
            fuzzy = []
            for rr in self.rows:
                for _, v in rr.nonempty():
                    nv = normalize_filename(v)
                    if nv and len(nv) >= _MIN_KEY_LEN and (nk in nv or nv in nk):
                        fuzzy.append(rr)
                        break
            r = self._decide(fuzzy, MATCH_TITLE_FUZZY, "いずれかのセルと部分一致（要確認）", fname)
            if r.ok or r.candidates:
                return r

        return MatchResult(ok=False, reason="台帳に該当する行が見つかりませんでした")

    @staticmethod
    def _decide(hits: List[ReferenceRow], method: str, reason: str,
                query: str = "") -> MatchResult:
        if not hits:
            return MatchResult(ok=False)
        uniq: List[ReferenceRow] = []
        seen = set()
        for rr in hits:
            key = (rr.source_file, rr.sheet_name, rr.row_number)
            if key not in seen:
                seen.add(key)
                uniq.append(rr)
        if len(uniq) == 1:
            row = uniq[0]
            # どの列で当たったかを控えておく。その列の値は検索の鍵そのものなので
            # 要約の証拠には要らない（保存パスを要約に書いても仕方がない）。
            head = ""
            qn = normalize_filename(query)
            for h, v in row.nonempty():
                vn = normalize_filename(Path(str(v).replace("\\", "/")).name)
                if qn and vn and (vn == qn or qn in normalize_text(v)):
                    head = h
                    break
            return MatchResult(ok=True, row=row, method=method, matched_header=head,
                               confidence=_CONFIDENCE.get(method, 0.5), reason=reason)
        # 同じ段で複数 = どちらか分からない。採用しない。
        return MatchResult(
            ok=False, method=method, confidence=0.0, candidates=uniq[:8],
            reason=(f"{reason} が {len(uniq)} 行に該当したため確定できません"
                    f"（どれか一つを選べる根拠が無いため採用しません）"))

    # -- 補助 ------------------------------------------------------------
    def stats(self) -> Dict[str, Any]:
        return {"rows": len(self.rows), "files": len(self.sources),
                "sources": self.sources, "errors": self.errors,
                "spec_id": self.spec.id}


# ---------------------------------------------------------------------------
# 索引のキャッシュ
# ---------------------------------------------------------------------------
#
# 一括処理で 100 件回すたびに数千行の Excel を読み直すのは無駄なので、
# ファイルの mtime+size を鍵にして使い回す。台帳が差し替わればキーが変わる。

_CACHE: Dict[str, ReferenceIndex] = {}


def _cache_key(paths: List[str], spec_id: str) -> str:
    parts = [spec_id]
    for p in sorted(paths):
        try:
            st = Path(p).stat()
            parts.append(f"{p}:{st.st_mtime_ns}:{st.st_size}")
        except OSError:
            parts.append(f"{p}:missing")
    return hashlib.sha1("|".join(parts).encode("utf-8")).hexdigest()


def collect_reference_files(paths: List[str]) -> List[str]:
    """ファイルとフォルダの混在を、Excel ファイルの一覧に均す。"""
    out: List[str] = []
    for raw in paths:
        if not raw:
            continue
        p = Path(raw)
        if p.is_dir():
            for ext in ("*.xlsx", "*.xlsm"):
                out.extend(str(x) for x in sorted(p.rglob(ext))
                           if not x.name.startswith("~$"))
        elif p.is_file() and p.suffix.lower() in (".xlsx", ".xlsm"):
            out.append(str(p))
    # 重複除去（順序は保つ）
    seen, uniq = set(), []
    for p in out:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    return uniq


def build_index(paths: List[str], spec: Optional[ReferenceSpec] = None,
                use_cache: bool = True) -> ReferenceIndex:
    """台帳ファイル群から索引を作る（キャッシュあり）。"""
    spec = spec or _DEFAULT_SPEC
    files = collect_reference_files(paths)
    key = _cache_key(files, spec.id)
    if use_cache and key in _CACHE:
        return _CACHE[key]

    idx = ReferenceIndex(spec)
    for f in files:
        idx.add_workbook(f)
    if use_cache:
        _CACHE[key] = idx
    return idx


def clear_cache() -> None:
    _CACHE.clear()
