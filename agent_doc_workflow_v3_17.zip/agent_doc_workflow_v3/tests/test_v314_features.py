"""v3.14：参照台帳（年度別の依頼一覧 Excel）。

決定事項（利用者の選択）：
  1A … 要約前に証拠として注入し、要約後はコードのみで食い違いを検出する
  2B … 確度が低くても最良の 1 行を採用し「要確認」と注記する
        ただし **同点（どれか分からない）は採用しない**——これは確度の低さ
        ではなくコイン投げなので、候補提示に留める
  3C … 常駐ライブラリを主とし、run 単位の追加指定も許す
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

openpyxl = pytest.importorskip("openpyxl")


# ======================================================================
# 台帳の作成ヘルパ
# ======================================================================

def _make_ledger(path: Path, rows, *, title_row=True, headers=None):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "2026年度"
    if title_row:
        ws.append(["2026年度 解析依頼一覧"])   # 表頭ではないタイトル行
    ws.append(headers or ["依頼番号", "依頼日", "タイトル", "依頼理由",
                          "依頼内容", "依頼者", "依頼目的", "報告書パス"])
    for r in rows:
        ws.append(r)
    wb.save(path)
    return path


@pytest.fixture()
def ledger(tmp_path):
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "2026年度_依頼一覧.xlsx", [
        ["2026-0012", "2026/04/10", "配管圧損の低減検討", "歩留り低下が続いたため",
         "形状A/BのCFD比較", "製造技術部 山田太郎", "圧損20%低減の可否判断",
         r"\\srv\解析\2026\2026-0012_配管圧損_報告書.pptx"],
        ["2026-0034", "2026/05/22", "筐体放熱評価", "客先要求", "熱流体解析",
         "設計二課 佐藤", "温度上限の確認",
         r"\\srv\解析\2026\2026-0034_筐体放熱_報告書.pptx"],
    ])
    return build_index([str(p)])


# ======================================================================
# 1. 表の読み取り
# ======================================================================

def test_header_row_autodetected_below_title_row(ledger):
    """1 行目がタイトル行の台帳が実務では普通。表頭を自動で探す。

    v3.17：表頭の語彙にも列の役割判定にも依存しない。表頭の行だけを推定する。
    """
    sheet = ledger.stats()["sources"][0]["sheets"][0]
    assert sheet["header_row"] == 2
    # 表頭は全部そのまま持つ（v3.17：列の役割判定は行わない）
    assert "依頼者" in sheet["headers"]
    assert "報告書パス" in sheet["headers"]


def test_rows_loaded(ledger):
    assert ledger.stats()["rows"] == 2


def test_broken_workbook_does_not_raise(tmp_path):
    """1 冊壊れていても他の台帳は使えること。"""
    from app.reference_index import ReferenceIndex

    bad = tmp_path / "broken.xlsx"
    bad.write_bytes(b"not an excel file")
    idx = ReferenceIndex()
    res = idx.add_workbook(str(bad))
    assert res["ok"] is False
    assert idx.errors


# ======================================================================
# 2. 照合（段階と確からしさ）
# ======================================================================

@pytest.mark.parametrize("filename,method", [
    ("2026-0012_配管圧損_報告書.pptx", "exact_filename"),
    ("2026-0012_配管圧損_報告書_ver2.pptx", "normalized_filename"),
    ("2026-0012_配管圧損_報告書(1).pptx", "normalized_filename"),
    ("2026-0034_別名で保存した報告.pptx", "request_number"),
])
def test_match_methods(ledger, filename, method):
    m = ledger.match(filename)
    assert m.ok, f"{filename} が照合できていない"
    assert m.method == method


def test_fullwidth_digits_absorbed(ledger):
    """日本語のファイル名は全角英数が平気で混ざる。"""
    m = ledger.match("２０２６-0034_筐体放熱_報告書.pptx")
    assert m.ok
    assert m.row.values["依頼者"] == "設計二課 佐藤"


def test_no_match_returns_cleanly(ledger):
    m = ledger.match("まったく無関係な資料.pptx")
    assert m.ok is False
    assert m.row is None
    assert not m.candidates


def test_request_number_regex_does_not_eat_plain_dates():
    """\\b は使えない（アンダースコアも単語文字）。日付を番号と誤認しないこと。"""
    from app.reference_index import extract_request_no

    assert extract_request_no("2026-0034_別名.pptx") == "2026-0034"
    assert extract_request_no("R07-0123_報告.pptx") == "R07-0123"
    assert extract_request_no("20260401_日報.pptx") == ""
    assert extract_request_no("報告書.pptx") == ""


# ======================================================================
# 3. 曖昧なときは採用しない（2B の境界）
# ======================================================================

def test_ambiguous_match_is_refused_not_guessed(tmp_path):
    """同名の報告書が別案件に二つ——部署別フォルダでは普通に起きる。

    「確度が低い」のではなく「どちらか分からない」。一方を選ぶのは
    コイン投げで、外すと他人の依頼者・依頼日を自信満々に要約へ書き込む。
    確認できずより悪いので、候補提示に留める。
    """
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "台帳.xlsx", [
        ["2026-0100", "2026/04/01", "第一四半期評価", "", "", "A部 田中", "",
         r"\\srv\A部\評価報告書.pptx"],
        ["2026-0200", "2026/07/01", "第二四半期評価", "", "", "B部 鈴木", "",
         r"\\srv\B部\評価報告書.pptx"],
    ])
    idx = build_index([str(p)])
    m = idx.match("評価報告書.pptx")

    assert m.ok is False, "同点で 1 行を選んではいけない"
    assert len(m.candidates) == 2
    assert "確定できません" in m.reason


def test_fuzzy_disabled_by_default(ledger):
    """表題の部分一致は誤爆しやすいので既定では使わない。"""
    m = ledger.match("配管圧損.pptx", allow_fuzzy=False)
    assert m.method != "title_fuzzy"


# ======================================================================
# 4. 確度に応じた注記（2B）
# ======================================================================

def test_confirmed_flag_tracks_threshold(ledger):
    from app.reference_index import CONFIRMED_THRESHOLD

    high = ledger.match("2026-0012_配管圧損_報告書.pptx")
    assert high.confidence >= CONFIRMED_THRESHOLD
    assert high.confirmed is True


def test_unconfirmed_match_is_tagged_in_evidence(ledger, monkeypatch):
    """確度が足りない照合から作った証拠には【要確認】が付くこと。"""
    from app.nodes import _reference_to_evidence

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    m.confidence = 0.88          # path_suffix 相当まで落とす
    evs = _reference_to_evidence(m)

    assert evs
    assert all("【要確認】" in e.content for e in evs)


def test_confirmed_match_has_no_tag(ledger):
    from app.nodes import _reference_to_evidence

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    evs = _reference_to_evidence(m)
    assert evs and not any("【要確認】" in e.content for e in evs)


# ======================================================================
# 5. 証拠への変換（1A の前半）
# ======================================================================

def test_evidence_carries_ledger_origin_and_source(ledger):
    """要約の主張が報告書由来か台帳由来かは読み手にとって意味が違う。"""
    from app.nodes import _reference_to_evidence

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    evs = _reference_to_evidence(m)

    assert all(e.origin == "ledger" for e in evs)
    assert all("参照台帳" in e.source for e in evs)
    # 行まで特定できる（後から現物に当たれる）
    assert all(":" in e.source for e in evs)


def test_evidence_carries_every_column_with_its_raw_header(ledger):
    """v3.15：語彙表に無い列も含め、全列が生の表頭のまま証拠になること。

    v3.14 は語彙表に載っている列だけを拾っていたので、「使用ソフト」
    「特記事項」のような列が黙って消えていた。人が手で埋めた情報を
    こちらの都合で無かったことにするのは誤り。
    """
    from app.nodes import _reference_to_evidence

    blob = " ".join(e.content for e in _reference_to_evidence(
        ledger.match("2026-0012_配管圧損_報告書.pptx")))
    for head in ("依頼者", "依頼理由", "依頼内容", "依頼目的", "依頼日", "タイトル"):
        assert f"「{head}」" in blob, f"{head} 列が証拠に入っていない"
    # 照合鍵そのもの（保存パス）は要約に不要なので入れない
    assert "報告書パス" not in blob


def test_unknown_columns_are_not_dropped(tmp_path):
    """語彙表に一切無い表頭ばかりの台帳でも、情報が落ちないこと。"""
    from app.nodes import _reference_to_evidence
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "変な表頭.xlsx", [
        ["2026-0700", "製造技術部", "配管検討", "FloEFD", "客先立会あり",
         r"\\srv\2026-0700_配管検討.pptx"],
    ], title_row=False,
        headers=["管理No", "起案部門", "案件テーマ", "使用ソフト", "特記事項",
                 "成果物の格納場所"])
    idx = build_index([str(p)])
    blob = " ".join(e.content for e in _reference_to_evidence(
        idx.match("2026-0700_配管検討.pptx")))
    for head in ("起案部門", "案件テーマ", "使用ソフト", "特記事項"):
        assert f"「{head}」" in blob, f"語彙外の列 {head} が消えている"


def test_empty_cells_produce_no_evidence(tmp_path):
    from app.nodes import _reference_to_evidence
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "sparse.xlsx", [
        ["2026-0500", "", "表題のみ", "", "", "", "", r"\\srv\sparse_報告書.pptx"],
    ])
    idx = build_index([str(p)])
    evs = _reference_to_evidence(idx.match("sparse_報告書.pptx"))
    contents = " ".join(e.content for e in evs)
    assert "依頼者" not in contents, "空欄から証拠を作ってはいけない"


# ======================================================================
# 6. 集約で落とされないこと
# ======================================================================

def test_reference_evidence_bypasses_selection():
    """台帳の証拠が確度フィルタや類別上限で落ちないこと。

    「台帳に書いてあるのに要約に出ない」は一番間の抜けた失敗。
    """
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert 'state.get("reference_evidence"' in src
    assert "agg = ref + agg" in src


# ======================================================================
# 7. 食い違い検出（1A の後半・LLM 不使用）
# ======================================================================

def test_conflict_detected_when_summary_omits_ledger_value(ledger):
    from app.nodes import _reference_conflicts

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    summary = {"case_name": "配管圧損の低減検討",
               "detail": {"finding": ["圧損 12.3 kPa"]}}
    conflicts = _reference_conflicts(summary, m.to_dict())

    fields = {c["field"] for c in conflicts}
    assert "依頼者" in fields, "台帳の依頼者が要約に無いなら指摘すべき"
    # どちらが正しいかは判定しない
    assert all("要確認" in c["note"] for c in conflicts)


def test_no_conflict_when_summary_contains_values(ledger):
    from app.nodes import _reference_conflicts

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    summary = {"requester": "製造技術部 山田太郎",
               "background": "歩留り低下が続いたため",
               "scope": "形状A/BのCFD比較",
               "purpose": "圧損20%低減の可否判断",
               "date": "2026/04/10",
               "title": "配管圧損の低減検討",
               "no": "2026-0012"}
    assert _reference_conflicts(summary, m.to_dict()) == []


def test_conflict_check_skips_very_short_values(ledger):
    """「A」「1」のような短い値は誤検出の元なので見ない。"""
    from app.nodes import _reference_conflicts

    m = ledger.match("2026-0012_配管圧損_報告書.pptx")
    m.row.cells = [("依頼者", "A")] + [c for c in m.row.cells if c[0] != "依頼者"]
    conflicts = _reference_conflicts({"x": "無関係"}, m.to_dict())
    assert "依頼者" not in {c["field"] for c in conflicts}


# ======================================================================
# 8. 結線と設定
# ======================================================================

def test_node_runs_before_first_llm_call():
    import inspect

    import app.graph as G

    src = inspect.getsource(G.build_graph)
    assert '"route_template", "lookup_reference"' in src
    assert '"lookup_reference", "prepare_html_text"' in src
    assert src.index('"lookup_reference"') < src.index('"extract_text_evidence"')


def test_run_workflow_accepts_per_run_paths():
    """3C：常駐ライブラリに **追加** できること（置き換えではない）。"""
    import inspect

    import app.graph as G

    sig = inspect.signature(G.run_workflow)
    assert "reference_paths" in sig.parameters
    src = inspect.getsource(G.run_workflow)
    assert '"reference_paths": list(reference_paths or [])' in src


def test_library_and_per_run_paths_are_merged():
    import inspect

    import app.nodes as N

    src = inspect.getsource(N.make_nodes)
    assert 'paths = list(state.get("reference_paths") or [])' in src
    assert "paths.append(str(lib_path))" in src


def test_disabled_by_config_is_a_noop(tmp_path):
    from app.config import load_config

    wf = load_config().workflow
    assert isinstance(wf.reference_enabled, bool)
    assert isinstance(wf.reference_adopt_unconfirmed, bool)
    assert wf.reference_allow_fuzzy is False, "曖昧照合は既定で無効"


def test_works_with_no_config_files_at_all():
    """v3.15：設定ファイルが 1 つも無いのが普通の状態。"""
    from app.reference_index import load_reference_specs

    specs = load_reference_specs()
    assert "default" in specs
    # 語彙表はもう存在しない
    assert not hasattr(specs["default"], "columns")
    assert not hasattr(specs["default"], "evidence_map")


# ======================================================================
# 9. 索引キャッシュ
# ======================================================================

def test_index_is_cached_between_calls(tmp_path):
    """一括処理で 100 件回すたびに数千行を読み直すのは無駄。"""
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "cache.xlsx", [
        ["2026-0700", "", "件名", "", "", "担当A", "", r"\\srv\cache_報告書.pptx"],
    ])
    a = build_index([str(p)])
    b = build_index([str(p)])
    assert a is b


def test_cache_key_changes_when_file_changes(tmp_path):
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = tmp_path / "mut.xlsx"
    _make_ledger(p, [["2026-0800", "", "旧", "", "", "旧担当", "", r"\\srv\mut.pptx"]])
    first = build_index([str(p)])
    _make_ledger(p, [["2026-0800", "", "新", "", "", "新担当", "", r"\\srv\mut.pptx"]])
    second = build_index([str(p)])
    assert first is not second, "台帳を差し替えたら索引も作り直すこと"


# ======================================================================
# 10. v3.17：Excel の Ctrl+F と同じ語義（列の役割を先に決めない）
# ======================================================================
#
# v3.14 は表頭の語彙表、v3.15/v3.16 は「どの列が保存パス列か」の形状判定に
# 頼っていた。どちらも前提が余計だった——人が台帳から報告書を探すとき、
# 列の役割を判定してから探したりしない。全体を検索して当たった行を読む。
# ファイル名は拡張子付きで十分に独特なので、それで足りる。

@pytest.mark.parametrize("headers,row,query,method", [
    # 保存パス列
    (["管理No", "部署", "格納先"],
     ["2026-0012", "製造", r"\\srv\解析\2026\2026-0012_配管圧損.pptx"],
     "2026-0012_配管圧損.pptx", "exact_filename"),
    # マクロ有 Excel（利用者自身の台帳形式）
    (["番号", "担当", "成果物"],
     ["2026-0013", "佐藤", "2026-0013_集計表.xlsm"],
     "2026-0013_集計表.xlsm", "exact_filename"),
    # 拡張子を持たないフォルダパス
    (["No", "担当", "格納先"],
     ["2026-0034", "鈴木", r"\\srv\解析\2026\筐体放熱検討"],
     "筐体放熱検討", "exact_filename"),
    # 「件名」欄に素のファイル名
    (["受付番号", "部署", "件名"],
     ["2026-0500", "品証", "振動解析_詳細報告"],
     "振動解析_詳細報告.pptx", "normalized_filename"),
    # CAD 図面
    (["図番", "設計", "ファイル"],
     ["DWG-1001", "設計一課", "DWG-1001_筐体図面.dwg"],
     "DWG-1001_筐体図面.dwg", "exact_filename"),
])
def test_matches_regardless_of_which_column_holds_it(tmp_path, headers, row, query, method):
    """どの列に入っていようと、どんな種類のファイルだろうと当たること。"""
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / f"{method}_{abs(hash(query))}.xlsx", [row],
                     title_row=False, headers=headers)
    m = build_index([str(p)]).match(query)
    assert m.ok, f"表頭 {headers} / 問い合わせ {query} で照合できていない"
    assert m.method == method


def test_matches_filename_buried_in_a_remarks_cell(tmp_path):
    """ファイル名が「備考」欄の文章に紛れていても当たる。

    Ctrl+F ならこれも見つかる。列の役割を決めてから探す設計では取り逃がす。
    """
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "remarks.xlsx", [
        ["2026-0600", "田中", "報告書は 2026-0600_疲労評価_最終.docx を参照"],
    ], title_row=False, headers=["番号", "担当", "備考"])
    m = build_index([str(p)]).match("2026-0600_疲労評価_最終.docx")
    assert m.ok


def test_matches_by_request_number_when_no_filename_column_exists(tmp_path):
    """ファイル名がどこにも書かれていない台帳でも、依頼番号で当たる。"""
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "nofile.xlsx", [["2026-0700", "品証", "熱伝導評価"]],
                     title_row=False, headers=["受付番号", "部署", "件名"])
    m = build_index([str(p)]).match("2026-0700_熱伝導評価_報告書.pptx")
    assert m.ok and m.method == "request_number"


def test_matched_column_is_recorded_and_excluded_from_evidence(tmp_path):
    """当たった列は「結果」であって「前提」ではない。

    記録するのは、その値が検索の鍵そのもの（保存パス等）で
    要約には要らないから。それ以外の用途は無い。
    """
    from app.nodes import _reference_to_evidence
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "matched.xlsx", [
        ["2026-0800", "製造", r"\\srv\2026-0800_検討.pptx", "備考あり"],
    ], title_row=False, headers=["番号", "部署", "格納先", "備考"])
    m = build_index([str(p)]).match("2026-0800_検討.pptx")

    assert m.matched_header == "格納先"
    blob = " ".join(e.content for e in _reference_to_evidence(m))
    assert "格納先" not in blob, "検索の鍵そのものは要約に不要"
    assert "備考" in blob, "それ以外の列は全部渡すこと"


def test_short_values_are_not_indexed(tmp_path):
    """部署コードのような短い値まで鍵にすると誤爆する。"""
    from app.reference_index import build_index, clear_cache

    clear_cache()
    p = _make_ledger(tmp_path / "short.xlsx", [["2026-0900", "QA", "検討"]],
                     title_row=False, headers=["番号", "部署", "件名"])
    idx = build_index([str(p)])
    assert all(len(k) >= 6 for k in idx.by_exact)
