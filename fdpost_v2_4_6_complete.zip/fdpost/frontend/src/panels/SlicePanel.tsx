/** Slice tool: axis (real-time) / free plane (drag the gizmo or type values),
 *  high-res render, batch export. Results appear in the bottom drawer. */
import { useState } from "react";
import { postAxisBatch, postPlaneBatch, postPlaneSlice } from "../api";
import { Feature } from "../features";
import NumberSlider from "../ui/NumberSlider";
import SliceCsvExport from "./SliceCsvExport";
import { useStore } from "../store";
import { toast } from "../toast";

export default function SlicePanel() {
  const { meta, previewGrid, activeId, activeField, slice, setSlice,
          batch, setBatch, set, addJob } = useStore();
  const [busy, setBusy] = useState(false);
  if (!meta?.bounds) return <div className="hint">データセットを読み込んでください</div>;

  const axisIdx = { x: 0, y: 1, z: 2 }[slice.axis];
  const nAxis = previewGrid ? previewGrid.dims[axisIdx] : 1;
  const axisOrigin = previewGrid ? previewGrid.origin[axisIdx] : 0;
  const axisStep = previewGrid ? previewGrid.spacing[axisIdx] : 1;
  const pos = axisOrigin + axisStep * Math.min(slice.k, nAxis - 1);
  const axisMax = axisOrigin + axisStep * (nAxis - 1);
  /** Metres -> nearest grid plane. The slice can only sit on a grid plane,
   *  so a typed position snaps to the closest one rather than being refused. */
  const posToIndex = (m: number) => Math.max(0, Math.min(nAxis - 1,
    Math.round((m - axisOrigin) / (axisStep || 1))));
  const [lo, hi] = meta.bounds;
  // Sweep bounds come from the data, so the sliders can never leave it.
  // Axis mode sweeps an absolute coordinate; plane mode a signed distance
  // from the centre, whose reach is half the body diagonal.
  const diag = Math.hypot(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]);
  const sweepLo = slice.submode === "axis" ? lo[axisIdx] : -diag / 2;
  const sweepHi = slice.submode === "axis" ? hi[axisIdx] : diag / 2;
  const sweepSpan = sweepHi - sweepLo;
  const sweepStepUnit = previewGrid
    ? Math.min(...previewGrid.spacing) : sweepSpan / 200;
  const sweepAxisLabel = slice.submode === "axis"
    ? `${slice.axis.toUpperCase()} 軸` : "中心からの符号付き距離";
  const nPlanes = Math.floor(
    Math.abs(batch.end - batch.start) / Math.max(batch.step, 1e-12)) + 1;

  const renderPlane = async () => {
    setBusy(true);
    try {
      const r = await postPlaneSlice(activeId!, {
        mode: "euler", tilt_deg: slice.tilt, azimuth_deg: slice.azimuth,
        distance: slice.distance, field: activeField, resolution: [400, 400],
      });
      if (!r.file_url) throw new Error("PNG URL が取得できませんでした");
      set({ planePng: r.file_url + "?t=" + Date.now(),
            drawerOpen: true, drawerTab: "plane" });
    } catch (e: any) { toast(e.message, "err"); }
    setBusy(false);
  };

  const runBatch = async () => {
    try {
      const j = slice.submode === "axis"
        ? await postAxisBatch(activeId!, {
            axis: slice.axis, start: batch.start, stop: batch.end,
            step: batch.step, field: activeField, with_vectors: batch.vectors,
            // batch output is an archival deliverable: highest fidelity by
            // default, at the resolution the source density supports
            fidelity: batch.hifi ? "scatter" : "grid",
            sample_px: batch.resolution || null, smooth: true })
        : await postPlaneBatch(activeId!, {
            mode: "euler", tilt_deg: slice.tilt, azimuth_deg: slice.azimuth,
            distance: 0, field: activeField, with_vectors: batch.vectors,
            resolution: [400, 400],
            distance_start: batch.start, distance_stop: batch.end,
            distance_step: batch.step,
            fidelity: batch.hifi ? "scatter" : "grid",
            sample_px: batch.resolution || null, smooth: true });
      addJob(j.id);
      toast("バッチ出力を開始しました(ジョブに追加)");
    } catch (e: any) { toast(e.message, "err"); }
  };

  return (
    <>
      <div className="panel">
        <h3>断面の定義</h3>
        <div className="tabs" style={{ marginBottom: 10 }}>
          <button className={slice.submode === "axis" ? "on" : ""}
                  onClick={() => setSlice({ submode: "axis" })}>軸直交</button>
          <button className={slice.submode === "plane" ? "on" : ""}
                  onClick={() => setSlice({ submode: "plane" })}>自由平面</button>
        </div>

        {slice.submode === "axis" && (
          <>
            <div className="row">
              <label>軸</label>
              {(["x", "y", "z"] as const).map((a) => (
                <button key={a} className={slice.axis === a ? "primary" : ""}
                        style={{ padding: "4px 12px" }}
                        onClick={() => setSlice({ axis: a, k: 0 })}>
                  {a.toUpperCase()}</button>
              ))}
            </div>
            <NumberSlider
              label="位置" value={pos} unit="m"
              min={axisOrigin} max={axisMax} step={axisStep || 1} snap
              onChange={(m) => {
                setSlice({ k: posToIndex(m) });
                set({ drawerOpen: true, drawerTab: "contour" });
              }} />
            <div className="hint" style={{ marginTop: 6 }}>
              3Dビューの平面をドラッグ / ←→キーでも移動できます。
              矢印をつかむと自由平面に切り替わります。
              平面が邪魔で視点を回せないときは Alt を押しながらドラッグ。
            </div>
          </>
        )}

        {slice.submode === "plane" && (
          <>
            <div className="hint" style={{ marginBottom: 8 }}>
              3Dビュー上で <b>T キーを押しながら上下ドラッグ = 回転角</b>、
              <b>A キーを押しながら左右ドラッグ = 方位角</b>。
              距離は平面のドラッグか ←→ キーです。
            </div>
            <div className="field-grid">
              <label>回転角 [°]</label>
              <input type="number" step="1" value={slice.tilt}
                     onChange={(e) => setSlice({ tilt: +e.target.value })} />
              <label style={{ gridColumn: "3" }}>方位角 [°]</label>
              <input type="number" step="1" value={slice.azimuth}
                     onChange={(e) => setSlice({ azimuth: +e.target.value })} />
              <label>距離 [m]</label>
              <input type="number" step="0.001" value={slice.distance}
                     onChange={(e) => setSlice({ distance: +e.target.value })} />
              <span />
              <button className="primary" style={{ gridColumn: "4" }}
                      onClick={renderPlane} disabled={busy}>
                {busy ? "生成中…" : "高解像度描画"}
              </button>
            </div>
            <div className="hint" style={{ marginTop: 8 }}>
              工業CADと同じ操作: 平面本体のドラッグ=法線方向に移動、
              矢印の先端ドラッグ=向きの回転(マウスを向けた方向)。
              ←→キー: 距離送り(Shiftで微動)。
            </div>
          </>
        )}
      </div>

      <Feature id="slice.csv">
        <SliceCsvExport />
      </Feature>

      <Feature id="slice.batch">
      <div className="panel">
        <h3>バッチ出力(PNG一括)</h3>
        <div className="hint" style={{ marginBottom: 8 }}>
          {sweepAxisLabel}の範囲を掃引して PNG を連続出力します。
          スライダーは常にデータ範囲内に収まります。
        </div>

        <NumberSlider label="開始" value={batch.start} unit="m"
                      min={sweepLo} max={sweepHi} step={sweepStepUnit}
                      onChange={(v) => setBatch({ start: v })} />
        <NumberSlider label="終了" value={batch.end} unit="m"
                      min={sweepLo} max={sweepHi} step={sweepStepUnit}
                      onChange={(v) => setBatch({ end: v })} />
        <NumberSlider label="間隔" value={batch.step} unit="m"
                      min={sweepStepUnit}
                      max={Math.max(sweepStepUnit * 2, sweepSpan / 2)}
                      step={sweepStepUnit}
                      onChange={(v) => setBatch({
                        step: Math.max(sweepStepUnit, v) })} />

        <div className="row" style={{ marginTop: 6 }}>
          <span className="mono" style={{ fontSize: 11,
                color: nPlanes > 200 ? "var(--err)" : "var(--text-dim)" }}>
            {nPlanes} 枚
            {nPlanes > 200 && " — 多すぎます(上限200)"}
          </span>
          <label style={{ marginLeft: "auto", display: "flex", gap: 5,
                          alignItems: "center", fontSize: 12 }}>
            <input type="checkbox" checked={batch.preview}
                   onChange={(e) => setBatch({ preview: e.target.checked })} />
            3Dに表示
          </label>
        </div>

        <div className="row" style={{ marginTop: 8 }}>
          <label style={{ display: "flex", gap: 5, alignItems: "center" }}>
            <input type="checkbox" checked={batch.vectors}
                   onChange={(e) => setBatch({ vectors: e.target.checked })} />
            ベクトル重畳
          </label>
          <label style={{ display: "flex", gap: 5, alignItems: "center" }}
                 title="元の点群から直接サンプリングして出力します(既定)。OFFにすると格子から高速に出力します">
            <input type="checkbox" checked={batch.hifi}
                   onChange={(e) => setBatch({ hifi: e.target.checked })} />
            高保真
          </label>
          <button style={{ marginLeft: "auto" }} className="primary"
                  disabled={nPlanes > 200} onClick={runBatch}>実行</button>
        </div>
        <div className="hint" style={{ marginTop: 6 }}>
          「3Dに表示」で開始面・終了面・各ステップ位置が
          ビューポートに黄色い枠として重なります。実行前に確認できます。
          <br />
          既定の<b>高保真</b>は元の点群から直接サンプリングし、
          点密度が支える解像度で出力します(格子解像度に縛られません)。
          プレビューより時間はかかります。
        </div>
      </div>
      </Feature>
    </>
  );
}
