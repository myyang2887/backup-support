/** Resizable results drawer: real-time contour / plane PNG / probe curve.
 *
 *  The contour tab paints at preview resolution instantly, then swaps in the
 *  full-resolution slice from the backend once scrubbing stops (see
 *  result2d/sliceSource). A badge tells you which one you are looking at. */
import { useEffect, useRef, useState } from "react";
import { getSliceNative, postSliceExport } from "../api";
import Contour2D from "../result2d/Contour2D";
import { QUIVER_DEFAULTS } from "../result2d/quiver";
import { useSliceData } from "../result2d/sliceSource";
import { useFeature } from "../features";
import { IconClose } from "../icons";
import { useStore } from "../store";
import { toast } from "../toast";
import ExportBar, { downloadAll } from "../panels/ExportBar";

export default function BottomDrawer() {
  const { meta, activeField, clim, slice, drawerOpen, drawerTab,
          planePng, probePng, cursorReadout, display, setDisplay,
          set } = useStore();
  const drawerFeature = useFeature("shell.drawer");
  const hudFeature = useFeature("viewport.cursorHud");
  const quiverFeature = useFeature("viewport.quiver2d");
  const [height, setHeight] = useState(320);
  const [arrows, setArrows] = useState(false);
  const [native, setNative] = useState<{ native_px: number; grid_px: number;
    slab_points: number } | null>(null);
  const [exporting, setExporting] = useState(false);
  const [files, setFiles] = useState<string[]>([]);
  const [density, setDensity] = useState(QUIVER_DEFAULTS.targetCount);
  const dragRef = useRef<{ y: number; h: number } | null>(null);

  const wantVectors = quiverFeature && arrows;
  const { plot, refining } = useSliceData(wantVectors);

  // What resolution is this slice actually worth? Density near the plane
  // decides; beyond it you get pixels, not information.
  useEffect(() => {
    const s2 = useStore.getState();
    if (!s2.activeId || drawerTab !== "contour" || !plot) { return; }
    let live2 = true;
    getSliceNative(s2.activeId, s2.activeField, s2.slice.axis, plot.position)
      .then((r) => { if (live2) setNative(r); })
      .catch(() => { if (live2) setNative(null); });
    return () => { live2 = false; };
  }, [drawerTab, plot?.position, activeField]);

  const exportSlice = async (fidelity: "grid" | "scatter") => {
    const s2 = useStore.getState();
    if (!s2.activeId || !plot) return;
    setExporting(true);
    try {
      const r = await postSliceExport(s2.activeId, {
        mode: "axis", axis: s2.slice.axis, position: plot.position,
        field: s2.activeField,
        resolution: Math.max(...plot.dims),
        fidelity, formats: ["png", "csv"], with_vectors: wantVectors,
        smooth: true,
      });
      const rel = [r.png_url, r.csv_url].filter(Boolean)
        .map((u) => (u as string).replace("/api/files/", ""));
      setFiles(rel);
      // Deliver to *this* browser immediately. Without it the files only
      // exist on the server host, which is invisible to a remote user.
      downloadAll(rel);
      toast(`${r.dims[0]}x${r.dims[1]} を出力・ダウンロードしました`);
    } catch (e: any) { toast(e.message, "err"); }
    setExporting(false);
  };

  if (!drawerFeature || !drawerOpen || !meta) return null;
  const unit = meta.units?.[activeField] ?? "";
  // the slice can never be finer than the preprocessed grid
  const gridMax = Math.max(16, ...(meta.dims ?? [128]));
  const sliderMax = Math.max(gridMax, 1024);
  const cur = display.sliceMaxDim || gridMax;
  const beyondGrid = cur > gridMax;

  const onGrab = (e: React.PointerEvent) => {
    dragRef.current = { y: e.clientY, h: height };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onMove = (e: React.PointerEvent) => {
    if (!dragRef.current) return;
    const h = dragRef.current.h + (dragRef.current.y - e.clientY);
    setHeight(Math.min(window.innerHeight * 0.65, Math.max(180, h)));
  };
  const onRelease = () => { dragRef.current = null; };

  const badge = plot && (
    <span className="mono" style={{ fontSize: 10, padding: "1px 6px",
          borderRadius: 8, marginLeft: 8,
          color: plot.resolution === "full" ? "var(--accent)" : "var(--text-faint)",
          background: "var(--bg-2)" }}>
      {plot.dims[0]}x{plot.dims[1]}
      {plot.resolution === "direct" ? " 点群直接"
       : plot.resolution === "full" ? " 格子実解像度"
       : refining ? " 精細化中…" : " プレビュー"}
    </span>
  );

  return (
    <div style={{ height, background: "var(--bg-1)",
                  borderTop: "1px solid var(--line)", display: "flex",
                  flexDirection: "column", flexShrink: 0 }}>
      <div onPointerDown={onGrab} onPointerMove={onMove} onPointerUp={onRelease}
           style={{ height: 5, cursor: "ns-resize", background: "transparent",
                    borderTop: "2px solid var(--line-strong)" }} />
      <div className="row" style={{ padding: "2px 10px 0", gap: 0 }}>
        <div className="tabs">
          <button className={drawerTab === "contour" ? "on" : ""}
                  onClick={() => set({ drawerTab: "contour" })}>断面(実時間)</button>
          <button className={drawerTab === "plane" ? "on" : ""}
                  onClick={() => set({ drawerTab: "plane" })}>斜め断面</button>
          <button className={drawerTab === "probe" ? "on" : ""}
                  onClick={() => set({ drawerTab: "probe" })}>ライン結果</button>
        </div>
        {drawerTab === "contour" && badge}
        {drawerTab === "contour" && (
          <div className="row" style={{ marginLeft: 10, gap: 6 }}>
            <label style={{ fontSize: 11, color: "var(--text-dim)" }}>解像度</label>
            <input type="range" min={16} max={sliderMax} step={4}
                   style={{ width: 130 }}
                   title={`格子解像度 ${gridMax} を超える分は、元の点群から`
                          + `直接サンプリングします`}
                   value={cur}
                   onInput={(e) => {
                     const v = +(e.target as HTMLInputElement).value;
                     setDisplay({ sliceMaxDim: v === gridMax ? 0 : v });
                   }} />
            <span className="mono" style={{ fontSize: 10, minWidth: 42,
                  color: beyondGrid ? "var(--accent)" : "var(--text-dim)" }}>
              {cur}
            </span>
            {native && (
              <button className="quiet" style={{ fontSize: 10, padding: "1px 6px" }}
                      title={`このスライス近傍の点密度から算出。データが実際に`
                             + `支えられる解像度です(近傍点 ${native.slab_points} 点)。`
                             + `これを大きく超えても画素が増えるだけで情報は増えません。`}
                      onClick={() => setDisplay({
                        sliceMaxDim: native.native_px, sliceHiFi: true })}>
                適正 {native.native_px}
              </button>
            )}
            <label style={{ display: "flex", gap: 4, alignItems: "center",
                            fontSize: 11, cursor: "pointer" }}
                   title="元の点群から直接サンプリングし、平面内で線形補間します。滑らかで格子解像度に縛られません">
              <input type="checkbox" checked={display.sliceHiFi}
                     onChange={(e) => setDisplay({ sliceHiFi: e.target.checked })} />
              高保真
            </label>
            <label style={{ display: "flex", gap: 4, alignItems: "center",
                            fontSize: 11, cursor: "pointer" }}
                   title="OFFにすると補間なしの生のセルを表示します(実際のサンプル格子の確認用)">
              <input type="checkbox" checked={display.sliceSmooth !== false}
                     onChange={(e) => setDisplay({ sliceSmooth: e.target.checked })} />
              平滑
            </label>
          </div>
        )}
        {drawerTab === "contour" && quiverFeature && (
          <div className="row" style={{ marginLeft: 12, gap: 8 }}>
            <label style={{ display: "flex", gap: 5, alignItems: "center",
                            fontSize: 11, cursor: "pointer" }}>
              <input type="checkbox" checked={arrows}
                     onChange={(e) => setArrows(e.target.checked)} />
              速度矢印
            </label>
            {arrows && (
              <input type="range" min={10} max={50} step={2} value={density}
                     title="矢印の密度" style={{ width: 90 }}
                     onInput={(e) => setDensity(+(e.target as HTMLInputElement).value)} />
            )}
          </div>
        )}
        {drawerTab === "contour" && plot && (
          <div className="row" style={{ marginLeft: 10, gap: 4 }}>
            <button style={{ fontSize: 11, padding: "2px 8px" }}
                    disabled={exporting}
                    title="いま見ている解像度・忠実度でPNGとCSVを出力します"
                    onClick={() => exportSlice(
                      // Mirror what the preview actually rendered, not the
                      // checkbox: the preview also switches to scatter on its
                      // own once the requested resolution passes the grid
                      // ceiling. Reading the checkbox instead would export
                      // grid data while the screen showed scatter data.
                      plot.resolution === "direct" ? "scatter" : "grid")}>
              {exporting ? "出力中…" : "この断面を出力"}
            </button>
            <button className="quiet" style={{ fontSize: 11, padding: "2px 8px" }}
                    disabled={exporting}
                    title="元データから最高忠実度で出力します(プレビュー設定は無視)"
                    onClick={() => exportSlice("scatter")}>
              高保真で出力
            </button>
          </div>
        )}
        {drawerTab === "contour" && files.length > 0 && (
          <div style={{ marginLeft: 8 }}><ExportBar files={files} /></div>
        )}
        <button className="quiet" style={{ marginLeft: "auto" }}
                title="閉じる" onClick={() => set({ drawerOpen: false })}>
          <IconClose size={13} />
        </button>
      </div>
      <div style={{ flex: 1, overflow: "auto", padding: "4px 10px 10px" }}>
        {drawerTab === "contour" && (plot
          ? <Contour2D slice={plot} field={activeField} unit={unit} clim={clim}
                       hover={hudFeature && cursorReadout}
                       smooth={display.sliceSmooth !== false}
                       quiver={wantVectors
                         ? { ...QUIVER_DEFAULTS, targetCount: density } : null}
                       title={`${slice.axis.toUpperCase()} = ${plot.position.toFixed(5)} m`} />
          : <div className="hint">断面ツールで軸直交モードを選ぶと実時間表示されます</div>)}
        {drawerTab === "plane" && (planePng
          ? <img src={planePng}
                 style={{ maxHeight: "100%", maxWidth: "100%", borderRadius: 4 }} />
          : <div className="hint">断面ツールの「高解像度描画」の結果がここに表示されます</div>)}
        {drawerTab === "probe" && (probePng
          ? <img src={probePng}
                 style={{ maxHeight: "100%", maxWidth: "100%", borderRadius: 4 }} />
          : <div className="hint">ラインツールの実行結果がここに表示されます</div>)}
      </div>
    </div>
  );
}
