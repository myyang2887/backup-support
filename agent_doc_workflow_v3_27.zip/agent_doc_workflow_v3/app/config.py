"""类型化配置。config.yaml 解析进 Pydantic 模型，错字段名在启动时立刻报错。"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

import yaml
from pydantic import BaseModel, Field

PROJECT_ROOT = Path(__file__).resolve().parent.parent


class VisionLLMConfig(BaseModel):
    """可选：视觉模型走独立端点（例如 Qwen3-VL 起在另一个 llama-server 上）。
    不配置则复用主 LLM 端点。"""
    base_url: str = ""
    api_key: str = "local-no-key-needed"
    model: str = "local-model"


class LLMConfig(BaseModel):
    base_url: str = "http://127.0.0.1:8080/v1"
    api_key: str = "local-no-key-needed"
    model: str = "local-model"
    temperature: float = 0.0
    vision: Optional[VisionLLMConfig] = None
    # llama.cpp server 支持 response_format=json_schema（grammar 约束解码）。
    # 不支持时自动降级为文本+正则提取，见 llm_client.py
    structured_output: str = "auto"  # "auto" | "json_schema" | "none"
    max_retries: int = 2
    timeout_seconds: float = 300.0
    # 测试/无 GPU 环境用的 mock 模式
    mock: bool = False


class PathsConfig(BaseModel):
    inbox_dir: str = "inbox"
    out_dir: str = "out"
    template_markdown: str = "templates/case_summary_v2.md.j2"
    template_yaml: str = "templates/case_summary_v1.yaml"

    def resolve(self, rel: str) -> Path:
        p = Path(rel)
        return p if p.is_absolute() else PROJECT_ROOT / p


class WorkflowConfig(BaseModel):
    chunk_chars: int = 6000
    chunk_overlap: int = 500
    # v3.8：0 = 無制限。v3.7 は 40 で黙って尾部を捨てていた（長い Word 文書の
    # 後半が要約に一切反映されない事故の原因）。精度優先のため既定を無制限に。
    max_text_chunks: int = 0
    min_chunk_informative_chars: int = 80
    # v3.8：情報量の少ないチャンクを捨てるか。既定 False＝捨てない。
    # 「タイトル＋重要な数値ひとつ」だけのページが消えるのを防ぐ。
    drop_low_info_chunks: bool = False
    max_visual_assets: int = 30

    # ---- v3.8 視覚 ----
    # ページ全文の書き起こしは 2048 tokens では日本語 1 ページで溢れ、JSON が
    # 壊れてページ丸ごと skip されていた。ページモードだけ上限を上げる。
    vision_page_max_tokens: int = 6144
    vision_asset_max_tokens: int = 2048
    # 0 = 無制限。v3.7 は readable_text[:10] で 1 ページの 6〜7 割を捨てていた。
    visual_readable_text_limit: int = 0

    # ---- v3.9 二段階書き出し（要約の加筆）----
    # 一段目は temperature 0 ＋ 構造制約で「正しい骨格」を作ることに専念させ、
    # 二段目でだけ表現を厚くする。一発で「正確かつ詳しく」を求めると弱い
    # モデルは字数のために作話するので、課題を 2 つに割る。
    expand_summary: bool = True
    expand_temperature: float = 0.25   # 抽出は 0 のまま。ここだけ少し上げる
    expand_max_tokens: int = 2048
    expand_evidence_chars: int = 20000
    # 加筆は 1 項目 = LLM 1 回。弱いモデルでは所要時間に直結するので上限を置く。
    # 長い項目（＝読み手が一番読む所）から順に使い切る。
    expand_max_fields: int = 3
    # 加筆結果に「証拠に無い数値」が混ざっていたら、その回の加筆を丸ごと捨てる。
    # 判定は確定的（数値の照合のみ）なのでモデルの巧拙に左右されない。
    expand_verify_numbers: bool = True

    # ---- v3.9 精読モード ----
    # ページ単位で本文証拠と視覚証拠を突き合わせ、数値の食い違いを検出する。
    # 判定は確定的な規則のみ（LLM 呼び出しを増やさないので実行時間はほぼ不変）。
    deep_read: bool = False

    # ---- v3.8 Excel シートのページ画像化（Windows + Excel COM）----
    excel_sheet_render: bool = True
    excel_sheet_render_max_sheets: int = 20
    excel_sheet_render_max_pages: int = 40
    excel_sheet_render_landscape: bool = True
    excel_sheet_render_timeout: float = 600.0

    # ---- v3 性能相关 ----
    # 数字原生 PDF 关掉 OCR 可大幅提速；扫描件需 true
    docling_ocr: bool = True
    # 阶段级缓存：同内容文件重跑时复用 解析/证据/视觉分析 产物
    resume: bool = True
    # 视觉资产预过滤
    image_min_edge_px: int = 100
    image_min_bytes: int = 5120
    image_max_edge_px: int = 1024
    # 视觉分析并行度
    vision_workers: int = 2
    # 证据提取单次调用输出上限（v2 的 4096 过于慷慨）
    extract_max_tokens: int = 3072

    # ---- v3 agent 逻辑 ----
    # 缺口回填：聚合后发现关键类别无证据时，做一次针对性补提取
    gap_fill: bool = True
    gap_fill_context_chars: int = 16000

    # Web 层：同时运行的 run 数（本地单 GPU 建议 1，多余请求排队）
    max_concurrent_runs: int = 1

    # ---- PDF 视觉提取（v3.2）----
    pdf_extract_embedded: bool = True     # 提取内嵌图片对象
    pdf_render_fallback: bool = True      # 无内嵌图时，图像型页面整页渲染
    pdf_render_min_text_chars: int = 120  # 文本字符数低于此值的页视为图像型
    pdf_render_scale: float = 2.0

    # 启动时后台预热 Docling（加载布局/OCR模型，消除首个用户请求的冷启动）
    warmup_on_start: bool = True

    # LangGraph SqliteSaver 节点级断点（与文件缓存互补；默认关）
    checkpoint_enabled: bool = False

    # 文本分支（切块→証拠抽出→集約→gap_fill）と視覚分支（画像収集→VLM 分析）を
    # 並行実行する。両者に依存関係は無い。false = 逐次（デバッグ時に耗时归因しやすい）
    parallel_branches: bool = True

    # ---- v3.6 解析ルート ----
    # "auto"   … 安価なプローブ（頁数/文字密度/画像数）で自動判定
    # "text"   … 常に Docling（従来動作）
    # "vision" … Docling を飛ばして全ページ画像化 → VLM が主役
    input_mode: str = "auto"

    # ---- v3.11 テンプレート自動判定（LLM 不使用）----
    # "manual" … UI/CLI で選んだテンプレートをそのまま使う（従来動作）
    # "auto"   … ファイル名＋本文冒頭の語でテンプレートを選ぶ
    #            （app/template_route.py・最初の LLM 呼出の前に決まる）
    template_mode: str = "manual"
    # 決め手が無い時の落とし先。generic_doc は「種別が特定できない資料の
    # 受け皿」と自ら名乗っているテンプレートなので既定はこれ。
    template_auto_fallback: str = "generic_doc"

    # ---- v3.11 office2pdf（Office → PDF・Rust 単一バイナリ・Apache-2.0）----
    # Office COM が不安定で LibreOffice がライセンス上使えない環境で、
    # PPTX/DOCX の全頁描画を成立させるための変換器。
    office2pdf_enabled: bool = True
    # 空なら OFFICE2PDF_PATH → tools/bin/office2pdf[.exe] → PATH の順に探す
    office2pdf_path: str = ""
    # 埋め込みフォントの無い資料向けに日本語フォントのディレクトリを渡せる
    office2pdf_font_path: str = ""

    # ---- v3.12 画像が密集した頁の扱い ----
    dense_page_threshold: int = 6
    contact_sheet_enabled: bool = True
    contact_sheet_cols: int = 3
    contact_sheet_max_edge_px: int = 2048
    contact_sheet_max_cells: int = 12
    # ---- v3.12 埋め込み画像へ渡す本文文脈の長さ（0 で無効）----
    visual_context_chars: int = 500
    # ---- v3.12 証拠が無い項目を推定で埋めるか ----
    # true  … 関連証拠から定性的に 1〜2 文書き、末尾に推定である旨を注記する
    #         （数値・日付・固有名詞の新規生成は禁止。手掛かり皆無なら従来どおり）
    # false … 従来どおり「資料内で確認できず」
    infer_when_missing: bool = True

    # ---- v3.14 参照台帳（年度別の依頼一覧 Excel）----
    # 報告書に書かれていないメタ情報（依頼番号・依頼日・依頼者・依頼目的…）を
    # 台帳から引いて **要約前に証拠として注入** する。LLM は台帳を読まない
    # ——照合は決定論的な join なので判断の余地が無く、コードでやる方が速く確実。
    reference_enabled: bool = True
    #: 常駐ライブラリ。ここに置いた Excel は全 run で使われる。
    reference_library_dir: str = "data/references"
    #: 列名マッピングの様式 ID（references/registry/<id>/reference.yaml）
    reference_spec_id: str = "default"
    #: 部分一致を使うか。台帳に報告書のファイル名が載っていない現場では
    #: これが本命になるので既定で有効。採点して最良の 1 行を採り、
    #: 候補は全部レポートに残す。
    reference_allow_partial: bool = True
    #: 台帳証拠の確度に掛ける係数。**元資料より少し低く** する。
    #: 報告書そのものが一次資料で、台帳は補助（古い・行がずれる可能性がある）。
    reference_confidence_factor: float = 0.9
    #: 確度が CONFIRMED_THRESHOLD 未満でも採用するか（採用時は要確認注記を付ける）
    reference_adopt_unconfirmed: bool = True
    #: 要約後に台帳と食い違う記述を検出して報告する（LLM は使わない）
    reference_conflict_check: bool = True
    vision_route_max_pages: int = 30          # これを超えると画像化は割高 → text
    vision_route_text_chars_per_page: int = 200  # 未満なら「テキスト層が薄い」→ vision
    vision_route_images_per_page: float = 1.5    # 以上なら「図版主体」→ vision
    vision_route_max_render_pages: int = 40   # vision 時に描画する最大ページ数
    # ページ全体を読ませるので通常の image_max_edge_px(1024) では文字が潰れる
    vision_route_page_max_edge_px: int = 1536
    # 证据聚合参数
    min_evidence_confidence: float = 0.3
    max_evidence_per_category: int = 12
    max_evidence_pack_chars: int = 32768
    # 校验失败后的修复重试次数（LangGraph 条件边）
    max_repair_attempts: int = 2
    # 并行提取证据的线程数（llama.cpp 单卡通常 1~2 即可，server 开 --parallel 时可调大）
    extract_workers: int = 4


class RedactionConfig(BaseModel):
    enabled: bool = True
    llm_rewrite: bool = True            # 规则层之上的 LLM 泛化改写（带泄漏复检回退）
    dictionary_path: str = "redaction/ng_words.yaml"


class WatchFolderConfig(BaseModel):
    enabled: bool = False
    path: str = "inbox_watch"           # 监视目录；处理后移入 processed/
    interval_seconds: int = 10


class LedgerConfig(BaseModel):
    db_path: str = "out/ledger.sqlite3"


class BatchConfig(BaseModel):
    """フォルダ一括処理（v3.6）。パスを受け取って配下を丸ごと処理する。"""
    enabled: bool = True
    recursive: bool = True          # サブフォルダも辿るか（UI から都度上書き可）
    max_files: int = 500            # 一度に投入する上限（事故防止）
    # 空リスト = 制限なし。運用で投入元を縛りたい場合はここにルートを列挙する
    allowed_roots: list[str] = Field(default_factory=list)


class SiteConfig(BaseModel):
    enabled: bool = False   # 対外紹介サイト機能の総開関（默认关闭；关闭时 UI 不显示、API 拒绝）


# 前端功能组默认值（唯一定义处）。联动的按钮/面板归为同一组：
# 例如 tier_switch 同时控制 社内/社外切换按钮 + 社外版下载 + 脱敏报告下载。
DEFAULT_UI_FEATURES: Dict[str, bool] = {
    "robot_animation": True,   # 小机器人 + peek 气泡（含头部临时复选框）
    "template_select": True,   # 上传时的模板下拉（关闭则固定用 case 模板）
    "cancel_button":   True,   # 运行中的「中断」按钮
    "metrics_table":   True,   # LLM 呼出指标表
    "vlm_test":        True,   # 头部「VLM テスト」按钮
    "evidence_tab":    True,   # 結果区「証拠」页签
    "hitl_tab":        True,   # 「修訂（HITL）」页签（含版本历史/良い例按钮）
    "chat_tab":        True,   # 「チャット」页签（流式对话）
    "tier_switch":     True,   # 社内/社外切换 + 社外下载 + 脱敏报告
    "rag_buttons":     True,   # 结果页 RAG 下载按钮
    "history_card":    True,   # 左栏 実行履歴 卡（含删除按钮）
    "ledger_card":     True,   # 左栏 案件台帳 卡（检索/Excel/RAG 全件导出）
    "dictionary_card": True,   # 左栏 NG ワード辞書 编辑卡
    "route_select":    True,   # v3.6 投入時の解析ルート選択（自動/テキスト/視覚）
    "batch_card":      True,   # v3.6 フォルダ一括処理カード + 専用履歴
    "reference_card":  True,   # v3.14 参照台帳（依頼一覧 Excel）の登録・照合テスト
    "doc_export":      True,   # v3.6 PDF / Word 書面エクスポート
    "deep_read":       True,   # v3.9 精読モード（ページ単位の突き合わせ）トグル
    "pptx_export":     True,   # v3.9 要約から PPTX を自動生成するボタン
    "pipeline_trace":  True,   # v3.9 実行トレース（ルート・使用実装）の表示
    "figure_insert":   True,   # v3.27 要約文への図版差し込み（採否レポート表示を含む）
    # "site" 组不在此处：由 site.enabled 独立控制（涉及后端 API 守门）
}


class UIConfig(BaseModel):
    robot_animation: bool = True          # 兼容旧配置；与 features 合并时生效
    # config.yaml 里按组覆盖，如 features: {chat_tab: false}
    features: Dict[str, bool] = Field(default_factory=dict)


class FigureWeights(BaseModel):
    """スコア成分の重み。合計は自由（内部で正規化する）。"""
    numeric: float = 0.40      # 数値・単位の一致（工学資料で最も効く）
    ngram: float = 0.28        # key_facts / visual_summary との文字 n-gram
    page: float = 0.20         # 本文の出所ページと図のページの近さ
    readable: float = 0.12     # 図中の読み取りテキスト（ノイズが多いので低め）


class FigureConfig(BaseModel):
    """v3.27 要約文への図版差し込み。

    既定は「挿さない」側に倒してある。min_margin（2 位との差）が肝で、
    これを 0 にすると「どちらとも取れる図」が入り始める。
    """
    enabled: bool = True
    max_figures: int = 3                   # 1 文書あたりの上限
    min_score: float = 0.42                # 絶対スコアの下限
    min_margin: float = 0.10               # 2 位との差の下限（曖昧なら挿さない）
    min_image_confidence: float = 0.35     # VLM の読み取り信頼度の下限
    allow_page_render: bool = False        # 全面レンダリングを図版として許すか
    external_tier: bool = False            # 社外版に図を入れるか（画像は脱敏されない）
    verify_with_vlm: bool = False          # 最終候補に Yes/No 確認を掛ける
    caption_max_chars: int = 60
    allow_sections: list[str] = Field(default_factory=lambda: [
        "判明した事実", "Findings", "対応効果", "Effects", "実施内容",
        "Implementation", "主要結果", "Key Results", "考察", "Discussion",
        "手法", "Methods", "解析・実験条件", "Conditions", "主な内容", "要点",
    ])
    deny_sections: list[str] = Field(default_factory=lambda: [
        "根拠情報", "収録案件", "メインタイトル",
    ])
    weights: FigureWeights = Field(default_factory=FigureWeights)

    def to_dict(self) -> Dict[str, Any]:
        """figure_select 側は pydantic を知らない（dict 契約）ので変換する。"""
        d = self.model_dump(mode="json")
        d["weights"] = self.weights.model_dump(mode="json")
        return d


class AppConfig(BaseModel):
    ui: UIConfig = Field(default_factory=UIConfig)
    figures: FigureConfig = Field(default_factory=FigureConfig)
    redaction: RedactionConfig = Field(default_factory=RedactionConfig)
    watch_folder: WatchFolderConfig = Field(default_factory=WatchFolderConfig)
    ledger: LedgerConfig = Field(default_factory=LedgerConfig)
    batch: BatchConfig = Field(default_factory=BatchConfig)
    site: SiteConfig = Field(default_factory=SiteConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    paths: PathsConfig = Field(default_factory=PathsConfig)
    workflow: WorkflowConfig = Field(default_factory=WorkflowConfig)


def load_config(path: Optional[str] = None) -> AppConfig:
    cfg_path = Path(path) if path else PROJECT_ROOT / "config.yaml"
    if not cfg_path.exists():
        return AppConfig()
    raw = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
    return AppConfig.model_validate(raw)
